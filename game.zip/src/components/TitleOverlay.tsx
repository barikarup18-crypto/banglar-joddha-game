import React, { useEffect, useState } from 'react';
import {
  canClaimDailyGift,
  DAILY_GIFT_COINS,
} from '../game/apsaraSystem';
import { toBengaliNumber } from '../game/GameEngine';
import {
  ApsaraProgressState,
  ApsaraVoiceState,
  FriendEntry,
  GamchaStyle,
  MissionId,
  WEAPON_CATALOG,
  WEAPON_SLOT_ORDER,
  WeaponType,
} from '../game/types';
import { ApsaraStage } from './ApsaraStage';

export type LobbyPanel = 'character' | 'weapon' | 'map' | 'friends' | 'rewards' | null;

interface TitleOverlayProps {
  highScore: number;
  muted: boolean;
  gamchaStyle: GamchaStyle;
  weaponType: WeaponType;
  progress: ApsaraProgressState;
  friends: FriendEntry[];
  apsaraVoiceState: ApsaraVoiceState;
  apsaraSpeechText: string;
  apsaraTranscript: string;
  apsaraVoiceMuted: boolean;
  apsaraMicNotice: string | null;
  externalPanelRequest: { panel: LobbyPanel; nonce: number } | null;
  onSelectGamcha: (style: GamchaStyle) => void;
  onSelectWeapon: (weapon: WeaponType) => void;
  onStart: () => void;
  onToggleMute: () => void;
  onToggleApsaraListen: () => void;
  onToggleApsaraVoiceMute: () => void;
  onSendApsaraPrompt: (utterance: string) => void;
  onSendFriendRequest: (friendIdOrName: string) => void;
  onAcceptFriendRequest: (friendId: string) => void;
  onInviteFriend: (friendId: string) => void;
  onAddNewFriendByName: (name: string) => void;
  onClaimDailyGift: () => void;
  onClaimMissionReward: (missionId: MissionId) => void;
  onSelectTitle: (title: string) => void;
}

const WEAPON_DISPLAY_STATS: Record<
  WeaponType,
  { subtitle: string; badge: string; powerPct: number; rangePct: number; barColor: string }
> = {
  agni47: {
    subtitle: 'স্বয়ংক্রিয় রাইফেল',
    badge: '২৪ গুলি',
    powerPct: 76,
    rangePct: 82,
    barColor: 'bg-[#f5c03e]',
  },
  kalbhairav: {
    subtitle: 'ভারী শটগান · ৫x স্প্রেড',
    badge: '৮ শেল',
    powerPct: 96,
    rangePct: 46,
    barColor: 'bg-[#ee6034]',
  },
  trishul: {
    subtitle: 'দূরপাল্লার স্নাইপার · ৪x স্কোপ',
    badge: '৫ গুলি',
    powerPct: 98,
    rangePct: 98,
    barColor: 'bg-[#56beff]',
  },
  fala: {
    subtitle: 'দ্রুত নীরব তীক্ষ্ণ ফলা',
    badge: 'অসীম',
    powerPct: 84,
    rangePct: 24,
    barColor: 'bg-[#d6e4f2]',
  },
};

export const TitleOverlay: React.FC<TitleOverlayProps> = ({
  highScore,
  muted,
  gamchaStyle,
  weaponType,
  progress,
  friends,
  apsaraVoiceState,
  apsaraSpeechText,
  apsaraTranscript,
  apsaraVoiceMuted,
  apsaraMicNotice,
  externalPanelRequest,
  onSelectGamcha,
  onSelectWeapon,
  onStart,
  onToggleMute,
  onToggleApsaraListen,
  onToggleApsaraVoiceMute,
  onSendApsaraPrompt,
  onSendFriendRequest,
  onAcceptFriendRequest,
  onInviteFriend,
  onAddNewFriendByName,
  onClaimDailyGift,
  onClaimMissionReward,
  onSelectTitle,
}) => {
  const [activePanel, setActivePanel] = useState<LobbyPanel>(null);
  const [newFriendInput, setNewFriendInput] = useState('');

  useEffect(() => {
    if (externalPanelRequest && externalPanelRequest.panel) {
      setActivePanel(externalPanelRequest.panel);
    }
  }, [externalPanelRequest]);

  const togglePanel = (panel: Exclude<LobbyPanel, null>) => {
    setActivePanel((prev) => (prev === panel ? null : panel));
  };

  const dailyReady = canClaimDailyGift(progress);
  const claimableMissionsCount = progress.missions.filter(
    (m) => !m.claimed && m.progress >= m.target,
  ).length;
  const totalRewardsReady = (dailyReady ? 1 : 0) + claimableMissionsCount;
  const incomingRequestsCount = friends.filter((f) => f.status === 'incoming_request').length;

  const handleManualAddFriend = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newFriendInput.trim();
    if (!trimmed) return;
    onAddNewFriendByName(trimmed);
    setNewFriendInput('');
  };

  return (
    <div className="pointer-events-none fixed inset-0 z-30 flex flex-col justify-between pb-[max(0.75rem,env(safe-area-inset-bottom))] pl-[max(0.75rem,env(safe-area-inset-left))] pr-[max(0.75rem,env(safe-area-inset-right))] pt-[max(0.75rem,env(safe-area-inset-top))] sm:px-6 sm:py-5">
      {/* Subtle top/bottom cinematic edge shading without obstructing the center 3D hero */}
      <div className="pointer-events-none fixed inset-x-0 top-0 -z-10 h-24 bg-gradient-to-b from-[#130b07]/70 to-transparent" />
      <div className="pointer-events-none fixed inset-x-0 bottom-0 -z-10 h-28 bg-gradient-to-t from-[#130b07]/78 to-transparent" />

      {/* TOP BAR: Player Profile Badge (Left) + Game Title Emblem & Audio (Right) */}
      <div className="flex items-start justify-between gap-2">
        {/* Top-Left: Player Profile Badge ('ভানু • LV 1') + Live Gold Coins & Diamonds */}
        <div className="pointer-events-auto flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2.5 rounded-xl border border-[#f5c763]/55 bg-[#19110c]/90 px-2.5 py-1.5 shadow-[0_6px_20px_rgba(0,0,0,0.52)]">
            <div className="relative flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-lg border border-[#ffd87d]/70 bg-gradient-to-b from-[#8f261f] to-[#3a120e]">
              <svg viewBox="0 0 40 40" className="h-9 w-9">
                <path d="M6 38 Q20 26 34 38 Z" fill={gamchaStyle === 'red-white' ? '#c92228' : '#1b7a3d'} />
                <path d="M10 38 Q20 30 30 38 Z" fill="#faf3e6" fillOpacity="0.65" />
                <circle cx="20" cy="17" r="8.5" fill="#c99163" />
                <path d="M11 16 C11 8, 29 8, 29 16 C26 11, 14 11, 11 16 Z" fill="#181414" />
                <rect
                  x="11.5"
                  y="12.5"
                  width="17"
                  height="2.8"
                  rx="1"
                  fill={gamchaStyle === 'red-white' ? '#d42028' : '#208844'}
                />
                <path d="M16.5 21 Q20 19.6 23.5 21" stroke="#181414" strokeWidth="1.6" fill="none" strokeLinecap="round" />
              </svg>
            </div>

            <div className="pr-1">
              <div className="flex items-center gap-1.5">
                <span className="font-bengali-ui whitespace-nowrap text-sm font-bold tracking-wide text-[#fff4de] sm:text-base">
                  ভানু • LV 1
                </span>
              </div>
              <div className="mt-0.5 flex items-center gap-1.5">
                <div className="h-1.5 w-16 overflow-hidden rounded-full bg-[#362418] sm:w-20">
                  <div className="h-full w-[42%] rounded-full bg-gradient-to-r from-[#f7b529] to-[#ffe17a]" />
                </div>
                <span className="font-bengali-ui whitespace-nowrap text-[10px] font-semibold text-[#ffd87c]">
                  {progress.activeTitle}
                </span>
              </div>
            </div>
          </div>

          {/* Live স্বর্ণমুদ্রা (Gold Coins) & Diamonds Currency Strip */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            <button
              type="button"
              onClick={() => togglePanel('rewards')}
              title="স্বর্ণমুদ্রা ও অপ্সরার উপহার"
              className="flex items-center gap-1.5 rounded-lg border border-[#f5c763]/45 bg-[#19110c]/88 px-2.5 py-1.5 shadow-[0_4px_14px_rgba(0,0,0,0.45)] transition-colors hover:border-[#ffd873]"
            >
              <svg viewBox="0 0 20 20" className="h-4 w-4 shrink-0">
                <circle cx="10" cy="10" r="8.5" fill="#f7c034" stroke="#9e640b" strokeWidth="1.4" />
                <circle cx="10" cy="10" r="5.5" fill="none" stroke="#fff0b5" strokeWidth="1.1" />
                <text x="10" y="13.2" textAnchor="middle" fontSize="8.5" fontWeight="bold" fill="#7c4704">
                  ৳
                </text>
              </svg>
              <span className="font-bengali-ui tabular-nums text-xs font-bold text-[#ffe59e] sm:text-sm">
                {toBengaliNumber(progress.goldCoins)}
              </span>
            </button>

            <div className="flex items-center gap-1.5 rounded-lg border border-[#63d4f5]/45 bg-[#111920]/88 px-2.5 py-1.5 shadow-[0_4px_14px_rgba(0,0,0,0.45)]">
              <svg viewBox="0 0 20 20" className="h-4 w-4 shrink-0">
                <polygon points="10,2 18,8 10,18 2,8" fill="#3fd3ff" stroke="#b8f3ff" strokeWidth="1.2" />
                <polyline points="2,8 18,8" stroke="#c8f7ff" strokeWidth="0.9" fill="none" />
                <polyline points="6,8 10,2 14,8 10,18 6,8" stroke="#0c84b0" strokeWidth="0.8" fill="none" />
              </svg>
              <span className="font-bengali-ui tabular-nums text-xs font-bold text-[#bdf2ff] sm:text-sm">
                {toBengaliNumber(progress.diamonds)}
              </span>
            </div>
          </div>
        </div>

        {/* Top-Right: Compact Game Emblem + Best Score + Audio Toggle */}
        <div className="flex items-center gap-2">
          <div className="hidden flex-col items-end sm:flex">
            <span className="font-bengali-display text-lg font-extrabold tracking-wide text-[#ffd875] drop-shadow-[0_2px_8px_rgba(0,0,0,0.85)]">
              বাংলার যোদ্ধা
            </span>
            {highScore > 0 ? (
              <span className="font-bengali-ui text-[11px] font-semibold text-[#f5ddb2]">
                সেরা স্কোর: <span className="tabular-nums text-[#ffd262]">{toBengaliNumber(highScore)}</span>
              </span>
            ) : (
              <span className="font-bengali-ui text-[11px] font-medium text-[#e9cfa8]/85">
                হুগলি তীর · পশ্চিমবঙ্গ
              </span>
            )}
          </div>

          <button
            type="button"
            onClick={onToggleMute}
            aria-label={muted ? 'শব্দ চালু করুন' : 'শব্দ বন্ধ করুন'}
            className="pointer-events-auto flex h-10 w-10 items-center justify-center rounded-xl border border-[#f0c268]/45 bg-[#19110c]/88 text-[#fdebd0] shadow hover:bg-[#2a1c14]"
          >
            {muted ? (
              <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-2">
                <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                <line x1="22" y1="9" x2="16" y2="15" strokeLinecap="round" />
                <line x1="16" y1="9" x2="22" y2="15" strokeLinecap="round" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-2">
                <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                <path d="M15.5 8.5a5 5 0 0 1 0 7" strokeLinecap="round" />
                <path d="M18.8 5.5a9 9 0 0 1 0 13" strokeLinecap="round" />
              </svg>
            )}
          </button>
        </div>
      </div>

      {/* MIDDLE ROW: Left Menu Rail & Contextual Drawer (Left) + Mysterious অপ্সরা Shadow Companion (Right) */}
      <div className="my-auto flex items-center justify-between gap-2">
        {/* Left Navigation Rail + Contextual Drawer */}
        <div className="relative flex items-center gap-2.5">
          <div className="pointer-events-auto flex flex-col gap-2">
            {/* 1. চরিত্র (Character) */}
            <button
              type="button"
              onClick={() => togglePanel('character')}
              className={`flex w-[118px] items-center gap-2 rounded-xl border px-2.5 py-2 text-left shadow-[0_6px_18px_rgba(0,0,0,0.48)] transition-colors active:scale-95 sm:w-[156px] sm:gap-2.5 sm:px-3 sm:py-2.5 ${
                activePanel === 'character'
                  ? 'border-[#ffd23f] bg-[#2e1d12]/94 text-[#fff4d4]'
                  : 'border-[#e8bc6a]/35 bg-[#18100b]/86 text-[#f5e3c6] hover:bg-[#241811]/92'
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-[#ffd05b] stroke-2 sm:h-5 sm:w-5">
                <circle cx="12" cy="7.5" r="3.5" />
                <path d="M5 20c0-3.8 3.1-6.5 7-6.5s7 2.7 7 6.5" strokeLinecap="round" />
              </svg>
              <div className="min-w-0">
                <div className="font-bengali-ui truncate text-xs font-bold leading-tight sm:text-sm">চরিত্র</div>
                <div className="font-bengali-ui truncate text-[10px] text-[#d6ba91]">
                  {gamchaStyle === 'red-white' ? 'লাল-সাদা গামছা' : 'সবুজ-সাদা গামছা'}
                </div>
              </div>
            </button>

            {/* 2. অস্ত্র (Weapons) */}
            <button
              type="button"
              onClick={() => togglePanel('weapon')}
              className={`flex w-[118px] items-center gap-2 rounded-xl border px-2.5 py-2 text-left shadow-[0_6px_18px_rgba(0,0,0,0.48)] transition-colors active:scale-95 sm:w-[156px] sm:gap-2.5 sm:px-3 sm:py-2.5 ${
                activePanel === 'weapon'
                  ? 'border-[#ffd23f] bg-[#2e1d12]/94 text-[#fff4d4]'
                  : 'border-[#e8bc6a]/35 bg-[#18100b]/86 text-[#f5e3c6] hover:bg-[#241811]/92'
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-[#ffd05b] stroke-2 sm:h-5 sm:w-5">
                <path d="M3 11h14l4-2v4l-4-1H13l-2 5H8l1-5H5l-2 2v-3z" strokeLinejoin="round" />
              </svg>
              <div className="min-w-0">
                <div className="font-bengali-ui truncate text-xs font-bold leading-tight sm:text-sm">অস্ত্র</div>
                <div className="font-bengali-ui truncate text-[10px] text-[#d6ba91]">
                  {WEAPON_CATALOG[weaponType].name}
                </div>
              </div>
            </button>

            {/* 3. বন্ধু তালিকা (Friends Drawer - Voice Synced) */}
            <button
              type="button"
              onClick={() => togglePanel('friends')}
              className={`relative flex w-[118px] items-center gap-2 rounded-xl border px-2.5 py-2 text-left shadow-[0_6px_18px_rgba(0,0,0,0.48)] transition-colors active:scale-95 sm:w-[156px] sm:gap-2.5 sm:px-3 sm:py-2.5 ${
                activePanel === 'friends'
                  ? 'border-[#6ee4ff] bg-[#132433]/94 text-[#e9f9ff]'
                  : 'border-[#63d4f5]/40 bg-[#121922]/86 text-[#e4f3fa] hover:bg-[#1a2533]/92'
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-[#74e4ff] stroke-2 sm:h-5 sm:w-5">
                <circle cx="9" cy="8" r="3.2" />
                <path d="M3 19c0-3.2 2.6-5.5 6-5.5s6 2.3 6 5.5" strokeLinecap="round" />
                <circle cx="17" cy="9" r="2.4" />
                <path d="M16.5 14.2c2.2.4 4 2 4.5 4.8" strokeLinecap="round" />
              </svg>
              <div className="min-w-0 flex-1">
                <div className="font-bengali-ui truncate text-xs font-bold leading-tight sm:text-sm">
                  বন্ধু তালিকা
                </div>
                <div className="font-bengali-ui truncate text-[10px] text-[#9ecfe0]">
                  {incomingRequestsCount > 0
                    ? `${toBengaliNumber(incomingRequestsCount)}টি অনুরোধ`
                    : `${toBengaliNumber(friends.filter((f) => f.status === 'friend').length)} জন বন্ধু`}
                </div>
              </div>
              {incomingRequestsCount > 0 && (
                <span className="font-bengali-ui tabular-nums flex h-5 min-w-[20px] items-center justify-center rounded-md bg-[#229dc9] px-1 text-[10px] font-extrabold text-white">
                  {toBengaliNumber(incomingRequestsCount)}
                </span>
              )}
            </button>

            {/* 4. অপ্সরার উপহার ও চ্যালেঞ্জ (Daily Gift & 3 Cross-Match Missions) */}
            <button
              type="button"
              onClick={() => togglePanel('rewards')}
              className={`relative flex w-[118px] items-center gap-2 rounded-xl border px-2.5 py-2 text-left shadow-[0_6px_18px_rgba(0,0,0,0.48)] transition-colors active:scale-95 sm:w-[156px] sm:gap-2.5 sm:px-3 sm:py-2.5 ${
                activePanel === 'rewards'
                  ? 'border-[#ffd966] bg-[#302010]/94 text-[#fff6dc]'
                  : totalRewardsReady > 0
                    ? 'border-[#ffd966]/80 bg-[#281b0e]/90 text-[#fff2cc] hover:bg-[#362412]'
                    : 'border-[#e8bc6a]/35 bg-[#18100b]/86 text-[#f5e3c6] hover:bg-[#241811]/92'
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-[#ffd768] stroke-2 sm:h-5 sm:w-5">
                <rect x="3" y="9" width="18" height="11" rx="2" />
                <path d="M12 9v11" />
                <path d="M3 13h18" />
                <path d="M12 9H8.5a2.2 2.2 0 1 1 0-4.4C10.8 4.6 12 9 12 9z" />
                <path d="M12 9h3.5a2.2 2.2 0 1 0 0-4.4C13.2 4.6 12 9 12 9z" />
              </svg>
              <div className="min-w-0 flex-1">
                <div className="font-bengali-ui truncate text-xs font-bold leading-tight sm:text-sm">
                  অপ্সরার উপহার
                </div>
                <div className="font-bengali-ui truncate text-[10px] text-[#f2cb79]">
                  {totalRewardsReady > 0 ? 'উপহার তৈরি!' : 'দৈনিক ও চ্যালেঞ্জ'}
                </div>
              </div>
              {totalRewardsReady > 0 && (
                <span className="font-bengali-ui tabular-nums flex h-5 min-w-[20px] items-center justify-center rounded-md bg-[#e09316] px-1 text-[10px] font-extrabold text-[#1e1004]">
                  {toBengaliNumber(totalRewardsReady)}
                </span>
              )}
            </button>

            {/* 5. ম্যাপ: বাংলা (Map) */}
            <button
              type="button"
              onClick={() => togglePanel('map')}
              className={`flex w-[118px] items-center gap-2 rounded-xl border px-2.5 py-2 text-left shadow-[0_6px_18px_rgba(0,0,0,0.48)] transition-colors active:scale-95 sm:w-[156px] sm:gap-2.5 sm:px-3 sm:py-2.5 ${
                activePanel === 'map'
                  ? 'border-[#ffd23f] bg-[#2e1d12]/94 text-[#fff4d4]'
                  : 'border-[#e8bc6a]/35 bg-[#18100b]/86 text-[#f5e3c6] hover:bg-[#241811]/92'
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-[#ffd05b] stroke-2 sm:h-5 sm:w-5">
                <path d="M12 21s-6-5.2-6-10a6 6 0 1 1 12 0c0 4.8-6 10-6 10z" />
                <circle cx="12" cy="11" r="2.2" />
              </svg>
              <div className="min-w-0">
                <div className="font-bengali-ui truncate text-xs font-bold leading-tight sm:text-sm">
                  ম্যাপ: বাংলা
                </div>
                <div className="font-bengali-ui truncate text-[10px] text-[#d6ba91]">হুগলি ও হাওড়া</div>
              </div>
            </button>
          </div>

          {/* Contextual Popover Drawers */}
          {activePanel === 'character' && (
            <div className="pointer-events-auto fixed left-3 top-1/2 z-40 w-[236px] -translate-y-1/2 rounded-xl border border-[#f5c763]/55 bg-[#1a110c]/95 p-4 shadow-[0_14px_36px_rgba(0,0,0,0.72)] md:static md:translate-y-0">
              <div className="mb-3 flex items-center justify-between">
                <span className="font-bengali-ui text-sm font-bold text-[#ffd978]">
                  গামছার রঙ বাছুন
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="text-xs font-bold text-[#ccb38e] hover:text-white"
                >
                  ✕
                </button>
              </div>
              <div className="flex flex-col gap-2">
                <button
                  type="button"
                  onClick={() => onSelectGamcha('red-white')}
                  className={`flex items-center gap-3 rounded-lg border px-3 py-2 text-left transition-colors ${
                    gamchaStyle === 'red-white'
                      ? 'border-[#ffd24c] bg-[#361813] text-[#fff6e3]'
                      : 'border-[#e8bc6a]/25 bg-[#231710] text-[#dfcaa8] hover:bg-[#2d1e15]'
                  }`}
                >
                  <span className="flex h-7 w-7 shrink-0 overflow-hidden rounded-md border border-[#fff2d9]/60">
                    <span className="h-full w-1/2 bg-[#c81f26]" />
                    <span className="h-full w-1/2 bg-[#faf3e6]" />
                  </span>
                  <div>
                    <div className="font-bengali-ui text-xs font-bold">লাল-সাদা গামছা</div>
                    <div className="font-bengali-ui text-[10px] text-[#c8b08a]">ঐতিহ্যবাহী বাংলা</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => onSelectGamcha('green-white')}
                  className={`flex items-center gap-3 rounded-lg border px-3 py-2 text-left transition-colors ${
                    gamchaStyle === 'green-white'
                      ? 'border-[#ffd24c] bg-[#16301d] text-[#fff6e3]'
                      : 'border-[#e8bc6a]/25 bg-[#231710] text-[#dfcaa8] hover:bg-[#2d1e15]'
                  }`}
                >
                  <span className="flex h-7 w-7 shrink-0 overflow-hidden rounded-md border border-[#fff2d9]/60">
                    <span className="h-full w-1/2 bg-[#1c7c3e]" />
                    <span className="h-full w-1/2 bg-[#faf3e6]" />
                  </span>
                  <div>
                    <div className="font-bengali-ui text-xs font-bold">সবুজ-সাদা গামছা</div>
                    <div className="font-bengali-ui text-[10px] text-[#c8b08a]">নদী তীরের স্টাইল</div>
                  </div>
                </button>
              </div>
            </div>
          )}

          {activePanel === 'weapon' && (
            <div className="pointer-events-auto fixed left-3 top-1/2 z-40 max-h-[68vh] w-[252px] -translate-y-1/2 overflow-y-auto rounded-xl border border-[#f5c763]/55 bg-[#1a110c]/95 p-4 shadow-[0_14px_36px_rgba(0,0,0,0.72)] md:static md:translate-y-0">
              <div className="mb-3 flex items-center justify-between">
                <span className="font-bengali-ui text-sm font-bold text-[#ffd978]">
                  অস্ত্র নির্বাচন
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="text-xs font-bold text-[#ccb38e] hover:text-white"
                >
                  ✕
                </button>
              </div>
              <div className="flex flex-col gap-2">
                {WEAPON_SLOT_ORDER.map((id) => {
                  const meta = WEAPON_CATALOG[id];
                  const stats = WEAPON_DISPLAY_STATS[id];
                  const selected = weaponType === id;
                  return (
                    <button
                      key={id}
                      type="button"
                      onClick={() => onSelectWeapon(id)}
                      className={`rounded-lg border p-2 text-left transition-colors ${
                        selected
                          ? 'border-[#ffd24c] bg-[#302012] text-[#fff6e3]'
                          : 'border-[#e8bc6a]/25 bg-[#231710] text-[#dfcaa8] hover:bg-[#2d1e15]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1">
                        <span className="font-bengali-ui text-xs font-bold">
                          {toBengaliNumber(meta.slot)}. {meta.name}
                        </span>
                        <span className="font-bengali-ui text-[10px] font-semibold text-[#ffd262]">
                          {stats.badge}
                        </span>
                      </div>
                      <div className="font-bengali-ui text-[10px] text-[#c8ae89]">{stats.subtitle}</div>
                      <div className="mt-1 space-y-1 text-[10px] text-[#cdb591]">
                        <div className="flex items-center gap-2">
                          <span className="w-9">ক্ষতি</span>
                          <div className="h-1.5 flex-1 rounded-full bg-[#3a281c]">
                            <div
                              style={{ width: `${stats.powerPct}%` }}
                              className={`h-full rounded-full ${stats.barColor}`}
                            />
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="w-9">রেঞ্জ</span>
                          <div className="h-1.5 flex-1 rounded-full bg-[#3a281c]">
                            <div
                              style={{ width: `${stats.rangePct}%` }}
                              className={`h-full rounded-full bg-[#f5c03e]`}
                            />
                          </div>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* বন্ধু তালিকা (Friends Drawer synced with Apsara Voice Commands) */}
          {activePanel === 'friends' && (
            <div className="pointer-events-auto fixed left-3 top-1/2 z-40 max-h-[70vh] w-[288px] -translate-y-1/2 overflow-y-auto rounded-xl border border-[#63d4f5]/55 bg-[#101822]/96 p-4 shadow-[0_14px_38px_rgba(0,0,0,0.78)] sm:w-[304px] md:static md:translate-y-0">
              <div className="mb-2 flex items-center justify-between">
                <span className="font-bengali-ui text-sm font-bold text-[#8be8ff]">
                  বন্ধু তালিকা · স্কোয়াড
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="text-xs font-bold text-[#9bc0d1] hover:text-white"
                >
                  ✕
                </button>
              </div>

              <p className="font-bengali-ui mb-2.5 text-[11px] leading-snug text-[#a5cad9]">
                ভয়েস কমান্ড বলুন: “রাহুল-কে রিকোয়েস্ট পাঠাও”, “অনির্বাণ-কে খেলায় ডাকো” বা “রিকোয়েস্ট গ্রহণ করো”
              </p>

              {/* Quick Add Friend by Name */}
              <form onSubmit={handleManualAddFriend} className="mb-3 flex gap-1.5">
                <input
                  type="text"
                  value={newFriendInput}
                  onChange={(e) => setNewFriendInput(e.target.value)}
                  placeholder="নতুন বন্ধুর নাম লিখুন..."
                  className="font-bengali-ui min-w-0 flex-1 rounded-lg border border-[#5cc9e8]/35 bg-[#0b121a] px-2.5 py-1.5 text-xs text-[#f0f9ff] placeholder:text-[#6f93a6] focus:border-[#ffd873] focus:outline-none"
                />
                <button
                  type="submit"
                  className="font-bengali-ui shrink-0 whitespace-nowrap rounded-lg border border-[#ffd875]/60 bg-[#2a2212] px-2.5 py-1.5 text-xs font-bold text-[#ffe394] hover:bg-[#3d3017]"
                >
                  পাঠান
                </button>
              </form>

              <div className="flex flex-col divide-y divide-[#5ac8e6]/15">
                {friends.map((friend) => (
                  <div
                    key={friend.id}
                    className="flex items-center justify-between gap-2 py-2 first:pt-0 last:pb-0"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bengali-ui truncate text-xs font-bold text-[#f4fbff]">
                          {friend.name}
                        </span>
                        <span className="font-bengali-ui tabular-nums text-[10px] text-[#9ac2d4]">
                          LV {toBengaliNumber(friend.level)}
                        </span>
                      </div>
                      <div className="font-bengali-ui text-[10px] text-[#8ab0c2]">
                        {friend.district} ·{' '}
                        {friend.presence === 'online'
                          ? 'অনলাইন'
                          : friend.presence === 'in_match'
                            ? 'ম্যাচে আছে'
                            : 'অফলাইন'}
                      </div>
                    </div>

                    <div className="shrink-0">
                      {friend.status === 'incoming_request' && (
                        <button
                          type="button"
                          onClick={() => onAcceptFriendRequest(friend.id)}
                          className="font-bengali-ui whitespace-nowrap rounded-lg border border-[#6be89c]/70 bg-[#133b25] px-2.5 py-1 text-[11px] font-bold text-[#c6ffdc] hover:bg-[#195233]"
                        >
                          গ্রহণ করুন
                        </button>
                      )}
                      {friend.status === 'suggested' && (
                        <button
                          type="button"
                          onClick={() => onSendFriendRequest(friend.id)}
                          className="font-bengali-ui whitespace-nowrap rounded-lg border border-[#ffd974]/65 bg-[#2f220f] px-2.5 py-1 text-[11px] font-bold text-[#ffe599] hover:bg-[#423015]"
                        >
                          রিকোয়েস্ট
                        </button>
                      )}
                      {friend.status === 'request_sent' && (
                        <span className="font-bengali-ui text-[10px] font-semibold text-[#ffd67d]">
                          অনুরোধ পাঠানো
                        </span>
                      )}
                      {friend.status === 'friend' && (
                        <button
                          type="button"
                          onClick={() => onInviteFriend(friend.id)}
                          disabled={friend.invitedToSquad}
                          className={`font-bengali-ui whitespace-nowrap rounded-lg border px-2.5 py-1 text-[11px] font-bold transition-colors ${
                            friend.invitedToSquad
                              ? 'border-[#64d7f5]/30 bg-[#152836] text-[#8bd9f0]'
                              : 'border-[#64d7f5]/70 bg-[#113952] text-[#d6f4ff] hover:bg-[#194e70]'
                          }`}
                        >
                          {friend.invitedToSquad ? 'ডাকা হয়েছে' : 'খেলায় ডাকুন'}
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* অপ্সরার উপহার ও চ্যালেঞ্জ (Daily Gift + 3 Cross-Match Missions) */}
          {activePanel === 'rewards' && (
            <div className="pointer-events-auto fixed left-3 top-1/2 z-40 max-h-[72vh] w-[294px] -translate-y-1/2 overflow-y-auto rounded-xl border border-[#ffd973]/60 bg-[#1a130e]/96 p-4 shadow-[0_14px_38px_rgba(0,0,0,0.78)] sm:w-[316px] md:static md:translate-y-0">
              <div className="mb-3 flex items-center justify-between">
                <span className="font-bengali-ui text-sm font-bold text-[#ffe082]">
                  অপ্সরার উপহার ও চ্যালেঞ্জ
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="text-xs font-bold text-[#ccb38e] hover:text-white"
                >
                  ✕
                </button>
              </div>

              {/* Daily Check-In Gift (+100 Gold Coins once/day) */}
              <div className="mb-3.5 border-b border-[#e7b96b]/20 pb-3.5">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <div className="font-bengali-ui text-xs font-bold text-[#fff4d4]">
                      দৈনিক উপস্থিতি উপহার
                    </div>
                    <div className="font-bengali-ui text-[11px] text-[#e0c496]">
                      +{toBengaliNumber(DAILY_GIFT_COINS)} স্বর্ণমুদ্রা · ধারা:{' '}
                      <span className="tabular-nums font-bold text-[#ffd86b]">
                        {toBengaliNumber(progress.dailyStreak)} দিন
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={onClaimDailyGift}
                    disabled={!dailyReady}
                    className={`font-bengali-ui shrink-0 whitespace-nowrap rounded-lg border px-3 py-1.5 text-xs font-extrabold transition-transform active:scale-95 ${
                      dailyReady
                        ? 'border-[#fff2b2] bg-gradient-to-b from-[#ffe047] to-[#d98406] text-[#241205] shadow-[0_0_16px_rgba(255,202,48,0.55)] hover:brightness-105'
                        : 'border-[#e7b96b]/25 bg-[#241a13] text-[#9e896f]'
                    }`}
                  >
                    {dailyReady ? 'উপহার নিন' : 'সংগৃহীত'}
                  </button>
                </div>
              </div>

              {/* 3 Cross-Match Missions */}
              <div className="space-y-3">
                {progress.missions.map((mission) => {
                  const pct = Math.min(100, Math.round((mission.progress / mission.target) * 100));
                  const completed = mission.progress >= mission.target;
                  const canClaim = completed && !mission.claimed;
                  return (
                    <div key={mission.id} className="space-y-1.5">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <div className="font-bengali-ui text-xs font-bold text-[#fcf0d8]">
                            {mission.title}
                          </div>
                          <div className="font-bengali-ui text-[10px] text-[#cfb58e]">
                            +{toBengaliNumber(mission.rewardCoins)} স্বর্ণমুদ্রা · উপাধি:{' '}
                            <span className="text-[#8be8ff]">{mission.unlockTitle}</span>
                          </div>
                        </div>

                        {canClaim ? (
                          <button
                            type="button"
                            onClick={() => onClaimMissionReward(mission.id)}
                            className="font-bengali-ui shrink-0 whitespace-nowrap rounded-lg border border-[#fff2b2] bg-gradient-to-b from-[#ffe047] to-[#d98406] px-2.5 py-1 text-[11px] font-extrabold text-[#241205] shadow-[0_0_14px_rgba(255,202,48,0.55)] hover:brightness-105 active:scale-95"
                          >
                            উপহার নিন
                          </button>
                        ) : (
                          <span className="font-bengali-ui tabular-nums shrink-0 text-[11px] font-bold text-[#f2cb79]">
                            {mission.claimed
                              ? 'সম্পন্ন'
                              : `${toBengaliNumber(mission.progress)}/${toBengaliNumber(mission.target)}`}
                          </span>
                        )}
                      </div>

                      <div className="h-1.5 w-full overflow-hidden rounded-full bg-[#332318]">
                        <div
                          style={{ width: `${pct}%` }}
                          className={`h-full rounded-full ${
                            mission.claimed
                              ? 'bg-[#45d982]'
                              : completed
                                ? 'bg-gradient-to-r from-[#ffd645] to-[#63e8ff]'
                                : 'bg-gradient-to-r from-[#d67e26] to-[#f7c448]'
                          }`}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Unlocked Titles Selector */}
              {progress.unlockedTitles.length > 1 && (
                <div className="mt-3.5 border-t border-[#e7b96b]/20 pt-3">
                  <div className="font-bengali-ui mb-1.5 text-[11px] font-bold text-[#ffd978]">
                    আনলক করা উপাধি নির্বাচন করুন
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {progress.unlockedTitles.map((title) => (
                      <button
                        key={title}
                        type="button"
                        onClick={() => onSelectTitle(title)}
                        className={`font-bengali-ui rounded-lg border px-2 py-1 text-[11px] font-semibold transition-colors ${
                          progress.activeTitle === title
                            ? 'border-[#6ee4ff] bg-[#143040] text-[#d6f7ff]'
                            : 'border-[#e7b96b]/25 bg-[#251a12] text-[#d8be98] hover:bg-[#332419]'
                        }`}
                      >
                        {title}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {activePanel === 'map' && (
            <div className="pointer-events-auto fixed left-3 top-1/2 z-40 w-[240px] -translate-y-1/2 rounded-xl border border-[#f5c763]/55 bg-[#1a110c]/95 p-4 shadow-[0_14px_36px_rgba(0,0,0,0.72)] md:static md:translate-y-0">
              <div className="mb-2 flex items-center justify-between">
                <span className="font-bengali-ui text-sm font-bold text-[#ffd978]">
                  ম্যাপ: বাংলা
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="text-xs font-bold text-[#ccb38e] hover:text-white"
                >
                  ✕
                </button>
              </div>
              <div className="font-bengali-display text-sm font-bold text-[#fff1d0]">
                হুগলি তীর · পশ্চিমবঙ্গ
              </div>
              <p className="font-bengali-ui mt-1 text-[11px] leading-relaxed text-[#d7be98]">
                হাওড়া ব্রিজের পটভূমিতে বাংলার মাটির গ্রাম, যোদ্ধা সিন্দুক, সঞ্জীবনী গাছ ও কালবৈশাখী বলয়ের মাঝে সার্ভাইভাল যুদ্ধ।
              </p>
              <div className="font-bengali-ui mt-2 text-[10px] font-semibold text-[#ffe08f]">
                হাওড়া সেতু · যোদ্ধা সিন্দুক · সঞ্জীবনী গাছ · কালবৈশাখী বলয়
              </div>
            </div>
          )}
        </div>

        {/* Right Stage: Mysterious Shadow Companion "অপ্সরা" */}
        <ApsaraStage
          voiceState={apsaraVoiceState}
          speechText={apsaraSpeechText}
          transcript={apsaraTranscript}
          voiceMuted={apsaraVoiceMuted}
          micNotice={apsaraMicNotice}
          auraBoosted={progress.auraBoostUnlocked}
          onToggleListen={onToggleApsaraListen}
          onToggleVoiceMute={onToggleApsaraVoiceMute}
          onSendPrompt={onSendApsaraPrompt}
        />
      </div>

      {/* BOTTOM BAR: Controls Hint (Left) + Drag-to-Rotate Cue (Center) + Glowing Yellow Start CTA (Right) */}
      <div className="flex items-end justify-between gap-2">
        <div className="hidden lg:block">
          <p className="font-bengali-ui text-xs font-medium text-[#edd9b9]/85 drop-shadow">
            ১–৪ অস্ত্র · F সিন্দুক/বাস · H সঞ্জীবনী · G বজ্র গোলা · রাইট-ক্লিক স্কোপ
          </p>
        </div>

        <div className="hidden items-center gap-2 rounded-full border border-[#f5c763]/35 bg-[#18100b]/74 px-3.5 py-1 text-[11px] font-semibold text-[#f5e1be] sm:flex">
          <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 fill-none stroke-[#ffd05b] stroke-2">
            <path d="M12 5l-5 5 5 5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <span className="font-bengali-ui">চরিত্র ঘোরাতে টেনে নিন</span>
          <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 fill-none stroke-[#ffd05b] stroke-2">
            <path d="M8 5l5 5-5 5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>

        <div className="pointer-events-auto ml-auto flex flex-col items-end gap-1">
          <div className="pr-1 text-[11px] font-semibold text-[#ffe5a3] drop-shadow">
            <span className="font-bengali-ui">সার্ভাইভাল মোড · ম্যাপ: বাংলা</span>
          </div>
          <button
            type="button"
            onClick={onStart}
            className="font-bengali-display group relative flex items-center gap-2.5 overflow-hidden rounded-xl border-2 border-[#fff4b8] bg-gradient-to-b from-[#ffe24a] via-[#f7b818] to-[#df8608] px-6 py-3 text-lg font-extrabold tracking-wide text-[#241205] shadow-[0_0_28px_rgba(255,194,32,0.72),0_10px_28px_rgba(0,0,0,0.6)] transition-transform duration-150 hover:scale-[1.03] hover:brightness-105 active:scale-[0.97] sm:gap-3 sm:px-9 sm:py-4 sm:text-2xl"
          >
            <span className="pointer-events-none absolute -left-8 top-0 h-full w-16 -skew-x-20 bg-white/25 transition-transform duration-300 group-hover:translate-x-56" />
            <span className="relative whitespace-nowrap">খেলা শুরু করুন</span>
            <svg
              viewBox="0 0 24 24"
              className="relative h-5 w-5 fill-[#241205] transition-transform duration-150 group-hover:translate-x-1 sm:h-6 sm:w-6"
            >
              <path d="M8 5v14l11-7z" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};
