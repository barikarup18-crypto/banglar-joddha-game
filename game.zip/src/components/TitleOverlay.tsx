import React, { useState } from 'react';
import { toBengaliNumber } from '../game/GameEngine';
import {
  ApsaraProgressState,
  FriendEntry,
  GamchaStyle,
  GameMode,
  TamedPetRecord,
  WEAPON_CATALOG,
  WEAPON_SLOT_ORDER,
  WeaponType,
} from '../game/types';

export type LobbyPanel = 'character' | 'weapon' | 'pet' | 'map' | 'friends' | null;

interface TitleOverlayProps {
  playerId: string;
  permanentPet: TamedPetRecord | null;
  gameMode: GameMode;
  highScore: number;
  muted: boolean;
  gamchaStyle: GamchaStyle;
  weaponType: WeaponType;
  progress: ApsaraProgressState;
  friends: FriendEntry[];
  onSelectGameMode: (mode: GameMode) => void;
  onSelectGamcha: (style: GamchaStyle) => void;
  onSelectWeapon: (weapon: WeaponType) => void;
  onStart: () => void;
  onToggleMute: () => void;
  onOpenSettings: () => void;
  onSendFriendRequest: (friendIdOrName: string) => void;
  onAcceptFriendRequest: (friendId: string) => void;
  onInviteFriend: (friendId: string) => void;
  onAddNewFriendByName: (name: string) => void;
}

const WEAPON_DISPLAY_STATS: Record<
  WeaponType,
  { subtitle: string; badge: string; powerPct: number; rangePct: number; barColor: string }
> = {
  agni47: {
    subtitle: 'স্বয়ংক্রিয় রাইফেল',
    badge: '২৪ গুলি',
    powerPct: 76,
    rangePct: 82,
    barColor: 'bg-[#f5c03e]',
  },
  kalbhairav: {
    subtitle: 'ভারী শটগান · ৫x স্প্রেড',
    badge: '৮ শেল',
    powerPct: 96,
    rangePct: 46,
    barColor: 'bg-[#ee6034]',
  },
  trishul: {
    subtitle: 'দূরপাল্লার স্নাইপার · ৪x স্কোপ',
    badge: '৫ গুলি',
    powerPct: 98,
    rangePct: 98,
    barColor: 'bg-[#56beff]',
  },
  fala: {
    subtitle: 'দ্রুত নীরব তীক্ষ্ণ ফলা',
    badge: 'অসীম',
    powerPct: 84,
    rangePct: 24,
    barColor: 'bg-[#d6e4f2]',
  },
};

export const TitleOverlay: React.FC<TitleOverlayProps> = ({
  playerId,
  permanentPet,
  gameMode,
  highScore,
  muted,
  gamchaStyle,
  weaponType,
  progress,
  friends,
  onSelectGameMode,
  onSelectGamcha,
  onSelectWeapon,
  onStart,
  onToggleMute,
  onOpenSettings,
  onSendFriendRequest,
  onAcceptFriendRequest,
  onInviteFriend,
  onAddNewFriendByName,
}) => {
  const [activePanel, setActivePanel] = useState<LobbyPanel>(null);
  const [newFriendInput, setNewFriendInput] = useState('');

  const togglePanel = (panel: Exclude<LobbyPanel, null>) => {
    setActivePanel((prev) => (prev === panel ? null : panel));
  };

  const incomingRequestsCount = friends.filter((f) => f.status === 'incoming_request').length;

  const handleManualAddFriend = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newFriendInput.trim();
    if (!trimmed) return;
    onAddNewFriendByName(trimmed);
    setNewFriendInput('');
  };

  return (
    <div className="pointer-events-none fixed inset-0 z-30 flex flex-col justify-between gap-1 overflow-hidden pb-[max(0.65rem,env(safe-area-inset-bottom))] pl-[max(0.65rem,env(safe-area-inset-left))] pr-[max(0.65rem,env(safe-area-inset-right))] pt-[max(0.65rem,env(safe-area-inset-top))] sm:pb-[max(0.9rem,env(safe-area-inset-bottom))] sm:pl-[max(1.25rem,env(safe-area-inset-left))] sm:pr-[max(1.25rem,env(safe-area-inset-right))] sm:pt-[max(0.85rem,env(safe-area-inset-top))]">
      {/* Subtle top/bottom cinematic edge shading without obstructing the center 3D hero */}
      <div className="pointer-events-none fixed inset-x-0 top-0 -z-10 h-24 bg-gradient-to-b from-[#130b07]/70 to-transparent" />
      <div className="pointer-events-none fixed inset-x-0 bottom-0 -z-10 h-28 bg-gradient-to-t from-[#130b07]/78 to-transparent" />

      {/* TOP BAR: Player Profile Badge (Left) + Game Title Emblem, Settings & Audio (Right) */}
      <div className="flex shrink-0 items-start justify-between gap-2">
        {/* Top-Left: Player Profile Badge ('ভানু • LV 1') + Live Gold Coins & Diamonds */}
        <div className="pointer-events-auto flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2.5 rounded-xl border border-[#f5c763]/55 bg-[#19110c]/90 px-2.5 py-1.5 shadow-[0_6px_20px_rgba(0,0,0,0.52)]">
            <div className="relative flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-lg border border-[#ffd87d]/70 bg-gradient-to-b from-[#8f261f] to-[#3a120e]">
              <svg viewBox="0 0 40 40" className="h-9 w-9">
                <path d="M6 38 Q20 26 34 38 Z" fill={gamchaStyle === 'red-white' ? '#c92228' : '#1b7a3d'} />
                <path d="M10 38 Q20 30 30 38 Z" fill="#faf3e6" fillOpacity="0.65" />
                <circle cx="20" cy="17" r="8.5" fill="#c99163" />
                <path d="M11 16 C11 8, 29 8, 29 16 C26 11, 14 11, 11 16 Z" fill="#181414" />
                <rect
                  x="11.5"
                  y="12.5"
                  width="17"
                  height="2.8"
                  rx="1"
                  fill={gamchaStyle === 'red-white' ? '#d42028' : '#208844'}
                />
                <path d="M16.5 21 Q20 19.6 23.5 21" stroke="#181414" strokeWidth="1.6" fill="none" strokeLinecap="round" />
              </svg>
            </div>

            <div className="pr-1">
              <div className="flex items-center gap-1.5">
                <span className="font-bengali-ui whitespace-nowrap text-sm font-bold tracking-wide text-[#fff4de] sm:text-base">
                  ভানু • LV 1
                </span>
                <span className="rounded bg-[#302014] px-1.5 py-0.5 font-mono text-[9px] font-bold tracking-wider text-[#ffd87c]">
                  {playerId}
                </span>
              </div>
              <div className="mt-0.5 flex items-center gap-1.5">
                <div className="h-1.5 w-16 overflow-hidden rounded-full bg-[#362418] sm:w-20">
                  <div className="h-full w-[42%] rounded-full bg-gradient-to-r from-[#f7b529] to-[#ffe17a]" />
                </div>
                <span className="font-bengali-ui whitespace-nowrap text-[10px] font-semibold text-[#ffd87c]">
                  {progress.activeTitle}
                </span>
              </div>
            </div>
          </div>

          {/* Live স্বর্ণমুদ্রা (Gold Coins) & Diamonds Currency Strip */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            <div className="flex items-center gap-1.5 rounded-lg border border-[#f5c763]/45 bg-[#19110c]/88 px-2.5 py-1.5 shadow-[0_4px_14px_rgba(0,0,0,0.45)]">
              <svg viewBox="0 0 20 20" className="h-4 w-4 shrink-0">
                <circle cx="10" cy="10" r="8.5" fill="#f7c034" stroke="#9e640b" strokeWidth="1.4" />
                <circle cx="10" cy="10" r="5.5" fill="none" stroke="#fff0b5" strokeWidth="1.1" />
                <text x="10" y="13.2" textAnchor="middle" fontSize="8.5" fontWeight="bold" fill="#7c4704">
                  ৳
                </text>
              </svg>
              <span className="font-bengali-ui tabular-nums text-xs font-bold text-[#ffe59e] sm:text-sm">
                {toBengaliNumber(progress.goldCoins)}
              </span>
            </div>

            <div className="flex items-center gap-1.5 rounded-lg border border-[#63d4f5]/45 bg-[#111920]/88 px-2.5 py-1.5 shadow-[0_4px_14px_rgba(0,0,0,0.45)]">
              <svg viewBox="0 0 20 20" className="h-4 w-4 shrink-0">
                <polygon points="10,2 18,8 10,18 2,8" fill="#3fd3ff" stroke="#b8f3ff" strokeWidth="1.2" />
                <polyline points="2,8 18,8" stroke="#c8f7ff" strokeWidth="0.9" fill="none" />
                <polyline points="6,8 10,2 14,8 10,18 6,8" stroke="#0c84b0" strokeWidth="0.8" fill="none" />
              </svg>
              <span className="font-bengali-ui tabular-nums text-xs font-bold text-[#bdf2ff] sm:text-sm">
                {toBengaliNumber(progress.diamonds)}
              </span>
            </div>
          </div>
        </div>

        {/* Top-Right: Compact Game Emblem + Best Score + Settings & Audio Toggles */}
        <div className="flex shrink-0 items-center gap-1.5 sm:gap-2">
          <div className="hidden flex-col items-end sm:flex">
            <span className="font-bengali-display text-lg font-extrabold tracking-wide text-[#ffd875] drop-shadow-[0_2px_8px_rgba(0,0,0,0.85)]">
              বাংলার যোদ্ধা
            </span>
            {highScore > 0 ? (
              <span className="font-bengali-ui text-[11px] font-semibold text-[#f5ddb2]">
                সেরা স্কোর: <span className="tabular-nums text-[#ffd262]">{toBengaliNumber(highScore)}</span>
              </span>
            ) : (
              <span className="font-bengali-ui text-[11px] font-medium text-[#e9cfa8]/85">
                হুগলি তীর · পশ্চিমবঙ্গ
              </span>
            )}
          </div>

          <button
            type="button"
            onClick={onOpenSettings}
            aria-label="সেটিংস"
            title="সেটিংস"
            className="pointer-events-auto flex h-10 items-center justify-center gap-1.5 rounded-xl border border-[#f0c268]/55 bg-[#19110c]/88 px-2.5 text-[#ffe394] shadow transition-colors hover:border-[#ffd76a] hover:bg-[#2a1c14] active:scale-95 sm:px-3"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5 shrink-0 fill-none stroke-current stroke-2">
              <circle cx="12" cy="12" r="3" />
              <path
                d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.08a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h.08a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v.08a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <span className="font-bengali-ui hidden whitespace-nowrap text-xs font-bold sm:inline">
              সেটিংস
            </span>
          </button>

          <button
            type="button"
            onClick={onToggleMute}
            aria-label={muted ? 'শব্দ চালু করুন' : 'শব্দ বন্ধ করুন'}
            className="pointer-events-auto flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-[#f0c268]/45 bg-[#19110c]/88 text-[#fdebd0] shadow hover:bg-[#2a1c14] active:scale-95"
          >
            {muted ? (
              <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-2">
                <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                <line x1="22" y1="9" x2="16" y2="15" strokeLinecap="round" />
                <line x1="16" y1="9" x2="22" y2="15" strokeLinecap="round" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-2">
                <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                <path d="M15.5 8.5a5 5 0 0 1 0 7" strokeLinecap="round" />
                <path d="M18.8 5.5a9 9 0 0 1 0 13" strokeLinecap="round" />
              </svg>
            )}
          </button>
        </div>
      </div>

      {/* MIDDLE ROW: Left Menu Rail & Contextual Drawer (Unobstructed 3D Hero Stage) */}
      <div className="my-auto flex min-h-0 flex-1 items-center justify-between gap-2 py-1">
        {/* Left Navigation Rail + Contextual Drawer */}
        <div className="relative flex max-h-full items-center gap-2.5">
          <div className="pointer-events-auto flex max-h-full flex-col gap-1.5 overflow-y-auto pr-0.5 sm:gap-2 [@media(max-height:500px)]:gap-1">
            {/* 1. চরিত্র (Character) */}
            <button
              type="button"
              onClick={() => togglePanel('character')}
              className={`flex w-[118px] items-center gap-2 rounded-xl border px-2.5 py-2 text-left shadow-[0_6px_18px_rgba(0,0,0,0.48)] transition-colors active:scale-95 sm:w-[156px] sm:gap-2.5 sm:px-3 sm:py-2.5 ${
                activePanel === 'character'
                  ? 'border-[#ffd23f] bg-[#2e1d12]/94 text-[#fff4d4]'
                  : 'border-[#e8bc6a]/35 bg-[#18100b]/86 text-[#f5e3c6] hover:bg-[#241811]/92'
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-[#ffd05b] stroke-2 sm:h-5 sm:w-5">
                <circle cx="12" cy="7.5" r="3.5" />
                <path d="M5 20c0-3.8 3.1-6.5 7-6.5s7 2.7 7 6.5" strokeLinecap="round" />
              </svg>
              <div className="min-w-0">
                <div className="font-bengali-ui truncate text-xs font-bold leading-tight sm:text-sm">চরিত্র</div>
                <div className="font-bengali-ui truncate text-[10px] text-[#d6ba91]">
                  {gamchaStyle === 'red-white' ? 'লাল-সাদা গামছা' : 'সবুজ-সাদা গামছা'}
                </div>
              </div>
            </button>

            {/* 2. অস্ত্র (Weapons) */}
            <button
              type="button"
              onClick={() => togglePanel('weapon')}
              className={`flex w-[118px] items-center gap-2 rounded-xl border px-2.5 py-2 text-left shadow-[0_6px_18px_rgba(0,0,0,0.48)] transition-colors active:scale-95 sm:w-[156px] sm:gap-2.5 sm:px-3 sm:py-2.5 ${
                activePanel === 'weapon'
                  ? 'border-[#ffd23f] bg-[#2e1d12]/94 text-[#fff4d4]'
                  : 'border-[#e8bc6a]/35 bg-[#18100b]/86 text-[#f5e3c6] hover:bg-[#241811]/92'
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-[#ffd05b] stroke-2 sm:h-5 sm:w-5">
                <path d="M3 11h14l4-2v4l-4-1H13l-2 5H8l1-5H5l-2 2v-3z" strokeLinejoin="round" />
              </svg>
              <div className="min-w-0">
                <div className="font-bengali-ui truncate text-xs font-bold leading-tight sm:text-sm">অস্ত্র</div>
                <div className="font-bengali-ui truncate text-[10px] text-[#d6ba91]">
                  {WEAPON_CATALOG[weaponType].name}
                </div>
              </div>
            </button>

            {/* 2b. পোষা সঙ্গী (Lifetime One-Pet Companion & Upgrade Placeholder) */}
            <button
              type="button"
              onClick={() => togglePanel('pet')}
              className={`relative flex w-[118px] items-center gap-2 rounded-xl border px-2.5 py-2 text-left shadow-[0_6px_18px_rgba(0,0,0,0.48)] transition-colors active:scale-95 sm:w-[156px] sm:gap-2.5 sm:px-3 sm:py-2.5 ${
                activePanel === 'pet'
                  ? 'border-[#6effc8] bg-[#102920]/94 text-[#e9fff6]'
                  : permanentPet
                    ? 'border-[#4df5b8]/55 bg-[#11211b]/88 text-[#e4fff5] hover:bg-[#163026]/92'
                    : 'border-[#e8bc6a]/35 bg-[#18100b]/86 text-[#f5e3c6] hover:bg-[#241811]/92'
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-[#5ef2bc] sm:h-5 sm:w-5">
                <circle cx="7.5" cy="8.5" r="2" />
                <circle cx="12" cy="6.8" r="2" />
                <circle cx="16.5" cy="8.5" r="2" />
                <path d="M12 11.4c-3.1 0-5.4 2.1-5.4 4.8 0 1.6 1.4 2.7 3 2.7 1.1 0 1.8-.4 2.4-.4s1.3.4 2.4.4c1.6 0 3-1.1 3-2.7 0-2.7-2.3-4.8-5.4-4.8z" />
              </svg>
              <div className="min-w-0 flex-1">
                <div className="font-bengali-ui truncate text-xs font-bold leading-tight sm:text-sm">
                  পোষা সঙ্গী
                </div>
                <div className="font-bengali-ui truncate text-[10px] text-[#9be8cc]">
                  {permanentPet ? permanentPet.nameBn : '১টি স্থায়ী বশ করুন'}
                </div>
              </div>
            </button>

            {/* 3. বন্ধু তালিকা (Friends Drawer - Voice Synced) */}
            <button
              type="button"
              onClick={() => togglePanel('friends')}
              className={`relative flex w-[118px] items-center gap-2 rounded-xl border px-2.5 py-2 text-left shadow-[0_6px_18px_rgba(0,0,0,0.48)] transition-colors active:scale-95 sm:w-[156px] sm:gap-2.5 sm:px-3 sm:py-2.5 ${
                activePanel === 'friends'
                  ? 'border-[#6ee4ff] bg-[#132433]/94 text-[#e9f9ff]'
                  : 'border-[#63d4f5]/40 bg-[#121922]/86 text-[#e4f3fa] hover:bg-[#1a2533]/92'
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-[#74e4ff] stroke-2 sm:h-5 sm:w-5">
                <circle cx="9" cy="8" r="3.2" />
                <path d="M3 19c0-3.2 2.6-5.5 6-5.5s6 2.3 6 5.5" strokeLinecap="round" />
                <circle cx="17" cy="9" r="2.4" />
                <path d="M16.5 14.2c2.2.4 4 2 4.5 4.8" strokeLinecap="round" />
              </svg>
              <div className="min-w-0 flex-1">
                <div className="font-bengali-ui truncate text-xs font-bold leading-tight sm:text-sm">
                  বন্ধু তালিকা
                </div>
                <div className="font-bengali-ui truncate text-[10px] text-[#9ecfe0]">
                  {incomingRequestsCount > 0
                    ? `${toBengaliNumber(incomingRequestsCount)}টি অনুরোধ`
                    : `${toBengaliNumber(friends.filter((f) => f.status === 'friend').length)} জন বন্ধু`}
                </div>
              </div>
              {incomingRequestsCount > 0 && (
                <span className="font-bengali-ui tabular-nums flex h-5 min-w-[20px] items-center justify-center rounded-md bg-[#229dc9] px-1 text-[10px] font-extrabold text-white">
                  {toBengaliNumber(incomingRequestsCount)}
                </span>
              )}
            </button>

            {/* 4. ম্যাপ: বাংলা (Map) */}
            <button
              type="button"
              onClick={() => togglePanel('map')}
              className={`flex w-[118px] items-center gap-2 rounded-xl border px-2.5 py-2 text-left shadow-[0_6px_18px_rgba(0,0,0,0.48)] transition-colors active:scale-95 sm:w-[156px] sm:gap-2.5 sm:px-3 sm:py-2.5 ${
                activePanel === 'map'
                  ? 'border-[#ffd23f] bg-[#2e1d12]/94 text-[#fff4d4]'
                  : 'border-[#e8bc6a]/35 bg-[#18100b]/86 text-[#f5e3c6] hover:bg-[#241811]/92'
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-[#ffd05b] stroke-2 sm:h-5 sm:w-5">
                <path d="M12 21s-6-5.2-6-10a6 6 0 1 1 12 0c0 4.8-6 10-6 10z" />
                <circle cx="12" cy="11" r="2.2" />
              </svg>
              <div className="min-w-0">
                <div className="font-bengali-ui truncate text-xs font-bold leading-tight sm:text-sm">
                  ম্যাপ: বাংলা
                </div>
                <div className="font-bengali-ui truncate text-[10px] text-[#d6ba91]">হুগলি ও হাওড়া</div>
              </div>
            </button>
          </div>

          {/* Contextual Popover Drawers */}
          {activePanel === 'character' && (
            <div className="pointer-events-auto fixed left-[max(0.75rem,env(safe-area-inset-left))] top-1/2 z-40 max-h-[calc(100dvh-6rem-env(safe-area-inset-top)-env(safe-area-inset-bottom))] w-[min(236px,calc(100vw-1.5rem-env(safe-area-inset-left)-env(safe-area-inset-right)))] -translate-y-1/2 overflow-y-auto rounded-xl border border-[#f5c763]/55 bg-[#1a110c]/95 p-4 shadow-[0_14px_36px_rgba(0,0,0,0.72)] md:static md:translate-y-0">
              <div className="mb-3 flex items-center justify-between">
                <span className="font-bengali-ui text-sm font-bold text-[#ffd978]">
                  গামছার রঙ বাছুন
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="text-xs font-bold text-[#ccb38e] hover:text-white"
                >
                  ✕
                </button>
              </div>
              <div className="flex flex-col gap-2">
                <button
                  type="button"
                  onClick={() => onSelectGamcha('red-white')}
                  className={`flex items-center gap-3 rounded-lg border px-3 py-2 text-left transition-colors ${
                    gamchaStyle === 'red-white'
                      ? 'border-[#ffd24c] bg-[#361813] text-[#fff6e3]'
                      : 'border-[#e8bc6a]/25 bg-[#231710] text-[#dfcaa8] hover:bg-[#2d1e15]'
                  }`}
                >
                  <span className="flex h-7 w-7 shrink-0 overflow-hidden rounded-md border border-[#fff2d9]/60">
                    <span className="h-full w-1/2 bg-[#c81f26]" />
                    <span className="h-full w-1/2 bg-[#faf3e6]" />
                  </span>
                  <div>
                    <div className="font-bengali-ui text-xs font-bold">লাল-সাদা গামছা</div>
                    <div className="font-bengali-ui text-[10px] text-[#c8b08a]">ঐতিহ্যবাহী বাংলা</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => onSelectGamcha('green-white')}
                  className={`flex items-center gap-3 rounded-lg border px-3 py-2 text-left transition-colors ${
                    gamchaStyle === 'green-white'
                      ? 'border-[#ffd24c] bg-[#16301d] text-[#fff6e3]'
                      : 'border-[#e8bc6a]/25 bg-[#231710] text-[#dfcaa8] hover:bg-[#2d1e15]'
                  }`}
                >
                  <span className="flex h-7 w-7 shrink-0 overflow-hidden rounded-md border border-[#fff2d9]/60">
                    <span className="h-full w-1/2 bg-[#1c7c3e]" />
                    <span className="h-full w-1/2 bg-[#faf3e6]" />
                  </span>
                  <div>
                    <div className="font-bengali-ui text-xs font-bold">সবুজ-সাদা গামছা</div>
                    <div className="font-bengali-ui text-[10px] text-[#c8b08a]">নদী তীরের স্টাইল</div>
                  </div>
                </button>
              </div>
            </div>
          )}

          {activePanel === 'weapon' && (
            <div className="pointer-events-auto fixed left-[max(0.75rem,env(safe-area-inset-left))] top-1/2 z-40 max-h-[calc(100dvh-6rem-env(safe-area-inset-top)-env(safe-area-inset-bottom))] w-[min(252px,calc(100vw-1.5rem-env(safe-area-inset-left)-env(safe-area-inset-right)))] -translate-y-1/2 overflow-y-auto rounded-xl border border-[#f5c763]/55 bg-[#1a110c]/95 p-4 shadow-[0_14px_36px_rgba(0,0,0,0.72)] md:static md:translate-y-0">
              <div className="mb-3 flex items-center justify-between">
                <span className="font-bengali-ui text-sm font-bold text-[#ffd978]">
                  অস্ত্র নির্বাচন
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="text-xs font-bold text-[#ccb38e] hover:text-white"
                >
                  ✕
                </button>
              </div>
              <div className="flex flex-col gap-2">
                {WEAPON_SLOT_ORDER.map((id) => {
                  const meta = WEAPON_CATALOG[id];
                  const stats = WEAPON_DISPLAY_STATS[id];
                  const selected = weaponType === id;
                  return (
                    <button
                      key={id}
                      type="button"
                      onClick={() => onSelectWeapon(id)}
                      className={`rounded-lg border p-2 text-left transition-colors ${
                        selected
                          ? 'border-[#ffd24c] bg-[#302012] text-[#fff6e3]'
                          : 'border-[#e8bc6a]/25 bg-[#231710] text-[#dfcaa8] hover:bg-[#2d1e15]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1">
                        <span className="font-bengali-ui text-xs font-bold">
                          {toBengaliNumber(meta.slot)}. {meta.name}
                        </span>
                        <span className="font-bengali-ui text-[10px] font-semibold text-[#ffd262]">
                          {stats.badge}
                        </span>
                      </div>
                      <div className="font-bengali-ui text-[10px] text-[#c8ae89]">{stats.subtitle}</div>
                      <div className="mt-1 space-y-1 text-[10px] text-[#cdb591]">
                        <div className="flex items-center gap-2">
                          <span className="w-9">ক্ষতি</span>
                          <div className="h-1.5 flex-1 rounded-full bg-[#3a281c]">
                            <div
                              style={{ width: `${stats.powerPct}%` }}
                              className={`h-full rounded-full ${stats.barColor}`}
                            />
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="w-9">রেঞ্জ</span>
                          <div className="h-1.5 flex-1 rounded-full bg-[#3a281c]">
                            <div
                              style={{ width: `${stats.rangePct}%` }}
                              className={`h-full rounded-full bg-[#f5c03e]`}
                            />
                          </div>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* পোষা সঙ্গী (Permanent Lifetime Companion & Future Resource Upgrade Placeholder Drawer) */}
          {activePanel === 'pet' && (
            <div className="pointer-events-auto fixed left-[max(0.75rem,env(safe-area-inset-left))] top-1/2 z-40 max-h-[calc(100dvh-6rem-env(safe-area-inset-top)-env(safe-area-inset-bottom))] w-[min(308px,calc(100vw-1.5rem-env(safe-area-inset-left)-env(safe-area-inset-right)))] -translate-y-1/2 overflow-y-auto rounded-xl border border-[#5ef2bc]/60 bg-[#0e1b16]/96 p-4 shadow-[0_14px_38px_rgba(0,0,0,0.78)] md:static md:translate-y-0">
              <div className="mb-2.5 flex items-center justify-between gap-2">
                <span className="font-bengali-ui text-sm font-bold text-[#88ffd4]">
                  পোষা সঙ্গী · আজীবনের নিয়ম
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="text-xs font-bold text-[#9bc9b8] hover:text-white"
                >
                  ✕
                </button>
              </div>

              <div className="mb-3 flex items-center justify-between rounded-lg border border-[#5ef2bc]/25 bg-[#0a1410] px-2.5 py-1.5 text-[11px]">
                <span className="font-bengali-ui text-[#b8decf]">প্লেয়ার আইডি</span>
                <span className="font-mono font-bold text-[#ffe27a]">{playerId}</span>
              </div>

              {permanentPet ? (
                <div className="space-y-3">
                  <div className="rounded-lg border border-[#5ef2bc]/45 bg-[#122b22] p-3">
                    <div className="flex items-center justify-between gap-2">
                      <div>
                        <div className="font-bengali-display text-base font-bold text-[#f2fff9]">
                          {permanentPet.nameBn}
                        </div>
                        <div className="font-bengali-ui text-[11px] font-semibold text-[#8cffd4]">
                          {permanentPet.titleBn}
                        </div>
                      </div>
                      <span className="font-bengali-ui rounded-md border border-[#ffd873]/55 bg-[#2a200d] px-2 py-0.5 text-[10px] font-bold text-[#ffe28a]">
                        স্থায়ী লক
                      </span>
                    </div>
                    <p className="font-bengali-ui mt-2 text-[11px] leading-relaxed text-[#cceee1]">
                      সহায়তা: {permanentPet.assistRoleBn}
                    </p>
                    <div className="mt-2 flex items-center justify-between text-[10px] text-[#9fd8c4]">
                      <span className="font-bengali-ui">বন্ধন শক্তি</span>
                      <span className="font-bengali-ui tabular-nums font-bold text-[#7fffcb]">
                        {toBengaliNumber(permanentPet.bondStrength)}%
                      </span>
                    </div>
                    <p className="font-bengali-ui mt-1.5 text-[10px] text-[#b4d9cb]/85">
                      এই আইডি-তে আজীবনের সঙ্গী স্থায়ীভাবে যুক্ত হয়েছে — দ্বিতীয় প্রাণী বশ করা যাবে না।
                    </p>
                  </div>

                  {/* Clean Placeholder Structure for Future Resource-Based Pet Upgrades */}
                  <div className="rounded-lg border border-[#f5c763]/35 bg-[#1b160e]/90 p-3">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-bengali-ui text-xs font-bold text-[#ffe08a]">
                        সঙ্গী আপগ্রেড (স্তর {toBengaliNumber(permanentPet.upgrades.level)}/
                        {toBengaliNumber(permanentPet.upgrades.maxLevel)})
                      </span>
                      <span className="font-bengali-ui rounded bg-[#332614] px-1.5 py-0.5 text-[9px] font-bold text-[#ffd26a]">
                        শীঘ্রই আসছে
                      </span>
                    </div>
                    <div className="font-bengali-ui mt-1.5 text-[11px] text-[#dfcaa8]">
                      পরবর্তী রিসোর্স: {permanentPet.upgrades.nextLevelResourceName} (
                      {toBengaliNumber(permanentPet.upgrades.nextLevelResourceCost)})
                    </div>
                    <div className="font-bengali-ui mt-1 text-[10px] text-[#bda684]">
                      {permanentPet.upgrades.upgradeLockedReason}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-2.5">
                  <div className="rounded-lg border border-[#ffd873]/40 bg-[#24190d] p-2.5">
                    <div className="font-bengali-ui text-xs font-bold text-[#ffe28a]">
                      আজীবনে কেবল ১টি প্রাণী বশ করা যাবে!
                    </div>
                    <p className="font-bengali-ui mt-1 text-[11px] leading-relaxed text-[#e6d1b0]">
                      ম্যাচে সুন্দরবনের বাঘ, বাংলার চিতাবাঘ বা প্রহরী কুকুরের মুখোমুখি হোন এবং সতর্কভাবে বশ করুন।
                    </p>
                  </div>

                  <ol className="font-bengali-ui space-y-1.5 text-[11px] leading-snug text-[#d6f5e8]">
                    <li>
                      <span className="font-bold text-[#ffe078]">১. লড়ে দুর্বল করুন:</span> ক্ষিপ্র প্রাণীটির স্বাস্থ্য ২২% এর নিচে নামান — কিন্তু <span className="font-bold text-[#ff8a80]">মারা গেলে বশ ব্যর্থ হবে!</span>
                    </li>
                    <li>
                      <span className="font-bold text-[#ffe078]">২. সোনালি বলয়ে বশ করুন [T]:</span> দ্রুত সোনালি বলয়ে ঢুকে <span className="font-bold text-[#88ffd4]">প্রাণী বশ করুন</span> বাটনে চাপুন (দেরি করলে শক্তি ফিরে পাবে)।
                    </li>
                    <li>
                      <span className="font-bold text-[#ffe078]">৩. সম্পূর্ণ স্থির থাকুন:</span> ৪.৫ সেকেন্ড এক চুলও নড়াচড়া বা আঘাত এড়িয়ে চললে প্রাণীটি আপনার আইডি-র স্থায়ী সঙ্গী হবে।
                    </li>
                  </ol>

                  <button
                    type="button"
                    onClick={() => {
                      onSelectGameMode('pet_taming');
                      setActivePanel(null);
                    }}
                    className={`font-bengali-ui w-full rounded-lg border px-3 py-2 text-xs font-extrabold transition-colors active:scale-95 ${
                      gameMode === 'pet_taming'
                        ? 'border-[#7fffcb] bg-[#144734] text-[#d6fff0]'
                        : 'border-[#5ef2bc]/75 bg-[#12382a] text-[#a8ffe0] hover:bg-[#194f3b]'
                    }`}
                  >
                    {gameMode === 'pet_taming'
                      ? 'প্রাণী বশ মোড নির্বাচিত আছে'
                      : 'প্রাণী বশ মোড নির্বাচন করুন'}
                  </button>
                </div>
              )}
            </div>
          )}

          {/* বন্ধু তালিকা (Friends Drawer synced with Apsara Voice Commands) */}
          {activePanel === 'friends' && (
            <div className="pointer-events-auto fixed left-[max(0.75rem,env(safe-area-inset-left))] top-1/2 z-40 max-h-[calc(100dvh-6rem-env(safe-area-inset-top)-env(safe-area-inset-bottom))] w-[min(304px,calc(100vw-1.5rem-env(safe-area-inset-left)-env(safe-area-inset-right)))] -translate-y-1/2 overflow-y-auto rounded-xl border border-[#63d4f5]/55 bg-[#101822]/96 p-4 shadow-[0_14px_38px_rgba(0,0,0,0.78)] md:static md:translate-y-0">
              <div className="mb-2 flex items-center justify-between">
                <span className="font-bengali-ui text-sm font-bold text-[#8be8ff]">
                  বন্ধু তালিকা · স্কোয়াড
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="text-xs font-bold text-[#9bc0d1] hover:text-white"
                >
                  ✕
                </button>
              </div>

              {/* Quick Add Friend by Name */}
              <form onSubmit={handleManualAddFriend} className="mb-3 flex gap-1.5">
                <input
                  type="text"
                  value={newFriendInput}
                  onChange={(e) => setNewFriendInput(e.target.value)}
                  placeholder="নতুন বন্ধুর নাম লিখুন..."
                  className="font-bengali-ui min-w-0 flex-1 rounded-lg border border-[#5cc9e8]/35 bg-[#0b121a] px-2.5 py-1.5 text-xs text-[#f0f9ff] placeholder:text-[#6f93a6] focus:border-[#ffd873] focus:outline-none"
                />
                <button
                  type="submit"
                  className="font-bengali-ui shrink-0 whitespace-nowrap rounded-lg border border-[#ffd875]/60 bg-[#2a2212] px-2.5 py-1.5 text-xs font-bold text-[#ffe394] hover:bg-[#3d3017]"
                >
                  পাঠান
                </button>
              </form>

              <div className="flex flex-col divide-y divide-[#5ac8e6]/15">
                {friends.map((friend) => (
                  <div
                    key={friend.id}
                    className="flex items-center justify-between gap-2 py-2 first:pt-0 last:pb-0"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bengali-ui truncate text-xs font-bold text-[#f4fbff]">
                          {friend.name}
                        </span>
                        <span className="font-bengali-ui tabular-nums text-[10px] text-[#9ac2d4]">
                          LV {toBengaliNumber(friend.level)}
                        </span>
                      </div>
                      <div className="font-bengali-ui text-[10px] text-[#8ab0c2]">
                        {friend.district} ·{' '}
                        {friend.presence === 'online'
                          ? 'অনলাইন'
                          : friend.presence === 'in_match'
                            ? 'ম্যাচে আছে'
                            : 'অফলাইন'}
                      </div>
                    </div>

                    <div className="shrink-0">
                      {friend.status === 'incoming_request' && (
                        <button
                          type="button"
                          onClick={() => onAcceptFriendRequest(friend.id)}
                          className="font-bengali-ui whitespace-nowrap rounded-lg border border-[#6be89c]/70 bg-[#133b25] px-2.5 py-1 text-[11px] font-bold text-[#c6ffdc] hover:bg-[#195233]"
                        >
                          গ্রহণ করুন
                        </button>
                      )}
                      {friend.status === 'suggested' && (
                        <button
                          type="button"
                          onClick={() => onSendFriendRequest(friend.id)}
                          className="font-bengali-ui whitespace-nowrap rounded-lg border border-[#ffd974]/65 bg-[#2f220f] px-2.5 py-1 text-[11px] font-bold text-[#ffe599] hover:bg-[#423015]"
                        >
                          রিকোয়েস্ট
                        </button>
                      )}
                      {friend.status === 'request_sent' && (
                        <span className="font-bengali-ui text-[10px] font-semibold text-[#ffd67d]">
                          অনুরোধ পাঠানো
                        </span>
                      )}
                      {friend.status === 'friend' && (
                        <button
                          type="button"
                          onClick={() => onInviteFriend(friend.id)}
                          disabled={friend.invitedToSquad}
                          className={`font-bengali-ui whitespace-nowrap rounded-lg border px-2.5 py-1 text-[11px] font-bold transition-colors ${
                            friend.invitedToSquad
                              ? 'border-[#64d7f5]/30 bg-[#152836] text-[#8bd9f0]'
                              : 'border-[#64d7f5]/70 bg-[#113952] text-[#d6f4ff] hover:bg-[#194e70]'
                          }`}
                        >
                          {friend.invitedToSquad ? 'ডাকা হয়েছে' : 'খেলায় ডাকুন'}
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activePanel === 'map' && (
            <div className="pointer-events-auto fixed left-[max(0.75rem,env(safe-area-inset-left))] top-1/2 z-40 max-h-[calc(100dvh-6rem-env(safe-area-inset-top)-env(safe-area-inset-bottom))] w-[min(240px,calc(100vw-1.5rem-env(safe-area-inset-left)-env(safe-area-inset-right)))] -translate-y-1/2 overflow-y-auto rounded-xl border border-[#f5c763]/55 bg-[#1a110c]/95 p-4 shadow-[0_14px_36px_rgba(0,0,0,0.72)] md:static md:translate-y-0">
              <div className="mb-2 flex items-center justify-between">
                <span className="font-bengali-ui text-sm font-bold text-[#ffd978]">
                  ম্যাপ: বাংলা
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="text-xs font-bold text-[#ccb38e] hover:text-white"
                >
                  ✕
                </button>
              </div>
              <div className="font-bengali-display text-sm font-bold text-[#fff1d0]">
                হুগলি তীর · পশ্চিমবঙ্গ
              </div>
              <p className="font-bengali-ui mt-1 text-[11px] leading-relaxed text-[#d7be98]">
                হাওড়া ব্রিজের পটভূমিতে বাংলার মাটির গ্রাম, যোদ্ধা সিন্দুক, সঞ্জীবনী গাছ ও কালবৈশাখী বলয়ের মাঝে সার্ভাইভাল যুদ্ধ।
              </p>
              <div className="font-bengali-ui mt-2 text-[10px] font-semibold text-[#ffe08f]">
                হাওড়া সেতু · যোদ্ধা সিন্দুক · সঞ্জীবনী গাছ · কালবৈশাখী বলয়
              </div>
            </div>
          )}
        </div>
      </div>

      {/* BOTTOM BAR: Controls Hint (Left) + Drag-to-Rotate Cue (Center) + Glowing Yellow Start CTA (Right) */}
      <div className="flex items-end justify-between gap-2">
        <div className="hidden lg:block">
          <p className="font-bengali-ui text-xs font-medium text-[#edd9b9]/85 drop-shadow">
            ১–৪ অস্ত্র · F সিন্দুক/বাস · H সঞ্জীবনী · G বজ্র গোলা · রাইট-ক্লিক স্কোপ
          </p>
        </div>

        <div className="hidden items-center gap-2 rounded-full border border-[#f5c763]/35 bg-[#18100b]/74 px-3.5 py-1 text-[11px] font-semibold text-[#f5e1be] sm:flex">
          <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 fill-none stroke-[#ffd05b] stroke-2">
            <path d="M12 5l-5 5 5 5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <span className="font-bengali-ui">চরিত্র ঘোরাতে টেনে নিন</span>
          <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 fill-none stroke-[#ffd05b] stroke-2">
            <path d="M8 5l5 5-5 5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>

        <div className="pointer-events-auto ml-auto flex flex-col items-end gap-1.5">
          {/* Mode Selector: Survival Mode vs Separate Pet Taming Mode */}
          <div className="flex items-center gap-1 rounded-xl border border-[#f5c763]/45 bg-[#140d09]/90 p-1 shadow-[0_6px_18px_rgba(0,0,0,0.55)] backdrop-blur-md">
            <button
              type="button"
              onClick={() => onSelectGameMode('survival')}
              className={`font-bengali-ui whitespace-nowrap rounded-lg px-2.5 py-1 text-[11px] font-bold transition-all sm:px-3 sm:py-1.5 sm:text-xs ${
                gameMode === 'survival'
                  ? 'bg-gradient-to-b from-[#ffd952] to-[#d4820a] text-[#241205] shadow-[0_0_12px_rgba(255,196,46,0.45)]'
                  : 'text-[#e5cfa8] hover:bg-white/10 hover:text-[#fff5dd]'
              }`}
            >
              সার্ভাইভাল মোড
            </button>
            <button
              type="button"
              onClick={() => onSelectGameMode('pet_taming')}
              className={`font-bengali-ui flex items-center gap-1 whitespace-nowrap rounded-lg px-2.5 py-1 text-[11px] font-bold transition-all sm:px-3 sm:py-1.5 sm:text-xs ${
                gameMode === 'pet_taming'
                  ? 'bg-gradient-to-b from-[#3ee8a8] to-[#117a53] text-[#052419] shadow-[0_0_14px_rgba(62,232,168,0.5)]'
                  : 'text-[#b5edd8] hover:bg-white/10 hover:text-[#e6fff5]'
              }`}
            >
              <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 shrink-0 fill-current">
                <circle cx="6.2" cy="6.8" r="1.7" />
                <circle cx="10" cy="5.4" r="1.7" />
                <circle cx="13.8" cy="6.8" r="1.7" />
                <path d="M10 9.4c-2.6 0-4.6 1.8-4.6 4.1 0 1.4 1.2 2.3 2.5 2.3 1 0 1.5-.4 2.1-.4s1.1.4 2.1.4c1.3 0 2.5-.9 2.5-2.3 0-2.3-2-4.1-4.6-4.1z" />
              </svg>
              <span>প্রাণী বশ মোড</span>
            </button>
          </div>

          <div className="pr-1 text-[11px] font-semibold text-[#ffe5a3] drop-shadow">
            <span className="font-bengali-ui">
              {gameMode === 'pet_taming'
                ? permanentPet
                  ? `প্রাণী বশ মোড · স্থায়ী সঙ্গী: ${permanentPet.nameBn}`
                  : 'প্রাণী বশ মোড · আজীবনে ১টি স্থায়ী সঙ্গী'
                : 'সার্ভাইভাল মোড · ম্যাপ: বাংলা'}
            </span>
          </div>

          <button
            type="button"
            onClick={onStart}
            className={`font-bengali-display group relative flex items-center gap-2.5 overflow-hidden rounded-xl border-2 px-6 py-3 text-lg font-extrabold tracking-wide transition-transform duration-150 hover:scale-[1.03] hover:brightness-105 active:scale-[0.97] sm:gap-3 sm:px-9 sm:py-4 sm:text-2xl ${
              gameMode === 'pet_taming'
                ? 'border-[#b8ffe4] bg-gradient-to-b from-[#45f0b2] via-[#1cc488] to-[#0d7d56] text-[#052418] shadow-[0_0_28px_rgba(45,230,165,0.68),0_10px_28px_rgba(0,0,0,0.6)]'
                : 'border-[#fff4b8] bg-gradient-to-b from-[#ffe24a] via-[#f7b818] to-[#df8608] text-[#241205] shadow-[0_0_28px_rgba(255,194,32,0.72),0_10px_28px_rgba(0,0,0,0.6)]'
            }`}
          >
            <span className="pointer-events-none absolute -left-8 top-0 h-full w-16 -skew-x-20 bg-white/25 transition-transform duration-300 group-hover:translate-x-56" />
            <span className="relative whitespace-nowrap">
              {gameMode === 'pet_taming' ? 'শিকার ও বশ শুরু' : 'খেলা শুরু করুন'}
            </span>
            <svg
              viewBox="0 0 24 24"
              className="relative h-5 w-5 fill-current transition-transform duration-150 group-hover:translate-x-1 sm:h-6 sm:w-6"
            >
              <path d="M8 5v14l11-7z" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};
