import React, { useState } from 'react';
import { toBengaliNumber } from '../game/GameEngine';
import {
  ANIMAL_HEART_TIER_ORDER,
  ANIMAL_HEART_TIERS,
  computePetStats,
  computePlayerMaxHealth,
  computePlayerWeaponDamageMult,
  getNextPetUpgradeCost,
  getNextPlayerUpgradeCost,
  PET_MAX_LEVEL,
} from '../game/petSystem';
import {
  AnimalHeartWallet,
  ApsaraProgressState,
  GamchaStyle,
  GameMode,
  HERO_OUTFIT_CATALOG,
  HERO_OUTFIT_ORDER,
  HeroOutfitId,
  LevelUpFeedback,
  LoadoutPreset,
  TamedPetRecord,
  WEAPON_CATALOG,
  WEAPON_SLOT_ORDER,
  WeaponType,
} from '../game/types';

export type LobbyPanel =
  | 'character'
  | 'weapon'
  | 'pet'
  | 'map'
  | 'animal_heart'
  | 'vault'
  | 'preset'
  | 'lab'
  | null;

interface TitleOverlayProps {
  guestName: string | null;
  playerId: string;
  playerLevel: number;
  playerMaxLevel: number;
  playerXp: number;
  playerXpToNext: number;
  playerMaxHealth: number;
  weaponDamageBonusPct: number;
  levelUpNotice: LevelUpFeedback | null;
  permanentPet: TamedPetRecord | null;
  animalHearts: AnimalHeartWallet;
  gameMode: GameMode;
  muted: boolean;
  gamchaStyle: GamchaStyle;
  heroOutfit: HeroOutfitId;
  weaponType: WeaponType;
  presets: LoadoutPreset[];
  progress: ApsaraProgressState;
  onSelectGameMode: (mode: GameMode) => void;
  onSelectGamcha: (style: GamchaStyle) => void;
  onSelectOutfit: (outfit: HeroOutfitId) => void;
  onSelectWeapon: (weapon: WeaponType) => void;
  onApplyPreset: (preset: LoadoutPreset) => void;
  onSavePreset: (slot: 1 | 2 | 3) => void;
  onUpgradePlayer: () => void;
  onUpgradePet: () => void;
  onStart: () => void;
  onToggleMute: () => void;
  onOpenSettings: () => void;
  onOpenGuestProfile: () => void;
}

const WEAPON_DISPLAY_STATS: Record<
  WeaponType,
  { subtitle: string; badge: string; powerPct: number; rangePct: number; barColor: string }
> = {
  agni47: {
    subtitle: 'স্বয়ংক্রিয় রাইফেল',
    badge: '২৪ গুলি',
    powerPct: 76,
    rangePct: 82,
    barColor: 'bg-[#f5c03e]',
  },
  kalbhairav: {
    subtitle: 'ভারী শটগান · ৫x স্প্রেড',
    badge: '৮ শেল',
    powerPct: 96,
    rangePct: 46,
    barColor: 'bg-[#ee6034]',
  },
  trishul: {
    subtitle: 'দূরপাল্লার স্নাইপার · ৪x স্কোপ',
    badge: '৫ গুলি',
    powerPct: 98,
    rangePct: 98,
    barColor: 'bg-[#56beff]',
  },
  fala: {
    subtitle: 'দ্রুত নীরব তীক্ষ্ণ ফলা',
    badge: 'অসীম',
    powerPct: 84,
    rangePct: 24,
    barColor: 'bg-[#d6e4f2]',
  },
};

export const TitleOverlay: React.FC<TitleOverlayProps> = ({
  guestName,
  playerId,
  playerLevel,
  playerMaxLevel,
  playerMaxHealth,
  weaponDamageBonusPct,
  levelUpNotice,
  permanentPet,
  animalHearts,
  gameMode,
  muted,
  gamchaStyle,
  heroOutfit,
  weaponType,
  presets,
  progress,
  onSelectGameMode,
  onSelectGamcha,
  onSelectOutfit,
  onSelectWeapon,
  onApplyPreset,
  onSavePreset,
  onUpgradePlayer,
  onUpgradePet,
  onStart,
  onToggleMute,
  onOpenSettings,
  onOpenGuestProfile,
}) => {
  const [activePanel, setActivePanel] = useState<LobbyPanel>(null);
  const [savedPresetSlot, setSavedPresetSlot] = useState<number | null>(null);
  const displayName = guestName && guestName.trim().length > 0 ? guestName : 'অতিথি';

  const playerLevelPct = Math.max(5, Math.min(100, (playerLevel / Math.max(1, playerMaxLevel)) * 100));
  const isPlayerMaxLv = playerLevel >= playerMaxLevel;
  const nextPlayerCost = getNextPlayerUpgradeCost(playerLevel);
  const canUpgradePlayer =
    !isPlayerMaxLv && nextPlayerCost > 0 && animalHearts.totalValue >= nextPlayerCost;

  const petCurLv = permanentPet?.upgrades.level ?? 0;
  const isPetMaxLv = Boolean(permanentPet && petCurLv >= PET_MAX_LEVEL);
  const nextPetCost = permanentPet ? getNextPetUpgradeCost(petCurLv) : 0;
  const canUpgradePet = Boolean(
    permanentPet && !isPetMaxLv && nextPetCost > 0 && animalHearts.totalValue >= nextPetCost,
  );
  const anyHeartLevelUpReady = canUpgradePlayer || canUpgradePet;

  const togglePanel = (panel: Exclude<LobbyPanel, null>) => {
    setActivePanel((prev) => (prev === panel ? null : panel));
  };

  return (
    <div className="pointer-events-none fixed inset-0 z-30 flex flex-col overflow-hidden pb-[max(0.65rem,env(safe-area-inset-bottom))] pl-[max(0.65rem,env(safe-area-inset-left))] pr-[max(0.65rem,env(safe-area-inset-right))] pt-[max(0.65rem,env(safe-area-inset-top))] sm:pb-[max(0.9rem,env(safe-area-inset-bottom))] sm:pl-[max(1.25rem,env(safe-area-inset-left))] sm:pr-[max(1.25rem,env(safe-area-inset-right))] sm:pt-[max(0.85rem,env(safe-area-inset-top))]">
      {/* Subtle top/bottom natural atmospheric edge shading without obstructing the center 3D hero */}
      <div className="pointer-events-none fixed inset-x-0 top-0 -z-10 h-24 bg-gradient-to-b from-[#0d0e0c]/75 to-transparent" />
      <div className="pointer-events-none fixed inset-x-0 bottom-0 -z-10 h-28 bg-gradient-to-t from-[#0d0e0c]/82 to-transparent" />

      {/* Lobby Level-Up Celebration Toast (Player or Pet Upgrade via Animal Hearts) */}
      {levelUpNotice && (
        <div
          key={levelUpNotice.seq}
          className={`pointer-events-none fixed left-1/2 top-[calc(4.6rem+env(safe-area-inset-top))] z-[60] flex w-max max-w-[90vw] -translate-x-1/2 flex-col items-center rounded-lg border px-4 py-2 text-center shadow-[0_12px_28px_rgba(0,0,0,0.75)] ${
            levelUpNotice.target === 'player'
              ? 'border-[#d6b368]/80 bg-[#171612]/96'
              : 'border-[#5ea88a]/80 bg-[#111916]/96'
          }`}
        >
          {(levelUpNotice.target === 'player' || levelUpNotice.target === 'both') && (
            <>
              <div className="font-bengali-display text-sm font-extrabold text-[#ffe178] sm:text-base">
                {displayName} লেভেল আপ! LV {toBengaliNumber(levelUpNotice.playerLevel)}
              </div>
              <div className="font-bengali-ui text-[10px] font-bold text-[#fff2cc] sm:text-xs">
                সর্বোচ্চ স্বাস্থ্য +{toBengaliNumber(levelUpNotice.playerHpGain)} · অস্ত্রের ক্ষতি +{toBengaliNumber(levelUpNotice.playerDmgBonusPct)}%
              </div>
            </>
          )}
          {(levelUpNotice.target === 'pet' || levelUpNotice.target === 'both') &&
            levelUpNotice.petNameBn &&
            levelUpNotice.petLevel && (
              <>
                <div className="font-bengali-display text-sm font-extrabold text-[#88ffd4] sm:text-base">
                  {levelUpNotice.petNameBn} লেভেল আপ! স্তর {toBengaliNumber(levelUpNotice.petLevel)}
                </div>
                <div className="font-bengali-ui text-[10px] font-bold text-[#d9fff1] sm:text-xs">
                  স্বাস্থ্য +{toBengaliNumber(levelUpNotice.petHpGain ?? 0)} · ক্ষতি +{toBengaliNumber(levelUpNotice.petDmgGain ?? 0)} · গতি +{toBengaliNumber(levelUpNotice.petSpeedGain ?? 0)}
                </div>
              </>
            )}
        </div>
      )}

      {/* TOP BAR: Player Profile Badge (Left) + Game Title Emblem, Settings & Audio (Right) */}
      <div className="relative z-20 flex shrink-0 items-start justify-between gap-2">
        {/* Top-Left: Player Profile Badge ('ভানু • LV X') + Live XP Bar + Live Gold Coins & Diamonds */}
        <div className="pointer-events-auto flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={onOpenGuestProfile}
            title="গেস্ট প্রোফাইল ও নাম পরিবর্তন"
            aria-label={`গেস্ট প্রোফাইল: ${displayName}`}
            className="group flex items-center gap-2.5 rounded-lg border border-[#b59c6b]/45 bg-[#121311]/92 px-2.5 py-1.5 text-left shadow-[0_6px_18px_rgba(0,0,0,0.6)] transition hover:border-[#d9b566]/80 hover:bg-[#1b1c19]/95 active:scale-[0.99]"
          >
            <div className="relative flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-md border border-[#b59c6b]/60 bg-gradient-to-b from-[#6e241f] to-[#2c110e]">
              <svg viewBox="0 0 40 40" className="h-9 w-9">
                <path d="M6 38 Q20 26 34 38 Z" fill={gamchaStyle === 'red-white' ? '#c92228' : '#1b7a3d'} />
                <path d="M10 38 Q20 30 30 38 Z" fill="#faf3e6" fillOpacity="0.65" />
                <circle cx="20" cy="17" r="8.5" fill="#c99163" />
                <path d="M11 16 C11 8, 29 8, 29 16 C26 11, 14 11, 11 16 Z" fill="#181414" />
                <rect
                  x="11.5"
                  y="12.5"
                  width="17"
                  height="2.8"
                  rx="1"
                  fill={gamchaStyle === 'red-white' ? '#d42028' : '#208844'}
                />
                <path d="M16.5 21 Q20 19.6 23.5 21" stroke="#181414" strokeWidth="1.6" fill="none" strokeLinecap="round" />
              </svg>
            </div>

            <div className="min-w-0 pr-1">
              <div className="flex items-center gap-1.5">
                <span className="font-bengali-ui max-w-[104px] truncate text-sm font-bold tracking-wide text-[#ece6d8] sm:max-w-[148px] sm:text-base">
                  {displayName}
                </span>
                <span className="font-bengali-ui whitespace-nowrap text-xs font-bold text-[#d9b566] sm:text-sm">
                  • LV {toBengaliNumber(playerLevel)}
                </span>
                <span className="rounded-sm border border-[#b59c6b]/25 bg-[#1e1f1b] px-1.5 py-0.5 font-mono text-[9px] font-bold tracking-wider text-[#d9b566]">
                  {playerId}
                </span>
                <svg
                  viewBox="0 0 16 16"
                  className="h-3 w-3 shrink-0 text-[#b59c6b]/75 transition group-hover:text-[#e6c882]"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.6"
                  aria-hidden="true"
                >
                  <path
                    d="M11.3 2.7a1.4 1.4 0 0 1 2 2L5.6 12.4l-2.9.8.8-2.9 7.8-7.6Z"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>
              <div className="mt-0.5 flex items-center gap-1.5">
                <div className="h-1.5 w-16 overflow-hidden rounded-sm bg-[#262823] sm:w-20">
                  <div
                    style={{ width: `${playerLevelPct}%` }}
                    className="h-full rounded-sm bg-gradient-to-r from-[#a87b28] to-[#dfb963] transition-[width] duration-200"
                  />
                </div>
                <span className="font-bengali-ui tabular-nums whitespace-nowrap text-[10px] font-semibold text-[#d9b566]">
                  {isPlayerMaxLv
                    ? 'সর্বোচ্চ LV'
                    : `LV ${toBengaliNumber(playerLevel)}/${toBengaliNumber(playerMaxLevel)}`}
                </span>
              </div>
              <div className="font-bengali-ui mt-0.5 flex items-center gap-1.5 text-[9px] font-semibold text-[#b3a895]">
                <span>স্বাস্থ্য {toBengaliNumber(playerMaxHealth)}</span>
                <span>·</span>
                <span className="text-[#d69b63]">
                  ক্ষতি +{toBengaliNumber(weaponDamageBonusPct)}%
                </span>
                <span className="hidden text-[#b59c6b]/85 sm:inline">· {progress.activeTitle}</span>
              </div>
            </div>
          </button>

          {/* Live স্বর্ণমুদ্রা (Gold Coins), Diamonds & Dedicated Standalone Animal Heart Button */}
          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
            <div className="flex items-center gap-1.5 rounded-md border border-[#b59c6b]/40 bg-[#121311]/92 px-2.5 py-1.5 shadow-[0_4px_12px_rgba(0,0,0,0.52)]">
              <svg viewBox="0 0 20 20" className="h-4 w-4 shrink-0">
                <circle cx="10" cy="10" r="8.5" fill="#c99a38" stroke="#6e4b10" strokeWidth="1.4" />
                <circle cx="10" cy="10" r="5.5" fill="none" stroke="#f0d999" strokeWidth="1.0" />
                <text x="10" y="13.2" textAnchor="middle" fontSize="8.5" fontWeight="bold" fill="#4f3306">
                  ৳
                </text>
              </svg>
              <span className="font-bengali-ui tabular-nums text-xs font-bold text-[#e6cfa0] sm:text-sm">
                {toBengaliNumber(progress.goldCoins)}
              </span>
            </div>

            <div className="flex items-center gap-1.5 rounded-md border border-[#6a98a8]/40 bg-[#111517]/92 px-2.5 py-1.5 shadow-[0_4px_12px_rgba(0,0,0,0.52)]">
              <svg viewBox="0 0 20 20" className="h-4 w-4 shrink-0">
                <polygon points="10,2 18,8 10,18 2,8" fill="#5da8c4" stroke="#b5dce8" strokeWidth="1.1" />
                <polyline points="2,8 18,8" stroke="#cbe7f0" strokeWidth="0.85" fill="none" />
                <polyline points="6,8 10,2 14,8 10,18 6,8" stroke="#245c73" strokeWidth="0.8" fill="none" />
              </svg>
              <span className="font-bengali-ui tabular-nums text-xs font-bold text-[#c2e0eb] sm:text-sm">
                {toBengaliNumber(progress.diamonds)}
              </span>
            </div>

            {/* Dedicated Separate Animal Heart Button — Opens Player & Animal Level-Up Modal */}
            <button
              type="button"
              onClick={() => togglePanel('animal_heart')}
              aria-label="এনিমেল হার্ট লেভেল আপ"
              className={`relative flex items-center gap-1.5 rounded-md border px-2.5 py-1.5 shadow-[0_4px_14px_rgba(0,0,0,0.55)] transition-colors active:scale-95 ${
                activePanel === 'animal_heart'
                  ? 'border-[#d67a88] bg-[#3b161e]/96 text-[#f5e1e5]'
                  : 'border-[#a84a5a]/65 bg-[#221215]/94 text-[#e8ccd2] hover:border-[#cf6b7b] hover:bg-[#2d161b]/96'
              }`}
            >
              <svg viewBox="0 0 20 20" className="h-4 w-4 shrink-0 fill-[#c93e54]">
                <path d="M10 17.4l-1.3-1.2C4.2 12.1 1.6 9.7 1.6 6.6 1.6 4.1 3.5 2.3 6 2.3c1.4 0 2.7.7 3.5 1.8h1c.8-1.1 2.1-1.8 3.5-1.8 2.5 0 4.4 1.8 4.4 4.3 0 3.1-2.6 5.5-7.1 9.6L10 17.4z" />
              </svg>
              <span className="font-bengali-ui whitespace-nowrap text-[11px] font-bold text-[#e8ccd2] sm:text-xs">
                এনিমেল হার্ট
              </span>
              <span className="font-bengali-ui tabular-nums rounded-sm border border-[#b59c6b]/30 bg-[#120b0c]/90 px-1.5 py-0.5 text-[11px] font-extrabold leading-none text-[#e0c078] sm:text-xs">
                {toBengaliNumber(animalHearts.totalValue)}
              </span>
              {anyHeartLevelUpReady && (
                <span
                  aria-hidden="true"
                  className="absolute -right-1 -top-1 inline-flex h-2.5 w-2.5 rounded-full border border-[#14100d] bg-[#d9a83c]"
                />
              )}
            </button>
          </div>
        </div>

        {/* Top-Right: Compact Game Emblem + Settings & Audio Toggles */}
        <div className="flex shrink-0 items-center gap-1.5 sm:gap-2">
          <div className="flex items-center gap-2">
            <div className="hidden flex-col items-end sm:flex">
              <span className="font-bengali-display text-lg font-extrabold tracking-wide text-[#e2c278] drop-shadow-[0_2px_6px_rgba(0,0,0,0.9)]">
                বাংলার যোদ্ধা
              </span>
              <span className="font-bengali-ui text-[11px] font-medium text-[#c2b8a3]">
                হুগলি তীর · পশ্চিমবঙ্গ
              </span>
            </div>
            <div className="h-10 w-10 shrink-0 overflow-hidden rounded-lg border border-[#b59c6b]/65 bg-[#121413] shadow-[0_6px_16px_rgba(0,0,0,0.65)] sm:h-11 sm:w-11">
              <img
                src="./assets/app-logo.png"
                alt="বাংলার যোদ্ধা"
                draggable={false}
                className="h-full w-full scale-[1.28] object-cover"
              />
            </div>
          </div>

          <button
            type="button"
            onClick={onOpenSettings}
            aria-label="সেটিংস"
            title="সেটিংস"
            className="pointer-events-auto flex h-10 items-center justify-center gap-1.5 rounded-lg border border-[#b59c6b]/45 bg-[#121311]/92 px-2.5 text-[#e2c994] shadow-[0_4px_12px_rgba(0,0,0,0.52)] transition-colors hover:border-[#d9b566]/80 hover:bg-[#1e201c] active:scale-95 sm:px-3"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5 shrink-0 fill-none stroke-current stroke-2">
              <circle cx="12" cy="12" r="3" />
              <path
                d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.08a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h.08a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v.08a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <span className="font-bengali-ui hidden whitespace-nowrap text-xs font-bold sm:inline">
              সেটিংস
            </span>
          </button>

          <button
            type="button"
            onClick={onToggleMute}
            aria-label={muted ? 'শব্দ চালু করুন' : 'শব্দ বন্ধ করুন'}
            className="pointer-events-auto flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-[#b59c6b]/40 bg-[#121311]/92 text-[#dfd5c3] shadow-[0_4px_12px_rgba(0,0,0,0.52)] hover:border-[#d9b566]/75 hover:bg-[#1e201c] active:scale-95"
          >
            {muted ? (
              <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-2">
                <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                <line x1="22" y1="9" x2="16" y2="15" strokeLinecap="round" />
                <line x1="16" y1="9" x2="22" y2="15" strokeLinecap="round" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-2">
                <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                <path d="M15.5 8.5a5 5 0 0 1 0 7" strokeLinecap="round" />
                <path d="M18.8 5.5a9 9 0 0 1 0 13" strokeLinecap="round" />
              </svg>
            )}
          </button>
        </div>
      </div>

      {/* MIDDLE ROW: Compact Left Menu Rail pushed cleanly below Top Profile/LV/XP Card and above Bottom Nav Strip */}
      <div className="relative z-10 mt-4 flex min-h-0 flex-1 items-start justify-start gap-2 pb-14 sm:mt-6 sm:pb-16 [@media(max-height:500px)]:mt-3 [@media(max-height:500px)]:pb-12">
        {/* Left Navigation Rail + Contextual Drawer */}
        <div className="relative flex max-h-full items-start gap-2">
          <div className="pointer-events-auto flex max-h-full flex-col gap-[3px] overflow-y-auto pr-0.5 sm:gap-1 [@media(max-height:500px)]:gap-[2px]">
            {/* 1. চরিত্র (Character) */}
            <button
              type="button"
              onClick={() => togglePanel('character')}
              className={`flex w-[82px] items-center gap-1 rounded-md border px-1.5 py-[3px] text-left shadow-[0_3px_10px_rgba(0,0,0,0.48)] transition-colors active:scale-95 sm:w-[104px] sm:gap-1.5 sm:px-2 sm:py-1 ${
                activePanel === 'character'
                  ? 'border-[#d9b566]/85 bg-[#23211b]/95 text-[#f2eadb]'
                  : 'border-[#b59c6b]/32 bg-[#121311]/90 text-[#dcd4c4] hover:border-[#b59c6b]/60 hover:bg-[#1b1c19]/94'
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-3 w-3 shrink-0 fill-none stroke-[#d9b566] stroke-2 sm:h-3.5 sm:w-3.5">
                <circle cx="12" cy="7.5" r="3.5" />
                <path d="M5 20c0-3.8 3.1-6.5 7-6.5s7 2.7 7 6.5" strokeLinecap="round" />
              </svg>
              <div className="min-w-0">
                <div className="font-bengali-ui truncate text-[10px] font-bold leading-[1.15] sm:text-[11px]">চরিত্র</div>
                <div className="font-bengali-ui truncate text-[8px] leading-[1.1] text-[#a79d8a] sm:text-[8.5px]">
                  {gamchaStyle === 'red-white' ? 'লাল-সাদা গামছা' : 'সবুজ-সাদা গামছা'}
                </div>
              </div>
            </button>

            {/* 2. অস্ত্র (Weapons) */}
            <button
              type="button"
              onClick={() => togglePanel('weapon')}
              className={`flex w-[82px] items-center gap-1 rounded-md border px-1.5 py-[3px] text-left shadow-[0_3px_10px_rgba(0,0,0,0.48)] transition-colors active:scale-95 sm:w-[104px] sm:gap-1.5 sm:px-2 sm:py-1 ${
                activePanel === 'weapon'
                  ? 'border-[#d9b566]/85 bg-[#23211b]/95 text-[#f2eadb]'
                  : 'border-[#b59c6b]/32 bg-[#121311]/90 text-[#dcd4c4] hover:border-[#b59c6b]/60 hover:bg-[#1b1c19]/94'
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-3 w-3 shrink-0 fill-none stroke-[#d9b566] stroke-2 sm:h-3.5 sm:w-3.5">
                <path d="M3 11h14l4-2v4l-4-1H13l-2 5H8l1-5H5l-2 2v-3z" strokeLinejoin="round" />
              </svg>
              <div className="min-w-0">
                <div className="font-bengali-ui truncate text-[10px] font-bold leading-[1.15] sm:text-[11px]">অস্ত্র</div>
                <div className="font-bengali-ui truncate text-[8px] leading-[1.1] text-[#a79d8a] sm:text-[8.5px]">
                  {WEAPON_CATALOG[weaponType].name}
                </div>
              </div>
            </button>

            {/* 2b. পোষা সঙ্গী (Lifetime One-Pet Companion & Upgrade Placeholder) */}
            <button
              type="button"
              onClick={() => togglePanel('pet')}
              className={`relative flex w-[82px] items-center gap-1 rounded-md border px-1.5 py-[3px] text-left shadow-[0_3px_10px_rgba(0,0,0,0.48)] transition-colors active:scale-95 sm:w-[104px] sm:gap-1.5 sm:px-2 sm:py-1 ${
                activePanel === 'pet'
                  ? 'border-[#66b898]/85 bg-[#14221c]/95 text-[#e6f5ee]'
                  : permanentPet
                    ? 'border-[#549e80]/55 bg-[#121b17]/92 text-[#dceee6] hover:bg-[#172620]/94'
                    : 'border-[#b59c6b]/32 bg-[#121311]/90 text-[#dcd4c4] hover:border-[#b59c6b]/60 hover:bg-[#1b1c19]/94'
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-3 w-3 shrink-0 fill-[#66b898] sm:h-3.5 sm:w-3.5">
                <circle cx="7.5" cy="8.5" r="2" />
                <circle cx="12" cy="6.8" r="2" />
                <circle cx="16.5" cy="8.5" r="2" />
                <path d="M12 11.4c-3.1 0-5.4 2.1-5.4 4.8 0 1.6 1.4 2.7 3 2.7 1.1 0 1.8-.4 2.4-.4s1.3.4 2.4.4c1.6 0 3-1.1 3-2.7 0-2.7-2.3-4.8-5.4-4.8z" />
              </svg>
              <div className="min-w-0 flex-1">
                <div className="font-bengali-ui truncate text-[10px] font-bold leading-[1.15] sm:text-[11px]">
                  পোষা সঙ্গী
                </div>
                <div className="font-bengali-ui truncate text-[8px] leading-[1.1] text-[#8bc2ab] sm:text-[8.5px]">
                  {permanentPet ? permanentPet.nameBn : '১টি স্থায়ী বশ করুন'}
                </div>
              </div>
            </button>

            {/* 3. ম্যাপ: বাংলা (Map) */}
            <button
              type="button"
              onClick={() => togglePanel('map')}
              className={`flex w-[82px] items-center gap-1 rounded-md border px-1.5 py-[3px] text-left shadow-[0_3px_10px_rgba(0,0,0,0.48)] transition-colors active:scale-95 sm:w-[104px] sm:gap-1.5 sm:px-2 sm:py-1 ${
                activePanel === 'map'
                  ? 'border-[#d9b566]/85 bg-[#23211b]/95 text-[#f2eadb]'
                  : 'border-[#b59c6b]/32 bg-[#121311]/90 text-[#dcd4c4] hover:border-[#b59c6b]/60 hover:bg-[#1b1c19]/94'
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-3 w-3 shrink-0 fill-none stroke-[#d9b566] stroke-2 sm:h-3.5 sm:w-3.5">
                <path d="M12 21s-6-5.2-6-10a6 6 0 1 1 12 0c0 4.8-6 10-6 10z" />
                <circle cx="12" cy="11" r="2.2" />
              </svg>
              <div className="min-w-0">
                <div className="font-bengali-ui truncate text-[10px] font-bold leading-[1.15] sm:text-[11px]">
                  ম্যাপ: বাংলা
                </div>
                <div className="font-bengali-ui truncate text-[8px] leading-[1.1] text-[#a79d8a] sm:text-[8.5px]">হুগলি ও হাওড়া</div>
              </div>
            </button>
          </div>

          {/* Contextual Popover Drawers */}
          {activePanel === 'character' && (
            <div className="pointer-events-auto fixed left-[max(0.75rem,env(safe-area-inset-left))] top-1/2 z-40 max-h-[calc(100dvh-6rem-env(safe-area-inset-top)-env(safe-area-inset-bottom))] w-[min(236px,calc(100vw-1.5rem-env(safe-area-inset-left)-env(safe-area-inset-right)))] -translate-y-1/2 overflow-y-auto rounded-lg border border-[#b59c6b]/45 bg-[#141512]/96 p-4 shadow-[0_16px_38px_rgba(0,0,0,0.78)] md:static md:translate-y-0">
              <div className="mb-3 flex items-center justify-between">
                <span className="font-bengali-ui text-sm font-bold text-[#ffd978]">
                  গামছার রঙ বাছুন
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="text-xs font-bold text-[#ccb38e] hover:text-white"
                >
                  ✕
                </button>
              </div>
              <div className="flex flex-col gap-2">
                <button
                  type="button"
                  onClick={() => onSelectGamcha('red-white')}
                  className={`flex items-center gap-3 rounded-lg border px-3 py-2 text-left transition-colors ${
                    gamchaStyle === 'red-white'
                      ? 'border-[#ffd24c] bg-[#361813] text-[#fff6e3]'
                      : 'border-[#e8bc6a]/25 bg-[#231710] text-[#dfcaa8] hover:bg-[#2d1e15]'
                  }`}
                >
                  <span className="flex h-7 w-7 shrink-0 overflow-hidden rounded-md border border-[#fff2d9]/60">
                    <span className="h-full w-1/2 bg-[#c81f26]" />
                    <span className="h-full w-1/2 bg-[#faf3e6]" />
                  </span>
                  <div>
                    <div className="font-bengali-ui text-xs font-bold">লাল-সাদা গামছা</div>
                    <div className="font-bengali-ui text-[10px] text-[#c8b08a]">ঐতিহ্যবাহী বাংলা</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => onSelectGamcha('green-white')}
                  className={`flex items-center gap-3 rounded-lg border px-3 py-2 text-left transition-colors ${
                    gamchaStyle === 'green-white'
                      ? 'border-[#ffd24c] bg-[#16301d] text-[#fff6e3]'
                      : 'border-[#e8bc6a]/25 bg-[#231710] text-[#dfcaa8] hover:bg-[#2d1e15]'
                  }`}
                >
                  <span className="flex h-7 w-7 shrink-0 overflow-hidden rounded-md border border-[#fff2d9]/60">
                    <span className="h-full w-1/2 bg-[#1c7c3e]" />
                    <span className="h-full w-1/2 bg-[#faf3e6]" />
                  </span>
                  <div>
                    <div className="font-bengali-ui text-xs font-bold">সবুজ-সাদা গামছা</div>
                    <div className="font-bengali-ui text-[10px] text-[#c8b08a]">নদী তীরের স্টাইল</div>
                  </div>
                </button>
              </div>
            </div>
          )}

          {activePanel === 'weapon' && (
            <div className="pointer-events-auto fixed left-[max(0.65rem,env(safe-area-inset-left))] top-[calc(4.15rem+env(safe-area-inset-top))] bottom-[calc(3.65rem+env(safe-area-inset-bottom))] z-40 w-[min(266px,calc(48vw-0.75rem))] overflow-y-auto rounded-lg border border-[#b59c6b]/45 bg-[#141512]/96 p-3.5 shadow-[0_16px_38px_rgba(0,0,0,0.78)] sm:p-4 lg:static lg:top-auto lg:bottom-auto lg:max-h-[calc(100dvh-11rem)] lg:w-[272px]">
              <div className="mb-3 flex items-center justify-between">
                <span className="font-bengali-ui text-sm font-bold text-[#ffd978]">
                  অস্ত্র নির্বাচন
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="text-xs font-bold text-[#ccb38e] hover:text-white"
                >
                  ✕
                </button>
              </div>
              <div className="flex flex-col gap-2">
                {WEAPON_SLOT_ORDER.map((id) => {
                  const meta = WEAPON_CATALOG[id];
                  const stats = WEAPON_DISPLAY_STATS[id];
                  const selected = weaponType === id;
                  return (
                    <button
                      key={id}
                      type="button"
                      onClick={() => onSelectWeapon(id)}
                      className={`rounded-lg border p-2 text-left transition-colors ${
                        selected
                          ? 'border-[#ffd24c] bg-[#302012] text-[#fff6e3]'
                          : 'border-[#e8bc6a]/25 bg-[#231710] text-[#dfcaa8] hover:bg-[#2d1e15]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1">
                        <span className="font-bengali-ui text-xs font-bold">
                          {toBengaliNumber(meta.slot)}. {meta.name}
                        </span>
                        <span className="font-bengali-ui text-[10px] font-semibold text-[#ffd262]">
                          {stats.badge}
                        </span>
                      </div>
                      <div className="font-bengali-ui text-[10px] text-[#c8ae89]">{stats.subtitle}</div>
                      <div className="mt-1 space-y-1 text-[10px] text-[#cdb591]">
                        <div className="flex items-center gap-2">
                          <span className="w-9">ক্ষতি</span>
                          <div className="h-1.5 flex-1 rounded-full bg-[#3a281c]">
                            <div
                              style={{ width: `${stats.powerPct}%` }}
                              className={`h-full rounded-full ${stats.barColor}`}
                            />
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="w-9">রেঞ্জ</span>
                          <div className="h-1.5 flex-1 rounded-full bg-[#3a281c]">
                            <div
                              style={{ width: `${stats.rangePct}%` }}
                              className={`h-full rounded-full bg-[#f5c03e]`}
                            />
                          </div>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* পোষা সঙ্গী (Permanent Lifetime Companion & Future Resource Upgrade Placeholder Drawer) */}
          {activePanel === 'pet' && (
            <div className="pointer-events-auto fixed left-[max(0.75rem,env(safe-area-inset-left))] top-1/2 z-40 max-h-[calc(100dvh-6rem-env(safe-area-inset-top)-env(safe-area-inset-bottom))] w-[min(308px,calc(100vw-1.5rem-env(safe-area-inset-left)-env(safe-area-inset-right)))] -translate-y-1/2 overflow-y-auto rounded-lg border border-[#5ea88a]/55 bg-[#111714]/96 p-4 shadow-[0_16px_40px_rgba(0,0,0,0.82)] md:static md:translate-y-0">
              <div className="mb-2.5 flex items-center justify-between gap-2">
                <span className="font-bengali-ui text-sm font-bold text-[#88ffd4]">
                  পোষা সঙ্গী · আজীবনের নিয়ম
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="text-xs font-bold text-[#9bc9b8] hover:text-white"
                >
                  ✕
                </button>
              </div>

              <div className="mb-2.5 flex items-center justify-between rounded-lg border border-[#5ef2bc]/25 bg-[#0a1410] px-2.5 py-1.5 text-[11px]">
                <span className="font-bengali-ui text-[#b8decf]">প্লেয়ার আইডি</span>
                <span className="font-mono font-bold text-[#ffe27a]">{playerId}</span>
              </div>

              {/* Per-Player Animal Heart Inventory Card */}
              <div className="mb-3 rounded-lg border border-rose-400/45 bg-[#231018]/90 px-2.5 py-2">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 shrink-0 fill-[#ff587a]">
                      <path d="M10 17.2l-1.2-1.1C4.4 12.2 1.8 9.8 1.8 6.8 1.8 4.4 3.6 2.6 6 2.6c1.4 0 2.7.7 3.5 1.8h1c.8-1.1 2.1-1.8 3.5-1.8 2.4 0 4.2 1.8 4.2 4.2 0 3-2.6 5.4-7 9.3L10 17.2z" />
                    </svg>
                    <span className="font-bengali-ui text-xs font-bold text-[#ffc2d0]">
                      এনিমেল হার্ট
                    </span>
                  </div>
                  <span className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#ffdf85]">
                    {toBengaliNumber(animalHearts.totalValue)} শক্তি
                  </span>
                </div>
                <div className="mt-1.5 grid grid-cols-2 gap-1">
                  {ANIMAL_HEART_TIER_ORDER.map((tier) => {
                    const count = animalHearts.tiers[tier] || 0;
                    const tMeta = ANIMAL_HEART_TIERS[tier];
                    const tierStyles: Record<number, string> = {
                      1: 'border-rose-300/45 bg-rose-500/20 text-[#ffe0e8]',
                      2: 'border-sky-300/50 bg-sky-500/20 text-[#d9f3ff]',
                      3: 'border-purple-300/55 bg-purple-500/20 text-[#f3dcff]',
                      4: 'border-amber-300/65 bg-amber-500/25 text-[#fff0c2]',
                    };
                    return (
                      <span
                        key={tier}
                        className={`font-bengali-ui flex items-center justify-between rounded border px-1.5 py-0.5 text-[9px] font-semibold ${
                          count > 0 ? tierStyles[tier] : 'border-white/10 bg-black/25 text-white/45'
                        }`}
                      >
                        <span>
                          {tMeta.shortNameBn} ({toBengaliNumber(tMeta.value)})
                        </span>
                        <span className="tabular-nums font-extrabold">×{toBengaliNumber(count)}</span>
                      </span>
                    );
                  })}
                </div>
                <p className="font-bengali-ui mt-1 text-[9px] leading-snug text-[#e6b8c4]/85">
                  খেলার সময় ৪ ধরনের এনিমেল হার্ট (সাধারণ ১ · দুর্লভ ৫ · মহাকাব্যিক ১৫ · কিংবদন্তি ৫০) সংগ্রহ করে লবিতে লেভেল আপ করুন।
                </p>
              </div>

              {permanentPet ? (
                (() => {
                  const curLv = permanentPet.upgrades.level;
                  const isMaxLv = curLv >= PET_MAX_LEVEL;
                  const nextCost = getNextPetUpgradeCost(curLv);
                  const nextStats = isMaxLv
                    ? null
                    : computePetStats(permanentPet.species, curLv + 1);
                  const canAfford = !isMaxLv && nextCost > 0 && animalHearts.totalValue >= nextCost;
                  const curStats = permanentPet.stats;

                  return (
                    <div className="space-y-3">
                      <div className="rounded-lg border border-[#5ef2bc]/45 bg-[#122b22] p-3">
                        <div className="flex items-center justify-between gap-2">
                          <div>
                            <div className="font-bengali-display text-base font-bold text-[#f2fff9]">
                              {permanentPet.nameBn}
                            </div>
                            <div className="font-bengali-ui text-[11px] font-semibold text-[#8cffd4]">
                              {permanentPet.titleBn} · স্তর {toBengaliNumber(curLv)}/{toBengaliNumber(PET_MAX_LEVEL)}
                            </div>
                          </div>
                          <span className="font-bengali-ui rounded-md border border-[#ffd873]/55 bg-[#2a200d] px-2 py-0.5 text-[10px] font-bold text-[#ffe28a]">
                            স্থায়ী লক
                          </span>
                        </div>
                        <p className="font-bengali-ui mt-1.5 text-[11px] leading-relaxed text-[#cceee1]">
                          সহায়তা: {permanentPet.assistRoleBn}
                        </p>

                        {/* Scaled Combat & Movement Stats Grid */}
                        <div className="mt-2.5 grid grid-cols-2 gap-1.5">
                          <div className="rounded-md border border-emerald-300/25 bg-[#0b1f18] px-2 py-1.5">
                            <div className="font-bengali-ui text-[9px] text-[#9fd8c4]">স্বাস্থ্য (HP)</div>
                            <div className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#e8fff6]">
                              {toBengaliNumber(curStats.maxHp)}
                              {nextStats && (
                                <span className="ml-1 text-[10px] font-bold text-[#7fffcb]">
                                  +{toBengaliNumber(nextStats.maxHp - curStats.maxHp)}
                                </span>
                              )}
                            </div>
                          </div>
                          <div className="rounded-md border border-amber-300/25 bg-[#0b1f18] px-2 py-1.5">
                            <div className="font-bengali-ui text-[9px] text-[#f3cfa0]">আক্রমণ ক্ষতি</div>
                            <div className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#ffe7b3]">
                              {toBengaliNumber(curStats.attackDamage)}
                              {nextStats && (
                                <span className="ml-1 text-[10px] font-bold text-[#ffd26a]">
                                  +{toBengaliNumber(nextStats.attackDamage - curStats.attackDamage)}
                                </span>
                              )}
                            </div>
                          </div>
                          <div className="rounded-md border border-sky-300/25 bg-[#0b1f18] px-2 py-1.5">
                            <div className="font-bengali-ui text-[9px] text-[#a7d8f0]">চলাচল গতি</div>
                            <div className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#dff4ff]">
                              {toBengaliNumber(curStats.moveSpeed)}
                              {nextStats && (
                                <span className="ml-1 text-[10px] font-bold text-[#7fd8ff]">
                                  +{toBengaliNumber(Number((nextStats.moveSpeed - curStats.moveSpeed).toFixed(1)))}
                                </span>
                              )}
                            </div>
                          </div>
                          <div className="rounded-md border border-purple-300/25 bg-[#0b1f18] px-2 py-1.5">
                            <div className="font-bengali-ui text-[9px] text-[#d6b8f5]">আঘাত কুলডাউন</div>
                            <div className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#f2e3ff]">
                              {toBengaliNumber(curStats.assistCooldown)} সে.
                              {nextStats && nextStats.assistCooldown < curStats.assistCooldown && (
                                <span className="ml-1 text-[10px] font-bold text-[#c79eff]">
                                  -{toBengaliNumber(Number((curStats.assistCooldown - nextStats.assistCooldown).toFixed(1)))}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        <p className="font-bengali-ui mt-2 text-[10px] text-[#b4d9cb]/85">
                          এই আইডি-তে আজীবনের সঙ্গী স্থায়ীভাবে যুক্ত আছে — দ্বিতীয় প্রাণী বশ করা যাবে না।
                        </p>
                      </div>

                      {/* Shortcut to Dedicated Animal Heart Level-Up Panel */}
                      <div className="rounded-lg border border-[#f5c763]/45 bg-[#1b150d]/95 p-3">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-bengali-ui text-xs font-bold text-[#ffe08a]">
                            সঙ্গী লেভেল-আপ (স্তর {toBengaliNumber(curLv)}/{toBengaliNumber(PET_MAX_LEVEL)})
                          </span>
                          <span
                            className={`font-bengali-ui rounded px-1.5 py-0.5 text-[9px] font-bold ${
                              isMaxLv
                                ? 'bg-emerald-500/25 text-[#88ffd4]'
                                : canAfford
                                  ? 'bg-rose-500/30 text-[#ffd6e0]'
                                  : 'bg-[#332614] text-[#ffd26a]'
                            }`}
                          >
                            {isMaxLv ? 'সর্বোচ্চ স্তর' : `প্রয়োজন: ${toBengaliNumber(nextCost)} হার্ট`}
                          </span>
                        </div>

                        <button
                          type="button"
                          onClick={() => setActivePanel('animal_heart')}
                          className="font-bengali-ui mt-2.5 flex w-full items-center justify-center gap-1.5 rounded-lg border border-[#ff9bb2]/80 bg-gradient-to-r from-[#9e1d44] to-[#c43a2b] px-3 py-2 text-xs font-extrabold text-white shadow-[0_4px_14px_rgba(225,65,95,0.35)] transition-all hover:brightness-110 active:scale-95"
                        >
                          <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 shrink-0 fill-[#ffd2dc]">
                            <path d="M10 17.2l-1.2-1.1C4.4 12.2 1.8 9.8 1.8 6.8 1.8 4.4 3.6 2.6 6 2.6c1.4 0 2.7.7 3.5 1.8h1c.8-1.1 2.1-1.8 3.5-1.8 2.4 0 4.2 1.8 4.2 4.2 0 3-2.6 5.4-7 9.3L10 17.2z" />
                          </svg>
                          <span>এনিমেল হার্ট লেভেল আপ প্যানেল খুলুন</span>
                        </button>

                        <div className="font-bengali-ui mt-2 text-[10px] leading-snug text-[#d8c3a3]">
                          {permanentPet.upgrades.unlockedPerks[permanentPet.upgrades.unlockedPerks.length - 1]}
                        </div>
                      </div>
                    </div>
                  );
                })()
              ) : (
                <div className="space-y-2.5">
                  <div className="rounded-lg border border-[#ffd873]/40 bg-[#24190d] p-2.5">
                    <div className="font-bengali-ui text-xs font-bold text-[#ffe28a]">
                      আজীবনে কেবল ১টি প্রাণী বশ করা যাবে!
                    </div>
                    <p className="font-bengali-ui mt-1 text-[11px] leading-relaxed text-[#e6d1b0]">
                      জঙ্গল, পাথুরে গুহা, পাথুরে পাহাড়, জলাভূমি, প্রাচীন ধ্বংসাবশেষ ও উন্মুক্ত তৃণভূমিতে লুকিয়ে থাকা গরিলা রাজা, অজগর সাপ, সিংহ রাজা, ভয়ংকর মাকড়সা, রয়্যাল টাইগার, বন্য শূকর ও ভালুক খুঁজে বের করে বশ করুন এবং এনিমেল হার্ট সংগ্রহ করুন।
                    </p>
                  </div>

                  <ol className="font-bengali-ui space-y-1.5 text-[11px] leading-snug text-[#d6f5e8]">
                    <li>
                      <span className="font-bold text-[#ffe078]">১. লড়ে দুর্বল করুন:</span> ক্ষিপ্র প্রাণীটির স্বাস্থ্য ২২% এর নিচে নামান — কিন্তু <span className="font-bold text-[#ff8a80]">মারা গেলে বশ ব্যর্থ হবে!</span>
                    </li>
                    <li>
                      <span className="font-bold text-[#ffe078]">২. সোনালি বলয়ে বশ করুন [T]:</span> দ্রুত সোনালি বলয়ে ঢুকে <span className="font-bold text-[#88ffd4]">প্রাণী বশ করুন</span> বাটনে চাপুন (দেরি করলে শক্তি ফিরে পাবে)।
                    </li>
                    <li>
                      <span className="font-bold text-[#ffe078]">৩. সম্পূর্ণ স্থির থাকুন:</span> ৪.৫ সেকেন্ড এক চুলও নড়াচড়া বা আঘাত এড়িয়ে চললে প্রাণীটি আপনার আইডি-র স্থায়ী সঙ্গী হবে।
                    </li>
                    <li>
                      <span className="font-bold text-[#ff9bb2]">৪. এনিমেল হার্ট দিয়ে লেভেল-আপ:</span> সব প্রাণী হার্ট দেয় না — কেবল নির্বাচিত বিশেষ হৃদয়ধারী প্রাণী পরাজিত করে ৪ স্তরের (১, ৫, ১৫, ৫০) এনিমেল হার্ট সংগ্রহ করুন এবং লবিতে খেলোয়াড় বা সঙ্গী লেভেল-আপ করুন।
                    </li>
                  </ol>

                  <button
                    type="button"
                    onClick={() => {
                      onSelectGameMode('pet_taming');
                      setActivePanel(null);
                    }}
                    className={`font-bengali-ui w-full rounded-lg border px-3 py-2 text-xs font-extrabold transition-colors active:scale-95 ${
                      gameMode === 'pet_taming'
                        ? 'border-[#7fffcb] bg-[#144734] text-[#d6fff0]'
                        : 'border-[#5ef2bc]/75 bg-[#12382a] text-[#a8ffe0] hover:bg-[#194f3b]'
                    }`}
                  >
                    {gameMode === 'pet_taming'
                      ? 'প্রাণী বশ মোড নির্বাচিত আছে'
                      : 'প্রাণী বশ মোড নির্বাচন করুন'}
                  </button>
                </div>
              )}
            </div>
          )}

          {activePanel === 'map' && (
            <div className="pointer-events-auto fixed left-[max(0.75rem,env(safe-area-inset-left))] top-1/2 z-40 max-h-[calc(100dvh-6rem-env(safe-area-inset-top)-env(safe-area-inset-bottom))] w-[min(240px,calc(100vw-1.5rem-env(safe-area-inset-left)-env(safe-area-inset-right)))] -translate-y-1/2 overflow-y-auto rounded-lg border border-[#b59c6b]/45 bg-[#141512]/96 p-4 shadow-[0_16px_38px_rgba(0,0,0,0.78)] md:static md:translate-y-0">
              <div className="mb-2 flex items-center justify-between">
                <span className="font-bengali-ui text-sm font-bold text-[#ffd978]">
                  ম্যাপ: বাংলা
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="text-xs font-bold text-[#ccb38e] hover:text-white"
                >
                  ✕
                </button>
              </div>
              <div className="font-bengali-display text-sm font-bold text-[#fff1d0]">
                হুগলি তীর · পশ্চিমবঙ্গ
              </div>
              <p className="font-bengali-ui mt-1 text-[11px] leading-relaxed text-[#d7be98]">
                হাওড়া ব্রিজের পটভূমিতে বাংলার মাটির গ্রাম, যোদ্ধা সিন্দুক, সঞ্জীবনী গাছ ও কালবৈশাখী বলয়ের মাঝে সার্ভাইভাল যুদ্ধ।
              </p>
              <div className="font-bengali-ui mt-2 text-[10px] font-semibold text-[#ffe08f]">
                হাওড়া সেতু · যোদ্ধা সিন্দুক · সঞ্জীবনী গাছ · কালবৈশাখী বলয়
              </div>
            </div>
          )}

          {/* ভল্ট / পোশাক (Vault / Dress — Live 3D Outfit & Gamcha Changing) */}
          {activePanel === 'vault' && (
            <div className="pointer-events-auto fixed left-[max(0.65rem,env(safe-area-inset-left))] top-[calc(4.15rem+env(safe-area-inset-top))] bottom-[calc(3.65rem+env(safe-area-inset-bottom))] z-40 w-[min(284px,calc(49vw-0.75rem))] overflow-y-auto rounded-lg border border-[#b59c6b]/45 bg-[#141512]/96 p-3.5 shadow-[0_16px_40px_rgba(0,0,0,0.8)] sm:p-4 lg:static lg:top-auto lg:bottom-auto lg:max-h-[calc(100dvh-11rem)] lg:w-[300px]">
              <div className="mb-1.5 flex items-center justify-between gap-2">
                <span className="font-bengali-ui text-sm font-bold text-[#ffd978]">
                  ভল্ট · পোশাক নির্বাচন
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="flex h-7 w-7 items-center justify-center rounded-md text-xs font-bold text-[#ccb38e] hover:bg-white/10 hover:text-white"
                >
                  ✕
                </button>
              </div>
              <p className="font-bengali-ui mb-2.5 text-[10px] leading-snug text-[#d4bc97]">
                পোশাক বাছুন — কেন্দ্রে ৩ডি চরিত্রে তাৎক্ষণিক পরিবর্তন দেখুন
              </p>

              <div className="grid grid-cols-2 gap-1.5">
                {HERO_OUTFIT_ORDER.map((id) => {
                  const outfit = HERO_OUTFIT_CATALOG[id];
                  const equipped = heroOutfit === id;
                  return (
                    <button
                      key={id}
                      type="button"
                      onClick={() => onSelectOutfit(id)}
                      className={`flex flex-col rounded-lg border p-2 text-left transition-colors active:scale-[0.98] ${
                        equipped
                          ? 'border-[#ffd24c] bg-[#332011] text-[#fff6e3]'
                          : 'border-[#e8bc6a]/25 bg-[#22160f] text-[#e0cca9] hover:border-[#e8bc6a]/55 hover:bg-[#2b1c13]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1.5">
                        <span className="flex h-6 w-9 shrink-0 overflow-hidden rounded border border-white/25">
                          <span
                            style={{ backgroundColor: outfit.swatchTop }}
                            className="h-full w-1/2"
                          />
                          <span
                            style={{ backgroundColor: outfit.swatchBottom }}
                            className="h-full w-1/3"
                          />
                          <span
                            style={{ backgroundColor: outfit.swatchAccent }}
                            className="h-full w-1/6"
                          />
                        </span>
                        {equipped && (
                          <span className="font-bengali-ui text-[9px] font-bold text-[#ffd86b]">
                            পরা আছে
                          </span>
                        )}
                      </div>
                      <div className="font-bengali-ui mt-1.5 truncate text-[11px] font-bold leading-tight">
                        {outfit.nameBn}
                      </div>
                      <div className="font-bengali-ui truncate text-[9px] text-[#c7ae87]">
                        {outfit.subtitleBn}
                      </div>
                    </button>
                  );
                })}
              </div>

              <div className="mt-3 border-t border-[#f0c268]/20 pt-2.5">
                <div className="font-bengali-ui mb-1.5 text-[11px] font-bold text-[#f2d69f]">
                  গামছার রঙ
                </div>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => onSelectGamcha('red-white')}
                    className={`flex items-center gap-2 rounded-lg border px-2.5 py-1.5 text-left transition-colors ${
                      gamchaStyle === 'red-white'
                        ? 'border-[#ffd24c] bg-[#361813] text-[#fff6e3]'
                        : 'border-[#e8bc6a]/25 bg-[#22160f] text-[#dfcaa8] hover:bg-[#2c1c13]'
                    }`}
                  >
                    <span className="flex h-5 w-5 shrink-0 overflow-hidden rounded border border-[#fff2d9]/60">
                      <span className="h-full w-1/2 bg-[#c81f26]" />
                      <span className="h-full w-1/2 bg-[#faf3e6]" />
                    </span>
                    <span className="font-bengali-ui truncate text-[10px] font-bold">
                      লাল-সাদা
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onSelectGamcha('green-white')}
                    className={`flex items-center gap-2 rounded-lg border px-2.5 py-1.5 text-left transition-colors ${
                      gamchaStyle === 'green-white'
                        ? 'border-[#ffd24c] bg-[#16301d] text-[#fff6e3]'
                        : 'border-[#e8bc6a]/25 bg-[#22160f] text-[#dfcaa8] hover:bg-[#2c1c13]'
                    }`}
                  >
                    <span className="flex h-5 w-5 shrink-0 overflow-hidden rounded border border-[#fff2d9]/60">
                      <span className="h-full w-1/2 bg-[#1c7c3e]" />
                      <span className="h-full w-1/2 bg-[#faf3e6]" />
                    </span>
                    <span className="font-bengali-ui truncate text-[10px] font-bold">
                      সবুজ-সাদা
                    </span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* প্রিসেট (Preset — 3 Saved Loadouts with 1-Tap Apply & Save Current) */}
          {activePanel === 'preset' && (
            <div className="pointer-events-auto fixed left-[max(0.65rem,env(safe-area-inset-left))] top-[calc(4.15rem+env(safe-area-inset-top))] bottom-[calc(3.65rem+env(safe-area-inset-bottom))] z-40 w-[min(284px,calc(49vw-0.75rem))] overflow-y-auto rounded-lg border border-[#b59c6b]/45 bg-[#141512]/96 p-3.5 shadow-[0_16px_40px_rgba(0,0,0,0.8)] sm:p-4 lg:static lg:top-auto lg:bottom-auto lg:max-h-[calc(100dvh-11rem)] lg:w-[300px]">
              <div className="mb-1.5 flex items-center justify-between gap-2">
                <span className="font-bengali-ui text-sm font-bold text-[#ffd978]">
                  প্রিসেট · সংরক্ষিত লোডআউট
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="flex h-7 w-7 items-center justify-center rounded-md text-xs font-bold text-[#ccb38e] hover:bg-white/10 hover:text-white"
                >
                  ✕
                </button>
              </div>
              <p className="font-bengali-ui mb-2.5 text-[10px] leading-snug text-[#d4bc97]">
                বর্তমান: {HERO_OUTFIT_CATALOG[heroOutfit].nameBn} · {WEAPON_CATALOG[weaponType].shortName} ·{' '}
                {gameMode === 'pet_taming' ? 'প্রাণী বশ' : 'সার্ভাইভাল'}
              </p>

              <div className="flex flex-col gap-2">
                {presets.map((preset) => {
                  const outfitMeta = HERO_OUTFIT_CATALOG[preset.outfit];
                  const weaponMeta = WEAPON_CATALOG[preset.weaponType];
                  const isActiveMatch =
                    preset.outfit === heroOutfit &&
                    preset.gamchaStyle === gamchaStyle &&
                    preset.weaponType === weaponType &&
                    preset.gameMode === gameMode;
                  const justSaved = savedPresetSlot === preset.slot;

                  return (
                    <div
                      key={preset.id}
                      className={`rounded-lg border p-2.5 transition-colors ${
                        isActiveMatch
                          ? 'border-[#ffd24c] bg-[#302012]'
                          : 'border-[#e8bc6a]/25 bg-[#22160f]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex min-w-0 items-center gap-2">
                          <span className="flex h-6 w-6 shrink-0 overflow-hidden rounded border border-white/25">
                            <span
                              style={{ backgroundColor: outfitMeta.swatchTop }}
                              className="h-full w-1/2"
                            />
                            <span
                              style={{ backgroundColor: outfitMeta.swatchBottom }}
                              className="h-full w-1/2"
                            />
                          </span>
                          <div className="min-w-0">
                            <div className="font-bengali-ui truncate text-xs font-bold text-[#fff3da]">
                              {toBengaliNumber(preset.slot)}. {preset.nameBn}
                            </div>
                            <div className="font-bengali-ui truncate text-[9.5px] text-[#cbb38e]">
                              {outfitMeta.nameBn} · {weaponMeta.shortName} ·{' '}
                              {preset.gameMode === 'pet_taming' ? 'প্রাণী বশ' : 'সার্ভাইভাল'}
                            </div>
                          </div>
                        </div>
                        {isActiveMatch && (
                          <span className="font-bengali-ui shrink-0 text-[9.5px] font-bold text-[#ffd86b]">
                            চালু
                          </span>
                        )}
                      </div>

                      <div className="mt-2 flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => onApplyPreset(preset)}
                          className="font-bengali-ui flex-1 whitespace-nowrap rounded-md border border-[#ffd873]/70 bg-gradient-to-b from-[#e09d18] to-[#b86d0a] px-2.5 py-1.5 text-[10.5px] font-extrabold text-[#1f1004] transition-all hover:brightness-110 active:scale-95"
                        >
                          প্রয়োগ করুন
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            onSavePreset(preset.slot);
                            setSavedPresetSlot(preset.slot);
                            window.setTimeout(() => {
                              setSavedPresetSlot((cur) => (cur === preset.slot ? null : cur));
                            }, 1400);
                          }}
                          className="font-bengali-ui whitespace-nowrap rounded-md border border-[#e8bc6a]/40 bg-[#18100b] px-2.5 py-1.5 text-[10.5px] font-bold text-[#f0d8b0] transition-colors hover:border-[#ffd262] hover:bg-[#2a1c12] active:scale-95"
                        >
                          {justSaved ? 'সেভ হয়েছে' : 'সেভ করুন'}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ল্যাব (Lab — Upgrades Hub & Game Systems Reference) */}
          {activePanel === 'lab' && (
            <div className="pointer-events-auto fixed left-[max(0.65rem,env(safe-area-inset-left))] top-[calc(4.15rem+env(safe-area-inset-top))] bottom-[calc(3.65rem+env(safe-area-inset-bottom))] z-40 w-[min(292px,calc(50vw-0.75rem))] overflow-y-auto rounded-lg border border-[#b59c6b]/45 bg-[#141512]/96 p-3.5 shadow-[0_16px_40px_rgba(0,0,0,0.8)] sm:p-4 lg:static lg:top-auto lg:bottom-auto lg:max-h-[calc(100dvh-11rem)] lg:w-[308px]">
              <div className="mb-2 flex items-center justify-between gap-2">
                <span className="font-bengali-ui text-sm font-bold text-[#ffd978]">
                  ল্যাব · আপগ্রেড ও সিস্টেম
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="flex h-7 w-7 items-center justify-center rounded-md text-xs font-bold text-[#ccb38e] hover:bg-white/10 hover:text-white"
                >
                  ✕
                </button>
              </div>

              {/* Live Upgrade Overview */}
              <div className="space-y-2 border-b border-[#f0c268]/20 pb-3">
                <div className="flex items-baseline justify-between gap-2 text-xs">
                  <span className="font-bengali-ui font-bold text-[#ffe6a3]">খেলোয়াড় (ভানু)</span>
                  <span className="font-bengali-ui tabular-nums text-[11px] font-semibold text-[#e8cfa5]">
                    LV {toBengaliNumber(playerLevel)}/{toBengaliNumber(playerMaxLevel)} · স্বাস্থ্য{' '}
                    {toBengaliNumber(playerMaxHealth)} · ক্ষতি +{toBengaliNumber(weaponDamageBonusPct)}%
                  </span>
                </div>

                <div className="flex items-baseline justify-between gap-2 text-xs">
                  <span className="font-bengali-ui font-bold text-[#8cffd4]">পোষা সঙ্গী</span>
                  <span className="font-bengali-ui tabular-nums text-[11px] font-semibold text-[#c9eee0]">
                    {permanentPet
                      ? `${permanentPet.nameBn} · স্তর ${toBengaliNumber(petCurLv)}/${toBengaliNumber(PET_MAX_LEVEL)}`
                      : 'বশ করা বাকি'}
                  </span>
                </div>

                <div className="flex items-baseline justify-between gap-2 text-xs">
                  <span className="font-bengali-ui font-bold text-[#ff9bb4]">এনিমেল হার্ট মান</span>
                  <span className="font-bengali-ui tabular-nums text-[11px] font-extrabold text-[#ffe28a]">
                    {toBengaliNumber(animalHearts.totalValue)} ({toBengaliNumber(animalHearts.totalCount)}টি)
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => setActivePanel('animal_heart')}
                  className="font-bengali-ui mt-1 flex w-full items-center justify-center gap-1.5 rounded-lg border border-[#ff9bb2]/80 bg-gradient-to-r from-[#9e1d44] to-[#c43a2b] px-3 py-2 text-xs font-extrabold text-white shadow-[0_4px_14px_rgba(225,65,95,0.35)] transition-all hover:brightness-110 active:scale-95"
                >
                  <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 shrink-0 fill-[#ffd2dc]">
                    <path d="M10 17.2l-1.2-1.1C4.4 12.2 1.8 9.8 1.8 6.8 1.8 4.4 3.6 2.6 6 2.6c1.4 0 2.7.7 3.5 1.8h1c.8-1.1 2.1-1.8 3.5-1.8 2.4 0 4.2 1.8 4.2 4.2 0 3-2.6 5.4-7 9.3L10 17.2z" />
                  </svg>
                  <span>এনিমেল হার্ট লেভেল আপ খুলুন</span>
                </button>
              </div>

              {/* Active Game Systems & Controls Reference */}
              <div className="mt-2.5 space-y-1.5 text-[10.5px] leading-relaxed text-[#dfc7a1]">
                <div className="font-bengali-ui font-bold text-[#ffd978]">সিস্টেম তথ্য</div>
                <p className="font-bengali-ui">
                  <span className="font-bold text-[#ffe6a8]">৪ টিয়ার হার্ট:</span> সাধারণ ১ · দুর্লভ ৫ · মহাকাব্যিক ১৫ · কিংবদন্তি ৫০ (কেবল নির্বাচিত বিশেষ প্রাণীতে ড্রপ)
                </p>
                <p className="font-bengali-ui">
                  <span className="font-bold text-[#ffe6a8]">লেভেল আপ নিয়ম:</span> ম্যাচে অটো লেভেল আপ নেই — লবিতে ১০ → ৩০ → ৫০ ক্রমে ১০০০ স্তর পর্যন্ত উন্নয়ন
                </p>
                <p className="font-bengali-ui">
                  <span className="font-bold text-[#ffe6a8]">বন্যপ্রাণী ও যানবাহন:</span> দূর থেকে তাড়া করে না, আঘাত করলে লড়ে · সাইকেল ও বাইকে দ্রুত ভ্রমণ · সর্বোচ্চ ৪০ শত্রু
                </p>
                <p className="font-bengali-ui border-t border-[#f0c268]/15 pt-1.5 text-[10px] text-[#cbb089]">
                  কন্ট্রোল: ১–৪ অস্ত্র · F সিন্দুক/বাস/বাইক · H সঞ্জীবনী · G বজ্র গোলা · T বশ · রাইট-ক্লিক স্কোপ
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* DEDICATED ANIMAL HEART LEVEL-UP MODAL (Player Level Up + Animal Level Up) */}
      {activePanel === 'animal_heart' && (() => {
        const nextPlayerMaxHp = isPlayerMaxLv
          ? playerMaxHealth
          : computePlayerMaxHealth(playerLevel + 1);
        const nextPlayerDmgBonusPct = isPlayerMaxLv
          ? weaponDamageBonusPct
          : Math.round((computePlayerWeaponDamageMult(playerLevel + 1) - 1) * 100);
        const nextPetStats =
          permanentPet && !isPetMaxLv
            ? computePetStats(permanentPet.species, petCurLv + 1)
            : null;

        return (
          <div
            onClick={() => setActivePanel(null)}
            className="pointer-events-auto fixed inset-0 z-50 flex items-center justify-center bg-[#0a0b09]/84 p-3 sm:p-5"
          >
            <div
              onClick={(e) => e.stopPropagation()}
              className="max-h-[calc(100dvh-2rem-env(safe-area-inset-top)-env(safe-area-inset-bottom))] w-full max-w-[580px] overflow-y-auto rounded-xl border border-[#b59c6b]/55 bg-[#141512] p-4 shadow-[0_22px_54px_rgba(0,0,0,0.88)] sm:p-5"
            >
              {/* Modal Header */}
              <div className="flex items-center justify-between gap-3 border-b border-[#b59c6b]/22 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-[#a84a5a]/60 bg-[#2a1318]">
                    <svg viewBox="0 0 20 20" className="h-5 w-5 fill-[#c93e54]">
                      <path d="M10 17.4l-1.3-1.2C4.2 12.1 1.6 9.7 1.6 6.6 1.6 4.1 3.5 2.3 6 2.3c1.4 0 2.7.7 3.5 1.8h1c.8-1.1 2.1-1.8 3.5-1.8 2.5 0 4.4 1.8 4.4 4.3 0 3.1-2.6 5.5-7.1 9.6L10 17.4z" />
                    </svg>
                  </div>
                  <div>
                    <h2 className="font-bengali-display text-base font-extrabold text-[#ffe4ec] sm:text-lg">
                      এনিমেল হার্ট · লেভেল আপ
                    </h2>
                    <p className="font-bengali-ui text-[10px] font-medium text-[#e8b8c6] sm:text-[11px]">
                      সংগৃহীত এনিমেল হার্ট খরচ করে খেলোয়াড় বা পোষা প্রাণী লেভেল আপ করুন
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1 rounded-lg border border-[#ffd262]/55 bg-[#2a151d] px-2.5 py-1">
                    <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 shrink-0 fill-[#ff587a]">
                      <path d="M10 17.2l-1.2-1.1C4.4 12.2 1.8 9.8 1.8 6.8 1.8 4.4 3.6 2.6 6 2.6c1.4 0 2.7.7 3.5 1.8h1c.8-1.1 2.1-1.8 3.5-1.8 2.4 0 4.2 1.8 4.2 4.2 0 3-2.6 5.4-7 9.3L10 17.2z" />
                    </svg>
                    <span className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#ffe28a] sm:text-sm">
                      {toBengaliNumber(animalHearts.totalValue)}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActivePanel(null)}
                    aria-label="বন্ধ করুন"
                    className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/15 bg-white/5 text-xs font-bold text-[#e5c2cc] hover:bg-white/15 hover:text-white"
                  >
                    ✕
                  </button>
                </div>
              </div>

              {/* 4-Tier Animal Heart Inventory Breakdown (Common=1, Rare=5, Epic=15, Legendary=50) */}
              <div className="mt-2.5 rounded-xl border border-rose-400/25 bg-black/30 p-2.5">
                <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-4">
                  {ANIMAL_HEART_TIER_ORDER.map((tier) => {
                    const count = animalHearts.tiers[tier] || 0;
                    const tMeta = ANIMAL_HEART_TIERS[tier];
                    const subtotal = count * tMeta.value;
                    const cardStyle: Record<number, { box: string; title: string; dot: string }> = {
                      1: {
                        box: count > 0 ? 'border-rose-400/50 bg-rose-500/15' : 'border-white/10 bg-black/25',
                        title: 'text-[#ffb8c8]',
                        dot: '#ef5368',
                      },
                      2: {
                        box: count > 0 ? 'border-sky-400/55 bg-sky-500/15' : 'border-white/10 bg-black/25',
                        title: 'text-[#9ce3ff]',
                        dot: '#3bb2ff',
                      },
                      3: {
                        box: count > 0 ? 'border-purple-400/55 bg-purple-500/15' : 'border-white/10 bg-black/25',
                        title: 'text-[#e5b3ff]',
                        dot: '#c84dff',
                      },
                      4: {
                        box: count > 0 ? 'border-amber-400/65 bg-amber-500/20' : 'border-white/10 bg-black/25',
                        title: 'text-[#ffe184]',
                        dot: '#ffb829',
                      },
                    };
                    const st = cardStyle[tier];
                    return (
                      <div
                        key={tier}
                        className={`rounded-lg border px-2 py-1.5 ${st.box}`}
                      >
                        <div className="flex items-center justify-between gap-1">
                          <div className="flex min-w-0 items-center gap-1">
                            <svg
                              viewBox="0 0 20 20"
                              style={{ fill: st.dot }}
                              className="h-3 w-3 shrink-0"
                            >
                              <path d="M10 17.2l-1.2-1.1C4.4 12.2 1.8 9.8 1.8 6.8 1.8 4.4 3.6 2.6 6 2.6c1.4 0 2.7.7 3.5 1.8h1c.8-1.1 2.1-1.8 3.5-1.8 2.4 0 4.2 1.8 4.2 4.2 0 3-2.6 5.4-7 9.3L10 17.2z" />
                            </svg>
                            <span className={`font-bengali-ui truncate text-[10px] font-extrabold ${st.title}`}>
                              {tMeta.shortNameBn}
                            </span>
                          </div>
                          <span className="font-bengali-ui tabular-nums text-[9px] font-bold text-white/75">
                            +{toBengaliNumber(tMeta.value)}
                          </span>
                        </div>
                        <div className="mt-1 flex items-baseline justify-between gap-1">
                          <span className="font-bengali-ui tabular-nums text-xs font-extrabold text-white">
                            ×{toBengaliNumber(count)}
                          </span>
                          <span className="font-bengali-ui tabular-nums text-[9px] font-semibold text-[#ffe28a]">
                            মান: {toBengaliNumber(subtotal)}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
                <div className="mt-1.5 flex flex-wrap items-center justify-between gap-1 text-[9px] font-semibold text-[#e6b8c4]/85">
                  <span className="font-bengali-ui">
                    সব টিয়ারের সঞ্চিত মান একত্রে লেভেল আপে খরচ হয় (১০ → ৩০ → ৫০ ...)
                  </span>
                  <span className="font-bengali-ui tabular-nums text-[#ffe28a]">
                    মোট হার্ট: {toBengaliNumber(animalHearts.totalCount)}টি · মোট মান: {toBengaliNumber(animalHearts.totalValue)}
                  </span>
                </div>
              </div>

              {/* TWO LEVEL-UP OPTIONS: Player Level Up + Animal Level Up */}
              <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
                {/* OPTION 1: PLAYER LEVEL UP */}
                <div className="flex flex-col justify-between rounded-xl border border-[#f5c763]/55 bg-gradient-to-b from-[#2b1c0e]/95 to-[#1b120a]/95 p-3.5 shadow-[0_6px_20px_rgba(0,0,0,0.45)]">
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-[#ffd873]/60 bg-[#402612]">
                          <svg viewBox="0 0 24 24" className="h-4.5 w-4.5 fill-none stroke-[#ffd45c] stroke-2">
                            <circle cx="12" cy="7.5" r="3.5" />
                            <path d="M5 20c0-3.8 3.1-6.5 7-6.5s7 2.7 7 6.5" strokeLinecap="round" />
                          </svg>
                        </div>
                        <div>
                          <div className="font-bengali-display text-sm font-extrabold text-[#ffe494]">
                            খেলোয়াড় লেভেল আপ
                          </div>
                          <div className="font-bengali-ui text-[10px] font-bold text-[#f2d09b]">
                            ভানু · LV {toBengaliNumber(playerLevel)}/{toBengaliNumber(playerMaxLevel)}
                          </div>
                        </div>
                      </div>
                      <span
                        className={`font-bengali-ui shrink-0 rounded px-1.5 py-0.5 text-[9px] font-bold ${
                          isPlayerMaxLv
                            ? 'bg-emerald-500/25 text-[#88ffd4]'
                            : canUpgradePlayer
                              ? 'bg-amber-400/25 text-[#ffe68a]'
                              : 'bg-black/40 text-[#d4b68c]'
                        }`}
                      >
                        {isPlayerMaxLv ? 'সর্বোচ্চ' : `${toBengaliNumber(nextPlayerCost)} হার্ট`}
                      </span>
                    </div>

                    <div className="mt-3 grid grid-cols-2 gap-1.5">
                      <div className="rounded-lg border border-amber-300/20 bg-black/35 px-2.5 py-1.5">
                        <div className="font-bengali-ui text-[9px] text-[#d9bc92]">সর্বোচ্চ স্বাস্থ্য</div>
                        <div className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#fff4de]">
                          {toBengaliNumber(playerMaxHealth)}
                          {!isPlayerMaxLv && (
                            <span className="ml-1 text-[10px] font-bold text-[#88ffd4]">
                              +{toBengaliNumber(nextPlayerMaxHp - playerMaxHealth)}
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="rounded-lg border border-amber-300/20 bg-black/35 px-2.5 py-1.5">
                        <div className="font-bengali-ui text-[9px] text-[#d9bc92]">অস্ত্রের ক্ষতি</div>
                        <div className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#ffc57a]">
                          +{toBengaliNumber(weaponDamageBonusPct)}%
                          {!isPlayerMaxLv && (
                            <span className="ml-1 text-[10px] font-bold text-[#ffe27a]">
                              → +{toBengaliNumber(nextPlayerDmgBonusPct)}%
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-3">
                    {!isPlayerMaxLv ? (
                      <button
                        type="button"
                        disabled={!canUpgradePlayer}
                        onClick={onUpgradePlayer}
                        className={`font-bengali-ui w-full rounded-md border px-3 py-2 text-xs font-extrabold transition-all ${
                          canUpgradePlayer
                            ? 'border-[#dec07c]/80 bg-gradient-to-b from-[#b88628] to-[#7c5313] text-[#140e06] shadow-[0_4px_12px_rgba(0,0,0,0.48)] hover:brightness-110 active:scale-95'
                            : 'cursor-not-allowed border-white/15 bg-white/5 text-white/45'
                        }`}
                      >
                        {canUpgradePlayer
                          ? `খেলোয়াড় লেভেল আপ → LV ${toBengaliNumber(playerLevel + 1)} (${toBengaliNumber(nextPlayerCost)} হার্ট)`
                          : `আরও ${toBengaliNumber(Math.max(0, nextPlayerCost - animalHearts.totalValue))} এনিমেল হার্ট প্রয়োজন`}
                      </button>
                    ) : (
                      <div className="font-bengali-ui rounded-lg border border-emerald-400/35 bg-emerald-950/45 px-2.5 py-2 text-center text-[11px] font-bold text-[#9effd6]">
                        খেলোয়াড় সর্বোচ্চ লেভেলে পৌঁছেছে!
                      </div>
                    )}
                  </div>
                </div>

                {/* OPTION 2: ANIMAL (PET) LEVEL UP */}
                <div className="flex flex-col justify-between rounded-xl border border-[#5ef2bc]/55 bg-gradient-to-b from-[#102920]/95 to-[#0b1b15]/95 p-3.5 shadow-[0_6px_20px_rgba(0,0,0,0.45)]">
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-[#5ef2bc]/60 bg-[#12382a]">
                          <svg viewBox="0 0 24 24" className="h-4.5 w-4.5 fill-[#5ef2bc]">
                            <circle cx="7.5" cy="8.5" r="2" />
                            <circle cx="12" cy="6.8" r="2" />
                            <circle cx="16.5" cy="8.5" r="2" />
                            <path d="M12 11.4c-3.1 0-5.4 2.1-5.4 4.8 0 1.6 1.4 2.7 3 2.7 1.1 0 1.8-.4 2.4-.4s1.3.4 2.4.4c1.6 0 3-1.1 3-2.7 0-2.7-2.3-4.8-5.4-4.8z" />
                          </svg>
                        </div>
                        <div>
                          <div className="font-bengali-display text-sm font-extrabold text-[#98ffd9]">
                            প্রাণী লেভেল আপ
                          </div>
                          <div className="font-bengali-ui text-[10px] font-bold text-[#b8ebda]">
                            {permanentPet
                              ? `${permanentPet.nameBn} · স্তর ${toBengaliNumber(petCurLv)}/${toBengaliNumber(PET_MAX_LEVEL)}`
                              : 'কোনো স্থায়ী পোষা সঙ্গী নেই'}
                          </div>
                        </div>
                      </div>
                      {permanentPet && (
                        <span
                          className={`font-bengali-ui shrink-0 rounded px-1.5 py-0.5 text-[9px] font-bold ${
                            isPetMaxLv
                              ? 'bg-emerald-500/25 text-[#88ffd4]'
                              : canUpgradePet
                                ? 'bg-rose-500/30 text-[#ffd6e0]'
                                : 'bg-black/40 text-[#a5d6c5]'
                          }`}
                        >
                          {isPetMaxLv ? 'সর্বোচ্চ' : `${toBengaliNumber(nextPetCost)} হার্ট`}
                        </span>
                      )}
                    </div>

                    {permanentPet ? (
                      <div className="mt-3 grid grid-cols-2 gap-1.5">
                        <div className="rounded-lg border border-emerald-300/20 bg-black/35 px-2 py-1">
                          <div className="font-bengali-ui text-[9px] text-[#9fd8c4]">স্বাস্থ্য</div>
                          <div className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#e8fff6]">
                            {toBengaliNumber(permanentPet.stats.maxHp)}
                            {nextPetStats && (
                              <span className="ml-1 text-[9px] font-bold text-[#7fffcb]">
                                +{toBengaliNumber(nextPetStats.maxHp - permanentPet.stats.maxHp)}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="rounded-lg border border-emerald-300/20 bg-black/35 px-2 py-1">
                          <div className="font-bengali-ui text-[9px] text-[#f3cfa0]">আক্রমণ ক্ষতি</div>
                          <div className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#ffe7b3]">
                            {toBengaliNumber(permanentPet.stats.attackDamage)}
                            {nextPetStats && (
                              <span className="ml-1 text-[9px] font-bold text-[#ffd26a]">
                                +{toBengaliNumber(nextPetStats.attackDamage - permanentPet.stats.attackDamage)}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="rounded-lg border border-emerald-300/20 bg-black/35 px-2 py-1">
                          <div className="font-bengali-ui text-[9px] text-[#a7d8f0]">গতি</div>
                          <div className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#dff4ff]">
                            {toBengaliNumber(permanentPet.stats.moveSpeed)}
                            {nextPetStats && (
                              <span className="ml-1 text-[9px] font-bold text-[#7fd8ff]">
                                +{toBengaliNumber(Number((nextPetStats.moveSpeed - permanentPet.stats.moveSpeed).toFixed(1)))}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="rounded-lg border border-emerald-300/20 bg-black/35 px-2 py-1">
                          <div className="font-bengali-ui text-[9px] text-[#d6b8f5]">কুলডাউন</div>
                          <div className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#f2e3ff]">
                            {toBengaliNumber(permanentPet.stats.assistCooldown)} সে.
                            {nextPetStats && nextPetStats.assistCooldown < permanentPet.stats.assistCooldown && (
                              <span className="ml-1 text-[9px] font-bold text-[#c79eff]">
                                -{toBengaliNumber(Number((permanentPet.stats.assistCooldown - nextPetStats.assistCooldown).toFixed(1)))}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="mt-3 rounded-lg border border-emerald-300/20 bg-black/30 p-2.5 text-[11px] leading-relaxed text-[#c6ece0]">
                        <span className="font-bengali-ui">
                          প্রাণী লেভেল আপ করতে আগে <span className="font-bold text-[#88ffd4]">প্রাণী বশ মোডে</span> গিয়ে ১টি স্থায়ী পোষা প্রাণী বশ করুন।
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="mt-3">
                    {permanentPet ? (
                      !isPetMaxLv ? (
                        <button
                          type="button"
                          disabled={!canUpgradePet}
                          onClick={onUpgradePet}
                          className={`font-bengali-ui w-full rounded-md border px-3 py-2 text-xs font-extrabold transition-all ${
                            canUpgradePet
                              ? 'border-[#d67a88]/80 bg-gradient-to-b from-[#96293d] to-[#631724] text-[#f7e9ec] shadow-[0_4px_12px_rgba(0,0,0,0.48)] hover:brightness-110 active:scale-95'
                              : 'cursor-not-allowed border-white/15 bg-white/5 text-white/45'
                          }`}
                        >
                          {canUpgradePet
                            ? `প্রাণী লেভেল আপ → স্তর ${toBengaliNumber(petCurLv + 1)} (${toBengaliNumber(nextPetCost)} হার্ট)`
                            : `আরও ${toBengaliNumber(Math.max(0, nextPetCost - animalHearts.totalValue))} এনিমেল হার্ট প্রয়োজন`}
                        </button>
                      ) : (
                        <div className="font-bengali-ui rounded-lg border border-emerald-400/35 bg-emerald-950/45 px-2.5 py-2 text-center text-[11px] font-bold text-[#9effd6]">
                          আপনার পোষা প্রাণী সর্বোচ্চ স্তরে পৌঁছেছে!
                        </div>
                      )
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          onSelectGameMode('pet_taming');
                          setActivePanel(null);
                        }}
                        className="font-bengali-ui w-full rounded-lg border border-[#5ef2bc]/75 bg-[#12382a] px-3 py-2 text-xs font-extrabold text-[#a8ffe0] transition-colors hover:bg-[#194f3b] active:scale-95"
                      >
                        প্রাণী বশ মোড নির্বাচন করুন
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* BOTTOM NAVIGATION BAR STRIP (Lower-Left Dock: Vault/Dress, Weapon, Preset, Lab) */}
      <nav
        aria-label="লবি নিচের মেনু"
        className="pointer-events-auto fixed bottom-[max(0.5rem,env(safe-area-inset-bottom))] left-[max(0.65rem,env(safe-area-inset-left))] z-20 flex items-stretch divide-x divide-[#b59c6b]/20 overflow-hidden rounded-lg border border-[#b59c6b]/45 bg-[#121311]/94 shadow-[0_8px_22px_rgba(0,0,0,0.68)] sm:bottom-[max(0.85rem,env(safe-area-inset-bottom))] sm:left-[max(1.25rem,env(safe-area-inset-left))]"
      >
        {/* 1. ভল্ট / পোশাক (Vault / Dress) */}
        <button
          type="button"
          onClick={() => togglePanel('vault')}
          aria-pressed={activePanel === 'vault'}
          className={`relative flex min-h-[40px] min-w-[66px] flex-col items-center justify-center gap-0.5 px-2.5 py-1.5 transition-colors active:scale-95 sm:min-h-[46px] sm:min-w-[84px] sm:flex-row sm:gap-2 sm:px-3.5 ${
            activePanel === 'vault'
              ? 'bg-[#24211a] text-[#ecd296]'
              : 'text-[#d4cbb8] hover:bg-white/5 hover:text-[#f2eadb]'
          }`}
        >
          <svg
            viewBox="0 0 24 24"
            className={`h-4 w-4 shrink-0 fill-none stroke-2 ${
              activePanel === 'vault' ? 'stroke-[#dfb963]' : 'stroke-[#b59c6b]'
            }`}
          >
            <path
              d="M8.5 4.5L5 7.5 7 11l2-1v9.5h6V10l2 1 2-3.5-3.5-3a3.5 3.5 0 0 1-7 0z"
              strokeLinejoin="round"
            />
          </svg>
          <span className="font-bengali-ui whitespace-nowrap text-[10px] font-bold leading-none sm:text-xs">
            ভল্ট
          </span>
          {activePanel === 'vault' && (
            <span aria-hidden="true" className="absolute inset-x-2 bottom-0 h-[2px] rounded-t bg-[#d9b566]" />
          )}
        </button>

        {/* 2. অস্ত্র (Weapon) */}
        <button
          type="button"
          onClick={() => togglePanel('weapon')}
          aria-pressed={activePanel === 'weapon'}
          className={`relative flex min-h-[40px] min-w-[66px] flex-col items-center justify-center gap-0.5 px-2.5 py-1.5 transition-colors active:scale-95 sm:min-h-[46px] sm:min-w-[84px] sm:flex-row sm:gap-2 sm:px-3.5 ${
            activePanel === 'weapon'
              ? 'bg-[#24211a] text-[#ecd296]'
              : 'text-[#d4cbb8] hover:bg-white/5 hover:text-[#f2eadb]'
          }`}
        >
          <svg
            viewBox="0 0 24 24"
            className={`h-4 w-4 shrink-0 fill-none stroke-2 ${
              activePanel === 'weapon' ? 'stroke-[#dfb963]' : 'stroke-[#b59c6b]'
            }`}
          >
            <path d="M3 11h14l4-2v4l-4-1H13l-2 5H8l1-5H5l-2 2v-3z" strokeLinejoin="round" />
          </svg>
          <span className="font-bengali-ui whitespace-nowrap text-[10px] font-bold leading-none sm:text-xs">
            অস্ত্র
          </span>
          {activePanel === 'weapon' && (
            <span aria-hidden="true" className="absolute inset-x-2 bottom-0 h-[2px] rounded-t bg-[#d9b566]" />
          )}
        </button>

        {/* 3. প্রিসেট (Preset) */}
        <button
          type="button"
          onClick={() => togglePanel('preset')}
          aria-pressed={activePanel === 'preset'}
          className={`relative flex min-h-[40px] min-w-[66px] flex-col items-center justify-center gap-0.5 px-2.5 py-1.5 transition-colors active:scale-95 sm:min-h-[46px] sm:min-w-[84px] sm:flex-row sm:gap-2 sm:px-3.5 ${
            activePanel === 'preset'
              ? 'bg-[#24211a] text-[#ecd296]'
              : 'text-[#d4cbb8] hover:bg-white/5 hover:text-[#f2eadb]'
          }`}
        >
          <svg
            viewBox="0 0 24 24"
            className={`h-4 w-4 shrink-0 fill-none stroke-2 ${
              activePanel === 'preset' ? 'stroke-[#dfb963]' : 'stroke-[#b59c6b]'
            }`}
          >
            <rect x="4" y="4" width="16" height="6" rx="1.5" />
            <rect x="4" y="14" width="16" height="6" rx="1.5" />
            <line x1="8" y1="7" x2="12" y2="7" strokeLinecap="round" />
            <line x1="8" y1="17" x2="14" y2="17" strokeLinecap="round" />
          </svg>
          <span className="font-bengali-ui whitespace-nowrap text-[10px] font-bold leading-none sm:text-xs">
            প্রিসেট
          </span>
          {activePanel === 'preset' && (
            <span aria-hidden="true" className="absolute inset-x-2 bottom-0 h-[2px] rounded-t bg-[#d9b566]" />
          )}
        </button>

        {/* 4. ল্যাব (Lab) */}
        <button
          type="button"
          onClick={() => togglePanel('lab')}
          aria-pressed={activePanel === 'lab'}
          className={`relative flex min-h-[40px] min-w-[66px] flex-col items-center justify-center gap-0.5 px-2.5 py-1.5 transition-colors active:scale-95 sm:min-h-[46px] sm:min-w-[84px] sm:flex-row sm:gap-2 sm:px-3.5 ${
            activePanel === 'lab'
              ? 'bg-[#24211a] text-[#ecd296]'
              : 'text-[#d4cbb8] hover:bg-white/5 hover:text-[#f2eadb]'
          }`}
        >
          <svg
            viewBox="0 0 24 24"
            className={`h-4 w-4 shrink-0 fill-none stroke-2 ${
              activePanel === 'lab' ? 'stroke-[#dfb963]' : 'stroke-[#b59c6b]'
            }`}
          >
            <path d="M9 3h6M10 3v5.5L5.2 17a2.5 2.5 0 0 0 2.2 3.7h9.2A2.5 2.5 0 0 0 18.8 17L14 8.5V3" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M8.5 14.5h7" strokeLinecap="round" />
          </svg>
          <span className="font-bengali-ui whitespace-nowrap text-[10px] font-bold leading-none sm:text-xs">
            ল্যাব
          </span>
          {activePanel === 'lab' && (
            <span aria-hidden="true" className="absolute inset-x-2 bottom-0 h-[2px] rounded-t bg-[#d9b566]" />
          )}
        </button>
      </nav>

      {/* DRAG-TO-ROTATE CUE (Wide Desktop Center Only — Never collides with Bottom Nav or Start CTA) */}
      <div className="pointer-events-none fixed bottom-[max(0.95rem,env(safe-area-inset-bottom))] left-1/2 z-10 hidden -translate-x-1/2 items-center gap-2 text-[11px] font-semibold text-[#d6cbb6]/85 drop-shadow xl:flex">
        <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 fill-none stroke-[#c9a659] stroke-2">
          <path d="M12 5l-5 5 5 5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        <span className="font-bengali-ui whitespace-nowrap">চরিত্র ঘোরাতে টেনে নিন</span>
        <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 fill-none stroke-[#c9a659] stroke-2">
          <path d="M8 5l5 5-5 5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </div>

      <div className="pointer-events-auto fixed bottom-[max(0.65rem,env(safe-area-inset-bottom))] right-[max(0.65rem,env(safe-area-inset-right))] z-20 flex flex-col items-end gap-1.5 sm:bottom-[max(0.9rem,env(safe-area-inset-bottom))] sm:right-[max(1.25rem,env(safe-area-inset-right))]">
          {/* Mode Selector: Survival Mode vs Separate Pet Taming Mode */}
          <div className="flex items-center gap-1 rounded-lg border border-[#b59c6b]/45 bg-[#121311]/94 p-1 shadow-[0_6px_18px_rgba(0,0,0,0.6)]">
            <button
              type="button"
              onClick={() => onSelectGameMode('survival')}
              className={`font-bengali-ui whitespace-nowrap rounded-md px-2.5 py-1 text-[11px] font-bold transition-colors sm:px-3 sm:py-1.5 sm:text-xs ${
                gameMode === 'survival'
                  ? 'border border-[#dec07c]/60 bg-gradient-to-b from-[#b88628] to-[#7d5514] text-[#140e06]'
                  : 'text-[#cfc6b4] hover:bg-white/8 hover:text-[#f0e8d8]'
              }`}
            >
              সার্ভাইভাল মোড
            </button>
            <button
              type="button"
              onClick={() => onSelectGameMode('pet_taming')}
              className={`font-bengali-ui flex items-center gap-1 whitespace-nowrap rounded-md px-2.5 py-1 text-[11px] font-bold transition-colors sm:px-3 sm:py-1.5 sm:text-xs ${
                gameMode === 'pet_taming'
                  ? 'border border-[#6eb898]/60 bg-gradient-to-b from-[#24664e] to-[#143d2e] text-[#e7f7ef]'
                  : 'text-[#a3cfb9] hover:bg-white/8 hover:text-[#dff5ea]'
              }`}
            >
              <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 shrink-0 fill-current">
                <circle cx="6.2" cy="6.8" r="1.7" />
                <circle cx="10" cy="5.4" r="1.7" />
                <circle cx="13.8" cy="6.8" r="1.7" />
                <path d="M10 9.4c-2.6 0-4.6 1.8-4.6 4.1 0 1.4 1.2 2.3 2.5 2.3 1 0 1.5-.4 2.1-.4s1.1.4 2.1.4c1.3 0 2.5-.9 2.5-2.3 0-2.3-2-4.1-4.6-4.1z" />
              </svg>
              <span>প্রাণী বশ মোড</span>
            </button>
          </div>

          <div className="pr-1 text-[11px] font-semibold text-[#dfd3bc] drop-shadow-[0_1px_4px_rgba(0,0,0,0.9)]">
            <span className="font-bengali-ui">
              {gameMode === 'pet_taming'
                ? permanentPet
                  ? `প্রাণী বশ মোড · স্থায়ী সঙ্গী: ${permanentPet.nameBn}`
                  : 'প্রাণী বশ মোড · আজীবনে ১টি স্থায়ী সঙ্গী'
                : 'সার্ভাইভাল মোড · ম্যাপ: বাংলা'}
            </span>
          </div>

          <button
            type="button"
            onClick={onStart}
            className={`font-bengali-display group relative flex items-center gap-2.5 overflow-hidden rounded-lg border px-6 py-3 text-lg font-extrabold tracking-wide transition-all duration-150 hover:brightness-110 active:scale-[0.98] sm:gap-3 sm:px-9 sm:py-3.5 sm:text-2xl ${
              gameMode === 'pet_taming'
                ? 'border-[#7bc4a4]/75 bg-gradient-to-b from-[#256950] via-[#1c523e] to-[#12382a] text-[#e9f7f0] shadow-[0_10px_24px_rgba(0,0,0,0.7),inset_0_1px_0_rgba(210,255,235,0.22)]'
                : 'border-[#e0c482]/80 bg-gradient-to-b from-[#bd8b2c] via-[#9c6f1d] to-[#6e4a10] text-[#140e06] shadow-[0_10px_24px_rgba(0,0,0,0.7),inset_0_1px_0_rgba(255,244,210,0.3)]'
            }`}
          >
            <span className="relative whitespace-nowrap">
              {gameMode === 'pet_taming' ? 'শিকার ও বশ শুরু' : 'খেলা শুরু করুন'}
            </span>
            <svg
              viewBox="0 0 24 24"
              className="relative h-5 w-5 fill-current transition-transform duration-150 group-hover:translate-x-1 sm:h-6 sm:w-6"
            >
              <path d="M8 5v14l11-7z" />
            </svg>
          </button>
      </div>
    </div>
  );
};
