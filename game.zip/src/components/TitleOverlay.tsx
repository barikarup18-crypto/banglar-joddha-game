import React, { useState } from 'react';
import { toBengaliNumber } from '../game/GameEngine';
import {
  ANIMAL_HEART_TIER_ORDER,
  ANIMAL_HEART_TIERS,
  computePetStats,
  computePlayerMaxHealth,
  computePlayerWeaponDamageMult,
  getNextPetUpgradeCost,
  getNextPlayerUpgradeCost,
  PET_MAX_LEVEL,
} from '../game/petSystem';
import {
  AnimalHeartWallet,
  ApsaraProgressState,
  GamchaStyle,
  GameMode,
  HERO_OUTFIT_CATALOG,
  HERO_OUTFIT_ORDER,
  HeroOutfitId,
  LevelUpFeedback,
  LoadoutPreset,
  TamedPetRecord,
  WEAPON_CATALOG,
  WEAPON_SLOT_ORDER,
  WeaponType,
} from '../game/types';

export type LobbyPanel =
  | 'character'
  | 'weapon'
  | 'pet'
  | 'map'
  | 'animal_heart'
  | 'vault'
  | 'preset'
  | 'lab'
  | null;

interface TitleOverlayProps {
  playerId: string;
  playerLevel: number;
  playerMaxLevel: number;
  playerXp: number;
  playerXpToNext: number;
  playerMaxHealth: number;
  weaponDamageBonusPct: number;
  levelUpNotice: LevelUpFeedback | null;
  permanentPet: TamedPetRecord | null;
  animalHearts: AnimalHeartWallet;
  gameMode: GameMode;
  muted: boolean;
  gamchaStyle: GamchaStyle;
  heroOutfit: HeroOutfitId;
  weaponType: WeaponType;
  presets: LoadoutPreset[];
  progress: ApsaraProgressState;
  onSelectGameMode: (mode: GameMode) => void;
  onSelectGamcha: (style: GamchaStyle) => void;
  onSelectOutfit: (outfit: HeroOutfitId) => void;
  onSelectWeapon: (weapon: WeaponType) => void;
  onApplyPreset: (preset: LoadoutPreset) => void;
  onSavePreset: (slot: 1 | 2 | 3) => void;
  onUpgradePlayer: () => void;
  onUpgradePet: () => void;
  onStart: () => void;
  onToggleMute: () => void;
  onOpenSettings: () => void;
}

const WEAPON_DISPLAY_STATS: Record<
  WeaponType,
  { subtitle: string; badge: string; powerPct: number; rangePct: number; barColor: string }
> = {
  agni47: {
    subtitle: 'স্বয়ংক্রিয় রাইফেল',
    badge: '২৪ গুলি',
    powerPct: 76,
    rangePct: 82,
    barColor: 'bg-[#f5c03e]',
  },
  kalbhairav: {
    subtitle: 'ভারী শটগান · ৫x স্প্রেড',
    badge: '৮ শেল',
    powerPct: 96,
    rangePct: 46,
    barColor: 'bg-[#ee6034]',
  },
  trishul: {
    subtitle: 'দূরপাল্লার স্নাইপার · ৪x স্কোপ',
    badge: '৫ গুলি',
    powerPct: 98,
    rangePct: 98,
    barColor: 'bg-[#56beff]',
  },
  fala: {
    subtitle: 'দ্রুত নীরব তীক্ষ্ণ ফলা',
    badge: 'অসীম',
    powerPct: 84,
    rangePct: 24,
    barColor: 'bg-[#d6e4f2]',
  },
};

export const TitleOverlay: React.FC<TitleOverlayProps> = ({
  playerId,
  playerLevel,
  playerMaxLevel,
  playerMaxHealth,
  weaponDamageBonusPct,
  levelUpNotice,
  permanentPet,
  animalHearts,
  gameMode,
  muted,
  gamchaStyle,
  heroOutfit,
  weaponType,
  presets,
  progress,
  onSelectGameMode,
  onSelectGamcha,
  onSelectOutfit,
  onSelectWeapon,
  onApplyPreset,
  onSavePreset,
  onUpgradePlayer,
  onUpgradePet,
  onStart,
  onToggleMute,
  onOpenSettings,
}) => {
  const [activePanel, setActivePanel] = useState<LobbyPanel>(null);
  const [savedPresetSlot, setSavedPresetSlot] = useState<number | null>(null);

  const playerLevelPct = Math.max(5, Math.min(100, (playerLevel / Math.max(1, playerMaxLevel)) * 100));
  const isPlayerMaxLv = playerLevel >= playerMaxLevel;
  const nextPlayerCost = getNextPlayerUpgradeCost(playerLevel);
  const canUpgradePlayer =
    !isPlayerMaxLv && nextPlayerCost > 0 && animalHearts.totalValue >= nextPlayerCost;

  const petCurLv = permanentPet?.upgrades.level ?? 0;
  const isPetMaxLv = Boolean(permanentPet && petCurLv >= PET_MAX_LEVEL);
  const nextPetCost = permanentPet ? getNextPetUpgradeCost(petCurLv) : 0;
  const canUpgradePet = Boolean(
    permanentPet && !isPetMaxLv && nextPetCost > 0 && animalHearts.totalValue >= nextPetCost,
  );
  const anyHeartLevelUpReady = canUpgradePlayer || canUpgradePet;

  const togglePanel = (panel: Exclude<LobbyPanel, null>) => {
    setActivePanel((prev) => (prev === panel ? null : panel));
  };

  return (
    <div className="pointer-events-none fixed inset-0 z-30 flex flex-col overflow-hidden pb-[max(0.65rem,env(safe-area-inset-bottom))] pl-[max(0.65rem,env(safe-area-inset-left))] pr-[max(0.65rem,env(safe-area-inset-right))] pt-[max(0.65rem,env(safe-area-inset-top))] sm:pb-[max(0.9rem,env(safe-area-inset-bottom))] sm:pl-[max(1.25rem,env(safe-area-inset-left))] sm:pr-[max(1.25rem,env(safe-area-inset-right))] sm:pt-[max(0.85rem,env(safe-area-inset-top))]">
      {/* Subtle top/bottom cinematic edge shading without obstructing the center 3D hero */}
      <div className="pointer-events-none fixed inset-x-0 top-0 -z-10 h-24 bg-gradient-to-b from-[#130b07]/70 to-transparent" />
      <div className="pointer-events-none fixed inset-x-0 bottom-0 -z-10 h-28 bg-gradient-to-t from-[#130b07]/78 to-transparent" />

      {/* Lobby Level-Up Celebration Toast (Player or Pet Upgrade via Animal Hearts) */}
      {levelUpNotice && (
        <div
          key={levelUpNotice.seq}
          className={`pointer-events-none fixed left-1/2 top-[calc(4.6rem+env(safe-area-inset-top))] z-[60] flex w-max max-w-[90vw] -translate-x-1/2 flex-col items-center rounded-2xl border-2 px-4 py-2 text-center shadow-[0_10px_24px_rgba(0,0,0,0.65)] ${
            levelUpNotice.target === 'player'
              ? 'border-[#ffd95e] bg-[#2a1a09]/95 shadow-[0_0_24px_rgba(255,204,64,0.48),0_10px_24px_rgba(0,0,0,0.65)]'
              : 'border-[#88ffd4] bg-[#0e261d]/95 shadow-[0_0_24px_rgba(77,245,184,0.45),0_10px_24px_rgba(0,0,0,0.65)]'
          }`}
        >
          {(levelUpNotice.target === 'player' || levelUpNotice.target === 'both') && (
            <>
              <div className="font-bengali-display text-sm font-extrabold text-[#ffe178] sm:text-base">
                ভানু লেভেল আপ! LV {toBengaliNumber(levelUpNotice.playerLevel)}
              </div>
              <div className="font-bengali-ui text-[10px] font-bold text-[#fff2cc] sm:text-xs">
                সর্বোচ্চ স্বাস্থ্য +{toBengaliNumber(levelUpNotice.playerHpGain)} · অস্ত্রের ক্ষতি +{toBengaliNumber(levelUpNotice.playerDmgBonusPct)}%
              </div>
            </>
          )}
          {(levelUpNotice.target === 'pet' || levelUpNotice.target === 'both') &&
            levelUpNotice.petNameBn &&
            levelUpNotice.petLevel && (
              <>
                <div className="font-bengali-display text-sm font-extrabold text-[#88ffd4] sm:text-base">
                  {levelUpNotice.petNameBn} লেভেল আপ! স্তর {toBengaliNumber(levelUpNotice.petLevel)}
                </div>
                <div className="font-bengali-ui text-[10px] font-bold text-[#d9fff1] sm:text-xs">
                  স্বাস্থ্য +{toBengaliNumber(levelUpNotice.petHpGain ?? 0)} · ক্ষতি +{toBengaliNumber(levelUpNotice.petDmgGain ?? 0)} · গতি +{toBengaliNumber(levelUpNotice.petSpeedGain ?? 0)}
                </div>
              </>
            )}
        </div>
      )}

      {/* TOP BAR: Player Profile Badge (Left) + Game Title Emblem, Settings & Audio (Right) */}
      <div className="relative z-20 flex shrink-0 items-start justify-between gap-2">
        {/* Top-Left: Player Profile Badge ('ভানু • LV X') + Live XP Bar + Live Gold Coins & Diamonds */}
        <div className="pointer-events-auto flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2.5 rounded-xl border border-[#f5c763]/55 bg-[#19110c]/90 px-2.5 py-1.5 shadow-[0_6px_20px_rgba(0,0,0,0.52)]">
            <div className="relative flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-lg border border-[#ffd87d]/70 bg-gradient-to-b from-[#8f261f] to-[#3a120e]">
              <svg viewBox="0 0 40 40" className="h-9 w-9">
                <path d="M6 38 Q20 26 34 38 Z" fill={gamchaStyle === 'red-white' ? '#c92228' : '#1b7a3d'} />
                <path d="M10 38 Q20 30 30 38 Z" fill="#faf3e6" fillOpacity="0.65" />
                <circle cx="20" cy="17" r="8.5" fill="#c99163" />
                <path d="M11 16 C11 8, 29 8, 29 16 C26 11, 14 11, 11 16 Z" fill="#181414" />
                <rect
                  x="11.5"
                  y="12.5"
                  width="17"
                  height="2.8"
                  rx="1"
                  fill={gamchaStyle === 'red-white' ? '#d42028' : '#208844'}
                />
                <path d="M16.5 21 Q20 19.6 23.5 21" stroke="#181414" strokeWidth="1.6" fill="none" strokeLinecap="round" />
              </svg>
            </div>

            <div className="pr-1">
              <div className="flex items-center gap-1.5">
                <span className="font-bengali-ui whitespace-nowrap text-sm font-bold tracking-wide text-[#fff4de] sm:text-base">
                  ভানু • LV {toBengaliNumber(playerLevel)}
                </span>
                <span className="rounded bg-[#302014] px-1.5 py-0.5 font-mono text-[9px] font-bold tracking-wider text-[#ffd87c]">
                  {playerId}
                </span>
              </div>
              <div className="mt-0.5 flex items-center gap-1.5">
                <div className="h-1.5 w-16 overflow-hidden rounded-full bg-[#362418] sm:w-20">
                  <div
                    style={{ width: `${playerLevelPct}%` }}
                    className="h-full rounded-full bg-gradient-to-r from-[#f7b529] to-[#ffe17a] transition-[width] duration-200"
                  />
                </div>
                <span className="font-bengali-ui tabular-nums whitespace-nowrap text-[10px] font-semibold text-[#ffd87c]">
                  {isPlayerMaxLv
                    ? 'সর্বোচ্চ LV'
                    : `LV ${toBengaliNumber(playerLevel)}/${toBengaliNumber(playerMaxLevel)}`}
                </span>
              </div>
              <div className="font-bengali-ui mt-0.5 flex items-center gap-1.5 text-[9px] font-semibold text-[#e6cba0]">
                <span>স্বাস্থ্য {toBengaliNumber(playerMaxHealth)}</span>
                <span>·</span>
                <span className="text-[#ffb870]">
                  ক্ষতি +{toBengaliNumber(weaponDamageBonusPct)}%
                </span>
                <span className="hidden text-[#ffd87c]/80 sm:inline">· {progress.activeTitle}</span>
              </div>
            </div>
          </div>

          {/* Live স্বর্ণমুদ্রা (Gold Coins), Diamonds & Dedicated Standalone Animal Heart Button */}
          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
            <div className="flex items-center gap-1.5 rounded-lg border border-[#f5c763]/45 bg-[#19110c]/88 px-2.5 py-1.5 shadow-[0_4px_14px_rgba(0,0,0,0.45)]">
              <svg viewBox="0 0 20 20" className="h-4 w-4 shrink-0">
                <circle cx="10" cy="10" r="8.5" fill="#f7c034" stroke="#9e640b" strokeWidth="1.4" />
                <circle cx="10" cy="10" r="5.5" fill="none" stroke="#fff0b5" strokeWidth="1.1" />
                <text x="10" y="13.2" textAnchor="middle" fontSize="8.5" fontWeight="bold" fill="#7c4704">
                  ৳
                </text>
              </svg>
              <span className="font-bengali-ui tabular-nums text-xs font-bold text-[#ffe59e] sm:text-sm">
                {toBengaliNumber(progress.goldCoins)}
              </span>
            </div>

            <div className="flex items-center gap-1.5 rounded-lg border border-[#63d4f5]/45 bg-[#111920]/88 px-2.5 py-1.5 shadow-[0_4px_14px_rgba(0,0,0,0.45)]">
              <svg viewBox="0 0 20 20" className="h-4 w-4 shrink-0">
                <polygon points="10,2 18,8 10,18 2,8" fill="#3fd3ff" stroke="#b8f3ff" strokeWidth="1.2" />
                <polyline points="2,8 18,8" stroke="#c8f7ff" strokeWidth="0.9" fill="none" />
                <polyline points="6,8 10,2 14,8 10,18 6,8" stroke="#0c84b0" strokeWidth="0.8" fill="none" />
              </svg>
              <span className="font-bengali-ui tabular-nums text-xs font-bold text-[#bdf2ff] sm:text-sm">
                {toBengaliNumber(progress.diamonds)}
              </span>
            </div>

            {/* Dedicated Separate Animal Heart Button — Opens Player & Animal Level-Up Modal */}
            <button
              type="button"
              onClick={() => togglePanel('animal_heart')}
              aria-label="এনিমেল হার্ট লেভেল আপ"
              className={`relative flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 shadow-[0_4px_14px_rgba(0,0,0,0.48)] transition-all active:scale-95 ${
                activePanel === 'animal_heart'
                  ? 'border-[#ff9cb4] bg-gradient-to-r from-[#59162b] to-[#3d111e] text-[#fff0f4] shadow-[0_0_16px_rgba(255,90,130,0.45)]'
                  : 'border-[#ff6b8d]/70 bg-gradient-to-r from-[#36101d]/95 to-[#240c14]/95 text-[#ffd9e3] hover:border-[#ff9bb2] hover:brightness-110'
              }`}
            >
              <svg viewBox="0 0 20 20" className="h-4 w-4 shrink-0 fill-[#ff4d79] drop-shadow-[0_0_6px_rgba(255,77,121,0.75)]">
                <path d="M10 17.4l-1.3-1.2C4.2 12.1 1.6 9.7 1.6 6.6 1.6 4.1 3.5 2.3 6 2.3c1.4 0 2.7.7 3.5 1.8h1c.8-1.1 2.1-1.8 3.5-1.8 2.5 0 4.4 1.8 4.4 4.3 0 3.1-2.6 5.5-7.1 9.6L10 17.4z" />
              </svg>
              <span className="font-bengali-ui whitespace-nowrap text-[11px] font-bold text-[#ffc8d6] sm:text-xs">
                এনিমেল হার্ট
              </span>
              <span className="font-bengali-ui tabular-nums rounded bg-[#1a0810]/85 px-1.5 py-0.5 text-[11px] font-extrabold leading-none text-[#ffe28a] sm:text-xs">
                {toBengaliNumber(animalHearts.totalValue)}
              </span>
              {anyHeartLevelUpReady && (
                <span
                  aria-hidden="true"
                  className="absolute -right-1 -top-1 flex h-2.5 w-2.5"
                >
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#ffcf48] opacity-80" />
                  <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-[#ffd84d]" />
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Top-Right: Compact Game Emblem + Settings & Audio Toggles */}
        <div className="flex shrink-0 items-center gap-1.5 sm:gap-2">
          <div className="flex items-center gap-2">
            <div className="hidden flex-col items-end sm:flex">
              <span className="font-bengali-display text-lg font-extrabold tracking-wide text-[#ffd875] drop-shadow-[0_2px_8px_rgba(0,0,0,0.85)]">
                বাংলার যোদ্ধা
              </span>
              <span className="font-bengali-ui text-[11px] font-medium text-[#e9cfa8]/85">
                হুগলি তীর · পশ্চিমবঙ্গ
              </span>
            </div>
            <div className="h-10 w-10 shrink-0 overflow-hidden rounded-xl border border-[#f5c763]/75 bg-[#121620] shadow-[0_6px_18px_rgba(0,0,0,0.62)] sm:h-11 sm:w-11">
              <img
                src="./assets/app-logo.png"
                alt="বাংলার যোদ্ধা"
                draggable={false}
                className="h-full w-full scale-[1.28] object-cover"
              />
            </div>
          </div>

          <button
            type="button"
            onClick={onOpenSettings}
            aria-label="সেটিংস"
            title="সেটিংস"
            className="pointer-events-auto flex h-10 items-center justify-center gap-1.5 rounded-xl border border-[#f0c268]/55 bg-[#19110c]/88 px-2.5 text-[#ffe394] shadow transition-colors hover:border-[#ffd76a] hover:bg-[#2a1c14] active:scale-95 sm:px-3"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5 shrink-0 fill-none stroke-current stroke-2">
              <circle cx="12" cy="12" r="3" />
              <path
                d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.08a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h.08a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v.08a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <span className="font-bengali-ui hidden whitespace-nowrap text-xs font-bold sm:inline">
              সেটিংস
            </span>
          </button>

          <button
            type="button"
            onClick={onToggleMute}
            aria-label={muted ? 'শব্দ চালু করুন' : 'শব্দ বন্ধ করুন'}
            className="pointer-events-auto flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-[#f0c268]/45 bg-[#19110c]/88 text-[#fdebd0] shadow hover:bg-[#2a1c14] active:scale-95"
          >
            {muted ? (
              <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-2">
                <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                <line x1="22" y1="9" x2="16" y2="15" strokeLinecap="round" />
                <line x1="16" y1="9" x2="22" y2="15" strokeLinecap="round" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-2">
                <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                <path d="M15.5 8.5a5 5 0 0 1 0 7" strokeLinecap="round" />
                <path d="M18.8 5.5a9 9 0 0 1 0 13" strokeLinecap="round" />
              </svg>
            )}
          </button>
        </div>
      </div>

      {/* MIDDLE ROW: Compact Left Menu Rail pushed cleanly below Top Profile/LV/XP Card and above Bottom Nav Strip */}
      <div className="relative z-10 mt-4 flex min-h-0 flex-1 items-start justify-start gap-2 pb-14 sm:mt-6 sm:pb-16 [@media(max-height:500px)]:mt-3 [@media(max-height:500px)]:pb-12">
        {/* Left Navigation Rail + Contextual Drawer */}
        <div className="relative flex max-h-full items-start gap-2">
          <div className="pointer-events-auto flex max-h-full flex-col gap-[3px] overflow-y-auto pr-0.5 sm:gap-1 [@media(max-height:500px)]:gap-[2px]">
            {/* 1. চরিত্র (Character) */}
            <button
              type="button"
              onClick={() => togglePanel('character')}
              className={`flex w-[82px] items-center gap-1 rounded-md border px-1.5 py-[3px] text-left shadow-[0_3px_10px_rgba(0,0,0,0.42)] transition-colors active:scale-95 sm:w-[104px] sm:gap-1.5 sm:px-2 sm:py-1 ${
                activePanel === 'character'
                  ? 'border-[#ffd23f] bg-[#2e1d12]/94 text-[#fff4d4]'
                  : 'border-[#e8bc6a]/35 bg-[#18100b]/86 text-[#f5e3c6] hover:bg-[#241811]/92'
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-3 w-3 shrink-0 fill-none stroke-[#ffd05b] stroke-2 sm:h-3.5 sm:w-3.5">
                <circle cx="12" cy="7.5" r="3.5" />
                <path d="M5 20c0-3.8 3.1-6.5 7-6.5s7 2.7 7 6.5" strokeLinecap="round" />
              </svg>
              <div className="min-w-0">
                <div className="font-bengali-ui truncate text-[10px] font-bold leading-[1.15] sm:text-[11px]">চরিত্র</div>
                <div className="font-bengali-ui truncate text-[8px] leading-[1.1] text-[#d6ba91] sm:text-[8.5px]">
                  {gamchaStyle === 'red-white' ? 'লাল-সাদা গামছা' : 'সবুজ-সাদা গামছা'}
                </div>
              </div>
            </button>

            {/* 2. অস্ত্র (Weapons) */}
            <button
              type="button"
              onClick={() => togglePanel('weapon')}
              className={`flex w-[82px] items-center gap-1 rounded-md border px-1.5 py-[3px] text-left shadow-[0_3px_10px_rgba(0,0,0,0.42)] transition-colors active:scale-95 sm:w-[104px] sm:gap-1.5 sm:px-2 sm:py-1 ${
                activePanel === 'weapon'
                  ? 'border-[#ffd23f] bg-[#2e1d12]/94 text-[#fff4d4]'
                  : 'border-[#e8bc6a]/35 bg-[#18100b]/86 text-[#f5e3c6] hover:bg-[#241811]/92'
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-3 w-3 shrink-0 fill-none stroke-[#ffd05b] stroke-2 sm:h-3.5 sm:w-3.5">
                <path d="M3 11h14l4-2v4l-4-1H13l-2 5H8l1-5H5l-2 2v-3z" strokeLinejoin="round" />
              </svg>
              <div className="min-w-0">
                <div className="font-bengali-ui truncate text-[10px] font-bold leading-[1.15] sm:text-[11px]">অস্ত্র</div>
                <div className="font-bengali-ui truncate text-[8px] leading-[1.1] text-[#d6ba91] sm:text-[8.5px]">
                  {WEAPON_CATALOG[weaponType].name}
                </div>
              </div>
            </button>

            {/* 2b. পোষা সঙ্গী (Lifetime One-Pet Companion & Upgrade Placeholder) */}
            <button
              type="button"
              onClick={() => togglePanel('pet')}
              className={`relative flex w-[82px] items-center gap-1 rounded-md border px-1.5 py-[3px] text-left shadow-[0_3px_10px_rgba(0,0,0,0.42)] transition-colors active:scale-95 sm:w-[104px] sm:gap-1.5 sm:px-2 sm:py-1 ${
                activePanel === 'pet'
                  ? 'border-[#6effc8] bg-[#102920]/94 text-[#e9fff6]'
                  : permanentPet
                    ? 'border-[#4df5b8]/55 bg-[#11211b]/88 text-[#e4fff5] hover:bg-[#163026]/92'
                    : 'border-[#e8bc6a]/35 bg-[#18100b]/86 text-[#f5e3c6] hover:bg-[#241811]/92'
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-3 w-3 shrink-0 fill-[#5ef2bc] sm:h-3.5 sm:w-3.5">
                <circle cx="7.5" cy="8.5" r="2" />
                <circle cx="12" cy="6.8" r="2" />
                <circle cx="16.5" cy="8.5" r="2" />
                <path d="M12 11.4c-3.1 0-5.4 2.1-5.4 4.8 0 1.6 1.4 2.7 3 2.7 1.1 0 1.8-.4 2.4-.4s1.3.4 2.4.4c1.6 0 3-1.1 3-2.7 0-2.7-2.3-4.8-5.4-4.8z" />
              </svg>
              <div className="min-w-0 flex-1">
                <div className="font-bengali-ui truncate text-[10px] font-bold leading-[1.15] sm:text-[11px]">
                  পোষা সঙ্গী
                </div>
                <div className="font-bengali-ui truncate text-[8px] leading-[1.1] text-[#9be8cc] sm:text-[8.5px]">
                  {permanentPet ? permanentPet.nameBn : '১টি স্থায়ী বশ করুন'}
                </div>
              </div>
            </button>

            {/* 3. ম্যাপ: বাংলা (Map) */}
            <button
              type="button"
              onClick={() => togglePanel('map')}
              className={`flex w-[82px] items-center gap-1 rounded-md border px-1.5 py-[3px] text-left shadow-[0_3px_10px_rgba(0,0,0,0.42)] transition-colors active:scale-95 sm:w-[104px] sm:gap-1.5 sm:px-2 sm:py-1 ${
                activePanel === 'map'
                  ? 'border-[#ffd23f] bg-[#2e1d12]/94 text-[#fff4d4]'
                  : 'border-[#e8bc6a]/35 bg-[#18100b]/86 text-[#f5e3c6] hover:bg-[#241811]/92'
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-3 w-3 shrink-0 fill-none stroke-[#ffd05b] stroke-2 sm:h-3.5 sm:w-3.5">
                <path d="M12 21s-6-5.2-6-10a6 6 0 1 1 12 0c0 4.8-6 10-6 10z" />
                <circle cx="12" cy="11" r="2.2" />
              </svg>
              <div className="min-w-0">
                <div className="font-bengali-ui truncate text-[10px] font-bold leading-[1.15] sm:text-[11px]">
                  ম্যাপ: বাংলা
                </div>
                <div className="font-bengali-ui truncate text-[8px] leading-[1.1] text-[#d6ba91] sm:text-[8.5px]">হুগলি ও হাওড়া</div>
              </div>
            </button>
          </div>

          {/* Contextual Popover Drawers */}
          {activePanel === 'character' && (
            <div className="pointer-events-auto fixed left-[max(0.75rem,env(safe-area-inset-left))] top-1/2 z-40 max-h-[calc(100dvh-6rem-env(safe-area-inset-top)-env(safe-area-inset-bottom))] w-[min(236px,calc(100vw-1.5rem-env(safe-area-inset-left)-env(safe-area-inset-right)))] -translate-y-1/2 overflow-y-auto rounded-xl border border-[#f5c763]/55 bg-[#1a110c]/95 p-4 shadow-[0_14px_36px_rgba(0,0,0,0.72)] md:static md:translate-y-0">
              <div className="mb-3 flex items-center justify-between">
                <span className="font-bengali-ui text-sm font-bold text-[#ffd978]">
                  গামছার রঙ বাছুন
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="text-xs font-bold text-[#ccb38e] hover:text-white"
                >
                  ✕
                </button>
              </div>
              <div className="flex flex-col gap-2">
                <button
                  type="button"
                  onClick={() => onSelectGamcha('red-white')}
                  className={`flex items-center gap-3 rounded-lg border px-3 py-2 text-left transition-colors ${
                    gamchaStyle === 'red-white'
                      ? 'border-[#ffd24c] bg-[#361813] text-[#fff6e3]'
                      : 'border-[#e8bc6a]/25 bg-[#231710] text-[#dfcaa8] hover:bg-[#2d1e15]'
                  }`}
                >
                  <span className="flex h-7 w-7 shrink-0 overflow-hidden rounded-md border border-[#fff2d9]/60">
                    <span className="h-full w-1/2 bg-[#c81f26]" />
                    <span className="h-full w-1/2 bg-[#faf3e6]" />
                  </span>
                  <div>
                    <div className="font-bengali-ui text-xs font-bold">লাল-সাদা গামছা</div>
                    <div className="font-bengali-ui text-[10px] text-[#c8b08a]">ঐতিহ্যবাহী বাংলা</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => onSelectGamcha('green-white')}
                  className={`flex items-center gap-3 rounded-lg border px-3 py-2 text-left transition-colors ${
                    gamchaStyle === 'green-white'
                      ? 'border-[#ffd24c] bg-[#16301d] text-[#fff6e3]'
                      : 'border-[#e8bc6a]/25 bg-[#231710] text-[#dfcaa8] hover:bg-[#2d1e15]'
                  }`}
                >
                  <span className="flex h-7 w-7 shrink-0 overflow-hidden rounded-md border border-[#fff2d9]/60">
                    <span className="h-full w-1/2 bg-[#1c7c3e]" />
                    <span className="h-full w-1/2 bg-[#faf3e6]" />
                  </span>
                  <div>
                    <div className="font-bengali-ui text-xs font-bold">সবুজ-সাদা গামছা</div>
                    <div className="font-bengali-ui text-[10px] text-[#c8b08a]">নদী তীরের স্টাইল</div>
                  </div>
                </button>
              </div>
            </div>
          )}

          {activePanel === 'weapon' && (
            <div className="pointer-events-auto fixed left-[max(0.65rem,env(safe-area-inset-left))] top-[calc(4.15rem+env(safe-area-inset-top))] bottom-[calc(3.65rem+env(safe-area-inset-bottom))] z-40 w-[min(266px,calc(48vw-0.75rem))] overflow-y-auto rounded-xl border border-[#f5c763]/55 bg-[#1a110c]/95 p-3.5 shadow-[0_14px_36px_rgba(0,0,0,0.72)] sm:p-4 lg:static lg:top-auto lg:bottom-auto lg:max-h-[calc(100dvh-11rem)] lg:w-[272px]">
              <div className="mb-3 flex items-center justify-between">
                <span className="font-bengali-ui text-sm font-bold text-[#ffd978]">
                  অস্ত্র নির্বাচন
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="text-xs font-bold text-[#ccb38e] hover:text-white"
                >
                  ✕
                </button>
              </div>
              <div className="flex flex-col gap-2">
                {WEAPON_SLOT_ORDER.map((id) => {
                  const meta = WEAPON_CATALOG[id];
                  const stats = WEAPON_DISPLAY_STATS[id];
                  const selected = weaponType === id;
                  return (
                    <button
                      key={id}
                      type="button"
                      onClick={() => onSelectWeapon(id)}
                      className={`rounded-lg border p-2 text-left transition-colors ${
                        selected
                          ? 'border-[#ffd24c] bg-[#302012] text-[#fff6e3]'
                          : 'border-[#e8bc6a]/25 bg-[#231710] text-[#dfcaa8] hover:bg-[#2d1e15]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1">
                        <span className="font-bengali-ui text-xs font-bold">
                          {toBengaliNumber(meta.slot)}. {meta.name}
                        </span>
                        <span className="font-bengali-ui text-[10px] font-semibold text-[#ffd262]">
                          {stats.badge}
                        </span>
                      </div>
                      <div className="font-bengali-ui text-[10px] text-[#c8ae89]">{stats.subtitle}</div>
                      <div className="mt-1 space-y-1 text-[10px] text-[#cdb591]">
                        <div className="flex items-center gap-2">
                          <span className="w-9">ক্ষতি</span>
                          <div className="h-1.5 flex-1 rounded-full bg-[#3a281c]">
                            <div
                              style={{ width: `${stats.powerPct}%` }}
                              className={`h-full rounded-full ${stats.barColor}`}
                            />
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="w-9">রেঞ্জ</span>
                          <div className="h-1.5 flex-1 rounded-full bg-[#3a281c]">
                            <div
                              style={{ width: `${stats.rangePct}%` }}
                              className={`h-full rounded-full bg-[#f5c03e]`}
                            />
                          </div>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* পোষা সঙ্গী (Permanent Lifetime Companion & Future Resource Upgrade Placeholder Drawer) */}
          {activePanel === 'pet' && (
            <div className="pointer-events-auto fixed left-[max(0.75rem,env(safe-area-inset-left))] top-1/2 z-40 max-h-[calc(100dvh-6rem-env(safe-area-inset-top)-env(safe-area-inset-bottom))] w-[min(308px,calc(100vw-1.5rem-env(safe-area-inset-left)-env(safe-area-inset-right)))] -translate-y-1/2 overflow-y-auto rounded-xl border border-[#5ef2bc]/60 bg-[#0e1b16]/96 p-4 shadow-[0_14px_38px_rgba(0,0,0,0.78)] md:static md:translate-y-0">
              <div className="mb-2.5 flex items-center justify-between gap-2">
                <span className="font-bengali-ui text-sm font-bold text-[#88ffd4]">
                  পোষা সঙ্গী · আজীবনের নিয়ম
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="text-xs font-bold text-[#9bc9b8] hover:text-white"
                >
                  ✕
                </button>
              </div>

              <div className="mb-2.5 flex items-center justify-between rounded-lg border border-[#5ef2bc]/25 bg-[#0a1410] px-2.5 py-1.5 text-[11px]">
                <span className="font-bengali-ui text-[#b8decf]">প্লেয়ার আইডি</span>
                <span className="font-mono font-bold text-[#ffe27a]">{playerId}</span>
              </div>

              {/* Per-Player Animal Heart Inventory Card */}
              <div className="mb-3 rounded-lg border border-rose-400/45 bg-[#231018]/90 px-2.5 py-2">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 shrink-0 fill-[#ff587a]">
                      <path d="M10 17.2l-1.2-1.1C4.4 12.2 1.8 9.8 1.8 6.8 1.8 4.4 3.6 2.6 6 2.6c1.4 0 2.7.7 3.5 1.8h1c.8-1.1 2.1-1.8 3.5-1.8 2.4 0 4.2 1.8 4.2 4.2 0 3-2.6 5.4-7 9.3L10 17.2z" />
                    </svg>
                    <span className="font-bengali-ui text-xs font-bold text-[#ffc2d0]">
                      এনিমেল হার্ট
                    </span>
                  </div>
                  <span className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#ffdf85]">
                    {toBengaliNumber(animalHearts.totalValue)} শক্তি
                  </span>
                </div>
                <div className="mt-1.5 grid grid-cols-2 gap-1">
                  {ANIMAL_HEART_TIER_ORDER.map((tier) => {
                    const count = animalHearts.tiers[tier] || 0;
                    const tMeta = ANIMAL_HEART_TIERS[tier];
                    const tierStyles: Record<number, string> = {
                      1: 'border-rose-300/45 bg-rose-500/20 text-[#ffe0e8]',
                      2: 'border-sky-300/50 bg-sky-500/20 text-[#d9f3ff]',
                      3: 'border-purple-300/55 bg-purple-500/20 text-[#f3dcff]',
                      4: 'border-amber-300/65 bg-amber-500/25 text-[#fff0c2]',
                    };
                    return (
                      <span
                        key={tier}
                        className={`font-bengali-ui flex items-center justify-between rounded border px-1.5 py-0.5 text-[9px] font-semibold ${
                          count > 0 ? tierStyles[tier] : 'border-white/10 bg-black/25 text-white/45'
                        }`}
                      >
                        <span>
                          {tMeta.shortNameBn} ({toBengaliNumber(tMeta.value)})
                        </span>
                        <span className="tabular-nums font-extrabold">×{toBengaliNumber(count)}</span>
                      </span>
                    );
                  })}
                </div>
                <p className="font-bengali-ui mt-1 text-[9px] leading-snug text-[#e6b8c4]/85">
                  খেলার সময় ৪ ধরনের এনিমেল হার্ট (সাধারণ ১ · দুর্লভ ৫ · মহাকাব্যিক ১৫ · কিংবদন্তি ৫০) সংগ্রহ করে লবিতে লেভেল আপ করুন।
                </p>
              </div>

              {permanentPet ? (
                (() => {
                  const curLv = permanentPet.upgrades.level;
                  const isMaxLv = curLv >= PET_MAX_LEVEL;
                  const nextCost = getNextPetUpgradeCost(curLv);
                  const nextStats = isMaxLv
                    ? null
                    : computePetStats(permanentPet.species, curLv + 1);
                  const canAfford = !isMaxLv && nextCost > 0 && animalHearts.totalValue >= nextCost;
                  const curStats = permanentPet.stats;

                  return (
                    <div className="space-y-3">
                      <div className="rounded-lg border border-[#5ef2bc]/45 bg-[#122b22] p-3">
                        <div className="flex items-center justify-between gap-2">
                          <div>
                            <div className="font-bengali-display text-base font-bold text-[#f2fff9]">
                              {permanentPet.nameBn}
                            </div>
                            <div className="font-bengali-ui text-[11px] font-semibold text-[#8cffd4]">
                              {permanentPet.titleBn} · স্তর {toBengaliNumber(curLv)}/{toBengaliNumber(PET_MAX_LEVEL)}
                            </div>
                          </div>
                          <span className="font-bengali-ui rounded-md border border-[#ffd873]/55 bg-[#2a200d] px-2 py-0.5 text-[10px] font-bold text-[#ffe28a]">
                            স্থায়ী লক
                          </span>
                        </div>
                        <p className="font-bengali-ui mt-1.5 text-[11px] leading-relaxed text-[#cceee1]">
                          সহায়তা: {permanentPet.assistRoleBn}
                        </p>

                        {/* Scaled Combat & Movement Stats Grid */}
                        <div className="mt-2.5 grid grid-cols-2 gap-1.5">
                          <div className="rounded-md border border-emerald-300/25 bg-[#0b1f18] px-2 py-1.5">
                            <div className="font-bengali-ui text-[9px] text-[#9fd8c4]">স্বাস্থ্য (HP)</div>
                            <div className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#e8fff6]">
                              {toBengaliNumber(curStats.maxHp)}
                              {nextStats && (
                                <span className="ml-1 text-[10px] font-bold text-[#7fffcb]">
                                  +{toBengaliNumber(nextStats.maxHp - curStats.maxHp)}
                                </span>
                              )}
                            </div>
                          </div>
                          <div className="rounded-md border border-amber-300/25 bg-[#0b1f18] px-2 py-1.5">
                            <div className="font-bengali-ui text-[9px] text-[#f3cfa0]">আক্রমণ ক্ষতি</div>
                            <div className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#ffe7b3]">
                              {toBengaliNumber(curStats.attackDamage)}
                              {nextStats && (
                                <span className="ml-1 text-[10px] font-bold text-[#ffd26a]">
                                  +{toBengaliNumber(nextStats.attackDamage - curStats.attackDamage)}
                                </span>
                              )}
                            </div>
                          </div>
                          <div className="rounded-md border border-sky-300/25 bg-[#0b1f18] px-2 py-1.5">
                            <div className="font-bengali-ui text-[9px] text-[#a7d8f0]">চলাচল গতি</div>
                            <div className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#dff4ff]">
                              {toBengaliNumber(curStats.moveSpeed)}
                              {nextStats && (
                                <span className="ml-1 text-[10px] font-bold text-[#7fd8ff]">
                                  +{toBengaliNumber(Number((nextStats.moveSpeed - curStats.moveSpeed).toFixed(1)))}
                                </span>
                              )}
                            </div>
                          </div>
                          <div className="rounded-md border border-purple-300/25 bg-[#0b1f18] px-2 py-1.5">
                            <div className="font-bengali-ui text-[9px] text-[#d6b8f5]">আঘাত কুলডাউন</div>
                            <div className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#f2e3ff]">
                              {toBengaliNumber(curStats.assistCooldown)} সে.
                              {nextStats && nextStats.assistCooldown < curStats.assistCooldown && (
                                <span className="ml-1 text-[10px] font-bold text-[#c79eff]">
                                  -{toBengaliNumber(Number((curStats.assistCooldown - nextStats.assistCooldown).toFixed(1)))}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        <p className="font-bengali-ui mt-2 text-[10px] text-[#b4d9cb]/85">
                          এই আইডি-তে আজীবনের সঙ্গী স্থায়ীভাবে যুক্ত আছে — দ্বিতীয় প্রাণী বশ করা যাবে না।
                        </p>
                      </div>

                      {/* Shortcut to Dedicated Animal Heart Level-Up Panel */}
                      <div className="rounded-lg border border-[#f5c763]/45 bg-[#1b150d]/95 p-3">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-bengali-ui text-xs font-bold text-[#ffe08a]">
                            সঙ্গী লেভেল-আপ (স্তর {toBengaliNumber(curLv)}/{toBengaliNumber(PET_MAX_LEVEL)})
                          </span>
                          <span
                            className={`font-bengali-ui rounded px-1.5 py-0.5 text-[9px] font-bold ${
                              isMaxLv
                                ? 'bg-emerald-500/25 text-[#88ffd4]'
                                : canAfford
                                  ? 'bg-rose-500/30 text-[#ffd6e0]'
                                  : 'bg-[#332614] text-[#ffd26a]'
                            }`}
                          >
                            {isMaxLv ? 'সর্বোচ্চ স্তর' : `প্রয়োজন: ${toBengaliNumber(nextCost)} হার্ট`}
                          </span>
                        </div>

                        <button
                          type="button"
                          onClick={() => setActivePanel('animal_heart')}
                          className="font-bengali-ui mt-2.5 flex w-full items-center justify-center gap-1.5 rounded-lg border border-[#ff9bb2]/80 bg-gradient-to-r from-[#9e1d44] to-[#c43a2b] px-3 py-2 text-xs font-extrabold text-white shadow-[0_4px_14px_rgba(225,65,95,0.35)] transition-all hover:brightness-110 active:scale-95"
                        >
                          <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 shrink-0 fill-[#ffd2dc]">
                            <path d="M10 17.2l-1.2-1.1C4.4 12.2 1.8 9.8 1.8 6.8 1.8 4.4 3.6 2.6 6 2.6c1.4 0 2.7.7 3.5 1.8h1c.8-1.1 2.1-1.8 3.5-1.8 2.4 0 4.2 1.8 4.2 4.2 0 3-2.6 5.4-7 9.3L10 17.2z" />
                          </svg>
                          <span>এনিমেল হার্ট লেভেল আপ প্যানেল খুলুন</span>
                        </button>

                        <div className="font-bengali-ui mt-2 text-[10px] leading-snug text-[#d8c3a3]">
                          {permanentPet.upgrades.unlockedPerks[permanentPet.upgrades.unlockedPerks.length - 1]}
                        </div>
                      </div>
                    </div>
                  );
                })()
              ) : (
                <div className="space-y-2.5">
                  <div className="rounded-lg border border-[#ffd873]/40 bg-[#24190d] p-2.5">
                    <div className="font-bengali-ui text-xs font-bold text-[#ffe28a]">
                      আজীবনে কেবল ১টি প্রাণী বশ করা যাবে!
                    </div>
                    <p className="font-bengali-ui mt-1 text-[11px] leading-relaxed text-[#e6d1b0]">
                      জঙ্গল, পাথুরে গুহা, পাথুরে পাহাড়, জলাভূমি, প্রাচীন ধ্বংসাবশেষ ও উন্মুক্ত তৃণভূমিতে লুকিয়ে থাকা গরিলা রাজা, অজগর সাপ, সিংহ রাজা, ভয়ংকর মাকড়সা, রয়্যাল টাইগার, বন্য শূকর ও ভালুক খুঁজে বের করে বশ করুন এবং এনিমেল হার্ট সংগ্রহ করুন।
                    </p>
                  </div>

                  <ol className="font-bengali-ui space-y-1.5 text-[11px] leading-snug text-[#d6f5e8]">
                    <li>
                      <span className="font-bold text-[#ffe078]">১. লড়ে দুর্বল করুন:</span> ক্ষিপ্র প্রাণীটির স্বাস্থ্য ২২% এর নিচে নামান — কিন্তু <span className="font-bold text-[#ff8a80]">মারা গেলে বশ ব্যর্থ হবে!</span>
                    </li>
                    <li>
                      <span className="font-bold text-[#ffe078]">২. সোনালি বলয়ে বশ করুন [T]:</span> দ্রুত সোনালি বলয়ে ঢুকে <span className="font-bold text-[#88ffd4]">প্রাণী বশ করুন</span> বাটনে চাপুন (দেরি করলে শক্তি ফিরে পাবে)।
                    </li>
                    <li>
                      <span className="font-bold text-[#ffe078]">৩. সম্পূর্ণ স্থির থাকুন:</span> ৪.৫ সেকেন্ড এক চুলও নড়াচড়া বা আঘাত এড়িয়ে চললে প্রাণীটি আপনার আইডি-র স্থায়ী সঙ্গী হবে।
                    </li>
                    <li>
                      <span className="font-bold text-[#ff9bb2]">৪. এনিমেল হার্ট দিয়ে লেভেল-আপ:</span> সব প্রাণী হার্ট দেয় না — কেবল নির্বাচিত বিশেষ হৃদয়ধারী প্রাণী পরাজিত করে ৪ স্তরের (১, ৫, ১৫, ৫০) এনিমেল হার্ট সংগ্রহ করুন এবং লবিতে খেলোয়াড় বা সঙ্গী লেভেল-আপ করুন।
                    </li>
                  </ol>

                  <button
                    type="button"
                    onClick={() => {
                      onSelectGameMode('pet_taming');
                      setActivePanel(null);
                    }}
                    className={`font-bengali-ui w-full rounded-lg border px-3 py-2 text-xs font-extrabold transition-colors active:scale-95 ${
                      gameMode === 'pet_taming'
                        ? 'border-[#7fffcb] bg-[#144734] text-[#d6fff0]'
                        : 'border-[#5ef2bc]/75 bg-[#12382a] text-[#a8ffe0] hover:bg-[#194f3b]'
                    }`}
                  >
                    {gameMode === 'pet_taming'
                      ? 'প্রাণী বশ মোড নির্বাচিত আছে'
                      : 'প্রাণী বশ মোড নির্বাচন করুন'}
                  </button>
                </div>
              )}
            </div>
          )}

          {activePanel === 'map' && (
            <div className="pointer-events-auto fixed left-[max(0.75rem,env(safe-area-inset-left))] top-1/2 z-40 max-h-[calc(100dvh-6rem-env(safe-area-inset-top)-env(safe-area-inset-bottom))] w-[min(240px,calc(100vw-1.5rem-env(safe-area-inset-left)-env(safe-area-inset-right)))] -translate-y-1/2 overflow-y-auto rounded-xl border border-[#f5c763]/55 bg-[#1a110c]/95 p-4 shadow-[0_14px_36px_rgba(0,0,0,0.72)] md:static md:translate-y-0">
              <div className="mb-2 flex items-center justify-between">
                <span className="font-bengali-ui text-sm font-bold text-[#ffd978]">
                  ম্যাপ: বাংলা
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="text-xs font-bold text-[#ccb38e] hover:text-white"
                >
                  ✕
                </button>
              </div>
              <div className="font-bengali-display text-sm font-bold text-[#fff1d0]">
                হুগলি তীর · পশ্চিমবঙ্গ
              </div>
              <p className="font-bengali-ui mt-1 text-[11px] leading-relaxed text-[#d7be98]">
                হাওড়া ব্রিজের পটভূমিতে বাংলার মাটির গ্রাম, যোদ্ধা সিন্দুক, সঞ্জীবনী গাছ ও কালবৈশাখী বলয়ের মাঝে সার্ভাইভাল যুদ্ধ।
              </p>
              <div className="font-bengali-ui mt-2 text-[10px] font-semibold text-[#ffe08f]">
                হাওড়া সেতু · যোদ্ধা সিন্দুক · সঞ্জীবনী গাছ · কালবৈশাখী বলয়
              </div>
            </div>
          )}

          {/* ভল্ট / পোশাক (Vault / Dress — Live 3D Outfit & Gamcha Changing) */}
          {activePanel === 'vault' && (
            <div className="pointer-events-auto fixed left-[max(0.65rem,env(safe-area-inset-left))] top-[calc(4.15rem+env(safe-area-inset-top))] bottom-[calc(3.65rem+env(safe-area-inset-bottom))] z-40 w-[min(284px,calc(49vw-0.75rem))] overflow-y-auto rounded-xl border border-[#f5c763]/55 bg-[#19100b]/96 p-3.5 shadow-[0_14px_38px_rgba(0,0,0,0.78)] sm:p-4 lg:static lg:top-auto lg:bottom-auto lg:max-h-[calc(100dvh-11rem)] lg:w-[300px]">
              <div className="mb-1.5 flex items-center justify-between gap-2">
                <span className="font-bengali-ui text-sm font-bold text-[#ffd978]">
                  ভল্ট · পোশাক নির্বাচন
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="flex h-7 w-7 items-center justify-center rounded-md text-xs font-bold text-[#ccb38e] hover:bg-white/10 hover:text-white"
                >
                  ✕
                </button>
              </div>
              <p className="font-bengali-ui mb-2.5 text-[10px] leading-snug text-[#d4bc97]">
                পোশাক বাছুন — কেন্দ্রে ৩ডি চরিত্রে তাৎক্ষণিক পরিবর্তন দেখুন
              </p>

              <div className="grid grid-cols-2 gap-1.5">
                {HERO_OUTFIT_ORDER.map((id) => {
                  const outfit = HERO_OUTFIT_CATALOG[id];
                  const equipped = heroOutfit === id;
                  return (
                    <button
                      key={id}
                      type="button"
                      onClick={() => onSelectOutfit(id)}
                      className={`flex flex-col rounded-lg border p-2 text-left transition-colors active:scale-[0.98] ${
                        equipped
                          ? 'border-[#ffd24c] bg-[#332011] text-[#fff6e3]'
                          : 'border-[#e8bc6a]/25 bg-[#22160f] text-[#e0cca9] hover:border-[#e8bc6a]/55 hover:bg-[#2b1c13]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1.5">
                        <span className="flex h-6 w-9 shrink-0 overflow-hidden rounded border border-white/25">
                          <span
                            style={{ backgroundColor: outfit.swatchTop }}
                            className="h-full w-1/2"
                          />
                          <span
                            style={{ backgroundColor: outfit.swatchBottom }}
                            className="h-full w-1/3"
                          />
                          <span
                            style={{ backgroundColor: outfit.swatchAccent }}
                            className="h-full w-1/6"
                          />
                        </span>
                        {equipped && (
                          <span className="font-bengali-ui text-[9px] font-bold text-[#ffd86b]">
                            পরা আছে
                          </span>
                        )}
                      </div>
                      <div className="font-bengali-ui mt-1.5 truncate text-[11px] font-bold leading-tight">
                        {outfit.nameBn}
                      </div>
                      <div className="font-bengali-ui truncate text-[9px] text-[#c7ae87]">
                        {outfit.subtitleBn}
                      </div>
                    </button>
                  );
                })}
              </div>

              <div className="mt-3 border-t border-[#f0c268]/20 pt-2.5">
                <div className="font-bengali-ui mb-1.5 text-[11px] font-bold text-[#f2d69f]">
                  গামছার রঙ
                </div>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => onSelectGamcha('red-white')}
                    className={`flex items-center gap-2 rounded-lg border px-2.5 py-1.5 text-left transition-colors ${
                      gamchaStyle === 'red-white'
                        ? 'border-[#ffd24c] bg-[#361813] text-[#fff6e3]'
                        : 'border-[#e8bc6a]/25 bg-[#22160f] text-[#dfcaa8] hover:bg-[#2c1c13]'
                    }`}
                  >
                    <span className="flex h-5 w-5 shrink-0 overflow-hidden rounded border border-[#fff2d9]/60">
                      <span className="h-full w-1/2 bg-[#c81f26]" />
                      <span className="h-full w-1/2 bg-[#faf3e6]" />
                    </span>
                    <span className="font-bengali-ui truncate text-[10px] font-bold">
                      লাল-সাদা
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onSelectGamcha('green-white')}
                    className={`flex items-center gap-2 rounded-lg border px-2.5 py-1.5 text-left transition-colors ${
                      gamchaStyle === 'green-white'
                        ? 'border-[#ffd24c] bg-[#16301d] text-[#fff6e3]'
                        : 'border-[#e8bc6a]/25 bg-[#22160f] text-[#dfcaa8] hover:bg-[#2c1c13]'
                    }`}
                  >
                    <span className="flex h-5 w-5 shrink-0 overflow-hidden rounded border border-[#fff2d9]/60">
                      <span className="h-full w-1/2 bg-[#1c7c3e]" />
                      <span className="h-full w-1/2 bg-[#faf3e6]" />
                    </span>
                    <span className="font-bengali-ui truncate text-[10px] font-bold">
                      সবুজ-সাদা
                    </span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* প্রিসেট (Preset — 3 Saved Loadouts with 1-Tap Apply & Save Current) */}
          {activePanel === 'preset' && (
            <div className="pointer-events-auto fixed left-[max(0.65rem,env(safe-area-inset-left))] top-[calc(4.15rem+env(safe-area-inset-top))] bottom-[calc(3.65rem+env(safe-area-inset-bottom))] z-40 w-[min(284px,calc(49vw-0.75rem))] overflow-y-auto rounded-xl border border-[#f5c763]/55 bg-[#19100b]/96 p-3.5 shadow-[0_14px_38px_rgba(0,0,0,0.78)] sm:p-4 lg:static lg:top-auto lg:bottom-auto lg:max-h-[calc(100dvh-11rem)] lg:w-[300px]">
              <div className="mb-1.5 flex items-center justify-between gap-2">
                <span className="font-bengali-ui text-sm font-bold text-[#ffd978]">
                  প্রিসেট · সংরক্ষিত লোডআউট
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="flex h-7 w-7 items-center justify-center rounded-md text-xs font-bold text-[#ccb38e] hover:bg-white/10 hover:text-white"
                >
                  ✕
                </button>
              </div>
              <p className="font-bengali-ui mb-2.5 text-[10px] leading-snug text-[#d4bc97]">
                বর্তমান: {HERO_OUTFIT_CATALOG[heroOutfit].nameBn} · {WEAPON_CATALOG[weaponType].shortName} ·{' '}
                {gameMode === 'pet_taming' ? 'প্রাণী বশ' : 'সার্ভাইভাল'}
              </p>

              <div className="flex flex-col gap-2">
                {presets.map((preset) => {
                  const outfitMeta = HERO_OUTFIT_CATALOG[preset.outfit];
                  const weaponMeta = WEAPON_CATALOG[preset.weaponType];
                  const isActiveMatch =
                    preset.outfit === heroOutfit &&
                    preset.gamchaStyle === gamchaStyle &&
                    preset.weaponType === weaponType &&
                    preset.gameMode === gameMode;
                  const justSaved = savedPresetSlot === preset.slot;

                  return (
                    <div
                      key={preset.id}
                      className={`rounded-lg border p-2.5 transition-colors ${
                        isActiveMatch
                          ? 'border-[#ffd24c] bg-[#302012]'
                          : 'border-[#e8bc6a]/25 bg-[#22160f]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex min-w-0 items-center gap-2">
                          <span className="flex h-6 w-6 shrink-0 overflow-hidden rounded border border-white/25">
                            <span
                              style={{ backgroundColor: outfitMeta.swatchTop }}
                              className="h-full w-1/2"
                            />
                            <span
                              style={{ backgroundColor: outfitMeta.swatchBottom }}
                              className="h-full w-1/2"
                            />
                          </span>
                          <div className="min-w-0">
                            <div className="font-bengali-ui truncate text-xs font-bold text-[#fff3da]">
                              {toBengaliNumber(preset.slot)}. {preset.nameBn}
                            </div>
                            <div className="font-bengali-ui truncate text-[9.5px] text-[#cbb38e]">
                              {outfitMeta.nameBn} · {weaponMeta.shortName} ·{' '}
                              {preset.gameMode === 'pet_taming' ? 'প্রাণী বশ' : 'সার্ভাইভাল'}
                            </div>
                          </div>
                        </div>
                        {isActiveMatch && (
                          <span className="font-bengali-ui shrink-0 text-[9.5px] font-bold text-[#ffd86b]">
                            চালু
                          </span>
                        )}
                      </div>

                      <div className="mt-2 flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => onApplyPreset(preset)}
                          className="font-bengali-ui flex-1 whitespace-nowrap rounded-md border border-[#ffd873]/70 bg-gradient-to-b from-[#e09d18] to-[#b86d0a] px-2.5 py-1.5 text-[10.5px] font-extrabold text-[#1f1004] transition-all hover:brightness-110 active:scale-95"
                        >
                          প্রয়োগ করুন
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            onSavePreset(preset.slot);
                            setSavedPresetSlot(preset.slot);
                            window.setTimeout(() => {
                              setSavedPresetSlot((cur) => (cur === preset.slot ? null : cur));
                            }, 1400);
                          }}
                          className="font-bengali-ui whitespace-nowrap rounded-md border border-[#e8bc6a]/40 bg-[#18100b] px-2.5 py-1.5 text-[10.5px] font-bold text-[#f0d8b0] transition-colors hover:border-[#ffd262] hover:bg-[#2a1c12] active:scale-95"
                        >
                          {justSaved ? 'সেভ হয়েছে' : 'সেভ করুন'}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ল্যাব (Lab — Upgrades Hub & Game Systems Reference) */}
          {activePanel === 'lab' && (
            <div className="pointer-events-auto fixed left-[max(0.65rem,env(safe-area-inset-left))] top-[calc(4.15rem+env(safe-area-inset-top))] bottom-[calc(3.65rem+env(safe-area-inset-bottom))] z-40 w-[min(292px,calc(50vw-0.75rem))] overflow-y-auto rounded-xl border border-[#f5c763]/55 bg-[#19100b]/96 p-3.5 shadow-[0_14px_38px_rgba(0,0,0,0.78)] sm:p-4 lg:static lg:top-auto lg:bottom-auto lg:max-h-[calc(100dvh-11rem)] lg:w-[308px]">
              <div className="mb-2 flex items-center justify-between gap-2">
                <span className="font-bengali-ui text-sm font-bold text-[#ffd978]">
                  ল্যাব · আপগ্রেড ও সিস্টেম
                </span>
                <button
                  type="button"
                  onClick={() => setActivePanel(null)}
                  aria-label="বন্ধ করুন"
                  className="flex h-7 w-7 items-center justify-center rounded-md text-xs font-bold text-[#ccb38e] hover:bg-white/10 hover:text-white"
                >
                  ✕
                </button>
              </div>

              {/* Live Upgrade Overview */}
              <div className="space-y-2 border-b border-[#f0c268]/20 pb-3">
                <div className="flex items-baseline justify-between gap-2 text-xs">
                  <span className="font-bengali-ui font-bold text-[#ffe6a3]">খেলোয়াড় (ভানু)</span>
                  <span className="font-bengali-ui tabular-nums text-[11px] font-semibold text-[#e8cfa5]">
                    LV {toBengaliNumber(playerLevel)}/{toBengaliNumber(playerMaxLevel)} · স্বাস্থ্য{' '}
                    {toBengaliNumber(playerMaxHealth)} · ক্ষতি +{toBengaliNumber(weaponDamageBonusPct)}%
                  </span>
                </div>

                <div className="flex items-baseline justify-between gap-2 text-xs">
                  <span className="font-bengali-ui font-bold text-[#8cffd4]">পোষা সঙ্গী</span>
                  <span className="font-bengali-ui tabular-nums text-[11px] font-semibold text-[#c9eee0]">
                    {permanentPet
                      ? `${permanentPet.nameBn} · স্তর ${toBengaliNumber(petCurLv)}/${toBengaliNumber(PET_MAX_LEVEL)}`
                      : 'বশ করা বাকি'}
                  </span>
                </div>

                <div className="flex items-baseline justify-between gap-2 text-xs">
                  <span className="font-bengali-ui font-bold text-[#ff9bb4]">এনিমেল হার্ট মান</span>
                  <span className="font-bengali-ui tabular-nums text-[11px] font-extrabold text-[#ffe28a]">
                    {toBengaliNumber(animalHearts.totalValue)} ({toBengaliNumber(animalHearts.totalCount)}টি)
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => setActivePanel('animal_heart')}
                  className="font-bengali-ui mt-1 flex w-full items-center justify-center gap-1.5 rounded-lg border border-[#ff9bb2]/80 bg-gradient-to-r from-[#9e1d44] to-[#c43a2b] px-3 py-2 text-xs font-extrabold text-white shadow-[0_4px_14px_rgba(225,65,95,0.35)] transition-all hover:brightness-110 active:scale-95"
                >
                  <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 shrink-0 fill-[#ffd2dc]">
                    <path d="M10 17.2l-1.2-1.1C4.4 12.2 1.8 9.8 1.8 6.8 1.8 4.4 3.6 2.6 6 2.6c1.4 0 2.7.7 3.5 1.8h1c.8-1.1 2.1-1.8 3.5-1.8 2.4 0 4.2 1.8 4.2 4.2 0 3-2.6 5.4-7 9.3L10 17.2z" />
                  </svg>
                  <span>এনিমেল হার্ট লেভেল আপ খুলুন</span>
                </button>
              </div>

              {/* Active Game Systems & Controls Reference */}
              <div className="mt-2.5 space-y-1.5 text-[10.5px] leading-relaxed text-[#dfc7a1]">
                <div className="font-bengali-ui font-bold text-[#ffd978]">সিস্টেম তথ্য</div>
                <p className="font-bengali-ui">
                  <span className="font-bold text-[#ffe6a8]">৪ টিয়ার হার্ট:</span> সাধারণ ১ · দুর্লভ ৫ · মহাকাব্যিক ১৫ · কিংবদন্তি ৫০ (কেবল নির্বাচিত বিশেষ প্রাণীতে ড্রপ)
                </p>
                <p className="font-bengali-ui">
                  <span className="font-bold text-[#ffe6a8]">লেভেল আপ নিয়ম:</span> ম্যাচে অটো লেভেল আপ নেই — লবিতে ১০ → ৩০ → ৫০ ক্রমে ১০০০ স্তর পর্যন্ত উন্নয়ন
                </p>
                <p className="font-bengali-ui">
                  <span className="font-bold text-[#ffe6a8]">বন্যপ্রাণী ও যানবাহন:</span> দূর থেকে তাড়া করে না, আঘাত করলে লড়ে · সাইকেল ও বাইকে দ্রুত ভ্রমণ · সর্বোচ্চ ৪০ শত্রু
                </p>
                <p className="font-bengali-ui border-t border-[#f0c268]/15 pt-1.5 text-[10px] text-[#cbb089]">
                  কন্ট্রোল: ১–৪ অস্ত্র · F সিন্দুক/বাস/বাইক · H সঞ্জীবনী · G বজ্র গোলা · T বশ · রাইট-ক্লিক স্কোপ
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* DEDICATED ANIMAL HEART LEVEL-UP MODAL (Player Level Up + Animal Level Up) */}
      {activePanel === 'animal_heart' && (() => {
        const nextPlayerMaxHp = isPlayerMaxLv
          ? playerMaxHealth
          : computePlayerMaxHealth(playerLevel + 1);
        const nextPlayerDmgBonusPct = isPlayerMaxLv
          ? weaponDamageBonusPct
          : Math.round((computePlayerWeaponDamageMult(playerLevel + 1) - 1) * 100);
        const nextPetStats =
          permanentPet && !isPetMaxLv
            ? computePetStats(permanentPet.species, petCurLv + 1)
            : null;

        return (
          <div
            onClick={() => setActivePanel(null)}
            className="pointer-events-auto fixed inset-0 z-50 flex items-center justify-center bg-[#0d0708]/76 p-3 backdrop-blur-sm sm:p-5"
          >
            <div
              onClick={(e) => e.stopPropagation()}
              className="max-h-[calc(100dvh-2rem-env(safe-area-inset-top)-env(safe-area-inset-bottom))] w-full max-w-[580px] overflow-y-auto rounded-2xl border-2 border-[#ff7b9c]/65 bg-gradient-to-b from-[#231018]/98 via-[#190d12]/98 to-[#140c0a]/98 p-4 shadow-[0_20px_54px_rgba(0,0,0,0.85),0_0_32px_rgba(255,77,121,0.22)] sm:p-5"
            >
              {/* Modal Header */}
              <div className="flex items-center justify-between gap-3 border-b border-[#ff89a6]/25 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-[#ff89a6]/60 bg-[#3a1222] shadow-[0_0_16px_rgba(255,77,121,0.35)]">
                    <svg viewBox="0 0 20 20" className="h-5 w-5 fill-[#ff4d79]">
                      <path d="M10 17.4l-1.3-1.2C4.2 12.1 1.6 9.7 1.6 6.6 1.6 4.1 3.5 2.3 6 2.3c1.4 0 2.7.7 3.5 1.8h1c.8-1.1 2.1-1.8 3.5-1.8 2.5 0 4.4 1.8 4.4 4.3 0 3.1-2.6 5.5-7.1 9.6L10 17.4z" />
                    </svg>
                  </div>
                  <div>
                    <h2 className="font-bengali-display text-base font-extrabold text-[#ffe4ec] sm:text-lg">
                      এনিমেল হার্ট · লেভেল আপ
                    </h2>
                    <p className="font-bengali-ui text-[10px] font-medium text-[#e8b8c6] sm:text-[11px]">
                      সংগৃহীত এনিমেল হার্ট খরচ করে খেলোয়াড় বা পোষা প্রাণী লেভেল আপ করুন
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1 rounded-lg border border-[#ffd262]/55 bg-[#2a151d] px-2.5 py-1">
                    <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 shrink-0 fill-[#ff587a]">
                      <path d="M10 17.2l-1.2-1.1C4.4 12.2 1.8 9.8 1.8 6.8 1.8 4.4 3.6 2.6 6 2.6c1.4 0 2.7.7 3.5 1.8h1c.8-1.1 2.1-1.8 3.5-1.8 2.4 0 4.2 1.8 4.2 4.2 0 3-2.6 5.4-7 9.3L10 17.2z" />
                    </svg>
                    <span className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#ffe28a] sm:text-sm">
                      {toBengaliNumber(animalHearts.totalValue)}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActivePanel(null)}
                    aria-label="বন্ধ করুন"
                    className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/15 bg-white/5 text-xs font-bold text-[#e5c2cc] hover:bg-white/15 hover:text-white"
                  >
                    ✕
                  </button>
                </div>
              </div>

              {/* 4-Tier Animal Heart Inventory Breakdown (Common=1, Rare=5, Epic=15, Legendary=50) */}
              <div className="mt-2.5 rounded-xl border border-rose-400/25 bg-black/30 p-2.5">
                <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-4">
                  {ANIMAL_HEART_TIER_ORDER.map((tier) => {
                    const count = animalHearts.tiers[tier] || 0;
                    const tMeta = ANIMAL_HEART_TIERS[tier];
                    const subtotal = count * tMeta.value;
                    const cardStyle: Record<number, { box: string; title: string; dot: string }> = {
                      1: {
                        box: count > 0 ? 'border-rose-400/50 bg-rose-500/15' : 'border-white/10 bg-black/25',
                        title: 'text-[#ffb8c8]',
                        dot: '#ef5368',
                      },
                      2: {
                        box: count > 0 ? 'border-sky-400/55 bg-sky-500/15' : 'border-white/10 bg-black/25',
                        title: 'text-[#9ce3ff]',
                        dot: '#3bb2ff',
                      },
                      3: {
                        box: count > 0 ? 'border-purple-400/55 bg-purple-500/15' : 'border-white/10 bg-black/25',
                        title: 'text-[#e5b3ff]',
                        dot: '#c84dff',
                      },
                      4: {
                        box: count > 0 ? 'border-amber-400/65 bg-amber-500/20' : 'border-white/10 bg-black/25',
                        title: 'text-[#ffe184]',
                        dot: '#ffb829',
                      },
                    };
                    const st = cardStyle[tier];
                    return (
                      <div
                        key={tier}
                        className={`rounded-lg border px-2 py-1.5 ${st.box}`}
                      >
                        <div className="flex items-center justify-between gap-1">
                          <div className="flex min-w-0 items-center gap-1">
                            <svg
                              viewBox="0 0 20 20"
                              style={{ fill: st.dot }}
                              className="h-3 w-3 shrink-0"
                            >
                              <path d="M10 17.2l-1.2-1.1C4.4 12.2 1.8 9.8 1.8 6.8 1.8 4.4 3.6 2.6 6 2.6c1.4 0 2.7.7 3.5 1.8h1c.8-1.1 2.1-1.8 3.5-1.8 2.4 0 4.2 1.8 4.2 4.2 0 3-2.6 5.4-7 9.3L10 17.2z" />
                            </svg>
                            <span className={`font-bengali-ui truncate text-[10px] font-extrabold ${st.title}`}>
                              {tMeta.shortNameBn}
                            </span>
                          </div>
                          <span className="font-bengali-ui tabular-nums text-[9px] font-bold text-white/75">
                            +{toBengaliNumber(tMeta.value)}
                          </span>
                        </div>
                        <div className="mt-1 flex items-baseline justify-between gap-1">
                          <span className="font-bengali-ui tabular-nums text-xs font-extrabold text-white">
                            ×{toBengaliNumber(count)}
                          </span>
                          <span className="font-bengali-ui tabular-nums text-[9px] font-semibold text-[#ffe28a]">
                            মান: {toBengaliNumber(subtotal)}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
                <div className="mt-1.5 flex flex-wrap items-center justify-between gap-1 text-[9px] font-semibold text-[#e6b8c4]/85">
                  <span className="font-bengali-ui">
                    সব টিয়ারের সঞ্চিত মান একত্রে লেভেল আপে খরচ হয় (১০ → ৩০ → ৫০ ...)
                  </span>
                  <span className="font-bengali-ui tabular-nums text-[#ffe28a]">
                    মোট হার্ট: {toBengaliNumber(animalHearts.totalCount)}টি · মোট মান: {toBengaliNumber(animalHearts.totalValue)}
                  </span>
                </div>
              </div>

              {/* TWO LEVEL-UP OPTIONS: Player Level Up + Animal Level Up */}
              <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
                {/* OPTION 1: PLAYER LEVEL UP */}
                <div className="flex flex-col justify-between rounded-xl border border-[#f5c763]/55 bg-gradient-to-b from-[#2b1c0e]/95 to-[#1b120a]/95 p-3.5 shadow-[0_6px_20px_rgba(0,0,0,0.45)]">
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-[#ffd873]/60 bg-[#402612]">
                          <svg viewBox="0 0 24 24" className="h-4.5 w-4.5 fill-none stroke-[#ffd45c] stroke-2">
                            <circle cx="12" cy="7.5" r="3.5" />
                            <path d="M5 20c0-3.8 3.1-6.5 7-6.5s7 2.7 7 6.5" strokeLinecap="round" />
                          </svg>
                        </div>
                        <div>
                          <div className="font-bengali-display text-sm font-extrabold text-[#ffe494]">
                            খেলোয়াড় লেভেল আপ
                          </div>
                          <div className="font-bengali-ui text-[10px] font-bold text-[#f2d09b]">
                            ভানু · LV {toBengaliNumber(playerLevel)}/{toBengaliNumber(playerMaxLevel)}
                          </div>
                        </div>
                      </div>
                      <span
                        className={`font-bengali-ui shrink-0 rounded px-1.5 py-0.5 text-[9px] font-bold ${
                          isPlayerMaxLv
                            ? 'bg-emerald-500/25 text-[#88ffd4]'
                            : canUpgradePlayer
                              ? 'bg-amber-400/25 text-[#ffe68a]'
                              : 'bg-black/40 text-[#d4b68c]'
                        }`}
                      >
                        {isPlayerMaxLv ? 'সর্বোচ্চ' : `${toBengaliNumber(nextPlayerCost)} হার্ট`}
                      </span>
                    </div>

                    <div className="mt-3 grid grid-cols-2 gap-1.5">
                      <div className="rounded-lg border border-amber-300/20 bg-black/35 px-2.5 py-1.5">
                        <div className="font-bengali-ui text-[9px] text-[#d9bc92]">সর্বোচ্চ স্বাস্থ্য</div>
                        <div className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#fff4de]">
                          {toBengaliNumber(playerMaxHealth)}
                          {!isPlayerMaxLv && (
                            <span className="ml-1 text-[10px] font-bold text-[#88ffd4]">
                              +{toBengaliNumber(nextPlayerMaxHp - playerMaxHealth)}
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="rounded-lg border border-amber-300/20 bg-black/35 px-2.5 py-1.5">
                        <div className="font-bengali-ui text-[9px] text-[#d9bc92]">অস্ত্রের ক্ষতি</div>
                        <div className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#ffc57a]">
                          +{toBengaliNumber(weaponDamageBonusPct)}%
                          {!isPlayerMaxLv && (
                            <span className="ml-1 text-[10px] font-bold text-[#ffe27a]">
                              → +{toBengaliNumber(nextPlayerDmgBonusPct)}%
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-3">
                    {!isPlayerMaxLv ? (
                      <button
                        type="button"
                        disabled={!canUpgradePlayer}
                        onClick={onUpgradePlayer}
                        className={`font-bengali-ui w-full rounded-lg border px-3 py-2 text-xs font-extrabold transition-all ${
                          canUpgradePlayer
                            ? 'border-[#fff1a8] bg-gradient-to-r from-[#f0a512] to-[#d9690b] text-[#221004] shadow-[0_4px_14px_rgba(245,175,30,0.45)] hover:brightness-110 active:scale-95'
                            : 'cursor-not-allowed border-white/15 bg-white/5 text-white/45'
                        }`}
                      >
                        {canUpgradePlayer
                          ? `খেলোয়াড় লেভেল আপ → LV ${toBengaliNumber(playerLevel + 1)} (${toBengaliNumber(nextPlayerCost)} হার্ট)`
                          : `আরও ${toBengaliNumber(Math.max(0, nextPlayerCost - animalHearts.totalValue))} এনিমেল হার্ট প্রয়োজন`}
                      </button>
                    ) : (
                      <div className="font-bengali-ui rounded-lg border border-emerald-400/35 bg-emerald-950/45 px-2.5 py-2 text-center text-[11px] font-bold text-[#9effd6]">
                        খেলোয়াড় সর্বোচ্চ লেভেলে পৌঁছেছে!
                      </div>
                    )}
                  </div>
                </div>

                {/* OPTION 2: ANIMAL (PET) LEVEL UP */}
                <div className="flex flex-col justify-between rounded-xl border border-[#5ef2bc]/55 bg-gradient-to-b from-[#102920]/95 to-[#0b1b15]/95 p-3.5 shadow-[0_6px_20px_rgba(0,0,0,0.45)]">
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-[#5ef2bc]/60 bg-[#12382a]">
                          <svg viewBox="0 0 24 24" className="h-4.5 w-4.5 fill-[#5ef2bc]">
                            <circle cx="7.5" cy="8.5" r="2" />
                            <circle cx="12" cy="6.8" r="2" />
                            <circle cx="16.5" cy="8.5" r="2" />
                            <path d="M12 11.4c-3.1 0-5.4 2.1-5.4 4.8 0 1.6 1.4 2.7 3 2.7 1.1 0 1.8-.4 2.4-.4s1.3.4 2.4.4c1.6 0 3-1.1 3-2.7 0-2.7-2.3-4.8-5.4-4.8z" />
                          </svg>
                        </div>
                        <div>
                          <div className="font-bengali-display text-sm font-extrabold text-[#98ffd9]">
                            প্রাণী লেভেল আপ
                          </div>
                          <div className="font-bengali-ui text-[10px] font-bold text-[#b8ebda]">
                            {permanentPet
                              ? `${permanentPet.nameBn} · স্তর ${toBengaliNumber(petCurLv)}/${toBengaliNumber(PET_MAX_LEVEL)}`
                              : 'কোনো স্থায়ী পোষা সঙ্গী নেই'}
                          </div>
                        </div>
                      </div>
                      {permanentPet && (
                        <span
                          className={`font-bengali-ui shrink-0 rounded px-1.5 py-0.5 text-[9px] font-bold ${
                            isPetMaxLv
                              ? 'bg-emerald-500/25 text-[#88ffd4]'
                              : canUpgradePet
                                ? 'bg-rose-500/30 text-[#ffd6e0]'
                                : 'bg-black/40 text-[#a5d6c5]'
                          }`}
                        >
                          {isPetMaxLv ? 'সর্বোচ্চ' : `${toBengaliNumber(nextPetCost)} হার্ট`}
                        </span>
                      )}
                    </div>

                    {permanentPet ? (
                      <div className="mt-3 grid grid-cols-2 gap-1.5">
                        <div className="rounded-lg border border-emerald-300/20 bg-black/35 px-2 py-1">
                          <div className="font-bengali-ui text-[9px] text-[#9fd8c4]">স্বাস্থ্য</div>
                          <div className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#e8fff6]">
                            {toBengaliNumber(permanentPet.stats.maxHp)}
                            {nextPetStats && (
                              <span className="ml-1 text-[9px] font-bold text-[#7fffcb]">
                                +{toBengaliNumber(nextPetStats.maxHp - permanentPet.stats.maxHp)}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="rounded-lg border border-emerald-300/20 bg-black/35 px-2 py-1">
                          <div className="font-bengali-ui text-[9px] text-[#f3cfa0]">আক্রমণ ক্ষতি</div>
                          <div className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#ffe7b3]">
                            {toBengaliNumber(permanentPet.stats.attackDamage)}
                            {nextPetStats && (
                              <span className="ml-1 text-[9px] font-bold text-[#ffd26a]">
                                +{toBengaliNumber(nextPetStats.attackDamage - permanentPet.stats.attackDamage)}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="rounded-lg border border-emerald-300/20 bg-black/35 px-2 py-1">
                          <div className="font-bengali-ui text-[9px] text-[#a7d8f0]">গতি</div>
                          <div className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#dff4ff]">
                            {toBengaliNumber(permanentPet.stats.moveSpeed)}
                            {nextPetStats && (
                              <span className="ml-1 text-[9px] font-bold text-[#7fd8ff]">
                                +{toBengaliNumber(Number((nextPetStats.moveSpeed - permanentPet.stats.moveSpeed).toFixed(1)))}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="rounded-lg border border-emerald-300/20 bg-black/35 px-2 py-1">
                          <div className="font-bengali-ui text-[9px] text-[#d6b8f5]">কুলডাউন</div>
                          <div className="font-bengali-ui tabular-nums text-xs font-extrabold text-[#f2e3ff]">
                            {toBengaliNumber(permanentPet.stats.assistCooldown)} সে.
                            {nextPetStats && nextPetStats.assistCooldown < permanentPet.stats.assistCooldown && (
                              <span className="ml-1 text-[9px] font-bold text-[#c79eff]">
                                -{toBengaliNumber(Number((permanentPet.stats.assistCooldown - nextPetStats.assistCooldown).toFixed(1)))}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="mt-3 rounded-lg border border-emerald-300/20 bg-black/30 p-2.5 text-[11px] leading-relaxed text-[#c6ece0]">
                        <span className="font-bengali-ui">
                          প্রাণী লেভেল আপ করতে আগে <span className="font-bold text-[#88ffd4]">প্রাণী বশ মোডে</span> গিয়ে ১টি স্থায়ী পোষা প্রাণী বশ করুন।
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="mt-3">
                    {permanentPet ? (
                      !isPetMaxLv ? (
                        <button
                          type="button"
                          disabled={!canUpgradePet}
                          onClick={onUpgradePet}
                          className={`font-bengali-ui w-full rounded-lg border px-3 py-2 text-xs font-extrabold transition-all ${
                            canUpgradePet
                              ? 'border-[#ff9bb2] bg-gradient-to-r from-[#c92a55] to-[#e65c3a] text-white shadow-[0_4px_14px_rgba(230,70,95,0.45)] hover:brightness-110 active:scale-95'
                              : 'cursor-not-allowed border-white/15 bg-white/5 text-white/45'
                          }`}
                        >
                          {canUpgradePet
                            ? `প্রাণী লেভেল আপ → স্তর ${toBengaliNumber(petCurLv + 1)} (${toBengaliNumber(nextPetCost)} হার্ট)`
                            : `আরও ${toBengaliNumber(Math.max(0, nextPetCost - animalHearts.totalValue))} এনিমেল হার্ট প্রয়োজন`}
                        </button>
                      ) : (
                        <div className="font-bengali-ui rounded-lg border border-emerald-400/35 bg-emerald-950/45 px-2.5 py-2 text-center text-[11px] font-bold text-[#9effd6]">
                          আপনার পোষা প্রাণী সর্বোচ্চ স্তরে পৌঁছেছে!
                        </div>
                      )
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          onSelectGameMode('pet_taming');
                          setActivePanel(null);
                        }}
                        className="font-bengali-ui w-full rounded-lg border border-[#5ef2bc]/75 bg-[#12382a] px-3 py-2 text-xs font-extrabold text-[#a8ffe0] transition-colors hover:bg-[#194f3b] active:scale-95"
                      >
                        প্রাণী বশ মোড নির্বাচন করুন
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* BOTTOM NAVIGATION BAR STRIP (Lower-Left Dock: Vault/Dress, Weapon, Preset, Lab) */}
      <nav
        aria-label="লবি নিচের মেনু"
        className="pointer-events-auto fixed bottom-[max(0.5rem,env(safe-area-inset-bottom))] left-[max(0.65rem,env(safe-area-inset-left))] z-20 flex items-stretch divide-x divide-[#f0c268]/18 overflow-hidden rounded-xl border border-[#f0c268]/45 bg-[#150e0a]/92 shadow-[0_8px_24px_rgba(0,0,0,0.68)] backdrop-blur-md sm:bottom-[max(0.85rem,env(safe-area-inset-bottom))] sm:left-[max(1.25rem,env(safe-area-inset-left))]"
      >
        {/* 1. ভল্ট / পোশাক (Vault / Dress) */}
        <button
          type="button"
          onClick={() => togglePanel('vault')}
          aria-pressed={activePanel === 'vault'}
          className={`relative flex min-h-[40px] min-w-[66px] flex-col items-center justify-center gap-0.5 px-2.5 py-1.5 transition-colors active:scale-95 sm:min-h-[46px] sm:min-w-[84px] sm:flex-row sm:gap-2 sm:px-3.5 ${
            activePanel === 'vault'
              ? 'bg-gradient-to-t from-[#f5c763]/24 to-[#2e1d10]/85 text-[#ffe79c]'
              : 'text-[#e8d4b5] hover:bg-white/5 hover:text-[#fff3d6]'
          }`}
        >
          <svg
            viewBox="0 0 24 24"
            className={`h-4 w-4 shrink-0 fill-none stroke-2 ${
              activePanel === 'vault' ? 'stroke-[#ffd966]' : 'stroke-[#e0be78]'
            }`}
          >
            <path
              d="M8.5 4.5L5 7.5 7 11l2-1v9.5h6V10l2 1 2-3.5-3.5-3a3.5 3.5 0 0 1-7 0z"
              strokeLinejoin="round"
            />
          </svg>
          <span className="font-bengali-ui whitespace-nowrap text-[10px] font-bold leading-none sm:text-xs">
            ভল্ট
          </span>
          {activePanel === 'vault' && (
            <span aria-hidden="true" className="absolute inset-x-2 bottom-0 h-[2px] rounded-t bg-[#ffd24c]" />
          )}
        </button>

        {/* 2. অস্ত্র (Weapon) */}
        <button
          type="button"
          onClick={() => togglePanel('weapon')}
          aria-pressed={activePanel === 'weapon'}
          className={`relative flex min-h-[40px] min-w-[66px] flex-col items-center justify-center gap-0.5 px-2.5 py-1.5 transition-colors active:scale-95 sm:min-h-[46px] sm:min-w-[84px] sm:flex-row sm:gap-2 sm:px-3.5 ${
            activePanel === 'weapon'
              ? 'bg-gradient-to-t from-[#f5c763]/24 to-[#2e1d10]/85 text-[#ffe79c]'
              : 'text-[#e8d4b5] hover:bg-white/5 hover:text-[#fff3d6]'
          }`}
        >
          <svg
            viewBox="0 0 24 24"
            className={`h-4 w-4 shrink-0 fill-none stroke-2 ${
              activePanel === 'weapon' ? 'stroke-[#ffd966]' : 'stroke-[#e0be78]'
            }`}
          >
            <path d="M3 11h14l4-2v4l-4-1H13l-2 5H8l1-5H5l-2 2v-3z" strokeLinejoin="round" />
          </svg>
          <span className="font-bengali-ui whitespace-nowrap text-[10px] font-bold leading-none sm:text-xs">
            অস্ত্র
          </span>
          {activePanel === 'weapon' && (
            <span aria-hidden="true" className="absolute inset-x-2 bottom-0 h-[2px] rounded-t bg-[#ffd24c]" />
          )}
        </button>

        {/* 3. প্রিসেট (Preset) */}
        <button
          type="button"
          onClick={() => togglePanel('preset')}
          aria-pressed={activePanel === 'preset'}
          className={`relative flex min-h-[40px] min-w-[66px] flex-col items-center justify-center gap-0.5 px-2.5 py-1.5 transition-colors active:scale-95 sm:min-h-[46px] sm:min-w-[84px] sm:flex-row sm:gap-2 sm:px-3.5 ${
            activePanel === 'preset'
              ? 'bg-gradient-to-t from-[#f5c763]/24 to-[#2e1d10]/85 text-[#ffe79c]'
              : 'text-[#e8d4b5] hover:bg-white/5 hover:text-[#fff3d6]'
          }`}
        >
          <svg
            viewBox="0 0 24 24"
            className={`h-4 w-4 shrink-0 fill-none stroke-2 ${
              activePanel === 'preset' ? 'stroke-[#ffd966]' : 'stroke-[#e0be78]'
            }`}
          >
            <rect x="4" y="4" width="16" height="6" rx="1.5" />
            <rect x="4" y="14" width="16" height="6" rx="1.5" />
            <line x1="8" y1="7" x2="12" y2="7" strokeLinecap="round" />
            <line x1="8" y1="17" x2="14" y2="17" strokeLinecap="round" />
          </svg>
          <span className="font-bengali-ui whitespace-nowrap text-[10px] font-bold leading-none sm:text-xs">
            প্রিসেট
          </span>
          {activePanel === 'preset' && (
            <span aria-hidden="true" className="absolute inset-x-2 bottom-0 h-[2px] rounded-t bg-[#ffd24c]" />
          )}
        </button>

        {/* 4. ল্যাব (Lab) */}
        <button
          type="button"
          onClick={() => togglePanel('lab')}
          aria-pressed={activePanel === 'lab'}
          className={`relative flex min-h-[40px] min-w-[66px] flex-col items-center justify-center gap-0.5 px-2.5 py-1.5 transition-colors active:scale-95 sm:min-h-[46px] sm:min-w-[84px] sm:flex-row sm:gap-2 sm:px-3.5 ${
            activePanel === 'lab'
              ? 'bg-gradient-to-t from-[#f5c763]/24 to-[#2e1d10]/85 text-[#ffe79c]'
              : 'text-[#e8d4b5] hover:bg-white/5 hover:text-[#fff3d6]'
          }`}
        >
          <svg
            viewBox="0 0 24 24"
            className={`h-4 w-4 shrink-0 fill-none stroke-2 ${
              activePanel === 'lab' ? 'stroke-[#ffd966]' : 'stroke-[#e0be78]'
            }`}
          >
            <path d="M9 3h6M10 3v5.5L5.2 17a2.5 2.5 0 0 0 2.2 3.7h9.2A2.5 2.5 0 0 0 18.8 17L14 8.5V3" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M8.5 14.5h7" strokeLinecap="round" />
          </svg>
          <span className="font-bengali-ui whitespace-nowrap text-[10px] font-bold leading-none sm:text-xs">
            ল্যাব
          </span>
          {activePanel === 'lab' && (
            <span aria-hidden="true" className="absolute inset-x-2 bottom-0 h-[2px] rounded-t bg-[#ffd24c]" />
          )}
        </button>
      </nav>

      {/* DRAG-TO-ROTATE CUE (Wide Desktop Center Only — Never collides with Bottom Nav or Start CTA) */}
      <div className="pointer-events-none fixed bottom-[max(0.95rem,env(safe-area-inset-bottom))] left-1/2 z-10 hidden -translate-x-1/2 items-center gap-2 text-[11px] font-semibold text-[#f5e1be]/85 drop-shadow xl:flex">
        <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 fill-none stroke-[#ffd05b] stroke-2">
          <path d="M12 5l-5 5 5 5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        <span className="font-bengali-ui whitespace-nowrap">চরিত্র ঘোরাতে টেনে নিন</span>
        <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 fill-none stroke-[#ffd05b] stroke-2">
          <path d="M8 5l5 5-5 5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </div>

      <div className="pointer-events-auto fixed bottom-[max(0.65rem,env(safe-area-inset-bottom))] right-[max(0.65rem,env(safe-area-inset-right))] z-20 flex flex-col items-end gap-1.5 sm:bottom-[max(0.9rem,env(safe-area-inset-bottom))] sm:right-[max(1.25rem,env(safe-area-inset-right))]">
          {/* Mode Selector: Survival Mode vs Separate Pet Taming Mode */}
          <div className="flex items-center gap-1 rounded-xl border border-[#f5c763]/45 bg-[#140d09]/90 p-1 shadow-[0_6px_18px_rgba(0,0,0,0.55)] backdrop-blur-md">
            <button
              type="button"
              onClick={() => onSelectGameMode('survival')}
              className={`font-bengali-ui whitespace-nowrap rounded-lg px-2.5 py-1 text-[11px] font-bold transition-all sm:px-3 sm:py-1.5 sm:text-xs ${
                gameMode === 'survival'
                  ? 'bg-gradient-to-b from-[#ffd952] to-[#d4820a] text-[#241205] shadow-[0_0_12px_rgba(255,196,46,0.45)]'
                  : 'text-[#e5cfa8] hover:bg-white/10 hover:text-[#fff5dd]'
              }`}
            >
              সার্ভাইভাল মোড
            </button>
            <button
              type="button"
              onClick={() => onSelectGameMode('pet_taming')}
              className={`font-bengali-ui flex items-center gap-1 whitespace-nowrap rounded-lg px-2.5 py-1 text-[11px] font-bold transition-all sm:px-3 sm:py-1.5 sm:text-xs ${
                gameMode === 'pet_taming'
                  ? 'bg-gradient-to-b from-[#3ee8a8] to-[#117a53] text-[#052419] shadow-[0_0_14px_rgba(62,232,168,0.5)]'
                  : 'text-[#b5edd8] hover:bg-white/10 hover:text-[#e6fff5]'
              }`}
            >
              <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 shrink-0 fill-current">
                <circle cx="6.2" cy="6.8" r="1.7" />
                <circle cx="10" cy="5.4" r="1.7" />
                <circle cx="13.8" cy="6.8" r="1.7" />
                <path d="M10 9.4c-2.6 0-4.6 1.8-4.6 4.1 0 1.4 1.2 2.3 2.5 2.3 1 0 1.5-.4 2.1-.4s1.1.4 2.1.4c1.3 0 2.5-.9 2.5-2.3 0-2.3-2-4.1-4.6-4.1z" />
              </svg>
              <span>প্রাণী বশ মোড</span>
            </button>
          </div>

          <div className="pr-1 text-[11px] font-semibold text-[#ffe5a3] drop-shadow">
            <span className="font-bengali-ui">
              {gameMode === 'pet_taming'
                ? permanentPet
                  ? `প্রাণী বশ মোড · স্থায়ী সঙ্গী: ${permanentPet.nameBn}`
                  : 'প্রাণী বশ মোড · আজীবনে ১টি স্থায়ী সঙ্গী'
                : 'সার্ভাইভাল মোড · ম্যাপ: বাংলা'}
            </span>
          </div>

          <button
            type="button"
            onClick={onStart}
            className={`font-bengali-display group relative flex items-center gap-2.5 overflow-hidden rounded-xl border-2 px-6 py-3 text-lg font-extrabold tracking-wide transition-transform duration-150 hover:scale-[1.03] hover:brightness-105 active:scale-[0.97] sm:gap-3 sm:px-9 sm:py-4 sm:text-2xl ${
              gameMode === 'pet_taming'
                ? 'border-[#b8ffe4] bg-gradient-to-b from-[#45f0b2] via-[#1cc488] to-[#0d7d56] text-[#052418] shadow-[0_0_28px_rgba(45,230,165,0.68),0_10px_28px_rgba(0,0,0,0.6)]'
                : 'border-[#fff4b8] bg-gradient-to-b from-[#ffe24a] via-[#f7b818] to-[#df8608] text-[#241205] shadow-[0_0_28px_rgba(255,194,32,0.72),0_10px_28px_rgba(0,0,0,0.6)]'
            }`}
          >
            <span className="pointer-events-none absolute -left-8 top-0 h-full w-16 -skew-x-20 bg-white/25 transition-transform duration-300 group-hover:translate-x-56" />
            <span className="relative whitespace-nowrap">
              {gameMode === 'pet_taming' ? 'শিকার ও বশ শুরু' : 'খেলা শুরু করুন'}
            </span>
            <svg
              viewBox="0 0 24 24"
              className="relative h-5 w-5 fill-current transition-transform duration-150 group-hover:translate-x-1 sm:h-6 sm:w-6"
            >
              <path d="M8 5v14l11-7z" />
            </svg>
          </button>
      </div>
    </div>
  );
};
