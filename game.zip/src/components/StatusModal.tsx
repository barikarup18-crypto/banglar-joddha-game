import React from 'react';
import { toBengaliNumber } from '../game/GameEngine';
import { HudSnapshot } from '../game/types';

interface StatusModalProps {
  hud: HudSnapshot;
  onResume: () => void;
  onRestart: () => void;
  onMainMenu: () => void;
}

export const StatusModal: React.FC<StatusModalProps> = ({
  hud,
  onResume,
  onRestart,
  onMainMenu,
}) => {
  if (hud.phase !== 'paused' && hud.phase !== 'gameover') return null;

  const isGameOver = hud.phase === 'gameover';
  const totalShotsHit = hud.headshots + hud.bodyshots;
  const headshotRate =
    totalShotsHit > 0 ? Math.round((hud.headshots / totalShotsHit) * 100) : 0;

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center overflow-y-auto bg-[#120b08]/84 pb-[max(1rem,env(safe-area-inset-bottom))] pl-[max(1rem,env(safe-area-inset-left))] pr-[max(1rem,env(safe-area-inset-right))] pt-[max(1rem,env(safe-area-inset-top))]">
      <div className="my-auto w-full max-w-md rounded-2xl border border-[#e8ba68]/55 bg-[#20140e] p-5 text-center shadow-[0_20px_60px_rgba(0,0,0,0.75)] sm:p-6">
        {/* Gamcha decorative top trim */}
        <div className="mx-auto mb-3 flex h-1.5 w-32 overflow-hidden rounded-full border border-[#5e2418]">
          <div className="flex-1 bg-[#c41e25]" />
          <div className="flex-1 bg-[#faf2e3]" />
          <div className="flex-1 bg-[#c41e25]" />
          <div className="flex-1 bg-[#faf2e3]" />
          <div className="flex-1 bg-[#c41e25]" />
        </div>

        <h2 className="font-bengali-display text-2xl font-bold text-[#ffd87d] sm:text-3xl">
          {isGameOver ? 'খেলা শেষ' : 'খেলা বিরতি'}
        </h2>
        <p className="font-bengali-ui mt-1 text-xs text-[#e3cbb0] sm:text-sm">
          {isGameOver
            ? 'হুগলির তীর রক্ষায় আপনি বীরত্বের সাথে লড়েছেন!'
            : 'আবার যুদ্ধ শুরু করতে প্রস্তুত?'}
        </p>

        {/* Primary Stats Grid */}
        <div className="mt-4 grid grid-cols-3 gap-2 rounded-xl border border-[#e7b96b]/25 bg-[#150d09] p-3">
          <div>
            <div className="font-bengali-ui text-xs text-[#c7a882]">স্কোর</div>
            <div className="font-bengali-ui tabular-nums mt-0.5 text-lg font-bold text-[#ffe296] sm:text-xl">
              {toBengaliNumber(hud.score)}
            </div>
          </div>
          <div>
            <div className="font-bengali-ui text-xs text-[#c7a882]">তরঙ্গ</div>
            <div className="font-bengali-ui tabular-nums mt-0.5 text-lg font-bold text-[#f9ebd4] sm:text-xl">
              {toBengaliNumber(hud.wave)}
            </div>
          </div>
          <div>
            <div className="font-bengali-ui text-xs text-[#c7a882]">পরাজিত শত্রু</div>
            <div className="font-bengali-ui tabular-nums mt-0.5 text-lg font-bold text-[#ff846e] sm:text-xl">
              {toBengaliNumber(hud.kills)}
            </div>
          </div>
        </div>

        {/* Headshot & Body Shot Breakdown */}
        <div className="mt-2 grid grid-cols-2 gap-2 rounded-xl border border-[#e7b96b]/22 bg-[#170f0a] px-3 py-2">
          <div className="flex flex-col items-center">
            <div className="font-bengali-ui text-xs font-semibold text-[#ff7c75]">মোট হেডশট</div>
            <div className="font-bengali-ui tabular-nums mt-0.5 text-lg font-extrabold text-[#ff4b4b] sm:text-xl">
              {toBengaliNumber(hud.headshots)}
            </div>
          </div>
          <div className="flex flex-col items-center border-l border-[#e7b96b]/20">
            <div className="font-bengali-ui text-xs font-semibold text-[#f3cf7c]">মোট বডিশট</div>
            <div className="font-bengali-ui tabular-nums mt-0.5 text-lg font-extrabold text-[#ffe9b3] sm:text-xl">
              {toBengaliNumber(hud.bodyshots)}
            </div>
          </div>
        </div>

        {isGameOver && (hud.highScore > 0 || totalShotsHit > 0) && (
          <div className="mt-3 flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-xs font-semibold text-[#e6c48a]">
            {hud.highScore > 0 && (
              <span>
                সেরা স্কোর:{' '}
                <span className="tabular-nums text-[#ffd26a]">{toBengaliNumber(hud.highScore)}</span>
              </span>
            )}
            {totalShotsHit > 0 && (
              <span>
                হেডশট হার:{' '}
                <span className="tabular-nums text-[#ff8e88]">{toBengaliNumber(headshotRate)}%</span>
              </span>
            )}
          </div>
        )}

        {/* Action Buttons */}
        <div className="mt-4 flex flex-col gap-2">
          {!isGameOver ? (
            <button
              type="button"
              onClick={onResume}
              className="font-bengali-ui w-full rounded-xl border border-[#ffe199] bg-[#c42027] py-2.5 text-base font-bold text-[#fff6e6] shadow hover:bg-[#d6262e]"
            >
              খেলা চালিয়ে যান
            </button>
          ) : (
            <button
              type="button"
              onClick={onRestart}
              className="font-bengali-ui w-full rounded-xl border border-[#ffe199] bg-[#c42027] py-2.5 text-base font-bold text-[#fff6e6] shadow hover:bg-[#d6262e]"
            >
              আবার খেলুন
            </button>
          )}

          {!isGameOver && (
            <button
              type="button"
              onClick={onRestart}
              className="font-bengali-ui w-full rounded-xl border border-[#e7b96b]/45 bg-[#2e1e15] py-2 text-sm font-semibold text-[#f8e6c8] hover:bg-[#3d291d]"
            >
              নতুন করে শুরু করুন
            </button>
          )}

          <button
            type="button"
            onClick={onMainMenu}
            className="font-bengali-ui w-full rounded-xl border border-[#e7b96b]/30 bg-transparent py-2 text-sm font-semibold text-[#d9bfa0] hover:bg-[#2a1b13]"
          >
            মূল মেনু
          </button>
        </div>
      </div>
    </div>
  );
};
