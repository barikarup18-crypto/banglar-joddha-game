import React from 'react';
import { toBengaliNumber } from '../game/GameEngine';
import { HudSnapshot } from '../game/types';

interface StatusModalProps {
  hud: HudSnapshot;
  onResume: () => void;
  onRestart: () => void;
  onMainMenu: () => void;
}

export const StatusModal: React.FC<StatusModalProps> = ({
  hud,
  onResume,
  onRestart,
  onMainMenu,
}) => {
  if (hud.phase !== 'paused' && hud.phase !== 'gameover') return null;

  const isGameOver = hud.phase === 'gameover';
  const totalShotsHit = hud.headshots + hud.bodyshots;
  const headshotRate =
    totalShotsHit > 0 ? Math.round((hud.headshots / totalShotsHit) * 100) : 0;

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center overflow-y-auto bg-[#0a0b09]/88 pb-[max(1rem,env(safe-area-inset-bottom))] pl-[max(1rem,env(safe-area-inset-left))] pr-[max(1rem,env(safe-area-inset-right))] pt-[max(1rem,env(safe-area-inset-top))]">
      <div className="my-auto w-full max-w-md rounded-xl border border-[#b59c6b]/50 bg-[#141512] p-5 text-center shadow-[0_22px_60px_rgba(0,0,0,0.85)] sm:p-6">
        {/* App Emblem & Gamcha decorative top trim */}
        <div className="mx-auto mb-2.5 h-12 w-12 overflow-hidden rounded-lg border border-[#b59c6b]/70 bg-[#111312] shadow-[0_6px_16px_rgba(0,0,0,0.65)]">
          <img
            src="./assets/app-logo.png"
            alt="বাংলার যোদ্ধা"
            draggable={false}
            className="h-full w-full scale-[1.28] object-cover"
          />
        </div>
        <div className="mx-auto mb-2.5 flex h-1.5 w-32 overflow-hidden rounded-sm border border-[#4a261f]">
          <div className="flex-1 bg-[#9c2426]" />
          <div className="flex-1 bg-[#e6dfd1]" />
          <div className="flex-1 bg-[#9c2426]" />
          <div className="flex-1 bg-[#e6dfd1]" />
          <div className="flex-1 bg-[#9c2426]" />
        </div>

        <h2
          className={`font-bengali-display text-2xl font-bold sm:text-3xl ${
            hud.matchVictory ? 'text-[#7fffcb]' : 'text-[#ffd87d]'
          }`}
        >
          {isGameOver ? (hud.matchVictory ? 'বিজয়!' : 'খেলা শেষ') : 'খেলা বিরতি'}
        </h2>
        <p className="font-bengali-ui mt-1 text-xs text-[#e3cbb0] sm:text-sm">
          {isGameOver
            ? hud.matchVictory
              ? `অভিনন্দন! মানচিত্রের সব ${toBengaliNumber(hud.maxMapEnemies)} জন শত্রুকে পরাজিত করেছেন!`
              : 'হুগলির তীর রক্ষায় আপনি বীরত্বের সাথে লড়েছেন!'
            : 'আবার যুদ্ধ শুরু করতে প্রস্তুত?'}
        </p>

        {/* Primary Stats Grid */}
        <div className="mt-4 grid grid-cols-3 gap-2 rounded-lg border border-[#b59c6b]/25 bg-[#0e0f0d] p-3">
          <div>
            <div className="font-bengali-ui text-xs text-[#a79d8a]">স্কোর</div>
            <div className="font-bengali-ui tabular-nums mt-0.5 text-lg font-bold text-[#e2c278] sm:text-xl">
              {toBengaliNumber(hud.score)}
            </div>
          </div>
          <div>
            <div className="font-bengali-ui text-xs text-[#a79d8a]">তরঙ্গ</div>
            <div className="font-bengali-ui tabular-nums mt-0.5 text-lg font-bold text-[#ece6d8] sm:text-xl">
              {toBengaliNumber(hud.wave)}
            </div>
          </div>
          <div>
            <div className="font-bengali-ui text-xs text-[#a79d8a]">পরাজিত শত্রু</div>
            <div className="font-bengali-ui tabular-nums mt-0.5 text-lg font-bold text-[#de7564] sm:text-xl">
              {toBengaliNumber(hud.kills)}
            </div>
          </div>
        </div>

        {/* Headshot & Body Shot Breakdown */}
        <div className="mt-2 grid grid-cols-2 gap-2 rounded-lg border border-[#b59c6b]/22 bg-[#10110f] px-3 py-2">
          <div className="flex flex-col items-center">
            <div className="font-bengali-ui text-xs font-semibold text-[#df7b75]">মোট হেডশট</div>
            <div className="font-bengali-ui tabular-nums mt-0.5 text-lg font-extrabold text-[#d94c4c] sm:text-xl">
              {toBengaliNumber(hud.headshots)}
            </div>
          </div>
          <div className="flex flex-col items-center border-l border-[#b59c6b]/20">
            <div className="font-bengali-ui text-xs font-semibold text-[#d9b870]">মোট বডিশট</div>
            <div className="font-bengali-ui tabular-nums mt-0.5 text-lg font-extrabold text-[#ece0c3] sm:text-xl">
              {toBengaliNumber(hud.bodyshots)}
            </div>
          </div>
        </div>

        {/* Player Level & Animal Heart Summary */}
        <div className="mt-2 flex flex-wrap items-center justify-between gap-2 rounded-lg border border-[#b59c6b]/28 bg-[#10110f] px-3 py-2 text-xs">
          <span className="font-bengali-ui font-bold text-[#ffe27a]">
            ভানু · LV {toBengaliNumber(hud.playerLevel)}
          </span>
          <span className="font-bengali-ui tabular-nums font-bold text-[#ff9bb2]">
            এনিমেল হার্ট: {toBengaliNumber(hud.animalHearts.totalValue)}
          </span>
          <span className="font-bengali-ui text-[#ffb870]">
            স্বাস্থ্য {toBengaliNumber(hud.maxHealth)} · ক্ষতি +{toBengaliNumber(hud.weaponDamageBonusPct)}%
          </span>
        </div>

        {isGameOver && (hud.highScore > 0 || totalShotsHit > 0) && (
          <div className="mt-3 flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-xs font-semibold text-[#e6c48a]">
            {hud.highScore > 0 && (
              <span>
                সেরা স্কোর:{' '}
                <span className="tabular-nums text-[#ffd26a]">{toBengaliNumber(hud.highScore)}</span>
              </span>
            )}
            {totalShotsHit > 0 && (
              <span>
                হেডশট হার:{' '}
                <span className="tabular-nums text-[#ff8e88]">{toBengaliNumber(headshotRate)}%</span>
              </span>
            )}
          </div>
        )}

        {/* Action Buttons */}
        <div className="mt-4 flex flex-col gap-2">
          {!isGameOver ? (
            <button
              type="button"
              onClick={onResume}
              className="font-bengali-ui w-full rounded-lg border border-[#d68c74]/75 bg-gradient-to-b from-[#9e2922] to-[#691813] py-2.5 text-base font-bold text-[#f4ebe0] shadow-[0_6px_16px_rgba(0,0,0,0.55)] hover:brightness-110"
            >
              খেলা চালিয়ে যান
            </button>
          ) : (
            <button
              type="button"
              onClick={onRestart}
              className="font-bengali-ui w-full rounded-lg border border-[#d68c74]/75 bg-gradient-to-b from-[#9e2922] to-[#691813] py-2.5 text-base font-bold text-[#f4ebe0] shadow-[0_6px_16px_rgba(0,0,0,0.55)] hover:brightness-110"
            >
              আবার খেলুন
            </button>
          )}

          {!isGameOver && (
            <button
              type="button"
              onClick={onRestart}
              className="font-bengali-ui w-full rounded-lg border border-[#b59c6b]/40 bg-[#1c1d19] py-2 text-sm font-semibold text-[#e6dfd1] hover:bg-[#262822]"
            >
              নতুন করে শুরু করুন
            </button>
          )}

          <button
            type="button"
            onClick={onMainMenu}
            className="font-bengali-ui w-full rounded-lg border border-[#b59c6b]/25 bg-transparent py-2 text-sm font-semibold text-[#b8ae9b] hover:bg-[#1c1d19]"
          >
            মূল মেনু
          </button>
        </div>
      </div>
    </div>
  );
};
