import React from 'react';
import { toBengaliNumber } from '../game/GameEngine';
import {
  HudSnapshot,
  WEAPON_CATALOG,
  WEAPON_SLOT_ORDER,
  WeaponType,
} from '../game/types';

interface GameHudProps {
  hud: HudSnapshot;
  missionToast?: string | null;
  onPause: () => void;
  onToggleMute: () => void;
  onExitBus: () => void;
  onEnterBus: () => void;
  onBusHorn: () => void;
  onToggleBusCameraView: () => void;
  onSelectWeapon: (weapon: WeaponType) => void;
  onToggleScope: () => void;
  onUseSanjibani: () => void;
  onThrowGrenade: () => void;
  onOpenChest: () => void;
}

function formatStormClock(seconds: number): string {
  const clamped = Math.max(0, Math.ceil(seconds));
  const mins = Math.floor(clamped / 60);
  const secs = clamped % 60;
  const secStr = secs < 10 ? `০${toBengaliNumber(secs)}` : toBengaliNumber(secs);
  return `${toBengaliNumber(mins)}:${secStr}`;
}

export const GameHud: React.FC<GameHudProps> = ({
  hud,
  missionToast,
  onPause,
  onToggleMute,
  onExitBus,
  onEnterBus,
  onBusHorn,
  onToggleBusCameraView,
  onSelectWeapon,
  onToggleScope,
  onUseSanjibani,
  onThrowGrenade,
  onOpenChest,
}) => {
  const healthPct = Math.max(0, Math.min(100, (hud.health / hud.maxHealth) * 100));
  const armorPct = Math.max(0, Math.min(100, (hud.armor / Math.max(1, hud.maxArmor)) * 100));
  const lowHealth = healthPct <= 30;
  const activeMeta = WEAPON_CATALOG[hud.activeWeapon];
  const lowAmmo = !activeMeta.isMelee && hud.ammo <= Math.max(2, Math.floor(hud.maxAmmo * 0.25)) && !hud.isReloading;
  const showSniperScope = hud.scopeActive && hud.activeWeapon === 'trishul' && hud.busMode === 'none';

  const canHeal = !hud.isHealing && hud.sanjibaniCount > 0 && hud.health < hud.maxHealth;
  const canThrowGrenade = hud.grenadeCount > 0;

  const locationBadge = (
    <div className="flex items-center gap-1.5 rounded-xl border border-[#f0c56d]/55 bg-[#1b130d]/90 px-2.5 py-1 text-[#fff3d6] shadow-[0_6px_16px_rgba(0,0,0,0.45)]">
      <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 shrink-0 fill-[#f5c247]">
        <path d="M10 2.2a5.3 5.3 0 0 0-5.3 5.3c0 3.7 4.4 8.8 4.8 9.2a.7.7 0 0 0 1 0c.4-.4 4.8-5.5 4.8-9.2A5.3 5.3 0 0 0 10 2.2zm0 7.2a2 2 0 1 1 0-4 2 2 0 0 1 0 4z" />
      </svg>
      <span className="font-bengali-ui whitespace-nowrap text-[11px] font-bold tracking-wide text-[#ffebb8] sm:text-xs">
        {hud.locationName}
      </span>
    </div>
  );

  const stormBadge = (
    <div
      className={`flex items-center gap-1.5 rounded-xl border px-2.5 py-1 shadow-[0_6px_16px_rgba(0,0,0,0.45)] ${
        hud.outsideStorm
          ? 'border-[#ff6b8a]/85 bg-[#3c0f22]/92 text-[#ffd8e2]'
          : hud.stormShrinking
            ? 'border-[#b982ff]/70 bg-[#1e1233]/90 text-[#e8d6ff]'
            : 'border-[#8f7ef2]/50 bg-[#171226]/86 text-[#dcd5ff]'
      }`}
    >
      <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 shrink-0 fill-none stroke-current stroke-2">
        <circle cx="10" cy="10" r="7.5" strokeDasharray="3 2" />
        <path d="M10.8 5.2L7.5 10.4h2.8L9.2 14.8l3.6-5.2H10l.8-4.4z" className="fill-current" stroke="none" />
      </svg>
      <div className="font-bengali-ui flex items-center gap-1.5 whitespace-nowrap text-[11px] font-bold sm:text-xs">
        {hud.outsideStorm ? (
          <>
            <span>বলয়ের বাইরে!</span>
            <span className="tabular-nums text-[#ffe38a]">
              {toBengaliNumber(hud.outsideStormRemaining)} সে.
            </span>
          </>
        ) : hud.stormShrinking ? (
          <span>কালবৈশাখী বলয় সংকুচিত হচ্ছে</span>
        ) : (
          <>
            <span className="text-[#c8b8ff]">ঝড় আসছে...</span>
            <span className="tabular-nums text-[#fff0a8]">{formatStormClock(hud.stormCountdown)}</span>
          </>
        )}
      </div>
    </div>
  );

  return (
    <div className="pointer-events-none fixed inset-0 z-10 overflow-hidden">
      {/* Kalboishakhi Storm Screen Rim Tint when outside safe circle */}
      {hud.outsideStorm && (
        <div
          style={{
            boxShadow: 'inset 0 0 120px 42px rgba(108, 42, 214, 0.72)',
          }}
          className="pointer-events-none fixed inset-0"
        />
      )}

      {/* Dramatic Swirling Wind-Flash Visual Overlay on Kalboishakhi Storm Teleportation */}
      {hud.stormTeleportFlash > 0.02 && (
        <div
          style={{ opacity: Math.min(1, hud.stormTeleportFlash) }}
          className="pointer-events-none fixed inset-0 z-30 flex items-center justify-center overflow-hidden"
        >
          <div
            style={{
              background:
                'radial-gradient(circle at center, rgba(220, 248, 255, 0.75) 0%, rgba(124, 224, 255, 0.42) 34%, rgba(114, 62, 214, 0.55) 72%, rgba(18, 12, 34, 0.75) 100%)',
            }}
            className="absolute inset-0"
          />
          <svg
            viewBox="0 0 400 400"
            className="storm-vortex-swirl relative h-[120vmax] w-[120vmax]"
          >
            <path
              d="M 200 40 A 160 160 0 0 1 355 240"
              fill="none"
              stroke="#d9f9ff"
              strokeWidth="6"
              strokeLinecap="round"
              strokeOpacity="0.82"
            />
            <path
              d="M 340 200 A 140 140 0 0 1 110 308"
              fill="none"
              stroke="#8ceaff"
              strokeWidth="5"
              strokeLinecap="round"
              strokeOpacity="0.78"
            />
            <path
              d="M 85 180 A 115 115 0 0 1 280 110"
              fill="none"
              stroke="#ffe294"
              strokeWidth="4.5"
              strokeLinecap="round"
              strokeOpacity="0.72"
            />
            <path
              d="M 200 115 A 85 85 0 1 1 128 246"
              fill="none"
              stroke="#d8b8ff"
              strokeWidth="4"
              strokeLinecap="round"
              strokeOpacity="0.85"
            />
          </svg>
        </div>
      )}

      {/* Damage Red Vignette Flash */}
      {hud.damageFlash > 0.02 && (
        <div
          style={{
            opacity: Math.min(0.85, hud.damageFlash),
            boxShadow: 'inset 0 0 110px 36px rgba(196, 20, 24, 0.85)',
          }}
          className="pointer-events-none fixed inset-0"
        />
      )}

      {/* Trishul Sniper Scope Full-Screen Optic Overlay */}
      {showSniperScope && (
        <div className="pointer-events-none fixed inset-0 z-0 flex items-center justify-center">
          <div
            style={{
              background:
                'radial-gradient(circle at center, transparent 0%, transparent 33%, rgba(6, 9, 14, 0.88) 36%, rgba(4, 6, 10, 0.98) 54%)',
            }}
            className="absolute inset-0"
          />
          <svg
            viewBox="0 0 400 400"
            className="relative h-[min(74vmin,540px)] w-[min(74vmin,540px)]"
          >
            <circle cx="200" cy="200" r="184" fill="none" stroke="#9ad4ff" strokeOpacity="0.45" strokeWidth="2" />
            <circle cx="200" cy="200" r="176" fill="none" stroke="#e8c36e" strokeOpacity="0.3" strokeWidth="1" />
            {/* Main Crosshair Axes */}
            <line x1="16" y1="200" x2="188" y2="200" stroke="#e9f4ff" strokeOpacity="0.82" strokeWidth="1.2" />
            <line x1="212" y1="200" x2="384" y2="200" stroke="#e9f4ff" strokeOpacity="0.82" strokeWidth="1.2" />
            <line x1="200" y1="16" x2="200" y2="188" stroke="#e9f4ff" strokeOpacity="0.82" strokeWidth="1.2" />
            <line x1="200" y1="212" x2="200" y2="384" stroke="#e9f4ff" strokeOpacity="0.82" strokeWidth="1.2" />
            {/* Rangefinder Mil-Dots */}
            {[110, 140, 170, 230, 260, 290].map((pos) => (
              <React.Fragment key={pos}>
                <line x1={pos} y1="195" x2={pos} y2="205" stroke="#ffd268" strokeOpacity="0.78" strokeWidth="1.3" />
                <line x1="195" y1={pos} x2="205" y2={pos} stroke="#ffd268" strokeOpacity="0.78" strokeWidth="1.3" />
              </React.Fragment>
            ))}
            {/* Center Precision Dot */}
            <circle cx="200" cy="200" r="2.6" fill="#ff3b3b" />
          </svg>
          <div className="font-bengali-ui absolute bottom-[22%] rounded-md border border-[#7ac6ff]/45 bg-[#0b131d]/86 px-2.5 py-0.5 text-[11px] font-bold text-[#c7e6ff]">
            ত্রিশূল স্কোপ · ৪x জুম
          </div>
        </div>
      )}

      {/* Top Perimeter Status Row */}
      <div className="relative z-10 flex items-start justify-between gap-2 px-2.5 pt-2.5 sm:px-6 sm:pt-4">
        {/* Top-Left: Raksha Kabach Armor Bar + Health ('স্বাস্থ্য') + Wave/Score + Headshot/Bodyshot Badge */}
        <div className="flex min-w-0 flex-col gap-1.5">
          {/* Vitals Card: Blue 50-pt Shield Bar ('রক্ষা কবচ') directly above Red Health Bar ('স্বাস্থ্য') */}
          <div className="w-[158px] rounded-xl border border-[#e7b96b]/45 bg-[#1b120d]/88 px-2.5 py-2 shadow-[0_6px_18px_rgba(0,0,0,0.44)] sm:w-[244px] sm:px-3.5 sm:py-2.5">
            {/* Raksha Kabach Shield Bar */}
            <div className="mb-1.5">
              <div className="mb-0.5 flex items-center justify-between gap-1">
                <div className="flex items-center gap-1">
                  <svg viewBox="0 0 20 20" className="h-3 w-3 shrink-0 fill-[#4db8ff] sm:h-3.5 sm:w-3.5">
                    <path d="M10 2L3.5 4.8v4.7c0 4.1 2.7 7.8 6.5 9 3.8-1.2 6.5-4.9 6.5-9V4.8L10 2z" />
                  </svg>
                  <span className="font-bengali-ui text-[10px] font-bold tracking-wide text-[#a8dcff] sm:text-xs">
                    রক্ষা কবচ
                  </span>
                </div>
                <span className="font-bengali-ui tabular-nums text-[10px] font-bold text-[#8fd1ff] sm:text-xs">
                  {toBengaliNumber(hud.armor)}/{toBengaliNumber(hud.maxArmor)}
                </span>
              </div>
              <div className="h-1.5 w-full overflow-hidden rounded-full bg-[#132538] sm:h-2">
                <div
                  style={{ width: `${armorPct}%` }}
                  className="h-full rounded-full bg-gradient-to-r from-[#1d7ce0] via-[#3aa6ff] to-[#87dbff] transition-[width] duration-150"
                />
              </div>
            </div>

            {/* Health Bar ('স্বাস্থ্য') */}
            <div className="mb-1 flex items-center justify-between gap-1">
              <div className="flex items-center gap-1 sm:gap-1.5">
                <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 shrink-0 fill-[#e03a32] sm:h-4 sm:w-4">
                  <path d="M10 17.5l-1.2-1.1C4.4 12.5 1.8 10.1 1.8 7.1 1.8 4.7 3.7 2.8 6.1 2.8c1.4 0 2.7.7 3.9 1.8 1.2-1.1 2.5-1.8 3.9-1.8 2.4 0 4.3 1.9 4.3 4.3 0 3-2.6 5.4-7 9.3L10 17.5z" />
                </svg>
                <span className="font-bengali-ui text-xs font-bold tracking-wide text-[#fdf1dc] sm:text-sm">
                  স্বাস্থ্য
                </span>
              </div>
              <span
                className={`font-bengali-ui tabular-nums text-xs font-bold sm:text-sm ${
                  lowHealth ? 'text-[#ff6961]' : 'text-[#f8d794]'
                }`}
              >
                {toBengaliNumber(hud.health)}/{toBengaliNumber(hud.maxHealth)}
              </span>
            </div>
            <div className="h-2 w-full overflow-hidden rounded-full bg-[#36231a] sm:h-2.5">
              <div
                style={{ width: `${healthPct}%` }}
                className={`h-full rounded-full transition-[width] duration-150 ${
                  lowHealth ? 'bg-[#e32d2d]' : 'bg-gradient-to-r from-[#c42429] to-[#ef7d3b]'
                }`}
              />
            </div>
          </div>

          {/* Compact Wave / Enemies / Score Bar */}
          <div className="flex flex-wrap items-center gap-1 sm:gap-1.5">
            <div className="rounded-lg border border-[#e7b96b]/35 bg-[#1b120d]/84 px-2 py-0.5 text-[10px] font-semibold text-[#f9e7c8] sm:px-2.5 sm:py-1 sm:text-xs">
              <span className="text-[#d9a85c]">তরঙ্গ </span>
              <span className="tabular-nums font-bold">{toBengaliNumber(hud.wave)}</span>
            </div>
            <div className="rounded-lg border border-[#e7b96b]/35 bg-[#1b120d]/84 px-2 py-0.5 text-[10px] font-semibold text-[#f9e7c8] sm:px-2.5 sm:py-1 sm:text-xs">
              <span className="text-[#e36c5b]">শত্রু </span>
              <span className="tabular-nums font-bold">{toBengaliNumber(hud.enemiesRemaining)}</span>
            </div>
            <div className="rounded-lg border border-[#e7b96b]/35 bg-[#1b120d]/84 px-2 py-0.5 text-[10px] font-semibold text-[#f9e7c8] sm:px-2.5 sm:py-1 sm:text-xs">
              <span className="text-[#f0c563]">স্কোর </span>
              <span className="tabular-nums font-bold">{toBengaliNumber(hud.score)}</span>
            </div>
          </div>

          {/* Live Headshot & Body Shot Counter Badge */}
          <div className="inline-flex w-fit items-center gap-1.5 rounded-lg border border-[#f5c768]/38 bg-[#1b120d]/86 px-2 py-0.5 text-[10px] font-bold shadow-[0_4px_12px_rgba(0,0,0,0.4)] sm:px-2.5 sm:py-1 sm:text-xs">
            <span className="font-bengali-ui text-[#ff6d66]">
              হেডশট: <span className="tabular-nums text-[#ffd8d6]">{toBengaliNumber(hud.headshots)}</span>
            </span>
            <span className="text-[#8e7458]">|</span>
            <span className="font-bengali-ui text-[#f7d277]">
              বডিশট: <span className="tabular-nums text-[#fff3d6]">{toBengaliNumber(hud.bodyshots)}</span>
            </span>
          </div>
        </div>

        {/* Top-Center: Current Bengali Location Badge + Kalboishakhi Storm Timer (Desktop/Tablet) */}
        <div className="hidden md:flex md:flex-col md:items-center md:gap-1.5">
          {locationBadge}
          {hud.busMode !== 'riding_intro' && stormBadge}
        </div>

        {/* Top-Right: Active Weapon + Ammo ('গুলি') OR Bus Speed Badge + Mute & Pause + Mobile Storm Pill */}
        <div className="flex shrink-0 flex-col items-end gap-1.5">
          <div className="flex items-start gap-1.5 sm:gap-2">
            {hud.busMode === 'driving' ? (
              <div className="rounded-xl border border-[#5cb6ff]/55 bg-[#0e1c2b]/88 px-2.5 py-1.5 text-right shadow-[0_6px_18px_rgba(0,0,0,0.45)] sm:px-3.5 sm:py-2">
                <div className="font-bengali-ui text-[10px] font-bold tracking-wide text-[#ffd65c] sm:text-[11px]">
                  WBTC বাস গতি
                </div>
                <div className="font-bengali-ui tabular-nums mt-0.5 text-base font-bold leading-tight text-[#fff7e2] sm:text-lg">
                  {toBengaliNumber(hud.busSpeedKmh)}{' '}
                  <span className="text-[11px] font-semibold text-[#a5d2f7] sm:text-xs">কিমি/ঘ</span>
                </div>
              </div>
            ) : (
              <div className="rounded-xl border border-[#e7b96b]/45 bg-[#1b120d]/88 px-2.5 py-1.5 text-right shadow-[0_6px_18px_rgba(0,0,0,0.44)] sm:px-3.5 sm:py-2">
                <div className="flex items-center justify-end gap-1.5">
                  <span className="font-bengali-ui text-[10px] font-bold text-[#ffd978] sm:text-xs">
                    {activeMeta.shortName}
                  </span>
                  <span className="text-[#8e7458]">·</span>
                  <span className="font-bengali-ui text-[10px] font-bold tracking-wider text-[#f3cb77] sm:text-xs">
                    {activeMeta.isMelee ? 'ছুরি' : 'গুলি'}
                  </span>
                </div>
                {activeMeta.isMelee ? (
                  <div className="font-bengali-ui mt-0.5 text-sm font-bold leading-tight text-[#e3f2ff] sm:text-base">
                    নীরব আঘাত
                  </div>
                ) : hud.isReloading ? (
                  <div className="mt-1 w-20 sm:w-24">
                    <div className="font-bengali-ui text-[10px] font-semibold text-[#ffd67d] sm:text-[11px]">
                      রিলোড হচ্ছে...
                    </div>
                    <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-[#3a291e]">
                      <div
                        style={{ width: `${Math.round(hud.reloadProgress * 100)}%` }}
                        className="h-full bg-[#f5c049]"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="font-bengali-ui tabular-nums mt-0.5 text-base font-bold leading-tight sm:text-lg">
                    <span className={lowAmmo ? 'text-[#ff6961]' : 'text-[#fff5e1]'}>
                      {toBengaliNumber(hud.ammo)}
                    </span>
                    <span className="mx-0.5 text-xs text-[#c7a980] sm:mx-1">/</span>
                    <span className="text-xs text-[#d9bd96] sm:text-sm">
                      {toBengaliNumber(hud.reserveAmmo)}
                    </span>
                  </div>
                )}
              </div>
            )}

            {/* Mute Toggle */}
            <button
              type="button"
              onClick={onToggleMute}
              aria-label={hud.muted ? 'শব্দ চালু করুন' : 'শব্দ বন্ধ করুন'}
              className="pointer-events-auto flex h-9 w-9 items-center justify-center rounded-xl border border-[#e7b96b]/45 bg-[#1b120d]/88 text-[#fdebd0] shadow-[0_4px_14px_rgba(0,0,0,0.4)] hover:bg-[#2b1d15] sm:h-10 sm:w-10"
            >
              {hud.muted ? (
                <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current stroke-2 sm:h-5 sm:w-5">
                  <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                  <line x1="22" y1="9" x2="16" y2="15" strokeLinecap="round" />
                  <line x1="16" y1="9" x2="22" y2="15" strokeLinecap="round" />
                </svg>
              ) : (
                <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current stroke-2 sm:h-5 sm:w-5">
                  <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                  <path d="M15.5 8.5a5 5 0 0 1 0 7" strokeLinecap="round" />
                  <path d="M18.8 5.5a9 9 0 0 1 0 13" strokeLinecap="round" />
                </svg>
              )}
            </button>

            {/* Pause Button */}
            <button
              type="button"
              onClick={onPause}
              aria-label="বিরতি"
              className="pointer-events-auto flex h-9 w-9 items-center justify-center rounded-xl border border-[#e7b96b]/45 bg-[#1b120d]/88 text-[#fdebd0] shadow-[0_4px_14px_rgba(0,0,0,0.4)] hover:bg-[#2b1d15] sm:h-10 sm:w-10"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 fill-current sm:h-5 sm:w-5">
                <rect x="6" y="5" width="4" height="14" rx="1" />
                <rect x="14" y="5" width="4" height="14" rx="1" />
              </svg>
            </button>
          </div>

          {/* Mobile Location Badge + Kalboishakhi Storm Pill neatly stacked under top-right cluster (zero overlap) */}
          <div className="flex flex-col items-end gap-1 md:hidden">
            {locationBadge}
            {hud.busMode !== 'riding_intro' && stormBadge}
          </div>
        </div>
      </div>

      {/* Center Reticle & Hitmarker (when on foot & not zoomed in full sniper optic) */}
      {hud.busMode === 'none' && (
        <div className="pointer-events-none fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className="relative h-9 w-9">
            {!showSniperScope && (
              <>
                <span className="absolute left-1/2 top-0 h-2.5 w-[2px] -translate-x-1/2 bg-[#fff6e2]/90 shadow" />
                <span className="absolute bottom-0 left-1/2 h-2.5 w-[2px] -translate-x-1/2 bg-[#fff6e2]/90 shadow" />
                <span className="absolute left-0 top-1/2 h-[2px] w-2.5 -translate-y-1/2 bg-[#fff6e2]/90 shadow" />
                <span className="absolute right-0 top-1/2 h-[2px] w-2.5 -translate-y-1/2 bg-[#fff6e2]/90 shadow" />
                <span className="absolute left-1/2 top-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#f5c247]" />
              </>
            )}

            {hud.hitMarker > 0.05 && (
              <svg
                viewBox="0 0 36 36"
                style={{ opacity: Math.min(1, hud.hitMarker) }}
                className="absolute inset-0 h-9 w-9"
              >
                <g
                  stroke={
                    hud.hitMarkerHeadshot || hud.hitMarkerKill ? '#ff2a2a' : '#ffe078'
                  }
                  strokeWidth={hud.hitMarkerHeadshot ? 3.4 : hud.hitMarkerKill ? 3 : 2.2}
                  strokeLinecap="round"
                >
                  <line x1="6" y1="6" x2="13" y2="13" />
                  <line x1="30" y1="6" x2="23" y2="13" />
                  <line x1="6" y1="30" x2="13" y2="23" />
                  <line x1="30" y1="30" x2="23" y2="23" />
                </g>
              </svg>
            )}
          </div>
        </div>
      )}

      {/* WBTC INTRO BUS RIDE UI: Route Indicator + Prominent 'বাস থেকে নামুন' (Jump / Exit Bus) Button */}
      {hud.busMode === 'riding_intro' && (
        <>
          <div className="pointer-events-none fixed left-1/2 top-4 hidden -translate-x-1/2 flex-col items-center rounded-xl border border-[#5bb2ff]/55 bg-[#0f1d2e]/88 px-4 py-2 shadow-[0_8px_24px_rgba(0,0,0,0.48)] sm:flex">
            <div className="flex items-center gap-2 text-xs font-bold text-[#ffd85c]">
              <span>WBTC S-12</span>
              <span className="text-[#8fc8f5]">•</span>
              <span className="font-bengali-ui text-[#fff6e3]">{hud.busZoneLabel || 'হাওড়া সেতু'}</span>
              <span className="rounded bg-[#1b4a33] px-1.5 py-0.5 font-bengali-ui text-[10px] font-bold text-[#9cf2be]">
                নিরাপদ অবতরণ
              </span>
            </div>
            <div className="mt-1.5 h-1.5 w-48 overflow-hidden rounded-full bg-[#1e354d]">
              <div
                style={{ width: `${Math.round(hud.busRouteProgress * 100)}%` }}
                className="h-full rounded-full bg-gradient-to-r from-[#2e9bff] via-[#ffd245] to-[#ef5338]"
              />
            </div>
          </div>

          <div className="pointer-events-auto fixed bottom-5 left-1/2 z-30 flex w-max max-w-[94vw] -translate-x-1/2 flex-col items-center gap-2 sm:bottom-7">
            <div className="flex items-center gap-2 rounded-lg border border-[#5bb2ff]/45 bg-[#0f1d2e]/88 px-3 py-1 text-xs font-semibold text-[#dff0ff] sm:hidden">
              <span>{hud.busZoneLabel || 'হাওড়া সেতু'}</span>
              <span className="rounded bg-[#1b4a33] px-1.5 py-0.5 text-[10px] font-bold text-[#9cf2be]">
                নিরাপদ
              </span>
            </div>
            <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3">
              <button
                type="button"
                onClick={onToggleBusCameraView}
                aria-label={hud.busInteriorCam ? 'বাইরের দৃশ্য' : 'ভিতরের দৃশ্য'}
                className="font-bengali-ui flex h-11 items-center gap-1.5 whitespace-nowrap rounded-xl border border-[#7ac4ff]/70 bg-[#102b4a]/92 px-3 text-xs font-bold text-[#e6f4ff] shadow-[0_6px_18px_rgba(0,0,0,0.5)] transition-colors hover:bg-[#194370] active:scale-95 sm:h-12 sm:px-4 sm:text-sm"
              >
                <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-[#ffd85c] stroke-2 sm:h-5 sm:w-5">
                  <path d="M2 12s3.8-6.5 10-6.5S22 12 22 12s-3.8 6.5-10 6.5S2 12 2 12z" />
                  <circle cx="12" cy="12" r="3" />
                </svg>
                <span>{hud.busInteriorCam ? 'বাইরের দৃশ্য' : 'ভিতরের দৃশ্য'}</span>
                <span className="hidden rounded bg-[#0a1d33] px-1.5 py-0.5 text-[10px] font-bold text-[#9fd3ff] sm:inline">
                  V
                </span>
              </button>

              <button
                type="button"
                onClick={onExitBus}
                disabled={hud.busExitSlowing}
                className={`font-bengali-display flex items-center gap-2 whitespace-nowrap rounded-2xl border-2 px-5 py-3 text-base font-extrabold tracking-wide transition-transform sm:gap-2.5 sm:px-8 sm:py-3.5 sm:text-xl ${
                  hud.busExitSlowing
                    ? 'cursor-wait border-[#ffe699] bg-gradient-to-b from-[#d4961a] to-[#9b5908] text-[#fff6dc] shadow-[0_0_22px_rgba(255,180,32,0.55),0_10px_24px_rgba(0,0,0,0.58)]'
                    : 'border-[#fff1b5] bg-gradient-to-b from-[#ffe047] via-[#f5b415] to-[#d97c06] text-[#241205] shadow-[0_0_26px_rgba(255,194,32,0.68),0_10px_28px_rgba(0,0,0,0.58)] hover:scale-[1.03] active:scale-[0.96]'
                }`}
              >
                <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-[2.4] sm:h-6 sm:w-6">
                  <path d="M9 4h8a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H9" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M13 12H3m0 0l4-4m-4 4l4 4" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                <span>{hud.busExitSlowing ? 'বাস থামছে... দরজা খুলছে' : 'বাস থেকে নামুন'}</span>
              </button>

              <button
                type="button"
                onClick={onBusHorn}
                aria-label="হর্ন বাজান"
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-[#5bb2ff]/65 bg-[#123d70]/90 text-[#ffe078] shadow-[0_6px_18px_rgba(0,0,0,0.5)] hover:bg-[#195194] active:scale-95 sm:h-12 sm:w-12"
              >
                <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-2">
                  <path d="M3 14v-4h4l6-4v12l-6-4H3z" strokeLinejoin="round" />
                  <path d="M17 9a4 4 0 0 1 0 6" strokeLinecap="round" />
                  <path d="M19.5 6.5a7.5 7.5 0 0 1 0 11" strokeLinecap="round" />
                </svg>
              </button>
            </div>
            <span className="font-bengali-ui text-center text-[11px] font-semibold text-[#f8e7c5] drop-shadow sm:text-xs">
              পছন্দের জায়গায় সরাসরি নামতে Space / F চাপুন · দৃশ্য বদলাতে V চাপুন
            </span>
          </div>
        </>
      )}

      {/* ON-FOOT CONTEXTUAL INTERACTION ROW ('সিন্দুক খুলুন' & 'বাসে উঠুন') + Sanjibani 3s Healing Progress */}
      {hud.busMode === 'none' && (
        <>
          {(hud.nearChest || hud.nearBus || hud.isHealing) && (
            <div className="pointer-events-none fixed bottom-[228px] left-1/2 z-30 flex w-max max-w-[94vw] -translate-x-1/2 flex-col items-center gap-2 lg:bottom-[92px]">
              {/* 3-Second Sanjibani Healing Channel Progress Bar */}
              {hud.isHealing && (
                <div className="flex w-52 flex-col gap-1 rounded-xl border border-[#5be694]/70 bg-[#0d261a]/92 px-3 py-1.5 shadow-[0_8px_20px_rgba(0,0,0,0.55)]">
                  <div className="flex items-center justify-between text-[11px] font-bold text-[#a8ffd0]">
                    <span className="font-bengali-ui">সঞ্জীবনী নিরাময়...</span>
                    <span className="font-bengali-ui tabular-nums">
                      {toBengaliNumber(Math.round(hud.healProgress * 100))}%
                    </span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-[#19422c]">
                    <div
                      style={{ width: `${Math.round(hud.healProgress * 100)}%` }}
                      className="h-full rounded-full bg-gradient-to-r from-[#24c96b] to-[#8cffb8]"
                    />
                  </div>
                </div>
              )}

              {/* Contextual Action Buttons Row */}
              {(hud.nearChest || hud.nearBus) && (
                <div className="pointer-events-auto flex items-center gap-2">
                  {hud.nearChest && (
                    <button
                      type="button"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        onOpenChest();
                      }}
                      className="font-bengali-display flex items-center gap-1.5 whitespace-nowrap rounded-xl border-2 border-[#ffe794] bg-gradient-to-b from-[#d9931c] to-[#8c4f0a] px-3.5 py-2 text-sm font-extrabold tracking-wide text-[#fff8e6] shadow-[0_0_20px_rgba(245,180,45,0.55),0_8px_20px_rgba(0,0,0,0.55)] transition-transform hover:scale-[1.03] active:scale-95 sm:px-5 sm:py-2.5 sm:text-base"
                    >
                      <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-[#ffe999] stroke-2 sm:h-5 sm:w-5">
                        <rect x="3" y="8" width="18" height="11" rx="2" />
                        <path d="M3 12h18" />
                        <path d="M5 8V6a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v2" />
                        <rect x="10.5" y="10.5" width="3" height="3.5" fill="#ffe999" />
                      </svg>
                      <span>সিন্দুক খুলুন</span>
                      <span className="hidden rounded bg-[#4a2604]/70 px-1.5 py-0.5 text-[11px] font-bold text-[#ffe58c] lg:inline">
                        F
                      </span>
                    </button>
                  )}

                  {hud.nearBus && (
                    <button
                      type="button"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        onEnterBus();
                      }}
                      className="font-bengali-display flex items-center gap-1.5 whitespace-nowrap rounded-xl border-2 border-[#ffe27a] bg-gradient-to-b from-[#1772cc] to-[#0d4a8c] px-3.5 py-2 text-sm font-bold tracking-wide text-[#fff9e8] shadow-[0_0_20px_rgba(30,130,235,0.55),0_8px_20px_rgba(0,0,0,0.55)] transition-transform hover:scale-[1.03] active:scale-95 sm:px-5 sm:py-2.5 sm:text-base"
                    >
                      <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-[#ffe27a] stroke-2 sm:h-5 sm:w-5">
                        <rect x="4" y="5" width="16" height="12" rx="2" />
                        <line x1="4" y1="11" x2="20" y2="11" />
                        <circle cx="8" cy="17" r="1.5" fill="#ffe27a" />
                        <circle cx="16" cy="17" r="1.5" fill="#ffe27a" />
                      </svg>
                      <span>বাসে উঠুন</span>
                      <span className="hidden rounded bg-[#0a2f59] px-1.5 py-0.5 text-[11px] font-bold text-[#ffd85c] lg:inline">
                        F
                      </span>
                    </button>
                  )}
                </div>
              )}
            </div>
          )}

          {/* QUICK-SWITCH WEAPON & TACTICAL CONSUMABLES DOCK
              - On < lg (phones/tablets): cleanly stacked above bottom touch joystick/shoot (bottom-[130px])
              - On lg+ (desktop): single unified horizontal bar centered at bottom-5 */}
          <div className="pointer-events-auto fixed bottom-[130px] left-1/2 z-25 flex w-max max-w-[calc(100vw-16px)] -translate-x-1/2 flex-col-reverse items-center gap-1.5 lg:bottom-5 lg:flex-row lg:gap-2">
            {/* 4 Weapon Quick-Switch Slots */}
            <div className="flex items-center gap-1 rounded-xl border border-[#e7b96b]/40 bg-[#17100c]/88 p-1 shadow-[0_8px_22px_rgba(0,0,0,0.52)] sm:gap-1.5 sm:p-1.5">
              {WEAPON_SLOT_ORDER.map((weaponId) => {
                const meta = WEAPON_CATALOG[weaponId];
                const slotState = hud.weapons[weaponId];
                const selected = hud.activeWeapon === weaponId;
                return (
                  <button
                    key={weaponId}
                    type="button"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      onSelectWeapon(weaponId);
                    }}
                    className={`relative flex min-w-[68px] touch-none flex-col items-start rounded-lg border px-2 py-1 text-left transition-colors sm:min-w-[82px] sm:px-2.5 sm:py-1.5 ${
                      selected
                        ? 'border-[#ffd45c] bg-[#3b2313] text-[#fff6df] shadow-[0_0_12px_rgba(255,204,76,0.35)]'
                        : 'border-[#e7b96b]/22 bg-[#211610]/85 text-[#d7bfa0] hover:bg-[#2d1e15]'
                    }`}
                  >
                    <div className="flex w-full items-center justify-between gap-1">
                      <span
                        className={`font-bengali-ui text-[9px] font-extrabold ${
                          selected ? 'text-[#ffd354]' : 'text-[#9d8568]'
                        }`}
                      >
                        {toBengaliNumber(meta.slot)}
                      </span>
                      <span className="font-bengali-ui tabular-nums text-[9px] font-bold text-[#c7b08d]">
                        {meta.isMelee ? '∞' : toBengaliNumber(slotState.ammo)}
                      </span>
                    </div>
                    <span className="font-bengali-ui mt-0.5 w-full truncate text-[10px] font-bold leading-tight sm:text-[11px]">
                      {meta.shortName}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Tactical Utility Buttons: Sanjibani Herb + Bajra Gola Grenade + Sniper Scope */}
            <div className="flex items-center gap-1.5 rounded-xl border border-[#e7b96b]/38 bg-[#17100c]/88 p-1 shadow-[0_8px_22px_rgba(0,0,0,0.52)] sm:p-1.5">
              {/* সঞ্জীবনী গাছ (Sanjibani Healing Plant) */}
              <button
                type="button"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onUseSanjibani();
                }}
                disabled={!canHeal && !hud.isHealing}
                aria-label="সঞ্জীবনী গাছ ব্যবহার করুন"
                className={`relative flex touch-none items-center gap-1.5 overflow-hidden rounded-lg border px-2.5 py-1.5 transition-colors sm:px-3 ${
                  hud.isHealing
                    ? 'border-[#72ffa9] bg-[#134229] text-[#d6ffe6]'
                    : canHeal
                      ? 'border-[#45d982]/75 bg-[#123321] text-[#d3ffe4] hover:bg-[#19462d] active:scale-95'
                      : 'border-[#45d982]/25 bg-[#1a221d]/75 text-[#87a894]/70'
                }`}
              >
                {hud.isHealing && (
                  <div
                    style={{ width: `${Math.round(hud.healProgress * 100)}%` }}
                    className="pointer-events-none absolute inset-y-0 left-0 bg-[#2be077]/35"
                  />
                )}
                <svg viewBox="0 0 24 24" className="relative h-4 w-4 shrink-0 fill-[#49f08f]">
                  <path d="M17 8C8 10 5.9 16.17 3.82 21.34l1.89.66.95-2.3c.48.17.98.3 1.34.3C19 20 22 3 22 3c-1 2-8 2.25-13 3.25S2 11.5 2 13.5s1.75 3.75 1.75 3.75C7 8 17 8 17 8z" />
                </svg>
                <span className="font-bengali-ui relative whitespace-nowrap text-[10px] font-bold sm:text-xs">
                  সঞ্জীবনী গাছ
                </span>
                <span className="font-bengali-ui tabular-nums relative rounded bg-[#0a2115] px-1.5 py-0.5 text-[10px] font-extrabold text-[#7fffb2]">
                  {toBengaliNumber(hud.sanjibaniCount)}
                </span>
              </button>

              {/* বজ্র গোলা (Bajra Gola Grenade) */}
              <button
                type="button"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onThrowGrenade();
                }}
                disabled={!canThrowGrenade}
                aria-label="বজ্র গোলা নিক্ষেপ করুন"
                className={`flex touch-none items-center gap-1.5 rounded-lg border px-2.5 py-1.5 transition-colors sm:px-3 ${
                  canThrowGrenade
                    ? 'border-[#ff9d47]/75 bg-[#361c10] text-[#ffe5c7] hover:bg-[#4a2614] active:scale-95'
                    : 'border-[#ff9d47]/22 bg-[#211712]/75 text-[#a68c78]/65'
                }`}
              >
                <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-[#ffae52] stroke-2">
                  <circle cx="12" cy="14" r="6" fill="#ff9436" fillOpacity="0.28" />
                  <path d="M10 8V5h4v3" />
                  <path d="M14 5l3-2" strokeLinecap="round" />
                </svg>
                <span className="font-bengali-ui whitespace-nowrap text-[10px] font-bold sm:text-xs">
                  বজ্র গোলা
                </span>
                <span className="font-bengali-ui tabular-nums rounded bg-[#211008] px-1.5 py-0.5 text-[10px] font-extrabold text-[#ffc978]">
                  {toBengaliNumber(hud.grenadeCount)}
                </span>
              </button>

              {/* স্কোপ (Scope Toggle — visible whenever Trishul Sniper is equipped) */}
              {hud.activeWeapon === 'trishul' && (
                <button
                  type="button"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    onToggleScope();
                  }}
                  aria-label="স্কোপ জুম"
                  className={`flex touch-none items-center gap-1.5 rounded-lg border px-2.5 py-1.5 transition-colors active:scale-95 sm:px-3 ${
                    hud.scopeActive
                      ? 'border-[#80dcff] bg-[#114a73] text-[#e6f8ff] shadow-[0_0_12px_rgba(88,200,255,0.45)]'
                      : 'border-[#6cbef5]/65 bg-[#122536] text-[#bfe5ff] hover:bg-[#19354d]'
                  }`}
                >
                  <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-current stroke-2">
                    <circle cx="12" cy="12" r="7" />
                    <line x1="12" y1="2" x2="12" y2="7" />
                    <line x1="12" y1="17" x2="12" y2="22" />
                    <line x1="2" y1="12" x2="7" y2="12" />
                    <line x1="17" y1="12" x2="22" y2="12" />
                  </svg>
                  <span className="font-bengali-ui whitespace-nowrap text-[10px] font-bold sm:text-xs">
                    স্কোপ
                  </span>
                </button>
              )}
            </div>
          </div>
        </>
      )}

      {/* Non-overlapping Top-Center Notification Stack (60s Storm Warning + Wave Banner + Action Toast + Apsara Mission Toast) */}
      {(hud.outsideStorm || hud.waveBanner || hud.pickupToast || missionToast) && (
        <div
          className={`pointer-events-none fixed left-1/2 z-20 flex w-max max-w-[92vw] -translate-x-1/2 flex-col items-center gap-1.5 ${
            hud.busMode === 'riding_intro'
              ? 'top-[96px] sm:top-[104px]'
              : 'top-[132px] md:top-[64px]'
          }`}
        >
          {hud.outsideStorm && (
            <div className="flex flex-col items-center gap-1 rounded-xl border border-[#b98aff]/75 bg-[#24103a]/92 px-3.5 py-1.5 shadow-[0_8px_24px_rgba(0,0,0,0.55)] sm:px-5 sm:py-2">
              <div className="font-bengali-ui text-center text-xs font-bold text-[#ffe599] sm:text-sm">
                কালবৈশাখী ঝড়!{' '}
                <span className="tabular-nums text-[#8cf3ff]">
                  {toBengaliNumber(hud.outsideStormRemaining)}
                </span>{' '}
                সেকেন্ডের মধ্যে সেফ জোনে যান...
              </div>
              <div className="h-1.5 w-44 overflow-hidden rounded-full bg-[#3e225c] sm:w-56">
                <div
                  style={{
                    width: `${Math.max(0, Math.min(100, (hud.outsideStormRemaining / 60) * 100))}%`,
                  }}
                  className="h-full rounded-full bg-gradient-to-r from-[#ff7a90] via-[#ffd76b] to-[#6beeff] transition-[width] duration-200"
                />
              </div>
            </div>
          )}

          {hud.waveBanner && (
            <div className="rounded-xl border border-[#f5c768]/65 bg-[#1d120c]/90 px-4 py-1.5 shadow-[0_8px_28px_rgba(0,0,0,0.48)] sm:px-6 sm:py-2">
              <div className="font-bengali-display text-center text-base font-bold tracking-wide text-[#ffe094] sm:text-2xl">
                {hud.waveBanner}
              </div>
            </div>
          )}

          {missionToast && (
            <div className="rounded-lg border border-[#6ce4ff]/65 bg-[#101c28]/92 px-3.5 py-1 text-center text-xs font-bold text-[#ffe599] shadow-[0_6px_18px_rgba(0,0,0,0.48)] sm:px-4 sm:text-sm">
              {missionToast}
            </div>
          )}

          {hud.pickupToast && (
            <div className="rounded-lg border border-[#e7c06f]/55 bg-[#20160f]/90 px-3.5 py-1 text-center text-xs font-bold text-[#ffebc2] sm:px-4 sm:text-sm">
              {hud.pickupToast}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
