import React from 'react';
import { toBengaliNumber } from '../game/GameEngine';
import { getNextPetUpgradeCost, PET_MAX_LEVEL } from '../game/petSystem';
import { CustomHudLayout } from '../game/settings';
import {
  HudSnapshot,
  WEAPON_CATALOG,
  WEAPON_SLOT_ORDER,
  WeaponType,
} from '../game/types';

interface GameHudProps {
  hud: HudSnapshot;
  customHud: CustomHudLayout;
  missionToast?: string | null;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  onOpenSettings: () => void;
  onPause: () => void;
  onToggleMute: () => void;
  onExitBus: () => void;
  onEnterBus: () => void;
  onMountVehicle: () => void;
  onBusHorn: () => void;
  onToggleBusCameraView: () => void;
  onSelectWeapon: (weapon: WeaponType) => void;
  onToggleScope: () => void;
  onUseSanjibani: () => void;
  onThrowGrenade: () => void;
  onOpenChest: () => void;
  onStartTaming: () => void;
  onUpgradePet: () => void;
}

function formatStormClock(seconds: number): string {
  const clamped = Math.max(0, Math.ceil(seconds));
  const mins = Math.floor(clamped / 60);
  const secs = clamped % 60;
  const secStr = secs < 10 ? `০${toBengaliNumber(secs)}` : toBengaliNumber(secs);
  return `${toBengaliNumber(mins)}:${secStr}`;
}

export const GameHud: React.FC<GameHudProps> = ({
  hud,
  customHud,
  missionToast,
  isFullscreen,
  onToggleFullscreen,
  onOpenSettings,
  onPause,
  onToggleMute,
  onExitBus,
  onEnterBus,
  onMountVehicle,
  onBusHorn,
  onToggleBusCameraView,
  onSelectWeapon,
  onToggleScope,
  onUseSanjibani,
  onThrowGrenade,
  onOpenChest,
  onStartTaming,
  onUpgradePet,
}) => {
  const healthPct = Math.max(0, Math.min(100, (hud.health / hud.maxHealth) * 100));
  const armorPct = Math.max(0, Math.min(100, (hud.armor / Math.max(1, hud.maxArmor)) * 100));
  const lowHealth = healthPct <= 30;
  const activeMeta = WEAPON_CATALOG[hud.activeWeapon];
  const lowAmmo =
    !activeMeta.isMelee &&
    hud.ammo <= Math.max(2, Math.floor(hud.maxAmmo * 0.25)) &&
    !hud.isReloading;
  const isOnFoot = hud.busMode === 'none' && hud.ridingVehicle === null;
  const showSniperScope =
    hud.scopeActive && hud.activeWeapon === 'trishul' && isOnFoot;

  const canHeal = !hud.isHealing && hud.sanjibaniCount > 0 && hud.health < hud.maxHealth;
  const canThrowGrenade = hud.grenadeCount > 0;

  const locationBadge = (
    <div className="flex items-center gap-1.5 rounded-full border border-amber-400/50 bg-black/45 px-3 py-1 text-[#fff3d6] backdrop-blur-md shadow-[0_6px_16px_rgba(0,0,0,0.4)]">
      <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 shrink-0 fill-[#f5c247]">
        <path d="M10 2.2a5.3 5.3 0 0 0-5.3 5.3c0 3.7 4.4 8.8 4.8 9.2a.7.7 0 0 0 1 0c.4-.4 4.8-5.5 4.8-9.2A5.3 5.3 0 0 0 10 2.2zm0 7.2a2 2 0 1 1 0-4 2 2 0 0 1 0 4z" />
      </svg>
      <span className="font-bengali-ui whitespace-nowrap text-[11px] font-bold tracking-wide text-[#ffebb8] sm:text-xs">
        {hud.locationName}
      </span>
    </div>
  );

  const stormBadge = (
    <div
      className={`flex items-center gap-1.5 rounded-full border px-3 py-1 backdrop-blur-md shadow-[0_6px_16px_rgba(0,0,0,0.4)] ${
        hud.outsideStorm
          ? 'border-[#ff6b8a]/80 bg-[#3c0f22]/75 text-[#ffd8e2]'
          : hud.stormShrinking
            ? 'border-[#b982ff]/70 bg-[#1e1233]/70 text-[#e8d6ff]'
            : 'border-amber-400/50 bg-black/45 text-[#e2dbff]'
      }`}
    >
      <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 shrink-0 fill-none stroke-current stroke-2">
        <circle cx="10" cy="10" r="7.5" strokeDasharray="3 2" />
        <path
          d="M10.8 5.2L7.5 10.4h2.8L9.2 14.8l3.6-5.2H10l.8-4.4z"
          className="fill-current"
          stroke="none"
        />
      </svg>
      <div className="font-bengali-ui flex items-center gap-1.5 whitespace-nowrap text-[11px] font-bold sm:text-xs">
        {hud.outsideStorm ? (
          <>
            <span>বলয়ের বাইরে!</span>
            <span className="tabular-nums text-[#ffe38a]">
              {toBengaliNumber(hud.outsideStormRemaining)} সে.
            </span>
          </>
        ) : hud.stormShrinking ? (
          <span>বলয় সংকুচিত হচ্ছে</span>
        ) : (
          <>
            <span className="text-[#d6c9ff]">ঝড়</span>
            <span className="tabular-nums text-[#fff0a8]">
              {formatStormClock(hud.stormCountdown)}
            </span>
          </>
        )}
      </div>
    </div>
  );

  return (
    <div className="pointer-events-none fixed inset-0 z-10 overflow-hidden">
      {/* Kalboishakhi Storm Screen Rim Tint when outside safe circle */}
      {hud.outsideStorm && (
        <div
          style={{
            boxShadow: 'inset 0 0 120px 42px rgba(108, 42, 214, 0.72)',
          }}
          className="pointer-events-none fixed inset-0"
        />
      )}

      {/* Dramatic Swirling Wind-Flash Visual Overlay on Kalboishakhi Storm Teleportation */}
      {hud.stormTeleportFlash > 0.02 && (
        <div
          style={{ opacity: Math.min(1, hud.stormTeleportFlash) }}
          className="pointer-events-none fixed inset-0 z-30 flex items-center justify-center overflow-hidden"
        >
          <div
            style={{
              background:
                'radial-gradient(circle at center, rgba(220, 248, 255, 0.75) 0%, rgba(124, 224, 255, 0.42) 34%, rgba(114, 62, 214, 0.55) 72%, rgba(18, 12, 34, 0.75) 100%)',
            }}
            className="absolute inset-0"
          />
          <svg
            viewBox="0 0 400 400"
            className="storm-vortex-swirl relative h-[120vmax] w-[120vmax]"
          >
            <path
              d="M 200 40 A 160 160 0 0 1 355 240"
              fill="none"
              stroke="#d9f9ff"
              strokeWidth="6"
              strokeLinecap="round"
              strokeOpacity="0.82"
            />
            <path
              d="M 340 200 A 140 140 0 0 1 110 308"
              fill="none"
              stroke="#8ceaff"
              strokeWidth="5"
              strokeLinecap="round"
              strokeOpacity="0.78"
            />
            <path
              d="M 85 180 A 115 115 0 0 1 280 110"
              fill="none"
              stroke="#ffe294"
              strokeWidth="4.5"
              strokeLinecap="round"
              strokeOpacity="0.72"
            />
            <path
              d="M 200 115 A 85 85 0 1 1 128 246"
              fill="none"
              stroke="#d8b8ff"
              strokeWidth="4"
              strokeLinecap="round"
              strokeOpacity="0.85"
            />
          </svg>
        </div>
      )}

      {/* Damage Red Vignette Flash */}
      {hud.damageFlash > 0.02 && (
        <div
          style={{
            opacity: Math.min(0.85, hud.damageFlash),
            boxShadow: 'inset 0 0 110px 36px rgba(196, 20, 24, 0.85)',
          }}
          className="pointer-events-none fixed inset-0"
        />
      )}

      {/* Trishul Sniper Scope Full-Screen Optic Overlay */}
      {showSniperScope && (
        <div className="pointer-events-none fixed inset-0 z-0 flex items-center justify-center">
          <div
            style={{
              background:
                'radial-gradient(circle at center, transparent 0%, transparent 33%, rgba(6, 9, 14, 0.88) 36%, rgba(4, 6, 10, 0.98) 54%)',
            }}
            className="absolute inset-0"
          />
          <svg
            viewBox="0 0 400 400"
            className="relative h-[min(74vmin,540px)] w-[min(74vmin,540px)]"
          >
            <circle
              cx="200"
              cy="200"
              r="184"
              fill="none"
              stroke="#9ad4ff"
              strokeOpacity="0.45"
              strokeWidth="2"
            />
            <circle
              cx="200"
              cy="200"
              r="176"
              fill="none"
              stroke="#e8c36e"
              strokeOpacity="0.3"
              strokeWidth="1"
            />
            <line
              x1="16"
              y1="200"
              x2="188"
              y2="200"
              stroke="#e9f4ff"
              strokeOpacity="0.82"
              strokeWidth="1.2"
            />
            <line
              x1="212"
              y1="200"
              x2="384"
              y2="200"
              stroke="#e9f4ff"
              strokeOpacity="0.82"
              strokeWidth="1.2"
            />
            <line
              x1="200"
              y1="16"
              x2="200"
              y2="188"
              stroke="#e9f4ff"
              strokeOpacity="0.82"
              strokeWidth="1.2"
            />
            <line
              x1="200"
              y1="212"
              x2="200"
              y2="384"
              stroke="#e9f4ff"
              strokeOpacity="0.82"
              strokeWidth="1.2"
            />
            {[110, 140, 170, 230, 260, 290].map((pos) => (
              <React.Fragment key={pos}>
                <line
                  x1={pos}
                  y1="195"
                  x2={pos}
                  y2="205"
                  stroke="#ffd268"
                  strokeOpacity="0.78"
                  strokeWidth="1.3"
                />
                <line
                  x1="195"
                  y1={pos}
                  x2="205"
                  y2={pos}
                  stroke="#ffd268"
                  strokeOpacity="0.78"
                  strokeWidth="1.3"
                />
              </React.Fragment>
            ))}
            <circle cx="200" cy="200" r="2.6" fill="#ff3b3b" />
          </svg>
          <div className="font-bengali-ui absolute bottom-[22%] rounded-full border border-sky-300/50 bg-black/55 px-3 py-1 text-[11px] font-bold text-[#c7e6ff] backdrop-blur-md">
            ত্রিশূল স্কোপ · ৪x জুম
          </div>
        </div>
      )}

      {/* Top Perimeter Status Row — Strict Safe-Area Insets on Both Portrait & Landscape */}
      <div className="relative z-10 flex items-start justify-between gap-2 pl-[max(0.65rem,env(safe-area-inset-left))] pr-[max(0.65rem,env(safe-area-inset-right))] pt-[max(0.55rem,env(safe-area-inset-top))] sm:pl-[max(1.25rem,env(safe-area-inset-left))] sm:pr-[max(1.25rem,env(safe-area-inset-right))] sm:pt-[max(0.75rem,env(safe-area-inset-top))]">
        {/* Top-Left: Vitals Pill + Wave/Enemies/Score Pills + Headshot/Bodyshot Pill */}
        <div className="flex min-w-0 flex-col gap-1 sm:gap-1.5">
          {/* Sleek Translucent Pill Vitals: Raksha Kabach Shield + Health */}
          <div className="w-[146px] rounded-2xl border border-amber-400/50 bg-black/45 px-2.5 py-1.5 backdrop-blur-md shadow-[0_6px_18px_rgba(0,0,0,0.4)] sm:w-[220px] sm:rounded-3xl sm:px-3.5 sm:py-2">
            {/* Raksha Kabach Shield Bar */}
            <div className="mb-1">
              <div className="mb-0.5 flex items-center justify-between gap-1">
                <div className="flex items-center gap-1">
                  <svg viewBox="0 0 20 20" className="h-3 w-3 shrink-0 fill-[#4db8ff] sm:h-3.5 sm:w-3.5">
                    <path d="M10 2L3.5 4.8v4.7c0 4.1 2.7 7.8 6.5 9 3.8-1.2 6.5-4.9 6.5-9V4.8L10 2z" />
                  </svg>
                  <span className="font-bengali-ui text-[10px] font-bold tracking-wide text-[#a8dcff] sm:text-xs">
                    রক্ষা কবচ
                  </span>
                </div>
                <span className="font-bengali-ui tabular-nums text-[10px] font-bold text-[#8fd1ff] sm:text-xs">
                  {toBengaliNumber(hud.armor)}/{toBengaliNumber(hud.maxArmor)}
                </span>
              </div>
              <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/15 sm:h-2">
                <div
                  style={{ width: `${armorPct}%` }}
                  className="h-full rounded-full bg-gradient-to-r from-[#1d7ce0] via-[#3aa6ff] to-[#87dbff] transition-[width] duration-150"
                />
              </div>
            </div>

            {/* Health Bar ('স্বাস্থ্য') */}
            <div className="mb-1 flex items-center justify-between gap-1">
              <div className="flex items-center gap-1 sm:gap-1.5">
                <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 shrink-0 fill-[#e03a32] sm:h-4 sm:w-4">
                  <path d="M10 17.5l-1.2-1.1C4.4 12.5 1.8 10.1 1.8 7.1 1.8 4.7 3.7 2.8 6.1 2.8c1.4 0 2.7.7 3.9 1.8 1.2-1.1 2.5-1.8 3.9-1.8 2.4 0 4.3 1.9 4.3 4.3 0 3-2.6 5.4-7 9.3L10 17.5z" />
                </svg>
                <span className="font-bengali-ui text-xs font-bold tracking-wide text-[#fdf1dc] sm:text-sm">
                  স্বাস্থ্য
                </span>
              </div>
              <span
                className={`font-bengali-ui tabular-nums text-xs font-bold sm:text-sm ${
                  lowHealth ? 'text-[#ff6961]' : 'text-[#f8d794]'
                }`}
              >
                {toBengaliNumber(hud.health)}/{toBengaliNumber(hud.maxHealth)}
              </span>
            </div>
            <div className="h-2 w-full overflow-hidden rounded-full bg-white/15 sm:h-2.5">
              <div
                style={{ width: `${healthPct}%` }}
                className={`h-full rounded-full transition-[width] duration-150 ${
                  lowHealth ? 'bg-[#e32d2d]' : 'bg-gradient-to-r from-[#c42429] to-[#ef7d3b]'
                }`}
              />
            </div>
          </div>

          {/* Sleek Translucent Pill Stat Strip: Survival Mode (Wave/Enemies/Score) vs Pet Taming Mode */}
          {hud.gameMode === 'pet_taming' ? (
            <div className="flex flex-wrap items-center gap-1 sm:gap-1.5">
              <div className="rounded-full border border-emerald-400/65 bg-[#0c261d]/75 px-2.5 py-0.5 text-[10px] font-bold text-[#a8ffe0] backdrop-blur-md sm:px-3 sm:py-1 sm:text-xs">
                <span className="font-bengali-ui">প্রাণী বশ মোড</span>
              </div>
              <div className="inline-flex items-center gap-1 rounded-full border border-rose-400/65 bg-[#2e0e19]/80 px-2.5 py-0.5 text-[10px] font-bold text-[#ffc4d2] backdrop-blur-md sm:px-3 sm:py-1 sm:text-xs">
                <svg viewBox="0 0 20 20" className="h-3 w-3 shrink-0 fill-[#ff587a]">
                  <path d="M10 17.2l-1.2-1.1C4.4 12.2 1.8 9.8 1.8 6.8 1.8 4.4 3.6 2.6 6 2.6c1.4 0 2.7.7 3.5 1.8h1c.8-1.1 2.1-1.8 3.5-1.8 2.4 0 4.2 1.8 4.2 4.2 0 3-2.6 5.4-7 9.3L10 17.2z" />
                </svg>
                <span className="font-bengali-ui tabular-nums">
                  হার্ট: {toBengaliNumber(hud.animalHearts.totalValue)}
                </span>
              </div>
            </div>
          ) : (
            <>
              <div className="flex flex-wrap items-center gap-1 sm:gap-1.5">
                <div className="rounded-full border border-amber-400/50 bg-black/45 px-2.5 py-0.5 text-[10px] font-semibold text-[#f9e7c8] backdrop-blur-md sm:px-3 sm:py-1 sm:text-xs">
                  <span className="text-[#f0c563]">তরঙ্গ </span>
                  <span className="tabular-nums font-bold">{toBengaliNumber(hud.wave)}</span>
                </div>
                <div className="rounded-full border border-amber-400/50 bg-black/45 px-2.5 py-0.5 text-[10px] font-semibold text-[#f9e7c8] backdrop-blur-md sm:px-3 sm:py-1 sm:text-xs">
                  <span className="text-[#ff8170]">শত্রু </span>
                  <span className="tabular-nums font-bold">{toBengaliNumber(hud.enemiesRemaining)}</span>
                </div>
                <div className="rounded-full border border-amber-400/50 bg-black/45 px-2.5 py-0.5 text-[10px] font-semibold text-[#f9e7c8] backdrop-blur-md sm:px-3 sm:py-1 sm:text-xs">
                  <span className="text-[#ffd26a]">স্কোর </span>
                  <span className="tabular-nums font-bold">{toBengaliNumber(hud.score)}</span>
                </div>
              </div>

              {/* Live Headshot & Body Shot Pill */}
              <div className="inline-flex w-fit items-center gap-1.5 rounded-full border border-amber-400/50 bg-black/45 px-2.5 py-0.5 text-[10px] font-bold backdrop-blur-md shadow-[0_4px_12px_rgba(0,0,0,0.38)] sm:px-3 sm:py-1 sm:text-xs">
                <span className="font-bengali-ui text-[#ff6d66]">
                  হেডশট: <span className="tabular-nums text-[#ffd8d6]">{toBengaliNumber(hud.headshots)}</span>
                </span>
                <span className="text-amber-300/45">·</span>
                <span className="font-bengali-ui text-[#f7d277]">
                  বডিশট: <span className="tabular-nums text-[#fff3d6]">{toBengaliNumber(hud.bodyshots)}</span>
                </span>
              </div>
            </>
          )}

          {/* Permanent Lifetime Companion Badge with Live Scaled Stats & Quick Heart Upgrade */}
          {hud.permanentPet &&
            (() => {
              const petLv = hud.permanentPet.upgrades.level;
              const nextCost = getNextPetUpgradeCost(petLv);
              const canUpgradeNow =
                petLv < PET_MAX_LEVEL &&
                nextCost > 0 &&
                hud.animalHearts.totalValue >= nextCost;
              return (
                <div className="flex flex-col gap-1">
                  <div className="inline-flex w-fit items-center gap-1.5 rounded-full border border-emerald-400/55 bg-[#0d241c]/75 px-2.5 py-0.5 text-[10px] font-bold text-[#c6ffe6] backdrop-blur-md shadow-[0_4px_12px_rgba(0,0,0,0.38)] sm:px-3 sm:py-1 sm:text-xs">
                    <svg viewBox="0 0 20 20" className="h-3 w-3 shrink-0 fill-[#4df5b8] sm:h-3.5 sm:w-3.5">
                      <circle cx="6.2" cy="6.8" r="1.7" />
                      <circle cx="10" cy="5.4" r="1.7" />
                      <circle cx="13.8" cy="6.8" r="1.7" />
                      <path d="M10 9.4c-2.6 0-4.6 1.8-4.6 4.1 0 1.4 1.2 2.3 2.5 2.3 1 0 1.5-.4 2.1-.4s1.1.4 2.1.4c1.3 0 2.5-.9 2.5-2.3 0-2.3-2-4.1-4.6-4.1z" />
                    </svg>
                    <span className="font-bengali-ui whitespace-nowrap">
                      {hud.permanentPet.nameBn}
                    </span>
                    <span className="font-bengali-ui text-[9px] text-[#ffe17d] sm:text-[10px]">
                      · স্তর {toBengaliNumber(petLv)}
                    </span>
                    <span className="hidden font-bengali-ui text-[9px] text-[#9be8cc] sm:inline">
                      · ক্ষতি {toBengaliNumber(hud.permanentPet.stats.attackDamage)} · গতি {toBengaliNumber(hud.permanentPet.stats.moveSpeed)}
                    </span>
                  </div>

                  {hud.gameMode === 'pet_taming' && canUpgradeNow && (
                    <button
                      type="button"
                      onClick={onUpgradePet}
                      className="pointer-events-auto inline-flex w-fit items-center gap-1 rounded-full border border-[#ff9bb2] bg-gradient-to-r from-[#c92a55] to-[#e65c3a] px-2.5 py-0.5 text-[10px] font-extrabold text-white shadow-[0_4px_12px_rgba(225,65,95,0.48)] transition-transform active:scale-95 sm:px-3 sm:py-1 sm:text-[11px]"
                    >
                      <span className="font-bengali-ui">
                        সঙ্গী আপগ্রেড → স্তর {toBengaliNumber(petLv + 1)} ({toBengaliNumber(nextCost)} হার্ট)
                      </span>
                    </button>
                  )}
                </div>
              );
            })()}

          {/* Active Wild Animal Tracking Compass / Close-Range Subdue Tracker (Pet Taming Mode only, safe-area bounded) */}
          {hud.gameMode === 'pet_taming' && hud.busMode !== 'riding_intro' && hud.wildAnimal && (
            hud.busMode === 'driving' || hud.wildAnimal.distance > 55 ? (
              <div className="w-[186px] rounded-xl border border-amber-400/55 bg-black/58 px-2.5 py-1.5 text-[#fff2d6] backdrop-blur-md shadow-[0_6px_16px_rgba(0,0,0,0.45)] sm:w-[248px] sm:px-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <div className="font-bengali-ui truncate text-[10px] font-bold text-[#ffd978] sm:text-[11px]">
                      {hud.wildAnimal.nameBn} · স্তর {toBengaliNumber(hud.wildAnimal.level)}
                    </div>
                    <div className="font-bengali-ui truncate text-[9px] font-semibold text-[#d7e8d4] sm:text-[10px]">
                      {hud.wildAnimal.areaBn} ·{' '}
                      <span className="tabular-nums text-[#ffe6a3]">
                        {toBengaliNumber(hud.wildAnimal.distance)} মি.
                      </span>
                    </div>
                    <div className="font-bengali-ui mt-0.5 truncate text-[9px] font-bold">
                      {hud.wildAnimal.hasAnimalHeart ? (
                        <span className="text-[#ff8ea8]">
                          হৃদয়ধারী · এনিমেল হার্ট (+{toBengaliNumber(hud.wildAnimal.heartValue)})
                        </span>
                      ) : (
                        <span className="text-white/55">সাধারণ প্রাণী · হার্ট ড্রপ নেই</span>
                      )}
                    </div>
                  </div>
                  <div
                    className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full border sm:h-8 sm:w-8 ${
                      hud.wildAnimal.hasAnimalHeart
                        ? 'border-rose-400/75 bg-rose-500/25'
                        : 'border-amber-300/60 bg-amber-500/20'
                    }`}
                    aria-label="প্রাণীর দিক"
                  >
                    <svg
                      viewBox="0 0 24 24"
                      style={{ transform: `rotate(${hud.wildAnimal.bearingDeg}deg)` }}
                      className={`h-4 w-4 transition-transform duration-100 sm:h-4.5 sm:w-4.5 ${
                        hud.wildAnimal.hasAnimalHeart ? 'text-[#ff7b9c]' : 'text-[#ffd866]'
                      }`}
                      fill="currentColor"
                    >
                      <path d="M12 3l6 15-6-3.6L6 18 12 3z" />
                    </svg>
                  </div>
                </div>
              </div>
            ) : (
              <div
                className={`w-[184px] rounded-xl border px-2.5 py-1.5 backdrop-blur-md shadow-[0_6px_16px_rgba(0,0,0,0.45)] sm:w-[244px] sm:px-3 ${
                  hud.wildAnimal.isSubdued
                    ? 'border-[#ffd452]/80 bg-[#2a1d08]/78 text-[#fff3cf]'
                    : hud.wildAnimal.hasAnimalHeart
                      ? 'border-rose-400/70 bg-[#240d15]/75 text-[#ffe6ee]'
                      : 'border-orange-400/55 bg-black/55 text-[#ffe7d1]'
                }`}
              >
                <div className="mb-0.5 flex items-center justify-between gap-1 text-[10px] font-bold sm:text-[11px]">
                  <span className="font-bengali-ui truncate">
                    {hud.wildAnimal.nameBn} · স্তর {toBengaliNumber(hud.wildAnimal.level)}
                  </span>
                  <div className="flex shrink-0 items-center gap-1">
                    <svg
                      viewBox="0 0 24 24"
                      style={{ transform: `rotate(${hud.wildAnimal.bearingDeg}deg)` }}
                      className="h-3 w-3 text-[#ffd866]"
                      fill="currentColor"
                    >
                      <path d="M12 3l6 15-6-3.6L6 18 12 3z" />
                    </svg>
                    <span className="font-bengali-ui tabular-nums text-[#ffd978]">
                      {toBengaliNumber(hud.wildAnimal.distance)} মি.
                    </span>
                  </div>
                </div>
                <div className="font-bengali-ui mb-1 text-[9px] font-bold">
                  {hud.wildAnimal.hasAnimalHeart ? (
                    <span className="text-[#ff8ea8]">
                      হৃদয়ধারী · এনিমেল হার্ট (+{toBengaliNumber(hud.wildAnimal.heartValue)})
                    </span>
                  ) : (
                    <span className="text-white/55">সাধারণ প্রাণী · হার্ট ড্রপ নেই</span>
                  )}
                </div>
                <div className="relative h-1.5 w-full overflow-hidden rounded-full bg-white/15">
                  <div
                    style={{
                      width: `${Math.max(0, Math.min(100, (hud.wildAnimal.hp / Math.max(1, hud.wildAnimal.maxHp)) * 100))}%`,
                    }}
                    className={`h-full rounded-full transition-[width] duration-150 ${
                      hud.wildAnimal.isSubdued
                        ? 'bg-gradient-to-r from-[#ffb72b] to-[#ffe678]'
                        : hud.wildAnimal.hasAnimalHeart
                          ? 'bg-gradient-to-r from-[#e12b5c] to-[#ff7652]'
                          : 'bg-gradient-to-r from-[#d93829] to-[#ff7b38]'
                    }`}
                  />
                  {/* Visual 22% Subdue Threshold Notch */}
                  <div
                    style={{ left: `${Math.round(hud.wildAnimal.subdueRatio * 100)}%` }}
                    className="pointer-events-none absolute inset-y-0 w-0.5 bg-white shadow-[0_0_4px_#fff]"
                  />
                </div>
                <div className="font-bengali-ui mt-1 text-[9px] font-semibold leading-tight sm:text-[10px]">
                  {hud.wildAnimal.isSubdued ? (
                    hud.permanentPet ? (
                      hud.wildAnimal.hasAnimalHeart ? (
                        <span className="text-[#ffadc0]">দুর্বল · পরাজিত করলে এনিমেল হার্ট পাবেন</span>
                      ) : (
                        <span className="text-[#ffd2a6]">দুর্বল · এই আইডি-তে স্থায়ী সঙ্গী আছে</span>
                      )
                    ) : (
                      <span className="text-[#9effc8]">দুর্বল (&lt;২২%)! দ্রুত সোনালি বলয়ে বশ করুন</span>
                    )
                  ) : hud.permanentPet && hud.wildAnimal.hasAnimalHeart ? (
                    <span className="text-[#ffc2d0]">পরাজিত করে এনিমেল হার্ট সংগ্রহ করুন</span>
                  ) : (
                    <span className="text-[#ffcaa0]">২২% এর নিচে দুর্বল করুন (মারবেন না!)</span>
                  )}
                </div>
              </div>
            )
          )}
        </div>

        {/* Top-Center: Location Pill + Kalboishakhi Storm Pill (Survival Mode only on Tablet/Desktop) */}
        <div className="hidden md:flex md:flex-col md:items-center md:gap-1.5">
          {locationBadge}
          {hud.gameMode === 'survival' && hud.busMode !== 'riding_intro' && stormBadge}
        </div>

        {/* Top-Right: Ammo / Bus Speed Pill + Circular Mute, Fullscreen, Settings & Pause + Mobile Location/Storm Pills */}
        <div className="flex shrink-0 flex-col items-end gap-1 sm:gap-1.5">
          <div className="flex items-center gap-1 sm:gap-2">
            {/* Desktop/Landscape inline Ammo or Bus Speed Pill */}
            <div className="hidden sm:block">
              {hud.busMode === 'driving' ? (
                <div className="rounded-full border border-amber-400/50 bg-black/45 px-3.5 py-1.5 text-right backdrop-blur-md shadow-[0_6px_18px_rgba(0,0,0,0.4)]">
                  <div className="font-bengali-ui text-[10px] font-bold tracking-wide text-[#ffd65c]">
                    WBTC বাস
                  </div>
                  <div className="font-bengali-ui tabular-nums text-sm font-bold leading-tight text-[#fff7e2] sm:text-base">
                    {toBengaliNumber(hud.busSpeedKmh)}{' '}
                    <span className="text-[10px] font-semibold text-[#a5d2f7]">কিমি/ঘ</span>
                  </div>
                </div>
              ) : hud.ridingVehicle !== null ? (
                <div
                  className={`rounded-full border px-3.5 py-1.5 text-right backdrop-blur-md shadow-[0_6px_18px_rgba(0,0,0,0.4)] ${
                    hud.ridingVehicle === 'motorcycle'
                      ? 'border-orange-400/65 bg-black/50'
                      : 'border-emerald-400/65 bg-black/50'
                  }`}
                >
                  <div
                    className={`font-bengali-ui text-[10px] font-bold tracking-wide ${
                      hud.ridingVehicle === 'motorcycle' ? 'text-[#ffb45c]' : 'text-[#84f5c1]'
                    }`}
                  >
                    {hud.ridingVehicle === 'motorcycle' ? 'বাইক ভ্রমণ' : 'সাইকেল ভ্রমণ'}
                  </div>
                  <div className="font-bengali-ui tabular-nums text-sm font-bold leading-tight text-[#fff7e2] sm:text-base">
                    {toBengaliNumber(hud.vehicleSpeedKmh)}{' '}
                    <span className="text-[10px] font-semibold text-[#ffd894]">কিমি/ঘ</span>
                  </div>
                </div>
              ) : (
                <div className="rounded-full border border-amber-400/50 bg-black/45 px-3.5 py-1.5 text-right backdrop-blur-md shadow-[0_6px_18px_rgba(0,0,0,0.4)]">
                  <div className="flex items-center justify-end gap-1">
                    <span className="font-bengali-ui text-xs font-bold text-[#ffd978]">
                      {activeMeta.shortName}
                    </span>
                    <span className="text-amber-300/50">·</span>
                    {activeMeta.isMelee ? (
                      <span className="font-bengali-ui text-xs font-bold text-[#e3f2ff]">
                        ছুরি
                      </span>
                    ) : hud.isReloading ? (
                      <span className="font-bengali-ui text-[10px] font-bold text-[#ffd67d]">
                        রিলোড {toBengaliNumber(Math.round(hud.reloadProgress * 100))}%
                      </span>
                    ) : (
                      <span className="font-bengali-ui tabular-nums text-sm font-bold">
                        <span className={lowAmmo ? 'text-[#ff6961]' : 'text-[#fff5e1]'}>
                          {toBengaliNumber(hud.ammo)}
                        </span>
                        <span className="mx-0.5 text-[10px] text-[#c7a980]">/</span>
                        <span className="text-[11px] text-[#d9bd96]">
                          {toBengaliNumber(hud.reserveAmmo)}
                        </span>
                      </span>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Circular Mute Toggle */}
            <button
              type="button"
              onClick={onToggleMute}
              onPointerDown={(e) => e.stopPropagation()}
              aria-label={hud.muted ? 'শব্দ চালু করুন' : 'শব্দ বন্ধ করুন'}
              className="pointer-events-auto flex h-9 w-9 touch-none select-none items-center justify-center rounded-full border border-amber-400/50 bg-black/45 text-[#fdebd0] backdrop-blur-md shadow-[0_4px_14px_rgba(0,0,0,0.4)] transition-transform hover:bg-black/65 active:scale-95 sm:h-10 sm:w-10"
            >
              {hud.muted ? (
                <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current stroke-2 sm:h-5 sm:w-5">
                  <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                  <line x1="22" y1="9" x2="16" y2="15" strokeLinecap="round" />
                  <line x1="16" y1="9" x2="22" y2="15" strokeLinecap="round" />
                </svg>
              ) : (
                <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current stroke-2 sm:h-5 sm:w-5">
                  <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                  <path d="M15.5 8.5a5 5 0 0 1 0 7" strokeLinecap="round" />
                  <path d="M18.8 5.5a9 9 0 0 1 0 13" strokeLinecap="round" />
                </svg>
              )}
            </button>

            {/* Circular Fullscreen Toggle */}
            <button
              type="button"
              onClick={onToggleFullscreen}
              onPointerDown={(e) => e.stopPropagation()}
              aria-label={isFullscreen ? 'ফুলস্ক্রিন বন্ধ করুন' : 'ফুলস্ক্রিন চালু করুন'}
              title={isFullscreen ? 'ফুলস্ক্রিন বন্ধ' : 'ফুলস্ক্রিন'}
              className={`pointer-events-auto flex h-9 w-9 touch-none select-none items-center justify-center rounded-full border backdrop-blur-md shadow-[0_4px_14px_rgba(0,0,0,0.4)] transition-transform hover:bg-black/65 active:scale-95 sm:h-10 sm:w-10 ${
                isFullscreen
                  ? 'border-amber-300/80 bg-amber-500/30 text-[#fff6db]'
                  : 'border-amber-400/50 bg-black/45 text-[#fdebd0]'
              }`}
            >
              {isFullscreen ? (
                <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current stroke-2 sm:h-5 sm:w-5">
                  <path d="M9 4v5H4" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M15 4v5h5" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M9 20v-5H4" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M15 20v-5h5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              ) : (
                <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current stroke-2 sm:h-5 sm:w-5">
                  <path d="M4 9V4h5" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M20 9V4h-5" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M4 15v5h5" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M20 15v5h-5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              )}
            </button>

            {/* Circular Settings Button (সেটিংস — right next to Pause) */}
            <button
              type="button"
              onClick={onOpenSettings}
              onPointerDown={(e) => e.stopPropagation()}
              aria-label="সেটিংস"
              title="সেটিংস"
              className="pointer-events-auto flex h-9 w-9 touch-none select-none items-center justify-center rounded-full border border-amber-400/55 bg-black/45 text-[#ffe394] backdrop-blur-md shadow-[0_4px_14px_rgba(0,0,0,0.4)] transition-transform hover:border-amber-300/85 hover:bg-black/65 active:scale-95 sm:h-10 sm:w-10"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current stroke-2 sm:h-5 sm:w-5">
                <circle cx="12" cy="12" r="3" />
                <path
                  d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.08a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h.08a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v.08a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>

            {/* Circular Pause Button */}
            <button
              type="button"
              onClick={onPause}
              onPointerDown={(e) => e.stopPropagation()}
              aria-label="বিরতি"
              className="pointer-events-auto flex h-9 w-9 touch-none select-none items-center justify-center rounded-full border border-amber-400/50 bg-black/45 text-[#fdebd0] backdrop-blur-md shadow-[0_4px_14px_rgba(0,0,0,0.4)] transition-transform hover:bg-black/65 active:scale-95 sm:h-10 sm:w-10"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 fill-current sm:h-5 sm:w-5">
                <rect x="6" y="5" width="4" height="14" rx="1.5" />
                <rect x="14" y="5" width="4" height="14" rx="1.5" />
              </svg>
            </button>
          </div>

          {/* Mobile Portrait Compact Ammo/Bus Pill (prevents horizontal crowding on narrow screens) */}
          <div className="sm:hidden">
            {hud.busMode === 'driving' ? (
              <div className="rounded-full border border-amber-400/50 bg-black/45 px-2.5 py-0.5 text-right backdrop-blur-md shadow-[0_4px_12px_rgba(0,0,0,0.4)]">
                <span className="font-bengali-ui tabular-nums text-[11px] font-bold text-[#fff7e2]">
                  WBTC · {toBengaliNumber(hud.busSpeedKmh)} কিমি/ঘ
                </span>
              </div>
            ) : hud.ridingVehicle !== null ? (
              <div
                className={`rounded-full border px-2.5 py-0.5 text-right backdrop-blur-md shadow-[0_4px_12px_rgba(0,0,0,0.4)] ${
                  hud.ridingVehicle === 'motorcycle'
                    ? 'border-orange-400/65 bg-black/50'
                    : 'border-emerald-400/65 bg-black/50'
                }`}
              >
                <span className="font-bengali-ui tabular-nums text-[11px] font-bold text-[#fff7e2]">
                  {hud.ridingVehicle === 'motorcycle' ? 'বাইক' : 'সাইকেল'} ·{' '}
                  {toBengaliNumber(hud.vehicleSpeedKmh)} কিমি/ঘ
                </span>
              </div>
            ) : (
              <div className="rounded-full border border-amber-400/50 bg-black/45 px-2.5 py-0.5 text-right backdrop-blur-md shadow-[0_4px_12px_rgba(0,0,0,0.4)]">
                <div className="flex items-center justify-end gap-1">
                  <span className="font-bengali-ui text-[10px] font-bold text-[#ffd978]">
                    {activeMeta.shortName}
                  </span>
                  <span className="text-amber-300/50">·</span>
                  {activeMeta.isMelee ? (
                    <span className="font-bengali-ui text-[10px] font-bold text-[#e3f2ff]">ছুরি</span>
                  ) : hud.isReloading ? (
                    <span className="font-bengali-ui text-[10px] font-bold text-[#ffd67d]">
                      রিলোড {toBengaliNumber(Math.round(hud.reloadProgress * 100))}%
                    </span>
                  ) : (
                    <span className="font-bengali-ui tabular-nums text-[11px] font-bold">
                      <span className={lowAmmo ? 'text-[#ff6961]' : 'text-[#fff5e1]'}>
                        {toBengaliNumber(hud.ammo)}
                      </span>
                      <span className="mx-0.5 text-[9px] text-[#c7a980]">/</span>
                      <span className="text-[10px] text-[#d9bd96]">
                        {toBengaliNumber(hud.reserveAmmo)}
                      </span>
                    </span>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Mobile Location Pill + Storm Pill (Survival Mode only) stacked cleanly under top-right */}
          <div className="flex flex-col items-end gap-1 md:hidden">
            {locationBadge}
            {hud.gameMode === 'survival' && hud.busMode !== 'riding_intro' && stormBadge}
          </div>
        </div>
      </div>

      {/* Center Reticle, Dynamic Spread, Hitmarker & Directional Damage Arc */}
      {isOnFoot && (
        <div className="pointer-events-none fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          {/* Directional Incoming Damage Indicator Arc */}
          {hud.damageFlash > 0.05 && hud.damageAngle !== null && (
            <div
              style={{
                opacity: Math.min(0.95, hud.damageFlash * 1.15),
                transform: `translate(-50%, -50%) rotate(${Math.round((hud.damageAngle * 180) / Math.PI)}deg)`,
              }}
              className="pointer-events-none absolute left-1/2 top-1/2 h-36 w-36 sm:h-44 sm:w-44"
            >
              <svg viewBox="0 0 120 120" className="h-full w-full drop-shadow-[0_0_8px_rgba(255,34,34,0.85)]">
                <path
                  d="M 38 14 A 48 48 0 0 1 82 14"
                  fill="none"
                  stroke="#ff2b2b"
                  strokeWidth="6.5"
                  strokeLinecap="round"
                />
                <polygon points="60,2 54,12 66,12" fill="#ff5454" />
              </svg>
            </div>
          )}

          {(() => {
            const spreadPx = Math.round(
              Math.min(14, Math.max(0, hud.reticleSpread) * (hud.scopeActive ? 5 : 13)),
            );
            const hitScale =
              hud.hitMarker > 0.05
                ? (hud.hitMarkerHeadshot || hud.hitMarkerKill ? 1.18 : 1.0) +
                  Math.sin(Math.min(1, hud.hitMarker) * Math.PI) * 0.28
                : 1;
            return (
              <div
                className={`relative h-10 w-10 transition-transform duration-150 ${
                  hud.scopeActive && !showSniperScope ? 'scale-90' : 'scale-100'
                }`}
              >
                {!showSniperScope && (
                  <>
                    <span
                      style={{ transform: `translate(-50%, ${-spreadPx}px)` }}
                      className="absolute left-1/2 top-1 h-2.5 w-[2px] rounded-full bg-[#fff8e8]/95 shadow-[0_0_3px_rgba(0,0,0,0.95)]"
                    />
                    <span
                      style={{ transform: `translate(-50%, ${spreadPx}px)` }}
                      className="absolute bottom-1 left-1/2 h-2.5 w-[2px] rounded-full bg-[#fff8e8]/95 shadow-[0_0_3px_rgba(0,0,0,0.95)]"
                    />
                    <span
                      style={{ transform: `translate(${-spreadPx}px, -50%)` }}
                      className="absolute left-1 top-1/2 h-[2px] w-2.5 rounded-full bg-[#fff8e8]/95 shadow-[0_0_3px_rgba(0,0,0,0.95)]"
                    />
                    <span
                      style={{ transform: `translate(${spreadPx}px, -50%)` }}
                      className="absolute right-1 top-1/2 h-[2px] w-2.5 rounded-full bg-[#fff8e8]/95 shadow-[0_0_3px_rgba(0,0,0,0.95)]"
                    />
                    <span
                      className={`absolute left-1/2 top-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full ring-1 ring-black/70 ${
                        hud.scopeActive
                          ? 'bg-cyan-300 shadow-[0_0_8px_#38bdf8]'
                          : 'bg-[#ffd25a] shadow-[0_0_4px_rgba(0,0,0,0.9)]'
                      }`}
                    />
                  </>
                )}

                {hud.hitMarker > 0.05 && (
                  <svg
                    viewBox="0 0 40 40"
                    style={{
                      opacity: Math.min(1, hud.hitMarker * 1.2),
                      transform: `scale(${hitScale.toFixed(3)})`,
                    }}
                    className="absolute inset-0 h-10 w-10 drop-shadow-[0_0_5px_rgba(0,0,0,0.9)]"
                  >
                    <g
                      stroke={
                        hud.hitMarkerHeadshot
                          ? '#ff2424'
                          : hud.hitMarkerKill
                            ? '#ff3d2e'
                            : '#fff3b8'
                      }
                      strokeWidth={hud.hitMarkerHeadshot ? 3.5 : hud.hitMarkerKill ? 3.1 : 2.4}
                      strokeLinecap="round"
                    >
                      <line x1="6" y1="6" x2="14.5" y2="14.5" />
                      <line x1="34" y1="6" x2="25.5" y2="14.5" />
                      <line x1="6" y1="34" x2="14.5" y2="25.5" />
                      <line x1="34" y1="34" x2="25.5" y2="25.5" />
                    </g>
                    {(hud.hitMarkerHeadshot || hud.hitMarkerKill) && (
                      <circle
                        cx="20"
                        cy="20"
                        r={hud.hitMarkerHeadshot ? 13 : 11}
                        fill="none"
                        stroke={hud.hitMarkerHeadshot ? '#ffd859' : '#ff5247'}
                        strokeWidth="1.6"
                        strokeDasharray="4 4"
                      />
                    )}
                  </svg>
                )}
              </div>
            );
          })()}
        </div>
      )}

      {/* WBTC INTRO BUS RIDE UI: Pill Route Indicator + Pill/Circular Controls */}
      {hud.busMode === 'riding_intro' && (
        <>
          <div className="pointer-events-none fixed left-1/2 top-[max(1rem,env(safe-area-inset-top))] hidden -translate-x-1/2 flex-col items-center rounded-full border border-amber-400/50 bg-black/45 px-5 py-2 backdrop-blur-md shadow-[0_8px_24px_rgba(0,0,0,0.48)] sm:flex">
            <div className="flex items-center gap-2 text-xs font-bold text-[#ffd85c]">
              <span>WBTC S-12</span>
              <span className="text-[#8fc8f5]">•</span>
              <span className="font-bengali-ui text-[#fff6e3]">{hud.busZoneLabel || 'হাওড়া সেতু'}</span>
              <span className="rounded-full bg-emerald-900/80 px-2 py-0.5 font-bengali-ui text-[10px] font-bold text-[#9cf2be]">
                নিরাপদ অবতরণ
              </span>
            </div>
            <div className="mt-1.5 h-1.5 w-48 overflow-hidden rounded-full bg-white/15">
              <div
                style={{ width: `${Math.round(hud.busRouteProgress * 100)}%` }}
                className="h-full rounded-full bg-gradient-to-r from-[#2e9bff] via-[#ffd245] to-[#ef5338]"
              />
            </div>
          </div>

          <div className="pointer-events-auto fixed bottom-[max(1rem,env(safe-area-inset-bottom))] left-1/2 z-30 flex w-max max-w-[94vw] -translate-x-1/2 flex-col items-center gap-2 sm:bottom-7">
            <div className="flex items-center gap-2 rounded-full border border-amber-400/50 bg-black/45 px-3.5 py-1 text-xs font-semibold text-[#dff0ff] backdrop-blur-md sm:hidden">
              <span>{hud.busZoneLabel || 'হাওড়া সেতু'}</span>
              <span className="rounded-full bg-emerald-900/80 px-2 py-0.5 text-[10px] font-bold text-[#9cf2be]">
                নিরাপদ
              </span>
            </div>
            <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3">
              <button
                type="button"
                onClick={onToggleBusCameraView}
                aria-label={hud.busInteriorCam ? 'বাইরের দৃশ্য' : 'ভিতরের দৃশ্য'}
                className="font-bengali-ui flex h-11 items-center gap-1.5 whitespace-nowrap rounded-full border border-amber-400/50 bg-black/45 px-4 text-xs font-bold text-[#e6f4ff] backdrop-blur-md shadow-[0_6px_18px_rgba(0,0,0,0.5)] transition-colors hover:bg-black/65 active:scale-95 sm:h-12 sm:px-5 sm:text-sm"
              >
                <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-[#ffd85c] stroke-2 sm:h-5 sm:w-5">
                  <path d="M2 12s3.8-6.5 10-6.5S22 12 22 12s-3.8 6.5-10 6.5S2 12 2 12z" />
                  <circle cx="12" cy="12" r="3" />
                </svg>
                <span>{hud.busInteriorCam ? 'বাইরের দৃশ্য' : 'ভিতরের দৃশ্য'}</span>
                <span className="hidden rounded-full bg-white/15 px-1.5 py-0.5 text-[10px] font-bold text-[#9fd3ff] sm:inline">
                  V
                </span>
              </button>

              <button
                type="button"
                onClick={onExitBus}
                disabled={hud.busExitSlowing}
                className={`font-bengali-display flex items-center gap-2 whitespace-nowrap rounded-full border-2 px-6 py-3 text-base font-extrabold tracking-wide transition-transform sm:gap-2.5 sm:px-8 sm:py-3.5 sm:text-xl ${
                  hud.busExitSlowing
                    ? 'cursor-wait border-[#ffe699] bg-gradient-to-b from-[#d4961a] to-[#9b5908] text-[#fff6dc] shadow-[0_0_22px_rgba(255,180,32,0.55),0_10px_24px_rgba(0,0,0,0.58)]'
                    : 'border-[#fff1b5] bg-gradient-to-b from-[#ffe047] via-[#f5b415] to-[#d97c06] text-[#241205] shadow-[0_0_26px_rgba(255,194,32,0.68),0_10px_28px_rgba(0,0,0,0.58)] hover:scale-[1.03] active:scale-[0.96]'
                }`}
              >
                <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-[2.4] sm:h-6 sm:w-6">
                  <path d="M9 4h8a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H9" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M13 12H3m0 0l4-4m-4 4l4 4" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                <span>{hud.busExitSlowing ? 'বাস থামছে... দরজা খুলছে' : 'বাস থেকে নামুন'}</span>
              </button>

              <button
                type="button"
                onClick={onBusHorn}
                aria-label="হর্ন বাজান"
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-amber-400/50 bg-black/45 text-[#ffe078] backdrop-blur-md shadow-[0_6px_18px_rgba(0,0,0,0.5)] hover:bg-black/65 active:scale-95 sm:h-12 sm:w-12"
              >
                <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-2">
                  <path d="M3 14v-4h4l6-4v12l-6-4H3z" strokeLinejoin="round" />
                  <path d="M17 9a4 4 0 0 1 0 6" strokeLinecap="round" />
                  <path d="M19.5 6.5a7.5 7.5 0 0 1 0 11" strokeLinecap="round" />
                </svg>
              </button>
            </div>
            <span className="font-bengali-ui text-center text-[11px] font-semibold text-[#f8e7c5] drop-shadow sm:text-xs">
              পছন্দের জায়গায় সরাসরি নামতে Space / F চাপুন · দৃশ্য বদলাতে V চাপুন
            </span>
          </div>
        </>
      )}

      {/* ON-FOOT CONTROLS: Customizable Scope, Weapon Bar, Sanjibani & Bajra Gola inside Safe-Area Stage */}
      {isOnFoot && (
        <>
          <div
            className="touch-controls-root pointer-events-none fixed z-25 touch-none select-none"
            style={{
              top: 'env(safe-area-inset-top, 0px)',
              right: 'env(safe-area-inset-right, 0px)',
              bottom: 'env(safe-area-inset-bottom, 0px)',
              left: 'env(safe-area-inset-left, 0px)',
            }}
          >
            {/* Customizable Circular Zoom / Scope Button ('স্কোপ' / 'জুম আউট') */}
            <div
              className="pointer-events-auto absolute touch-none select-none"
              style={{
                left: `${customHud.scope.x}%`,
                top: `${customHud.scope.y}%`,
                transform: `translate(-50%, -50%) scale(${customHud.scope.size})`,
                opacity: customHud.scope.opacity,
              }}
            >
              <button
                type="button"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onToggleScope();
                }}
                aria-pressed={hud.scopeActive}
                aria-label={hud.scopeActive ? 'জুম আউট' : 'স্কোপ জুম ইন'}
                className={`touch-control-btn flex h-14 w-14 touch-none select-none flex-col items-center justify-center rounded-full border backdrop-blur-md transition-all duration-150 active:scale-95 sm:h-16 sm:w-16 ${
                  hud.scopeActive
                    ? 'border-cyan-300 bg-cyan-950/70 text-cyan-100 ring-2 ring-cyan-300/80 ring-offset-2 ring-offset-black/40 shadow-[0_0_24px_rgba(56,189,248,0.68)]'
                    : 'border-amber-400/50 bg-black/45 text-[#fff0cf] shadow-[0_8px_22px_rgba(0,0,0,0.48)] hover:border-amber-300/80 hover:bg-black/60'
                }`}
              >
                <svg viewBox="0 0 24 24" className="pointer-events-none h-5 w-5 fill-none stroke-current stroke-[2.1] sm:h-6 sm:w-6">
                  <circle cx="12" cy="12" r="7" />
                  <line x1="12" y1="2.5" x2="12" y2="6.5" strokeLinecap="round" />
                  <line x1="12" y1="17.5" x2="12" y2="21.5" strokeLinecap="round" />
                  <line x1="2.5" y1="12" x2="6.5" y2="12" strokeLinecap="round" />
                  <line x1="17.5" y1="12" x2="21.5" y2="12" strokeLinecap="round" />
                  {hud.scopeActive ? (
                    <line x1="9" y1="12" x2="15" y2="12" strokeLinecap="round" />
                  ) : (
                    <>
                      <line x1="9" y1="12" x2="15" y2="12" strokeLinecap="round" />
                      <line x1="12" y1="9" x2="12" y2="15" strokeLinecap="round" />
                    </>
                  )}
                </svg>
                <span className="font-bengali-ui pointer-events-none mt-0.5 whitespace-nowrap text-[9px] font-bold leading-none sm:text-[10px]">
                  {hud.scopeActive ? 'জুম আউট' : 'স্কোপ'}
                </span>
              </button>
            </div>

            {/* Customizable 4-Slot Weapon Bar */}
            <div
              className="pointer-events-auto absolute touch-none select-none"
              style={{
                left: `${customHud.weapons.x}%`,
                top: `${customHud.weapons.y}%`,
                transform: `translate(-50%, -50%) scale(${customHud.weapons.size})`,
                opacity: customHud.weapons.opacity,
              }}
            >
              <div className="flex w-max max-w-[92vw] items-center gap-1 rounded-full border border-amber-400/50 bg-black/45 p-1 backdrop-blur-md shadow-[0_8px_22px_rgba(0,0,0,0.48)] sm:gap-1.5 sm:p-1.5">
                {WEAPON_SLOT_ORDER.map((weaponId) => {
                  const meta = WEAPON_CATALOG[weaponId];
                  const slotState = hud.weapons[weaponId];
                  const selected = hud.activeWeapon === weaponId;
                  return (
                    <button
                      key={weaponId}
                      type="button"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        onSelectWeapon(weaponId);
                      }}
                      className={`touch-control-btn relative flex touch-none select-none items-center gap-1 whitespace-nowrap rounded-full border px-2 py-1.5 transition-all active:scale-95 sm:gap-1.5 sm:px-3 sm:py-1.5 ${
                        selected
                          ? 'border-amber-300 bg-amber-500/30 text-[#fff8e6] shadow-[0_0_14px_rgba(251,191,36,0.45)]'
                          : 'border-transparent bg-white/5 text-[#e2cfa8] hover:bg-white/12'
                      }`}
                    >
                      <span className="font-bengali-ui pointer-events-none text-[10px] font-bold leading-none sm:text-xs">
                        {meta.shortName}
                      </span>
                      <span
                        className={`font-bengali-ui tabular-nums pointer-events-none text-[9px] font-extrabold leading-none sm:text-[10px] ${
                          selected ? 'text-amber-200' : 'text-amber-300/70'
                        }`}
                      >
                        {meta.isMelee ? '∞' : toBengaliNumber(slotState.ammo)}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Customizable Circular সঞ্জীবনী গাছ (Sanjibani Healing Plant) Button */}
            <div
              className="pointer-events-auto absolute touch-none select-none"
              style={{
                left: `${customHud.sanjibani.x}%`,
                top: `${customHud.sanjibani.y}%`,
                transform: `translate(-50%, -50%) scale(${customHud.sanjibani.size})`,
                opacity: customHud.sanjibani.opacity,
              }}
            >
              <button
                type="button"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onUseSanjibani();
                }}
                disabled={!canHeal && !hud.isHealing}
                aria-label="সঞ্জীবনী গাছ ব্যবহার করুন"
                title="সঞ্জীবনী গাছ"
                className={`touch-control-btn relative flex h-12 w-12 shrink-0 touch-none select-none flex-col items-center justify-center rounded-full border backdrop-blur-md shadow-[0_6px_18px_rgba(0,0,0,0.45)] transition-all active:scale-95 sm:h-14 sm:w-14 ${
                  hud.isHealing
                    ? 'border-emerald-300 bg-emerald-900/65 text-[#d6ffe6] ring-2 ring-emerald-300/60'
                    : canHeal
                      ? 'border-amber-400/50 bg-black/45 text-[#d3ffe4] hover:border-emerald-400/80 hover:bg-emerald-950/60'
                      : 'border-amber-400/25 bg-black/35 text-[#87a894]/65'
                }`}
              >
                {hud.isHealing && (
                  <div
                    style={{ height: `${Math.round(hud.healProgress * 100)}%` }}
                    className="pointer-events-none absolute inset-x-0 bottom-0 rounded-full bg-emerald-400/35"
                  />
                )}
                <svg viewBox="0 0 24 24" className="pointer-events-none relative h-4 w-4 shrink-0 fill-[#49f08f] sm:h-5 sm:w-5">
                  <path d="M17 8C8 10 5.9 16.17 3.82 21.34l1.89.66.95-2.3c.48.17.98.3 1.34.3C19 20 22 3 22 3c-1 2-8 2.25-13 3.25S2 11.5 2 13.5s1.75 3.75 1.75 3.75C7 8 17 8 17 8z" />
                </svg>
                <span className="font-bengali-ui pointer-events-none relative mt-0.5 text-[8px] font-bold leading-none sm:text-[9px]">
                  সঞ্জীবনী
                </span>
                <span className="font-bengali-ui tabular-nums pointer-events-none absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full border border-emerald-300/60 bg-emerald-950 px-1 text-[9px] font-extrabold text-[#7fffb2]">
                  {toBengaliNumber(hud.sanjibaniCount)}
                </span>
              </button>
            </div>

            {/* Customizable Circular বজ্র গোলা (Bajra Gola Grenade) Button */}
            <div
              className="pointer-events-auto absolute touch-none select-none"
              style={{
                left: `${customHud.grenade.x}%`,
                top: `${customHud.grenade.y}%`,
                transform: `translate(-50%, -50%) scale(${customHud.grenade.size})`,
                opacity: customHud.grenade.opacity,
              }}
            >
              <button
                type="button"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onThrowGrenade();
                }}
                disabled={!canThrowGrenade}
                aria-label="বজ্র গোলা নিক্ষেপ করুন"
                title="বজ্র গোলা"
                className={`touch-control-btn relative flex h-12 w-12 shrink-0 touch-none select-none flex-col items-center justify-center rounded-full border backdrop-blur-md shadow-[0_6px_18px_rgba(0,0,0,0.45)] transition-all active:scale-95 sm:h-14 sm:w-14 ${
                  canThrowGrenade
                    ? 'border-amber-400/50 bg-black/45 text-[#ffe5c7] hover:border-amber-300/80 hover:bg-amber-950/60'
                    : 'border-amber-400/25 bg-black/35 text-[#a68c78]/60'
                }`}
              >
                <svg viewBox="0 0 24 24" className="pointer-events-none h-4 w-4 shrink-0 fill-none stroke-[#ffae52] stroke-2 sm:h-5 sm:w-5">
                  <circle cx="12" cy="14" r="6" fill="#ff9436" fillOpacity="0.28" />
                  <path d="M10 8V5h4v3" />
                  <path d="M14 5l3-2" strokeLinecap="round" />
                </svg>
                <span className="font-bengali-ui pointer-events-none mt-0.5 text-[8px] font-bold leading-none sm:text-[9px]">
                  বজ্র গোলা
                </span>
                <span className="font-bengali-ui tabular-nums pointer-events-none absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full border border-amber-300/60 bg-amber-950 px-1 text-[9px] font-extrabold text-[#ffc978]">
                  {toBengaliNumber(hud.grenadeCount)}
                </span>
              </button>
            </div>
          </div>

          {/* Contextual Action Pills ('প্রাণী বশ করুন', 'সিন্দুক খুলুন', 'সাইকেল/বাইক', 'বাসে উঠুন') + Taming & Sanjibani Progress Bars */}
          {(hud.nearChest ||
            hud.nearBus ||
            hud.nearVehicle !== null ||
            hud.isHealing ||
            hud.tamingActive ||
            hud.wildAnimal?.canTame ||
            hud.wildAnimal?.blockedByLifetimeLimit) && (
            <div className="pointer-events-none fixed bottom-[calc(4.75rem+env(safe-area-inset-bottom))] left-1/2 z-30 flex w-max max-w-[92vw] -translate-x-1/2 flex-col items-center gap-2 sm:bottom-[calc(5.25rem+env(safe-area-inset-bottom))]">
              {hud.tamingActive && (
                <div className="flex w-64 flex-col gap-1.5 rounded-2xl border-2 border-[#6effc8]/80 bg-[#0b241c]/88 px-4 py-2.5 backdrop-blur-md shadow-[0_0_24px_rgba(70,240,175,0.45),0_10px_24px_rgba(0,0,0,0.6)] sm:w-72">
                  <div className="flex items-center justify-between text-xs font-extrabold text-[#b8ffe4]">
                    <span className="font-bengali-ui">প্রাণী বশ হচ্ছে...</span>
                    <span className="font-bengali-ui tabular-nums text-[#ffe680]">
                      {toBengaliNumber(Math.round(hud.tamingProgress * 100))}%
                    </span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-white/15">
                    <div
                      style={{ width: `${Math.round(hud.tamingProgress * 100)}%` }}
                      className="h-full rounded-full bg-gradient-to-r from-[#24d491] via-[#6effc8] to-[#ffe066]"
                    />
                  </div>
                  {hud.tamingStatusText && (
                    <div className="font-bengali-ui text-center text-[10px] font-semibold text-[#e2fff3]">
                      {hud.tamingStatusText}
                    </div>
                  )}
                </div>
              )}

              {hud.isHealing && (
                <div className="flex w-52 flex-col gap-1 rounded-full border border-emerald-400/65 bg-black/55 px-4 py-2 backdrop-blur-md shadow-[0_8px_20px_rgba(0,0,0,0.5)]">
                  <div className="flex items-center justify-between text-[11px] font-bold text-[#a8ffd0]">
                    <span className="font-bengali-ui">সঞ্জীবনী নিরাময়...</span>
                    <span className="font-bengali-ui tabular-nums">
                      {toBengaliNumber(Math.round(hud.healProgress * 100))}%
                    </span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/15">
                    <div
                      style={{ width: `${Math.round(hud.healProgress * 100)}%` }}
                      className="h-full rounded-full bg-gradient-to-r from-[#24c96b] to-[#8cffb8]"
                    />
                  </div>
                </div>
              )}

              {!hud.tamingActive && hud.wildAnimal?.blockedByLifetimeLimit && (
                <div className="rounded-full border border-amber-300/60 bg-black/65 px-4 py-1.5 text-center text-[11px] font-bold text-[#ffe3a3] backdrop-blur-md shadow-[0_6px_18px_rgba(0,0,0,0.5)]">
                  <span className="font-bengali-ui">
                    আজীবনে ১টিই সঙ্গী অনুমোদিত — আপনার আইডি-তে ({hud.playerId}) ইতিমধ্যেই স্থায়ী সঙ্গী আছে
                  </span>
                </div>
              )}

              {(hud.nearChest ||
                hud.nearBus ||
                hud.nearVehicle !== null ||
                (!hud.tamingActive && hud.wildAnimal?.canTame)) && (
                <div className="pointer-events-auto flex flex-wrap items-center justify-center gap-2">
                  {!hud.tamingActive && hud.wildAnimal?.canTame && (
                    <button
                      type="button"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        onStartTaming();
                      }}
                      className="font-bengali-display flex items-center gap-1.5 whitespace-nowrap rounded-full border-2 border-[#a8ffe0] bg-gradient-to-b from-[#17a36f] to-[#0b5c40] px-4 py-2 text-sm font-extrabold tracking-wide text-[#f2fff9] shadow-[0_0_24px_rgba(45,230,155,0.6),0_8px_20px_rgba(0,0,0,0.55)] transition-transform hover:scale-[1.03] active:scale-95 sm:px-5 sm:py-2.5 sm:text-base"
                    >
                      <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-[#b8ffe4] sm:h-5 sm:w-5">
                        <circle cx="7.5" cy="8.5" r="2" />
                        <circle cx="12" cy="6.8" r="2" />
                        <circle cx="16.5" cy="8.5" r="2" />
                        <path d="M12 11.4c-3.1 0-5.4 2.1-5.4 4.8 0 1.6 1.4 2.7 3 2.7 1.1 0 1.8-.4 2.4-.4s1.3.4 2.4.4c1.6 0 3-1.1 3-2.7 0-2.7-2.3-4.8-5.4-4.8z" />
                      </svg>
                      <span>প্রাণী বশ করুন</span>
                      <span className="hidden rounded-full bg-[#063826]/80 px-2 py-0.5 text-[11px] font-bold text-[#a8ffe0] lg:inline">
                        T
                      </span>
                    </button>
                  )}

                  {hud.nearVehicle !== null && (
                    <button
                      type="button"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        onMountVehicle();
                      }}
                      className={`font-bengali-display flex items-center gap-1.5 whitespace-nowrap rounded-full border-2 px-4 py-2 text-sm font-extrabold tracking-wide text-[#fff9eb] transition-transform hover:scale-[1.03] active:scale-95 sm:px-5 sm:py-2.5 sm:text-base ${
                        hud.nearVehicle === 'motorcycle'
                          ? 'border-[#ffd980] bg-gradient-to-b from-[#d95816] to-[#8a230b] shadow-[0_0_22px_rgba(245,120,38,0.6),0_8px_20px_rgba(0,0,0,0.55)]'
                          : 'border-[#a6ffd6] bg-gradient-to-b from-[#178a68] to-[#0c4f3d] shadow-[0_0_22px_rgba(40,210,145,0.58),0_8px_20px_rgba(0,0,0,0.55)]'
                      }`}
                    >
                      {hud.nearVehicle === 'motorcycle' ? (
                        <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-[#ffe28a] stroke-2 sm:h-5 sm:w-5">
                          <circle cx="6" cy="17" r="3" />
                          <circle cx="18" cy="17" r="3" />
                          <path d="M9 17h4l3-7h2" strokeLinecap="round" strokeLinejoin="round" />
                          <path d="M6 14l4-4h4" strokeLinecap="round" strokeLinejoin="round" />
                          <path d="M14 7h3" strokeLinecap="round" />
                        </svg>
                      ) : (
                        <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-[#b8ffe2] stroke-2 sm:h-5 sm:w-5">
                          <circle cx="6.5" cy="16.5" r="3" />
                          <circle cx="17.5" cy="16.5" r="3" />
                          <path d="M6.5 16.5L10.5 10h5l2 6.5" strokeLinecap="round" strokeLinejoin="round" />
                          <path d="M10.5 10l2 6.5" strokeLinecap="round" />
                          <path d="M9 8h2.5" strokeLinecap="round" />
                          <path d="M14.5 7.5h2.5" strokeLinecap="round" />
                        </svg>
                      )}
                      <span>
                        {hud.nearVehicle === 'motorcycle' ? 'বাইকে উঠুন' : 'সাইকেলে উঠুন'}
                      </span>
                      <span
                        className={`hidden rounded-full px-2 py-0.5 text-[11px] font-bold lg:inline ${
                          hud.nearVehicle === 'motorcycle'
                            ? 'bg-[#4f1305]/75 text-[#ffe194]'
                            : 'bg-[#073629]/75 text-[#b5ffe0]'
                        }`}
                      >
                        F
                      </span>
                    </button>
                  )}

                  {hud.nearChest && (
                    <button
                      type="button"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        onOpenChest();
                      }}
                      className="font-bengali-display flex items-center gap-1.5 whitespace-nowrap rounded-full border-2 border-[#ffe794] bg-gradient-to-b from-[#d9931c] to-[#8c4f0a] px-4 py-2 text-sm font-extrabold tracking-wide text-[#fff8e6] shadow-[0_0_20px_rgba(245,180,45,0.55),0_8px_20px_rgba(0,0,0,0.55)] transition-transform hover:scale-[1.03] active:scale-95 sm:px-5 sm:py-2.5 sm:text-base"
                    >
                      <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-[#ffe999] stroke-2 sm:h-5 sm:w-5">
                        <rect x="3" y="8" width="18" height="11" rx="2" />
                        <path d="M3 12h18" />
                        <path d="M5 8V6a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v2" />
                        <rect x="10.5" y="10.5" width="3" height="3.5" fill="#ffe999" />
                      </svg>
                      <span>সিন্দুক খুলুন</span>
                      <span className="hidden rounded-full bg-[#4a2604]/70 px-2 py-0.5 text-[11px] font-bold text-[#ffe58c] lg:inline">
                        F
                      </span>
                    </button>
                  )}

                  {hud.nearBus && (
                    <button
                      type="button"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        onEnterBus();
                      }}
                      className="font-bengali-display flex items-center gap-1.5 whitespace-nowrap rounded-full border-2 border-[#ffe27a] bg-gradient-to-b from-[#1772cc] to-[#0d4a8c] px-4 py-2 text-sm font-bold tracking-wide text-[#fff9e8] shadow-[0_0_20px_rgba(30,130,235,0.55),0_8px_20px_rgba(0,0,0,0.55)] transition-transform hover:scale-[1.03] active:scale-95 sm:px-5 sm:py-2.5 sm:text-base"
                    >
                      <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-[#ffe27a] stroke-2 sm:h-5 sm:w-5">
                        <rect x="4" y="5" width="16" height="12" rx="2" />
                        <line x1="4" y1="11" x2="20" y2="11" />
                        <circle cx="8" cy="17" r="1.5" fill="#ffe27a" />
                        <circle cx="16" cy="17" r="1.5" fill="#ffe27a" />
                      </svg>
                      <span>বাসে উঠুন</span>
                      <span className="hidden rounded-full bg-[#0a2f59] px-2 py-0.5 text-[11px] font-bold text-[#ffd85c] lg:inline">
                        F
                      </span>
                    </button>
                  )}
                </div>
              )}
            </div>
          )}
        </>
      )}

      {/* Non-overlapping Top-Center Pill Notification Stack */}
      {(hud.outsideStorm || hud.waveBanner || hud.pickupToast || missionToast) && (
        <div
          className={`pointer-events-none fixed left-1/2 z-20 flex w-max max-w-[92vw] -translate-x-1/2 flex-col items-center gap-1.5 ${
            hud.busMode === 'riding_intro'
              ? 'top-[calc(5.2rem+env(safe-area-inset-top))] sm:top-[6.2rem]'
              : 'top-[calc(7.6rem+env(safe-area-inset-top))] md:top-[4.4rem]'
          }`}
        >
          {hud.outsideStorm && (
            <div className="flex flex-col items-center gap-1 rounded-full border border-[#b98aff]/70 bg-black/55 px-4 py-1.5 backdrop-blur-md shadow-[0_8px_24px_rgba(0,0,0,0.5)] sm:px-5 sm:py-2">
              <div className="font-bengali-ui text-center text-xs font-bold text-[#ffe599] sm:text-sm">
                কালবৈশাখী ঝড়!{' '}
                <span className="tabular-nums text-[#8cf3ff]">
                  {toBengaliNumber(hud.outsideStormRemaining)}
                </span>{' '}
                সেকেন্ডের মধ্যে সেফ জোনে যান...
              </div>
              <div className="h-1.5 w-44 overflow-hidden rounded-full bg-white/15 sm:w-56">
                <div
                  style={{
                    width: `${Math.max(0, Math.min(100, (hud.outsideStormRemaining / 60) * 100))}%`,
                  }}
                  className="h-full rounded-full bg-gradient-to-r from-[#ff7a90] via-[#ffd76b] to-[#6beeff] transition-[width] duration-200"
                />
              </div>
            </div>
          )}

          {hud.waveBanner && (
            <div className="rounded-full border border-amber-400/60 bg-black/50 px-5 py-1.5 backdrop-blur-md shadow-[0_8px_28px_rgba(0,0,0,0.45)] sm:px-7 sm:py-2">
              <div className="font-bengali-display text-center text-base font-bold tracking-wide text-[#ffe094] sm:text-xl">
                {hud.waveBanner}
              </div>
            </div>
          )}

          {missionToast && (
            <div className="rounded-full border border-cyan-300/60 bg-black/55 px-4 py-1 text-center text-xs font-bold text-[#ffe599] backdrop-blur-md shadow-[0_6px_18px_rgba(0,0,0,0.48)] sm:px-5 sm:text-sm">
              {missionToast}
            </div>
          )}

          {hud.pickupToast && (
            <div className="rounded-full border border-amber-400/50 bg-black/50 px-4 py-1 text-center text-xs font-bold text-[#ffebc2] backdrop-blur-md sm:px-5 sm:text-sm">
              {hud.pickupToast}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
