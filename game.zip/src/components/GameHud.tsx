import React from 'react';
import { toBengaliNumber } from '../game/GameEngine';
import { CustomHudLayout } from '../game/settings';
import {
  HudSnapshot,
  WEAPON_CATALOG,
  WEAPON_SLOT_ORDER,
  WeaponType,
} from '../game/types';

interface GameHudProps {
  hud: HudSnapshot;
  customHud: CustomHudLayout;
  missionToast?: string | null;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  onOpenSettings: () => void;
  onPause: () => void;
  onToggleMute: () => void;
  onExitBus: () => void;
  onEnterBus: () => void;
  onMountVehicle: () => void;
  onBusHorn: () => void;
  onToggleBusCameraView: () => void;
  onSelectWeapon: (weapon: WeaponType) => void;
  onToggleScope: () => void;
  onUseSanjibani: () => void;
  onThrowGrenade: () => void;
  onOpenChest: () => void;
  onStartTaming: () => void;
}

function formatStormClock(seconds: number): string {
  const clamped = Math.max(0, Math.ceil(seconds));
  const mins = Math.floor(clamped / 60);
  const secs = clamped % 60;
  const secStr = secs < 10 ? `০${toBengaliNumber(secs)}` : toBengaliNumber(secs);
  return `${toBengaliNumber(mins)}:${secStr}`;
}

export const GameHud: React.FC<GameHudProps> = ({
  hud,
  customHud,
  missionToast,
  isFullscreen,
  onToggleFullscreen,
  onOpenSettings,
  onPause,
  onToggleMute,
  onExitBus,
  onEnterBus,
  onMountVehicle,
  onBusHorn,
  onToggleBusCameraView,
  onSelectWeapon,
  onToggleScope,
  onUseSanjibani,
  onThrowGrenade,
  onOpenChest,
  onStartTaming,
}) => {
  const healthPct = Math.max(0, Math.min(100, (hud.health / hud.maxHealth) * 100));
  const armorPct = Math.max(0, Math.min(100, (hud.armor / Math.max(1, hud.maxArmor)) * 100));
  const lowHealth = healthPct <= 30;
  const activeMeta = WEAPON_CATALOG[hud.activeWeapon];
  const lowAmmo =
    !activeMeta.isMelee &&
    hud.ammo <= Math.max(2, Math.floor(hud.maxAmmo * 0.25)) &&
    !hud.isReloading;
  const isOnFoot = hud.busMode === 'none' && hud.ridingVehicle === null;
  const showSniperScope =
    hud.scopeActive && hud.activeWeapon === 'trishul' && isOnFoot;

  const canHeal = !hud.isHealing && hud.sanjibaniCount > 0 && hud.health < hud.maxHealth;
  const canThrowGrenade = hud.grenadeCount > 0;

  const locationBadge = (
    <div className="flex items-center gap-1.5 rounded-md border border-[#b59c6b]/45 bg-[#121311]/90 px-3 py-1 text-[#ece6d8] shadow-[0_6px_16px_rgba(0,0,0,0.5)]">
      <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 shrink-0 fill-[#d9b566]">
        <path d="M10 2.2a5.3 5.3 0 0 0-5.3 5.3c0 3.7 4.4 8.8 4.8 9.2a.7.7 0 0 0 1 0c.4-.4 4.8-5.5 4.8-9.2A5.3 5.3 0 0 0 10 2.2zm0 7.2a2 2 0 1 1 0-4 2 2 0 0 1 0 4z" />
      </svg>
      <span className="font-bengali-ui whitespace-nowrap text-[11px] font-bold tracking-wide text-[#e8d9b5] sm:text-xs">
        {hud.locationName}
      </span>
    </div>
  );

  const stormBadge = (
    <div
      className={`flex items-center gap-1.5 rounded-md border px-3 py-1 shadow-[0_6px_16px_rgba(0,0,0,0.5)] ${
        hud.outsideStorm
          ? 'border-[#c95368]/80 bg-[#2b1017]/92 text-[#f0cfd6]'
          : hud.stormShrinking
            ? 'border-[#9a7ac4]/70 bg-[#191424]/92 text-[#ddd2eb]'
            : 'border-[#b59c6b]/45 bg-[#121311]/90 text-[#dcd4c4]'
      }`}
    >
      <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 shrink-0 fill-none stroke-current stroke-2">
        <circle cx="10" cy="10" r="7.5" strokeDasharray="3 2" />
        <path
          d="M10.8 5.2L7.5 10.4h2.8L9.2 14.8l3.6-5.2H10l.8-4.4z"
          className="fill-current"
          stroke="none"
        />
      </svg>
      <div className="font-bengali-ui flex items-center gap-1.5 whitespace-nowrap text-[11px] font-bold sm:text-xs">
        {hud.outsideStorm ? (
          <>
            <span>বলয়ের বাইরে!</span>
            <span className="tabular-nums text-[#ffe38a]">
              {toBengaliNumber(hud.outsideStormRemaining)} সে.
            </span>
          </>
        ) : hud.stormShrinking ? (
          <span>বলয় সংকুচিত হচ্ছে</span>
        ) : (
          <>
            <span className="text-[#d6c9ff]">ঝড়</span>
            <span className="tabular-nums text-[#fff0a8]">
              {formatStormClock(hud.stormCountdown)}
            </span>
          </>
        )}
      </div>
    </div>
  );

  return (
    <div className="pointer-events-none fixed inset-0 z-10 overflow-hidden">
      {/* Kalboishakhi Storm Screen Rim Tint when outside safe circle */}
      {hud.outsideStorm && (
        <div
          style={{
            boxShadow: 'inset 0 0 120px 42px rgba(108, 42, 214, 0.72)',
          }}
          className="pointer-events-none fixed inset-0"
        />
      )}

      {/* Dramatic Swirling Wind-Flash Visual Overlay on Kalboishakhi Storm Teleportation */}
      {hud.stormTeleportFlash > 0.02 && (
        <div
          style={{ opacity: Math.min(1, hud.stormTeleportFlash) }}
          className="pointer-events-none fixed inset-0 z-30 flex items-center justify-center overflow-hidden"
        >
          <div
            style={{
              background:
                'radial-gradient(circle at center, rgba(220, 248, 255, 0.75) 0%, rgba(124, 224, 255, 0.42) 34%, rgba(114, 62, 214, 0.55) 72%, rgba(18, 12, 34, 0.75) 100%)',
            }}
            className="absolute inset-0"
          />
          <svg
            viewBox="0 0 400 400"
            className="storm-vortex-swirl relative h-[120vmax] w-[120vmax]"
          >
            <path
              d="M 200 40 A 160 160 0 0 1 355 240"
              fill="none"
              stroke="#d9f9ff"
              strokeWidth="6"
              strokeLinecap="round"
              strokeOpacity="0.82"
            />
            <path
              d="M 340 200 A 140 140 0 0 1 110 308"
              fill="none"
              stroke="#8ceaff"
              strokeWidth="5"
              strokeLinecap="round"
              strokeOpacity="0.78"
            />
            <path
              d="M 85 180 A 115 115 0 0 1 280 110"
              fill="none"
              stroke="#ffe294"
              strokeWidth="4.5"
              strokeLinecap="round"
              strokeOpacity="0.72"
            />
            <path
              d="M 200 115 A 85 85 0 1 1 128 246"
              fill="none"
              stroke="#d8b8ff"
              strokeWidth="4"
              strokeLinecap="round"
              strokeOpacity="0.85"
            />
          </svg>
        </div>
      )}

      {/* Damage Red Vignette Flash */}
      {hud.damageFlash > 0.02 && (
        <div
          style={{
            opacity: Math.min(0.85, hud.damageFlash),
            boxShadow: 'inset 0 0 110px 36px rgba(196, 20, 24, 0.85)',
          }}
          className="pointer-events-none fixed inset-0"
        />
      )}

      {/* Trishul Sniper Scope Full-Screen Optic Overlay */}
      {showSniperScope && (
        <div className="pointer-events-none fixed inset-0 z-0 flex items-center justify-center">
          <div
            style={{
              background:
                'radial-gradient(circle at center, transparent 0%, transparent 33%, rgba(6, 9, 14, 0.88) 36%, rgba(4, 6, 10, 0.98) 54%)',
            }}
            className="absolute inset-0"
          />
          <svg
            viewBox="0 0 400 400"
            className="relative h-[min(74vmin,540px)] w-[min(74vmin,540px)]"
          >
            <circle
              cx="200"
              cy="200"
              r="184"
              fill="none"
              stroke="#9ad4ff"
              strokeOpacity="0.45"
              strokeWidth="2"
            />
            <circle
              cx="200"
              cy="200"
              r="176"
              fill="none"
              stroke="#e8c36e"
              strokeOpacity="0.3"
              strokeWidth="1"
            />
            <line
              x1="16"
              y1="200"
              x2="188"
              y2="200"
              stroke="#e9f4ff"
              strokeOpacity="0.82"
              strokeWidth="1.2"
            />
            <line
              x1="212"
              y1="200"
              x2="384"
              y2="200"
              stroke="#e9f4ff"
              strokeOpacity="0.82"
              strokeWidth="1.2"
            />
            <line
              x1="200"
              y1="16"
              x2="200"
              y2="188"
              stroke="#e9f4ff"
              strokeOpacity="0.82"
              strokeWidth="1.2"
            />
            <line
              x1="200"
              y1="212"
              x2="200"
              y2="384"
              stroke="#e9f4ff"
              strokeOpacity="0.82"
              strokeWidth="1.2"
            />
            {[110, 140, 170, 230, 260, 290].map((pos) => (
              <React.Fragment key={pos}>
                <line
                  x1={pos}
                  y1="195"
                  x2={pos}
                  y2="205"
                  stroke="#ffd268"
                  strokeOpacity="0.78"
                  strokeWidth="1.3"
                />
                <line
                  x1="195"
                  y1={pos}
                  x2="205"
                  y2={pos}
                  stroke="#ffd268"
                  strokeOpacity="0.78"
                  strokeWidth="1.3"
                />
              </React.Fragment>
            ))}
            <circle cx="200" cy="200" r="2.6" fill="#ff3b3b" />
          </svg>
          <div className="font-bengali-ui absolute bottom-[22%] rounded-md border border-[#7ea8bd]/55 bg-[#0f1316]/92 px-3 py-1 text-[11px] font-bold text-[#c6dce8]">
            ত্রিশূল স্কোপ · ৪x জুম
          </div>
        </div>
      )}

      {/* Top Perimeter Status Row — Strict Safe-Area Insets on Both Portrait & Landscape */}
      <div className="relative z-10 flex items-start justify-between gap-2 pl-[max(0.65rem,env(safe-area-inset-left))] pr-[max(0.65rem,env(safe-area-inset-right))] pt-[max(0.55rem,env(safe-area-inset-top))] sm:pl-[max(1.25rem,env(safe-area-inset-left))] sm:pr-[max(1.25rem,env(safe-area-inset-right))] sm:pt-[max(0.75rem,env(safe-area-inset-top))]">
        {/* Top-Left: Vitals Pill + Wave/Enemies/Score Pills + Headshot/Bodyshot Pill */}
        <div className="flex min-w-0 flex-col gap-1 sm:gap-1.5">
          {/* Tactical Matte Vitals Plate: Player LV + Raksha Kabach Shield + Health */}
          <div className="w-[154px] rounded-lg border border-[#b59c6b]/45 bg-[#121311]/90 px-2.5 py-1.5 shadow-[0_6px_18px_rgba(0,0,0,0.52)] sm:w-[228px] sm:px-3.5 sm:py-2">
            {/* Compact Player LV, Damage Bonus & Collected Animal Heart Counter */}
            <div className="mb-1 flex items-center justify-between gap-1">
              <div className="flex items-center gap-1">
                <span className="font-bengali-ui rounded-sm border border-[#b59c6b]/30 bg-[#1f201b] px-1.5 py-0.5 text-[9px] font-extrabold leading-none text-[#e0c078] sm:text-[10px]">
                  LV {toBengaliNumber(hud.playerLevel)}
                </span>
                {hud.weaponDamageBonusPct > 0 && (
                  <span className="font-bengali-ui text-[9px] font-bold leading-none text-[#ffb870] sm:text-[10px]">
                    +{toBengaliNumber(hud.weaponDamageBonusPct)}% ক্ষতি
                  </span>
                )}
              </div>
              <span className="font-bengali-ui inline-flex items-center gap-0.5 tabular-nums text-[9px] font-bold leading-none text-[#ff9bb2] sm:text-[10px]">
                <svg viewBox="0 0 20 20" className="h-2.5 w-2.5 shrink-0 fill-[#ff587a] sm:h-3 sm:w-3">
                  <path d="M10 17.2l-1.2-1.1C4.4 12.2 1.8 9.8 1.8 6.8 1.8 4.4 3.6 2.6 6 2.6c1.4 0 2.7.7 3.5 1.8h1c.8-1.1 2.1-1.8 3.5-1.8 2.4 0 4.2 1.8 4.2 4.2 0 3-2.6 5.4-7 9.3L10 17.2z" />
                </svg>
                {toBengaliNumber(hud.animalHearts.totalValue)}
              </span>
            </div>

            {/* Raksha Kabach Shield Bar */}
            <div className="mb-1">
              <div className="mb-0.5 flex items-center justify-between gap-1">
                <div className="flex items-center gap-1">
                  <svg viewBox="0 0 20 20" className="h-3 w-3 shrink-0 fill-[#4db8ff] sm:h-3.5 sm:w-3.5">
                    <path d="M10 2L3.5 4.8v4.7c0 4.1 2.7 7.8 6.5 9 3.8-1.2 6.5-4.9 6.5-9V4.8L10 2z" />
                  </svg>
                  <span className="font-bengali-ui text-[10px] font-bold tracking-wide text-[#a8dcff] sm:text-xs">
                    রক্ষা কবচ
                  </span>
                </div>
                <span className="font-bengali-ui tabular-nums text-[10px] font-bold text-[#8fd1ff] sm:text-xs">
                  {toBengaliNumber(hud.armor)}/{toBengaliNumber(hud.maxArmor)}
                </span>
              </div>
              <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/15 sm:h-2">
                <div
                  style={{ width: `${armorPct}%` }}
                  className="h-full rounded-full bg-gradient-to-r from-[#1d7ce0] via-[#3aa6ff] to-[#87dbff] transition-[width] duration-150"
                />
              </div>
            </div>

            {/* Health Bar ('স্বাস্থ্য') */}
            <div className="mb-1 flex items-center justify-between gap-1">
              <div className="flex items-center gap-1 sm:gap-1.5">
                <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 shrink-0 fill-[#e03a32] sm:h-4 sm:w-4">
                  <path d="M10 17.5l-1.2-1.1C4.4 12.5 1.8 10.1 1.8 7.1 1.8 4.7 3.7 2.8 6.1 2.8c1.4 0 2.7.7 3.9 1.8 1.2-1.1 2.5-1.8 3.9-1.8 2.4 0 4.3 1.9 4.3 4.3 0 3-2.6 5.4-7 9.3L10 17.5z" />
                </svg>
                <span className="font-bengali-ui text-xs font-bold tracking-wide text-[#fdf1dc] sm:text-sm">
                  স্বাস্থ্য
                </span>
              </div>
              <span
                className={`font-bengali-ui tabular-nums text-xs font-bold sm:text-sm ${
                  lowHealth ? 'text-[#ff6961]' : 'text-[#f8d794]'
                }`}
              >
                {toBengaliNumber(hud.health)}/{toBengaliNumber(hud.maxHealth)}
              </span>
            </div>
            <div className="h-2 w-full overflow-hidden rounded-full bg-white/15 sm:h-2.5">
              <div
                style={{ width: `${healthPct}%` }}
                className={`h-full rounded-full transition-[width] duration-150 ${
                  lowHealth ? 'bg-[#e32d2d]' : 'bg-gradient-to-r from-[#c42429] to-[#ef7d3b]'
                }`}
              />
            </div>
          </div>

          {/* Tactical Matte Stat Strip: Survival Mode (Wave/Enemies/Score) vs Pet Taming Mode */}
          {hud.gameMode === 'pet_taming' ? (
            <div className="flex flex-wrap items-center gap-1 sm:gap-1.5">
              <div className="rounded-md border border-[#5ea88a]/55 bg-[#111c17]/92 px-2.5 py-0.5 text-[10px] font-bold text-[#a6dec6] sm:px-3 sm:py-1 sm:text-xs">
                <span className="font-bengali-ui">প্রাণী বশ মোড</span>
              </div>
              <div className="inline-flex items-center gap-1 rounded-md border border-[#a84a5a]/60 bg-[#211115]/92 px-2.5 py-0.5 text-[10px] font-bold text-[#e8c6ce] sm:px-3 sm:py-1 sm:text-xs">
                <svg viewBox="0 0 20 20" className="h-3 w-3 shrink-0 fill-[#c93e54]">
                  <path d="M10 17.2l-1.2-1.1C4.4 12.2 1.8 9.8 1.8 6.8 1.8 4.4 3.6 2.6 6 2.6c1.4 0 2.7.7 3.5 1.8h1c.8-1.1 2.1-1.8 3.5-1.8 2.4 0 4.2 1.8 4.2 4.2 0 3-2.6 5.4-7 9.3L10 17.2z" />
                </svg>
                <span className="font-bengali-ui tabular-nums">
                  হার্ট: {toBengaliNumber(hud.animalHearts.totalValue)}
                </span>
              </div>
            </div>
          ) : (
            <>
              <div className="flex flex-wrap items-center gap-1 sm:gap-1.5">
                <div className="rounded-md border border-[#b59c6b]/40 bg-[#121311]/90 px-2.5 py-0.5 text-[10px] font-semibold text-[#ece6d8] sm:px-3 sm:py-1 sm:text-xs">
                  <span className="text-[#d9b566]">তরঙ্গ </span>
                  <span className="tabular-nums font-bold">{toBengaliNumber(hud.wave)}</span>
                </div>
                <div className="rounded-md border border-[#b59c6b]/40 bg-[#121311]/90 px-2.5 py-0.5 text-[10px] font-semibold text-[#ece6d8] sm:px-3 sm:py-1 sm:text-xs">
                  <span className="text-[#de7564]">শত্রু </span>
                  <span className="tabular-nums font-bold">{toBengaliNumber(hud.enemiesRemaining)}</span>
                </div>
                <div className="rounded-md border border-[#b59c6b]/40 bg-[#121311]/90 px-2.5 py-0.5 text-[10px] font-semibold text-[#ece6d8] sm:px-3 sm:py-1 sm:text-xs">
                  <span className="text-[#d9b566]">স্কোর </span>
                  <span className="tabular-nums font-bold">{toBengaliNumber(hud.score)}</span>
                </div>
              </div>

              {/* Live Headshot & Body Shot Plate */}
              <div className="inline-flex w-fit items-center gap-1.5 rounded-md border border-[#b59c6b]/40 bg-[#121311]/90 px-2.5 py-0.5 text-[10px] font-bold shadow-[0_4px_12px_rgba(0,0,0,0.45)] sm:px-3 sm:py-1 sm:text-xs">
                <span className="font-bengali-ui text-[#df6a64]">
                  হেডশট: <span className="tabular-nums text-[#f0d0ce]">{toBengaliNumber(hud.headshots)}</span>
                </span>
                <span className="text-[#b59c6b]/45">·</span>
                <span className="font-bengali-ui text-[#d9b870]">
                  বডিশট: <span className="tabular-nums text-[#ece6d8]">{toBengaliNumber(hud.bodyshots)}</span>
                </span>
              </div>
            </>
          )}

          {/* Permanent Lifetime Companion Badge with Live Scaled Stats (upgrades happen in lobby) */}
          {hud.permanentPet && (
            <div className="flex w-fit items-center gap-1.5 rounded-md border border-[#5ea88a]/50 bg-[#111c17]/92 px-2.5 py-1 text-[10px] font-bold text-[#c2e8d8] shadow-[0_4px_12px_rgba(0,0,0,0.45)] sm:px-3 sm:py-1 sm:text-xs">
              <svg viewBox="0 0 20 20" className="h-3 w-3 shrink-0 fill-[#66b898] sm:h-3.5 sm:w-3.5">
                <circle cx="6.2" cy="6.8" r="1.7" />
                <circle cx="10" cy="5.4" r="1.7" />
                <circle cx="13.8" cy="6.8" r="1.7" />
                <path d="M10 9.4c-2.6 0-4.6 1.8-4.6 4.1 0 1.4 1.2 2.3 2.5 2.3 1 0 1.5-.4 2.1-.4s1.1.4 2.1.4c1.3 0 2.5-.9 2.5-2.3 0-2.3-2-4.1-4.6-4.1z" />
              </svg>
              <span className="font-bengali-ui whitespace-nowrap">
                {hud.permanentPet.nameBn}
              </span>
              <span className="font-bengali-ui text-[9px] text-[#e0c078] sm:text-[10px]">
                · স্তর {toBengaliNumber(hud.permanentPet.upgrades.level)}
              </span>
              <span className="hidden font-bengali-ui text-[9px] text-[#8bc2ab] sm:inline">
                · ক্ষতি {toBengaliNumber(hud.permanentPet.stats.attackDamage)} · গতি {toBengaliNumber(hud.permanentPet.stats.moveSpeed)}
              </span>
            </div>
          )}

          {/* Subtle Exploration Prompt (Pet Taming Mode when no animal is spotted nearby) */}
          {hud.gameMode === 'pet_taming' && hud.busMode !== 'riding_intro' && !hud.wildAnimal && (
            <div className="w-[192px] rounded-lg border border-[#5ea88a]/40 bg-[#121513]/92 px-2.5 py-1.5 text-[#d4ebdf] shadow-[0_6px_16px_rgba(0,0,0,0.5)] sm:w-[258px] sm:px-3">
              <div className="font-bengali-ui text-[10px] font-bold text-[#95d4b9] sm:text-[11px]">
                জঙ্গল, গুহা, পাহাড়, জলাভূমি ও ধ্বংসাবশেষ খুঁজুন
              </div>
              <div className="font-bengali-ui mt-0.5 text-[9px] leading-snug text-[#b7c7be] sm:text-[10px]">
                বন্য প্রাণীরা বিভিন্ন এলাকায় লুকিয়ে আছে — ঘুরে ঘুরে খুঁজে বের করুন।
              </div>
            </div>
          )}

          {/* Close-Range Discovered Wild Animal Card (shown ONLY once player explores close or engages) */}
          {hud.busMode !== 'riding_intro' && hud.wildAnimal && (
            <div
              className={`w-[188px] rounded-lg border px-2.5 py-1.5 shadow-[0_6px_18px_rgba(0,0,0,0.56)] sm:w-[250px] sm:px-3 ${
                hud.wildAnimal.isSubdued
                  ? 'border-[#d6b368]/80 bg-[#1f1a10]/94 text-[#efe5cb]'
                  : hud.wildAnimal.hasAnimalHeart && hud.wildAnimal.heartTier === 4
                    ? 'border-[#d9ad4a]/85 bg-[#211a0d]/94 text-[#f2e6c4]'
                    : hud.wildAnimal.hasAnimalHeart && hud.wildAnimal.heartTier === 3
                      ? 'border-[#a573c9]/80 bg-[#1b1222]/94 text-[#e8d9f2]'
                      : hud.wildAnimal.hasAnimalHeart && hud.wildAnimal.heartTier === 2
                        ? 'border-[#5c9ec4]/75 bg-[#101a22]/94 text-[#d6e8f2]'
                        : hud.wildAnimal.hasAnimalHeart
                          ? 'border-[#b8566a]/75 bg-[#1f1215]/94 text-[#f0d8de]'
                          : 'border-[#b59c6b]/50 bg-[#121311]/92 text-[#e8dfd0]'
              }`}
            >
              <div className="mb-0.5 flex items-center justify-between gap-1 text-[10px] font-bold sm:text-[11px]">
                <span className="font-bengali-ui truncate">
                  {hud.wildAnimal.nameBn} · স্তর {toBengaliNumber(hud.wildAnimal.level)}
                </span>
                <span className="font-bengali-ui shrink-0 tabular-nums text-[#ffd978]">
                  {toBengaliNumber(hud.wildAnimal.distance)} মি.
                </span>
              </div>
              <div className="font-bengali-ui mb-1 text-[9px] font-bold">
                {hud.wildAnimal.hasAnimalHeart ? (
                  <span
                    className={
                      hud.wildAnimal.heartTier === 4
                        ? 'text-[#ffd95c]'
                        : hud.wildAnimal.heartTier === 3
                          ? 'text-[#e39eff]'
                          : hud.wildAnimal.heartTier === 2
                            ? 'text-[#7fd4ff]'
                            : 'text-[#ff8ea8]'
                    }
                  >
                    {hud.wildAnimal.heartTier === 4
                      ? 'কিংবদন্তি হৃদয়ধারী'
                      : hud.wildAnimal.heartTier === 3
                        ? 'মহাকাব্যিক হৃদয়ধারী'
                        : hud.wildAnimal.heartTier === 2
                          ? 'দুর্লভ হৃদয়ধারী'
                          : 'বিশেষ হৃদয়ধারী'}{' '}
                    · হার্ট (+{toBengaliNumber(hud.wildAnimal.heartValue)})
                  </span>
                ) : (
                  <span className="text-white/60">
                    {hud.wildAnimal.areaBn} · সাধারণ প্রাণী (হার্ট নেই)
                  </span>
                )}
              </div>
              <div className="relative h-1.5 w-full overflow-hidden rounded-full bg-white/15">
                <div
                  style={{
                    width: `${Math.max(0, Math.min(100, (hud.wildAnimal.hp / Math.max(1, hud.wildAnimal.maxHp)) * 100))}%`,
                  }}
                  className={`h-full rounded-full transition-[width] duration-150 ${
                    hud.wildAnimal.isSubdued
                      ? 'bg-gradient-to-r from-[#ffb72b] to-[#ffe678]'
                      : hud.wildAnimal.hasAnimalHeart && hud.wildAnimal.heartTier === 4
                        ? 'bg-gradient-to-r from-[#f59e0b] to-[#fde047]'
                        : hud.wildAnimal.hasAnimalHeart && hud.wildAnimal.heartTier === 3
                          ? 'bg-gradient-to-r from-[#9333ea] to-[#e879f9]'
                          : hud.wildAnimal.hasAnimalHeart && hud.wildAnimal.heartTier === 2
                            ? 'bg-gradient-to-r from-[#0284c7] to-[#38bdf8]'
                            : hud.wildAnimal.hasAnimalHeart
                              ? 'bg-gradient-to-r from-[#e12b5c] to-[#ff7652]'
                              : 'bg-gradient-to-r from-[#d93829] to-[#ff7b38]'
                  }`}
                />
                {/* Visual 22% Subdue Threshold Notch */}
                {hud.gameMode === 'pet_taming' && (
                  <div
                    style={{ left: `${Math.round(hud.wildAnimal.subdueRatio * 100)}%` }}
                    className="pointer-events-none absolute inset-y-0 w-0.5 bg-white shadow-[0_0_4px_#fff]"
                  />
                )}
              </div>
              <div className="font-bengali-ui mt-1 text-[9px] font-semibold leading-tight sm:text-[10px]">
                {hud.gameMode !== 'pet_taming' ? (
                  hud.wildAnimal.hasAnimalHeart ? (
                    <span className="text-[#ffc2d0]">বিশেষ প্রাণী · পরাজিত করলে এনিমেল হার্ট পাবেন</span>
                  ) : (
                    <span className="text-[#ffcaa0]">সাধারণ বন্য প্রাণী (এনিমেল হার্ট দেয় না)</span>
                  )
                ) : hud.wildAnimal.isSubdued ? (
                  hud.permanentPet ? (
                    hud.wildAnimal.hasAnimalHeart ? (
                      <span className="text-[#ffadc0]">দুর্বল · পরাজিত করলে এনিমেল হার্ট পাবেন</span>
                    ) : (
                      <span className="text-[#ffd2a6]">সাধারণ প্রাণী · এটি এনিমেল হার্ট দেয় না</span>
                    )
                  ) : (
                    <span className="text-[#9effc8]">দুর্বল (&lt;২২%)! দ্রুত সোনালি বলয়ে বশ করুন</span>
                  )
                ) : hud.permanentPet ? (
                  hud.wildAnimal.hasAnimalHeart ? (
                    <span className="text-[#ffc2d0]">বিশেষ হৃদয়ধারী · পরাজিত করে এনিমেল হার্ট সংগ্রহ করুন</span>
                  ) : (
                    <span className="text-[#ffd2a6]">সাধারণ প্রাণী — এটি এনিমেল হার্ট দেয় না</span>
                  )
                ) : (
                  <span className="text-[#ffcaa0]">২২% এর নিচে দুর্বল করুন (মারবেন না!)</span>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Top-Center: Location Pill + Kalboishakhi Storm Pill (Survival Mode only on Tablet/Desktop) */}
        <div className="hidden md:flex md:flex-col md:items-center md:gap-1.5">
          {locationBadge}
          {hud.gameMode === 'survival' && hud.busMode !== 'riding_intro' && stormBadge}
        </div>

        {/* Top-Right: Ammo / Bus Speed Pill + Circular Mute, Fullscreen, Settings & Pause + Mobile Location/Storm Pills */}
        <div className="flex shrink-0 flex-col items-end gap-1 sm:gap-1.5">
          <div className="flex items-center gap-1 sm:gap-2">
            {/* Desktop/Landscape inline Ammo or Bus Speed Plate */}
            <div className="hidden sm:block">
              {hud.busMode === 'driving' ? (
                <div className="rounded-md border border-[#b59c6b]/45 bg-[#121311]/90 px-3.5 py-1.5 text-right shadow-[0_6px_18px_rgba(0,0,0,0.5)]">
                  <div className="font-bengali-ui text-[10px] font-bold tracking-wide text-[#d9b566]">
                    WBTC বাস
                  </div>
                  <div className="font-bengali-ui tabular-nums text-sm font-bold leading-tight text-[#ece6d8] sm:text-base">
                    {toBengaliNumber(hud.busSpeedKmh)}{' '}
                    <span className="text-[10px] font-semibold text-[#96b9d1]">কিমি/ঘ</span>
                  </div>
                </div>
              ) : hud.ridingVehicle !== null ? (
                <div
                  className={`rounded-md border px-3.5 py-1.5 text-right shadow-[0_6px_18px_rgba(0,0,0,0.5)] ${
                    hud.ridingVehicle === 'motorcycle'
                      ? 'border-[#c9854a]/60 bg-[#121311]/92'
                      : 'border-[#5ea88a]/60 bg-[#121311]/92'
                  }`}
                >
                  <div
                    className={`font-bengali-ui text-[10px] font-bold tracking-wide ${
                      hud.ridingVehicle === 'motorcycle' ? 'text-[#dba063]' : 'text-[#7fc4a6]'
                    }`}
                  >
                    {hud.ridingVehicle === 'motorcycle' ? 'বাইক ভ্রমণ' : 'সাইকেল ভ্রমণ'}
                  </div>
                  <div className="font-bengali-ui tabular-nums text-sm font-bold leading-tight text-[#ece6d8] sm:text-base">
                    {toBengaliNumber(hud.vehicleSpeedKmh)}{' '}
                    <span className="text-[10px] font-semibold text-[#cbb896]">কিমি/ঘ</span>
                  </div>
                </div>
              ) : (
                <div className="rounded-md border border-[#b59c6b]/45 bg-[#121311]/90 px-3.5 py-1.5 text-right shadow-[0_6px_18px_rgba(0,0,0,0.5)]">
                  <div className="flex items-center justify-end gap-1">
                    <span className="font-bengali-ui text-xs font-bold text-[#d9b566]">
                      {activeMeta.shortName}
                    </span>
                    <span className="text-[#b59c6b]/45">·</span>
                    {activeMeta.isMelee ? (
                      <span className="font-bengali-ui text-xs font-bold text-[#d8e3eb]">
                        ছুরি
                      </span>
                    ) : hud.isReloading ? (
                      <span className="font-bengali-ui text-[10px] font-bold text-[#dfc078]">
                        রিলোড {toBengaliNumber(Math.round(hud.reloadProgress * 100))}%
                      </span>
                    ) : (
                      <span className="font-bengali-ui tabular-nums text-sm font-bold">
                        <span className={lowAmmo ? 'text-[#e05b53]' : 'text-[#ece6d8]'}>
                          {toBengaliNumber(hud.ammo)}
                        </span>
                        <span className="mx-0.5 text-[10px] text-[#9c907b]">/</span>
                        <span className="text-[11px] text-[#bfb5a2]">
                          {toBengaliNumber(hud.reserveAmmo)}
                        </span>
                      </span>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Tactical Mute Toggle */}
            <button
              type="button"
              onClick={onToggleMute}
              onPointerDown={(e) => e.stopPropagation()}
              aria-label={hud.muted ? 'শব্দ চালু করুন' : 'শব্দ বন্ধ করুন'}
              className="pointer-events-auto flex h-9 w-9 touch-none select-none items-center justify-center rounded-lg border border-[#b59c6b]/45 bg-[#121311]/90 text-[#e0d8c8] shadow-[0_4px_14px_rgba(0,0,0,0.5)] transition-colors hover:border-[#d9b566]/75 hover:bg-[#1e201c] active:scale-95 sm:h-10 sm:w-10"
            >
              {hud.muted ? (
                <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current stroke-2 sm:h-5 sm:w-5">
                  <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                  <line x1="22" y1="9" x2="16" y2="15" strokeLinecap="round" />
                  <line x1="16" y1="9" x2="22" y2="15" strokeLinecap="round" />
                </svg>
              ) : (
                <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current stroke-2 sm:h-5 sm:w-5">
                  <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                  <path d="M15.5 8.5a5 5 0 0 1 0 7" strokeLinecap="round" />
                  <path d="M18.8 5.5a9 9 0 0 1 0 13" strokeLinecap="round" />
                </svg>
              )}
            </button>

            {/* Tactical Fullscreen Toggle */}
            <button
              type="button"
              onClick={onToggleFullscreen}
              onPointerDown={(e) => e.stopPropagation()}
              aria-label={isFullscreen ? 'ফুলস্ক্রিন বন্ধ করুন' : 'ফুলস্ক্রিন চালু করুন'}
              title={isFullscreen ? 'ফুলস্ক্রিন বন্ধ' : 'ফুলস্ক্রিন'}
              className={`pointer-events-auto flex h-9 w-9 touch-none select-none items-center justify-center rounded-lg border shadow-[0_4px_14px_rgba(0,0,0,0.5)] transition-colors hover:bg-[#1e201c] active:scale-95 sm:h-10 sm:w-10 ${
                isFullscreen
                  ? 'border-[#d9b566]/80 bg-[#27231a]/95 text-[#f0e5c8]'
                  : 'border-[#b59c6b]/45 bg-[#121311]/90 text-[#e0d8c8]'
              }`}
            >
              {isFullscreen ? (
                <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current stroke-2 sm:h-5 sm:w-5">
                  <path d="M9 4v5H4" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M15 4v5h5" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M9 20v-5H4" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M15 20v-5h5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              ) : (
                <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current stroke-2 sm:h-5 sm:w-5">
                  <path d="M4 9V4h5" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M20 9V4h-5" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M4 15v5h5" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M20 15v5h-5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              )}
            </button>

            {/* Tactical Settings Button (সেটিংস — right next to Pause) */}
            <button
              type="button"
              onClick={onOpenSettings}
              onPointerDown={(e) => e.stopPropagation()}
              aria-label="সেটিংস"
              title="সেটিংস"
              className="pointer-events-auto flex h-9 w-9 touch-none select-none items-center justify-center rounded-lg border border-[#b59c6b]/45 bg-[#121311]/90 text-[#e2c994] shadow-[0_4px_14px_rgba(0,0,0,0.5)] transition-colors hover:border-[#d9b566]/80 hover:bg-[#1e201c] active:scale-95 sm:h-10 sm:w-10"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current stroke-2 sm:h-5 sm:w-5">
                <circle cx="12" cy="12" r="3" />
                <path
                  d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.08a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h.08a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v.08a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>

            {/* Tactical Pause Button */}
            <button
              type="button"
              onClick={onPause}
              onPointerDown={(e) => e.stopPropagation()}
              aria-label="বিরতি"
              className="pointer-events-auto flex h-9 w-9 touch-none select-none items-center justify-center rounded-lg border border-[#b59c6b]/45 bg-[#121311]/90 text-[#e0d8c8] shadow-[0_4px_14px_rgba(0,0,0,0.5)] transition-colors hover:border-[#d9b566]/75 hover:bg-[#1e201c] active:scale-95 sm:h-10 sm:w-10"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 fill-current sm:h-5 sm:w-5">
                <rect x="6" y="5" width="4" height="14" rx="1.5" />
                <rect x="14" y="5" width="4" height="14" rx="1.5" />
              </svg>
            </button>
          </div>

          {/* Mobile Portrait Compact Ammo/Bus Plate (prevents horizontal crowding on narrow screens) */}
          <div className="sm:hidden">
            {hud.busMode === 'driving' ? (
              <div className="rounded-md border border-[#b59c6b]/45 bg-[#121311]/90 px-2.5 py-0.5 text-right shadow-[0_4px_12px_rgba(0,0,0,0.48)]">
                <span className="font-bengali-ui tabular-nums text-[11px] font-bold text-[#ece6d8]">
                  WBTC · {toBengaliNumber(hud.busSpeedKmh)} কিমি/ঘ
                </span>
              </div>
            ) : hud.ridingVehicle !== null ? (
              <div
                className={`rounded-md border px-2.5 py-0.5 text-right shadow-[0_4px_12px_rgba(0,0,0,0.48)] ${
                  hud.ridingVehicle === 'motorcycle'
                    ? 'border-[#c9854a]/60 bg-[#121311]/92'
                    : 'border-[#5ea88a]/60 bg-[#121311]/92'
                }`}
              >
                <span className="font-bengali-ui tabular-nums text-[11px] font-bold text-[#ece6d8]">
                  {hud.ridingVehicle === 'motorcycle' ? 'বাইক' : 'সাইকেল'} ·{' '}
                  {toBengaliNumber(hud.vehicleSpeedKmh)} কিমি/ঘ
                </span>
              </div>
            ) : (
              <div className="rounded-md border border-[#b59c6b]/45 bg-[#121311]/90 px-2.5 py-0.5 text-right shadow-[0_4px_12px_rgba(0,0,0,0.48)]">
                <div className="flex items-center justify-end gap-1">
                  <span className="font-bengali-ui text-[10px] font-bold text-[#d9b566]">
                    {activeMeta.shortName}
                  </span>
                  <span className="text-[#b59c6b]/45">·</span>
                  {activeMeta.isMelee ? (
                    <span className="font-bengali-ui text-[10px] font-bold text-[#d8e3eb]">ছুরি</span>
                  ) : hud.isReloading ? (
                    <span className="font-bengali-ui text-[10px] font-bold text-[#dfc078]">
                      রিলোড {toBengaliNumber(Math.round(hud.reloadProgress * 100))}%
                    </span>
                  ) : (
                    <span className="font-bengali-ui tabular-nums text-[11px] font-bold">
                      <span className={lowAmmo ? 'text-[#e05b53]' : 'text-[#ece6d8]'}>
                        {toBengaliNumber(hud.ammo)}
                      </span>
                      <span className="mx-0.5 text-[9px] text-[#9c907b]">/</span>
                      <span className="text-[10px] text-[#bfb5a2]">
                        {toBengaliNumber(hud.reserveAmmo)}
                      </span>
                    </span>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Mobile Location Plate + Storm Plate (Survival Mode only) stacked cleanly under top-right */}
          <div className="flex flex-col items-end gap-1 md:hidden">
            {locationBadge}
            {hud.gameMode === 'survival' && hud.busMode !== 'riding_intro' && stormBadge}
          </div>

          {/* Compact Corner Minimap / Radar (Player Position + Nearby/Active Enemy Locations) */}
          {hud.busMode !== 'riding_intro' && (
            <div
              aria-label="রাডার মিনিম্যাপ"
              className="pointer-events-none relative mt-0.5 h-[84px] w-[84px] shrink-0 overflow-hidden rounded-full border border-[#b59c6b]/55 bg-[#0d120f]/92 shadow-[0_6px_18px_rgba(0,0,0,0.65)] sm:h-[106px] sm:w-[106px]"
            >
              <svg viewBox="0 0 100 100" className="h-full w-full">
                {/* Tactical radar background rings & crosshairs */}
                <circle cx="50" cy="50" r="46" fill="none" stroke="rgba(245,194,71,0.22)" strokeWidth="1" />
                <circle
                  cx="50"
                  cy="50"
                  r="30"
                  fill="none"
                  stroke="rgba(120,235,180,0.2)"
                  strokeWidth="0.9"
                  strokeDasharray="2.5 2.5"
                />
                <circle
                  cx="50"
                  cy="50"
                  r="15"
                  fill="none"
                  stroke="rgba(120,235,180,0.18)"
                  strokeWidth="0.8"
                />
                <line x1="50" y1="5" x2="50" y2="95" stroke="rgba(255,255,255,0.1)" strokeWidth="0.7" />
                <line x1="5" y1="50" x2="95" y2="50" stroke="rgba(255,255,255,0.1)" strokeWidth="0.7" />

                {/* Subtle forward field-of-view cone */}
                <path
                  d="M 50 50 L 32 14 A 40 40 0 0 1 68 14 Z"
                  fill="rgba(77,245,184,0.11)"
                />

                {/* Rotating North ('উ') rim indicator */}
                <g transform={`rotate(${hud.radarNorthDeg} 50 50)`}>
                  <circle cx="50" cy="6.5" r="4.8" fill="rgba(14,22,18,0.9)" stroke="#f5c247" strokeWidth="0.8" />
                  <text
                    x="50"
                    y="8.7"
                    textAnchor="middle"
                    fontSize="6"
                    fontWeight="bold"
                    fill="#ffe07d"
                  >
                    উ
                  </text>
                </g>

                {/* Active Enemies, Wild Animal & Pet Blips */}
                {hud.radarBlips.map((blip, idx) => {
                  const cx = 50 + blip.x * 42;
                  const cy = 50 - blip.y * 42;
                  if (blip.kind === 'pet') {
                    return (
                      <circle
                        key={`p-${idx}`}
                        cx={cx}
                        cy={cy}
                        r="2.4"
                        fill="#4df5b8"
                        stroke="#09241a"
                        strokeWidth="0.8"
                      />
                    );
                  }
                  if (blip.kind === 'wild_heart' || blip.kind === 'wild') {
                    const color = blip.kind === 'wild_heart' ? '#ff5882' : '#ffd24c';
                    return (
                      <g key={`w-${idx}`}>
                        <circle cx={cx} cy={cy} r="5.2" fill={color} fillOpacity="0.24" />
                        <circle
                          cx={cx}
                          cy={cy}
                          r={blip.clamped ? '2.8' : '3.3'}
                          fill={color}
                          stroke="#ffffff"
                          strokeWidth="0.8"
                        />
                      </g>
                    );
                  }
                  const isHeavy = blip.kind === 'heavy';
                  const dotR = blip.clamped ? (isHeavy ? 2.6 : 2.2) : isHeavy ? 3.5 : 2.9;
                  const dotFill = blip.clamped ? '#ff8452' : isHeavy ? '#ff2a55' : '#ff3d3d';
                  return (
                    <g key={`e-${idx}`}>
                      {!blip.clamped && (
                        <circle cx={cx} cy={cy} r={dotR + 2} fill={dotFill} fillOpacity="0.22" />
                      )}
                      <circle
                        cx={cx}
                        cy={cy}
                        r={dotR}
                        fill={dotFill}
                        stroke="#fff2e6"
                        strokeWidth="0.7"
                      />
                    </g>
                  );
                })}

                {/* Centered Player Position & Facing Chevron */}
                <polygon
                  points="50,43.5 54.4,54 50,51.6 45.6,54"
                  fill="#6bffc7"
                  stroke="#09241a"
                  strokeWidth="0.9"
                />
              </svg>
            </div>
          )}
        </div>
      </div>

      {/* Center Reticle, Dynamic Spread, Hitmarker & Directional Damage Arc */}
      {isOnFoot && (
        <div className="pointer-events-none fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          {/* Directional Incoming Damage Indicator Arc */}
          {hud.damageFlash > 0.05 && hud.damageAngle !== null && (
            <div
              style={{
                opacity: Math.min(0.95, hud.damageFlash * 1.15),
                transform: `translate(-50%, -50%) rotate(${Math.round((hud.damageAngle * 180) / Math.PI)}deg)`,
              }}
              className="pointer-events-none absolute left-1/2 top-1/2 h-36 w-36 sm:h-44 sm:w-44"
            >
              <svg viewBox="0 0 120 120" className="h-full w-full drop-shadow-[0_0_8px_rgba(255,34,34,0.85)]">
                <path
                  d="M 38 14 A 48 48 0 0 1 82 14"
                  fill="none"
                  stroke="#ff2b2b"
                  strokeWidth="6.5"
                  strokeLinecap="round"
                />
                <polygon points="60,2 54,12 66,12" fill="#ff5454" />
              </svg>
            </div>
          )}

          {(() => {
            const spreadPx = Math.round(
              Math.min(14, Math.max(0, hud.reticleSpread) * (hud.scopeActive ? 5 : 13)),
            );
            const hitScale =
              hud.hitMarker > 0.05
                ? (hud.hitMarkerHeadshot || hud.hitMarkerKill ? 1.18 : 1.0) +
                  Math.sin(Math.min(1, hud.hitMarker) * Math.PI) * 0.28
                : 1;
            return (
              <div
                className={`relative h-10 w-10 transition-transform duration-150 ${
                  hud.scopeActive && !showSniperScope ? 'scale-90' : 'scale-100'
                }`}
              >
                {!showSniperScope && (
                  <>
                    <span
                      style={{ transform: `translate(-50%, ${-spreadPx}px)` }}
                      className="absolute left-1/2 top-1 h-2.5 w-[2px] rounded-full bg-[#fff8e8]/95 shadow-[0_0_3px_rgba(0,0,0,0.95)]"
                    />
                    <span
                      style={{ transform: `translate(-50%, ${spreadPx}px)` }}
                      className="absolute bottom-1 left-1/2 h-2.5 w-[2px] rounded-full bg-[#fff8e8]/95 shadow-[0_0_3px_rgba(0,0,0,0.95)]"
                    />
                    <span
                      style={{ transform: `translate(${-spreadPx}px, -50%)` }}
                      className="absolute left-1 top-1/2 h-[2px] w-2.5 rounded-full bg-[#fff8e8]/95 shadow-[0_0_3px_rgba(0,0,0,0.95)]"
                    />
                    <span
                      style={{ transform: `translate(${spreadPx}px, -50%)` }}
                      className="absolute right-1 top-1/2 h-[2px] w-2.5 rounded-full bg-[#fff8e8]/95 shadow-[0_0_3px_rgba(0,0,0,0.95)]"
                    />
                    <span
                      className={`absolute left-1/2 top-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full ring-1 ring-black/70 ${
                        hud.scopeActive
                          ? 'bg-cyan-300 shadow-[0_0_8px_#38bdf8]'
                          : 'bg-[#ffd25a] shadow-[0_0_4px_rgba(0,0,0,0.9)]'
                      }`}
                    />
                  </>
                )}

                {hud.hitMarker > 0.05 && (
                  <svg
                    viewBox="0 0 40 40"
                    style={{
                      opacity: Math.min(1, hud.hitMarker * 1.2),
                      transform: `scale(${hitScale.toFixed(3)})`,
                    }}
                    className="absolute inset-0 h-10 w-10 drop-shadow-[0_0_5px_rgba(0,0,0,0.9)]"
                  >
                    <g
                      stroke={
                        hud.hitMarkerHeadshot
                          ? '#ff2424'
                          : hud.hitMarkerKill
                            ? '#ff3d2e'
                            : '#fff3b8'
                      }
                      strokeWidth={hud.hitMarkerHeadshot ? 3.5 : hud.hitMarkerKill ? 3.1 : 2.4}
                      strokeLinecap="round"
                    >
                      <line x1="6" y1="6" x2="14.5" y2="14.5" />
                      <line x1="34" y1="6" x2="25.5" y2="14.5" />
                      <line x1="6" y1="34" x2="14.5" y2="25.5" />
                      <line x1="34" y1="34" x2="25.5" y2="25.5" />
                    </g>
                    {(hud.hitMarkerHeadshot || hud.hitMarkerKill) && (
                      <circle
                        cx="20"
                        cy="20"
                        r={hud.hitMarkerHeadshot ? 13 : 11}
                        fill="none"
                        stroke={hud.hitMarkerHeadshot ? '#ffd859' : '#ff5247'}
                        strokeWidth="1.6"
                        strokeDasharray="4 4"
                      />
                    )}
                  </svg>
                )}
              </div>
            );
          })()}
        </div>
      )}

      {/* WBTC INTRO BUS RIDE UI: Tactical Route Plate + Controls */}
      {hud.busMode === 'riding_intro' && (
        <>
          <div className="pointer-events-none fixed left-1/2 top-[max(1rem,env(safe-area-inset-top))] hidden -translate-x-1/2 flex-col items-center rounded-lg border border-[#b59c6b]/45 bg-[#121311]/92 px-5 py-2 shadow-[0_8px_24px_rgba(0,0,0,0.6)] sm:flex">
            <div className="flex items-center gap-2 text-xs font-bold text-[#d9b566]">
              <span>WBTC S-12</span>
              <span className="text-[#82a8bf]">•</span>
              <span className="font-bengali-ui text-[#ece6d8]">{hud.busZoneLabel || 'হাওড়া সেতু'}</span>
              <span className="rounded-sm bg-[#163326] px-2 py-0.5 font-bengali-ui text-[10px] font-bold text-[#95d9b8]">
                নিরাপদ অবতরণ
              </span>
            </div>
            <div className="mt-1.5 h-1.5 w-48 overflow-hidden rounded-sm bg-white/15">
              <div
                style={{ width: `${Math.round(hud.busRouteProgress * 100)}%` }}
                className="h-full rounded-sm bg-gradient-to-r from-[#4b8bb8] via-[#c99a38] to-[#b84c35]"
              />
            </div>
          </div>

          <div className="pointer-events-auto fixed bottom-[max(1rem,env(safe-area-inset-bottom))] left-1/2 z-30 flex w-max max-w-[94vw] -translate-x-1/2 flex-col items-center gap-2 sm:bottom-7">
            <div className="flex items-center gap-2 rounded-md border border-[#b59c6b]/45 bg-[#121311]/92 px-3.5 py-1 text-xs font-semibold text-[#dfd7c8] sm:hidden">
              <span>{hud.busZoneLabel || 'হাওড়া সেতু'}</span>
              <span className="rounded-sm bg-[#163326] px-2 py-0.5 text-[10px] font-bold text-[#95d9b8]">
                নিরাপদ
              </span>
            </div>
            <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3">
              <button
                type="button"
                onClick={onToggleBusCameraView}
                aria-label={hud.busInteriorCam ? 'বাইরের দৃশ্য' : 'ভিতরের দৃশ্য'}
                className="font-bengali-ui flex h-11 items-center gap-1.5 whitespace-nowrap rounded-lg border border-[#b59c6b]/45 bg-[#121311]/92 px-4 text-xs font-bold text-[#ece6d8] shadow-[0_6px_18px_rgba(0,0,0,0.58)] transition-colors hover:bg-[#1e201c] active:scale-95 sm:h-12 sm:px-5 sm:text-sm"
              >
                <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-[#d9b566] stroke-2 sm:h-5 sm:w-5">
                  <path d="M2 12s3.8-6.5 10-6.5S22 12 22 12s-3.8 6.5-10 6.5S2 12 2 12z" />
                  <circle cx="12" cy="12" r="3" />
                </svg>
                <span>{hud.busInteriorCam ? 'বাইরের দৃশ্য' : 'ভিতরের দৃশ্য'}</span>
                <span className="hidden rounded-sm bg-white/10 px-1.5 py-0.5 text-[10px] font-bold text-[#9ec0d6] sm:inline">
                  V
                </span>
              </button>

              <button
                type="button"
                onClick={onExitBus}
                disabled={hud.busExitSlowing}
                className={`font-bengali-display flex items-center gap-2 whitespace-nowrap rounded-lg border px-6 py-3 text-base font-extrabold tracking-wide transition-all sm:gap-2.5 sm:px-8 sm:py-3.5 sm:text-xl ${
                  hud.busExitSlowing
                    ? 'cursor-wait border-[#dec07c]/70 bg-gradient-to-b from-[#9c6f1d] to-[#6e4a10] text-[#f2e8d0] shadow-[0_10px_24px_rgba(0,0,0,0.65)]'
                    : 'border-[#e0c482]/80 bg-gradient-to-b from-[#bd8b2c] via-[#9c6f1d] to-[#6e4a10] text-[#140e06] shadow-[0_10px_24px_rgba(0,0,0,0.68),inset_0_1px_0_rgba(255,244,210,0.28)] hover:brightness-110 active:scale-[0.97]'
                }`}
              >
                <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-[2.4] sm:h-6 sm:w-6">
                  <path d="M9 4h8a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H9" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M13 12H3m0 0l4-4m-4 4l4 4" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                <span>{hud.busExitSlowing ? 'বাস থামছে... দরজা খুলছে' : 'বাস থেকে নামুন'}</span>
              </button>

              <button
                type="button"
                onClick={onBusHorn}
                aria-label="হর্ন বাজান"
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border border-[#b59c6b]/45 bg-[#121311]/92 text-[#dfc078] shadow-[0_6px_18px_rgba(0,0,0,0.58)] hover:bg-[#1e201c] active:scale-95 sm:h-12 sm:w-12"
              >
                <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-2">
                  <path d="M3 14v-4h4l6-4v12l-6-4H3z" strokeLinejoin="round" />
                  <path d="M17 9a4 4 0 0 1 0 6" strokeLinecap="round" />
                  <path d="M19.5 6.5a7.5 7.5 0 0 1 0 11" strokeLinecap="round" />
                </svg>
              </button>
            </div>
            <span className="font-bengali-ui text-center text-[11px] font-semibold text-[#f8e7c5] drop-shadow sm:text-xs">
              পছন্দের জায়গায় সরাসরি নামতে Space / F চাপুন · দৃশ্য বদলাতে V চাপুন
            </span>
          </div>
        </>
      )}

      {/* ON-FOOT CONTROLS: Customizable Scope, Weapon Bar, Sanjibani & Bajra Gola inside Safe-Area Stage */}
      {isOnFoot && (
        <>
          <div
            className="touch-controls-root pointer-events-none fixed z-25 touch-none select-none"
            style={{
              top: 'env(safe-area-inset-top, 0px)',
              right: 'env(safe-area-inset-right, 0px)',
              bottom: 'env(safe-area-inset-bottom, 0px)',
              left: 'env(safe-area-inset-left, 0px)',
            }}
          >
            {/* Customizable Circular Zoom / Scope Button ('স্কোপ' / 'জুম আউট') */}
            <div
              className="pointer-events-auto absolute touch-none select-none"
              style={{
                left: `${customHud.scope.x}%`,
                top: `${customHud.scope.y}%`,
                transform: `translate(-50%, -50%) scale(${customHud.scope.size})`,
                opacity: customHud.scope.opacity,
              }}
            >
              <button
                type="button"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onToggleScope();
                }}
                aria-pressed={hud.scopeActive}
                aria-label={hud.scopeActive ? 'জুম আউট' : 'স্কোপ জুম ইন'}
                className={`touch-control-btn flex h-14 w-14 touch-none select-none flex-col items-center justify-center rounded-full border transition-all duration-150 active:scale-95 sm:h-16 sm:w-16 ${
                  hud.scopeActive
                    ? 'border-[#7ec0db] bg-[#132933]/92 text-[#d6edf7] ring-1 ring-[#7ec0db]/75 shadow-[0_8px_20px_rgba(0,0,0,0.62)]'
                    : 'border-[#b59c6b]/45 bg-[#121311]/88 text-[#ece6d8] shadow-[0_8px_20px_rgba(0,0,0,0.58)] hover:border-[#d9b566]/80 hover:bg-[#1c1d1a]/94'
                }`}
              >
                <svg viewBox="0 0 24 24" className="pointer-events-none h-5 w-5 fill-none stroke-current stroke-[2.1] sm:h-6 sm:w-6">
                  <circle cx="12" cy="12" r="7" />
                  <line x1="12" y1="2.5" x2="12" y2="6.5" strokeLinecap="round" />
                  <line x1="12" y1="17.5" x2="12" y2="21.5" strokeLinecap="round" />
                  <line x1="2.5" y1="12" x2="6.5" y2="12" strokeLinecap="round" />
                  <line x1="17.5" y1="12" x2="21.5" y2="12" strokeLinecap="round" />
                  {hud.scopeActive ? (
                    <line x1="9" y1="12" x2="15" y2="12" strokeLinecap="round" />
                  ) : (
                    <>
                      <line x1="9" y1="12" x2="15" y2="12" strokeLinecap="round" />
                      <line x1="12" y1="9" x2="12" y2="15" strokeLinecap="round" />
                    </>
                  )}
                </svg>
                <span className="font-bengali-ui pointer-events-none mt-0.5 whitespace-nowrap text-[9px] font-bold leading-none sm:text-[10px]">
                  {hud.scopeActive ? 'জুম আউট' : 'স্কোপ'}
                </span>
              </button>
            </div>

            {/* Customizable 4-Slot Weapon Bar */}
            <div
              className="pointer-events-auto absolute touch-none select-none"
              style={{
                left: `${customHud.weapons.x}%`,
                top: `${customHud.weapons.y}%`,
                transform: `translate(-50%, -50%) scale(${customHud.weapons.size})`,
                opacity: customHud.weapons.opacity,
              }}
            >
              <div className="flex w-max max-w-[92vw] items-center gap-1 rounded-lg border border-[#b59c6b]/45 bg-[#121311]/92 p-1 shadow-[0_8px_22px_rgba(0,0,0,0.6)] sm:gap-1.5 sm:p-1.5">
                {WEAPON_SLOT_ORDER.map((weaponId) => {
                  const meta = WEAPON_CATALOG[weaponId];
                  const slotState = hud.weapons[weaponId];
                  const selected = hud.activeWeapon === weaponId;
                  return (
                    <button
                      key={weaponId}
                      type="button"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        onSelectWeapon(weaponId);
                      }}
                      className={`touch-control-btn relative flex touch-none select-none items-center gap-1 whitespace-nowrap rounded-md border px-2 py-1.5 transition-colors active:scale-95 sm:gap-1.5 sm:px-3 sm:py-1.5 ${
                        selected
                          ? 'border-[#d9b566]/85 bg-[#292318] text-[#f2e8d2]'
                          : 'border-transparent bg-white/5 text-[#cfc6b4] hover:bg-white/10'
                      }`}
                    >
                      <span className="font-bengali-ui pointer-events-none text-[10px] font-bold leading-none sm:text-xs">
                        {meta.shortName}
                      </span>
                      <span
                        className={`font-bengali-ui tabular-nums pointer-events-none text-[9px] font-extrabold leading-none sm:text-[10px] ${
                          selected ? 'text-[#e0c078]' : 'text-[#a89d88]'
                        }`}
                      >
                        {meta.isMelee ? '∞' : toBengaliNumber(slotState.ammo)}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Customizable Circular সঞ্জীবনী গাছ (Sanjibani Healing Plant) Button */}
            <div
              className="pointer-events-auto absolute touch-none select-none"
              style={{
                left: `${customHud.sanjibani.x}%`,
                top: `${customHud.sanjibani.y}%`,
                transform: `translate(-50%, -50%) scale(${customHud.sanjibani.size})`,
                opacity: customHud.sanjibani.opacity,
              }}
            >
              <button
                type="button"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onUseSanjibani();
                }}
                disabled={!canHeal && !hud.isHealing}
                aria-label="সঞ্জীবনী গাছ ব্যবহার করুন"
                title="সঞ্জীবনী গাছ"
                className={`touch-control-btn relative flex h-12 w-12 shrink-0 touch-none select-none flex-col items-center justify-center rounded-full border shadow-[0_6px_16px_rgba(0,0,0,0.55)] transition-colors active:scale-95 sm:h-14 sm:w-14 ${
                  hud.isHealing
                    ? 'border-[#6eb898] bg-[#163628]/94 text-[#d6f5e6] ring-1 ring-[#6eb898]/70'
                    : canHeal
                      ? 'border-[#b59c6b]/45 bg-[#121311]/88 text-[#cbe8d8] hover:border-[#6eb898]/80 hover:bg-[#14261e]/94'
                      : 'border-[#b59c6b]/25 bg-[#121311]/70 text-[#809488]/65'
                }`}
              >
                {hud.isHealing && (
                  <div
                    style={{ height: `${Math.round(hud.healProgress * 100)}%` }}
                    className="pointer-events-none absolute inset-x-0 bottom-0 rounded-full bg-[#4a9c74]/35"
                  />
                )}
                <svg viewBox="0 0 24 24" className="pointer-events-none relative h-4 w-4 shrink-0 fill-[#54b882] sm:h-5 sm:w-5">
                  <path d="M17 8C8 10 5.9 16.17 3.82 21.34l1.89.66.95-2.3c.48.17.98.3 1.34.3C19 20 22 3 22 3c-1 2-8 2.25-13 3.25S2 11.5 2 13.5s1.75 3.75 1.75 3.75C7 8 17 8 17 8z" />
                </svg>
                <span className="font-bengali-ui pointer-events-none relative mt-0.5 text-[8px] font-bold leading-none sm:text-[9px]">
                  সঞ্জীবনী
                </span>
                <span className="font-bengali-ui tabular-nums pointer-events-none absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full border border-[#6eb898]/65 bg-[#11241b] px-1 text-[9px] font-extrabold text-[#98dec0]">
                  {toBengaliNumber(hud.sanjibaniCount)}
                </span>
              </button>
            </div>

            {/* Customizable Circular বজ্র গোলা (Bajra Gola Grenade) Button */}
            <div
              className="pointer-events-auto absolute touch-none select-none"
              style={{
                left: `${customHud.grenade.x}%`,
                top: `${customHud.grenade.y}%`,
                transform: `translate(-50%, -50%) scale(${customHud.grenade.size})`,
                opacity: customHud.grenade.opacity,
              }}
            >
              <button
                type="button"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onThrowGrenade();
                }}
                disabled={!canThrowGrenade}
                aria-label="বজ্র গোলা নিক্ষেপ করুন"
                title="বজ্র গোলা"
                className={`touch-control-btn relative flex h-12 w-12 shrink-0 touch-none select-none flex-col items-center justify-center rounded-full border shadow-[0_6px_16px_rgba(0,0,0,0.55)] transition-colors active:scale-95 sm:h-14 sm:w-14 ${
                  canThrowGrenade
                    ? 'border-[#b59c6b]/45 bg-[#121311]/88 text-[#e8d9c4] hover:border-[#d9b566]/80 hover:bg-[#241c13]/94'
                    : 'border-[#b59c6b]/25 bg-[#121311]/70 text-[#8a8075]/60'
                }`}
              >
                <svg viewBox="0 0 24 24" className="pointer-events-none h-4 w-4 shrink-0 fill-none stroke-[#ffae52] stroke-2 sm:h-5 sm:w-5">
                  <circle cx="12" cy="14" r="6" fill="#ff9436" fillOpacity="0.28" />
                  <path d="M10 8V5h4v3" />
                  <path d="M14 5l3-2" strokeLinecap="round" />
                </svg>
                <span className="font-bengali-ui pointer-events-none mt-0.5 text-[8px] font-bold leading-none sm:text-[9px]">
                  বজ্র গোলা
                </span>
                <span className="font-bengali-ui tabular-nums pointer-events-none absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full border border-amber-300/60 bg-amber-950 px-1 text-[9px] font-extrabold text-[#ffc978]">
                  {toBengaliNumber(hud.grenadeCount)}
                </span>
              </button>
            </div>
          </div>

          {/* Contextual Action Pills ('প্রাণী বশ করুন', 'সিন্দুক খুলুন', 'সাইকেল/বাইক', 'বাসে উঠুন') + Taming & Sanjibani Progress Bars */}
          {(hud.nearChest ||
            hud.nearBus ||
            hud.nearVehicle !== null ||
            hud.isHealing ||
            hud.tamingActive ||
            hud.wildAnimal?.canTame ||
            hud.wildAnimal?.blockedByLifetimeLimit) && (
            <div className="pointer-events-none fixed bottom-[calc(4.75rem+env(safe-area-inset-bottom))] left-1/2 z-30 flex w-max max-w-[92vw] -translate-x-1/2 flex-col items-center gap-2 sm:bottom-[calc(5.25rem+env(safe-area-inset-bottom))]">
              {hud.tamingActive && (
                <div className="flex w-64 flex-col gap-1.5 rounded-lg border border-[#6eb898]/75 bg-[#111c17]/95 px-4 py-2.5 shadow-[0_10px_24px_rgba(0,0,0,0.7)] sm:w-72">
                  <div className="flex items-center justify-between text-xs font-extrabold text-[#b4e6cf]">
                    <span className="font-bengali-ui">প্রাণী বশ হচ্ছে...</span>
                    <span className="font-bengali-ui tabular-nums text-[#e0c078]">
                      {toBengaliNumber(Math.round(hud.tamingProgress * 100))}%
                    </span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-sm bg-white/15">
                    <div
                      style={{ width: `${Math.round(hud.tamingProgress * 100)}%` }}
                      className="h-full rounded-sm bg-gradient-to-r from-[#2c8a64] via-[#5bb58f] to-[#d9b566]"
                    />
                  </div>
                  {hud.tamingStatusText && (
                    <div className="font-bengali-ui text-center text-[10px] font-semibold text-[#d2ebdf]">
                      {hud.tamingStatusText}
                    </div>
                  )}
                </div>
              )}

              {hud.isHealing && (
                <div className="flex w-52 flex-col gap-1 rounded-md border border-[#5ea88a]/65 bg-[#121613]/94 px-4 py-2 shadow-[0_8px_20px_rgba(0,0,0,0.6)]">
                  <div className="flex items-center justify-between text-[11px] font-bold text-[#a3dec1]">
                    <span className="font-bengali-ui">সঞ্জীবনী নিরাময়...</span>
                    <span className="font-bengali-ui tabular-nums">
                      {toBengaliNumber(Math.round(hud.healProgress * 100))}%
                    </span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-sm bg-white/15">
                    <div
                      style={{ width: `${Math.round(hud.healProgress * 100)}%` }}
                      className="h-full rounded-sm bg-gradient-to-r from-[#2d8a5a] to-[#74c798]"
                    />
                  </div>
                </div>
              )}

              {!hud.tamingActive && hud.wildAnimal?.blockedByLifetimeLimit && (
                <div className="rounded-md border border-[#b59c6b]/55 bg-[#121311]/94 px-4 py-1.5 text-center text-[11px] font-bold text-[#e6d5b2] shadow-[0_6px_18px_rgba(0,0,0,0.6)]">
                  <span className="font-bengali-ui">
                    আজীবনে ১টিই সঙ্গী অনুমোদিত — আপনার আইডি-তে ({hud.playerId}) ইতিমধ্যেই স্থায়ী সঙ্গী আছে
                  </span>
                </div>
              )}

              {(hud.nearChest ||
                hud.nearBus ||
                hud.nearVehicle !== null ||
                (!hud.tamingActive && hud.wildAnimal?.canTame)) && (
                <div className="pointer-events-auto flex flex-wrap items-center justify-center gap-2">
                  {!hud.tamingActive && hud.wildAnimal?.canTame && (
                    <button
                      type="button"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        onStartTaming();
                      }}
                      className="font-bengali-display flex items-center gap-1.5 whitespace-nowrap rounded-lg border border-[#7bc4a4]/75 bg-gradient-to-b from-[#24664e] to-[#143d2e] px-4 py-2 text-sm font-extrabold tracking-wide text-[#e8f6ef] shadow-[0_8px_20px_rgba(0,0,0,0.65)] transition hover:brightness-110 active:scale-95 sm:px-5 sm:py-2.5 sm:text-base"
                    >
                      <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-[#9ee0c4] sm:h-5 sm:w-5">
                        <circle cx="7.5" cy="8.5" r="2" />
                        <circle cx="12" cy="6.8" r="2" />
                        <circle cx="16.5" cy="8.5" r="2" />
                        <path d="M12 11.4c-3.1 0-5.4 2.1-5.4 4.8 0 1.6 1.4 2.7 3 2.7 1.1 0 1.8-.4 2.4-.4s1.3.4 2.4.4c1.6 0 3-1.1 3-2.7 0-2.7-2.3-4.8-5.4-4.8z" />
                      </svg>
                      <span>প্রাণী বশ করুন</span>
                      <span className="hidden rounded-sm bg-[#0c261c]/80 px-2 py-0.5 text-[11px] font-bold text-[#9ee0c4] lg:inline">
                        T
                      </span>
                    </button>
                  )}

                  {hud.nearVehicle !== null && (
                    <button
                      type="button"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        onMountVehicle();
                      }}
                      className={`font-bengali-display flex items-center gap-1.5 whitespace-nowrap rounded-lg border px-4 py-2 text-sm font-extrabold tracking-wide text-[#f4ede0] shadow-[0_8px_20px_rgba(0,0,0,0.65)] transition hover:brightness-110 active:scale-95 sm:px-5 sm:py-2.5 sm:text-base ${
                        hud.nearVehicle === 'motorcycle'
                          ? 'border-[#d6a267]/75 bg-gradient-to-b from-[#9c4519] to-[#63260b]'
                          : 'border-[#7bc4a4]/75 bg-gradient-to-b from-[#21634c] to-[#123b2d]'
                      }`}
                    >
                      {hud.nearVehicle === 'motorcycle' ? (
                        <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-[#e6c48a] stroke-2 sm:h-5 sm:w-5">
                          <circle cx="6" cy="17" r="3" />
                          <circle cx="18" cy="17" r="3" />
                          <path d="M9 17h4l3-7h2" strokeLinecap="round" strokeLinejoin="round" />
                          <path d="M6 14l4-4h4" strokeLinecap="round" strokeLinejoin="round" />
                          <path d="M14 7h3" strokeLinecap="round" />
                        </svg>
                      ) : (
                        <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-[#a3dec4] stroke-2 sm:h-5 sm:w-5">
                          <circle cx="6.5" cy="16.5" r="3" />
                          <circle cx="17.5" cy="16.5" r="3" />
                          <path d="M6.5 16.5L10.5 10h5l2 6.5" strokeLinecap="round" strokeLinejoin="round" />
                          <path d="M10.5 10l2 6.5" strokeLinecap="round" />
                          <path d="M9 8h2.5" strokeLinecap="round" />
                          <path d="M14.5 7.5h2.5" strokeLinecap="round" />
                        </svg>
                      )}
                      <span>
                        {hud.nearVehicle === 'motorcycle' ? 'বাইকে উঠুন' : 'সাইকেলে উঠুন'}
                      </span>
                      <span
                        className={`hidden rounded-sm px-2 py-0.5 text-[11px] font-bold lg:inline ${
                          hud.nearVehicle === 'motorcycle'
                            ? 'bg-[#3d1505]/75 text-[#e6c48a]'
                            : 'bg-[#0a261d]/75 text-[#a3dec4]'
                        }`}
                      >
                        F
                      </span>
                    </button>
                  )}

                  {hud.nearChest && (
                    <button
                      type="button"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        onOpenChest();
                      }}
                      className="font-bengali-display flex items-center gap-1.5 whitespace-nowrap rounded-lg border border-[#dec07c]/75 bg-gradient-to-b from-[#a87822] to-[#6e4910] px-4 py-2 text-sm font-extrabold tracking-wide text-[#171007] shadow-[0_8px_20px_rgba(0,0,0,0.65)] transition hover:brightness-110 active:scale-95 sm:px-5 sm:py-2.5 sm:text-base"
                    >
                      <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-current stroke-2 sm:h-5 sm:w-5">
                        <rect x="3" y="8" width="18" height="11" rx="2" />
                        <path d="M3 12h18" />
                        <path d="M5 8V6a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v2" />
                        <rect x="10.5" y="10.5" width="3" height="3.5" fill="currentColor" />
                      </svg>
                      <span>সিন্দুক খুলুন</span>
                      <span className="hidden rounded-sm bg-[#291805]/30 px-2 py-0.5 text-[11px] font-bold text-[#171007] lg:inline">
                        F
                      </span>
                    </button>
                  )}

                  {hud.nearBus && (
                    <button
                      type="button"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        onEnterBus();
                      }}
                      className="font-bengali-display flex items-center gap-1.5 whitespace-nowrap rounded-lg border border-[#82b2d6]/70 bg-gradient-to-b from-[#255d8f] to-[#163a5c] px-4 py-2 text-sm font-bold tracking-wide text-[#ebf2f7] shadow-[0_8px_20px_rgba(0,0,0,0.65)] transition hover:brightness-110 active:scale-95 sm:px-5 sm:py-2.5 sm:text-base"
                    >
                      <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-[#d9b566] stroke-2 sm:h-5 sm:w-5">
                        <rect x="4" y="5" width="16" height="12" rx="2" />
                        <line x1="4" y1="11" x2="20" y2="11" />
                        <circle cx="8" cy="17" r="1.5" fill="#d9b566" />
                        <circle cx="16" cy="17" r="1.5" fill="#d9b566" />
                      </svg>
                      <span>বাসে উঠুন</span>
                      <span className="hidden rounded-sm bg-[#0c2338] px-2 py-0.5 text-[11px] font-bold text-[#d9b566] lg:inline">
                        F
                      </span>
                    </button>
                  )}
                </div>
              )}
            </div>
          )}
        </>
      )}

      {/* Non-overlapping Top-Center Notification Stack */}
      {(hud.outsideStorm || hud.levelUpNotice || hud.waveBanner || hud.pickupToast || missionToast) && (
        <div
          className={`pointer-events-none fixed left-1/2 z-20 flex w-max max-w-[92vw] -translate-x-1/2 flex-col items-center gap-1.5 ${
            hud.busMode === 'riding_intro'
              ? 'top-[calc(5.2rem+env(safe-area-inset-top))] sm:top-[6.2rem]'
              : 'top-[calc(7.6rem+env(safe-area-inset-top))] md:top-[4.4rem]'
          }`}
        >
          {hud.levelUpNotice && (
            <div
              key={hud.levelUpNotice.seq}
              className="flex flex-col items-center rounded-lg border border-[#d6b368]/75 bg-[#151613]/95 px-4 py-2 text-center shadow-[0_12px_26px_rgba(0,0,0,0.72)] sm:px-6 sm:py-2.5"
            >
              {(hud.levelUpNotice.target === 'player' || hud.levelUpNotice.target === 'both') && (
                <>
                  <div className="font-bengali-display text-sm font-extrabold tracking-wide text-[#e2c278] sm:text-lg">
                    লেভেল আপ! ভানু · LV {toBengaliNumber(hud.levelUpNotice.playerLevel)}
                  </div>
                  <div className="font-bengali-ui mt-0.5 text-[10px] font-bold text-[#e6dcc6] sm:text-xs">
                    সর্বোচ্চ স্বাস্থ্য +{toBengaliNumber(hud.levelUpNotice.playerHpGain)} · অস্ত্রের ক্ষতি +{toBengaliNumber(hud.levelUpNotice.playerDmgBonusPct)}%
                  </div>
                </>
              )}
              {(hud.levelUpNotice.target === 'pet' || hud.levelUpNotice.target === 'both') &&
                hud.levelUpNotice.petNameBn &&
                hud.levelUpNotice.petLevel && (
                  <div
                    className={
                      hud.levelUpNotice.target === 'both'
                        ? 'mt-1 border-t border-[#5ea88a]/30 pt-1'
                        : ''
                    }
                  >
                    <div className="font-bengali-display text-xs font-extrabold tracking-wide text-[#8ad1b3] sm:text-base">
                      {hud.levelUpNotice.petNameBn} লেভেল আপ! স্তর {toBengaliNumber(hud.levelUpNotice.petLevel)}
                    </div>
                    <div className="font-bengali-ui mt-0.5 text-[10px] font-bold text-[#cde8dc] sm:text-xs">
                      স্বাস্থ্য +{toBengaliNumber(hud.levelUpNotice.petHpGain ?? 0)} · ক্ষতি +{toBengaliNumber(hud.levelUpNotice.petDmgGain ?? 0)} · গতি +{toBengaliNumber(hud.levelUpNotice.petSpeedGain ?? 0)}
                    </div>
                  </div>
                )}
            </div>
          )}

          {hud.outsideStorm && (
            <div className="flex flex-col items-center gap-1 rounded-md border border-[#9a7ac4]/70 bg-[#171321]/94 px-4 py-1.5 shadow-[0_8px_22px_rgba(0,0,0,0.62)] sm:px-5 sm:py-2">
              <div className="font-bengali-ui text-center text-xs font-bold text-[#e6d19e] sm:text-sm">
                কালবৈশাখী ঝড়!{' '}
                <span className="tabular-nums text-[#96d1e3]">
                  {toBengaliNumber(hud.outsideStormRemaining)}
                </span>{' '}
                সেকেন্ডের মধ্যে সেফ জোনে যান...
              </div>
              <div className="h-1.5 w-44 overflow-hidden rounded-sm bg-white/15 sm:w-56">
                <div
                  style={{
                    width: `${Math.max(0, Math.min(100, (hud.outsideStormRemaining / 60) * 100))}%`,
                  }}
                  className="h-full rounded-sm bg-gradient-to-r from-[#c95368] via-[#d9b566] to-[#6aaec7] transition-[width] duration-200"
                />
              </div>
            </div>
          )}

          {hud.waveBanner && (
            <div className="rounded-md border border-[#b59c6b]/55 bg-[#121311]/94 px-5 py-1.5 shadow-[0_8px_24px_rgba(0,0,0,0.62)] sm:px-7 sm:py-2">
              <div className="font-bengali-display text-center text-base font-bold tracking-wide text-[#e2c278] sm:text-xl">
                {hud.waveBanner}
              </div>
            </div>
          )}

          {missionToast && (
            <div className="rounded-md border border-[#6a98a8]/60 bg-[#111517]/94 px-4 py-1 text-center text-xs font-bold text-[#e6d5b2] shadow-[0_6px_18px_rgba(0,0,0,0.58)] sm:px-5 sm:text-sm">
              {missionToast}
            </div>
          )}

          {hud.pickupToast && (
            <div className="rounded-md border border-[#b59c6b]/45 bg-[#121311]/92 px-4 py-1 text-center text-xs font-bold text-[#ece6d8] sm:px-5 sm:text-sm">
              {hud.pickupToast}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
