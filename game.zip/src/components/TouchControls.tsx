import React, { useEffect, useRef, useState } from 'react';
import { CustomHudLayout } from '../game/settings';
import { BusMode, TwoWheelerKind, WEAPON_CATALOG, WeaponType } from '../game/types';

interface TouchControlsProps {
  busMode: BusMode;
  ridingVehicle: TwoWheelerKind | null;
  activeWeapon: WeaponType;
  customHud: CustomHudLayout;
  onMove: (x: number, y: number) => void;
  onShootChange: (shooting: boolean) => void;
  onToggleSprint: () => void;
  onReload: () => void;
  onJump: () => void;
  onCrouch: () => void;
  onExitBus: () => void;
  onBusHorn: () => void;
  onDismountVehicle: () => void;
  isReloading: boolean;
  isSprinting: boolean;
  isCrouching: boolean;
  isJumping: boolean;
  ammo: number;
  maxAmmo: number;
  reserveAmmo: number;
}

const DEADZONE = 0.1;

function safeSetCapture(el: Element, pointerId: number): void {
  try {
    el.setPointerCapture(pointerId);
  } catch {
    // Ignore synthetic or non-capturable pointer events
  }
}

function safeReleaseCapture(el: Element, pointerId: number): void {
  try {
    if (el.hasPointerCapture(pointerId)) {
      el.releasePointerCapture(pointerId);
    }
  } catch {
    // Ignore already-released capture
  }
}

export const TouchControls: React.FC<TouchControlsProps> = ({
  busMode,
  ridingVehicle,
  activeWeapon,
  customHud,
  onMove,
  onShootChange,
  onToggleSprint,
  onReload,
  onJump,
  onCrouch,
  onExitBus,
  onBusHorn,
  onDismountVehicle,
  isReloading,
  isSprinting,
  isCrouching,
  isJumping,
  ammo,
  maxAmmo,
  reserveAmmo,
}) => {
  const baseRef = useRef<HTMLDivElement | null>(null);

  // Independent per-control pointerId tracking so joystick + 2+ action buttons work simultaneously
  const joyPointerId = useRef<number | null>(null);
  const shootPointerId = useRef<number | null>(null);
  const sprintPointerId = useRef<number | null>(null);
  const reloadPointerId = useRef<number | null>(null);
  const jumpPointerId = useRef<number | null>(null);
  const crouchPointerId = useRef<number | null>(null);
  const hornPointerId = useRef<number | null>(null);
  const exitBusPointerId = useRef<number | null>(null);
  const dismountVehiclePointerId = useRef<number | null>(null);

  const [knobOffset, setKnobOffset] = useState({ x: 0, y: 0 });
  const [joyActive, setJoyActive] = useState(false);
  const [shootPressed, setShootPressed] = useState(false);
  const [sprintPressed, setSprintPressed] = useState(false);
  const [reloadPressed, setReloadPressed] = useState(false);
  const [jumpPressed, setJumpPressed] = useState(false);
  const [crouchPressed, setCrouchPressed] = useState(false);
  const [hornPressed, setHornPressed] = useState(false);
  const [exitBusPressed, setExitBusPressed] = useState(false);
  const [dismountPressed, setDismountPressed] = useState(false);

  // Release all active touch pointers cleanly when switching between bus, bike/cycle & on-foot modes
  useEffect(() => {
    joyPointerId.current = null;
    shootPointerId.current = null;
    sprintPointerId.current = null;
    reloadPointerId.current = null;
    jumpPointerId.current = null;
    crouchPointerId.current = null;
    hornPointerId.current = null;
    exitBusPointerId.current = null;
    dismountVehiclePointerId.current = null;
    setJoyActive(false);
    setKnobOffset({ x: 0, y: 0 });
    setShootPressed(false);
    setSprintPressed(false);
    setReloadPressed(false);
    setJumpPressed(false);
    setCrouchPressed(false);
    setHornPressed(false);
    setExitBusPressed(false);
    setDismountPressed(false);
    onMove(0, 0);
    onShootChange(false);
  }, [busMode, ridingVehicle, onMove, onShootChange]);

  // Ensure move & shoot inputs are cleanly released if TouchControls unmounts (e.g. opening Settings/Custom HUD)
  useEffect(() => {
    return () => {
      onMove(0, 0);
      onShootChange(false);
    };
  }, [onMove, onShootChange]);

  // Hide touch shooter/steering pads while watching the WBTC intro bus drop-in
  if (busMode === 'riding_intro') return null;

  const joyCfg = customHud.joystick;
  const shootCfg = customHud.shoot;
  const reloadCfg = customHud.reload;
  const sprintCfg = customHud.sprint;
  const jumpCfg = customHud.jump;
  const crouchCfg = customHud.crouch;

  const updateJoystick = (clientX: number, clientY: number) => {
    const el = baseRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const scale = Math.max(0.5, joyCfg.size);
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const maxRadius = Math.max(26, (rect.width / scale) * 0.37);

    let dx = (clientX - cx) / scale;
    let dy = (clientY - cy) / scale;
    const dist = Math.hypot(dx, dy);

    if (dist > maxRadius) {
      dx = (dx / dist) * maxRadius;
      dy = (dy / dist) * maxRadius;
    }

    setKnobOffset({ x: dx, y: dy });

    const nx = dx / maxRadius;
    const ny = -dy / maxRadius; // forward is up on screen
    const mag = Math.hypot(nx, ny);
    if (mag < DEADZONE) {
      onMove(0, 0);
    } else {
      onMove(nx, ny);
    }
  };

  // --- Joystick Multi-Touch Handlers ---
  const handleJoyDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.stopPropagation();
    if (joyPointerId.current !== null && joyPointerId.current !== e.pointerId) return;
    joyPointerId.current = e.pointerId;
    safeSetCapture(e.currentTarget, e.pointerId);
    setJoyActive(true);
    updateJoystick(e.clientX, e.clientY);
  };

  const handleJoyMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerId !== joyPointerId.current) return;
    e.stopPropagation();
    updateJoystick(e.clientX, e.clientY);
  };

  const handleJoyEnd = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerId !== joyPointerId.current) return;
    e.stopPropagation();
    safeReleaseCapture(e.currentTarget, e.pointerId);
    joyPointerId.current = null;
    setJoyActive(false);
    setKnobOffset({ x: 0, y: 0 });
    onMove(0, 0);
  };

  // --- Shoot / Melee Hold Multi-Touch Handlers ---
  const handleShootDown = (e: React.PointerEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    if (shootPointerId.current !== null && shootPointerId.current !== e.pointerId) return;
    shootPointerId.current = e.pointerId;
    safeSetCapture(e.currentTarget, e.pointerId);
    setShootPressed(true);
    onShootChange(true);
  };

  const handleShootMove = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerId !== shootPointerId.current) return;
    e.stopPropagation();
  };

  const handleShootEnd = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerId !== shootPointerId.current) return;
    e.stopPropagation();
    safeReleaseCapture(e.currentTarget, e.pointerId);
    shootPointerId.current = null;
    setShootPressed(false);
    onShootChange(false);
  };

  // --- Tap-to-Toggle Sprint (দৌড়) Multi-Touch Handlers (Free Fire style) ---
  const handleSprintDown = (e: React.PointerEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    if (sprintPointerId.current !== null && sprintPointerId.current !== e.pointerId) return;
    sprintPointerId.current = e.pointerId;
    safeSetCapture(e.currentTarget, e.pointerId);
    setSprintPressed(true);
    onToggleSprint();
  };

  const handleSprintMove = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerId !== sprintPointerId.current) return;
    e.stopPropagation();
  };

  const handleSprintEnd = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerId !== sprintPointerId.current) return;
    e.stopPropagation();
    safeReleaseCapture(e.currentTarget, e.pointerId);
    sprintPointerId.current = null;
    setSprintPressed(false);
  };

  // --- Reload Multi-Touch Handlers ---
  const handleReloadDown = (e: React.PointerEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    if (reloadPointerId.current !== null && reloadPointerId.current !== e.pointerId) return;
    reloadPointerId.current = e.pointerId;
    safeSetCapture(e.currentTarget, e.pointerId);
    setReloadPressed(true);
    onReload();
  };

  const handleReloadMove = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerId !== reloadPointerId.current) return;
    e.stopPropagation();
  };

  const handleReloadEnd = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerId !== reloadPointerId.current) return;
    e.stopPropagation();
    safeReleaseCapture(e.currentTarget, e.pointerId);
    reloadPointerId.current = null;
    setReloadPressed(false);
  };

  // --- Jump (জাম্প) Multi-Touch Handlers ---
  const handleJumpDown = (e: React.PointerEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    if (jumpPointerId.current !== null && jumpPointerId.current !== e.pointerId) return;
    jumpPointerId.current = e.pointerId;
    safeSetCapture(e.currentTarget, e.pointerId);
    setJumpPressed(true);
    onJump();
  };

  const handleJumpMove = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerId !== jumpPointerId.current) return;
    e.stopPropagation();
  };

  const handleJumpEnd = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerId !== jumpPointerId.current) return;
    e.stopPropagation();
    safeReleaseCapture(e.currentTarget, e.pointerId);
    jumpPointerId.current = null;
    setJumpPressed(false);
  };

  // --- Crouch/Sit (বসা) Multi-Touch Handlers ---
  const handleCrouchDown = (e: React.PointerEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    if (crouchPointerId.current !== null && crouchPointerId.current !== e.pointerId) return;
    crouchPointerId.current = e.pointerId;
    safeSetCapture(e.currentTarget, e.pointerId);
    setCrouchPressed(true);
    onCrouch();
  };

  const handleCrouchMove = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerId !== crouchPointerId.current) return;
    e.stopPropagation();
  };

  const handleCrouchEnd = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerId !== crouchPointerId.current) return;
    e.stopPropagation();
    safeReleaseCapture(e.currentTarget, e.pointerId);
    crouchPointerId.current = null;
    setCrouchPressed(false);
  };

  // --- Bus Horn Multi-Touch Handlers ---
  const handleHornDown = (e: React.PointerEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    if (hornPointerId.current !== null && hornPointerId.current !== e.pointerId) return;
    hornPointerId.current = e.pointerId;
    safeSetCapture(e.currentTarget, e.pointerId);
    setHornPressed(true);
    onBusHorn();
  };

  const handleHornMove = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerId !== hornPointerId.current) return;
    e.stopPropagation();
  };

  const handleHornEnd = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerId !== hornPointerId.current) return;
    e.stopPropagation();
    safeReleaseCapture(e.currentTarget, e.pointerId);
    hornPointerId.current = null;
    setHornPressed(false);
  };

  // --- Exit Bus Multi-Touch Handlers ---
  const handleExitBusDown = (e: React.PointerEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    if (exitBusPointerId.current !== null && exitBusPointerId.current !== e.pointerId) return;
    exitBusPointerId.current = e.pointerId;
    safeSetCapture(e.currentTarget, e.pointerId);
    setExitBusPressed(true);
    onExitBus();
  };

  const handleExitBusMove = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerId !== exitBusPointerId.current) return;
    e.stopPropagation();
  };

  const handleExitBusEnd = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerId !== exitBusPointerId.current) return;
    e.stopPropagation();
    safeReleaseCapture(e.currentTarget, e.pointerId);
    exitBusPointerId.current = null;
    setExitBusPressed(false);
  };

  // --- Dismount Bicycle / Motorcycle Multi-Touch Handlers ---
  const handleDismountDown = (e: React.PointerEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    if (dismountVehiclePointerId.current !== null && dismountVehiclePointerId.current !== e.pointerId) return;
    dismountVehiclePointerId.current = e.pointerId;
    safeSetCapture(e.currentTarget, e.pointerId);
    setDismountPressed(true);
    onDismountVehicle();
  };

  const handleDismountMove = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerId !== dismountVehiclePointerId.current) return;
    e.stopPropagation();
  };

  const handleDismountEnd = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerId !== dismountVehiclePointerId.current) return;
    e.stopPropagation();
    safeReleaseCapture(e.currentTarget, e.pointerId);
    dismountVehiclePointerId.current = null;
    setDismountPressed(false);
  };

  const isMelee = WEAPON_CATALOG[activeWeapon].isMelee;
  const canReload = !isMelee && !isReloading && ammo < maxAmmo && reserveAmmo > 0;
  const isDriving = busMode === 'driving';
  const isRidingTwoWheeler = ridingVehicle !== null;

  return (
    <div
      className="touch-controls-root pointer-events-none fixed z-20 touch-none select-none"
      style={{
        top: 'env(safe-area-inset-top, 0px)',
        right: 'env(safe-area-inset-right, 0px)',
        bottom: 'env(safe-area-inset-bottom, 0px)',
        left: 'env(safe-area-inset-left, 0px)',
      }}
    >
      {/* Customizable Translucent Circular Virtual Joystick */}
      <div
        className="touch-controls-root pointer-events-auto absolute flex shrink-0 touch-none select-none flex-col items-center gap-1"
        style={{
          left: `${joyCfg.x}%`,
          top: `${joyCfg.y}%`,
          transform: `translate(-50%, -50%) scale(${joyCfg.size})`,
          opacity: joyCfg.opacity,
        }}
      >
        <div
          ref={baseRef}
          onPointerDown={handleJoyDown}
          onPointerMove={handleJoyMove}
          onPointerUp={handleJoyEnd}
          onPointerCancel={handleJoyEnd}
          onLostPointerCapture={handleJoyEnd}
          aria-label={
            isDriving
              ? 'বাস চালনা জয়স্টিক'
              : ridingVehicle === 'motorcycle'
                ? 'বাইক চালনা জয়স্টিক'
                : ridingVehicle === 'bicycle'
                  ? 'সাইকেল চালনা জয়স্টিক'
                  : 'চলাচল জয়স্টিক'
          }
          role="slider"
          aria-valuenow={Math.round(Math.hypot(knobOffset.x, knobOffset.y))}
          className={`touch-joystick relative flex h-[88px] w-[88px] touch-none select-none items-center justify-center rounded-full border backdrop-blur-md shadow-[0_8px_24px_rgba(0,0,0,0.45)] sm:h-[108px] sm:w-[108px] ${
            isDriving
              ? 'border-sky-400/60 bg-black/45'
              : ridingVehicle === 'motorcycle'
                ? 'border-orange-400/65 bg-black/45'
                : ridingVehicle === 'bicycle'
                  ? 'border-emerald-400/65 bg-black/45'
                  : 'border-amber-400/50 bg-black/45'
          }`}
        >
          <div className="pointer-events-none absolute inset-2.5 rounded-full border border-amber-300/25" />
          <div className="pointer-events-none absolute top-2 h-1.5 w-1.5 rounded-full bg-amber-300/60" />
          <div className="pointer-events-none absolute bottom-2 h-1.5 w-1.5 rounded-full bg-amber-300/60" />
          <div className="pointer-events-none absolute left-2 h-1.5 w-1.5 rounded-full bg-amber-300/60" />
          <div className="pointer-events-none absolute right-2 h-1.5 w-1.5 rounded-full bg-amber-300/60" />

          {/* Draggable Thumbstick Puck */}
          <div
            style={{
              transform: `translate3d(${knobOffset.x}px, ${knobOffset.y}px, 0)`,
            }}
            className={`pointer-events-none flex h-10 w-10 items-center justify-center rounded-full border-2 transition-colors duration-75 sm:h-12 sm:w-12 ${
              isDriving
                ? joyActive
                  ? 'border-[#fff2d6] bg-[#1a7ad9]'
                  : 'border-sky-300/80 bg-[#124d8c]/85'
                : ridingVehicle === 'motorcycle'
                  ? joyActive
                    ? 'border-[#fff2d6] bg-[#d95816]'
                    : 'border-orange-300/85 bg-[#9c320d]/85'
                  : ridingVehicle === 'bicycle'
                    ? joyActive
                      ? 'border-[#fff2d6] bg-[#199e74]'
                      : 'border-emerald-300/85 bg-[#0f664b]/85'
                    : joyActive
                      ? 'border-[#fff2d6] bg-[#c9282d]'
                      : 'border-amber-300/80 bg-[#8d2c22]/85'
            } shadow-[0_4px_12px_rgba(0,0,0,0.5)]`}
          >
            <div className="h-3 w-3 rounded-full bg-[#fff5e4]/85" />
          </div>
        </div>
        <span className="font-bengali-ui pointer-events-none select-none text-[10px] font-semibold tracking-wide text-[#f6e3c2]/90 drop-shadow sm:text-[11px]">
          {isDriving
            ? 'বাস চালনা'
            : ridingVehicle === 'motorcycle'
              ? 'বাইক চালনা'
              : ridingVehicle === 'bicycle'
                ? 'সাইকেল চালনা'
                : 'চলাচল'}
        </span>
      </div>

      {/* Bus Driving Controls OR Bicycle/Motorcycle Dismount OR Customizable On-Foot Shooter Controls */}
      {isDriving ? (
        <div className="touch-controls-root pointer-events-auto absolute bottom-4 right-4 flex shrink-0 touch-none select-none items-end gap-2 sm:bottom-6 sm:right-6 sm:gap-3">
          <button
            type="button"
            onPointerDown={handleHornDown}
            onPointerMove={handleHornMove}
            onPointerUp={handleHornEnd}
            onPointerCancel={handleHornEnd}
            onLostPointerCapture={handleHornEnd}
            className={`touch-control-btn flex h-12 w-12 touch-none select-none flex-col items-center justify-center rounded-full border border-amber-400/50 bg-black/45 text-[#ffe17a] backdrop-blur-md shadow-[0_6px_18px_rgba(0,0,0,0.5)] transition-transform sm:h-14 sm:w-14 ${
              hornPressed ? 'scale-95 border-[#fff0b3] bg-amber-500/40' : ''
            }`}
            aria-label="হর্ন"
          >
            <svg viewBox="0 0 24 24" className="pointer-events-none h-4 w-4 fill-none stroke-current stroke-2 sm:h-5 sm:w-5">
              <path d="M3 14v-4h4l6-4v12l-6-4H3z" strokeLinejoin="round" />
              <path d="M17 9a4 4 0 0 1 0 6" strokeLinecap="round" />
            </svg>
            <span className="font-bengali-ui pointer-events-none text-[9px] font-bold leading-none sm:text-[10px]">
              হর্ন
            </span>
          </button>

          <button
            type="button"
            onPointerDown={handleExitBusDown}
            onPointerMove={handleExitBusMove}
            onPointerUp={handleExitBusEnd}
            onPointerCancel={handleExitBusEnd}
            onLostPointerCapture={handleExitBusEnd}
            className={`touch-control-btn font-bengali-display flex touch-none select-none items-center gap-1.5 whitespace-nowrap rounded-full border-2 border-[#fff0b3] bg-gradient-to-b from-[#ffe047] via-[#f4b114] to-[#d97c06] px-5 py-3 text-sm font-extrabold text-[#241205] shadow-[0_8px_24px_rgba(0,0,0,0.55)] transition-transform sm:gap-2 sm:px-6 sm:py-3.5 sm:text-lg ${
              exitBusPressed ? 'scale-95' : ''
            }`}
          >
            <span className="pointer-events-none">বাস থেকে নামুন</span>
            <span className="pointer-events-none hidden rounded-full bg-[#241205]/20 px-2 py-0.5 text-xs font-bold sm:inline">
              F
            </span>
          </button>
        </div>
      ) : isRidingTwoWheeler ? (
        <div className="touch-controls-root pointer-events-auto absolute bottom-5 right-4 flex shrink-0 touch-none select-none flex-col items-end gap-2 sm:bottom-6 sm:right-6">
          <button
            type="button"
            onPointerDown={handleDismountDown}
            onPointerMove={handleDismountMove}
            onPointerUp={handleDismountEnd}
            onPointerCancel={handleDismountEnd}
            onLostPointerCapture={handleDismountEnd}
            className={`touch-control-btn font-bengali-display flex touch-none select-none items-center gap-1.5 whitespace-nowrap rounded-full border-2 border-[#fff0b3] bg-gradient-to-b from-[#ffe047] via-[#f4b114] to-[#d97c06] px-5 py-3 text-sm font-extrabold text-[#241205] shadow-[0_8px_24px_rgba(0,0,0,0.55)] transition-transform sm:gap-2 sm:px-6 sm:py-3.5 sm:text-lg ${
              dismountPressed ? 'scale-95' : ''
            }`}
          >
            <svg viewBox="0 0 24 24" className="pointer-events-none h-4 w-4 fill-none stroke-current stroke-[2.4] sm:h-5 sm:w-5">
              <path d="M9 4h8a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H9" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M13 12H3m0 0l4-4m-4 4l4 4" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <span className="pointer-events-none">
              {ridingVehicle === 'motorcycle' ? 'বাইক থেকে নামুন' : 'সাইকেল থেকে নামুন'}
            </span>
            <span className="pointer-events-none hidden rounded-full bg-[#241205]/20 px-2 py-0.5 text-xs font-bold sm:inline">
              F
            </span>
          </button>
        </div>
      ) : (
        <>
          {/* Customizable Circular Reload Button */}
          {!isMelee && (
            <div
              className="pointer-events-auto absolute touch-none select-none"
              style={{
                left: `${reloadCfg.x}%`,
                top: `${reloadCfg.y}%`,
                transform: `translate(-50%, -50%) scale(${reloadCfg.size})`,
                opacity: reloadCfg.opacity,
              }}
            >
              <button
                type="button"
                onPointerDown={handleReloadDown}
                onPointerMove={handleReloadMove}
                onPointerUp={handleReloadEnd}
                onPointerCancel={handleReloadEnd}
                onLostPointerCapture={handleReloadEnd}
                disabled={!canReload}
                className={`touch-control-btn flex h-11 w-11 touch-none select-none flex-col items-center justify-center rounded-full border backdrop-blur-md text-xs font-bold shadow-[0_4px_14px_rgba(0,0,0,0.45)] transition-transform sm:h-12 sm:w-12 ${
                  reloadPressed ? 'scale-95' : ''
                } ${
                  canReload
                    ? 'border-amber-400/55 bg-black/45 text-[#fdeccf]'
                    : 'border-amber-400/20 bg-black/30 text-[#bca98f]/45'
                }`}
                aria-label="রিলোড"
              >
                <svg viewBox="0 0 24 24" className="pointer-events-none h-3.5 w-3.5 fill-none stroke-current stroke-2 sm:h-4 sm:w-4">
                  <path d="M21 12a9 9 0 1 1-2.64-6.36" strokeLinecap="round" />
                  <path d="M21 3v6h-6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                <span className="font-bengali-ui pointer-events-none mt-0.5 text-[8px] leading-none sm:text-[9px]">
                  রিলোড
                </span>
              </button>
            </div>
          )}

          {/* Customizable Circular Tap-to-Toggle Sprint Button (দৌড়) */}
          <div
            className="pointer-events-auto absolute touch-none select-none"
            style={{
              left: `${sprintCfg.x}%`,
              top: `${sprintCfg.y}%`,
              transform: `translate(-50%, -50%) scale(${sprintCfg.size})`,
              opacity: sprintCfg.opacity,
            }}
          >
            <button
              type="button"
              onPointerDown={handleSprintDown}
              onPointerMove={handleSprintMove}
              onPointerUp={handleSprintEnd}
              onPointerCancel={handleSprintEnd}
              onLostPointerCapture={handleSprintEnd}
              aria-pressed={isSprinting}
              className={`touch-control-btn relative flex h-11 w-11 touch-none select-none flex-col items-center justify-center rounded-full border backdrop-blur-md text-xs font-bold shadow-[0_4px_14px_rgba(0,0,0,0.45)] transition-all sm:h-12 sm:w-12 ${
                sprintPressed ? 'scale-95' : ''
              } ${
                isSprinting
                  ? 'border-[#fff1ad] bg-amber-500/88 text-[#1a110a] ring-2 ring-[#ffd966]/80 ring-offset-1 ring-offset-black/40 shadow-[0_0_18px_rgba(255,196,38,0.62)]'
                  : 'border-amber-400/50 bg-black/45 text-[#fdeccf] hover:border-amber-300/80 hover:bg-black/60'
              }`}
              aria-label="দৌড়"
            >
              {isSprinting && (
                <span className="pointer-events-none absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full border border-[#1a110a] bg-[#fff5b8] shadow-[0_0_8px_rgba(255,230,120,0.9)]" />
              )}
              <svg viewBox="0 0 24 24" className="pointer-events-none h-3.5 w-3.5 fill-none stroke-current stroke-2 sm:h-4 sm:w-4">
                <path d="M13 4L5 14h7l-1 6 8-10h-7l1-6z" strokeLinejoin="round" />
              </svg>
              <span className="font-bengali-ui pointer-events-none mt-0.5 text-[8px] leading-none sm:text-[9px]">
                দৌড়
              </span>
            </button>
          </div>

          {/* Customizable Circular Jump Button (জাম্প) */}
          <div
            className="pointer-events-auto absolute touch-none select-none"
            style={{
              left: `${jumpCfg.x}%`,
              top: `${jumpCfg.y}%`,
              transform: `translate(-50%, -50%) scale(${jumpCfg.size})`,
              opacity: jumpCfg.opacity,
            }}
          >
            <button
              type="button"
              onPointerDown={handleJumpDown}
              onPointerMove={handleJumpMove}
              onPointerUp={handleJumpEnd}
              onPointerCancel={handleJumpEnd}
              onLostPointerCapture={handleJumpEnd}
              aria-label="জাম্প"
              className={`touch-control-btn flex h-11 w-11 touch-none select-none flex-col items-center justify-center rounded-full border backdrop-blur-md text-xs font-bold shadow-[0_4px_14px_rgba(0,0,0,0.45)] transition-all sm:h-12 sm:w-12 ${
                jumpPressed || isJumping
                  ? 'scale-95 border-[#ffe899] bg-amber-500/80 text-[#1c1108] shadow-[0_0_16px_rgba(255,204,77,0.55)]'
                  : 'border-amber-400/55 bg-black/45 text-[#fdeccf] hover:border-amber-300/80 hover:bg-black/60'
              }`}
            >
              <svg viewBox="0 0 24 24" className="pointer-events-none h-4 w-4 fill-none stroke-current stroke-[2.2] sm:h-4.5 sm:w-4.5">
                <path d="M12 4v11" strokeLinecap="round" />
                <path d="M7.5 8.5L12 4l4.5 4.5" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M6.5 19.5h11" strokeLinecap="round" />
              </svg>
              <span className="font-bengali-ui pointer-events-none mt-0.5 text-[8px] leading-none sm:text-[9px]">
                জাম্প
              </span>
            </button>
          </div>

          {/* Customizable Circular Crouch / Sit Button (বসা) */}
          <div
            className="pointer-events-auto absolute touch-none select-none"
            style={{
              left: `${crouchCfg.x}%`,
              top: `${crouchCfg.y}%`,
              transform: `translate(-50%, -50%) scale(${crouchCfg.size})`,
              opacity: crouchCfg.opacity,
            }}
          >
            <button
              type="button"
              onPointerDown={handleCrouchDown}
              onPointerMove={handleCrouchMove}
              onPointerUp={handleCrouchEnd}
              onPointerCancel={handleCrouchEnd}
              onLostPointerCapture={handleCrouchEnd}
              aria-pressed={isCrouching}
              aria-label="বসা"
              className={`touch-control-btn flex h-11 w-11 touch-none select-none flex-col items-center justify-center rounded-full border backdrop-blur-md text-xs font-bold shadow-[0_4px_14px_rgba(0,0,0,0.45)] transition-all sm:h-12 sm:w-12 ${
                crouchPressed ? 'scale-95' : ''
              } ${
                isCrouching
                  ? 'border-[#8effc9] bg-emerald-800/80 text-[#e8fff4] ring-2 ring-[#6effbe]/75 ring-offset-1 ring-offset-black/40 shadow-[0_0_18px_rgba(52,211,153,0.58)]'
                  : 'border-amber-400/55 bg-black/45 text-[#fdeccf] hover:border-amber-300/80 hover:bg-black/60'
              }`}
            >
              <svg viewBox="0 0 24 24" className="pointer-events-none h-4 w-4 fill-none stroke-current stroke-[2.2] sm:h-4.5 sm:w-4.5">
                <circle cx="13" cy="6.5" r="2" fill="currentColor" stroke="none" />
                <path d="M12 10.5l-2.8 3.2 4.3 1.3-1.2 4.2" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M12.5 11.2l3.8 1.5" strokeLinecap="round" />
                <path d="M6.5 19.5h11" strokeLinecap="round" />
              </svg>
              <span className="font-bengali-ui pointer-events-none mt-0.5 text-[8px] leading-none sm:text-[9px]">
                বসা
              </span>
            </button>
          </div>

          {/* Customizable Main Circular Shoot / Melee Slash Button ('গুলি' / 'আঘাত') */}
          <div
            className="pointer-events-auto absolute touch-none select-none"
            style={{
              left: `${shootCfg.x}%`,
              top: `${shootCfg.y}%`,
              transform: `translate(-50%, -50%) scale(${shootCfg.size})`,
              opacity: shootCfg.opacity,
            }}
          >
            <button
              type="button"
              onPointerDown={handleShootDown}
              onPointerMove={handleShootMove}
              onPointerUp={handleShootEnd}
              onPointerCancel={handleShootEnd}
              onLostPointerCapture={handleShootEnd}
              aria-label={isMelee ? 'ছুরি আঘাত করুন' : 'গুলি করুন'}
              className={`touch-control-btn relative flex h-[74px] w-[74px] touch-none select-none flex-col items-center justify-center rounded-full border-2 backdrop-blur-md shadow-[0_10px_28px_rgba(0,0,0,0.52)] transition-transform sm:h-[86px] sm:w-[86px] ${
                shootPressed
                  ? 'scale-95 border-[#fff3d1] bg-[#e22b2b]/90 text-white'
                  : isMelee
                    ? 'border-amber-400/60 bg-black/50 text-[#f4f9ff] hover:bg-slate-800/70'
                    : 'border-amber-400/75 bg-[#b81d24]/80 text-[#fff5e4] hover:bg-[#cc232b]/90'
              }`}
            >
              {isMelee ? (
                <svg viewBox="0 0 32 32" className="pointer-events-none h-6 w-6 fill-none stroke-current stroke-[2.2] sm:h-7 sm:w-7">
                  <path d="M6 26l6-6" strokeLinecap="round" />
                  <path d="M10 18l14-12 2 2-12 14-4-4z" strokeLinejoin="round" />
                  <path d="M9 17l6 6" strokeLinecap="round" />
                </svg>
              ) : (
                <svg viewBox="0 0 32 32" className="pointer-events-none h-6 w-6 fill-none stroke-current stroke-[2.2] sm:h-7 sm:w-7">
                  <circle cx="16" cy="16" r="9" />
                  <line x1="16" y1="3" x2="16" y2="9" strokeLinecap="round" />
                  <line x1="16" y1="23" x2="16" y2="29" strokeLinecap="round" />
                  <line x1="3" y1="16" x2="9" y2="16" strokeLinecap="round" />
                  <line x1="23" y1="16" x2="29" y2="16" strokeLinecap="round" />
                  <circle cx="16" cy="16" r="2" className="fill-current" />
                </svg>
              )}
              <span className="font-bengali-ui pointer-events-none mt-0.5 text-xs font-bold leading-none tracking-wide sm:text-sm">
                {isMelee ? 'আঘাত' : 'গুলি'}
              </span>
            </button>
          </div>
        </>
      )}
    </div>
  );
};
