import React, { useEffect, useRef, useState } from 'react';
import { BusMode, WEAPON_CATALOG, WeaponType } from '../game/types';

interface TouchControlsProps {
  busMode: BusMode;
  activeWeapon: WeaponType;
  onMove: (x: number, y: number) => void;
  onShootChange: (shooting: boolean) => void;
  onSprintChange: (sprinting: boolean) => void;
  onReload: () => void;
  onExitBus: () => void;
  onBusHorn: () => void;
  isReloading: boolean;
  ammo: number;
  maxAmmo: number;
  reserveAmmo: number;
}

const DEADZONE = 0.1;

export const TouchControls: React.FC<TouchControlsProps> = ({
  busMode,
  activeWeapon,
  onMove,
  onShootChange,
  onSprintChange,
  onReload,
  onExitBus,
  onBusHorn,
  isReloading,
  ammo,
  maxAmmo,
  reserveAmmo,
}) => {
  const baseRef = useRef<HTMLDivElement | null>(null);
  const joyPointerId = useRef<number | null>(null);
  const shootPointerId = useRef<number | null>(null);
  const sprintPointerId = useRef<number | null>(null);

  const [knobOffset, setKnobOffset] = useState({ x: 0, y: 0 });
  const [joyActive, setJoyActive] = useState(false);
  const [shootPressed, setShootPressed] = useState(false);
  const [sprintPressed, setSprintPressed] = useState(false);

  // Release any active touch inputs cleanly when transitioning between bus & on-foot modes
  useEffect(() => {
    joyPointerId.current = null;
    shootPointerId.current = null;
    sprintPointerId.current = null;
    setJoyActive(false);
    setKnobOffset({ x: 0, y: 0 });
    setShootPressed(false);
    setSprintPressed(false);
    onMove(0, 0);
    onShootChange(false);
    onSprintChange(false);
  }, [busMode, onMove, onShootChange, onSprintChange]);

  // Hide touch shooter/steering pads while watching the WBTC intro bus drop-in
  if (busMode === 'riding_intro') return null;

  const updateJoystick = (clientX: number, clientY: number) => {
    const el = baseRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const maxRadius = Math.max(30, rect.width * 0.37);

    let dx = clientX - cx;
    let dy = clientY - cy;
    const dist = Math.hypot(dx, dy);

    if (dist > maxRadius) {
      dx = (dx / dist) * maxRadius;
      dy = (dy / dist) * maxRadius;
    }

    setKnobOffset({ x: dx, y: dy });

    const nx = dx / maxRadius;
    const ny = -dy / maxRadius; // forward is up on screen
    const mag = Math.hypot(nx, ny);
    if (mag < DEADZONE) {
      onMove(0, 0);
    } else {
      onMove(nx, ny);
    }
  };

  const handleJoyDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.stopPropagation();
    if (joyPointerId.current !== null) return;
    joyPointerId.current = e.pointerId;
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // Ignore synthetic/non-capturable pointer events
    }
    setJoyActive(true);
    updateJoystick(e.clientX, e.clientY);
  };

  const handleJoyMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerId !== joyPointerId.current) return;
    e.stopPropagation();
    updateJoystick(e.clientX, e.clientY);
  };

  const handleJoyUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerId !== joyPointerId.current) return;
    e.stopPropagation();
    joyPointerId.current = null;
    setJoyActive(false);
    setKnobOffset({ x: 0, y: 0 });
    onMove(0, 0);
  };

  const handleShootDown = (e: React.PointerEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    if (shootPointerId.current !== null) return;
    shootPointerId.current = e.pointerId;
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // Ignore synthetic/non-capturable pointer events
    }
    setShootPressed(true);
    onShootChange(true);
  };

  const handleShootUp = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerId !== shootPointerId.current) return;
    e.stopPropagation();
    shootPointerId.current = null;
    setShootPressed(false);
    onShootChange(false);
  };

  const handleSprintDown = (e: React.PointerEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    if (sprintPointerId.current !== null) return;
    sprintPointerId.current = e.pointerId;
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // Ignore synthetic/non-capturable pointer events
    }
    setSprintPressed(true);
    onSprintChange(true);
  };

  const handleSprintUp = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerId !== sprintPointerId.current) return;
    e.stopPropagation();
    sprintPointerId.current = null;
    setSprintPressed(false);
    onSprintChange(false);
  };

  const isMelee = WEAPON_CATALOG[activeWeapon].isMelee;
  const canReload = !isMelee && !isReloading && ammo < maxAmmo && reserveAmmo > 0;
  const isDriving = busMode === 'driving';

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-[calc(3.5rem+env(safe-area-inset-bottom))] z-20 flex items-end justify-between gap-2 pl-[max(0.85rem,env(safe-area-inset-left))] pr-[max(1.25rem,env(safe-area-inset-right))] sm:bottom-[calc(4.25rem+env(safe-area-inset-bottom))] sm:px-7">
      {/* Bottom-Left: Sleek Translucent Circular Virtual Joystick */}
      <div className="pointer-events-auto flex shrink-0 flex-col items-center gap-1">
        <div
          ref={baseRef}
          onPointerDown={handleJoyDown}
          onPointerMove={handleJoyMove}
          onPointerUp={handleJoyUp}
          onPointerCancel={handleJoyUp}
          aria-label={isDriving ? 'বাস চালনা জয়স্টিক' : 'চলাচল জয়স্টিক'}
          role="slider"
          aria-valuenow={Math.round(Math.hypot(knobOffset.x, knobOffset.y))}
          className={`relative flex h-[90px] w-[90px] touch-none items-center justify-center rounded-full border backdrop-blur-md shadow-[0_8px_24px_rgba(0,0,0,0.45)] sm:h-[112px] sm:w-[112px] ${
            isDriving
              ? 'border-sky-400/60 bg-black/45'
              : 'border-amber-400/50 bg-black/45'
          }`}
        >
          <div className="pointer-events-none absolute inset-2.5 rounded-full border border-amber-300/25" />
          <div className="pointer-events-none absolute top-2 h-1.5 w-1.5 rounded-full bg-amber-300/60" />
          <div className="pointer-events-none absolute bottom-2 h-1.5 w-1.5 rounded-full bg-amber-300/60" />
          <div className="pointer-events-none absolute left-2 h-1.5 w-1.5 rounded-full bg-amber-300/60" />
          <div className="pointer-events-none absolute right-2 h-1.5 w-1.5 rounded-full bg-amber-300/60" />

          {/* Draggable Thumbstick Puck */}
          <div
            style={{
              transform: `translate3d(${knobOffset.x}px, ${knobOffset.y}px, 0)`,
            }}
            className={`pointer-events-none flex h-10 w-10 items-center justify-center rounded-full border-2 transition-colors duration-75 sm:h-12 sm:w-12 ${
              isDriving
                ? joyActive
                  ? 'border-[#fff2d6] bg-[#1a7ad9]'
                  : 'border-sky-300/80 bg-[#124d8c]/85'
                : joyActive
                  ? 'border-[#fff2d6] bg-[#c9282d]'
                  : 'border-amber-300/80 bg-[#8d2c22]/85'
            } shadow-[0_4px_12px_rgba(0,0,0,0.5)]`}
          >
            <div className="h-3 w-3 rounded-full bg-[#fff5e4]/85" />
          </div>
        </div>
        <span className="font-bengali-ui text-[10px] font-semibold tracking-wide text-[#f6e3c2]/90 drop-shadow sm:text-[11px]">
          {isDriving ? 'বাস চালনা' : 'চলাচল'}
        </span>
      </div>

      {/* Bottom-Right: Bus Driving Controls OR On-Foot Circular Shooter Buttons */}
      {isDriving ? (
        <div className="pointer-events-auto flex shrink-0 items-end gap-2 pb-1 sm:gap-3">
          <button
            type="button"
            onPointerDown={(e) => {
              e.stopPropagation();
              onBusHorn();
            }}
            className="flex h-12 w-12 touch-none flex-col items-center justify-center rounded-full border border-amber-400/50 bg-black/45 text-[#ffe17a] backdrop-blur-md shadow-[0_6px_18px_rgba(0,0,0,0.5)] active:scale-95 sm:h-14 sm:w-14"
            aria-label="হর্ন"
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current stroke-2 sm:h-5 sm:w-5">
              <path d="M3 14v-4h4l6-4v12l-6-4H3z" strokeLinejoin="round" />
              <path d="M17 9a4 4 0 0 1 0 6" strokeLinecap="round" />
            </svg>
            <span className="font-bengali-ui text-[9px] font-bold leading-none sm:text-[10px]">হর্ন</span>
          </button>

          <button
            type="button"
            onPointerDown={(e) => {
              e.stopPropagation();
              onExitBus();
            }}
            className="font-bengali-display flex items-center gap-1.5 whitespace-nowrap rounded-full border-2 border-[#fff0b3] bg-gradient-to-b from-[#ffe047] via-[#f4b114] to-[#d97c06] px-5 py-3 text-sm font-extrabold text-[#241205] shadow-[0_8px_24px_rgba(0,0,0,0.55)] active:scale-95 sm:gap-2 sm:px-6 sm:py-3.5 sm:text-lg"
          >
            <span>বাস থেকে নামুন</span>
            <span className="hidden rounded-full bg-[#241205]/20 px-2 py-0.5 text-xs font-bold sm:inline">
              F
            </span>
          </button>
        </div>
      ) : (
        <div className="pointer-events-auto flex shrink-0 items-end gap-2 sm:gap-3">
          <div className="flex flex-col gap-2 pb-0.5 sm:gap-2.5">
            {/* Circular Reload Button */}
            {!isMelee && (
              <button
                type="button"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onReload();
                }}
                disabled={!canReload}
                className={`flex h-11 w-11 touch-none flex-col items-center justify-center rounded-full border backdrop-blur-md text-xs font-bold shadow-[0_4px_14px_rgba(0,0,0,0.45)] transition-transform active:scale-95 sm:h-12 sm:w-12 ${
                  canReload
                    ? 'border-amber-400/55 bg-black/45 text-[#fdeccf]'
                    : 'border-amber-400/20 bg-black/30 text-[#bca98f]/45'
                }`}
                aria-label="রিলোড"
              >
                <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 fill-none stroke-current stroke-2 sm:h-4 sm:w-4">
                  <path d="M21 12a9 9 0 1 1-2.64-6.36" strokeLinecap="round" />
                  <path d="M21 3v6h-6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                <span className="font-bengali-ui mt-0.5 text-[8px] leading-none sm:text-[9px]">
                  রিলোড
                </span>
              </button>
            )}

            {/* Circular Sprint Button */}
            <button
              type="button"
              onPointerDown={handleSprintDown}
              onPointerUp={handleSprintUp}
              onPointerCancel={handleSprintUp}
              className={`flex h-11 w-11 touch-none flex-col items-center justify-center rounded-full border backdrop-blur-md text-xs font-bold shadow-[0_4px_14px_rgba(0,0,0,0.45)] transition-transform active:scale-95 sm:h-12 sm:w-12 ${
                sprintPressed
                  ? 'border-[#ffe6a3] bg-amber-500/85 text-[#1a110a]'
                  : 'border-amber-400/50 bg-black/45 text-[#fdeccf]'
              }`}
              aria-label="দৌড়"
            >
              <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 fill-none stroke-current stroke-2 sm:h-4 sm:w-4">
                <path d="M13 4L5 14h7l-1 6 8-10h-7l1-6z" strokeLinejoin="round" />
              </svg>
              <span className="font-bengali-ui mt-0.5 text-[8px] leading-none sm:text-[9px]">
                দৌড়
              </span>
            </button>
          </div>

          {/* Main Circular Shoot / Melee Slash Button ('গুলি' / 'আঘাত') */}
          <div className="flex flex-col items-center gap-1">
            <button
              type="button"
              onPointerDown={handleShootDown}
              onPointerUp={handleShootUp}
              onPointerCancel={handleShootUp}
              aria-label={isMelee ? 'ছুরি আঘাত করুন' : 'গুলি করুন'}
              className={`relative flex h-[74px] w-[74px] touch-none flex-col items-center justify-center rounded-full border-2 backdrop-blur-md shadow-[0_10px_28px_rgba(0,0,0,0.52)] transition-transform sm:h-[86px] sm:w-[86px] ${
                shootPressed
                  ? 'scale-95 border-[#fff3d1] bg-[#e22b2b]/90 text-white'
                  : isMelee
                    ? 'border-amber-400/60 bg-black/50 text-[#f4f9ff] hover:bg-slate-800/70'
                    : 'border-amber-400/75 bg-[#b81d24]/80 text-[#fff5e4] hover:bg-[#cc232b]/90'
              }`}
            >
              {isMelee ? (
                <svg viewBox="0 0 32 32" className="h-6 w-6 fill-none stroke-current stroke-[2.2] sm:h-7 sm:w-7">
                  <path d="M6 26l6-6" strokeLinecap="round" />
                  <path d="M10 18l14-12 2 2-12 14-4-4z" strokeLinejoin="round" />
                  <path d="M9 17l6 6" strokeLinecap="round" />
                </svg>
              ) : (
                <svg viewBox="0 0 32 32" className="h-6 w-6 fill-none stroke-current stroke-[2.2] sm:h-7 sm:w-7">
                  <circle cx="16" cy="16" r="9" />
                  <line x1="16" y1="3" x2="16" y2="9" strokeLinecap="round" />
                  <line x1="16" y1="23" x2="16" y2="29" strokeLinecap="round" />
                  <line x1="3" y1="16" x2="9" y2="16" strokeLinecap="round" />
                  <line x1="23" y1="16" x2="29" y2="16" strokeLinecap="round" />
                  <circle cx="16" cy="16" r="2" className="fill-current" />
                </svg>
              )}
              <span className="font-bengali-ui mt-0.5 text-xs font-bold leading-none tracking-wide sm:text-sm">
                {isMelee ? 'আঘাত' : 'গুলি'}
              </span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
