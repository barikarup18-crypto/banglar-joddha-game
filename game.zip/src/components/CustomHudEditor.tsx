import React, { useEffect, useRef, useState } from 'react';
import { toBengaliNumber } from '../game/GameEngine';
import {
  clampHudControl,
  cloneCustomHud,
  CustomHudLayout,
  DEFAULT_CUSTOM_HUD,
  HUD_CONTROL_META,
  HUD_CONTROL_ORDER,
  HudControlId,
} from '../game/settings';

interface CustomHudEditorProps {
  open: boolean;
  initialLayout: CustomHudLayout;
  onSave: (layout: CustomHudLayout) => void;
  onCancel: () => void;
}

type ActiveInteraction =
  | {
      mode: 'drag';
      id: HudControlId;
      pointerId: number;
      offsetX: number;
      offsetY: number;
    }
  | {
      mode: 'resize';
      id: HudControlId;
      pointerId: number;
      centerX: number;
      centerY: number;
      startDist: number;
      startSize: number;
    };

export const CustomHudEditor: React.FC<CustomHudEditorProps> = ({
  open,
  initialLayout,
  onSave,
  onCancel,
}) => {
  const safeStageRef = useRef<HTMLDivElement | null>(null);
  const wasOpenRef = useRef(false);
  const [draft, setDraft] = useState<CustomHudLayout>(() => cloneCustomHud(initialLayout));
  const draftRef = useRef<CustomHudLayout>(draft);
  const [selectedId, setSelectedId] = useState<HudControlId>('shoot');
  const [activeId, setActiveId] = useState<HudControlId | null>(null);
  const [activeMode, setActiveMode] = useState<'drag' | 'resize' | null>(null);

  const interactionRef = useRef<ActiveInteraction | null>(null);

  useEffect(() => {
    draftRef.current = draft;
  }, [draft]);

  // Only re-initialize draft when transitioning from closed -> open so edits are never overwritten
  useEffect(() => {
    if (open && !wasOpenRef.current) {
      const fresh = cloneCustomHud(initialLayout);
      setDraft(fresh);
      draftRef.current = fresh;
      setSelectedId('shoot');
      setActiveId(null);
      setActiveMode(null);
      interactionRef.current = null;
    }
    if (!open && wasOpenRef.current) {
      interactionRef.current = null;
      setActiveId(null);
      setActiveMode(null);
    }
    wasOpenRef.current = open;
  }, [open, initialLayout]);

  const getStageRect = () => {
    const el = safeStageRef.current;
    if (el) return el.getBoundingClientRect();
    return {
      left: 0,
      top: 0,
      width: Math.max(1, window.innerWidth),
      height: Math.max(1, window.innerHeight),
    };
  };

  // Window-level pointer tracking prevents mobile lostpointercapture from aborting drags/resizes
  useEffect(() => {
    if (!open) return;

    const handleWindowPointerMove = (e: PointerEvent) => {
      const active = interactionRef.current;
      if (!active || active.pointerId !== e.pointerId) return;
      e.preventDefault();

      if (active.mode === 'drag') {
        const rect = getStageRect();
        const nextX =
          ((e.clientX - active.offsetX - rect.left) / Math.max(1, rect.width)) * 100;
        const nextY =
          ((e.clientY - active.offsetY - rect.top) / Math.max(1, rect.height)) * 100;

        setDraft((prev) => {
          const updated = {
            ...prev,
            [active.id]: clampHudControl({
              ...prev[active.id],
              x: nextX,
              y: nextY,
            }),
          };
          draftRef.current = updated;
          return updated;
        });
      } else {
        const curDist = Math.max(
          16,
          Math.hypot(e.clientX - active.centerX, e.clientY - active.centerY),
        );
        const ratio = curDist / Math.max(16, active.startDist);
        const nextSize = active.startSize * ratio;

        setDraft((prev) => {
          const updated = {
            ...prev,
            [active.id]: clampHudControl({
              ...prev[active.id],
              size: nextSize,
            }),
          };
          draftRef.current = updated;
          return updated;
        });
      }
    };

    const handleWindowPointerEnd = (e: PointerEvent) => {
      const active = interactionRef.current;
      if (!active || active.pointerId !== e.pointerId) return;
      interactionRef.current = null;
      setActiveId(null);
      setActiveMode(null);
    };

    window.addEventListener('pointermove', handleWindowPointerMove, { passive: false });
    window.addEventListener('pointerup', handleWindowPointerEnd);
    window.addEventListener('pointercancel', handleWindowPointerEnd);
    return () => {
      window.removeEventListener('pointermove', handleWindowPointerMove);
      window.removeEventListener('pointerup', handleWindowPointerEnd);
      window.removeEventListener('pointercancel', handleWindowPointerEnd);
    };
  }, [open]);

  if (!open) return null;

  const selectedConfig = draft[selectedId];

  const handleControlPointerDown = (
    id: HudControlId,
    e: React.PointerEvent<HTMLDivElement>,
  ) => {
    e.stopPropagation();
    e.preventDefault();
    setSelectedId(id);
    setActiveId(id);
    setActiveMode('drag');

    const rect = getStageRect();
    const cfg = draftRef.current[id];
    const centerX = rect.left + (cfg.x / 100) * rect.width;
    const centerY = rect.top + (cfg.y / 100) * rect.height;

    interactionRef.current = {
      mode: 'drag',
      id,
      pointerId: e.pointerId,
      offsetX: e.clientX - centerX,
      offsetY: e.clientY - centerY,
    };
  };

  const handleResizePointerDown = (
    id: HudControlId,
    e: React.PointerEvent<HTMLButtonElement>,
  ) => {
    e.stopPropagation();
    e.preventDefault();
    setSelectedId(id);
    setActiveId(id);
    setActiveMode('resize');

    const rect = getStageRect();
    const cfg = draftRef.current[id];
    const centerX = rect.left + (cfg.x / 100) * rect.width;
    const centerY = rect.top + (cfg.y / 100) * rect.height;
    const startDist = Math.max(24, Math.hypot(e.clientX - centerX, e.clientY - centerY));

    interactionRef.current = {
      mode: 'resize',
      id,
      pointerId: e.pointerId,
      centerX,
      centerY,
      startDist,
      startSize: cfg.size,
    };
  };

  const handleSizeChange = (pct: number) => {
    setDraft((prev) => {
      const updated = {
        ...prev,
        [selectedId]: clampHudControl({
          ...prev[selectedId],
          size: pct / 100,
        }),
      };
      draftRef.current = updated;
      return updated;
    });
  };

  const handleStepSize = (deltaPct: number) => {
    const nextPct = Math.round(draftRef.current[selectedId].size * 100) + deltaPct;
    handleSizeChange(nextPct);
  };

  const handleOpacityChange = (pct: number) => {
    setDraft((prev) => {
      const updated = {
        ...prev,
        [selectedId]: clampHudControl({
          ...prev[selectedId],
          opacity: pct / 100,
        }),
      };
      draftRef.current = updated;
      return updated;
    });
  };

  const handleReset = () => {
    interactionRef.current = null;
    setActiveId(null);
    setActiveMode(null);
    const defaults = cloneCustomHud(DEFAULT_CUSTOM_HUD);
    setDraft(defaults);
    draftRef.current = defaults;
  };

  const renderControlVisual = (id: HudControlId) => {
    switch (id) {
      case 'joystick':
        return (
          <div className="flex flex-col items-center gap-1">
            <div className="relative flex h-[88px] w-[88px] items-center justify-center rounded-full border border-amber-400/65 bg-black/55 backdrop-blur-md shadow-[0_8px_24px_rgba(0,0,0,0.45)] sm:h-[108px] sm:w-[108px]">
              <div className="absolute inset-2.5 rounded-full border border-amber-300/30" />
              <div className="flex h-10 w-10 items-center justify-center rounded-full border-2 border-amber-300/85 bg-[#8d2c22]/85 sm:h-12 sm:w-12">
                <div className="h-3 w-3 rounded-full bg-[#fff5e4]/85" />
              </div>
            </div>
            <span className="font-bengali-ui text-[10px] font-semibold text-[#f6e3c2]">চলাচল</span>
          </div>
        );

      case 'shoot':
        return (
          <div className="flex h-[74px] w-[74px] flex-col items-center justify-center rounded-full border-2 border-amber-400/80 bg-[#b81d24]/85 text-[#fff5e4] shadow-[0_10px_28px_rgba(0,0,0,0.52)] sm:h-[86px] sm:w-[86px]">
            <svg viewBox="0 0 32 32" className="h-6 w-6 fill-none stroke-current stroke-[2.2] sm:h-7 sm:w-7">
              <circle cx="16" cy="16" r="9" />
              <line x1="16" y1="3" x2="16" y2="9" strokeLinecap="round" />
              <line x1="16" y1="23" x2="16" y2="29" strokeLinecap="round" />
              <line x1="3" y1="16" x2="9" y2="16" strokeLinecap="round" />
              <line x1="23" y1="16" x2="29" y2="16" strokeLinecap="round" />
              <circle cx="16" cy="16" r="2" className="fill-current" />
            </svg>
            <span className="font-bengali-ui mt-0.5 text-xs font-bold leading-none sm:text-sm">
              গুলি
            </span>
          </div>
        );

      case 'scope':
        return (
          <div className="flex h-14 w-14 flex-col items-center justify-center rounded-full border border-amber-400/65 bg-black/55 text-[#fff0cf] backdrop-blur-md shadow-[0_8px_22px_rgba(0,0,0,0.48)] sm:h-16 sm:w-16">
            <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-[2.1] sm:h-6 sm:w-6">
              <circle cx="12" cy="12" r="7" />
              <line x1="12" y1="2.5" x2="12" y2="6.5" strokeLinecap="round" />
              <line x1="12" y1="17.5" x2="12" y2="21.5" strokeLinecap="round" />
              <line x1="2.5" y1="12" x2="6.5" y2="12" strokeLinecap="round" />
              <line x1="17.5" y1="12" x2="21.5" y2="12" strokeLinecap="round" />
              <line x1="9" y1="12" x2="15" y2="12" strokeLinecap="round" />
              <line x1="12" y1="9" x2="12" y2="15" strokeLinecap="round" />
            </svg>
            <span className="font-bengali-ui mt-0.5 text-[9px] font-bold leading-none sm:text-[10px]">
              স্কোপ
            </span>
          </div>
        );

      case 'reload':
        return (
          <div className="flex h-11 w-11 flex-col items-center justify-center rounded-full border border-amber-400/65 bg-black/55 text-[#fdeccf] backdrop-blur-md shadow-[0_4px_14px_rgba(0,0,0,0.45)] sm:h-12 sm:w-12">
            <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 fill-none stroke-current stroke-2 sm:h-4 sm:w-4">
              <path d="M21 12a9 9 0 1 1-2.64-6.36" strokeLinecap="round" />
              <path d="M21 3v6h-6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <span className="font-bengali-ui mt-0.5 text-[8px] font-bold leading-none sm:text-[9px]">
              রিলোড
            </span>
          </div>
        );

      case 'sprint':
        return (
          <div className="flex h-11 w-11 flex-col items-center justify-center rounded-full border border-amber-400/65 bg-black/55 text-[#fdeccf] backdrop-blur-md shadow-[0_4px_14px_rgba(0,0,0,0.45)] sm:h-12 sm:w-12">
            <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 fill-none stroke-current stroke-2 sm:h-4 sm:w-4">
              <path d="M13 4L5 14h7l-1 6 8-10h-7l1-6z" strokeLinejoin="round" />
            </svg>
            <span className="font-bengali-ui mt-0.5 text-[8px] font-bold leading-none sm:text-[9px]">
              দৌড়
            </span>
          </div>
        );

      case 'jump':
        return (
          <div className="flex h-11 w-11 flex-col items-center justify-center rounded-full border border-amber-400/65 bg-black/55 text-[#fdeccf] backdrop-blur-md shadow-[0_4px_14px_rgba(0,0,0,0.45)] sm:h-12 sm:w-12">
            <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current stroke-[2.2] sm:h-4.5 sm:w-4.5">
              <path d="M12 4v11" strokeLinecap="round" />
              <path d="M7.5 8.5L12 4l4.5 4.5" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M6.5 19.5h11" strokeLinecap="round" />
            </svg>
            <span className="font-bengali-ui mt-0.5 text-[8px] font-bold leading-none sm:text-[9px]">
              জাম্প
            </span>
          </div>
        );

      case 'crouch':
        return (
          <div className="flex h-11 w-11 flex-col items-center justify-center rounded-full border border-amber-400/65 bg-black/55 text-[#fdeccf] backdrop-blur-md shadow-[0_4px_14px_rgba(0,0,0,0.45)] sm:h-12 sm:w-12">
            <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current stroke-[2.2] sm:h-4.5 sm:w-4.5">
              <circle cx="13" cy="6.5" r="2" fill="currentColor" stroke="none" />
              <path d="M12 10.5l-2.8 3.2 4.3 1.3-1.2 4.2" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M12.5 11.2l3.8 1.5" strokeLinecap="round" />
              <path d="M6.5 19.5h11" strokeLinecap="round" />
            </svg>
            <span className="font-bengali-ui mt-0.5 text-[8px] font-bold leading-none sm:text-[9px]">
              বসা
            </span>
          </div>
        );

      case 'weapons':
        return (
          <div className="flex items-center gap-1 rounded-full border border-amber-400/65 bg-black/55 p-1 backdrop-blur-md shadow-[0_8px_22px_rgba(0,0,0,0.48)] sm:gap-1.5 sm:p-1.5">
            {['অগ্নি-৪৭', 'কালভৈরব', 'ত্রিশূল', 'ফলা'].map((name, idx) => (
              <div
                key={name}
                className={`whitespace-nowrap rounded-full border px-2 py-1 text-[10px] font-bold sm:px-3 sm:text-xs ${
                  idx === 0
                    ? 'border-amber-300 bg-amber-500/35 text-[#fff8e6]'
                    : 'border-transparent bg-white/8 text-[#e2cfa8]'
                }`}
              >
                <span className="font-bengali-ui">{name}</span>
              </div>
            ))}
          </div>
        );

      case 'sanjibani':
        return (
          <div className="relative flex h-12 w-12 flex-col items-center justify-center rounded-full border border-amber-400/65 bg-black/55 text-[#d3ffe4] backdrop-blur-md shadow-[0_6px_18px_rgba(0,0,0,0.45)] sm:h-14 sm:w-14">
            <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-[#49f08f] sm:h-5 sm:w-5">
              <path d="M17 8C8 10 5.9 16.17 3.82 21.34l1.89.66.95-2.3c.48.17.98.3 1.34.3C19 20 22 3 22 3c-1 2-8 2.25-13 3.25S2 11.5 2 13.5s1.75 3.75 1.75 3.75C7 8 17 8 17 8z" />
            </svg>
            <span className="font-bengali-ui mt-0.5 text-[8px] font-bold leading-none sm:text-[9px]">
              সঞ্জীবনী
            </span>
            <span className="font-bengali-ui tabular-nums absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full border border-emerald-300/60 bg-emerald-950 px-1 text-[9px] font-extrabold text-[#7fffb2]">
              ১
            </span>
          </div>
        );

      case 'grenade':
        return (
          <div className="relative flex h-12 w-12 flex-col items-center justify-center rounded-full border border-amber-400/65 bg-black/55 text-[#ffe5c7] backdrop-blur-md shadow-[0_6px_18px_rgba(0,0,0,0.45)] sm:h-14 sm:w-14">
            <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-[#ffae52] stroke-2 sm:h-5 sm:w-5">
              <circle cx="12" cy="14" r="6" fill="#ff9436" fillOpacity="0.28" />
              <path d="M10 8V5h4v3" />
              <path d="M14 5l3-2" strokeLinecap="round" />
            </svg>
            <span className="font-bengali-ui mt-0.5 text-[8px] font-bold leading-none sm:text-[9px]">
              বজ্র গোলা
            </span>
            <span className="font-bengali-ui tabular-nums absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full border border-amber-300/60 bg-amber-950 px-1 text-[9px] font-extrabold text-[#ffc978]">
              ১
            </span>
          </div>
        );
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="কাস্টম বাটন সাজান"
      onPointerDown={(e) => e.stopPropagation()}
      onMouseDown={(e) => e.stopPropagation()}
      onTouchStart={(e) => e.stopPropagation()}
      onContextMenu={(e) => e.preventDefault()}
      className="touch-controls-root fixed inset-0 z-50 h-[100dvh] w-[100vw] touch-none select-none overflow-hidden bg-[#0c0806]/68 backdrop-blur-[2px]"
    >
      {/* Subtle tactical grid guide */}
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-0 opacity-20"
        style={{
          backgroundImage:
            'linear-gradient(to right, rgba(255,214,102,0.28) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,214,102,0.28) 1px, transparent 1px)',
          backgroundSize: '48px 48px',
        }}
      />

      {/* Safe-Area Bounded Stage: matches live gameplay safe-area positioning 1:1 on portrait & landscape */}
      <div
        ref={safeStageRef}
        className="fixed overflow-visible"
        style={{
          top: 'env(safe-area-inset-top, 0px)',
          right: 'env(safe-area-inset-right, 0px)',
          bottom: 'env(safe-area-inset-bottom, 0px)',
          left: 'env(safe-area-inset-left, 0px)',
        }}
      >
        {/* Top Floating Custom HUD Toolbar (Quick-Select, Size 50%-150%, Opacity 30%-100%, Reset, Save, Cancel) */}
        <div
          onPointerDown={(e) => e.stopPropagation()}
          className="pointer-events-auto absolute left-1/2 top-2 z-40 w-[min(calc(100%-0.75rem),760px)] -translate-x-1/2 rounded-2xl border border-[#f5c763]/55 bg-[#150f0b]/95 px-2.5 py-2 text-[#f9ebd4] shadow-[0_14px_38px_rgba(0,0,0,0.72)] backdrop-blur-md sm:px-4 sm:py-2.5"
        >
          <div className="flex flex-wrap items-center justify-between gap-2">
            {/* Selected Button Label */}
            <div className="flex items-center gap-2">
              <span className="font-bengali-display whitespace-nowrap text-xs font-bold text-[#ffd875] sm:text-sm">
                নির্বাচিত: {HUD_CONTROL_META[selectedId].label}
              </span>
              <span className="hidden text-xs text-[#a99272] sm:inline">·</span>
              <span className="font-bengali-ui hidden text-[11px] text-[#cdb593] sm:inline">
                টেনে সরান বা কোনা টেনে বড়-ছোট করুন
              </span>
            </div>

            {/* Action Buttons: Reset, Save, Close */}
            <div className="flex items-center gap-1.5 sm:gap-2">
              <button
                type="button"
                onClick={handleReset}
                className="font-bengali-ui min-h-[32px] whitespace-nowrap rounded-lg border border-[#e8bc6a]/40 bg-[#251a13] px-2.5 py-1 text-xs font-bold text-[#f4dfbe] transition-colors hover:border-[#ffd25a] hover:bg-[#332319] active:scale-95 sm:min-h-[34px] sm:px-3"
              >
                রিসেট
              </button>
              <button
                type="button"
                onClick={() => onSave(cloneCustomHud(draftRef.current))}
                className="font-bengali-ui min-h-[32px] whitespace-nowrap rounded-lg border border-[#fff2b2] bg-gradient-to-b from-[#ffe047] to-[#d98406] px-3 py-1 text-xs font-extrabold text-[#241205] shadow-[0_0_14px_rgba(255,196,38,0.45)] transition-transform hover:brightness-105 active:scale-95 sm:min-h-[34px] sm:px-3.5"
              >
                সেভ করুন
              </button>
              <button
                type="button"
                onClick={onCancel}
                aria-label="বাতিল করুন"
                className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-[#e8bc6a]/30 bg-[#221710] text-xs font-bold text-[#dfc8a6] hover:bg-[#312218] active:scale-95"
              >
                ✕
              </button>
            </div>
          </div>

          {/* Quick-Select Button Strip so Fire ('গুলি') or any overlapped control is always 1-tap selectable */}
          <div className="mt-1.5 flex items-center gap-1 overflow-x-auto pb-0.5">
            {HUD_CONTROL_ORDER.map((id) => {
              const isSel = selectedId === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => setSelectedId(id)}
                  className={`font-bengali-ui shrink-0 whitespace-nowrap rounded-md border px-2 py-0.5 text-[10px] font-bold transition-colors sm:text-[11px] ${
                    isSel
                      ? 'border-[#ffe066] bg-[#f5b415]/25 text-[#fff4d4]'
                      : 'border-[#e8bc6a]/20 bg-[#221811]/85 text-[#cab493] hover:border-[#e8bc6a]/45 hover:text-[#f7e7cc]'
                  }`}
                >
                  {HUD_CONTROL_META[id].shortLabel}
                </button>
              );
            })}
          </div>

          {/* Sliders Row: Size (50%..150%) & Opacity (30%..100%) */}
          <div className="mt-1.5 grid grid-cols-2 gap-2.5 border-t border-[#e8bc6a]/15 pt-1.5 sm:gap-5">
            {/* Size Slider + Step Buttons */}
            <div className="flex flex-col gap-1">
              <div className="flex items-center justify-between gap-1.5 text-[11px] sm:text-xs">
                <label htmlFor="hud-size-slider" className="font-bengali-ui font-bold text-[#f2dec0]">
                  আকার (Size)
                </label>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => handleStepSize(-5)}
                    aria-label="আকার কমান"
                    className="flex h-5 w-5 items-center justify-center rounded border border-[#e8bc6a]/35 bg-[#261a12] text-xs font-bold text-[#ffe29b] active:scale-95"
                  >
                    −
                  </button>
                  <span className="font-bengali-ui min-w-[36px] text-center tabular-nums font-extrabold text-[#ffd562]">
                    {toBengaliNumber(Math.round(selectedConfig.size * 100))}%
                  </span>
                  <button
                    type="button"
                    onClick={() => handleStepSize(5)}
                    aria-label="আকার বাড়ান"
                    className="flex h-5 w-5 items-center justify-center rounded border border-[#e8bc6a]/35 bg-[#261a12] text-xs font-bold text-[#ffe29b] active:scale-95"
                  >
                    +
                  </button>
                </div>
              </div>
              <input
                id="hud-size-slider"
                type="range"
                min={50}
                max={150}
                step={1}
                value={Math.round(selectedConfig.size * 100)}
                onChange={(e) => handleSizeChange(Number(e.target.value))}
                className="h-2 w-full cursor-pointer appearance-none rounded-full bg-[#362519] accent-[#f5b415]"
              />
            </div>

            {/* Opacity Slider */}
            <div className="flex flex-col gap-1">
              <div className="flex items-center justify-between gap-2 text-[11px] sm:text-xs">
                <label
                  htmlFor="hud-opacity-slider"
                  className="font-bengali-ui font-bold text-[#f2dec0]"
                >
                  স্বচ্ছতা (Opacity)
                </label>
                <span className="font-bengali-ui tabular-nums font-extrabold text-[#6ee4ff]">
                  {toBengaliNumber(Math.round(selectedConfig.opacity * 100))}%
                </span>
              </div>
              <input
                id="hud-opacity-slider"
                type="range"
                min={30}
                max={100}
                step={1}
                value={Math.round(selectedConfig.opacity * 100)}
                onChange={(e) => handleOpacityChange(Number(e.target.value))}
                className="h-2 w-full cursor-pointer appearance-none rounded-full bg-[#242c36] accent-[#38bdf8]"
              />
            </div>
          </div>
        </div>

        {/* Draggable & Resizable Live HUD Controls Canvas */}
        {HUD_CONTROL_ORDER.map((id) => {
          const cfg = draft[id];
          const isSelected = selectedId === id;
          const isInteracting = activeId === id;

          return (
            <div
              key={id}
              data-hud-control={id}
              onPointerDown={(e) => handleControlPointerDown(id, e)}
              style={{
                left: `${cfg.x}%`,
                top: `${cfg.y}%`,
                transform: `translate(-50%, -50%) scale(${cfg.size})`,
                opacity: cfg.opacity,
                zIndex: isInteracting ? 32 : isSelected ? 25 : 12,
              }}
              className={`touch-control-btn absolute cursor-grab touch-none select-none active:cursor-grabbing ${
                isSelected
                  ? 'rounded-2xl ring-2 ring-[#ffe066] ring-offset-4 ring-offset-black/45'
                  : 'rounded-2xl ring-1 ring-white/25'
              }`}
            >
              <div className="pointer-events-none">{renderControlVisual(id)}</div>

              {/* Direct Drag-to-Resize Corner Handle on Selected Control (compensated for scale so always easy to grab) */}
              {isSelected && (
                <button
                  type="button"
                  aria-label={`${HUD_CONTROL_META[id].label} আকার পরিবর্তন`}
                  onPointerDown={(e) => handleResizePointerDown(id, e)}
                  style={{
                    transform: `scale(${1 / Math.max(0.55, cfg.size)})`,
                  }}
                  className={`absolute -bottom-3 -right-3 flex h-7 w-7 cursor-nwse-resize touch-none items-center justify-center rounded-full border-2 border-[#231407] bg-gradient-to-b from-[#ffe269] to-[#e69508] text-[#231407] shadow-[0_3px_12px_rgba(0,0,0,0.65)] ${
                    isInteracting && activeMode === 'resize' ? 'ring-2 ring-white' : ''
                  }`}
                >
                  <svg
                    viewBox="0 0 24 24"
                    className="pointer-events-none h-3.5 w-3.5 fill-none stroke-current stroke-[2.6]"
                  >
                    <path d="M15 4h5v5" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M9 20H4v-5" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M20 4l-6 6" strokeLinecap="round" />
                    <path d="M4 20l6-6" strokeLinecap="round" />
                  </svg>
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
