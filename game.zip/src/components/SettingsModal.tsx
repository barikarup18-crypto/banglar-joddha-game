import React, { useState } from 'react';
import { toBengaliNumber } from '../game/GameEngine';
import {
  DEFAULT_GAME_SETTINGS,
  GameSettings,
  GraphicsQuality,
  HUD_CONTROL_META,
  HUD_CONTROL_ORDER,
} from '../game/settings';

type SettingsTab = 'controls' | 'sensitivity' | 'display';

interface SettingsModalProps {
  open: boolean;
  settings: GameSettings;
  onUpdateSettings: (updater: (prev: GameSettings) => GameSettings) => void;
  onOpenCustomHud: () => void;
  onResetCustomHud: () => void;
  onClose: () => void;
}

const GRAPHICS_OPTIONS: {
  id: GraphicsQuality;
  label: string;
  sublabel: string;
  detail: string;
}[] = [
  {
    id: 'low',
    label: 'নিম্ন (Low)',
    sublabel: 'সর্বোচ্চ FPS',
    detail: 'শ্যাডো বন্ধ · ১.০x রেজোলিউশন',
  },
  {
    id: 'medium',
    label: 'মাঝারি (Medium)',
    sublabel: 'ব্যালেন্সড',
    detail: '১০২৪ শ্যাডো · ১.২৫x রেজোলিউশন',
  },
  {
    id: 'high',
    label: 'উচ্চ (High)',
    sublabel: 'শার্প গ্রাফিক্স',
    detail: '২০৪৮ শ্যাডো · ১.৫x রেজোলিউশন',
  },
];

export const SettingsModal: React.FC<SettingsModalProps> = ({
  open,
  settings,
  onUpdateSettings,
  onOpenCustomHud,
  onResetCustomHud,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<SettingsTab>('controls');

  if (!open) return null;

  const handleResetSensitivity = () => {
    onUpdateSettings((prev) => ({
      ...prev,
      generalSensitivity: DEFAULT_GAME_SETTINGS.generalSensitivity,
      scopeSensitivity: DEFAULT_GAME_SETTINGS.scopeSensitivity,
    }));
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="সেটিংস"
      onPointerDown={(e) => e.stopPropagation()}
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#0a0b09]/86 pb-[max(0.75rem,env(safe-area-inset-bottom))] pl-[max(0.75rem,env(safe-area-inset-left))] pr-[max(0.75rem,env(safe-area-inset-right))] pt-[max(0.75rem,env(safe-area-inset-top))]"
    >
      <div className="flex max-h-[calc(100dvh-1.5rem-env(safe-area-inset-top)-env(safe-area-inset-bottom))] w-full max-w-[680px] flex-col overflow-hidden rounded-xl border border-[#b59c6b]/50 bg-[#141512] text-[#ece6d8] shadow-[0_24px_64px_rgba(0,0,0,0.88)]">
        {/* Header */}
        <div className="flex items-center justify-between gap-4 border-b border-[#b59c6b]/20 bg-[#0f100e] px-4 py-3 sm:px-6 sm:py-4">
          <div className="flex items-center gap-2.5">
            <svg
              viewBox="0 0 24 24"
              className="h-5 w-5 shrink-0 fill-none stroke-[#d9b566] stroke-2"
              aria-hidden="true"
            >
              <circle cx="12" cy="12" r="3" />
              <path
                d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.08a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h.08a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v.08a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <h2 className="font-bengali-display whitespace-nowrap text-lg font-bold tracking-wide text-[#e2c278] sm:text-xl">
              সেটিংস
            </h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="সেটিংস বন্ধ করুন"
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-[#b59c6b]/35 bg-[#1b1c19] text-sm font-bold text-[#dfd5c3] transition-colors hover:border-[#d9b566]/70 hover:bg-[#252622] active:scale-95"
          >
            ✕
          </button>
        </div>

        {/* Body: Left Tactical Tab Rail on landscape/sm+ & Top Segmented Tabs on narrow portrait */}
        <div className="flex min-h-0 flex-1 flex-col sm:flex-row">
          {/* Tab Navigation */}
          <nav
            aria-label="সেটিংস বিভাগ"
            className="flex shrink-0 gap-1.5 border-b border-[#b59c6b]/18 bg-[#10110f] p-2.5 sm:w-48 sm:flex-col sm:gap-2 sm:border-b-0 sm:border-r sm:p-4"
          >
            <button
              type="button"
              onClick={() => setActiveTab('controls')}
              className={`font-bengali-ui flex min-h-[42px] flex-1 items-center justify-center gap-2 whitespace-nowrap rounded-lg border px-3 py-2 text-xs font-bold transition-colors sm:flex-none sm:justify-start sm:text-sm ${
                activeTab === 'controls'
                  ? 'border-[#d9b566]/80 bg-[#23211a] text-[#f2eadb]'
                  : 'border-transparent bg-transparent text-[#ada391] hover:bg-[#1a1b18] hover:text-[#ece6d8]'
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-current stroke-2">
                <rect x="2" y="6" width="20" height="12" rx="4" />
                <path d="M6 12h4M8 10v4" strokeLinecap="round" />
                <circle cx="15.5" cy="11" r="1" className="fill-current" />
                <circle cx="18" cy="13" r="1" className="fill-current" />
              </svg>
              <span>কন্ট্রোল</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('sensitivity')}
              className={`font-bengali-ui flex min-h-[42px] flex-1 items-center justify-center gap-2 whitespace-nowrap rounded-lg border px-3 py-2 text-xs font-bold transition-colors sm:flex-none sm:justify-start sm:text-sm ${
                activeTab === 'sensitivity'
                  ? 'border-[#d9b566]/80 bg-[#23211a] text-[#f2eadb]'
                  : 'border-transparent bg-transparent text-[#ada391] hover:bg-[#1a1b18] hover:text-[#ece6d8]'
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-current stroke-2">
                <circle cx="12" cy="12" r="8" />
                <line x1="12" y1="2" x2="12" y2="6" strokeLinecap="round" />
                <line x1="12" y1="18" x2="12" y2="22" strokeLinecap="round" />
                <line x1="2" y1="12" x2="6" y2="12" strokeLinecap="round" />
                <line x1="18" y1="12" x2="22" y2="12" strokeLinecap="round" />
              </svg>
              <span>সেন্সিটিভিটি</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('display')}
              className={`font-bengali-ui flex min-h-[42px] flex-1 items-center justify-center gap-2 whitespace-nowrap rounded-lg border px-3 py-2 text-xs font-bold transition-colors sm:flex-none sm:justify-start sm:text-sm ${
                activeTab === 'display'
                  ? 'border-[#d9b566]/80 bg-[#23211a] text-[#f2eadb]'
                  : 'border-transparent bg-transparent text-[#ada391] hover:bg-[#1a1b18] hover:text-[#ece6d8]'
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 fill-none stroke-current stroke-2">
                <rect x="3" y="4" width="18" height="12" rx="2" />
                <path d="M8 20h8M12 16v4" strokeLinecap="round" />
              </svg>
              <span>গ্রাফিক্স ও শব্দ</span>
            </button>
          </nav>

          {/* Active Tab Content */}
          <div className="min-h-0 flex-1 overflow-y-auto p-4 sm:p-6">
            {/* TAB 1: CONTROLS & CUSTOM HUD */}
            {activeTab === 'controls' && (
              <div className="space-y-5">
                <div>
                  <h3 className="font-bengali-display text-base font-bold text-[#ffe294] sm:text-lg">
                    কন্ট্রোল ও কাস্টম HUD
                  </h3>
                  <p className="font-bengali-ui mt-1 text-xs leading-relaxed text-[#d9c1a0] sm:text-sm">
                    আপনার খেলার ধরন অনুযায়ী যেকোনো বাটন টেনে সরান, আকার (৫০%–১৫০%) এবং স্বচ্ছতা (৩০%–১০০%) নিজের মতো সাজিয়ে নিন।
                  </p>
                </div>

                {/* Primary CTA: Launch Full-Screen Custom HUD Editor */}
                <div className="flex flex-wrap items-center gap-3 border-y border-[#b59c6b]/18 py-4">
                  <button
                    type="button"
                    onClick={onOpenCustomHud}
                    className="font-bengali-display flex min-h-[46px] flex-1 items-center justify-center gap-2 whitespace-nowrap rounded-lg border border-[#dec07c]/80 bg-gradient-to-b from-[#b88628] via-[#996d1b] to-[#6e4a10] px-5 py-2.5 text-sm font-extrabold tracking-wide text-[#140e06] shadow-[0_6px_16px_rgba(0,0,0,0.55),inset_0_1px_0_rgba(255,244,210,0.28)] transition hover:brightness-110 active:scale-[0.98] sm:text-base"
                  >
                    <svg viewBox="0 0 24 24" className="h-5 w-5 shrink-0 fill-none stroke-current stroke-2">
                      <path d="M5 9l-3 3 3 3M9 5l3-3 3 3M15 19l-3 3-3-3M19 9l3 3-3 3" strokeLinecap="round" strokeLinejoin="round" />
                      <line x1="2" y1="12" x2="22" y2="12" strokeLinecap="round" />
                      <line x1="12" y1="2" x2="12" y2="22" strokeLinecap="round" />
                    </svg>
                    <span>কাস্টম বাটন সাজান</span>
                  </button>

                  <button
                    type="button"
                    onClick={onResetCustomHud}
                    className="font-bengali-ui min-h-[46px] shrink-0 whitespace-nowrap rounded-lg border border-[#b59c6b]/35 bg-[#1b1c19] px-4 py-2 text-xs font-bold text-[#dfd5c3] transition-colors hover:border-[#d9b566]/70 hover:bg-[#252622] active:scale-95 sm:text-sm"
                  >
                    রিসেট
                  </button>
                </div>

                {/* Clean Tabular Readout of Customizable Controls */}
                <div>
                  <div className="font-bengali-ui mb-2 text-xs font-bold text-[#e7c995]">
                    কাস্টমাইজযোগ্য কন্ট্রোল ({toBengaliNumber(HUD_CONTROL_ORDER.length)}টি)
                  </div>
                  <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-xs">
                    {HUD_CONTROL_ORDER.map((id) => {
                      const cfg = settings.customHud[id];
                      return (
                        <div
                          key={id}
                          className="flex items-center justify-between gap-2 border-b border-[#e8bc6a]/10 py-1.5"
                        >
                          <span className="font-bengali-ui truncate font-semibold text-[#f5e4c8]">
                            {HUD_CONTROL_META[id].shortLabel}
                          </span>
                          <span className="font-bengali-ui tabular-nums whitespace-nowrap text-[11px] text-[#cbb08b]">
                            {toBengaliNumber(Math.round(cfg.size * 100))}% ·{' '}
                            {toBengaliNumber(Math.round(cfg.opacity * 100))}%
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: SENSITIVITY */}
            {activeTab === 'sensitivity' && (
              <div className="space-y-6">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="font-bengali-display text-base font-bold text-[#ffe294] sm:text-lg">
                      সেন্সিটিভিটি
                    </h3>
                    <p className="font-bengali-ui mt-1 text-xs text-[#d9c1a0] sm:text-sm">
                      ক্যামেরা ঘোরানো এবং স্কোপ দিয়ে লক্ষ্য ঠিক করার গতি নির্ধারণ করুন।
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleResetSensitivity}
                    className="font-bengali-ui shrink-0 whitespace-nowrap rounded-lg border border-[#e8bc6a]/35 bg-[#251a13] px-3 py-1.5 text-xs font-bold text-[#f2dcba] hover:border-[#ffd25a]/70 hover:bg-[#332319]"
                  >
                    রিসেট
                  </button>
                </div>

                {/* General Camera Sensitivity Slider */}
                <div className="space-y-2.5 border-t border-[#e8bc6a]/15 pt-4">
                  <div className="flex items-center justify-between gap-2">
                    <label
                      htmlFor="slider-general-sens"
                      className="font-bengali-ui text-sm font-bold text-[#fff1d4]"
                    >
                      সাধারণ ক্যামেরা গতি
                    </label>
                    <span className="font-bengali-ui tabular-nums text-base font-extrabold text-[#ffd562]">
                      {toBengaliNumber(settings.generalSensitivity)}
                    </span>
                  </div>
                  <input
                    id="slider-general-sens"
                    type="range"
                    min={0}
                    max={100}
                    step={1}
                    value={settings.generalSensitivity}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      onUpdateSettings((prev) => ({ ...prev, generalSensitivity: val }));
                    }}
                    className="h-2.5 w-full cursor-pointer appearance-none rounded-full bg-[#362519] accent-[#f5b415]"
                  />
                  <div className="font-bengali-ui flex justify-between text-[11px] text-[#bda380]">
                    <span>০ (ধীর)</span>
                    <span>৫০ (স্বাভাবিক)</span>
                    <span>১০০ (দ্রুত)</span>
                  </div>
                </div>

                {/* Scope Aim Sensitivity Slider */}
                <div className="space-y-2.5 border-t border-[#e8bc6a]/15 pt-4">
                  <div className="flex items-center justify-between gap-2">
                    <label
                      htmlFor="slider-scope-sens"
                      className="font-bengali-ui text-sm font-bold text-[#fff1d4]"
                    >
                      স্কোপ নিশানা গতি
                    </label>
                    <span className="font-bengali-ui tabular-nums text-base font-extrabold text-[#6ee4ff]">
                      {toBengaliNumber(settings.scopeSensitivity)}
                    </span>
                  </div>
                  <input
                    id="slider-scope-sens"
                    type="range"
                    min={0}
                    max={100}
                    step={1}
                    value={settings.scopeSensitivity}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      onUpdateSettings((prev) => ({ ...prev, scopeSensitivity: val }));
                    }}
                    className="h-2.5 w-full cursor-pointer appearance-none rounded-full bg-[#242c36] accent-[#38bdf8]"
                  />
                  <div className="font-bengali-ui flex justify-between text-[11px] text-[#bda380]">
                    <span>০ (নিখুঁত)</span>
                    <span>৫০ (ব্যালেন্সড)</span>
                    <span>১০০ (দ্রুত)</span>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 3: DISPLAY & AUDIO */}
            {activeTab === 'display' && (
              <div className="space-y-6">
                <div>
                  <h3 className="font-bengali-display text-base font-bold text-[#ffe294] sm:text-lg">
                    গ্রাফিক্স ও শব্দ
                  </h3>
                  <p className="font-bengali-ui mt-1 text-xs text-[#d9c1a0] sm:text-sm">
                    মোবাইলে স্মুথ FPS-এর জন্য গ্রাফিক্স মান এবং গেমের সাউন্ড ইফেক্ট নিয়ন্ত্রণ করুন।
                  </p>
                </div>

                {/* Graphics Quality Selector */}
                <div className="space-y-2.5 border-t border-[#e8bc6a]/15 pt-4">
                  <div className="font-bengali-ui text-sm font-bold text-[#fff1d4]">
                    গ্রাফিক্স কোয়ালিটি
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {GRAPHICS_OPTIONS.map((opt) => {
                      const active = settings.graphicsQuality === opt.id;
                      return (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() =>
                            onUpdateSettings((prev) => ({
                              ...prev,
                              graphicsQuality: opt.id,
                            }))
                          }
                          className={`flex min-h-[68px] flex-col items-center justify-center rounded-xl border px-2 py-2.5 text-center transition-colors active:scale-95 ${
                            active
                              ? 'border-[#ffd25a] bg-[#332111] text-[#fff6dc]'
                              : 'border-[#e8bc6a]/22 bg-[#211711] text-[#cfb693] hover:border-[#e8bc6a]/50 hover:bg-[#2b1e16]'
                          }`}
                        >
                          <span className="font-bengali-ui whitespace-nowrap text-xs font-extrabold sm:text-sm">
                            {opt.label}
                          </span>
                          <span
                            className={`font-bengali-ui mt-0.5 whitespace-nowrap text-[10px] font-semibold ${
                              active ? 'text-[#ffd562]' : 'text-[#a88e6d]'
                            }`}
                          >
                            {opt.sublabel}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                  <div className="font-bengali-ui text-xs text-[#c7ae8b]">
                    {GRAPHICS_OPTIONS.find((o) => o.id === settings.graphicsQuality)?.detail}
                  </div>
                </div>

                {/* Sound Effects Toggle & Volume Slider */}
                <div className="space-y-4 border-t border-[#e8bc6a]/15 pt-4">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <div className="font-bengali-ui text-sm font-bold text-[#fff1d4]">
                        সাউন্ড ইফেক্টস
                      </div>
                      <div className="font-bengali-ui text-xs text-[#bfa684]">
                        গুলির শব্দ, রিলোড, বিস্ফোরণ ও পরিবেশের শব্দ
                      </div>
                    </div>

                    <button
                      type="button"
                      role="switch"
                      aria-checked={settings.sfxEnabled}
                      onClick={() =>
                        onUpdateSettings((prev) => ({
                          ...prev,
                          sfxEnabled: !prev.sfxEnabled,
                        }))
                      }
                      className={`font-bengali-ui flex min-h-[40px] min-w-[84px] shrink-0 items-center justify-center whitespace-nowrap rounded-xl border px-3.5 text-xs font-extrabold transition-colors active:scale-95 ${
                        settings.sfxEnabled
                          ? 'border-[#ffd25a] bg-[#362410] text-[#ffe58f]'
                          : 'border-[#e8bc6a]/25 bg-[#201610] text-[#a68f75]'
                      }`}
                    >
                      {settings.sfxEnabled ? 'চালু' : 'বন্ধ'}
                    </button>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <label
                        htmlFor="slider-sfx-volume"
                        className="font-bengali-ui text-xs font-bold text-[#e6cca4] sm:text-sm"
                      >
                        শব্দের মাত্রা
                      </label>
                      <span className="font-bengali-ui tabular-nums text-sm font-extrabold text-[#ffd562]">
                        {toBengaliNumber(settings.sfxEnabled ? settings.sfxVolume : 0)}%
                      </span>
                    </div>
                    <input
                      id="slider-sfx-volume"
                      type="range"
                      min={0}
                      max={100}
                      step={1}
                      value={settings.sfxVolume}
                      disabled={!settings.sfxEnabled}
                      onChange={(e) => {
                        const val = Number(e.target.value);
                        onUpdateSettings((prev) => ({
                          ...prev,
                          sfxVolume: val,
                          sfxEnabled: val > 0 ? true : prev.sfxEnabled,
                        }));
                      }}
                      className="h-2.5 w-full cursor-pointer appearance-none rounded-full bg-[#362519] accent-[#f5b415] disabled:cursor-not-allowed disabled:opacity-45"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between gap-3 border-t border-[#b59c6b]/18 bg-[#0f100e] px-4 py-2.5 sm:px-6 sm:py-3">
          <span className="font-bengali-ui text-[11px] text-[#a79d8a] sm:text-xs">
            সব পরিবর্তন স্বয়ংক্রিয়ভাবে সেভ হয়
          </span>
          <button
            type="button"
            onClick={onClose}
            className="font-bengali-ui min-h-[40px] shrink-0 whitespace-nowrap rounded-lg border border-[#d9b566]/65 bg-[#23211a] px-5 py-2 text-xs font-bold text-[#e6cf98] transition-colors hover:bg-[#2f2c22] active:scale-95 sm:text-sm"
          >
            সম্পন্ন
          </button>
        </div>
      </div>
    </div>
  );
};
