import React, { useEffect, useRef, useState } from 'react';
import { toBengaliNumber } from '../game/GameEngine';
import { MAX_GUEST_NAME_LENGTH, sanitizeGuestName } from '../game/loadoutStorage';
import { GamchaStyle } from '../game/types';

interface GuestProfileModalProps {
  open: boolean;
  currentName: string | null;
  playerId: string;
  playerLevel: number;
  gamchaStyle: GamchaStyle;
  isMandatory: boolean;
  onConfirm: (guestName: string) => void;
  onClose?: () => void;
}

export const GuestProfileModal: React.FC<GuestProfileModalProps> = ({
  open,
  currentName,
  playerId,
  playerLevel,
  gamchaStyle,
  isMandatory,
  onConfirm,
  onClose,
}) => {
  const [nameInput, setNameInput] = useState<string>(currentName ?? '');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!open) return;
    setNameInput(currentName ?? '');
    setErrorMessage(null);
    const timer = window.setTimeout(() => {
      inputRef.current?.focus();
    }, 60);
    return () => window.clearTimeout(timer);
  }, [open, currentName]);

  if (!open) return null;

  const trimmedPreview = sanitizeGuestName(nameInput);

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const cleaned = sanitizeGuestName(nameInput);
    if (!cleaned) {
      setErrorMessage('নাম খালি রাখা যাবে না — এগোতে আপনার নাম লিখুন (Please enter your name).');
      inputRef.current?.focus();
      return;
    }
    setErrorMessage(null);
    onConfirm(cleaned);
  };

  const handleBackdropClick = (event: React.MouseEvent<HTMLDivElement>) => {
    if (event.target === event.currentTarget && !isMandatory && onClose) {
      onClose();
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="guest-modal-title"
      onClick={handleBackdropClick}
      onPointerDown={(e) => e.stopPropagation()}
      onKeyDown={(e) => {
        e.stopPropagation();
        if (e.key === 'Escape' && !isMandatory && onClose) {
          onClose();
        }
      }}
      onKeyUp={(e) => e.stopPropagation()}
      className="fixed inset-0 z-[70] flex items-center justify-center bg-[#0a0b09]/88 pb-[max(0.75rem,env(safe-area-inset-bottom))] pl-[max(0.75rem,env(safe-area-inset-left))] pr-[max(0.75rem,env(safe-area-inset-right))] pt-[max(0.75rem,env(safe-area-inset-top))]"
    >
      <div className="flex max-h-[calc(100dvh-1.5rem-env(safe-area-inset-top)-env(safe-area-inset-bottom))] w-full max-w-[420px] flex-col overflow-y-auto rounded-xl border border-[#b59c6b]/55 bg-[#141512] text-[#ece6d8] shadow-[0_24px_64px_rgba(0,0,0,0.9)]">
        {/* Header */}
        <div className="flex items-center justify-between gap-3 border-b border-[#b59c6b]/22 bg-[#0f100e] px-4 py-3 sm:px-5 sm:py-3.5">
          <div className="flex min-w-0 items-center gap-3">
            <div className="relative flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-md border border-[#b59c6b]/60 bg-gradient-to-b from-[#6e241f] to-[#2c110e]">
              <svg viewBox="0 0 40 40" className="h-9 w-9" aria-hidden="true">
                <path
                  d="M6 38 Q20 26 34 38 Z"
                  fill={gamchaStyle === 'red-white' ? '#c92228' : '#1b7a3d'}
                />
                <path d="M10 38 Q20 30 30 38 Z" fill="#faf3e6" fillOpacity="0.65" />
                <circle cx="20" cy="17" r="8.5" fill="#c99163" />
                <path d="M11 16 C11 8, 29 8, 29 16 C26 11, 14 11, 11 16 Z" fill="#181414" />
                <rect
                  x="11.5"
                  y="12.5"
                  width="17"
                  height="2.8"
                  rx="1"
                  fill={gamchaStyle === 'red-white' ? '#d42028' : '#208844'}
                />
                <path
                  d="M16.5 21 Q20 19.6 23.5 21"
                  stroke="#181414"
                  strokeWidth="1.6"
                  fill="none"
                  strokeLinecap="round"
                />
              </svg>
            </div>

            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-bengali-ui text-[10px] font-bold uppercase tracking-wider text-[#d9b566]">
                  বাংলার যোদ্ধা
                </span>
                <span className="rounded-sm border border-[#b59c6b]/25 bg-[#1e1f1b] px-1.5 py-0.5 font-mono text-[9px] font-bold text-[#d9b566]">
                  {playerId}
                </span>
                <span className="font-bengali-ui text-[10px] font-semibold text-[#b3a895]">
                  LV {toBengaliNumber(playerLevel)}
                </span>
              </div>
              <h2
                id="guest-modal-title"
                className="font-bengali-display truncate text-base font-extrabold tracking-wide text-[#ece6d8] sm:text-lg"
              >
                {isMandatory ? 'Play as Guest · অতিথি প্রবেশ' : 'গেস্ট প্রোফাইল · Guest Profile'}
              </h2>
            </div>
          </div>

          {!isMandatory && onClose && (
            <button
              type="button"
              onClick={onClose}
              aria-label="প্রোফাইল বন্ধ করুন"
              className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md border border-[#b59c6b]/35 bg-[#1c1d19] text-[#d9c396] transition hover:border-[#d9b566]/75 hover:bg-[#272823]"
            >
              <svg viewBox="0 0 20 20" className="h-4 w-4" aria-hidden="true">
                <path
                  d="M5 5l10 10M15 5L5 15"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                />
              </svg>
            </button>
          )}
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-3 px-4 py-3.5 sm:px-5 sm:py-4">
          <p className="font-bengali-ui text-xs leading-relaxed text-[#e6cca2]">
            {isMandatory
              ? 'গেমে প্রবেশ করতে আপনার গেস্ট নাম লিখুন। নামটি এই ডিভাইসে ভবিষ্যতের জন্য সংরক্ষিত থাকবে।'
              : 'আপনার গেস্ট নাম পরিবর্তন করুন। নতুন নামটি এই ডিভাইসে লোকালি সংরক্ষিত থাকবে।'}
          </p>

          <div>
            <div className="mb-1.5 flex items-center justify-between gap-2">
              <label
                htmlFor="guest-player-name-input"
                className="font-bengali-ui text-xs font-bold text-[#ffe29a]"
              >
                খেলোয়াড়ের নাম (Player Name) <span className="text-[#ff7866]">*</span>
              </label>
              <span className="font-mono text-[10px] text-[#c7aa7e]">
                {trimmedPreview.length}/{MAX_GUEST_NAME_LENGTH}
              </span>
            </div>

            <input
              ref={inputRef}
              id="guest-player-name-input"
              type="text"
              value={nameInput}
              maxLength={MAX_GUEST_NAME_LENGTH}
              autoComplete="nickname"
              spellCheck={false}
              placeholder="আপনার নাম লিখুন / Enter your name"
              aria-required="true"
              aria-invalid={Boolean(errorMessage)}
              aria-describedby={errorMessage ? 'guest-name-error' : undefined}
              onChange={(e) => {
                setNameInput(e.target.value);
                if (errorMessage && sanitizeGuestName(e.target.value).length > 0) {
                  setErrorMessage(null);
                }
              }}
              className={`font-bengali-ui w-full rounded-lg border bg-[#0e0f0d] px-3.5 py-2.5 text-sm font-semibold text-[#ece6d8] placeholder-[#7f7868] outline-none transition ${
                errorMessage
                  ? 'border-[#d45748] ring-2 ring-[#d45748]/25'
                  : 'border-[#b59c6b]/40 focus:border-[#d9b566] focus:ring-2 focus:ring-[#d9b566]/20'
              }`}
            />

            {errorMessage && (
              <div
                id="guest-name-error"
                role="alert"
                className="font-bengali-ui mt-1.5 flex items-start gap-1.5 rounded-md border border-[#c95347]/50 bg-[#291311]/95 px-2.5 py-1.5 text-[11px] font-semibold leading-snug text-[#f2bcb4]"
              >
                <svg
                  viewBox="0 0 20 20"
                  className="mt-0.5 h-3.5 w-3.5 shrink-0 fill-[#df6858]"
                  aria-hidden="true"
                >
                  <path d="M10 2a8 8 0 1 0 0 16 8 8 0 0 0 0-16zm0 4.25a.9.9 0 0 1 .9.9v3.7a.9.9 0 0 1-1.8 0v-3.7a.9.9 0 0 1 .9-.9zm0 7.75a1.05 1.05 0 1 1 0-2.1 1.05 1.05 0 0 1 0 2.1z" />
                </svg>
                <span>{errorMessage}</span>
              </div>
            )}
          </div>

          <div className="mt-0.5 flex items-center justify-end gap-2">
            {!isMandatory && onClose && (
              <button
                type="button"
                onClick={onClose}
                className="font-bengali-ui rounded-lg border border-[#b59c6b]/35 bg-[#1c1d19] px-3.5 py-2 text-xs font-bold text-[#d4cbb8] transition hover:border-[#d9b566]/65 hover:bg-[#262722]"
              >
                বাতিল
              </button>
            )}

            <button
              type="submit"
              className={`font-bengali-display flex items-center justify-center gap-2 rounded-lg border border-[#d68c74]/70 bg-gradient-to-b from-[#9e2922] via-[#801e18] to-[#5c1310] px-4 py-2.5 text-sm font-extrabold tracking-wide text-[#f4ebe0] shadow-[0_8px_20px_rgba(0,0,0,0.6),inset_0_1px_0_rgba(255,220,200,0.22)] transition hover:brightness-110 active:scale-[0.99] ${
                isMandatory ? 'w-full' : ''
              }`}
            >
              <span>{isMandatory ? 'Play as Guest' : 'নাম সংরক্ষণ করুন'}</span>
              <span className="font-bengali-ui text-xs font-bold text-[#e6c98a]">
                {isMandatory ? '· খেলায় প্রবেশ' : '· Save'}
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
