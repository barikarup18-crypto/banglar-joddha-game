import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { ChestAnchor } from './battleRoyaleAssets';
import { CircleCollider } from './types';

export interface MarketZoneResult {
  group: THREE.Group;
  colliders: CircleCollider[];
  chestAnchors: ChestAnchor[];
  sanjibaniAnchors: Array<{ x: number; z: number }>;
  enemySpawns: THREE.Vector3[];
  bicycleAnchors: Array<{ x: number; z: number; rotY: number; colorIdx: number }>;
  motorcycleAnchors: Array<{ x: number; z: number; rotY: number; colorIdx: number }>;
}

export interface TwoWheelerPlacement {
  x: number;
  y: number;
  z: number;
  rotY: number;
  colorIdx: number;
}

/**
 * Normalizes and merges an array of BufferGeometries into a single geometry for InstancedMesh batching.
 */
function mergeParts(parts: THREE.BufferGeometry[], keepUv = false): THREE.BufferGeometry {
  const normalized = parts.map((raw) => {
    const g = raw.index ? raw.toNonIndexed() : raw.clone();
    if (!g.attributes.normal) g.computeVertexNormals();
    if (!keepUv && g.attributes.uv) {
      g.deleteAttribute('uv');
    } else if (keepUv && !g.attributes.uv) {
      const count = g.attributes.position.count;
      g.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(count * 2), 2));
    }
    if (g.attributes.color) g.deleteAttribute('color');
    raw.dispose();
    return g;
  });
  const merged = mergeGeometries(normalized, false);
  normalized.forEach((g) => g.dispose());
  if (!merged) {
    throw new Error('Failed to merge Kolkata market geometry batch');
  }
  merged.computeBoundingSphere();
  return merged;
}

/**
 * Adds tight rotated twin-circle collision footprints for a rectangular building or stall so actors
 * glide cleanly along facades and around alley corners without snagging or clipping.
 */
function addRotatedFootprintColliders(
  colliders: CircleCollider[],
  cx: number,
  cz: number,
  width: number,
  depth: number,
  rotY: number,
  height: number,
  baseY: number,
  kind: CircleCollider['kind'],
): void {
  const halfMajor = Math.max(width, depth) * 0.5;
  const halfMinor = Math.min(width, depth) * 0.5;
  const radius = halfMinor + 0.14;
  const offset = Math.max(0, halfMajor - halfMinor * 0.92);

  if (offset < 0.35) {
    colliders.push({ x: cx, z: cz, radius: halfMajor + 0.1, height, baseY, kind });
    return;
  }

  const cosY = Math.cos(rotY);
  const sinY = Math.sin(rotY);
  const axisX = width >= depth ? cosY : sinY;
  const axisZ = width >= depth ? -sinY : cosY;

  for (const sign of [-1, 1]) {
    colliders.push({
      x: cx + axisX * offset * sign,
      z: cz + axisZ * offset * sign,
      radius,
      height,
      baseY,
      kind,
    });
  }
}

/**
 * Procedural weathered Bengali market signboard CanvasTexture (SRGBColorSpace, crisp typography).
 */
function createBengaliSignTexture(
  titleBn: string,
  subtitleBn: string,
  bgHex: string,
  borderHex: string,
  textHex: string,
  accentHex: string,
  weathered = false,
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 160;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = bgHex;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Subtle painted board grain & sun-fade gradient
  const grad = ctx.createLinearGradient(0, 0, 0, canvas.height);
  grad.addColorStop(0, 'rgba(255,255,255,0.12)');
  grad.addColorStop(0.55, 'rgba(0,0,0,0)');
  grad.addColorStop(1, 'rgba(0,0,0,0.22)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Decorative Kolkata signboard border
  ctx.strokeStyle = borderHex;
  ctx.lineWidth = 10;
  ctx.strokeRect(10, 10, canvas.width - 20, canvas.height - 20);
  ctx.strokeStyle = accentHex;
  ctx.lineWidth = 3;
  ctx.strokeRect(20, 20, canvas.width - 40, canvas.height - 40);

  // Gritty rust streaks for Chor Bazaar signs
  if (weathered) {
    ctx.fillStyle = 'rgba(116, 52, 24, 0.32)';
    for (let i = 0; i < 16; i++) {
      const rx = 24 + ((i * 71) % 460);
      const rw = 8 + (i % 5) * 6;
      const rh = 18 + (i % 4) * 16;
      ctx.fillRect(rx, 10, rw, rh);
    }
    ctx.fillStyle = 'rgba(40, 32, 26, 0.22)';
    for (let i = 0; i < 12; i++) {
      const rx = 30 + ((i * 93) % 450);
      ctx.fillRect(rx, 118, 22, 28);
    }
  }

  // Primary Bengali title
  ctx.fillStyle = textHex;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = 'bold 54px "Hind Siliguri", "Noto Sans Bengali", sans-serif';
  ctx.fillText(titleBn, canvas.width * 0.5, subtitleBn ? 66 : 82);

  if (subtitleBn) {
    ctx.fillStyle = accentHex;
    ctx.font = '600 26px "Hind Siliguri", "Noto Sans Bengali", sans-serif';
    ctx.fillText(subtitleBn, canvas.width * 0.5, 118);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

/**
 * Procedural striped Kolkata shopfront awning CanvasTexture.
 */
function createStripedAwningTexture(stripeA: string, stripeB: string): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  const stripes = 8;
  const sw = canvas.width / stripes;
  for (let i = 0; i < stripes; i++) {
    ctx.fillStyle = i % 2 === 0 ? stripeA : stripeB;
    ctx.fillRect(i * sw, 0, sw + 1, canvas.height);
  }
  // Subtle fabric weave darkening near lower edge
  const g = ctx.createLinearGradient(0, 0, 0, canvas.height);
  g.addColorStop(0, 'rgba(255,255,255,0.08)');
  g.addColorStop(1, 'rgba(0,0,0,0.22)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(2, 1);
  return tex;
}

// ============================================================================
// 1. কলকাতা বড়বাজার (KOLKATA BURRABAZAR — Dense Wholesale Market District)
//    Center: (118, 105), spans x in [78..158], z in [72..138] (80m x 66m)
// ============================================================================
export function buildBurrabazarZone(centerX: number, centerZ: number): MarketZoneResult {
  const group = new THREE.Group();
  group.position.set(centerX, 0, centerZ);
  const colliders: CircleCollider[] = [];
  const chestAnchors: ChestAnchor[] = [];
  const sanjibaniAnchors: Array<{ x: number; z: number }> = [];
  const enemySpawns: THREE.Vector3[] = [];
  const bicycleAnchors: MarketZoneResult['bicycleAnchors'] = [];
  const motorcycleAnchors: MarketZoneResult['motorcycleAnchors'] = [];

  const dummy = new THREE.Object3D();
  const tmpCol = new THREE.Color();

  // Shared materials with distinct PBR roughness/metalness contrast
  const streetAsphaltMat = new THREE.MeshStandardMaterial({
    color: 0x4c4b4a,
    roughness: 0.91,
    metalness: 0.04,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const chowkStoneMat = new THREE.MeshStandardMaterial({
    color: 0x7b7164,
    roughness: 0.88,
    metalness: 0.03,
    polygonOffset: true,
    polygonOffsetFactor: -2,
    polygonOffsetUnits: -2,
  });
  const plasterWallMat = new THREE.MeshStandardMaterial({
    color: 0xffffff, // Tinted per shophouse via setColorAt
    roughness: 0.86,
    metalness: 0.02,
  });
  const corniceTrimMat = new THREE.MeshStandardMaterial({
    color: 0xe6d6bc,
    roughness: 0.82,
    metalness: 0.03,
  });
  const greenShutterMat = new THREE.MeshStandardMaterial({
    color: 0x1e4d37, // Iconic Kolkata bottle-green khorkhori shutters
    roughness: 0.66,
    metalness: 0.08,
  });
  const steelShutterMat = new THREE.MeshStandardMaterial({
    color: 0x566470, // Rolled corrugated shopfront metal shutters & wrought-iron balconies
    roughness: 0.44,
    metalness: 0.68,
  });
  const awningTex = createStripedAwningTexture('#c9392b', '#f2e4c4');
  const awningMat = new THREE.MeshStandardMaterial({
    map: awningTex,
    roughness: 0.84,
    metalness: 0.02,
    side: THREE.DoubleSide,
  });
  const archBrickMat = new THREE.MeshStandardMaterial({
    color: 0x9f3b28,
    roughness: 0.84,
    metalness: 0.03,
  });
  const crateWoodMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    roughness: 0.88,
    metalness: 0.02,
  });
  const sackBurlapMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    roughness: 0.95,
    metalness: 0.0,
  });
  const ironPoleMat = new THREE.MeshStandardMaterial({
    color: 0x2f383e,
    roughness: 0.42,
    metalness: 0.78,
  });
  const warmLampMat = new THREE.MeshStandardMaterial({
    color: 0xffe4a0,
    emissive: 0xffb347,
    emissiveIntensity: 1.7,
    roughness: 0.25,
  });

  // 1a. Urban Market Street Grid Pavement & Central Burrabazar Chowk
  const marketPlaza = new THREE.Mesh(new THREE.PlaneGeometry(80, 66), streetAsphaltMat);
  marketPlaza.rotation.x = -Math.PI / 2;
  marketPlaza.position.set(0, 0.045, 0);
  marketPlaza.receiveShadow = true;
  group.add(marketPlaza);

  // Raised brick-paved central wholesale Chowk (crossroads plaza)
  const chowkPad = new THREE.Mesh(new THREE.PlaneGeometry(24, 22), chowkStoneMat);
  chowkPad.rotation.x = -Math.PI / 2;
  chowkPad.position.set(-2, 0.065, 2);
  chowkPad.receiveShadow = true;
  group.add(chowkPad);

  // 1b. Two Grand Heritage Kolkata Entry Archways ("কলকাতা বড়বাজার")
  // West Main Entry (local x = -38, z = 2) & North Zamindar-side Entry (local x = -2, z = -31)
  const mainSignTex = createBengaliSignTexture(
    'কলকাতা বড়বাজার',
    'পাইকারি বাজার ও গলি',
    '#7c1f19',
    '#e4b95b',
    '#fff4d6',
    '#f6cd6d',
    false,
  );
  const mainSignMat = new THREE.MeshStandardMaterial({
    map: mainSignTex,
    roughness: 0.55,
    metalness: 0.08,
  });

  const buildEntryArch = (lx: number, lz: number, rotY: number) => {
    const arch = new THREE.Group();
    arch.position.set(lx, 0, lz);
    arch.rotation.y = rotY;

    const spanHalf = 4.9; // 9.8m wide portal (even WBTC bus fits cleanly!)
    for (const sx of [-spanHalf, spanHalf]) {
      const base = new THREE.Mesh(new THREE.BoxGeometry(1.55, 0.7, 1.55), corniceTrimMat);
      base.position.set(sx, 0.35, 0);
      arch.add(base);

      const pillar = new THREE.Mesh(new THREE.BoxGeometry(1.18, 5.6, 1.18), archBrickMat);
      pillar.position.set(sx, 3.1, 0);
      pillar.castShadow = true;
      pillar.receiveShadow = true;
      arch.add(pillar);

      const cap = new THREE.Mesh(new THREE.BoxGeometry(1.52, 0.42, 1.52), corniceTrimMat);
      cap.position.set(sx, 6.0, 0);
      arch.add(cap);

      const finial = new THREE.Mesh(new THREE.SphereGeometry(0.42, 10, 8), corniceTrimMat);
      finial.position.set(sx, 6.52, 0);
      arch.add(finial);

      const cosY = Math.cos(rotY);
      const sinY = Math.sin(rotY);
      colliders.push({
        x: centerX + lx + sx * cosY,
        z: centerZ + lz - sx * sinY,
        radius: 0.85,
        height: 6.2,
        baseY: 0,
        kind: 'ruin',
      });
    }

    // Overhead beam & double-sided Bengali signboard
    const lintel = new THREE.Mesh(new THREE.BoxGeometry(spanHalf * 2 + 1.6, 0.65, 1.15), archBrickMat);
    lintel.position.set(0, 6.0, 0);
    lintel.castShadow = true;
    arch.add(lintel);

    const signBoard = new THREE.Mesh(new THREE.BoxGeometry(7.2, 2.05, 0.34), corniceTrimMat);
    signBoard.position.set(0, 7.25, 0);
    arch.add(signBoard);

    for (const sz of [0.19, -0.19]) {
      const face = new THREE.Mesh(new THREE.PlaneGeometry(6.8, 1.82), mainSignMat);
      face.position.set(0, 7.25, sz);
      if (sz < 0) face.rotation.y = Math.PI;
      arch.add(face);
    }

    group.add(arch);
  };

  buildEntryArch(-38, 2, Math.PI / 2); // West approach from Village Square
  buildEntryArch(-2, -31, 0); // North approach from Zamindar Bari

  // 1c. 10 Large Multi-Story Heritage Burrabazar Shophouses (Batched into just 5 InstancedMesh draw calls!)
  // Dimensions: 11.4m wide x 7.6m deep x 7.8m tall with ground-floor shops, upper balconies & overhangs
  const sw = 11.4;
  const sd = 7.6;
  const sh = 7.6;

  // Shophouse Part 1: Main plastered building volume + rooftop parapet + side pilasters
  const bodyParts: THREE.BufferGeometry[] = [];
  const mainVol = new THREE.BoxGeometry(sw, sh, sd);
  mainVol.translate(0, sh * 0.5, 0);
  bodyParts.push(mainVol);
  const paraH = 1.05;
  const pF = new THREE.BoxGeometry(sw + 0.1, paraH, 0.34);
  pF.translate(0, sh + paraH * 0.5, sd * 0.5 - 0.17);
  bodyParts.push(pF);
  const pB = new THREE.BoxGeometry(sw + 0.1, paraH, 0.34);
  pB.translate(0, sh + paraH * 0.5, -sd * 0.5 + 0.17);
  bodyParts.push(pB);
  const pL = new THREE.BoxGeometry(0.34, paraH, sd - 0.5);
  pL.translate(-sw * 0.5 + 0.17, sh + paraH * 0.5, 0);
  bodyParts.push(pL);
  const pR = new THREE.BoxGeometry(0.34, paraH, sd - 0.5);
  pR.translate(sw * 0.5 - 0.17, sh + paraH * 0.5, 0);
  bodyParts.push(pR);
  const shopBodyGeo = mergeParts(bodyParts, false);

  // Shophouse Part 2: Raised sidewalk plinth, mid-floor cornice, upper balcony slab, roofline molding & shop pilasters
  const trimParts: THREE.BufferGeometry[] = [];
  const plinth = new THREE.BoxGeometry(sw + 0.9, 0.42, sd + 1.15);
  plinth.translate(0, 0.21, 0.12);
  trimParts.push(plinth);
  const midBelt = new THREE.BoxGeometry(sw + 0.5, 0.32, sd + 0.5);
  midBelt.translate(0, 3.72, 0);
  trimParts.push(midBelt);
  const topBelt = new THREE.BoxGeometry(sw + 0.68, 0.36, sd + 0.68);
  topBelt.translate(0, sh, 0);
  trimParts.push(topBelt);
  // Projecting upper-floor Kolkata balcony along front (+Z)
  const balcFloor = new THREE.BoxGeometry(sw - 0.8, 0.24, 1.35);
  balcFloor.translate(0, 3.85, sd * 0.5 + 0.64);
  trimParts.push(balcFloor);
  // Ground-floor shopfront separating columns
  for (const px of [-sw * 0.46, -sw * 0.16, sw * 0.16, sw * 0.46]) {
    const pil = new THREE.BoxGeometry(0.46, 3.6, 0.46);
    pil.translate(px, 1.85, sd * 0.5 + 0.08);
    trimParts.push(pil);
  }
  const shopTrimGeo = mergeParts(trimParts, false);

  // Shophouse Part 3: Ground-floor steel shop shutters + upper balcony wrought-iron railings
  const metalParts: THREE.BufferGeometry[] = [];
  for (const sx of [-sw * 0.31, 0, sw * 0.31]) {
    const shutter = new THREE.BoxGeometry(2.65, 2.75, 0.24);
    shutter.translate(sx, 1.75, sd * 0.5 + 0.04);
    metalParts.push(shutter);
  }
  // Upper balcony wrought-iron rail bars
  const railTop = new THREE.BoxGeometry(sw - 0.75, 0.1, 0.12);
  railTop.translate(0, 4.92, sd * 0.5 + 1.24);
  metalParts.push(railTop);
  const railMid = new THREE.BoxGeometry(sw - 0.75, 0.08, 0.08);
  railMid.translate(0, 4.42, sd * 0.5 + 1.24);
  metalParts.push(railMid);
  for (let rx = -4.8; rx <= 4.81; rx += 1.2) {
    const post = new THREE.BoxGeometry(0.08, 1.05, 0.08);
    post.translate(rx, 4.42, sd * 0.5 + 1.24);
    metalParts.push(post);
  }
  const shopMetalGeo = mergeParts(metalParts, false);

  // Shophouse Part 4: Heritage Kolkata bottle-green khorkhori windows on 2nd floor & sides
  const windowParts: THREE.BufferGeometry[] = [];
  for (const wx of [-sw * 0.32, 0, sw * 0.32]) {
    const wf = new THREE.BoxGeometry(1.45, 2.05, 0.24);
    wf.translate(wx, 5.45, sd * 0.5 + 0.05);
    windowParts.push(wf);
    const wb = new THREE.BoxGeometry(1.45, 1.9, 0.24);
    wb.translate(wx, 5.45, -sd * 0.5 - 0.05);
    windowParts.push(wb);
  }
  for (const sideX of [-sw * 0.5 - 0.05, sw * 0.5 + 0.05]) {
    for (const wz of [-1.75, 1.75]) {
      const ws = new THREE.BoxGeometry(0.24, 1.85, 1.32);
      ws.translate(sideX, 5.45, wz);
      windowParts.push(ws);
    }
  }
  const shopWinGeo = mergeParts(windowParts, false);

  // Shophouse Part 5: Sloped colorful cloth shop awnings jutting out over the street sidewalk
  const awningGeo = new THREE.BoxGeometry(sw - 0.6, 0.14, 2.25);
  awningGeo.rotateX(0.24);
  awningGeo.translate(0, 3.32, sd * 0.5 + 1.02);

  // Curated Burrabazar Shophouse Grid: creates 4.6m–16m wide crossing alleys + open central Chowk!
  const shophousePlacements: Array<{ x: number; z: number; rotY: number; tint: number; sign?: [string, string, string] }> = [
    // North Market Row (facing South into the main avenue, wide 4.6m side alleys + grand North Gate)
    { x: -30, z: -22, rotY: 0, tint: 0xd98a5b, sign: ['বড়বাজার বস্ত্রালয়', 'শাড়ি ও ধুতি', '#8c2222'] },
    { x: -14, z: -22, rotY: 0, tint: 0xe6c382, sign: ['মশলা ভাণ্ডার', 'পাইকারি', '#1e5b43'] },
    { x: 14, z: -22, rotY: 0, tint: 0xcf6a4c, sign: ['সোনার বাংলা স্টোর', 'হার্ডওয়্যার', '#1d4475'] },
    { x: 30, z: -22, rotY: 0, tint: 0xdec49b },
    // West & East Flanking Shophouses framing the Central Chowk
    { x: -25, z: -7, rotY: Math.PI / 2, tint: 0xe3b876, sign: ['কলকাতা চায়ের দোকান', 'গরম চা ও মিষ্টি', '#7a3c16'] },
    { x: -25, z: 10, rotY: Math.PI / 2, tint: 0xd47d5a },
    { x: 24, z: -7, rotY: -Math.PI / 2, tint: 0xe5cca0, sign: ['মিষ্টান্ন ভাণ্ডার', 'রসগোল্লা', '#912948'] },
    { x: 24, z: 10, rotY: -Math.PI / 2, tint: 0xc97b55 },
    // South Market Row (facing North into the main avenue, generous flanking alleys)
    { x: -26, z: 24, rotY: Math.PI, tint: 0xdfba84 },
    { x: -8, z: 24, rotY: Math.PI, tint: 0xd1714f, sign: ['পাইকারি বাজার', 'বড়বাজার চক', '#265341'] },
    { x: 14, z: 24, rotY: Math.PI, tint: 0xe2c794 },
    { x: 30, z: 24, rotY: Math.PI, tint: 0xd89668 },
  ];

  const sc = shophousePlacements.length;
  const imBody = new THREE.InstancedMesh(shopBodyGeo, plasterWallMat, sc);
  const imTrim = new THREE.InstancedMesh(shopTrimGeo, corniceTrimMat, sc);
  const imMetal = new THREE.InstancedMesh(shopMetalGeo, steelShutterMat, sc);
  const imWin = new THREE.InstancedMesh(shopWinGeo, greenShutterMat, sc);
  const imAwning = new THREE.InstancedMesh(awningGeo, awningMat, sc);

  imBody.castShadow = true;
  imBody.receiveShadow = true;
  imTrim.receiveShadow = true;
  imAwning.castShadow = true;

  const signBoardGeo = new THREE.BoxGeometry(5.6, 1.15, 0.14);

  shophousePlacements.forEach((sp, i) => {
    dummy.position.set(sp.x, 0, sp.z);
    dummy.rotation.set(0, sp.rotY, 0);
    dummy.scale.setScalar(1);
    dummy.updateMatrix();
    imBody.setMatrixAt(i, dummy.matrix);
    imTrim.setMatrixAt(i, dummy.matrix);
    imMetal.setMatrixAt(i, dummy.matrix);
    imWin.setMatrixAt(i, dummy.matrix);
    imAwning.setMatrixAt(i, dummy.matrix);
    tmpCol.setHex(sp.tint);
    imBody.setColorAt(i, tmpCol);

    addRotatedFootprintColliders(
      colliders,
      centerX + sp.x,
      centerZ + sp.z,
      sw + 0.5,
      sd + 0.65,
      sp.rotY,
      sh + 1.1,
      0,
      'house',
    );

    // Mount authentic Bengali shopfront fascia signboards on featured storefronts
    if (sp.sign) {
      const [bnTitle, bnSub, bg] = sp.sign;
      const tex = createBengaliSignTexture(bnTitle, bnSub, bg, '#f0d285', '#fff8e6', '#ffd670', false);
      const sMat = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.58, metalness: 0.06 });
      const signMesh = new THREE.Mesh(signBoardGeo, sMat);
      const fwdDist = sd * 0.5 + 0.25;
      signMesh.position.set(
        sp.x + Math.sin(sp.rotY) * fwdDist,
        3.95,
        sp.z + Math.cos(sp.rotY) * fwdDist,
      );
      signMesh.rotation.y = sp.rotY;
      group.add(signMesh);
    }
  });

  for (const im of [imBody, imTrim, imMetal, imWin, imAwning]) {
    im.instanceMatrix.needsUpdate = true;
    if (im.instanceColor) im.instanceColor.needsUpdate = true;
    im.computeBoundingSphere();
    group.add(im);
  }

  // 1d. Central Burrabazar Heritage Clock-Pillar / Cast-Iron Street Lamp Island (360° Chowk Anchor Cover)
  const islandGroup = new THREE.Group();
  islandGroup.position.set(-1, 0, 2);
  const islandBase = new THREE.Mesh(new THREE.CylinderGeometry(2.3, 2.6, 0.55, 8), archBrickMat);
  islandBase.position.y = 0.275;
  islandBase.receiveShadow = true;
  islandBase.castShadow = true;
  islandGroup.add(islandBase);

  const islandPedestal = new THREE.Mesh(new THREE.BoxGeometry(1.6, 1.9, 1.6), corniceTrimMat);
  islandPedestal.position.y = 1.45;
  islandPedestal.castShadow = true;
  islandGroup.add(islandPedestal);

  const lampPost = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.22, 4.6, 8), ironPoleMat);
  lampPost.position.y = 4.4;
  islandGroup.add(lampPost);

  for (const ox of [-0.95, 0.95]) {
    const arm = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.1, 0.1), ironPoleMat);
    arm.position.set(ox * 0.55, 6.45, 0);
    islandGroup.add(arm);
    const globe = new THREE.Mesh(new THREE.SphereGeometry(0.28, 8, 8), warmLampMat);
    globe.position.set(ox, 6.25, 0);
    islandGroup.add(globe);
  }
  group.add(islandGroup);
  colliders.push({ x: centerX - 1, z: centerZ + 2, radius: 2.45, height: 2.5, baseY: 0, kind: 'prop' });

  // 1e. Batched Tactical Market Cover: Wholesale Crate Stacks, Burlap Spice Sacks & Handcarts (Thelagari)
  const crateSpots: Array<[number, number, number, number, number]> = [
    // [x, z, rotY, sx, sy] — positioned cleanly to create peek-angles without blocking alleys
    [-13.5, -9.5, 0.18, 1.2, 1.05],
    [-12.1, -8.8, -0.35, 0.85, 0.72],
    [8.5, -10.2, 0.4, 1.25, 1.1],
    [10.2, -9.8, -0.15, 0.9, 1.35],
    [-12.8, 12.2, 0.22, 1.2, 1.0],
    [-11.2, 12.8, -0.45, 0.85, 0.78],
    [9.4, 11.8, -0.28, 1.3, 1.08],
    [11.0, 12.4, 0.3, 0.88, 1.25],
    [2.5, -16.5, 0.12, 1.15, 0.95],
    [4.5, 17.5, -0.2, 1.2, 1.0],
    [-16.8, 1.5, 1.45, 1.15, 1.05],
    [14.2, 2.2, -1.52, 1.22, 1.05],
  ];
  const crateGeo = new THREE.BoxGeometry(1.55, 1.05, 1.15);
  crateGeo.translate(0, 0.525, 0);
  const imCrates = new THREE.InstancedMesh(crateGeo, crateWoodMat, crateSpots.length);
  imCrates.castShadow = true;
  imCrates.receiveShadow = true;
  const woodTints = [0x9c6b3b, 0x86592e, 0xb07c45, 0x7a512a];
  crateSpots.forEach(([cx, cz, rot, sx, sy], idx) => {
    dummy.position.set(cx, 0.04, cz);
    dummy.rotation.set(0, rot, 0);
    dummy.scale.set(sx, sy, 1);
    dummy.updateMatrix();
    imCrates.setMatrixAt(idx, dummy.matrix);
    tmpCol.setHex(woodTints[idx % woodTints.length]);
    imCrates.setColorAt(idx, tmpCol);
    // Register collider on primary crate of each cluster
    if (idx % 2 === 0 || idx >= 8) {
      colliders.push({
        x: centerX + cx,
        z: centerZ + cz,
        radius: 1.05 * Math.max(sx, 1),
        height: 1.15 * sy,
        baseY: 0,
        kind: 'prop',
      });
    }
  });
  imCrates.instanceMatrix.needsUpdate = true;
  if (imCrates.instanceColor) imCrates.instanceColor.needsUpdate = true;
  imCrates.computeBoundingSphere();
  group.add(imCrates);

  // Wholesale Burlap Grain/Spice Sack Clusters (বস্তা — low crouch cover beside shopfronts)
  const sackGeo = new THREE.DodecahedronGeometry(0.56, 1);
  sackGeo.scale(1.15, 0.78, 0.92);
  sackGeo.translate(0, 0.36, 0);
  const sackCoords: Array<[number, number]> = [
    [-17.2, -16.8], [-16.3, -16.6], [-16.8, -16.1],
    [13.2, -16.5], [14.1, -16.4], [13.6, -15.8],
    [-16.4, 18.2], [-15.5, 18.0], [-16.0, 17.4],
    [15.2, 18.0], [16.1, 17.8], [15.6, 17.2],
    [-8.5, 3.8], [-7.6, 3.5], [6.8, -1.2], [7.6, -0.8],
  ];
  const imSacks = new THREE.InstancedMesh(sackGeo, sackBurlapMat, sackCoords.length);
  const sackTints = [0xc2a274, 0xb5915e, 0xcab082, 0xa88454];
  sackCoords.forEach(([sx, sz], i) => {
    dummy.position.set(sx, 0.04, sz);
    dummy.rotation.set(0, i * 1.1, 0);
    dummy.scale.setScalar(0.95 + (i % 3) * 0.14);
    dummy.updateMatrix();
    imSacks.setMatrixAt(i, dummy.matrix);
    tmpCol.setHex(sackTints[i % sackTints.length]);
    imSacks.setColorAt(i, tmpCol);
  });
  imSacks.instanceMatrix.needsUpdate = true;
  if (imSacks.instanceColor) imSacks.instanceColor.needsUpdate = true;
  imSacks.computeBoundingSphere();
  group.add(imSacks);

  // 4 Iconic Kolkata Wooden Handcarts (ঠেলাগাড়ি / Thelagari) parked along market flanks (1 merged InstancedMesh!)
  const cartParts: THREE.BufferGeometry[] = [];
  const bed = new THREE.BoxGeometry(2.6, 0.22, 1.35);
  bed.translate(0, 0.86, 0);
  cartParts.push(bed);
  const sideL = new THREE.BoxGeometry(2.6, 0.34, 0.1);
  sideL.translate(0, 1.08, 0.62);
  cartParts.push(sideL);
  const sideR = new THREE.BoxGeometry(2.6, 0.34, 0.1);
  sideR.translate(0, 1.08, -0.62);
  cartParts.push(sideR);
  // Twin pull handles
  for (const hz of [-0.42, 0.42]) {
    const h = new THREE.CylinderGeometry(0.045, 0.045, 1.2, 6);
    h.rotateZ(Math.PI / 2);
    h.translate(1.85, 0.86, hz);
    cartParts.push(h);
  }
  // Four spoked wheels
  for (const wx of [-0.85, 0.85]) {
    for (const wz of [-0.72, 0.72]) {
      const wheel = new THREE.TorusGeometry(0.36, 0.055, 6, 14);
      wheel.translate(wx, 0.38, wz);
      cartParts.push(wheel);
    }
  }
  const cartGeo = mergeParts(cartParts, false);
  const cartMat = new THREE.MeshStandardMaterial({ color: 0x744d2a, roughness: 0.86, metalness: 0.08 });
  const cartDefs: Array<[number, number, number]> = [
    [-7.5, -13.5, 0.15],
    [13.8, -4.2, -1.42],
    [-13.5, 6.2, 1.65],
    [7.2, 15.6, -2.9],
  ];
  const imCarts = new THREE.InstancedMesh(cartGeo, cartMat, cartDefs.length);
  imCarts.castShadow = true;
  imCarts.receiveShadow = true;
  cartDefs.forEach(([cx, cz, rot], i) => {
    dummy.position.set(cx, 0.04, cz);
    dummy.rotation.set(0, rot, 0);
    dummy.scale.setScalar(1.08);
    dummy.updateMatrix();
    imCarts.setMatrixAt(i, dummy.matrix);
    colliders.push({ x: centerX + cx, z: centerZ + cz, radius: 1.25, height: 1.25, baseY: 0, kind: 'prop' });
  });
  imCarts.instanceMatrix.needsUpdate = true;
  imCarts.computeBoundingSphere();
  group.add(imCarts);

  // Overhead festive market wire festoons spanning the central Burrabazar avenue (visual atmosphere, 1 draw call)
  const wireParts: THREE.BufferGeometry[] = [];
  for (const wz of [-12, -2, 10]) {
    const wire = new THREE.BoxGeometry(40, 0.05, 0.05);
    wire.translate(0, 6.2, wz);
    wireParts.push(wire);
    for (let fx = -16; fx <= 16; fx += 3.2) {
      const flag = new THREE.BoxGeometry(0.45, 0.55, 0.06);
      flag.translate(fx, 5.88, wz);
      wireParts.push(flag);
    }
  }
  const festoonGeo = mergeParts(wireParts, false);
  const festoonMat = new THREE.MeshStandardMaterial({ color: 0xe38b29, roughness: 0.75 });
  const festoons = new THREE.Mesh(festoonGeo, festoonMat);
  group.add(festoons);

  // 1f. Curated Loot Chests, Sanjibani Herbs, Enemy Spawns & Parked Two-Wheelers in Burrabazar
  chestAnchors.push(
    { x: centerX + 1.5, y: 0.06, z: centerZ - 16.5, rotY: 0 },
    { x: centerX - 18.0, y: 0.06, z: centerZ + 2.0, rotY: Math.PI / 2 },
    { x: centerX + 17.5, y: 0.06, z: centerZ + 1.5, rotY: -Math.PI / 2 },
    { x: centerX + 2.5, y: 0.06, z: centerZ + 18.2, rotY: Math.PI },
  );

  sanjibaniAnchors.push(
    { x: centerX - 33, z: centerZ - 12 },
    { x: centerX + 34, z: centerZ - 14 },
    { x: centerX - 33, z: centerZ + 16 },
    { x: centerX + 33, z: centerZ + 18 },
  );

  // Open alley & Chowk tactical enemy spawn points (verified completely clear of all buildings & props)
  enemySpawns.push(
    new THREE.Vector3(centerX - 1.5, 0, centerZ - 11),
    new THREE.Vector3(centerX + 5.5, 0, centerZ + 7.5),
    new THREE.Vector3(centerX - 10.5, 0, centerZ - 15.0),
    new THREE.Vector3(centerX + 16.5, 0, centerZ + 16),
  );

  // Parked Bicycles (সাইকেল) along Burrabazar shopfronts & alley curbs (never blocking center lane!)
  const burraBikes: Array<[number, number, number, number]> = [
    [-27.5, -16.6, 0.12, 0],
    [-16.2, -16.8, -0.08, 1],
    [10.4, -16.8, 0.22, 2],
    [22.5, -16.6, -0.15, 3],
    [-19.2, -9.8, 1.48, 4],
    [-19.2, 12.6, 1.62, 0],
    [18.2, -9.5, -1.52, 2],
    [18.2, 12.2, -1.6, 1],
    [-11.8, 18.4, 3.05, 3],
    [19.2, 18.5, 2.95, 4],
  ];
  for (const [bx, bz, rotY, colorIdx] of burraBikes) {
    bicycleAnchors.push({ x: centerX + bx, z: centerZ + bz, rotY, colorIdx });
  }

  // Parked Motorcycles/Bikes (বাইক) outside Burrabazar entrance gates, shops & Chowk corners
  const burraMotos: Array<[number, number, number, number]> = [
    [-33.5, -3.8, 0.45, 0],
    [-33.2, 7.6, -0.52, 1],
    [-6.4, -27.2, 1.38, 2],
    [3.8, -27.4, -1.45, 3],
    [-19.0, 5.2, 1.35, 4],
    [18.0, 5.6, -1.42, 5],
    [-25.5, 18.4, 2.75, 0],
    [12.4, 18.4, -2.85, 2],
  ];
  for (const [mx, mz, rotY, colorIdx] of burraMotos) {
    motorcycleAnchors.push({ x: centerX + mx, z: centerZ + mz, rotY, colorIdx });
  }

  return {
    group,
    colliders,
    chestAnchors,
    sanjibaniAnchors,
    enemySpawns,
    bicycleAnchors,
    motorcycleAnchors,
  };
}

// ============================================================================
// 2. চোরবাজার (CHOR BAZAAR — Cluttered Scrap, Salvage & Flea Market Maze)
//    Center: (112, -108), spans x in [80..144], z in [-135..-81] (64m x 54m)
//    Directly East of Old Tram Depot across Howrah Bridge!
// ============================================================================
export function buildChorBazaarZone(centerX: number, centerZ: number): MarketZoneResult {
  const group = new THREE.Group();
  group.position.set(centerX, 0, centerZ);
  const colliders: CircleCollider[] = [];
  const chestAnchors: ChestAnchor[] = [];
  const sanjibaniAnchors: Array<{ x: number; z: number }> = [];
  const enemySpawns: THREE.Vector3[] = [];
  const bicycleAnchors: MarketZoneResult['bicycleAnchors'] = [];
  const motorcycleAnchors: MarketZoneResult['motorcycleAnchors'] = [];

  const dummy = new THREE.Object3D();
  const tmpCol = new THREE.Color();

  // Gritty salvage-market PBR materials
  const oilGravelMat = new THREE.MeshStandardMaterial({
    color: 0x423e3b, // Oil-stained dark gravel & patched tarmac
    roughness: 0.95,
    metalness: 0.05,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const concreteSlabMat = new THREE.MeshStandardMaterial({
    color: 0x67625c,
    roughness: 0.92,
    polygonOffset: true,
    polygonOffsetFactor: -2,
    polygonOffsetUnits: -2,
  });
  const rustySteelMat = new THREE.MeshStandardMaterial({
    color: 0x734634,
    roughness: 0.72,
    metalness: 0.56,
  });
  const tinSheetMat = new THREE.MeshStandardMaterial({
    color: 0xffffff, // Tinted per shed/sheet via setColorAt
    roughness: 0.54,
    metalness: 0.62,
    side: THREE.DoubleSide,
  });
  const tarpCanopyMat = new THREE.MeshStandardMaterial({
    color: 0xffffff, // Vibrant mismatched flea-market plastic tarpaulins
    roughness: 0.82,
    metalness: 0.04,
    side: THREE.DoubleSide,
  });
  const scrapWoodMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    roughness: 0.9,
    metalness: 0.02,
  });
  const barrelMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    roughness: 0.52,
    metalness: 0.58,
  });
  const rubberTireMat = new THREE.MeshStandardMaterial({
    color: 0x222427,
    roughness: 0.92,
    metalness: 0.06,
  });

  // 2a. Gritty Oil-Stained Chor Bazaar Yard Pavement
  const yardBase = new THREE.Mesh(new THREE.PlaneGeometry(64, 54), oilGravelMat);
  yardBase.rotation.x = -Math.PI / 2;
  yardBase.position.set(0, 0.042, 0);
  yardBase.receiveShadow = true;
  group.add(yardBase);

  // Patchwork concrete salvage bays inside the yard
  for (const [px, pz, pw, pd] of [
    [-12, -16, 22, 12],
    [16, -15, 20, 13],
    [14, 15, 22, 12],
  ]) {
    const slab = new THREE.Mesh(new THREE.PlaneGeometry(pw, pd), concreteSlabMat);
    slab.rotation.x = -Math.PI / 2;
    slab.position.set(px, 0.058, pz);
    slab.receiveShadow = true;
    group.add(slab);
  }

  // 2b. Weathered Steel-Pipe Entrance Gantry Arch ("চোরবাজার") facing Old Tram Depot (West side)
  const chorSignTex = createBengaliSignTexture(
    'চোরবাজার',
    'পুরনো মাল • যন্ত্রাংশ • স্ক্র্যাপ',
    '#1b3c59',
    '#d9a12b',
    '#fff0b8',
    '#f2b84b',
    true,
  );
  const chorSignMat = new THREE.MeshStandardMaterial({
    map: chorSignTex,
    roughness: 0.62,
    metalness: 0.18,
  });

  const buildChorGate = (lx: number, lz: number, rotY: number) => {
    const gate = new THREE.Group();
    gate.position.set(lx, 0, lz);
    gate.rotation.y = rotY;

    const halfW = 4.6;
    for (const sx of [-halfW, halfW]) {
      // Twin rusted iron scaffold posts + horizontal truss braces
      const pA = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.19, 5.6, 8), rustySteelMat);
      pA.position.set(sx - 0.25, 2.8, 0);
      pA.castShadow = true;
      gate.add(pA);
      const pB = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.19, 5.6, 8), rustySteelMat);
      pB.position.set(sx + 0.25, 2.8, 0);
      gate.add(pB);
      const footing = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.6, 1.1), concreteSlabMat);
      footing.position.set(sx, 0.3, 0);
      gate.add(footing);

      const cosY = Math.cos(rotY);
      const sinY = Math.sin(rotY);
      colliders.push({
        x: centerX + lx + sx * cosY,
        z: centerZ + lz - sx * sinY,
        radius: 0.72,
        height: 5.5,
        baseY: 0,
        kind: 'prop',
      });
    }

    const crossbar = new THREE.Mesh(new THREE.BoxGeometry(halfW * 2 + 1.2, 0.34, 0.38), rustySteelMat);
    crossbar.position.set(0, 5.45, 0);
    gate.add(crossbar);

    // Slightly tilted weathered metal signboard for gritty character
    const boardBacking = new THREE.Mesh(new THREE.BoxGeometry(6.4, 1.85, 0.18), rustySteelMat);
    boardBacking.position.set(0, 6.45, 0);
    boardBacking.rotation.z = -0.025;
    gate.add(boardBacking);

    for (const sz of [0.11, -0.11]) {
      const face = new THREE.Mesh(new THREE.PlaneGeometry(6.1, 1.68), chorSignMat);
      face.position.set(0, 6.45, sz);
      face.rotation.z = -0.025;
      if (sz < 0) face.rotation.y = Math.PI;
      gate.add(face);
    }

    group.add(gate);
  };

  buildChorGate(-30, 0, Math.PI / 2); // Main West gate from Tram Depot plaza

  // 2c. 4 Corrugated-Tin Salvage Sheds / Junk Workshops around perimeter (2 InstancedMesh draw calls!)
  const shedW = 9.4;
  const shedD = 5.4;
  const shedH = 3.55;

  const shedWallParts: THREE.BufferGeometry[] = [];
  const backW = new THREE.BoxGeometry(shedW, shedH, 0.42);
  backW.translate(0, shedH * 0.5, -shedD * 0.5 + 0.21);
  shedWallParts.push(backW);
  const leftW = new THREE.BoxGeometry(0.42, shedH, shedD);
  leftW.translate(-shedW * 0.5 + 0.21, shedH * 0.5, 0);
  shedWallParts.push(leftW);
  const rightW = new THREE.BoxGeometry(0.42, shedH, shedD);
  rightW.translate(shedW * 0.5 - 0.21, shedH * 0.5, 0);
  shedWallParts.push(rightW);
  // Sloped corrugated iron shed roof
  const shedRoof = new THREE.BoxGeometry(shedW + 1.0, 0.18, shedD + 1.25);
  shedRoof.rotateX(0.14);
  shedRoof.translate(0, shedH + 0.2, 0.2);
  shedWallParts.push(shedRoof);
  const shedTinGeo = mergeParts(shedWallParts, false);

  // Workbench & steel beams inside each salvage shed
  const shedFrameParts: THREE.BufferGeometry[] = [];
  for (const fx of [-shedW * 0.46, 0, shedW * 0.46]) {
    const fPost = new THREE.CylinderGeometry(0.1, 0.12, shedH + 0.1, 6);
    fPost.translate(fx, (shedH + 0.1) * 0.5, shedD * 0.5 - 0.15);
    shedFrameParts.push(fPost);
  }
  const bench = new THREE.BoxGeometry(shedW - 1.8, 1.0, 1.2);
  bench.translate(0, 0.5, -shedD * 0.5 + 1.2);
  shedFrameParts.push(bench);
  const shedFrameGeo = mergeParts(shedFrameParts, false);

  const shedDefs: Array<{ x: number; z: number; rotY: number; tint: number }> = [
    { x: -16, z: -21, rotY: 0.04, tint: 0x6f7f89 },
    { x: 14, z: -21, rotY: -0.05, tint: 0x876252 },
    { x: 25, z: -2, rotY: -Math.PI / 2, tint: 0x63726c },
    { x: 15, z: 20, rotY: Math.PI + 0.04, tint: 0x7a6d5e },
  ];
  const imShedTin = new THREE.InstancedMesh(shedTinGeo, tinSheetMat, shedDefs.length);
  const imShedFrame = new THREE.InstancedMesh(shedFrameGeo, rustySteelMat, shedDefs.length);
  imShedTin.castShadow = true;
  imShedTin.receiveShadow = true;

  shedDefs.forEach((sd, i) => {
    dummy.position.set(sd.x, 0, sd.z);
    dummy.rotation.set(0, sd.rotY, 0);
    dummy.scale.setScalar(1);
    dummy.updateMatrix();
    imShedTin.setMatrixAt(i, dummy.matrix);
    imShedFrame.setMatrixAt(i, dummy.matrix);
    tmpCol.setHex(sd.tint);
    imShedTin.setColorAt(i, tmpCol);

    // Solid twin-circle footprint on the shed rear/workbench volume (keeps perimeter solid)
    addRotatedFootprintColliders(
      colliders,
      centerX + sd.x,
      centerZ + sd.z,
      shedW + 0.2,
      shedD + 0.2,
      sd.rotY,
      shedH + 0.5,
      0,
      'house',
    );
  });
  for (const im of [imShedTin, imShedFrame]) {
    im.instanceMatrix.needsUpdate = true;
    if (im.instanceColor) im.instanceColor.needsUpdate = true;
    im.computeBoundingSphere();
    group.add(im);
  }

  // 2d. 12 Patchwork Tarpaulin Flea-Market Stalls (3 InstancedMesh draw calls for all 12 stalls!)
  const stallWoodParts: THREE.BufferGeometry[] = [];
  const tableTop = new THREE.BoxGeometry(4.6, 0.96, 1.55);
  tableTop.translate(0, 0.48, 0);
  stallWoodParts.push(tableTop);
  for (const [px, pz] of [
    [-2.15, -0.68], [2.15, -0.68], [-2.15, 0.68], [2.15, 0.68],
  ]) {
    const pole = new THREE.CylinderGeometry(0.065, 0.075, 2.75, 6);
    pole.translate(px, 1.375, pz);
    stallWoodParts.push(pole);
  }
  const stallWoodGeo = mergeParts(stallWoodParts, false);

  // Sloped patchwork plastic tarp awning roof
  const stallTarpGeo = new THREE.BoxGeometry(5.1, 0.1, 2.35);
  stallTarpGeo.rotateX(0.2);
  stallTarpGeo.translate(0, 2.78, 0.12);

  // Cluttered scrap wares / radio boxes / spare parts piled atop every stall table
  const wareParts: THREE.BufferGeometry[] = [];
  const w1 = new THREE.BoxGeometry(0.75, 0.48, 0.62);
  w1.translate(-1.35, 1.18, 0.08);
  wareParts.push(w1);
  const w2 = new THREE.CylinderGeometry(0.32, 0.34, 0.42, 8);
  w2.translate(-0.25, 1.16, -0.1);
  wareParts.push(w2);
  const w3 = new THREE.BoxGeometry(0.92, 0.36, 0.72);
  w3.rotateY(0.25);
  w3.translate(0.82, 1.14, 0.06);
  wareParts.push(w3);
  const w4 = new THREE.TorusGeometry(0.26, 0.08, 6, 12);
  w4.rotateX(Math.PI / 2);
  w4.translate(1.75, 1.04, -0.05);
  wareParts.push(w4);
  const stallWareGeo = mergeParts(wareParts, false);

  // Weaving CQB stall layout with guaranteed 4.8m–6.5m tactical corridors between rows
  const chorStalls: Array<{ x: number; z: number; rotY: number; tarp: number }> = [
    // North-Central Row
    { x: -18, z: -9.5, rotY: 0.08, tarp: 0x2665a8 }, // Classic Kolkata blue tarpaulin
    { x: -9.5, z: -10.2, rotY: -0.06, tarp: 0xd96b27 }, // Faded orange tarp
    { x: 1.5, z: -9.8, rotY: 0.1, tarp: 0x2a7a6d }, // Teal tarp
    { x: 11.5, z: -9.5, rotY: -0.08, tarp: 0xc24833 }, // Brick-red tarp
    // Mid-Yard Zigzag Stalls (breaks long sniper sightlines into fun CQB angles!)
    { x: -16.5, z: 2.2, rotY: 1.48, tarp: 0xd49b2a }, // Ochre tarp
    { x: -3.5, z: 1.2, rotY: -0.15, tarp: 0x2d5e99 },
    { x: 8.5, z: 2.5, rotY: 0.22, tarp: 0x5c7839 }, // Olive tarp
    // South Flea-Market Row
    { x: -20, z: 13.5, rotY: Math.PI - 0.1, tarp: 0xc95a2b },
    { x: -11, z: 14.2, rotY: Math.PI + 0.08, tarp: 0x2665a8 },
    { x: -0.5, z: 13.5, rotY: Math.PI - 0.05, tarp: 0x2a7a6d },
    { x: -16, z: 22.0, rotY: 0.05, tarp: 0xb54434 },
    { x: -4.5, z: 22.0, rotY: -0.08, tarp: 0xd18a28 },
  ];

  const imStallWood = new THREE.InstancedMesh(stallWoodGeo, scrapWoodMat, chorStalls.length);
  const imStallTarp = new THREE.InstancedMesh(stallTarpGeo, tarpCanopyMat, chorStalls.length);
  const imStallWares = new THREE.InstancedMesh(stallWareGeo, rustySteelMat, chorStalls.length);
  imStallWood.castShadow = true;
  imStallWood.receiveShadow = true;
  imStallTarp.castShadow = true;

  const stallWoodTints = [0x6e4a2b, 0x5c3e24, 0x7c5734, 0x64472c];
  chorStalls.forEach((st, i) => {
    dummy.position.set(st.x, 0.04, st.z);
    dummy.rotation.set(0, st.rotY, 0);
    dummy.scale.setScalar(1);
    dummy.updateMatrix();
    imStallWood.setMatrixAt(i, dummy.matrix);
    imStallTarp.setMatrixAt(i, dummy.matrix);
    imStallWares.setMatrixAt(i, dummy.matrix);
    tmpCol.setHex(stallWoodTints[i % stallWoodTints.length]);
    imStallWood.setColorAt(i, tmpCol);
    tmpCol.setHex(st.tarp);
    imStallTarp.setColorAt(i, tmpCol);

    addRotatedFootprintColliders(
      colliders,
      centerX + st.x,
      centerZ + st.z,
      4.7,
      1.75,
      st.rotY,
      1.35,
      0,
      'stall',
    );
  });
  for (const im of [imStallWood, imStallTarp, imStallWares]) {
    im.instanceMatrix.needsUpdate = true;
    if (im.instanceColor) im.instanceColor.needsUpdate = true;
    im.computeBoundingSphere();
    group.add(im);
  }

  // 2e. Cluttered Salvage Cover Props: Oil Drums, Stacked Crates, Rubber Tire Piles & Tin Screens (4 InstancedMeshes!)
  // 200L Oil Drums / Barrels (blue, rusted red, dark steel)
  const drumGeo = new THREE.CylinderGeometry(0.42, 0.42, 1.15, 10);
  drumGeo.translate(0, 0.575, 0);
  const drumClusters: Array<[number, number, number]> = [
    [-23.5, -5.5, 0x22558c], [-22.6, -5.1, 0x993526], [-23.1, -6.2, 0x3b434a],
    [-8.5, -3.5, 0x993526], [-7.6, -3.2, 0x22558c],
    [3.8, -3.8, 0x3b434a], [4.7, -3.4, 0xc27b25], [4.1, -4.5, 0x993526],
    [15.8, -4.5, 0x22558c], [16.7, -4.1, 0x3b434a],
    [16.2, 8.8, 0x993526], [17.1, 9.2, 0x22558c], [16.5, 8.1, 0xc27b25],
    [-11.5, 8.2, 0x3b434a], [-10.6, 8.6, 0x993526],
    [4.5, 9.5, 0x22558c], [5.4, 9.2, 0x3b434a],
  ];
  const imDrums = new THREE.InstancedMesh(drumGeo, barrelMat, drumClusters.length);
  imDrums.castShadow = true;
  imDrums.receiveShadow = true;
  const drumColliderIndices = [0, 3, 5, 8, 10, 13, 15];
  drumClusters.forEach(([dx, dz, hex], i) => {
    dummy.position.set(dx, 0.04, dz);
    dummy.rotation.set(0, i * 0.7, 0);
    dummy.scale.setScalar(1.04);
    dummy.updateMatrix();
    imDrums.setMatrixAt(i, dummy.matrix);
    tmpCol.setHex(hex);
    imDrums.setColorAt(i, tmpCol);
    if (drumColliderIndices.includes(i)) {
      colliders.push({ x: centerX + dx + 0.35, z: centerZ + dz, radius: 1.05, height: 1.22, baseY: 0, kind: 'prop' });
    }
  });
  imDrums.instanceMatrix.needsUpdate = true;
  if (imDrums.instanceColor) imDrums.instanceColor.needsUpdate = true;
  imDrums.computeBoundingSphere();
  group.add(imDrums);

  // Salvage Wooden Shipping Crates (stacked waist & shoulder height cover!)
  const scrapCrateGeo = new THREE.BoxGeometry(1.48, 1.08, 1.18);
  scrapCrateGeo.translate(0, 0.54, 0);
  const scrapCrates: Array<[number, number, number, number, number]> = [
    [-22.5, 6.8, 0.35, 1.15, 1.05],
    [-22.3, 6.9, 0.1, 0.72, 1.85], // Stacked top crate
    [-1.2, -15.5, 0.15, 1.3, 1.1],
    [13.8, 11.2, -0.42, 1.25, 1.05],
    [2.5, 18.8, 0.28, 1.2, 1.15],
    [-24.2, -14.8, -0.22, 1.18, 1.08],
    [18.8, -12.5, 0.65, 1.15, 1.05],
    [-7.2, 18.0, -0.18, 1.1, 0.95],
  ];
  const imScrapCrates = new THREE.InstancedMesh(scrapCrateGeo, scrapWoodMat, scrapCrates.length);
  imScrapCrates.castShadow = true;
  imScrapCrates.receiveShadow = true;
  scrapCrates.forEach(([cx, cz, rot, sx, sy], i) => {
    const isStackedTop = i === 1;
    dummy.position.set(cx, isStackedTop ? 1.16 : 0.04, cz);
    dummy.rotation.set(0, rot, 0);
    dummy.scale.set(sx, isStackedTop ? 0.75 : sy, isStackedTop ? 0.78 : 1);
    dummy.updateMatrix();
    imScrapCrates.setMatrixAt(i, dummy.matrix);
    tmpCol.setHex(stallWoodTints[(i + 1) % stallWoodTints.length]);
    imScrapCrates.setColorAt(i, tmpCol);
    if (!isStackedTop) {
      colliders.push({ x: centerX + cx, z: centerZ + cz, radius: 1.05 * sx, height: 1.2 * sy, baseY: 0, kind: 'prop' });
    }
  });
  imScrapCrates.instanceMatrix.needsUpdate = true;
  if (imScrapCrates.instanceColor) imScrapCrates.instanceColor.needsUpdate = true;
  imScrapCrates.computeBoundingSphere();
  group.add(imScrapCrates);

  // Stacked Rubber Auto Tires & Junk Scrap Heaps (classic Chor Bazaar auto-parts silhouette!)
  const tireStackParts: THREE.BufferGeometry[] = [];
  for (let t = 0; t < 3; t++) {
    const tire = new THREE.TorusGeometry(0.46, 0.16, 7, 14);
    tire.rotateX(Math.PI / 2);
    tire.translate((t % 2) * 0.06, 0.16 + t * 0.3, (t === 2 ? -0.05 : 0));
    tireStackParts.push(tire);
  }
  const leanedTire = new THREE.TorusGeometry(0.46, 0.16, 7, 14);
  leanedTire.rotateY(0.4);
  leanedTire.rotateX(0.28);
  leanedTire.translate(0.75, 0.45, 0.25);
  tireStackParts.push(leanedTire);
  const tirePileGeo = mergeParts(tireStackParts, false);

  const tirePileCoords: Array<[number, number, number]> = [
    [-24.0, -11.5, 0.4],
    [-4.8, -14.8, 1.2],
    [18.2, 2.8, -0.7],
    [10.2, 13.5, 2.1],
    [-12.5, 3.2, -1.4],
    [-23.5, 19.2, 0.8],
    [22.5, -13.2, -2.0],
  ];
  const imTires = new THREE.InstancedMesh(tirePileGeo, rubberTireMat, tirePileCoords.length);
  imTires.castShadow = true;
  imTires.receiveShadow = true;
  tirePileCoords.forEach(([tx, tz, rot], i) => {
    dummy.position.set(tx, 0.04, tz);
    dummy.rotation.set(0, rot, 0);
    dummy.scale.setScalar(1.08);
    dummy.updateMatrix();
    imTires.setMatrixAt(i, dummy.matrix);
    colliders.push({ x: centerX + tx, z: centerZ + tz, radius: 1.0, height: 1.05, baseY: 0, kind: 'prop' });
  });
  imTires.instanceMatrix.needsUpdate = true;
  imTires.computeBoundingSphere();
  group.add(imTires);

  // Corrugated Tin Scrap Divider Screens (waist-to-chest angular tactical cover)
  const screenGeo = new THREE.BoxGeometry(3.4, 1.55, 0.16);
  screenGeo.translate(0, 0.775, 0);
  const screenDefs: Array<[number, number, number, number]> = [
    [-11.5, -4.5, 0.35, 0x6f7d86],
    [12.5, -3.5, -0.45, 0x85624e],
    [0.5, 7.2, 0.15, 0x5d6e68],
    [17.5, 13.2, 1.35, 0x7a6856],
  ];
  const imScreens = new THREE.InstancedMesh(screenGeo, tinSheetMat, screenDefs.length);
  imScreens.castShadow = true;
  screenDefs.forEach(([sx, sz, rot, tint], i) => {
    dummy.position.set(sx, 0.04, sz);
    dummy.rotation.set(0, rot, 0);
    dummy.scale.setScalar(1);
    dummy.updateMatrix();
    imScreens.setMatrixAt(i, dummy.matrix);
    tmpCol.setHex(tint);
    imScreens.setColorAt(i, tmpCol);
    addRotatedFootprintColliders(colliders, centerX + sx, centerZ + sz, 3.4, 0.55, rot, 1.58, 0, 'prop');
  });
  imScreens.instanceMatrix.needsUpdate = true;
  if (imScreens.instanceColor) imScreens.instanceColor.needsUpdate = true;
  imScreens.computeBoundingSphere();
  group.add(imScreens);

  // 2f. Loot Chests, Sanjibani Herbs, Enemy Spawns & Parked Vehicles in Chor Bazaar
  chestAnchors.push(
    { x: centerX - 15.5, y: 0.06, z: centerZ - 17.5, rotY: 0.1 },
    { x: centerX + 14.5, y: 0.06, z: centerZ - 17.2, rotY: -0.15 },
    { x: centerX + 20.5, y: 0.06, z: centerZ - 1.5, rotY: -Math.PI / 2 },
    { x: centerX + 14.5, y: 0.06, z: centerZ + 16.5, rotY: Math.PI },
  );

  sanjibaniAnchors.push(
    { x: centerX - 27, z: centerZ + 12 },
    { x: centerX + 26, z: centerZ - 18 },
    { x: centerX + 25, z: centerZ + 21 },
  );

  enemySpawns.push(
    new THREE.Vector3(centerX - 10, 0, centerZ - 15.5),
    new THREE.Vector3(centerX + 2.5, 0, centerZ - 3.0),
    new THREE.Vector3(centerX + 14.5, 0, centerZ + 5.0),
    new THREE.Vector3(centerX - 9.5, 0, centerZ + 9.2),
  );

  // Parked Bicycles around Chor Bazaar scrap stalls & entrance
  const chorBikes: Array<[number, number, number, number]> = [
    [-26.2, -4.8, 0.35, 1],
    [-25.8, 4.6, -0.4, 0],
    [-11.2, -16.2, 0.12, 3],
    [8.2, -16.5, -0.25, 2],
    [19.5, -8.2, -1.45, 4],
    [19.8, 6.2, -1.65, 1],
    [-1.5, 17.5, 2.9, 0],
    [-22.2, 16.2, 1.35, 2],
  ];
  for (const [bx, bz, rotY, colorIdx] of chorBikes) {
    bicycleAnchors.push({ x: centerX + bx, z: centerZ + bz, rotY, colorIdx });
  }

  // Parked Motorcycles/Bikes around Chor Bazaar mechanic sheds & outer perimeter
  const chorMotos: Array<[number, number, number, number]> = [
    [-26.5, -8.5, 0.6, 5],
    [-26.5, 8.8, -0.55, 1],
    [-6.5, -17.8, 0.15, 0],
    [19.2, -15.8, -0.95, 3],
    [19.4, 1.2, -1.48, 2],
    [8.8, 17.6, 2.85, 4],
    [-19.5, 24.5, 0.25, 0],
  ];
  for (const [mx, mz, rotY, colorIdx] of chorMotos) {
    motorcycleAnchors.push({ x: centerX + mx, z: centerZ + mz, rotY, colorIdx });
  }

  return {
    group,
    colliders,
    chestAnchors,
    sanjibaniAnchors,
    enemySpawns,
    bicycleAnchors,
    motorcycleAnchors,
  };
}

// ============================================================================
// 3. GPU-INSTANCED MULTI-PART BICYCLES (সাইকেল) & MOTORCYCLES/BIKES (বাইক)
//    All bicycles across the entire 1520x1520 map = 3 draw calls!
//    All motorcycles across the entire 1520x1520 map = 4 draw calls!
// ============================================================================

/**
 * Helper to create a cylinder strut cleanly aligned between two 3D points (for bike/cycle frames & forks).
 */
function makeTubeBetween(
  ax: number,
  ay: number,
  az: number,
  bx: number,
  by: number,
  bz: number,
  rTop: number,
  rBot: number,
  radialSegs = 6,
): THREE.BufferGeometry {
  const start = new THREE.Vector3(ax, ay, az);
  const end = new THREE.Vector3(bx, by, bz);
  const dir = end.clone().sub(start);
  const len = dir.length();
  const geo = new THREE.CylinderGeometry(rTop, rBot, len, radialSegs);
  const quat = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
  const mat = new THREE.Matrix4().compose(
    start.add(end).multiplyScalar(0.5),
    quat,
    new THREE.Vector3(1, 1, 1),
  );
  geo.applyMatrix4(mat);
  return geo;
}

export interface RideableTwoWheeler {
  id: number;
  kind: 'bicycle' | 'motorcycle';
  instanceIndex: number;
  colliderIndex: number;
  baseColliderRadius: number;
  x: number;
  y: number;
  z: number;
  yaw: number; // Travel heading yaw where forward = (sin(yaw), 0, cos(yaw))
  homeX: number;
  homeY: number;
  homeZ: number;
  homeYaw: number;
  setTransform: (
    x: number,
    y: number,
    z: number,
    travelYaw: number,
    slopePitch: number,
    leanRoll: number,
  ) => void;
  reset: () => void;
}

const _bikeDummy = new THREE.Object3D();
_bikeDummy.rotation.order = 'YZX';
let _nextTwoWheelerId = 1;

/**
 * Renders all classic Indian/Kolkata Bicycles (সাইকেল) across streets, markets & village edges
 * in just 3 InstancedMesh draw calls, returning rideable per-instance controllers.
 */
export function buildInstancedBicycles(
  placements: TwoWheelerPlacement[],
  colliders: CircleCollider[],
): { group: THREE.Group; vehicles: RideableTwoWheeler[] } {
  const group = new THREE.Group();
  const vehicles: RideableTwoWheeler[] = [];
  if (placements.length === 0) return { group, vehicles };

  // Model aligned along X axis (rear wheel at x = -0.58, front wheel at x = +0.58, wheel radius = 0.36m)
  const rWheel = 0.36;
  const xRear = -0.58;
  const xFront = 0.58;

  // --- Material Group 1: Rubber Tires, Leather Saddle, Handle Grips & Pedals ---
  const rubberParts: THREE.BufferGeometry[] = [];
  for (const wx of [xRear, xFront]) {
    const tire = new THREE.TorusGeometry(rWheel, 0.042, 8, 18);
    tire.translate(wx, rWheel + 0.02, 0);
    rubberParts.push(tire);
  }
  // Classic sprung bicycle saddle
  const saddle = new THREE.BoxGeometry(0.28, 0.075, 0.17);
  saddle.translate(-0.22, 0.96, 0);
  rubberParts.push(saddle);
  const saddleNose = new THREE.BoxGeometry(0.14, 0.06, 0.09);
  saddleNose.translate(-0.08, 0.955, 0);
  rubberParts.push(saddleNose);
  // Rubber handlebar grips
  for (const gz of [-0.28, 0.28]) {
    const grip = new THREE.CylinderGeometry(0.024, 0.024, 0.13, 6);
    grip.rotateX(Math.PI / 2);
    grip.translate(0.37, 1.02, gz);
    rubberParts.push(grip);
  }
  // Pedals
  for (const [py, pz] of [[0.24, 0.15], [0.46, -0.15]]) {
    const pedal = new THREE.BoxGeometry(0.11, 0.035, 0.075);
    pedal.translate(-0.08, py, pz);
    rubberParts.push(pedal);
  }
  const cycleRubberGeo = mergeParts(rubberParts, false);

  // --- Material Group 2: Painted Classic Diamond Frame, Forks, Mudguards, Rear Carrier & Front Basket ---
  const frameParts: THREE.BufferGeometry[] = [];
  // Diamond frame tubes (Bottom bracket at (-0.08, 0.36, 0), Seat cluster (-0.22, 0.84, 0), Head tube (0.42, 0.84 -> 0.46, 0.66))
  frameParts.push(makeTubeBetween(-0.22, 0.84, 0, 0.42, 0.83, 0, 0.024, 0.024)); // Top tube
  frameParts.push(makeTubeBetween(-0.08, 0.36, 0, 0.45, 0.72, 0, 0.026, 0.026)); // Down tube
  frameParts.push(makeTubeBetween(-0.08, 0.36, 0, -0.22, 0.86, 0, 0.024, 0.024)); // Seat tube
  frameParts.push(makeTubeBetween(0.41, 0.88, 0, 0.46, 0.68, 0, 0.028, 0.028)); // Head tube
  // Twin rear stays & front fork blades
  for (const sz of [-0.065, 0.065]) {
    frameParts.push(makeTubeBetween(-0.08, 0.36, sz * 0.4, xRear, rWheel + 0.02, sz, 0.016, 0.016)); // Chainstay
    frameParts.push(makeTubeBetween(-0.22, 0.82, sz * 0.4, xRear, rWheel + 0.02, sz, 0.016, 0.016)); // Seatstay
    frameParts.push(makeTubeBetween(0.45, 0.68, sz * 0.5, xFront, rWheel + 0.02, sz, 0.018, 0.018)); // Front fork
  }
  // Curved front & rear mudguards (fenders)
  for (const wx of [xRear, xFront]) {
    const fender = new THREE.TorusGeometry(rWheel + 0.06, 0.032, 6, 12, Math.PI * 0.85);
    fender.rotateZ(Math.PI * 0.08);
    fender.translate(wx, rWheel + 0.02, 0);
    frameParts.push(fender);
  }
  // Iconic Kolkata rear luggage carrier rack
  const carrier = new THREE.BoxGeometry(0.46, 0.035, 0.22);
  carrier.translate(xRear - 0.04, 0.8, 0);
  frameParts.push(carrier);
  for (const cz of [-0.09, 0.09]) {
    frameParts.push(makeTubeBetween(xRear - 0.16, 0.79, cz, xRear, rWheel + 0.03, cz * 0.8, 0.012, 0.012));
  }
  // Classic front market wire-style parcel basket
  const basketBase = new THREE.BoxGeometry(0.24, 0.22, 0.32);
  basketBase.translate(0.56, 0.86, 0);
  frameParts.push(basketBase);
  const cycleFrameGeo = mergeParts(frameParts, false);

  // --- Material Group 3: Chrome Rims, Wheel Spokes, Swept Handlebars, Crankset & Kickstand ---
  const chromeParts: THREE.BufferGeometry[] = [];
  for (const wx of [xRear, xFront]) {
    const rim = new THREE.TorusGeometry(rWheel - 0.038, 0.016, 6, 16);
    rim.translate(wx, rWheel + 0.02, 0);
    chromeParts.push(rim);
    const hub = new THREE.CylinderGeometry(0.036, 0.036, 0.14, 8);
    hub.rotateX(Math.PI / 2);
    hub.translate(wx, rWheel + 0.02, 0);
    chromeParts.push(hub);
    // 4 intersecting diametric spoke bars per wheel (8 visual spokes!)
    for (let s = 0; s < 4; s++) {
      const sp = new THREE.CylinderGeometry(0.008, 0.008, (rWheel - 0.04) * 2, 4);
      sp.rotateZ((s * Math.PI) / 4);
      sp.translate(wx, rWheel + 0.02, 0);
      chromeParts.push(sp);
    }
  }
  // Handlebar stem & wide swept-back commuter handlebars
  chromeParts.push(makeTubeBetween(0.41, 0.87, 0, 0.39, 1.03, 0, 0.018, 0.018));
  chromeParts.push(makeTubeBetween(0.39, 1.03, 0, 0.37, 1.02, -0.24, 0.016, 0.016));
  chromeParts.push(makeTubeBetween(0.39, 1.03, 0, 0.37, 1.02, 0.24, 0.016, 0.016));
  // Seatpost & crankset chainring
  chromeParts.push(makeTubeBetween(-0.22, 0.85, 0, -0.22, 0.94, 0, 0.016, 0.016));
  const chainring = new THREE.CylinderGeometry(0.11, 0.11, 0.025, 10);
  chainring.rotateX(Math.PI / 2);
  chainring.translate(-0.08, 0.36, 0.06);
  chromeParts.push(chainring);
  // Kickstand grounded to pavement
  chromeParts.push(makeTubeBetween(-0.16, 0.34, 0.04, -0.24, 0.02, 0.22, 0.012, 0.012));
  const cycleChromeGeo = mergeParts(chromeParts, false);

  const rubberMat = new THREE.MeshStandardMaterial({ color: 0x202225, roughness: 0.9, metalness: 0.04 });
  const frameMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.36, metalness: 0.42 });
  const chromeMat = new THREE.MeshStandardMaterial({ color: 0xd0d7de, roughness: 0.22, metalness: 0.88 });

  const n = placements.length;
  const imRubber = new THREE.InstancedMesh(cycleRubberGeo, rubberMat, n);
  const imFrame = new THREE.InstancedMesh(cycleFrameGeo, frameMat, n);
  const imChrome = new THREE.InstancedMesh(cycleChromeGeo, chromeMat, n);
  imFrame.castShadow = true;
  imRubber.castShadow = true;

  // Authentic Kolkata bicycle paint finishes (Atlas/Hero Black, Crimson Red, Royal Blue, Bottle Green, Vintage Teal)
  const cyclePalette = [0x1c2026, 0xa82424, 0x1e4d82, 0x1f5c3a, 0x226973];
  const tmpCol = new THREE.Color();
  const baseScale = 1.06;
  const parkedLean = 0.11;
  const baseColRadius = 0.56;

  placements.forEach((p, i) => {
    const homeYaw = p.rotY + Math.PI / 2;
    const colliderIndex = colliders.length;
    colliders.push({
      x: p.x,
      z: p.z,
      radius: baseColRadius,
      height: 1.05,
      baseY: p.y,
      kind: 'prop',
    });

    const applyTransform = (
      x: number,
      y: number,
      z: number,
      travelYaw: number,
      slopePitch: number,
      leanRoll: number,
    ) => {
      vehicle.x = x;
      vehicle.y = y;
      vehicle.z = z;
      vehicle.yaw = travelYaw;
      _bikeDummy.position.set(x, y, z);
      _bikeDummy.rotation.set(leanRoll, travelYaw - Math.PI / 2, slopePitch);
      _bikeDummy.scale.setScalar(baseScale);
      _bikeDummy.updateMatrix();
      imRubber.setMatrixAt(i, _bikeDummy.matrix);
      imFrame.setMatrixAt(i, _bikeDummy.matrix);
      imChrome.setMatrixAt(i, _bikeDummy.matrix);
      imRubber.instanceMatrix.needsUpdate = true;
      imFrame.instanceMatrix.needsUpdate = true;
      imChrome.instanceMatrix.needsUpdate = true;
    };

    const vehicle: RideableTwoWheeler = {
      id: _nextTwoWheelerId++,
      kind: 'bicycle',
      instanceIndex: i,
      colliderIndex,
      baseColliderRadius: baseColRadius,
      x: p.x,
      y: p.y,
      z: p.z,
      yaw: homeYaw,
      homeX: p.x,
      homeY: p.y,
      homeZ: p.z,
      homeYaw,
      setTransform: applyTransform,
      reset: () => {
        applyTransform(p.x, p.y, p.z, homeYaw, 0, parkedLean);
        const col = colliders[colliderIndex];
        if (col) {
          col.x = p.x;
          col.z = p.z;
          col.baseY = p.y;
          col.radius = baseColRadius;
        }
      },
    };

    applyTransform(p.x, p.y, p.z, homeYaw, 0, parkedLean);
    tmpCol.setHex(cyclePalette[p.colorIdx % cyclePalette.length]);
    imFrame.setColorAt(i, tmpCol);
    vehicles.push(vehicle);
  });

  for (const im of [imRubber, imFrame, imChrome]) {
    im.frustumCulled = false;
    im.instanceMatrix.needsUpdate = true;
    if (im.instanceColor) im.instanceColor.needsUpdate = true;
    group.add(im);
  }
  return { group, vehicles };
}

/**
 * Renders all classic Indian Street Motorcycles / Bikes (বাইক) across markets, streets & village edges
 * in just 4 InstancedMesh draw calls, returning rideable per-instance controllers.
 */
export function buildInstancedMotorcycles(
  placements: TwoWheelerPlacement[],
  colliders: CircleCollider[],
): { group: THREE.Group; vehicles: RideableTwoWheeler[] } {
  const group = new THREE.Group();
  const vehicles: RideableTwoWheeler[] = [];
  if (placements.length === 0) return { group, vehicles };

  // Aligned along X axis (rear tire at x = -0.68, front tire at x = +0.68, total length ~2.12m, height ~1.18m)
  const rTire = 0.35;
  const xRear = -0.68;
  const xFront = 0.68;

  // --- Material Group 1: Chunky Motorcycle Tires, Stepped Two-Seater Bench & Rubber Grips ---
  const rubberParts: THREE.BufferGeometry[] = [];
  for (const wx of [xRear, xFront]) {
    const tire = new THREE.TorusGeometry(rTire, 0.095, 10, 18);
    tire.translate(wx, rTire + 0.04, 0);
    rubberParts.push(tire);
  }
  // Contoured black leather stepped two-person commuter bench seat
  const riderSeat = new THREE.BoxGeometry(0.46, 0.14, 0.31);
  riderSeat.translate(-0.18, 0.78, 0);
  rubberParts.push(riderSeat);
  const pillionSeat = new THREE.BoxGeometry(0.44, 0.15, 0.32);
  pillionSeat.translate(-0.6, 0.84, 0);
  rubberParts.push(pillionSeat);
  // Handlebar rubber grips
  for (const gz of [-0.36, 0.36]) {
    const grip = new THREE.CylinderGeometry(0.028, 0.028, 0.15, 6);
    grip.rotateX(Math.PI / 2);
    grip.translate(0.36, 1.08, gz);
    rubberParts.push(grip);
  }
  // Rear mudflap
  const flap = new THREE.BoxGeometry(0.06, 0.24, 0.2);
  flap.rotateZ(-0.28);
  flap.translate(-1.02, 0.56, 0);
  rubberParts.push(flap);
  const motoRubberGeo = mergeParts(rubberParts, false);

  // --- Material Group 2: Glossy Painted Fuel Tank, Side Panels, Curved Fenders & Headlight Cowl ---
  const paintParts: THREE.BufferGeometry[] = [];
  // Iconic sculpted teardrop-profile motorcycle fuel tank
  const tankCore = new THREE.CylinderGeometry(0.18, 0.21, 0.58, 10);
  tankCore.rotateZ(Math.PI / 2 - 0.12);
  tankCore.scale(1.0, 0.85, 1.05);
  tankCore.translate(0.18, 0.88, 0);
  paintParts.push(tankCore);
  const tankTop = new THREE.BoxGeometry(0.48, 0.18, 0.32);
  tankTop.rotateZ(-0.1);
  tankTop.translate(0.17, 0.91, 0);
  paintParts.push(tankTop);
  // Side battery/tool cover panels under seat
  for (const sz of [-0.15, 0.15]) {
    const panel = new THREE.BoxGeometry(0.38, 0.26, 0.07);
    panel.translate(-0.22, 0.62, sz);
    paintParts.push(panel);
  }
  // Curved rear tail fairing
  const tailCowl = new THREE.BoxGeometry(0.36, 0.14, 0.28);
  tailCowl.rotateZ(0.16);
  tailCowl.translate(-0.84, 0.82, 0);
  paintParts.push(tailCowl);
  // Front & rear curved wheel mudguards
  const frontFender = new THREE.TorusGeometry(rTire + 0.11, 0.075, 6, 12, Math.PI * 0.68);
  frontFender.rotateZ(Math.PI * 0.16);
  frontFender.translate(xFront, rTire + 0.04, 0);
  paintParts.push(frontFender);
  const rearFender = new THREE.TorusGeometry(rTire + 0.12, 0.08, 6, 12, Math.PI * 0.72);
  rearFender.rotateZ(Math.PI * 0.18);
  rearFender.translate(xRear, rTire + 0.04, 0);
  paintParts.push(rearFender);
  // Front headlamp visor cowl
  const cowl = new THREE.BoxGeometry(0.18, 0.24, 0.26);
  cowl.rotateZ(-0.28);
  cowl.translate(0.55, 0.98, 0);
  paintParts.push(cowl);
  const motoPaintGeo = mergeParts(paintParts, false);

  // --- Material Group 3: Engine Block, Chrome Exhaust Silencer, Telescopic Forks, Wheel Rims/Spokes, Shocks & Mirrors ---
  const metalParts: THREE.BufferGeometry[] = [];
  // Air-cooled ribbed engine block + crankcase
  const engineBlock = new THREE.BoxGeometry(0.42, 0.36, 0.28);
  engineBlock.translate(0.06, 0.5, 0);
  metalParts.push(engineBlock);
  const cylHead = new THREE.CylinderGeometry(0.14, 0.15, 0.28, 8);
  cylHead.rotateZ(-0.18);
  cylHead.translate(0.14, 0.66, 0);
  metalParts.push(cylHead);
  // Iconic long chrome exhaust muffler along right side (+Z)
  metalParts.push(makeTubeBetween(0.22, 0.56, 0.13, 0.26, 0.34, 0.18, 0.036, 0.036));
  const muffler = new THREE.CylinderGeometry(0.062, 0.048, 0.96, 8);
  muffler.rotateZ(Math.PI / 2 - 0.1);
  muffler.translate(-0.26, 0.34, 0.2);
  metalParts.push(muffler);
  // Twin telescopic front suspension forks
  for (const fz of [-0.12, 0.12]) {
    metalParts.push(makeTubeBetween(0.44, 1.04, fz, xFront, rTire + 0.04, fz * 0.85, 0.032, 0.026));
    // Twin rear coil shock absorbers
    metalParts.push(makeTubeBetween(-0.48, 0.76, fz * 1.15, xRear, rTire + 0.04, fz * 1.15, 0.028, 0.028));
    // Rear swingarm
    metalParts.push(makeTubeBetween(-0.1, 0.42, fz, xRear, rTire + 0.04, fz, 0.024, 0.024));
  }
  // Raised commuter handlebars + twin side mirrors
  metalParts.push(makeTubeBetween(0.41, 1.06, -0.32, 0.41, 1.06, 0.32, 0.022, 0.022));
  for (const mz of [-0.28, 0.28]) {
    metalParts.push(makeTubeBetween(0.4, 1.07, mz, 0.38, 1.22, mz * 1.2, 0.01, 0.01));
    const mirror = new THREE.BoxGeometry(0.04, 0.08, 0.12);
    mirror.translate(0.38, 1.24, mz * 1.24);
    metalParts.push(mirror);
  }
  // Alloy wheel hubs & 5-spoke star struts
  for (const wx of [xRear, xFront]) {
    const rim = new THREE.TorusGeometry(rTire - 0.085, 0.028, 6, 14);
    rim.translate(wx, rTire + 0.04, 0);
    metalParts.push(rim);
    const hub = new THREE.CylinderGeometry(0.068, 0.068, 0.2, 8);
    hub.rotateX(Math.PI / 2);
    hub.translate(wx, rTire + 0.04, 0);
    metalParts.push(hub);
    for (let s = 0; s < 3; s++) {
      const spoke = new THREE.BoxGeometry(0.032, (rTire - 0.08) * 2, 0.036);
      spoke.rotateZ((s * Math.PI) / 3);
      spoke.translate(wx, rTire + 0.04, 0);
      metalParts.push(spoke);
    }
  }
  // Rear pillion grab rail & side kickstand
  const grabRail = new THREE.TorusGeometry(0.16, 0.02, 6, 10, Math.PI);
  grabRail.rotateX(Math.PI / 2);
  grabRail.rotateZ(Math.PI / 2);
  grabRail.translate(-0.82, 0.9, 0);
  metalParts.push(grabRail);
  metalParts.push(makeTubeBetween(-0.08, 0.36, 0.1, -0.18, 0.02, 0.32, 0.018, 0.018));
  const motoMetalGeo = mergeParts(metalParts, false);

  // --- Material Group 4: Round Front Headlamp & Rear Tail-Lamp ---
  const lampParts: THREE.BufferGeometry[] = [];
  const headLamp = new THREE.CylinderGeometry(0.11, 0.09, 0.14, 10);
  headLamp.rotateZ(Math.PI / 2);
  headLamp.translate(0.62, 0.94, 0);
  lampParts.push(headLamp);
  const tailLamp = new THREE.BoxGeometry(0.08, 0.1, 0.16);
  tailLamp.translate(-0.98, 0.82, 0);
  lampParts.push(tailLamp);
  const motoLampGeo = mergeParts(lampParts, false);

  const rubberMat = new THREE.MeshStandardMaterial({ color: 0x1d1f23, roughness: 0.88, metalness: 0.05 });
  const paintMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.26, metalness: 0.48 });
  const metalMat = new THREE.MeshStandardMaterial({ color: 0xc2cbd4, roughness: 0.28, metalness: 0.84 });
  const lampMat = new THREE.MeshStandardMaterial({
    color: 0xfff0c4,
    emissive: 0x4a3818,
    emissiveIntensity: 0.8,
    roughness: 0.2,
    metalness: 0.15,
  });

  const n = placements.length;
  const imRubber = new THREE.InstancedMesh(motoRubberGeo, rubberMat, n);
  const imPaint = new THREE.InstancedMesh(motoPaintGeo, paintMat, n);
  const imMetal = new THREE.InstancedMesh(motoMetalGeo, metalMat, n);
  const imLamp = new THREE.InstancedMesh(motoLampGeo, lampMat, n);
  imPaint.castShadow = true;
  imRubber.castShadow = true;
  imMetal.castShadow = true;

  // Classic Kolkata street motorcycle finishes (Royal Maroon, Gloss Black, Racing Red, Cobalt Blue, Military Olive, Metallic Silver)
  const motoPalette = [0x7d1921, 0x1c2128, 0xc42828, 0x1c4b85, 0x3b4f34, 0x8d99a6];
  const tmpCol = new THREE.Color();
  const baseScale = 1.08;
  const parkedLean = 0.13;
  const baseColRadius = 0.82;

  placements.forEach((p, i) => {
    const homeYaw = p.rotY + Math.PI / 2;
    const colliderIndex = colliders.length;
    // Compact cover collider (~waist/chest crouch cover without trapping movement)
    colliders.push({
      x: p.x,
      z: p.z,
      radius: baseColRadius,
      height: 1.18,
      baseY: p.y,
      kind: 'prop',
    });

    const applyTransform = (
      x: number,
      y: number,
      z: number,
      travelYaw: number,
      slopePitch: number,
      leanRoll: number,
    ) => {
      vehicle.x = x;
      vehicle.y = y;
      vehicle.z = z;
      vehicle.yaw = travelYaw;
      _bikeDummy.position.set(x, y, z);
      _bikeDummy.rotation.set(leanRoll, travelYaw - Math.PI / 2, slopePitch);
      _bikeDummy.scale.setScalar(baseScale);
      _bikeDummy.updateMatrix();
      imRubber.setMatrixAt(i, _bikeDummy.matrix);
      imPaint.setMatrixAt(i, _bikeDummy.matrix);
      imMetal.setMatrixAt(i, _bikeDummy.matrix);
      imLamp.setMatrixAt(i, _bikeDummy.matrix);
      imRubber.instanceMatrix.needsUpdate = true;
      imPaint.instanceMatrix.needsUpdate = true;
      imMetal.instanceMatrix.needsUpdate = true;
      imLamp.instanceMatrix.needsUpdate = true;
    };

    const vehicle: RideableTwoWheeler = {
      id: _nextTwoWheelerId++,
      kind: 'motorcycle',
      instanceIndex: i,
      colliderIndex,
      baseColliderRadius: baseColRadius,
      x: p.x,
      y: p.y,
      z: p.z,
      yaw: homeYaw,
      homeX: p.x,
      homeY: p.y,
      homeZ: p.z,
      homeYaw,
      setTransform: applyTransform,
      reset: () => {
        applyTransform(p.x, p.y, p.z, homeYaw, 0, parkedLean);
        const col = colliders[colliderIndex];
        if (col) {
          col.x = p.x;
          col.z = p.z;
          col.baseY = p.y;
          col.radius = baseColRadius;
        }
      },
    };

    applyTransform(p.x, p.y, p.z, homeYaw, 0, parkedLean);
    tmpCol.setHex(motoPalette[p.colorIdx % motoPalette.length]);
    imPaint.setColorAt(i, tmpCol);
    vehicles.push(vehicle);
  });

  for (const im of [imRubber, imPaint, imMetal, imLamp]) {
    im.frustumCulled = false;
    im.instanceMatrix.needsUpdate = true;
    if (im.instanceColor) im.instanceColor.needsUpdate = true;
    group.add(im);
  }
  return { group, vehicles };
}
