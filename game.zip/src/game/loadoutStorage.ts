import {
  GamchaStyle,
  GameMode,
  HERO_OUTFIT_CATALOG,
  HeroOutfitId,
  LoadoutPreset,
  WEAPON_CATALOG,
  WeaponType,
} from './types';

const STORAGE_KEY_OUTFIT = 'banglar_joddha_hero_outfit_v1';
const STORAGE_KEY_GAMCHA = 'banglar_joddha_gamcha_v1';
const STORAGE_KEY_PRESETS = 'banglar_joddha_loadout_presets_v1';

export const DEFAULT_LOADOUT_PRESETS: LoadoutPreset[] = [
  {
    id: 'preset-1',
    slot: 1,
    nameBn: 'সার্ভাইভাল যোদ্ধা',
    outfit: 'classic_khadi',
    gamchaStyle: 'red-white',
    weaponType: 'agni47',
    gameMode: 'survival',
  },
  {
    id: 'preset-2',
    slot: 2,
    nameBn: 'জঙ্গল ও প্রাণী শিকার',
    outfit: 'sundarban_ranger',
    gamchaStyle: 'green-white',
    weaponType: 'trishul',
    gameMode: 'pet_taming',
  },
  {
    id: 'preset-3',
    slot: 3,
    nameBn: 'কালবৈশাখী অ্যাসল্ট',
    outfit: 'kalboishakhi_noir',
    gamchaStyle: 'red-white',
    weaponType: 'kalbhairav',
    gameMode: 'survival',
  },
];

function isValidOutfit(value: unknown): value is HeroOutfitId {
  return typeof value === 'string' && value in HERO_OUTFIT_CATALOG;
}

function isValidGamcha(value: unknown): value is GamchaStyle {
  return value === 'red-white' || value === 'green-white';
}

function isValidWeapon(value: unknown): value is WeaponType {
  return typeof value === 'string' && value in WEAPON_CATALOG;
}

function isValidMode(value: unknown): value is GameMode {
  return value === 'survival' || value === 'pet_taming';
}

export function loadHeroOutfit(): HeroOutfitId {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_OUTFIT);
    if (isValidOutfit(raw)) return raw;
  } catch {
    // ignore storage errors
  }
  return 'classic_khadi';
}

export function saveHeroOutfit(outfit: HeroOutfitId): void {
  try {
    localStorage.setItem(STORAGE_KEY_OUTFIT, outfit);
  } catch {
    // ignore storage errors
  }
}

export function loadGamchaStyle(): GamchaStyle {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_GAMCHA);
    if (isValidGamcha(raw)) return raw;
  } catch {
    // ignore storage errors
  }
  return 'red-white';
}

export function saveGamchaStyle(style: GamchaStyle): void {
  try {
    localStorage.setItem(STORAGE_KEY_GAMCHA, style);
  } catch {
    // ignore storage errors
  }
}

export function loadLoadoutPresets(): LoadoutPreset[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_PRESETS);
    if (!raw) return DEFAULT_LOADOUT_PRESETS.map((p) => ({ ...p }));
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed) || parsed.length !== 3) {
      return DEFAULT_LOADOUT_PRESETS.map((p) => ({ ...p }));
    }
    return DEFAULT_LOADOUT_PRESETS.map((fallback, idx) => {
      const candidate = parsed[idx] as Partial<LoadoutPreset> | undefined;
      if (!candidate || typeof candidate !== 'object') return { ...fallback };
      return {
        id: fallback.id,
        slot: fallback.slot,
        nameBn:
          typeof candidate.nameBn === 'string' && candidate.nameBn.trim().length > 0
            ? candidate.nameBn.trim()
            : fallback.nameBn,
        outfit: isValidOutfit(candidate.outfit) ? candidate.outfit : fallback.outfit,
        gamchaStyle: isValidGamcha(candidate.gamchaStyle)
          ? candidate.gamchaStyle
          : fallback.gamchaStyle,
        weaponType: isValidWeapon(candidate.weaponType)
          ? candidate.weaponType
          : fallback.weaponType,
        gameMode: isValidMode(candidate.gameMode) ? candidate.gameMode : fallback.gameMode,
      };
    });
  } catch {
    return DEFAULT_LOADOUT_PRESETS.map((p) => ({ ...p }));
  }
}

export function saveLoadoutPresets(presets: LoadoutPreset[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_PRESETS, JSON.stringify(presets));
  } catch {
    // ignore storage errors
  }
}
