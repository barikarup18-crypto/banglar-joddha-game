import { toBengaliNumber } from './GameEngine';
import {
  ApsaraProgressState,
  FriendEntry,
  HudSnapshot,
  MissionProgress,
} from './types';

const PROGRESS_STORAGE_KEY = 'banglar_joddha_apsara_progress_v1';
const FRIENDS_STORAGE_KEY = 'banglar_joddha_apsara_friends_v1';

export const DAILY_GIFT_COINS = 100;

export function getTodayDateKey(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function createDefaultMissions(): MissionProgress[] {
  return [
    {
      id: 'headshots_3',
      title: '৩টি হেডশট করুন',
      target: 3,
      progress: 0,
      rewardCoins: 150,
      unlockTitle: 'অচ্যুত নিশানা',
      claimed: false,
    },
    {
      id: 'kills_5',
      title: '৫ জন শত্রু পরাজিত করুন',
      target: 5,
      progress: 0,
      rewardCoins: 200,
      unlockTitle: 'হুগলির বীর',
      claimed: false,
    },
    {
      id: 'sanjibani_5',
      title: '৫টি সঞ্জীবনী গাছ সংগ্রহ করুন',
      target: 5,
      progress: 0,
      rewardCoins: 150,
      unlockTitle: 'সঞ্জীবনী রক্ষক',
      claimed: false,
    },
  ];
}

export function createDefaultProgress(): ApsaraProgressState {
  return {
    goldCoins: 2450,
    diamonds: 120,
    lastDailyClaimDate: null,
    dailyStreak: 0,
    missions: createDefaultMissions(),
    unlockedTitles: ['হুগলি গার্ড'],
    activeTitle: 'হুগলি গার্ড',
    auraBoostUnlocked: false,
  };
}

export function createDefaultFriends(): FriendEntry[] {
  return [
    {
      id: 'friend-rahul',
      name: 'রাহুল',
      aliases: ['rahul', 'রাহুল', 'রাহুলকে'],
      level: 7,
      status: 'suggested',
      presence: 'online',
      invitedToSquad: false,
      district: 'কলকাতা',
    },
    {
      id: 'friend-riya',
      name: 'রিয়া',
      aliases: ['riya', 'ria', 'রিয়া', 'রিয়া'],
      level: 9,
      status: 'incoming_request',
      presence: 'online',
      invitedToSquad: false,
      district: 'হাওড়া',
    },
    {
      id: 'friend-anirban',
      name: 'অনির্বাণ',
      aliases: ['anirban', 'অনির্বাণ', 'অনির্বাণকে', 'অনির্বান'],
      level: 11,
      status: 'friend',
      presence: 'online',
      invitedToSquad: false,
      district: 'শিলিগুড়ি',
    },
    {
      id: 'friend-sourav',
      name: 'সৌরভ',
      aliases: ['sourav', 'saurav', 'সৌরভ', 'সৌরভকে'],
      level: 8,
      status: 'suggested',
      presence: 'in_match',
      invitedToSquad: false,
      district: 'দুর্গাপুর',
    },
    {
      id: 'friend-priya',
      name: 'প্রিয়া',
      aliases: ['priya', 'প্রিয়া', 'প্রিয়া'],
      level: 6,
      status: 'friend',
      presence: 'online',
      invitedToSquad: false,
      district: 'শান্তিনিকেতন',
    },
    {
      id: 'friend-sudipta',
      name: 'সুদীপ্ত',
      aliases: ['sudipta', 'sudipto', 'সুদীপ্ত'],
      level: 10,
      status: 'incoming_request',
      presence: 'offline',
      invitedToSquad: false,
      district: 'বর্ধমান',
    },
  ];
}

export function loadApsaraProgress(): ApsaraProgressState {
  const defaults = createDefaultProgress();
  try {
    const raw = window.localStorage.getItem(PROGRESS_STORAGE_KEY);
    if (!raw) return defaults;
    const parsed = JSON.parse(raw) as Partial<ApsaraProgressState>;
    const savedMap = new Map<string, MissionProgress>();
    if (Array.isArray(parsed.missions)) {
      for (const m of parsed.missions) {
        if (m && typeof m.id === 'string') {
          savedMap.set(m.id, m);
        }
      }
    }
    const mergedMissions = defaults.missions.map((base) => {
      const saved = savedMap.get(base.id);
      if (!saved) return base;
      return {
        ...base,
        progress: Math.min(base.target, Math.max(0, Number(saved.progress) || 0)),
        claimed: Boolean(saved.claimed),
      };
    });
    const unlockedTitles =
      Array.isArray(parsed.unlockedTitles) && parsed.unlockedTitles.length > 0
        ? parsed.unlockedTitles.filter((t): t is string => typeof t === 'string')
        : defaults.unlockedTitles;
    const activeTitle =
      typeof parsed.activeTitle === 'string' && unlockedTitles.includes(parsed.activeTitle)
        ? parsed.activeTitle
        : unlockedTitles[0];

    return {
      goldCoins: typeof parsed.goldCoins === 'number' ? parsed.goldCoins : defaults.goldCoins,
      diamonds: typeof parsed.diamonds === 'number' ? parsed.diamonds : defaults.diamonds,
      lastDailyClaimDate:
        typeof parsed.lastDailyClaimDate === 'string' ? parsed.lastDailyClaimDate : null,
      dailyStreak: typeof parsed.dailyStreak === 'number' ? parsed.dailyStreak : 0,
      missions: mergedMissions,
      unlockedTitles,
      activeTitle,
      auraBoostUnlocked: Boolean(parsed.auraBoostUnlocked),
    };
  } catch {
    return defaults;
  }
}

export function saveApsaraProgress(state: ApsaraProgressState): void {
  try {
    window.localStorage.setItem(PROGRESS_STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Ignore restricted storage environments
  }
}

export function loadFriendsList(): FriendEntry[] {
  try {
    const raw = window.localStorage.getItem(FRIENDS_STORAGE_KEY);
    if (!raw) return createDefaultFriends();
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed) || parsed.length === 0) return createDefaultFriends();
    return parsed as FriendEntry[];
  } catch {
    return createDefaultFriends();
  }
}

export function saveFriendsList(friends: FriendEntry[]): void {
  try {
    window.localStorage.setItem(FRIENDS_STORAGE_KEY, JSON.stringify(friends));
  } catch {
    // Ignore restricted storage environments
  }
}

export function canClaimDailyGift(state: ApsaraProgressState): boolean {
  return state.lastDailyClaimDate !== getTodayDateKey();
}

// --- Web Speech API (100% Client-Side Bengali TTS & STT) ---

interface BrowserSpeechRecognitionEvent {
  resultIndex: number;
  results: {
    length: number;
    [index: number]: {
      isFinal: boolean;
      0: { transcript: string };
    };
  };
}

interface BrowserSpeechRecognition {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  onstart: (() => void) | null;
  onend: (() => void) | null;
  onerror: ((event: { error: string }) => void) | null;
  onresult: ((event: BrowserSpeechRecognitionEvent) => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
}

type SpeechRecognitionCtor = new () => BrowserSpeechRecognition;

export function getSpeechRecognitionCtor(): SpeechRecognitionCtor | null {
  if (typeof window === 'undefined') return null;
  const w = window as unknown as {
    SpeechRecognition?: SpeechRecognitionCtor;
    webkitSpeechRecognition?: SpeechRecognitionCtor;
  };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

export function isSpeechRecognitionSupported(): boolean {
  return getSpeechRecognitionCtor() !== null;
}

let cachedBengaliFemaleVoice: SpeechSynthesisVoice | null = null;
let voicesListenerAttached = false;

const FEMALE_VOICE_KEYWORDS = [
  'nabanita',
  'tanishaa',
  'kalpana',
  'heera',
  'shreya',
  'swara',
  'priya',
  'ananya',
  'female',
  'woman',
  'girl',
  'google বাংলা',
  'google bangla',
  'google bengali',
];

const MALE_VOICE_KEYWORDS = ['bashkar', 'pradeep', 'hemant', 'ravi', 'male', 'man', 'boy', 'guy'];

function scoreVoiceForApsara(voice: SpeechSynthesisVoice): number {
  const lang = voice.lang.toLowerCase();
  const name = voice.name.toLowerCase();
  if (!lang.startsWith('bn')) return -1;

  let score = 10;
  if (lang === 'bn-bd') score += 8;
  else if (lang === 'bn-in') score += 7;

  if (FEMALE_VOICE_KEYWORDS.some((kw) => name.includes(kw))) {
    score += 30;
  }
  if (MALE_VOICE_KEYWORDS.some((kw) => name.includes(kw))) {
    score -= 25;
  }
  if (voice.localService) {
    score += 2;
  }
  return score;
}

export function selectBengaliFemaleVoice(): SpeechSynthesisVoice | null {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return null;
  const voices = window.speechSynthesis.getVoices();
  if (!voices || voices.length === 0) return cachedBengaliFemaleVoice;

  const bnVoices = voices.filter((v) => v.lang.toLowerCase().startsWith('bn'));
  if (bnVoices.length === 0) return null;

  let bestVoice: SpeechSynthesisVoice = bnVoices[0];
  let bestScore = scoreVoiceForApsara(bestVoice);
  for (let i = 1; i < bnVoices.length; i++) {
    const s = scoreVoiceForApsara(bnVoices[i]);
    if (s > bestScore) {
      bestScore = s;
      bestVoice = bnVoices[i];
    }
  }

  cachedBengaliFemaleVoice = bestVoice;
  return bestVoice;
}

export function initApsaraVoices(): () => void {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return () => {};
  const refresh = () => {
    selectBengaliFemaleVoice();
  };
  refresh();

  if (!voicesListenerAttached) {
    voicesListenerAttached = true;
    window.speechSynthesis.onvoiceschanged = refresh;
  }
  window.speechSynthesis.addEventListener?.('voiceschanged', refresh);

  return () => {
    window.speechSynthesis.removeEventListener?.('voiceschanged', refresh);
  };
}

export function stopApsaraSpeech(): void {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
  try {
    window.speechSynthesis.cancel();
  } catch {
    // Ignore synth cancel errors
  }
}

export function speakAsApsara(
  text: string,
  options: {
    muted: boolean;
    onStart?: () => void;
    onEnd?: () => void;
  },
): () => void {
  let cleanedUp = false;
  let fallbackTimer: number | null = null;
  let waitVoicesTimer: number | null = null;
  let voicesChangedHandler: (() => void) | null = null;

  const clearTimers = () => {
    if (fallbackTimer !== null) {
      window.clearTimeout(fallbackTimer);
      fallbackTimer = null;
    }
    if (waitVoicesTimer !== null) {
      window.clearTimeout(waitVoicesTimer);
      waitVoicesTimer = null;
    }
    if (voicesChangedHandler && typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.removeEventListener?.('voiceschanged', voicesChangedHandler);
      voicesChangedHandler = null;
    }
  };

  const finish = () => {
    if (cleanedUp) return;
    cleanedUp = true;
    clearTimers();
    options.onEnd?.();
  };

  if (options.muted || typeof window === 'undefined' || !('speechSynthesis' in window)) {
    // Still pulse silhouette briefly so visual speech bubble feels alive when muted
    options.onStart?.();
    const durationMs = Math.min(4400, Math.max(1600, text.length * 46));
    fallbackTimer = window.setTimeout(finish, durationMs);
    return () => {
      cleanedUp = true;
      clearTimers();
    };
  }

  const dispatchSpeak = () => {
    if (cleanedUp) return;
    try {
      const synth = window.speechSynthesis;
      synth.cancel();
      if (synth.paused) {
        synth.resume();
      }

      const utterance = new SpeechSynthesisUtterance(text);
      const chosenVoice = selectBengaliFemaleVoice();
      if (chosenVoice) {
        utterance.voice = chosenVoice;
        utterance.lang = chosenVoice.lang || 'bn-IN';
      } else {
        utterance.lang = 'bn-IN';
      }

      // Enforce soft, sweet feminine Bengali voice tuning even on single-voice devices
      utterance.pitch = 1.28;
      utterance.rate = 0.96;
      utterance.volume = 1.0;

      let started = false;
      utterance.onstart = () => {
        if (cleanedUp) return;
        started = true;
        options.onStart?.();
      };
      utterance.onend = () => finish();
      utterance.onerror = () => finish();

      // Safety guard: some embedded iframes do not fire onstart/onend reliably
      const maxDurationMs = Math.min(10000, Math.max(2800, text.length * 100));
      fallbackTimer = window.setTimeout(() => {
        if (!started) options.onStart?.();
        finish();
      }, maxDurationMs);

      options.onStart?.();
      synth.speak(utterance);
    } catch {
      options.onStart?.();
      fallbackTimer = window.setTimeout(finish, 2200);
    }
  };

  // Handle async voice list loading in Chrome / Edge / Android WebView
  const voicesNow = window.speechSynthesis.getVoices();
  if (voicesNow.length > 0 || cachedBengaliFemaleVoice) {
    dispatchSpeak();
  } else {
    let spoken = false;
    const triggerOnce = () => {
      if (spoken || cleanedUp) return;
      spoken = true;
      clearTimers();
      dispatchSpeak();
    };
    voicesChangedHandler = triggerOnce;
    window.speechSynthesis.addEventListener?.('voiceschanged', triggerOnce);
    waitVoicesTimer = window.setTimeout(triggerOnce, 220);
  }

  return () => {
    cleanedUp = true;
    clearTimers();
    stopApsaraSpeech();
  };
}

// --- Bengali Voice Command & Conversational Response Engine ---

export type ApsaraAction =
  | { type: 'none' }
  | { type: 'send_friend_request'; targetName: string; friendId: string | null }
  | { type: 'invite_squad'; targetName: string; friendId: string | null }
  | { type: 'accept_friend_request'; targetName: string | null; friendId: string | null }
  | { type: 'claim_daily_gift' }
  | { type: 'open_friends' }
  | { type: 'open_rewards' };

export interface ApsaraDialogResult {
  reply: string;
  action: ApsaraAction;
}

function normalizeText(input: string): string {
  return input
    .trim()
    .toLowerCase()
    .replace(/[।?!,.'"`~()[\]{}]/g, ' ')
    .replace(/\s+/g, ' ');
}

function stripBengaliCaseSuffix(raw: string): string {
  return raw
    .trim()
    .replace(/[-–—]?\s*(কে|এর|র)$/u, '')
    .replace(/^(আমার বন্ধু|বন্ধু|যোদ্ধা)\s+/u, '')
    .trim();
}

function matchFriendBySpokenName(
  spokenRaw: string,
  friends: FriendEntry[],
): FriendEntry | null {
  const cleaned = normalizeText(stripBengaliCaseSuffix(spokenRaw));
  if (!cleaned) return null;

  for (const f of friends) {
    const fName = normalizeText(f.name);
    if (fName === cleaned || cleaned.includes(fName) || fName.includes(cleaned)) {
      return f;
    }
    for (const alias of f.aliases) {
      const normAlias = normalizeText(alias);
      if (
        normAlias === cleaned ||
        cleaned.includes(normAlias) ||
        (cleaned.length >= 3 && normAlias.includes(cleaned))
      ) {
        return f;
      }
    }
  }
  return null;
}

function extractNameBeforeCommand(text: string, commandRegex: RegExp): string {
  const match = text.match(commandRegex);
  if (!match || !match[1]) return '';
  return stripBengaliCaseSuffix(match[1]);
}

const TIPS_POOL = [
  'শোনো যোদ্ধা—দূর থেকে শত্রুকে ঘায়েল করতে ত্রিশূল স্নাইপারের স্কোপ ব্যবহার করো, হেডশটে আড়াই গুণ ক্ষতি হবে!',
  'হুগলির পাড়ে যোদ্ধা সিন্দুক খুঁজতে ভুলো না! ওখান থেকে রক্ষা কবচ পেলে তোমার ৫০ পয়েন্টের নীল ঢাল তৈরি হবে।',
  'কালবৈশাখী বলয় ছোট হওয়ার আগেই নিরাপদ অঞ্চলে ঢুকে পড়ো, আর ব্যাগে অন্তত দুটি সঞ্জীবনী গাছ রাখো!',
  'মাটির ঘরের আড়ালে শত্রু লুকিয়ে থাকলে একটা বজ্র গোলা ছুঁড়ে দাও—তিন সেকেন্ডেই খেলা ঘুরে যাবে!',
  'কাছের লড়াইয়ে কালভৈরব শটগান আর নীরব আক্রমণে বাংলার ফলা অপ্রতিরোধ্য। মাথা ঠান্ডা রাখলে জয় নিশ্চিত!',
];

export function processApsaraUtterance(
  rawText: string,
  friends: FriendEntry[],
  progress: ApsaraProgressState,
): ApsaraDialogResult {
  const text = rawText.trim();
  const norm = normalizeText(text);

  // 1. Accept incoming friend request: "রিকোয়েস্ট গ্রহণ করো" / "অনুরোধ গ্রহণ করো"
  if (
    /(রিকোয়েস্ট|রিকোয়েস্ট|অনুরোধ|request).*(গ্রহণ|একসেপ্ট|স্বীকার|accept)|(গ্রহণ|একসেপ্ট).*(রিকোয়েস্ট|রিকোয়েস্ট|অনুরোধ)/u.test(
      norm,
    )
  ) {
    const incoming = friends.filter((f) => f.status === 'incoming_request');
    if (incoming.length === 0) {
      return {
        reply: 'এই মুহূর্তে কোনো নতুন বন্ধুত্বের অনুরোধ অপেক্ষায় নেই যোদ্ধা। বন্ধু তালিকা খুলে দেখতে পারো!',
        action: { type: 'open_friends' },
      };
    }
    // Check if a specific name was mentioned
    const specific =
      incoming.find((f) =>
        [f.name, ...f.aliases].some((a) => norm.includes(normalizeText(a))),
      ) ?? incoming[0];
    return {
      reply: `${specific.name}-এর বন্ধুত্বের অনুরোধ গ্রহণ করা হয়েছে যোদ্ধা! এখন আপনারা একসাথে লড়তে পারবে।`,
      action: {
        type: 'accept_friend_request',
        targetName: specific.name,
        friendId: specific.id,
      },
    };
  }

  // 2. Send Friend Request: "[Name]-কে রিকোয়েস্ট পাঠাও" / "[Name]-কে ফ্রেন্ড রিকোয়েস্ট পাঠাও"
  if (
    /(ফ্রেন্ড\s*)?(রিকোয়েস্ট|রিকোয়েস্ট|অনুরোধ|friend\s*request)\s*(পাঠাও|দাও|করো|send)/u.test(
      norm,
    )
  ) {
    const rawName = extractNameBeforeCommand(
      text,
      /(.+?)(?:[-–—]?\s*কে)?\s+(?:ফ্রেন্ড\s*)?(?:রিকোয়েস্ট|রিকোয়েস্ট|অনুরোধ|friend\s*request)/iu,
    );
    const matched = matchFriendBySpokenName(rawName, friends);
    const displayName = matched?.name || rawName || friends.find((f) => f.status === 'suggested')?.name || 'রাহুল';
    if (matched?.status === 'friend') {
      return {
        reply: `${matched.name} তো আগে থেকেই তোমার বন্ধু তালিকায় আছে যোদ্ধা! চাইলে ওকে খেলায় ডাকতে পারো।`,
        action: { type: 'open_friends' },
      };
    }
    return {
      reply: `${displayName}-কে বন্ধুত্বের অনুরোধ পাঠানো হয়েছে যোদ্ধা!`,
      action: {
        type: 'send_friend_request',
        targetName: displayName,
        friendId: matched?.id ?? null,
      },
    };
  }

  // 3. Squad Invite: "[Name]-কে খেলায় ডাকো" / "[Name]-কে ইনভাইট করো"
  if (/(খেলায়|খেলায়|স্কোয়াডে|স্কোয়াডে|ম্যাচে)?\s*(ডাকো|ডাক|ইনভাইট|invite)/u.test(norm)) {
    const rawName = extractNameBeforeCommand(
      text,
      /(.+?)(?:[-–—]?\s*কে)?\s+(?:খেলায়|খেলায়|স্কোয়াডে|স্কোয়াডে|ম্যাচে)?\s*(?:ডাকো|ডাক|ইনভাইট|invite)/iu,
    );
    const matched = matchFriendBySpokenName(rawName, friends);
    const displayName = matched?.name || rawName || friends.find((f) => f.status === 'friend')?.name || 'অনির্বাণ';
    return {
      reply: `${displayName}-কে খেলায় ডাকার আমন্ত্রণ পাঠানো হয়েছে যোদ্ধা! প্রস্তুত হয়ে নাও।`,
      action: {
        type: 'invite_squad',
        targetName: displayName,
        friendId: matched?.id ?? null,
      },
    };
  }

  // 4. Daily Gift / Rewards command
  if (/(উপহার|গিফট|স্বর্ণমুদ্রা|দৈনিক|চ্যালেঞ্জ|মিশন|reward|gift)/u.test(norm)) {
    if (canClaimDailyGift(progress)) {
      return {
        reply: 'তোমার জন্য আজকের ১০০ স্বর্ণমুদ্রা উপহার দিলাম যোদ্ধা! হুগলির মাঠে বিজয়ী হয়ে ফিরো।',
        action: { type: 'claim_daily_gift' },
      };
    }
    return {
      reply: 'আজকের দৈনিক উপহার তো নিয়েই নিয়েছো! মিশনগুলো সম্পূর্ণ করলে আরও স্বর্ণমুদ্রা পাবে।',
      action: { type: 'open_rewards' },
    };
  }

  // 5. Game Tips
  if (/(টিপস|জেতার|কীভাবে|কিভাবে|অস্ত্র|হেডশট|ঝড়|ঝড়|সিন্দুক|সঞ্জীবনী|কৌশল|tips)/u.test(norm)) {
    const tip = TIPS_POOL[Math.floor(Math.random() * TIPS_POOL.length)];
    return { reply: tip, action: { type: 'none' } };
  }

  // 6. Personal / Friendly Emotional Conversations
  if (/(কেমন আছো|কেমন আছেন|ভালো আছো|ভাল আছো)/u.test(norm)) {
    return {
      reply:
        'আমি ছায়ার মতো নীরব, কিন্তু তোমার কণ্ঠ শুনলে আমার সোনালি আভা আরও উজ্জ্বল হয়ে ওঠে! তুমি কেমন আছো যোদ্ধা?',
      action: { type: 'none' },
    };
  }

  if (/(কী করছো|কি করছো|কি করো|কী করো)/u.test(norm)) {
    return {
      reply:
        'হুগলির তীরে তোমার জন্য অপেক্ষা করছি আর কালবৈশাখীর গতিবিধি লক্ষ্য রাখছি। আজ কতগুলো হেডশট মারবে?',
      action: { type: 'none' },
    };
  }

  if (/(ভালোবাসো|ভালবাসো|প্রেম|পছন্দ করো|love)/u.test(norm)) {
    return {
      reply:
        'হিহি, দুষ্টু যোদ্ধা! আমি তো ছায়া আর জ্যোৎস্নার অপ্সরা—তবে তোমার সাহস আর নিশানা আমার ভীষণ প্রিয়!',
      action: { type: 'none' },
    };
  }

  if (/(মন খারাপ|দুঃখ|কষ্ট|একা|হতাশ|ক্লান্ত)/u.test(norm)) {
    return {
      reply:
        'মন খারাপ কোরো না যোদ্ধা, আমি সবসময় তোমার পাশে আছি। গভীর নিশ্বাস নাও—একটা দুর্দান্ত ম্যাচ খেললেই দেখবে মন একদম ফুরফুরে হয়ে গেছে!',
      action: { type: 'none' },
    };
  }

  if (/(তোমার নাম|তুমি কে|পরিচয়|পরিচয়)/u.test(norm)) {
    return {
      reply:
        'আমি অপ্সরা—বাংলার যোদ্ধার ছায়া-সঙ্গিনী। যুদ্ধের কৌশল, বন্ধুদের আমন্ত্রণ আর উপহার নিয়ে আমি সবসময় তোমার পাশে আছি।',
      action: { type: 'none' },
    };
  }

  if (/(হ্যালো|হাই|নমস্কার|আসসালামু|শুভ|hello|hi)/u.test(norm)) {
    return {
      reply:
        'নমস্কার যোদ্ধা! অপ্সরা তোমার কথা শুনছে। আজ কি বন্ধুদের ডাকবে, নাকি একাই ময়দানে নামবে?',
      action: { type: 'none' },
    };
  }

  if (/(ধন্যবাদ|থ্যাংকস|thanks|ভালো লাগলো)/u.test(norm)) {
    return {
      reply: 'স্বাগতম যোদ্ধা! তোমার বিজয়ই আমার সবচেয়ে বড় আনন্দ।',
      action: { type: 'none' },
    };
  }

  return {
    reply: `শুনলাম যোদ্ধা—"${text}"। তুমি চাইলে আমার কাছে জেতার টিপস চাইতে পারো, মন খুলে কথা বলতে পারো, বা কোনো বন্ধুকে খেলায় ডাকতে পারো!`,
    action: { type: 'none' },
  };
}

export function buildMatchSummaryCommentary(hud: HudSnapshot): string {
  if (hud.headshots >= 3) {
    return `অসাধারণ নিশানা যোদ্ধা! ${toBengaliNumber(hud.headshots)}টি নিখুঁত হেডশট আর ${toBengaliNumber(hud.kills)} জন শত্রু পরাজিত করেছো—আমি সত্যিই মুগ্ধ!`;
  }
  if (hud.kills >= 5) {
    return `দারুণ লড়েছো যোদ্ধা! মোট ${toBengaliNumber(hud.kills)} জন শত্রুকে হারিয়ে ${toBengaliNumber(hud.score)} স্কোর করেছো। পরের ম্যাচে আরও বড় জয় আসবে!`;
  }
  if (hud.kills >= 1) {
    return `ভালো চেষ্টা ছিল যোদ্ধা! ${toBengaliNumber(hud.kills)} জন শত্রুকে পরাজিত করেছো। পরের ম্যাচে সিন্দুক থেকে রক্ষা কবচ আর সঞ্জীবনী নিয়ে নামো!`;
  }
  return 'কোনো চিন্তা নেই যোদ্ধা, প্রতিটি লড়াই থেকেই শেখা যায়! আবার নামো, এবার অপ্সরা তোমার পাশে আছে।';
}

export const QUICK_FALLBACK_PROMPTS: { label: string; utterance: string }[] = [
  { label: 'তুমি কেমন আছো?', utterance: 'তুমি কেমন আছো?' },
  { label: 'কী করছো?', utterance: 'কী করছো?' },
  { label: 'আমাকে ভালোবাসো?', utterance: 'আমাকে ভালোবাসো?' },
  { label: 'জেতার টিপস দাও', utterance: 'জেতার টিপস দাও' },
  { label: 'রাহুল-কে রিকোয়েস্ট', utterance: 'রাহুল-কে ফ্রেন্ড রিকোয়েস্ট পাঠাও' },
  { label: 'অনির্বাণ-কে ডাকো', utterance: 'অনির্বাণ-কে খেলায় ডাকো' },
];
