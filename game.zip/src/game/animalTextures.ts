import * as THREE from 'three';
import { WildAnimalSpecies } from './types';

export interface AnimalTextureSet {
  coatMap: THREE.CanvasTexture;
  bumpMap: THREE.CanvasTexture;
  accentMap?: THREE.CanvasTexture;
  skinBumpMap?: THREE.CanvasTexture;
}

// Lightweight seeded PRNG so every animal coat pattern is crisp, natural & deterministic
function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function makeCanvas(size = 256): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  return [canvas, ctx];
}

function toTexture(
  canvas: HTMLCanvasElement,
  isColor: boolean,
  repeatX = 2,
  repeatY = 2,
): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = isColor ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeatX, repeatY);
  tex.anisotropy = 4;
  tex.needsUpdate = true;
  return tex;
}

// Shared cached micro-relief bump textures (tiny 256x256, allocated once)
let cachedFurBump: THREE.CanvasTexture | null = null;
let cachedScaleBump: THREE.CanvasTexture | null = null;
let cachedHideBump: THREE.CanvasTexture | null = null;
const cachedSpeciesSets = new Map<WildAnimalSpecies, AnimalTextureSet>();

export function getSharedFurBumpMap(): THREE.CanvasTexture {
  if (cachedFurBump) return cachedFurBump;
  const rand = mulberry32(4109);
  const [canvas, ctx] = makeCanvas(256);
  ctx.fillStyle = '#7e7e7e';
  ctx.fillRect(0, 0, 256, 256);

  // Soft undercoat clump waves
  for (let i = 0; i < 240; i++) {
    const x = rand() * 256;
    const y = rand() * 256;
    const r = 6 + rand() * 14;
    ctx.fillStyle = rand() > 0.5 ? 'rgba(175,175,175,0.12)' : 'rgba(65,65,65,0.12)';
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // Fine directional guard hair strands (wrapped vertically)
  for (let i = 0; i < 2200; i++) {
    const x = rand() * 256;
    const y = rand() * 256;
    const len = 6 + rand() * 13;
    const dx = (rand() - 0.5) * 3.2;
    const light = rand() > 0.48;
    ctx.strokeStyle = light ? 'rgba(232,232,232,0.26)' : 'rgba(34,34,34,0.28)';
    ctx.lineWidth = 0.9 + rand() * 0.9;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + dx, y + len);
    ctx.stroke();
    if (y + len > 256) {
      ctx.beginPath();
      ctx.moveTo(x, y - 256);
      ctx.lineTo(x + dx, y + len - 256);
      ctx.stroke();
    }
  }
  cachedFurBump = toTexture(canvas, false, 3, 3);
  return cachedFurBump;
}

export function getSharedScaleBumpMap(): THREE.CanvasTexture {
  if (cachedScaleBump) return cachedScaleBump;
  const [canvas, ctx] = makeCanvas(256);
  ctx.fillStyle = '#383838';
  ctx.fillRect(0, 0, 256, 256);

  // Interlocking hexagonal/diamond reptile scales with subtle ridge highlights
  const cols = 16;
  const rows = 20;
  const cellW = 256 / cols;
  const cellH = 256 / rows;

  for (let row = -1; row <= rows + 1; row++) {
    const xOff = (row & 1) === 0 ? 0 : cellW * 0.5;
    for (let col = -1; col <= cols + 1; col++) {
      const cx = col * cellW + xOff;
      const cy = row * cellH;
      const grad = ctx.createRadialGradient(cx, cy - cellH * 0.14, 1, cx, cy, cellW * 0.65);
      grad.addColorStop(0, '#ededed');
      grad.addColorStop(0.62, '#a8a8a8');
      grad.addColorStop(1, '#2a2a2a');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.moveTo(cx, cy - cellH * 0.68);
      ctx.lineTo(cx + cellW * 0.52, cy);
      ctx.lineTo(cx, cy + cellH * 0.68);
      ctx.lineTo(cx - cellW * 0.52, cy);
      ctx.closePath();
      ctx.fill();
    }
  }
  cachedScaleBump = toTexture(canvas, false, 3, 2);
  return cachedScaleBump;
}

export function getSharedHideBumpMap(): THREE.CanvasTexture {
  if (cachedHideBump) return cachedHideBump;
  const rand = mulberry32(8831);
  const [canvas, ctx] = makeCanvas(256);
  ctx.fillStyle = '#808080';
  ctx.fillRect(0, 0, 256, 256);

  // Organic leathery skin pores & chitin pits + micro-creases
  for (let i = 0; i < 950; i++) {
    const x = rand() * 256;
    const y = rand() * 256;
    const r = 1.2 + rand() * 4.5;
    ctx.fillStyle = rand() > 0.5 ? 'rgba(215,215,215,0.2)' : 'rgba(38,38,38,0.24)';
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
  for (let i = 0; i < 180; i++) {
    const x = rand() * 256;
    const y = rand() * 256;
    const a = (rand() - 0.5) * 0.7;
    const len = 10 + rand() * 22;
    ctx.strokeStyle = 'rgba(32,32,32,0.28)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + Math.cos(a) * len, y + Math.sin(a) * len);
    ctx.stroke();
  }
  cachedHideBump = toTexture(canvas, false, 2, 2);
  return cachedHideBump;
}

function paintFurStrokes(
  ctx: CanvasRenderingContext2D,
  rand: () => number,
  count: number,
  lightColor: string,
  darkColor: string,
  lenMin = 6,
  lenMax = 14,
): void {
  for (let i = 0; i < count; i++) {
    const x = rand() * 256;
    const y = rand() * 256;
    const len = lenMin + rand() * (lenMax - lenMin);
    const dx = (rand() - 0.5) * 2.6;
    ctx.strokeStyle = rand() > 0.48 ? lightColor : darkColor;
    ctx.lineWidth = 0.9 + rand() * 1.1;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + dx, y + len);
    ctx.stroke();
    if (y + len > 256) {
      ctx.beginPath();
      ctx.moveTo(x, y - 256);
      ctx.lineTo(x + dx, y + len - 256);
      ctx.stroke();
    }
  }
}

function createTigerCoatTexture(): THREE.CanvasTexture {
  const rand = mulberry32(101);
  const [canvas, ctx] = makeCanvas(256);

  // Grounded Sundarbans dusty burnt-ochre to deep russet wild coat gradient
  const baseGrad = ctx.createLinearGradient(0, 0, 256, 0);
  baseGrad.addColorStop(0, '#a35d28');
  baseGrad.addColorStop(0.45, '#8f4c1f');
  baseGrad.addColorStop(0.75, '#a6622d');
  baseGrad.addColorStop(1, '#a35d28');
  ctx.fillStyle = baseGrad;
  ctx.fillRect(0, 0, 256, 256);

  // Organic fur tonal mottling & wild forest dust
  for (let i = 0; i < 260; i++) {
    const x = rand() * 256;
    const y = rand() * 256;
    const r = 8 + rand() * 22;
    ctx.fillStyle = rand() > 0.5 ? 'rgba(192,140,86,0.14)' : 'rgba(58,28,12,0.18)';
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // Irregular jagged organic Bengal tiger stripes (forked & tapered, never geometric rings)
  const stripeBands = 7;
  for (let b = 0; b < stripeBands; b++) {
    const baseY = (b + 0.5) * (256 / stripeBands) + (rand() - 0.5) * 10;
    const thickness = 5.5 + rand() * 6.5;
    ctx.fillStyle = 'rgba(24, 17, 13, 0.92)';
    ctx.beginPath();
    const steps = 18;
    for (let s = 0; s <= steps; s++) {
      const px = (s / steps) * 256;
      const wave = Math.sin(s * 0.72 + b * 2.1) * 7.5 + (rand() - 0.5) * 3.5;
      const taper = 0.45 + 0.55 * Math.sin((s / steps) * Math.PI);
      const py = baseY + wave - thickness * 0.5 * taper;
      if (s === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    for (let s = steps; s >= 0; s--) {
      const px = (s / steps) * 256;
      const wave = Math.sin(s * 0.72 + b * 2.1) * 7.5 + (rand() - 0.5) * 3.5;
      const taper = 0.45 + 0.55 * Math.sin((s / steps) * Math.PI);
      const py = baseY + wave + thickness * 0.5 * taper;
      ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fill();

    // Occasional forked sub-stripe
    if (b % 2 === 0) {
      ctx.strokeStyle = 'rgba(26, 18, 14, 0.85)';
      ctx.lineWidth = 3.2;
      ctx.beginPath();
      const sx = 36 + rand() * 140;
      ctx.moveTo(sx, baseY);
      ctx.quadraticCurveTo(sx + 24, baseY + 11, sx + 52, baseY + 6);
      ctx.stroke();
    }
  }

  paintFurStrokes(ctx, rand, 1800, 'rgba(246,192,132,0.22)', 'rgba(54,24,10,0.22)', 5, 11);
  return toTexture(canvas, true, 2, 2);
}

function createLeopardCoatTexture(): THREE.CanvasTexture {
  const rand = mulberry32(202);
  const [canvas, ctx] = makeCanvas(256);

  ctx.fillStyle = '#a47e45';
  ctx.fillRect(0, 0, 256, 256);

  for (let i = 0; i < 240; i++) {
    const x = rand() * 256;
    const y = rand() * 256;
    ctx.fillStyle = rand() > 0.5 ? 'rgba(188,160,108,0.16)' : 'rgba(84,58,26,0.2)';
    ctx.beginPath();
    ctx.arc(x, y, 8 + rand() * 18, 0, Math.PI * 2);
    ctx.fill();
  }

  // Authentic broken-ring leopard rosettes with warm tawny centers
  for (let i = 0; i < 42; i++) {
    const cx = rand() * 256;
    const cy = rand() * 256;
    const r = 6.5 + rand() * 5.5;
    for (const ox of [-256, 0, 256]) {
      for (const oy of [-256, 0, 256]) {
        const px = cx + ox;
        const py = cy + oy;
        if (px < -20 || px > 276 || py < -20 || py > 276) continue;
        // Darker golden-brown core
        ctx.fillStyle = 'rgba(136, 90, 34, 0.72)';
        ctx.beginPath();
        ctx.arc(px, py, r * 0.66, 0, Math.PI * 2);
        ctx.fill();
        // 3–4 irregular dark charcoal petals around rosette rim
        const petals = 3 + Math.floor(rand() * 2);
        for (let p = 0; p < petals; p++) {
          const ang = (p / petals) * Math.PI * 2 + rand() * 0.5;
          const rx = px + Math.cos(ang) * r * 0.74;
          const ry = py + Math.sin(ang) * r * 0.74;
          ctx.fillStyle = 'rgba(30, 21, 14, 0.88)';
          ctx.beginPath();
          ctx.ellipse(rx, ry, r * 0.42, r * 0.25, ang + Math.PI / 2, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }
  }

  paintFurStrokes(ctx, rand, 1600, 'rgba(242,216,158,0.2)', 'rgba(62,42,18,0.2)', 4, 9);
  return toTexture(canvas, true, 2, 2);
}

function createLionCoatAndManeTextures(): { coat: THREE.CanvasTexture; mane: THREE.CanvasTexture } {
  const rand = mulberry32(303);
  const [canvas, ctx] = makeCanvas(256);
  ctx.fillStyle = '#9b7746';
  ctx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 300; i++) {
    ctx.fillStyle = rand() > 0.5 ? 'rgba(188,158,112,0.16)' : 'rgba(84,56,26,0.2)';
    ctx.beginPath();
    ctx.arc(rand() * 256, rand() * 256, 8 + rand() * 20, 0, Math.PI * 2);
    ctx.fill();
  }
  paintFurStrokes(ctx, rand, 2200, 'rgba(202,174,126,0.22)', 'rgba(66,44,20,0.26)', 5, 11);

  // Shaggy dark-chestnut to umber lion mane strands
  const [mCanvas, mCtx] = makeCanvas(256);
  const mGrad = mCtx.createLinearGradient(0, 0, 0, 256);
  mGrad.addColorStop(0, '#5a3418');
  mGrad.addColorStop(0.5, '#3b2010');
  mGrad.addColorStop(1, '#26140b');
  mCtx.fillStyle = mGrad;
  mCtx.fillRect(0, 0, 256, 256);
  paintFurStrokes(mCtx, rand, 2600, 'rgba(164,104,52,0.28)', 'rgba(18,9,5,0.38)', 10, 22);

  return {
    coat: toTexture(canvas, true, 2, 2),
    mane: toTexture(mCanvas, true, 2, 2),
  };
}

function createGorillaTextures(): { fur: THREE.CanvasTexture; silverback: THREE.CanvasTexture } {
  const rand = mulberry32(404);
  const [canvas, ctx] = makeCanvas(256);
  ctx.fillStyle = '#252325';
  ctx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 220; i++) {
    ctx.fillStyle = rand() > 0.5 ? 'rgba(66,60,58,0.16)' : 'rgba(14,13,15,0.22)';
    ctx.beginPath();
    ctx.arc(rand() * 256, rand() * 256, 7 + rand() * 18, 0, Math.PI * 2);
    ctx.fill();
  }
  paintFurStrokes(ctx, rand, 2400, 'rgba(92,84,80,0.22)', 'rgba(12,11,13,0.34)', 7, 15);

  // Frosted silverback saddle fur
  const [sCanvas, sCtx] = makeCanvas(256);
  const grad = sCtx.createRadialGradient(128, 128, 14, 128, 128, 150);
  grad.addColorStop(0, '#9a9ea4');
  grad.addColorStop(0.6, '#6e7278');
  grad.addColorStop(1, '#313034');
  sCtx.fillStyle = grad;
  sCtx.fillRect(0, 0, 256, 256);
  paintFurStrokes(sCtx, rand, 2400, 'rgba(218,222,228,0.28)', 'rgba(34,34,38,0.3)', 8, 16);

  return {
    fur: toTexture(canvas, true, 2, 2),
    silverback: toTexture(sCanvas, true, 1, 1),
  };
}

function createPythonScaleTexture(): THREE.CanvasTexture {
  const rand = mulberry32(505);
  const [canvas, ctx] = makeCanvas(256);

  // Natural Indian rock python olive-bronze base
  ctx.fillStyle = '#5a5f3b';
  ctx.fillRect(0, 0, 256, 256);

  // Large dark-bordered tan saddle blotches (reticulated python camouflage)
  for (let row = 0; row < 4; row++) {
    const cy = row * 64 + 32;
    const cx = 128 + ((row & 1) === 0 ? -10 : 10);
    // Dark umber rim
    ctx.fillStyle = '#241c13';
    ctx.beginPath();
    ctx.moveTo(cx, cy - 26);
    ctx.lineTo(cx + 58, cy);
    ctx.lineTo(cx, cy + 26);
    ctx.lineTo(cx - 58, cy);
    ctx.closePath();
    ctx.fill();

    // Warm ochre-tan inner diamond
    ctx.fillStyle = '#9b834e';
    ctx.beginPath();
    ctx.moveTo(cx, cy - 18);
    ctx.lineTo(cx + 42, cy);
    ctx.lineTo(cx, cy + 18);
    ctx.lineTo(cx - 42, cy);
    ctx.closePath();
    ctx.fill();

    // Lateral ocelli spots
    for (const sx of [26, 230]) {
      ctx.fillStyle = '#2b2217';
      ctx.beginPath();
      ctx.ellipse(sx, cy, 16, 11, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#b49f66';
      ctx.beginPath();
      ctx.ellipse(sx, cy, 9, 6, 0, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // Overlay crisp hexagonal scale borders + subtle dorsal sheen
  const cols = 16;
  const rows = 20;
  const cellW = 256 / cols;
  const cellH = 256 / rows;
  ctx.lineWidth = 1.1;
  for (let row = -1; row <= rows + 1; row++) {
    const xOff = (row & 1) === 0 ? 0 : cellW * 0.5;
    for (let col = -1; col <= cols + 1; col++) {
      const cx = col * cellW + xOff;
      const cy = row * cellH;
      ctx.strokeStyle = 'rgba(20, 18, 12, 0.36)';
      ctx.beginPath();
      ctx.moveTo(cx, cy - cellH * 0.65);
      ctx.lineTo(cx + cellW * 0.5, cy);
      ctx.lineTo(cx, cy + cellH * 0.65);
      ctx.lineTo(cx - cellW * 0.5, cy);
      ctx.closePath();
      ctx.stroke();

      if (rand() > 0.65) {
        ctx.fillStyle = 'rgba(235, 224, 178, 0.08)';
        ctx.fill();
      }
    }
  }

  return toTexture(canvas, true, 2, 2);
}

function createSpiderCarapaceTexture(): THREE.CanvasTexture {
  const rand = mulberry32(606);
  const [canvas, ctx] = makeCanvas(256);

  // Dark mottled forest-spider chitin (slate-brown & charcoal, natural not flat black)
  ctx.fillStyle = '#241f22';
  ctx.fillRect(0, 0, 256, 256);

  for (let i = 0; i < 360; i++) {
    ctx.fillStyle =
      rand() > 0.55 ? 'rgba(72, 56, 52, 0.24)' : 'rgba(14, 12, 16, 0.28)';
    ctx.beginPath();
    ctx.arc(rand() * 256, rand() * 256, 4 + rand() * 14, 0, Math.PI * 2);
    ctx.fill();
  }

  // Subtle muted burnt-crimson dorsal chevrons (natural venomous warning pattern)
  ctx.fillStyle = 'rgba(146, 36, 36, 0.58)';
  for (let y = 44; y <= 200; y += 52) {
    ctx.beginPath();
    ctx.moveTo(128, y - 14);
    ctx.lineTo(156, y + 8);
    ctx.lineTo(128, y + 2);
    ctx.lineTo(100, y + 8);
    ctx.closePath();
    ctx.fill();
  }

  // Fine sensory arachnid bristles
  paintFurStrokes(ctx, rand, 1400, 'rgba(102, 86, 80, 0.2)', 'rgba(10, 8, 12, 0.3)', 4, 9);
  return toTexture(canvas, true, 1, 1);
}

function createCoarseCoatTexture(
  seed: number,
  baseHex: string,
  mottleLight: string,
  mottleDark: string,
  strokeLight: string,
  strokeDark: string,
  lenMin: number,
  lenMax: number,
): THREE.CanvasTexture {
  const rand = mulberry32(seed);
  const [canvas, ctx] = makeCanvas(256);
  ctx.fillStyle = baseHex;
  ctx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 280; i++) {
    ctx.fillStyle = rand() > 0.5 ? mottleLight : mottleDark;
    ctx.beginPath();
    ctx.arc(rand() * 256, rand() * 256, 7 + rand() * 20, 0, Math.PI * 2);
    ctx.fill();
  }
  paintFurStrokes(ctx, rand, 2200, strokeLight, strokeDark, lenMin, lenMax);
  return toTexture(canvas, true, 2, 2);
}

export function getAnimalTextureSet(species: WildAnimalSpecies): AnimalTextureSet {
  const existing = cachedSpeciesSets.get(species);
  if (existing) return existing;

  const furBump = getSharedFurBumpMap();
  const hideBump = getSharedHideBumpMap();
  let set: AnimalTextureSet;

  switch (species) {
    case 'sundarban_tiger':
      set = { coatMap: createTigerCoatTexture(), bumpMap: furBump };
      break;
    case 'bengal_leopard':
      set = { coatMap: createLeopardCoatTexture(), bumpMap: furBump };
      break;
    case 'lion_king': {
      const { coat, mane } = createLionCoatAndManeTextures();
      set = { coatMap: coat, bumpMap: furBump, accentMap: mane };
      break;
    }
    case 'gorilla_king': {
      const { fur, silverback } = createGorillaTextures();
      set = {
        coatMap: fur,
        bumpMap: furBump,
        accentMap: silverback,
        skinBumpMap: hideBump,
      };
      break;
    }
    case 'ajagar_python':
      set = {
        coatMap: createPythonScaleTexture(),
        bumpMap: getSharedScaleBumpMap(),
      };
      break;
    case 'giant_spider':
      set = {
        coatMap: createSpiderCarapaceTexture(),
        bumpMap: hideBump,
      };
      break;
    case 'bengal_bear':
      set = {
        coatMap: createCoarseCoatTexture(
          707,
          '#271f1a',
          'rgba(66,52,42,0.18)',
          'rgba(16,12,10,0.24)',
          'rgba(88,72,58,0.24)',
          'rgba(12,9,8,0.34)',
          8,
          17,
        ),
        bumpMap: furBump,
      };
      break;
    case 'wild_boar':
      set = {
        coatMap: createCoarseCoatTexture(
          808,
          '#4a3a2f',
          'rgba(104,86,68,0.2)',
          'rgba(32,24,18,0.24)',
          'rgba(122,102,82,0.26)',
          'rgba(24,18,14,0.32)',
          7,
          15,
        ),
        bumpMap: furBump,
        skinBumpMap: hideBump,
      };
      break;
    case 'village_hound':
    default:
      set = {
        coatMap: createCoarseCoatTexture(
          909,
          '#7b5436',
          'rgba(148,112,78,0.18)',
          'rgba(58,36,20,0.22)',
          'rgba(168,136,102,0.22)',
          'rgba(42,26,14,0.28)',
          4,
          10,
        ),
        bumpMap: furBump,
      };
      break;
  }

  cachedSpeciesSets.set(species, set);
  return set;
}
