import * as THREE from 'three';

export interface TextureBundle {
  gamchaMap: THREE.CanvasTexture;
  gamchaGreenMap: THREE.CanvasTexture;
  mudWallMap: THREE.CanvasTexture;
  mudWallBump: THREE.CanvasTexture;
  thatchMap: THREE.CanvasTexture;
  groundMap: THREE.CanvasTexture;
  groundBump: THREE.CanvasTexture;
  palmBarkMap: THREE.CanvasTexture;
  frondMap: THREE.CanvasTexture;
  bridgeSteelMap: THREE.CanvasTexture;
  waterBump: THREE.CanvasTexture;
  contactShadowMap: THREE.CanvasTexture;
  skyMap: THREE.CanvasTexture;
  taxiSignMap: THREE.CanvasTexture;
  licensePlateMap: THREE.CanvasTexture;
  busSideMap: THREE.CanvasTexture;
  busDestinationMap: THREE.CanvasTexture;
  skinBumpMap: THREE.CanvasTexture;
  skinAlbedoMap: THREE.CanvasTexture;
  faceAlbedoMap: THREE.CanvasTexture;
  fabricBumpMap: THREE.CanvasTexture;
  clothAlbedoMap: THREE.CanvasTexture;
  tacticalWeaveMap: THREE.CanvasTexture;
  leatherAlbedoMap: THREE.CanvasTexture;
  stoneAlbedoMap: THREE.CanvasTexture;
  stoneBumpMap: THREE.CanvasTexture;
  weatheredBrickMap: THREE.CanvasTexture;
  barkBumpMap: THREE.CanvasTexture;
  disposeAll: () => void;
}

function makeCanvas(w: number, h: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;
  return [canvas, ctx];
}

function configureTexture(
  canvas: HTMLCanvasElement,
  anisotropy: number,
  isColor: boolean,
  repeatX = 1,
  repeatY = 1,
): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = isColor ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeatX, repeatY);
  tex.anisotropy = anisotropy;
  tex.needsUpdate = true;
  return tex;
}

function createGamchaCanvas(variant: 'red-white' | 'green-white' = 'red-white'): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 256);
  // Sun-washed traditional Bengali handloom cotton gamcha (unbleached khadi cream + earthy natural dyes)
  ctx.fillStyle = '#e5dccb';
  ctx.fillRect(0, 0, 256, 256);

  // Subtle cotton weave base
  ctx.fillStyle = 'rgba(145, 130, 112, 0.28)';
  for (let i = 0; i < 256; i += 4) {
    ctx.fillRect(i, 0, 1, 256);
    ctx.fillRect(0, i, 256, 1);
  }

  const primary = variant === 'red-white' ? '#961e22' : '#1b5731';
  const bright = variant === 'red-white' ? '#ae2c2e' : '#266d3e';
  const deep = variant === 'red-white' ? '#701519' : '#133f23';
  const accent = variant === 'red-white' ? '#2c462b' : '#9c782a';

  // Warp & weft bands
  const bands = [
    { pos: 0, w: 30, color: primary },
    { pos: 40, w: 10, color: bright },
    { pos: 64, w: 34, color: deep },
    { pos: 112, w: 12, color: accent },
    { pos: 132, w: 30, color: primary },
    { pos: 174, w: 10, color: bright },
    { pos: 198, w: 34, color: deep },
  ];

  ctx.globalAlpha = 0.84;
  for (const b of bands) {
    ctx.fillStyle = b.color;
    ctx.fillRect(b.pos, 0, b.w, 256);
  }
  ctx.globalAlpha = 0.74;
  for (const b of bands) {
    ctx.fillStyle = b.color;
    ctx.fillRect(0, b.pos, 256, b.w);
  }
  ctx.globalAlpha = 1;

  // Fine woven crosshatch & subtle field-dust wear
  ctx.fillStyle = 'rgba(240, 232, 215, 0.14)';
  for (let y = 0; y < 256; y += 4) {
    for (let x = (y % 8 === 0 ? 0 : 2); x < 256; x += 4) {
      ctx.fillRect(x, y, 2, 2);
    }
  }
  for (let i = 0; i < 120; i++) {
    ctx.fillStyle = i % 2 === 0 ? 'rgba(65, 52, 38, 0.08)' : 'rgba(235, 224, 204, 0.07)';
    ctx.beginPath();
    ctx.arc(Math.random() * 256, Math.random() * 256, 4 + Math.random() * 14, 0, Math.PI * 2);
    ctx.fill();
  }
  return canvas;
}

function createMudWallCanvas(): { color: HTMLCanvasElement; bump: HTMLCanvasElement } {
  const [canvas, ctx] = makeCanvas(512, 512);
  const [bump, bCtx] = makeCanvas(256, 256);

  // Weathered Bengal sun-dried ochre clay plaster with monsoon dampness along lower wall
  const grad = ctx.createLinearGradient(0, 0, 0, 512);
  grad.addColorStop(0, '#9e8462');
  grad.addColorStop(0.68, '#8a6f4e');
  grad.addColorStop(0.88, '#664e36');
  grad.addColorStop(1, '#4c3826');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 512, 512);

  bCtx.fillStyle = '#808080';
  bCtx.fillRect(0, 0, 256, 256);

  // Hand-plastered mud blotches, rain streaks & lime weathering
  for (let i = 0; i < 1800; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const r = 2 + Math.random() * 16;
    const light = Math.random() > 0.52;
    ctx.fillStyle = light ? 'rgba(186, 162, 128, 0.1)' : 'rgba(54, 38, 24, 0.13)';
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();

    bCtx.fillStyle = light ? 'rgba(225,225,225,0.16)' : 'rgba(35,35,35,0.16)';
    bCtx.beginPath();
    bCtx.arc(x * 0.5, y * 0.5, r * 0.5, 0, Math.PI * 2);
    bCtx.fill();
  }

  // Vertical monsoon water streaks & damp moss patches near eaves and base
  for (let i = 0; i < 48; i++) {
    const x = Math.random() * 512;
    const h = 45 + Math.random() * 140;
    const streak = ctx.createLinearGradient(x, 0, x, h);
    streak.addColorStop(0, 'rgba(38, 36, 26, 0.24)');
    streak.addColorStop(1, 'rgba(38, 36, 26, 0)');
    ctx.fillStyle = streak;
    ctx.fillRect(x, 0, 4 + Math.random() * 10, h);
  }

  // Hairline dry-clay shrinkage cracks
  ctx.strokeStyle = 'rgba(42, 30, 18, 0.34)';
  ctx.lineWidth = 1.1;
  bCtx.strokeStyle = 'rgba(25, 25, 25, 0.45)';
  bCtx.lineWidth = 1;
  for (let i = 0; i < 32; i++) {
    let cx = Math.random() * 512;
    let cy = Math.random() * 400;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    bCtx.beginPath();
    bCtx.moveTo(cx * 0.5, cy * 0.5);
    for (let s = 0; s < 5; s++) {
      cx += (Math.random() - 0.5) * 18;
      cy += 6 + Math.random() * 14;
      ctx.lineTo(cx, cy);
      bCtx.lineTo(cx * 0.5, cy * 0.5);
    }
    ctx.stroke();
    bCtx.stroke();
  }

  // Embedded straw flecks in clay plaster
  ctx.strokeStyle = 'rgba(195, 172, 118, 0.32)';
  ctx.lineWidth = 1.1;
  for (let i = 0; i < 340; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const a = Math.random() * Math.PI;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + Math.cos(a) * 9, y + Math.sin(a) * 9);
    ctx.stroke();
  }

  // Aged Bengal terracotta mud dado + chalk-faded Alpona band
  ctx.fillStyle = '#5c3323';
  ctx.fillRect(0, 412, 512, 100);
  // Mud splash grime along bottom groundline
  const grimeGrad = ctx.createLinearGradient(0, 448, 0, 512);
  grimeGrad.addColorStop(0, 'rgba(30, 22, 15, 0)');
  grimeGrad.addColorStop(1, 'rgba(26, 20, 14, 0.55)');
  ctx.fillStyle = grimeGrad;
  ctx.fillRect(0, 448, 512, 64);

  ctx.strokeStyle = 'rgba(222, 214, 196, 0.52)';
  ctx.lineWidth = 2.6;
  ctx.beginPath();
  ctx.moveTo(0, 412);
  ctx.lineTo(512, 412);
  ctx.stroke();

  ctx.fillStyle = 'rgba(222, 214, 196, 0.48)';
  for (let x = 16; x < 512; x += 32) {
    ctx.beginPath();
    ctx.arc(x, 404, 11, Math.PI, 0);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(x, 396, 2.2, 0, Math.PI * 2);
    ctx.fill();
  }

  return { color: canvas, bump };
}

function createThatchCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 256);
  // Sun-bleached weathered dry paddy-straw thatch (desaturated warm grey-brown)
  ctx.fillStyle = '#68553a';
  ctx.fillRect(0, 0, 256, 256);

  for (let layer = 0; layer < 8; layer++) {
    const yBase = layer * 32;
    ctx.fillStyle = 'rgba(24, 18, 10, 0.36)';
    ctx.fillRect(0, yBase + 27, 256, 5);
    for (let i = 0; i < 290; i++) {
      const x = Math.random() * 256;
      const shade = Math.random();
      ctx.strokeStyle =
        shade > 0.68
          ? '#96805a'
          : shade > 0.32
            ? '#725d3e'
            : '#3f3220';
      ctx.lineWidth = 0.9 + Math.random() * 1.4;
      ctx.beginPath();
      ctx.moveTo(x, yBase + Math.random() * 5);
      ctx.lineTo(x + (Math.random() - 0.5) * 4.5, yBase + 31 + Math.random() * 6);
      ctx.stroke();
    }
  }
  return canvas;
}

function createGroundCanvas(): { color: HTMLCanvasElement; bump: HTMLCanvasElement } {
  const [canvas, ctx] = makeCanvas(512, 512);
  const [bump, bCtx] = makeCanvas(256, 256);

  // Gritty, realistic humid Bengal alluvial soil, dry grass, damp loam & red laterite pebbles
  ctx.fillStyle = '#4c5231';
  ctx.fillRect(0, 0, 512, 512);

  bCtx.fillStyle = '#7e7e7e';
  bCtx.fillRect(0, 0, 256, 256);

  // Broad organic earth/turf moisture patches
  for (let i = 0; i < 720; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const r = 8 + Math.random() * 28;
    const pick = Math.random();
    ctx.fillStyle =
      pick < 0.34
        ? 'rgba(98, 72, 47, 0.34)'
        : pick < 0.66
          ? 'rgba(46, 62, 30, 0.36)'
          : pick < 0.86
            ? 'rgba(116, 88, 56, 0.26)'
            : 'rgba(66, 76, 38, 0.28)';
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();

    bCtx.fillStyle = pick < 0.48 ? 'rgba(220,220,220,0.26)' : 'rgba(38,38,38,0.28)';
    bCtx.beginPath();
    bCtx.arc(x * 0.5, y * 0.5, r * 0.44, 0, Math.PI * 2);
    bCtx.fill();
  }

  // Fine wild grass stalks, dried straw, dark loam pits & gravel pebbles
  for (let i = 0; i < 2800; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const r = Math.random();
    if (r < 0.42) {
      ctx.fillStyle = 'rgba(32, 46, 20, 0.48)';
      ctx.fillRect(x, y, 1.8, 5.2);
    } else if (r < 0.74) {
      ctx.fillStyle = 'rgba(128, 102, 70, 0.38)';
      ctx.fillRect(x, y, 2.2, 2.5);
    } else if (r < 0.9) {
      ctx.fillStyle = 'rgba(94, 102, 54, 0.34)';
      ctx.fillRect(x, y, 1.6, 4.4);
    } else {
      ctx.fillStyle = 'rgba(46, 36, 26, 0.42)';
      ctx.fillRect(x, y, 2.6, 2.6);
    }
    if (i % 2 === 0) {
      bCtx.fillStyle = r < 0.5 ? 'rgba(235,235,235,0.28)' : 'rgba(32,32,32,0.28)';
      bCtx.fillRect(x * 0.5, y * 0.5, 1.6, 2.4);
    }
  }
  return { color: canvas, bump };
}

function createPalmBarkCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(128, 256);
  ctx.fillStyle = '#534538';
  ctx.fillRect(0, 0, 128, 256);

  // Deep weathered growth rings, bark fissures & subtle moss
  for (let y = 0; y < 256; y += 16) {
    ctx.fillStyle = '#332920';
    ctx.fillRect(0, y, 128, 4);
    ctx.fillStyle = '#6b5b4b';
    ctx.fillRect(0, y + 4, 128, 3);
  }
  for (let i = 0; i < 420; i++) {
    const pick = Math.random();
    ctx.fillStyle =
      pick < 0.48
        ? 'rgba(28,22,16,0.32)'
        : pick < 0.84
          ? 'rgba(128,114,98,0.2)'
          : 'rgba(54,72,38,0.2)';
    ctx.fillRect(Math.random() * 128, Math.random() * 256, 3 + Math.random() * 6, 2 + Math.random() * 5);
  }
  return canvas;
}

function createFrondCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 128);
  ctx.clearRect(0, 0, 256, 128);

  // Sun-weathered woody palm stem
  ctx.fillStyle = '#4a5c28';
  ctx.fillRect(0, 60, 256, 8);

  // Natural deep tropical olive-green palm leaflets
  for (let x = 10; x < 246; x += 7) {
    const t = x / 256;
    const len = Math.sin(t * Math.PI) * 56 + 6;
    ctx.fillStyle = x % 14 === 0 ? '#26461f' : '#335927';

    ctx.beginPath();
    ctx.moveTo(x, 62);
    ctx.lineTo(x + 12, 62 - len);
    ctx.lineTo(x + 6, 62);
    ctx.closePath();
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(x, 66);
    ctx.lineTo(x + 12, 66 + len);
    ctx.lineTo(x + 6, 66);
    ctx.closePath();
    ctx.fill();
  }
  return canvas;
}

function createBridgeSteelCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 256);
  // Gritty weathered Howrah Bridge industrial steel with oxidized rust streaks & grime
  ctx.fillStyle = '#5f676d';
  ctx.fillRect(0, 0, 256, 256);

  for (let i = 0; i < 820; i++) {
    const pick = Math.random();
    ctx.fillStyle =
      pick < 0.4
        ? 'rgba(170, 178, 184, 0.08)'
        : pick < 0.78
          ? 'rgba(34, 38, 42, 0.14)'
          : 'rgba(118, 62, 34, 0.14)';
    ctx.fillRect(Math.random() * 256, Math.random() * 256, 6 + Math.random() * 10, 8 + Math.random() * 14);
  }

  // Steel plate seam lines, rivets & dripping iron-oxide rust streaks
  ctx.strokeStyle = 'rgba(28, 32, 36, 0.62)';
  ctx.lineWidth = 2.2;
  for (let y = 0; y < 256; y += 64) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(256, y);
    ctx.stroke();
    for (let x = 12; x < 256; x += 24) {
      // Rust stain bleeding down from rivet
      const rust = ctx.createLinearGradient(x, y + 8, x, y + 28);
      rust.addColorStop(0, 'rgba(116, 54, 24, 0.38)');
      rust.addColorStop(1, 'rgba(116, 54, 24, 0)');
      ctx.fillStyle = rust;
      ctx.fillRect(x - 2, y + 8, 4, 20);

      ctx.fillStyle = 'rgba(195, 202, 208, 0.45)';
      ctx.beginPath();
      ctx.arc(x, y + 8, 2.2, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  return canvas;
}

function createWaterBumpCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 256);
  ctx.fillStyle = '#808080';
  ctx.fillRect(0, 0, 256, 256);

  for (let y = 0; y < 256; y += 8) {
    for (let x = 0; x < 256; x += 16) {
      const grad = ctx.createRadialGradient(x + 8, y + 4, 1, x + 8, y + 4, 14);
      grad.addColorStop(0, 'rgba(235,235,235,0.44)');
      grad.addColorStop(1, 'rgba(65,65,65,0)');
      ctx.fillStyle = grad;
      ctx.fillRect(x - 6, y - 4, 28, 16);
    }
  }
  return canvas;
}

function createContactShadowCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(128, 128);
  const grad = ctx.createRadialGradient(64, 64, 6, 64, 64, 60);
  grad.addColorStop(0, 'rgba(12, 10, 8, 0.78)');
  grad.addColorStop(0.55, 'rgba(14, 11, 8, 0.34)');
  grad.addColorStop(1, 'rgba(14, 11, 8, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 128, 128);
  return canvas;
}

function createSkyCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(512, 256);
  // Grounded humid late-afternoon Bengal sky: muted slate-blue zenith melting into dusty warm horizon haze
  const grad = ctx.createLinearGradient(0, 0, 0, 256);
  grad.addColorStop(0.0, '#3a5168');
  grad.addColorStop(0.24, '#597187');
  grad.addColorStop(0.5, '#8397a6');
  grad.addColorStop(0.72, '#adb6ba');
  grad.addColorStop(0.88, '#cbc4b6');
  grad.addColorStop(1.0, '#b5bcb9');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 512, 256);

  // Layered realistic monsoon-season stratus & cumulus clouds with shaded undersides
  for (let i = 0; i < 34; i++) {
    const cx = Math.random() * 512;
    const cy = 54 + Math.random() * 102;
    const rx = 32 + Math.random() * 78;
    const ry = 7 + Math.random() * 15;

    // Darker shaded cloud belly
    const belly = ctx.createRadialGradient(cx, cy + ry * 0.25, 2, cx, cy + ry * 0.25, rx);
    belly.addColorStop(0, 'rgba(84, 92, 100, 0.34)');
    belly.addColorStop(0.65, 'rgba(98, 106, 112, 0.14)');
    belly.addColorStop(1, 'rgba(98, 106, 112, 0)');
    ctx.save();
    ctx.translate(cx, cy + 3);
    ctx.scale(1, ry / rx);
    ctx.fillStyle = belly;
    ctx.beginPath();
    ctx.arc(0, 0, rx, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Warm sunlit upper cloud edge
    const top = ctx.createRadialGradient(cx, cy - ry * 0.18, 2, cx, cy - ry * 0.18, rx * 0.92);
    top.addColorStop(0, 'rgba(235, 228, 214, 0.42)');
    top.addColorStop(0.55, 'rgba(218, 214, 206, 0.18)');
    top.addColorStop(1, 'rgba(210, 210, 204, 0)');
    ctx.save();
    ctx.translate(cx, cy - 2);
    ctx.scale(1, (ry * 0.85) / rx);
    ctx.fillStyle = top;
    ctx.beginPath();
    ctx.arc(0, 0, rx * 0.92, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // Diffused late-afternoon sun glare through humid river-basin haze
  const sunGrad = ctx.createRadialGradient(342, 126, 5, 342, 126, 98);
  sunGrad.addColorStop(0, 'rgba(255, 245, 218, 0.96)');
  sunGrad.addColorStop(0.22, 'rgba(244, 216, 168, 0.48)');
  sunGrad.addColorStop(0.58, 'rgba(222, 192, 148, 0.16)');
  sunGrad.addColorStop(1, 'rgba(216, 190, 152, 0)');
  ctx.fillStyle = sunGrad;
  ctx.fillRect(236, 24, 212, 204);

  return canvas;
}

function createTaxiSignCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 96);
  ctx.fillStyle = '#f6c216';
  ctx.fillRect(0, 0, 256, 96);
  ctx.strokeStyle = '#141414';
  ctx.lineWidth = 8;
  ctx.strokeRect(6, 6, 244, 84);
  ctx.fillStyle = '#141414';
  ctx.font = 'bold 52px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('TAXI', 128, 52);
  return canvas;
}

function createLicensePlateCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 64);
  ctx.fillStyle = '#f5c418';
  ctx.fillRect(0, 0, 256, 64);
  ctx.strokeStyle = '#151515';
  ctx.lineWidth = 5;
  ctx.strokeRect(4, 4, 248, 56);
  ctx.fillStyle = '#111111';
  ctx.font = 'bold 34px monospace';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('WB 04 7182', 128, 34);
  return canvas;
}

function createBusSideCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(512, 160);
  // Iconic Kolkata WBTC Blue-and-White lower hull + Yellow-Red accent stripe
  ctx.fillStyle = '#f4f6f8';
  ctx.fillRect(0, 0, 512, 48);

  // Bold golden-yellow & crimson waist stripe
  ctx.fillStyle = '#f4be1c';
  ctx.fillRect(0, 48, 512, 20);
  ctx.fillStyle = '#cc2229';
  ctx.fillRect(0, 68, 512, 12);

  // Classic West Bengal government royal/sky blue lower body
  const blueGrad = ctx.createLinearGradient(0, 80, 0, 160);
  blueGrad.addColorStop(0, '#1466b8');
  blueGrad.addColorStop(1, '#0c478a');
  ctx.fillStyle = blueGrad;
  ctx.fillRect(0, 80, 512, 80);

  // Panel rivets & wheel arch subtle trim lines
  ctx.strokeStyle = 'rgba(255,255,255,0.22)';
  ctx.lineWidth = 2;
  for (let x = 64; x < 512; x += 64) {
    ctx.beginPath();
    ctx.moveTo(x, 82);
    ctx.lineTo(x, 158);
    ctx.stroke();
  }

  // WBTC Bengali + English Branding
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 34px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('WBTC  •  কলকাতা', 256, 118);

  ctx.fillStyle = '#ffe17a';
  ctx.font = 'bold 16px sans-serif';
  ctx.fillText('পশ্চিমবঙ্গ পরিবহন নিগম  |  HOWRAH - VILLAGE', 256, 146);

  return canvas;
}

function createBusDestinationCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 64);
  ctx.fillStyle = '#121820';
  ctx.fillRect(0, 0, 256, 64);
  ctx.strokeStyle = '#f4be1c';
  ctx.lineWidth = 4;
  ctx.strokeRect(3, 3, 250, 58);

  ctx.fillStyle = '#ffd54a';
  ctx.font = 'bold 26px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('S-12  হাওড়া ↔ গ্রাম', 128, 34);
  return canvas;
}

function createSkinBumpCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 256);
  ctx.fillStyle = '#808080';
  ctx.fillRect(0, 0, 256, 256);

  // Fine organic skin pore & micro-relief grain
  for (let i = 0; i < 3200; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    const r = 0.6 + Math.random() * 1.4;
    const isPore = Math.random() < 0.55;
    ctx.fillStyle = isPore ? 'rgba(42, 42, 42, 0.24)' : 'rgba(218, 218, 218, 0.16)';
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // Subtle fine dermal tension micro-lines
  ctx.strokeStyle = 'rgba(110, 110, 110, 0.18)';
  ctx.lineWidth = 0.7;
  for (let i = 0; i < 180; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    const len = 4 + Math.random() * 10;
    const a = (Math.random() - 0.5) * 0.5;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + Math.cos(a) * len, y + Math.sin(a) * len);
    ctx.stroke();
  }
  return canvas;
}

function createSkinAlbedoCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 256);
  // Warm neutral ivory multiplied by each character's natural Bengali skin hex
  ctx.fillStyle = '#f8f0e8';
  ctx.fillRect(0, 0, 256, 256);

  // Subtle organic epidermal melanin & warm capillary blood-flow mottling
  for (let i = 0; i < 650; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    const r = 4 + Math.random() * 18;
    const roll = Math.random();
    const grad = ctx.createRadialGradient(x, y, 0.5, x, y, r);
    if (roll < 0.36) {
      grad.addColorStop(0, 'rgba(222, 168, 152, 0.085)');
      grad.addColorStop(1, 'rgba(222, 168, 152, 0)');
    } else if (roll < 0.72) {
      grad.addColorStop(0, 'rgba(218, 192, 158, 0.075)');
      grad.addColorStop(1, 'rgba(218, 192, 158, 0)');
    } else {
      grad.addColorStop(0, 'rgba(255, 248, 240, 0.07)');
      grad.addColorStop(1, 'rgba(255, 248, 240, 0)');
    }
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  for (let i = 0; i < 900; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    ctx.fillStyle = Math.random() > 0.5 ? 'rgba(155, 118, 92, 0.055)' : 'rgba(255, 245, 236, 0.05)';
    ctx.fillRect(x, y, 1.5, 1.5);
  }
  return canvas;
}

function createFaceAlbedoCanvas(): HTMLCanvasElement {
  // Mapped to SphereGeometry UVs where +Z (front of face) is at u = 0.25 (cx = 128 on 512px)
  const [canvas, ctx] = makeCanvas(512, 256);
  ctx.fillStyle = '#f8f0e8';
  ctx.fillRect(0, 0, 512, 256);

  for (let i = 0; i < 480; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 256;
    const r = 6 + Math.random() * 22;
    const grad = ctx.createRadialGradient(x, y, 1, x, y, r);
    grad.addColorStop(0, Math.random() > 0.5 ? 'rgba(218, 174, 154, 0.06)' : 'rgba(252, 244, 235, 0.05)');
    grad.addColorStop(1, 'rgba(218, 174, 154, 0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  const cx = 128;
  const cy = 128;

  // Warm sun-kissed forehead & nose bridge glow
  const foreheadGrad = ctx.createRadialGradient(cx, cy - 36, 4, cx, cy - 32, 54);
  foreheadGrad.addColorStop(0, 'rgba(255, 244, 230, 0.18)');
  foreheadGrad.addColorStop(1, 'rgba(255, 244, 230, 0)');
  ctx.fillStyle = foreheadGrad;
  ctx.beginPath();
  ctx.arc(cx, cy - 32, 54, 0, Math.PI * 2);
  ctx.fill();

  // Natural warm blush on cheekbones + nose-tip warmth
  for (const sx of [-24, 24]) {
    const cheekGrad = ctx.createRadialGradient(cx + sx, cy + 12, 2, cx + sx, cy + 12, 24);
    cheekGrad.addColorStop(0, 'rgba(214, 134, 118, 0.16)');
    cheekGrad.addColorStop(1, 'rgba(214, 134, 118, 0)');
    ctx.fillStyle = cheekGrad;
    ctx.beginPath();
    ctx.arc(cx + sx, cy + 12, 24, 0, Math.PI * 2);
    ctx.fill();
  }
  const noseWarm = ctx.createRadialGradient(cx, cy + 14, 2, cx, cy + 14, 15);
  noseWarm.addColorStop(0, 'rgba(218, 144, 126, 0.14)');
  noseWarm.addColorStop(1, 'rgba(218, 144, 126, 0)');
  ctx.fillStyle = noseWarm;
  ctx.beginPath();
  ctx.arc(cx, cy + 14, 15, 0, Math.PI * 2);
  ctx.fill();

  // Soft anatomical orbital & under-eye shading
  for (const sx of [-19, 19]) {
    const orbitGrad = ctx.createRadialGradient(cx + sx, cy - 5, 2, cx + sx, cy - 5, 16);
    orbitGrad.addColorStop(0, 'rgba(138, 98, 82, 0.22)');
    orbitGrad.addColorStop(1, 'rgba(138, 98, 82, 0)');
    ctx.fillStyle = orbitGrad;
    ctx.beginPath();
    ctx.arc(cx + sx, cy - 5, 16, 0, Math.PI * 2);
    ctx.fill();
  }

  // Subtle lower-jaw & under-chin warmth for sculpted facial depth
  const jawGrad = ctx.createLinearGradient(0, cy + 44, 0, cy + 96);
  jawGrad.addColorStop(0, 'rgba(132, 102, 86, 0)');
  jawGrad.addColorStop(0.65, 'rgba(122, 92, 76, 0.16)');
  jawGrad.addColorStop(1, 'rgba(105, 76, 62, 0.24)');
  ctx.fillStyle = jawGrad;
  ctx.fillRect(cx - 72, cy + 44, 144, 58);

  return canvas;
}

function createFabricBumpCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 256);
  ctx.fillStyle = '#7e7e7e';
  ctx.fillRect(0, 0, 256, 256);

  // Fine woven cotton / tactical ripstop cross-threads
  for (let y = 0; y < 256; y += 3) {
    ctx.fillStyle = y % 6 === 0 ? 'rgba(215, 215, 215, 0.22)' : 'rgba(55, 55, 55, 0.2)';
    ctx.fillRect(0, y, 256, 1.5);
  }
  for (let x = 0; x < 256; x += 3) {
    ctx.fillStyle = x % 6 === 0 ? 'rgba(220, 220, 220, 0.2)' : 'rgba(50, 50, 50, 0.18)';
    ctx.fillRect(x, 0, 1.5, 256);
  }

  // Subtle tactical ripstop reinforcement grid every 16px
  ctx.strokeStyle = 'rgba(235, 235, 235, 0.24)';
  ctx.lineWidth = 1;
  for (let i = 0; i < 256; i += 16) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, 256);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, i);
    ctx.lineTo(256, i);
    ctx.stroke();
  }
  return canvas;
}

function createClothAlbedoCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 256);
  // Neutral bright-ivory handloom khadi cotton slub weave (multiplies cleanly with any outfit color)
  ctx.fillStyle = '#f5f3ef';
  ctx.fillRect(0, 0, 256, 256);

  // Subtle organic woven thread slubs & warm natural cotton depth
  for (let y = 0; y < 256; y += 2) {
    ctx.fillStyle = y % 4 === 0 ? 'rgba(255,255,255,0.24)' : 'rgba(195,188,178,0.16)';
    ctx.fillRect(0, y, 256, 1);
  }
  for (let x = 0; x < 256; x += 2) {
    ctx.fillStyle = x % 4 === 0 ? 'rgba(255,255,255,0.2)' : 'rgba(188,180,170,0.14)';
    ctx.fillRect(x, 0, 1, 256);
  }
  for (let i = 0; i < 320; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    const w = 8 + Math.random() * 26;
    ctx.fillStyle = Math.random() > 0.5 ? 'rgba(255,255,255,0.14)' : 'rgba(165,156,144,0.11)';
    ctx.fillRect(x, y, w, 1.5);
  }
  // Subtle natural fabric fold shading
  for (let i = 0; i < 24; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    const r = 14 + Math.random() * 28;
    const grad = ctx.createRadialGradient(x, y, 1, x, y, r);
    grad.addColorStop(0, Math.random() > 0.5 ? 'rgba(155,146,136,0.09)' : 'rgba(255,255,255,0.08)');
    grad.addColorStop(1, 'rgba(155,146,136,0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
  return canvas;
}

function createTacticalWeaveCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 256);
  // Neutral Cordura ripstop weave (multiplies cleanly with tactical pants & plate carrier colors)
  ctx.fillStyle = '#e8e8e6';
  ctx.fillRect(0, 0, 256, 256);

  for (let y = 0; y < 256; y += 3) {
    ctx.fillStyle = y % 6 === 0 ? 'rgba(255,255,255,0.18)' : 'rgba(145,145,140,0.18)';
    ctx.fillRect(0, y, 256, 1.4);
  }
  for (let x = 0; x < 256; x += 3) {
    ctx.fillStyle = x % 6 === 0 ? 'rgba(255,255,255,0.16)' : 'rgba(140,140,136,0.16)';
    ctx.fillRect(x, 0, 1.4, 256);
  }

  // Ripstop grid reinforcement threads
  ctx.strokeStyle = 'rgba(255,255,255,0.22)';
  ctx.lineWidth = 1;
  for (let i = 0; i < 256; i += 16) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, 256);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, i);
    ctx.lineTo(256, i);
    ctx.stroke();
  }

  // Subtle field dust & edge-wear mottling
  for (let i = 0; i < 180; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    ctx.fillStyle = Math.random() > 0.5 ? 'rgba(120,116,110,0.09)' : 'rgba(255,255,255,0.07)';
    ctx.beginPath();
    ctx.arc(x, y, 5 + Math.random() * 14, 0, Math.PI * 2);
    ctx.fill();
  }
  return canvas;
}

function createLeatherAlbedoCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(128, 128);
  ctx.fillStyle = '#ddd6ce';
  ctx.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 420; i++) {
    const x = Math.random() * 128;
    const y = Math.random() * 128;
    ctx.fillStyle = Math.random() > 0.45 ? 'rgba(120,104,90,0.18)' : 'rgba(255,248,238,0.14)';
    ctx.beginPath();
    ctx.arc(x, y, 1.2 + Math.random() * 3.8, 0, Math.PI * 2);
    ctx.fill();
  }
  // Fine leather scuff marks
  ctx.strokeStyle = 'rgba(255,245,232,0.16)';
  ctx.lineWidth = 0.8;
  for (let i = 0; i < 45; i++) {
    const x = Math.random() * 128;
    const y = Math.random() * 128;
    const a = Math.random() * Math.PI;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + Math.cos(a) * 11, y + Math.sin(a) * 11);
    ctx.stroke();
  }
  return canvas;
}

function createStoneCanvases(): { color: HTMLCanvasElement; bump: HTMLCanvasElement } {
  const [canvas, ctx] = makeCanvas(256, 256);
  const [bump, bCtx] = makeCanvas(256, 256);

  // Neutral weathered granite / laterite stone base (tints cleanly with any material color)
  ctx.fillStyle = '#c4beb4';
  ctx.fillRect(0, 0, 256, 256);
  bCtx.fillStyle = '#808080';
  bCtx.fillRect(0, 0, 256, 256);

  // Mineral strata & rock grain mottling
  for (let i = 0; i < 620; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    const rx = 4 + Math.random() * 18;
    const ry = 2 + Math.random() * 10;
    const light = Math.random() > 0.52;
    ctx.fillStyle = light ? 'rgba(232, 226, 214, 0.14)' : 'rgba(64, 58, 52, 0.16)';
    ctx.beginPath();
    ctx.ellipse(x, y, rx, ry, (Math.random() - 0.5) * 0.4, 0, Math.PI * 2);
    ctx.fill();

    bCtx.fillStyle = light ? 'rgba(225,225,225,0.22)' : 'rgba(32,32,32,0.24)';
    bCtx.beginPath();
    bCtx.ellipse(x, y, rx * 0.85, ry * 0.85, 0, 0, Math.PI * 2);
    bCtx.fill();
  }

  // Deep rock fractures & chiselled stone seams
  ctx.strokeStyle = 'rgba(38, 34, 30, 0.36)';
  ctx.lineWidth = 1.4;
  bCtx.strokeStyle = 'rgba(18, 18, 18, 0.65)';
  bCtx.lineWidth = 1.6;
  for (let i = 0; i < 24; i++) {
    let cx = Math.random() * 256;
    let cy = Math.random() * 256;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    bCtx.beginPath();
    bCtx.moveTo(cx, cy);
    for (let s = 0; s < 5; s++) {
      cx += (Math.random() - 0.5) * 26;
      cy += (Math.random() - 0.3) * 18;
      ctx.lineTo(cx, cy);
      bCtx.lineTo(cx, cy);
    }
    ctx.stroke();
    bCtx.stroke();
  }

  // Subtle damp lichen & fine mineral grit
  for (let i = 0; i < 900; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    const r = Math.random();
    ctx.fillStyle =
      r < 0.45
        ? 'rgba(42, 38, 34, 0.24)'
        : r < 0.82
          ? 'rgba(235, 230, 222, 0.18)'
          : 'rgba(78, 92, 58, 0.2)';
    ctx.fillRect(x, y, 2, 2);
  }
  return { color: canvas, bump };
}

function createWeatheredBrickCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 256);
  // Aged crumbly lime mortar background
  ctx.fillStyle = '#8b8173';
  ctx.fillRect(0, 0, 256, 256);

  const rows = 8;
  const cols = 4;
  const rowH = 256 / rows;
  const colW = 256 / cols;

  for (let r = 0; r < rows; r++) {
    const offset = (r % 2) * (colW * 0.5);
    for (let c = -1; c <= cols; c++) {
      const bx = c * colW + offset + 2;
      const by = r * rowH + 2;
      const bw = colW - 4;
      const bh = rowH - 4;
      const shade = Math.random();
      ctx.fillStyle =
        shade < 0.34
          ? '#7f422f'
          : shade < 0.68
            ? '#8c4c36'
            : shade < 0.88
              ? '#6e3727'
              : '#9a5940';
      ctx.fillRect(bx, by, bw, bh);

      // Subtle brick surface soot & weathering
      ctx.fillStyle = Math.random() > 0.5 ? 'rgba(30, 22, 18, 0.2)' : 'rgba(210, 185, 160, 0.12)';
      ctx.fillRect(bx + 2, by + 2, bw - 4, bh * 0.45);
    }
  }

  // Damp moss & monsoon soot streaks over brickwork
  for (let i = 0; i < 420; i++) {
    const pick = Math.random();
    ctx.fillStyle =
      pick < 0.5
        ? 'rgba(34, 28, 22, 0.18)'
        : pick < 0.8
          ? 'rgba(66, 78, 44, 0.16)'
          : 'rgba(195, 185, 168, 0.14)';
    ctx.beginPath();
    ctx.arc(Math.random() * 256, Math.random() * 256, 2 + Math.random() * 9, 0, Math.PI * 2);
    ctx.fill();
  }
  return canvas;
}

function createBarkBumpCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(128, 256);
  ctx.fillStyle = '#7e7e7e';
  ctx.fillRect(0, 0, 128, 256);
  for (let i = 0; i < 360; i++) {
    const x = Math.random() * 128;
    const y = Math.random() * 256;
    ctx.fillStyle = Math.random() > 0.5 ? 'rgba(230,230,230,0.34)' : 'rgba(26,26,26,0.38)';
    ctx.fillRect(x, y, 2 + Math.random() * 4, 10 + Math.random() * 24);
  }
  return canvas;
}

export function createTextureBundle(renderer: THREE.WebGLRenderer): TextureBundle {
  const maxAniso = Math.min(renderer.capabilities.getMaxAnisotropy(), 8);

  const gamchaMap = configureTexture(createGamchaCanvas('red-white'), maxAniso, true, 2, 2);
  const gamchaGreenMap = configureTexture(createGamchaCanvas('green-white'), maxAniso, true, 2, 2);
  const mud = createMudWallCanvas();
  const mudWallMap = configureTexture(mud.color, maxAniso, true, 2, 1);
  const mudWallBump = configureTexture(mud.bump, maxAniso, false, 2, 1);
  const thatchMap = configureTexture(createThatchCanvas(), maxAniso, true, 3, 2);
  const ground = createGroundCanvas();
  const groundMap = configureTexture(ground.color, maxAniso, true, 16, 16);
  const groundBump = configureTexture(ground.bump, maxAniso, false, 16, 16);
  const palmBarkMap = configureTexture(createPalmBarkCanvas(), maxAniso, true, 1, 5);
  const frondMap = configureTexture(createFrondCanvas(), maxAniso, true, 1, 1);
  frondMap.wrapS = THREE.ClampToEdgeWrapping;
  frondMap.wrapT = THREE.ClampToEdgeWrapping;
  const bridgeSteelMap = configureTexture(createBridgeSteelCanvas(), maxAniso, true, 2, 4);
  const waterBump = configureTexture(createWaterBumpCanvas(), maxAniso, false, 14, 14);
  const contactShadowMap = configureTexture(createContactShadowCanvas(), maxAniso, true, 1, 1);
  contactShadowMap.wrapS = THREE.ClampToEdgeWrapping;
  contactShadowMap.wrapT = THREE.ClampToEdgeWrapping;
  const skyMap = configureTexture(createSkyCanvas(), maxAniso, true, 1, 1);
  skyMap.wrapS = THREE.ClampToEdgeWrapping;
  skyMap.wrapT = THREE.ClampToEdgeWrapping;
  const taxiSignMap = configureTexture(createTaxiSignCanvas(), maxAniso, true, 1, 1);
  const licensePlateMap = configureTexture(createLicensePlateCanvas(), maxAniso, true, 1, 1);
  const busSideMap = configureTexture(createBusSideCanvas(), maxAniso, true, 1, 1);
  const busDestinationMap = configureTexture(createBusDestinationCanvas(), maxAniso, true, 1, 1);
  const skinBumpMap = configureTexture(createSkinBumpCanvas(), maxAniso, false, 3, 3);
  const skinAlbedoMap = configureTexture(createSkinAlbedoCanvas(), maxAniso, true, 2, 2);
  const faceAlbedoMap = configureTexture(createFaceAlbedoCanvas(), maxAniso, true, 1, 1);
  faceAlbedoMap.wrapS = THREE.RepeatWrapping;
  faceAlbedoMap.wrapT = THREE.ClampToEdgeWrapping;
  const fabricBumpMap = configureTexture(createFabricBumpCanvas(), maxAniso, false, 4, 4);
  const clothAlbedoMap = configureTexture(createClothAlbedoCanvas(), maxAniso, true, 3, 3);
  const tacticalWeaveMap = configureTexture(createTacticalWeaveCanvas(), maxAniso, true, 4, 4);
  const leatherAlbedoMap = configureTexture(createLeatherAlbedoCanvas(), maxAniso, true, 2, 2);
  const stone = createStoneCanvases();
  const stoneAlbedoMap = configureTexture(stone.color, maxAniso, true, 2, 2);
  const stoneBumpMap = configureTexture(stone.bump, maxAniso, false, 2, 2);
  const weatheredBrickMap = configureTexture(createWeatheredBrickCanvas(), maxAniso, true, 2, 1);
  const barkBumpMap = configureTexture(createBarkBumpCanvas(), maxAniso, false, 1, 4);

  const all = [
    gamchaMap,
    gamchaGreenMap,
    mudWallMap,
    mudWallBump,
    thatchMap,
    groundMap,
    groundBump,
    palmBarkMap,
    frondMap,
    bridgeSteelMap,
    waterBump,
    contactShadowMap,
    skyMap,
    taxiSignMap,
    licensePlateMap,
    busSideMap,
    busDestinationMap,
    skinBumpMap,
    skinAlbedoMap,
    faceAlbedoMap,
    fabricBumpMap,
    clothAlbedoMap,
    tacticalWeaveMap,
    leatherAlbedoMap,
    stoneAlbedoMap,
    stoneBumpMap,
    weatheredBrickMap,
    barkBumpMap,
  ];

  return {
    gamchaMap,
    gamchaGreenMap,
    mudWallMap,
    mudWallBump,
    thatchMap,
    groundMap,
    groundBump,
    palmBarkMap,
    frondMap,
    bridgeSteelMap,
    waterBump,
    contactShadowMap,
    skyMap,
    taxiSignMap,
    licensePlateMap,
    busSideMap,
    busDestinationMap,
    skinBumpMap,
    skinAlbedoMap,
    faceAlbedoMap,
    fabricBumpMap,
    clothAlbedoMap,
    tacticalWeaveMap,
    leatherAlbedoMap,
    stoneAlbedoMap,
    stoneBumpMap,
    weatheredBrickMap,
    barkBumpMap,
    disposeAll: () => {
      all.forEach((t) => t.dispose());
    },
  };
}
