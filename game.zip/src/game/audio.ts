// Procedural Web Audio API synthesizer for West Bengal survival shooter.
// Zero external audio files — all shots, reloads, impacts, pickups, and ambience are synthesized.

export class GameAudio {
  private ctx: AudioContext | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private masterGain: GainNode | null = null;
  private muted = false;
  private sfxVolume = 0.8;
  private ambienceGain: GainNode | null = null;
  private ambienceStarted = false;

  private getEffectiveGain(): number {
    return this.muted ? 0 : 0.72 * this.sfxVolume;
  }

  public unlock(): void {
    try {
      if (!this.ctx) {
        const AudioCtx =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (!AudioCtx) return;
        this.ctx = new AudioCtx();
        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.value = this.getEffectiveGain();
        this.masterGain.connect(this.ctx.destination);
        this.noiseBuffer = this.createNoiseBuffer(this.ctx, 1.5);
      }
      if (this.ctx && this.ctx.state === 'suspended') {
        void this.ctx.resume().catch(() => {
          // Ignore browser autoplay policy rejection until user gesture
        });
      }
      this.startRiverAmbience();
    } catch {
      // Ignore Web Audio restriction errors in restricted iframes
    }
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public setSfxVolume(volume01: number): void {
    this.sfxVolume = Math.max(0, Math.min(1, Number.isFinite(volume01) ? volume01 : 0.8));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(this.getEffectiveGain(), this.ctx.currentTime, 0.03);
    }
  }

  public getSfxVolume(): number {
    return this.sfxVolume;
  }

  public setMuted(mute: boolean): void {
    this.muted = mute;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(this.getEffectiveGain(), this.ctx.currentTime, 0.03);
    }
  }

  public toggleMute(): boolean {
    this.setMuted(!this.muted);
    return this.muted;
  }

  private createNoiseBuffer(ctx: AudioContext, durationSec: number): AudioBuffer {
    const length = Math.floor(ctx.sampleRate * durationSec);
    const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < length; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    return buffer;
  }

  private startRiverAmbience(): void {
    if (this.ambienceStarted || !this.ctx || !this.masterGain || !this.noiseBuffer) return;
    this.ambienceStarted = true;

    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    src.loop = true;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = 340;
    filter.Q.value = 1.2;

    const lfo = this.ctx.createOscillator();
    lfo.frequency.value = 0.16;
    const lfoGain = this.ctx.createGain();
    lfoGain.gain.value = 110;
    lfo.connect(lfoGain);
    lfoGain.connect(filter.frequency);
    lfo.start();

    const gain = this.ctx.createGain();
    gain.gain.value = 0.045;
    this.ambienceGain = gain;

    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);
    src.start();
  }

  public playPlayerShot(): void {
    if (!this.ctx || !this.masterGain || !this.noiseBuffer || this.muted) return;
    const now = this.ctx.currentTime;

    // Sharp punchy transient noise
    const noise = this.ctx.createBufferSource();
    noise.buffer = this.noiseBuffer;
    const bp = this.ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(1450 + Math.random() * 240, now);
    bp.frequency.exponentialRampToValueAtTime(260, now + 0.12);
    bp.Q.value = 0.85;

    const nGain = this.ctx.createGain();
    nGain.gain.setValueAtTime(0.45, now);
    nGain.gain.exponentialRampToValueAtTime(0.001, now + 0.14);

    noise.connect(bp);
    bp.connect(nGain);
    nGain.connect(this.masterGain);
    noise.start(now);
    noise.stop(now + 0.15);

    // Low mechanical thump
    const osc = this.ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(170, now);
    osc.frequency.exponentialRampToValueAtTime(42, now + 0.09);

    const oGain = this.ctx.createGain();
    oGain.gain.setValueAtTime(0.38, now);
    oGain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);

    osc.connect(oGain);
    oGain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.11);
  }

  public playEnemyShot(distance: number): void {
    if (!this.ctx || !this.masterGain || !this.noiseBuffer || this.muted) return;
    const atten = Math.max(0.08, Math.min(0.65, 1 - distance / 52));
    const now = this.ctx.currentTime;

    const noise = this.ctx.createBufferSource();
    noise.buffer = this.noiseBuffer;
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(950, now);
    filter.frequency.exponentialRampToValueAtTime(220, now + 0.11);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.24 * atten, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);
    noise.start(now);
    noise.stop(now + 0.13);
  }

  public playDryFire(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'square';
    osc.frequency.setValueAtTime(640, now);
    osc.frequency.exponentialRampToValueAtTime(180, now + 0.035);
    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.12, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.045);
  }

  public playReload(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const clicks = [0, 0.28, 0.56];
    const freqs = [420, 560, 740];
    clicks.forEach((offset, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freqs[idx], now + offset);
      osc.frequency.exponentialRampToValueAtTime(freqs[idx] * 0.55, now + offset + 0.055);
      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.15, now + offset);
      gain.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.06);
      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(now + offset);
      osc.stop(now + offset + 0.065);
    });
  }

  public playEnemyHit(isKill: boolean): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;

    // 1. Crisp PUBG/Free Fire tactical hit-tick transient (bandpassed noise burst)
    if (this.noiseBuffer) {
      const noise = this.ctx.createBufferSource();
      noise.buffer = this.noiseBuffer;
      const bp = this.ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.setValueAtTime(isKill ? 2400 : 1950, now);
      bp.frequency.exponentialRampToValueAtTime(680, now + 0.045);
      bp.Q.value = 1.8;

      const nGain = this.ctx.createGain();
      nGain.gain.setValueAtTime(isKill ? 0.34 : 0.24, now);
      nGain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

      noise.connect(bp);
      bp.connect(nGain);
      nGain.connect(this.masterGain);
      noise.start(now);
      noise.stop(now + 0.055);
    }

    // 2. Punchy impact body thump / crisp kill confirmation chime
    const osc = this.ctx.createOscillator();
    osc.type = isKill ? 'triangle' : 'triangle';
    osc.frequency.setValueAtTime(isKill ? 560 : 390, now);
    osc.frequency.exponentialRampToValueAtTime(isKill ? 980 : 155, now + (isKill ? 0.13 : 0.055));

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(isKill ? 0.28 : 0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + (isKill ? 0.16 : 0.065));

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + (isKill ? 0.17 : 0.07));

    if (isKill) {
      // Crisp high confirmation harmonic for elimination
      const confirmOsc = this.ctx.createOscillator();
      confirmOsc.type = 'sine';
      confirmOsc.frequency.setValueAtTime(1180, now + 0.045);
      confirmOsc.frequency.exponentialRampToValueAtTime(1560, now + 0.16);
      const cGain = this.ctx.createGain();
      cGain.gain.setValueAtTime(0.001, now + 0.045);
      cGain.gain.linearRampToValueAtTime(0.18, now + 0.06);
      cGain.gain.exponentialRampToValueAtTime(0.001, now + 0.21);
      confirmOsc.connect(cGain);
      cGain.connect(this.masterGain);
      confirmOsc.start(now + 0.045);
      confirmOsc.stop(now + 0.22);
    }
  }

  public playPlayerHurt(armorAbsorbed = false): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;

    // Impact slap transient so incoming bullets register immediately
    if (this.noiseBuffer) {
      const noise = this.ctx.createBufferSource();
      noise.buffer = this.noiseBuffer;
      const bp = this.ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.setValueAtTime(armorAbsorbed ? 1650 : 720, now);
      bp.frequency.exponentialRampToValueAtTime(220, now + 0.09);
      bp.Q.value = armorAbsorbed ? 2.4 : 1.1;

      const nGain = this.ctx.createGain();
      nGain.gain.setValueAtTime(armorAbsorbed ? 0.3 : 0.34, now);
      nGain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);

      noise.connect(bp);
      bp.connect(nGain);
      nGain.connect(this.masterGain);
      noise.start(now);
      noise.stop(now + 0.11);
    }

    const osc = this.ctx.createOscillator();
    osc.type = armorAbsorbed ? 'triangle' : 'sawtooth';
    osc.frequency.setValueAtTime(armorAbsorbed ? 240 : 155, now);
    osc.frequency.exponentialRampToValueAtTime(armorAbsorbed ? 78 : 48, now + 0.15);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = armorAbsorbed ? 680 : 390;

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.34, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.17);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.18);
  }

  public playPickup(kind: 'health' | 'ammo'): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const notes = kind === 'health' ? [440, 554.37, 659.25] : [392, 493.88, 587.33];
    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.065);
      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.16, now + idx * 0.065);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.065 + 0.18);
      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(now + idx * 0.065);
      osc.stop(now + idx * 0.065 + 0.19);
    });
  }

  public playWaveStart(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    // Resonant conch / shankha-inspired warm brass fifth
    const freqs = [293.66, 440];
    freqs.forEach((freq, i) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq * 0.96, now + i * 0.1);
      osc.frequency.linearRampToValueAtTime(freq, now + i * 0.1 + 0.18);

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = 900;

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.001, now + i * 0.1);
      gain.gain.linearRampToValueAtTime(0.18, now + i * 0.1 + 0.14);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.1 + 0.72);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);
      osc.start(now + i * 0.1);
      osc.stop(now + i * 0.1 + 0.75);
    });
  }

  public playBusHorn(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    // Classic Kolkata WBTC dual-tone air horn (F4 + A4 brassy sawtooth pair)
    const freqs = [349.23, 440.0];
    freqs.forEach((f) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(f, now);

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.value = 920;
      filter.Q.value = 1.4;

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.14, now + 0.04);
      gain.gain.setValueAtTime(0.14, now + 0.28);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.42);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);
      osc.start(now);
      osc.stop(now + 0.44);
    });
  }

  public playWeaponShot(weapon: 'agni47' | 'kalbhairav' | 'trishul' | 'fala'): void {
    if (!this.ctx || !this.masterGain || !this.noiseBuffer || this.muted) return;
    const now = this.ctx.currentTime;

    if (weapon === 'fala') {
      // Fast silent tactical Bengali blade slash (air whoosh + faint steel glint)
      const noise = this.ctx.createBufferSource();
      noise.buffer = this.noiseBuffer;
      const bp = this.ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.setValueAtTime(2400, now);
      bp.frequency.exponentialRampToValueAtTime(620, now + 0.11);
      bp.Q.value = 2.2;

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.18, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

      noise.connect(bp);
      bp.connect(gain);
      gain.connect(this.masterGain);
      noise.start(now);
      noise.stop(now + 0.13);

      const glint = this.ctx.createOscillator();
      glint.type = 'sine';
      glint.frequency.setValueAtTime(2800, now);
      glint.frequency.exponentialRampToValueAtTime(1600, now + 0.06);
      const gGain = this.ctx.createGain();
      gGain.gain.setValueAtTime(0.06, now);
      gGain.gain.exponentialRampToValueAtTime(0.001, now + 0.065);
      glint.connect(gGain);
      gGain.connect(this.masterGain);
      glint.start(now);
      glint.stop(now + 0.07);
      return;
    }

    if (weapon === 'kalbhairav') {
      // Heavy booming shotgun blast
      const noise = this.ctx.createBufferSource();
      noise.buffer = this.noiseBuffer;
      const lp = this.ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.setValueAtTime(1650, now);
      lp.frequency.exponentialRampToValueAtTime(160, now + 0.24);
      const nGain = this.ctx.createGain();
      nGain.gain.setValueAtTime(0.62, now);
      nGain.gain.exponentialRampToValueAtTime(0.001, now + 0.26);
      noise.connect(lp);
      lp.connect(nGain);
      nGain.connect(this.masterGain);
      noise.start(now);
      noise.stop(now + 0.28);

      const boom = this.ctx.createOscillator();
      boom.type = 'triangle';
      boom.frequency.setValueAtTime(135, now);
      boom.frequency.exponentialRampToValueAtTime(30, now + 0.19);
      const bGain = this.ctx.createGain();
      bGain.gain.setValueAtTime(0.54, now);
      bGain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
      boom.connect(bGain);
      bGain.connect(this.masterGain);
      boom.start(now);
      boom.stop(now + 0.22);
      return;
    }

    if (weapon === 'trishul') {
      // High-velocity long-range sniper crack + crisp resonant tail
      const noise = this.ctx.createBufferSource();
      noise.buffer = this.noiseBuffer;
      const bp = this.ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.setValueAtTime(2200, now);
      bp.frequency.exponentialRampToValueAtTime(190, now + 0.34);
      bp.Q.value = 0.7;
      const nGain = this.ctx.createGain();
      nGain.gain.setValueAtTime(0.64, now);
      nGain.gain.exponentialRampToValueAtTime(0.001, now + 0.36);
      noise.connect(bp);
      bp.connect(nGain);
      nGain.connect(this.masterGain);
      noise.start(now);
      noise.stop(now + 0.38);

      const crack = this.ctx.createOscillator();
      crack.type = 'sawtooth';
      crack.frequency.setValueAtTime(240, now);
      crack.frequency.exponentialRampToValueAtTime(38, now + 0.18);
      const cGain = this.ctx.createGain();
      cGain.gain.setValueAtTime(0.42, now);
      cGain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
      crack.connect(cGain);
      cGain.connect(this.masterGain);
      crack.start(now);
      crack.stop(now + 0.21);
      return;
    }

    // Default: অগ্নি-৪৭ crisp automatic rifle shot
    this.playPlayerShot();
  }

  public playHeadshotPing(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;

    // Sharp helmet-crunch transient
    if (this.noiseBuffer) {
      const crunch = this.ctx.createBufferSource();
      crunch.buffer = this.noiseBuffer;
      const hp = this.ctx.createBiquadFilter();
      hp.type = 'bandpass';
      hp.frequency.setValueAtTime(3400, now);
      hp.frequency.exponentialRampToValueAtTime(1250, now + 0.055);
      hp.Q.value = 2.0;
      const cGain = this.ctx.createGain();
      cGain.gain.setValueAtTime(0.32, now);
      cGain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);
      crunch.connect(hp);
      hp.connect(cGain);
      cGain.connect(this.masterGain);
      crunch.start(now);
      crunch.stop(now + 0.065);
    }

    // Crisp high-resonance metallic helmet ping (dual inharmonic bell partials)
    const freqs = [1860, 2793, 3720];
    freqs.forEach((f, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      osc.type = idx === 0 ? 'triangle' : 'sine';
      osc.frequency.setValueAtTime(f, now);
      osc.frequency.exponentialRampToValueAtTime(f * 0.96, now + 0.24);

      const gain = this.ctx.createGain();
      const peak = idx === 0 ? 0.3 : idx === 1 ? 0.24 : 0.13;
      gain.gain.setValueAtTime(peak, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + (0.2 + idx * 0.05));

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(now);
      osc.stop(now + 0.31);
    });
  }

  public playChestOpen(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    // Wooden latch click + brass treasure chord
    const notes = [392, 493.88, 587.33, 783.99];
    notes.forEach((f, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(f, now + idx * 0.055);
      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.18, now + idx * 0.055);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.055 + 0.26);
      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(now + idx * 0.055);
      osc.stop(now + idx * 0.055 + 0.28);
    });
  }

  public playGrenadeThrow(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(280, now);
    osc.frequency.exponentialRampToValueAtTime(620, now + 0.14);
    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.14, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.16);
  }

  public playGrenadeExplosion(): void {
    if (!this.ctx || !this.masterGain || !this.noiseBuffer || this.muted) return;
    const now = this.ctx.currentTime;

    // Deep sub-bass thunder shockwave
    const sub = this.ctx.createOscillator();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(110, now);
    sub.frequency.exponentialRampToValueAtTime(24, now + 0.62);
    const sGain = this.ctx.createGain();
    sGain.gain.setValueAtTime(0.68, now);
    sGain.gain.exponentialRampToValueAtTime(0.001, now + 0.66);
    sub.connect(sGain);
    sGain.connect(this.masterGain);
    sub.start(now);
    sub.stop(now + 0.68);

    // Roaring fiery debris crackle
    const noise = this.ctx.createBufferSource();
    noise.buffer = this.noiseBuffer;
    const lp = this.ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(1400, now);
    lp.frequency.exponentialRampToValueAtTime(140, now + 0.72);
    const nGain = this.ctx.createGain();
    nGain.gain.setValueAtTime(0.62, now);
    nGain.gain.exponentialRampToValueAtTime(0.001, now + 0.75);
    noise.connect(lp);
    lp.connect(nGain);
    nGain.connect(this.masterGain);
    noise.start(now);
    noise.stop(now + 0.78);
  }

  public playHealComplete(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((f, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(f, now + idx * 0.07);
      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.16, now + idx * 0.07);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.07 + 0.28);
      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(now + idx * 0.07);
      osc.stop(now + idx * 0.07 + 0.3);
    });
  }

  public playStormWarning(): void {
    if (!this.ctx || !this.masterGain || !this.noiseBuffer || this.muted) return;
    const now = this.ctx.currentTime;
    const noise = this.ctx.createBufferSource();
    noise.buffer = this.noiseBuffer;
    const lp = this.ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(240, now);
    lp.frequency.exponentialRampToValueAtTime(70, now + 0.9);
    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.28, now + 0.12);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.95);
    noise.connect(lp);
    lp.connect(gain);
    gain.connect(this.masterGain);
    noise.start(now);
    noise.stop(now + 0.98);
  }

  public playStormTeleport(): void {
    if (!this.ctx || !this.masterGain || !this.noiseBuffer || this.muted) return;
    const now = this.ctx.currentTime;

    // 1. Swirling Kalboishakhi gale sweep (bandpass noise rising & whipping down)
    const gale = this.ctx.createBufferSource();
    gale.buffer = this.noiseBuffer;
    const bp = this.ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.Q.value = 2.6;
    bp.frequency.setValueAtTime(220, now);
    bp.frequency.exponentialRampToValueAtTime(1950, now + 0.32);
    bp.frequency.exponentialRampToValueAtTime(310, now + 1.15);

    const galeGain = this.ctx.createGain();
    galeGain.gain.setValueAtTime(0.001, now);
    galeGain.gain.linearRampToValueAtTime(0.52, now + 0.14);
    galeGain.gain.exponentialRampToValueAtTime(0.001, now + 1.2);

    gale.connect(bp);
    bp.connect(galeGain);
    galeGain.connect(this.masterGain);
    gale.start(now);
    gale.stop(now + 1.25);

    // 2. Deep thunderous whoosh impact
    const sub = this.ctx.createOscillator();
    sub.type = 'triangle';
    sub.frequency.setValueAtTime(140, now);
    sub.frequency.exponentialRampToValueAtTime(34, now + 0.55);
    const subGain = this.ctx.createGain();
    subGain.gain.setValueAtTime(0.42, now);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
    sub.connect(subGain);
    subGain.connect(this.masterGain);
    sub.start(now);
    sub.stop(now + 0.62);

    // 3. Ethereal high wind shimmer chime on arrival
    const shimmer = this.ctx.createOscillator();
    shimmer.type = 'sine';
    shimmer.frequency.setValueAtTime(740, now + 0.08);
    shimmer.frequency.exponentialRampToValueAtTime(1480, now + 0.34);
    shimmer.frequency.exponentialRampToValueAtTime(520, now + 0.85);
    const shGain = this.ctx.createGain();
    shGain.gain.setValueAtTime(0.001, now + 0.08);
    shGain.gain.linearRampToValueAtTime(0.16, now + 0.18);
    shGain.gain.exponentialRampToValueAtTime(0.001, now + 0.88);
    shimmer.connect(shGain);
    shGain.connect(this.masterGain);
    shimmer.start(now + 0.08);
    shimmer.stop(now + 0.9);
  }

  public playBusJump(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(190, now);
    osc.frequency.exponentialRampToValueAtTime(58, now + 0.18);
    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.24, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.22);
  }

  public playBusDoorBrake(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;

    // 1. Pneumatic air-brake & folding door hiss (bandpass-filtered white noise)
    const sampleCount = Math.floor(this.ctx.sampleRate * 0.42);
    const buffer = this.ctx.createBuffer(1, sampleCount, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < sampleCount; i++) {
      data[i] = (Math.random() * 2 - 1) * (1 - i / sampleCount);
    }
    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(2400, now);
    filter.frequency.exponentialRampToValueAtTime(950, now + 0.4);
    filter.Q.value = 1.6;

    const hissGain = this.ctx.createGain();
    hissGain.gain.setValueAtTime(0.001, now);
    hissGain.gain.linearRampToValueAtTime(0.18, now + 0.04);
    hissGain.gain.exponentialRampToValueAtTime(0.001, now + 0.42);

    noise.connect(filter);
    filter.connect(hissGain);
    hissGain.connect(this.masterGain);
    noise.start(now);

    // 2. Crisp metallic door-latch clack as side passenger door opens
    const latch = this.ctx.createOscillator();
    latch.type = 'triangle';
    latch.frequency.setValueAtTime(420, now + 0.12);
    latch.frequency.exponentialRampToValueAtTime(140, now + 0.21);
    const latchGain = this.ctx.createGain();
    latchGain.gain.setValueAtTime(0.001, now + 0.12);
    latchGain.gain.linearRampToValueAtTime(0.14, now + 0.13);
    latchGain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
    latch.connect(latchGain);
    latchGain.connect(this.masterGain);
    latch.start(now + 0.12);
    latch.stop(now + 0.23);
  }

  public playAnimalGrowl(aggressive = true): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'sawtooth';
    const baseFreq = aggressive ? 105 : 145;
    osc.frequency.setValueAtTime(baseFreq, now);
    osc.frequency.exponentialRampToValueAtTime(aggressive ? 56 : 82, now + 0.36);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(aggressive ? 310 : 420, now);
    filter.Q.value = 2.0;

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(aggressive ? 0.28 : 0.18, now + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.38);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.4);
  }

  public playAnimalSubdued(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const notes = [523.25, 659.25];
    notes.forEach((f, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(f, now + idx * 0.09);
      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.001, now + idx * 0.09);
      gain.gain.linearRampToValueAtTime(0.2, now + idx * 0.09 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.09 + 0.32);
      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(now + idx * 0.09);
      osc.stop(now + idx * 0.09 + 0.34);
    });
  }

  public playTameTick(progress: number): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'sine';
    const freq = 340 + progress * 420;
    osc.frequency.setValueAtTime(freq, now);
    osc.frequency.exponentialRampToValueAtTime(freq * 1.15, now + 0.08);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.14, now + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.11);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.12);
  }

  public playTameSuccess(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    // Celebratory Bengali shankha/sitar ascending chord
    const notes = [392.0, 493.88, 587.33, 783.99];
    notes.forEach((f, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(f, now + idx * 0.085);
      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.001, now + idx * 0.085);
      gain.gain.linearRampToValueAtTime(0.22, now + idx * 0.085 + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.085 + 0.48);
      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(now + idx * 0.085);
      osc.stop(now + idx * 0.085 + 0.5);
    });
  }

  public playTameFail(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const notes = [260, 185];
    notes.forEach((f, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(f, now + idx * 0.12);
      osc.frequency.exponentialRampToValueAtTime(f * 0.72, now + idx * 0.12 + 0.18);
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = 540;
      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.18, now + idx * 0.12);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.12 + 0.22);
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);
      osc.start(now + idx * 0.12);
      osc.stop(now + idx * 0.12 + 0.24);
    });
  }

  public playPetAssistBark(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.exponentialRampToValueAtTime(340, now + 0.05);
    osc.frequency.exponentialRampToValueAtTime(140, now + 0.16);
    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.18, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.2);
  }

  public dispose(): void {
    if (this.ambienceGain) {
      this.ambienceGain.disconnect();
      this.ambienceGain = null;
    }
    if (this.ctx) {
      void this.ctx.close();
      this.ctx = null;
    }
    this.masterGain = null;
    this.noiseBuffer = null;
    this.ambienceStarted = false;
  }
}
