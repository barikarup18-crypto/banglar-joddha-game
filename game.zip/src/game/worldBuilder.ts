import * as THREE from 'three';
import {
  buildExtendedRiverGhat,
  buildOldTramDepotAndBazaar,
  buildSalForestAndHills,
  buildZamindarBari,
  ChestAnchor,
} from './battleRoyaleAssets';
import { TextureBundle } from './textures';
import { BoxCollider, CircleCollider, WildAnimalSpecies } from './types';

export interface SwayingPalm {
  crown: THREE.Group;
  phase: number;
  baseRotX: number;
  baseRotZ: number;
}

export interface WildAnimalHabitatAnchor {
  x: number;
  z: number;
  areaBn: string;
  speciesHint?: WildAnimalSpecies;
}

export interface WorldBuildResult {
  worldGroup: THREE.Group;
  boxColliders: BoxCollider[];
  circleColliders: CircleCollider[];
  swayingPalms: SwayingPalm[];
  boatGroup: THREE.Group;
  bobbingBoats: THREE.Group[];
  waterUniforms: { uTime: { value: number } };
  waterBumpTexture: THREE.CanvasTexture;
  enemySpawnPoints: THREE.Vector3[];
  wildAnimalHabitats: WildAnimalHabitatAnchor[];
  pickupAnchors: THREE.Vector3[];
  landmarkChestAnchors: ChestAnchor[];
  landmarkSanjibaniAnchors: Array<{ x: number; z: number }>;
  playableBounds: { minX: number; maxX: number; minZ: number; maxZ: number };
  getGroundHeight: (x: number, z: number, currentY?: number) => number;
  isWaterBlocked: (x: number, z: number) => boolean;
  getLocationName: (x: number, z: number, currentY?: number) => string;
}

function addContactShadow(
  parent: THREE.Object3D,
  shadowMap: THREE.CanvasTexture,
  width: number,
  depth: number,
  opacity = 0.48,
): void {
  const geo = new THREE.PlaneGeometry(width, depth);
  geo.rotateX(-Math.PI / 2);
  const mat = new THREE.MeshBasicMaterial({
    map: shadowMap,
    transparent: true,
    opacity,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.y = 0.025;
  parent.add(mesh);
}

/**
 * Builds an iconic Howrah-style steel cantilever truss bridge spanning the Hooghly River.
 */
function buildHowrahBridge(textures: TextureBundle): THREE.Group {
  const bridge = new THREE.Group();
  bridge.position.set(0, 0, -40);

  const steelMat = new THREE.MeshStandardMaterial({
    map: textures.bridgeSteelMap,
    color: 0x9aa5ad,
    roughness: 0.42,
    metalness: 0.78,
  });
  const darkSteelMat = new THREE.MeshStandardMaterial({
    color: 0x4b545c,
    roughness: 0.55,
    metalness: 0.72,
  });
  const deckMat = new THREE.MeshStandardMaterial({
    color: 0x3b3d40,
    roughness: 0.88,
    metalness: 0.05,
  });
  const stoneMat = new THREE.MeshStandardMaterial({
    color: 0x8f8274,
    roughness: 0.92,
    metalness: 0.02,
  });
  const lampGlowMat = new THREE.MeshStandardMaterial({
    color: 0xffdf99,
    emissive: 0xffae42,
    emissiveIntensity: 2.2,
    roughness: 0.25,
  });

  const deckY = 6.2;
  const totalLen = 136;
  const halfWidth = 4.6;

  // Roadway deck
  const deck = new THREE.Mesh(new THREE.BoxGeometry(totalLen, 0.75, halfWidth * 2), deckMat);
  deck.position.set(0, deckY, 0);
  deck.receiveShadow = true;
  bridge.add(deck);

  // Side curb girders
  for (const zSide of [-halfWidth, halfWidth]) {
    const girder = new THREE.Mesh(new THREE.BoxGeometry(totalLen, 1.05, 0.55), darkSteelMat);
    girder.position.set(0, deckY + 0.2, zSide);
    bridge.add(girder);
  }

  // Twin iconic Howrah Bridge main towers at x = -28 and x = +28
  const towerPositions = [-28, 28];
  const towerHeight = 25;

  for (const tx of towerPositions) {
    // Stone river masonry piers
    const pier = new THREE.Mesh(new THREE.BoxGeometry(6.2, 8.2, halfWidth * 2 + 3.2), stoneMat);
    pier.position.set(tx, 2.2, 0);
    bridge.add(pier);

    // Tapered twin steel tower legs on front & back of roadway
    for (const zSide of [-halfWidth, halfWidth]) {
      const leg = new THREE.Mesh(new THREE.BoxGeometry(1.7, towerHeight, 1.5), steelMat);
      leg.position.set(tx, deckY + towerHeight * 0.5 - 1.5, zSide);
      bridge.add(leg);

      // Decorative riveted crown finial atop tower
      const cap = new THREE.Mesh(new THREE.BoxGeometry(2.3, 1.1, 2.1), darkSteelMat);
      cap.position.set(tx, deckY + towerHeight - 1.2, zSide);
      bridge.add(cap);
    }

    // Overhead portal cross-beams & X-bracing linking front/back legs
    const beamHeights = [deckY + 8.5, deckY + 15.5, deckY + 21.8];
    for (const by of beamHeights) {
      const cross = new THREE.Mesh(new THREE.BoxGeometry(1.3, 1.25, halfWidth * 2 + 1.2), steelMat);
      cross.position.set(tx, by, 0);
      bridge.add(cross);
    }

    // Diagonal portal X-braces inside tower head
    const diagLen = Math.hypot(halfWidth * 2, 6.2);
    for (const dir of [-1, 1]) {
      const brace = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.42, diagLen), darkSteelMat);
      brace.position.set(tx, deckY + 18.6, 0);
      brace.rotation.x = dir * Math.atan2(6.2, halfWidth * 2);
      bridge.add(brace);
    }
  }

  // Classic cantilever curved upper truss chords (both front & back sides)
  // Profile height as a function of x: peaks over towers (±28), curves down to central suspended span and outer anchor spans
  const upperChordY = (x: number): number => {
    const ax = Math.abs(x);
    if (ax <= 28) {
      // Between towers: graceful catenary-like dip to central span
      const t = ax / 28; // 0 at center, 1 at tower
      return deckY + 7.2 + Math.pow(t, 2.15) * 16.0;
    } else {
      // Anchor arms sloping down toward riverbanks
      const t = Math.min(1, (ax - 28) / 36);
      return deckY + 23.2 - Math.pow(t, 0.88) * 18.5;
    }
  };

  const segments = 24;
  const xMin = -62;
  const xMax = 62;
  const dx = (xMax - xMin) / segments;
  const vA = new THREE.Vector3();
  const vB = new THREE.Vector3();
  const vMid = new THREE.Vector3();
  const upAxis = new THREE.Vector3(0, 1, 0);
  const quat = new THREE.Quaternion();

  const addStrut = (
    ax: number,
    ay: number,
    az: number,
    bx: number,
    by: number,
    bz: number,
    thickness: number,
    mat: THREE.Material,
  ) => {
    vA.set(ax, ay, az);
    vB.set(bx, by, bz);
    const len = vA.distanceTo(vB);
    if (len < 0.05) return;
    vMid.addVectors(vA, vB).multiplyScalar(0.5);
    const dir = vB.clone().sub(vA).normalize();
    quat.setFromUnitVectors(upAxis, dir);
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(thickness, len, thickness), mat);
    mesh.position.copy(vMid);
    mesh.quaternion.copy(quat);
    bridge.add(mesh);
  };

  for (const zSide of [-halfWidth, halfWidth]) {
    for (let i = 0; i < segments; i++) {
      const x0 = xMin + i * dx;
      const x1 = x0 + dx;
      const y0 = upperChordY(x0);
      const y1 = upperChordY(x1);

      // Upper chord member
      addStrut(x0, y0, zSide, x1, y1, zSide, 0.58, steelMat);
      // Vertical hanger post
      addStrut(x0, deckY, zSide, x0, y0, zSide, 0.34, darkSteelMat);
      // Alternating Warren/Pratt diagonal truss member
      if (i % 2 === 0) {
        addStrut(x0, deckY, zSide, x1, y1, zSide, 0.3, steelMat);
      } else {
        addStrut(x0, y0, zSide, x1, deckY, zSide, 0.3, steelMat);
      }
    }
    // Closing vertical strut
    addStrut(xMax, deckY, zSide, xMax, upperChordY(xMax), zSide, 0.34, darkSteelMat);
  }

  // Overhead wind-bracing cross struts between front and back upper chords
  for (let i = 3; i < segments - 2; i += 2) {
    const x = xMin + i * dx;
    const y = upperChordY(x);
    if (y > deckY + 8.0) {
      addStrut(x, y, -halfWidth, x, y, halfWidth, 0.34, darkSteelMat);
    }
  }

  // Warm glowing sodium bridge lamps along the deck
  for (let x = -52; x <= 52; x += 13) {
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 3.2, 6), darkSteelMat);
    post.position.set(x, deckY + 1.8, halfWidth - 0.3);
    bridge.add(post);

    const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.28, 8, 8), lampGlowMat);
    bulb.position.set(x, deckY + 3.45, halfWidth - 0.3);
    bridge.add(bulb);
  }

  return bridge;
}

/**
 * Builds an iconic Kolkata Yellow Hindustan Ambassador Taxi (12-part composite THREE.Group).
 */
function buildYellowTaxi(textures: TextureBundle): THREE.Group {
  const taxi = new THREE.Group();

  const yellowPaint = new THREE.MeshPhysicalMaterial({
    color: 0xf4bd14,
    roughness: 0.24,
    metalness: 0.18,
    clearcoat: 1.0,
    clearcoatRoughness: 0.12,
  });
  const blackTrim = new THREE.MeshStandardMaterial({
    color: 0x1b1c1f,
    roughness: 0.55,
    metalness: 0.2,
  });
  const chromeMat = new THREE.MeshStandardMaterial({
    color: 0xe6ebef,
    roughness: 0.16,
    metalness: 0.92,
  });
  const glassMat = new THREE.MeshPhysicalMaterial({
    color: 0x1d2b35,
    roughness: 0.12,
    metalness: 0.15,
    clearcoat: 1.0,
  });
  const rubberMat = new THREE.MeshStandardMaterial({
    color: 0x171717,
    roughness: 0.92,
    metalness: 0.02,
  });
  const headlightMat = new THREE.MeshStandardMaterial({
    color: 0xfff3c4,
    emissive: 0xffd275,
    emissiveIntensity: 1.4,
    roughness: 0.2,
  });
  const taillightMat = new THREE.MeshStandardMaterial({
    color: 0xd92626,
    emissive: 0xb51818,
    emissiveIntensity: 0.9,
    roughness: 0.25,
  });

  // 1. Classic rounded lower body hull using beveled ExtrudeGeometry (side profile)
  const hullShape = new THREE.Shape();
  hullShape.moveTo(-2.15, 0.36);
  hullShape.lineTo(2.15, 0.36);
  hullShape.quadraticCurveTo(2.3, 0.5, 2.22, 0.96);
  hullShape.lineTo(1.25, 1.08);
  hullShape.lineTo(-1.35, 1.08);
  hullShape.lineTo(-2.18, 0.94);
  hullShape.quadraticCurveTo(-2.3, 0.62, -2.15, 0.36);

  const hullGeo = new THREE.ExtrudeGeometry(hullShape, {
    depth: 1.66,
    bevelEnabled: true,
    bevelThickness: 0.12,
    bevelSize: 0.08,
    bevelSegments: 3,
  });
  hullGeo.translate(0, 0, -0.83);
  const hull = new THREE.Mesh(hullGeo, yellowPaint);
  hull.castShadow = true;
  hull.receiveShadow = true;
  taxi.add(hull);

  // 2. Classic black Kolkata taxi lower side band / rocker stripe
  const stripe = new THREE.Mesh(new THREE.BoxGeometry(4.36, 0.26, 1.9), blackTrim);
  stripe.position.set(0, 0.48, 0);
  taxi.add(stripe);

  // 3. Domed Ambassador greenhouse cabin
  const cabinShape = new THREE.Shape();
  cabinShape.moveTo(-1.26, 1.04);
  cabinShape.lineTo(1.12, 1.04);
  cabinShape.quadraticCurveTo(0.84, 1.64, 0.48, 1.7);
  cabinShape.lineTo(-0.76, 1.7);
  cabinShape.quadraticCurveTo(-1.12, 1.6, -1.26, 1.04);
  const cabinGeo = new THREE.ExtrudeGeometry(cabinShape, {
    depth: 1.44,
    bevelEnabled: true,
    bevelThickness: 0.1,
    bevelSize: 0.08,
    bevelSegments: 3,
  });
  cabinGeo.translate(0, 0, -0.72);
  const cabin = new THREE.Mesh(cabinGeo, yellowPaint);
  cabin.castShadow = true;
  taxi.add(cabin);

  // 4. Windshield, rear glass & side windows
  const sideGlass = new THREE.Mesh(new THREE.BoxGeometry(1.75, 0.44, 1.66), glassMat);
  sideGlass.position.set(-0.1, 1.35, 0);
  taxi.add(sideGlass);

  const frontBackGlass = new THREE.Mesh(new THREE.BoxGeometry(2.08, 0.42, 1.32), glassMat);
  frontBackGlass.position.set(-0.08, 1.34, 0);
  taxi.add(frontBackGlass);

  // 5. Roof "TAXI" illuminated sign box
  const signMat = new THREE.MeshStandardMaterial({
    map: textures.taxiSignMap,
    emissive: 0xffe07d,
    emissiveMap: textures.taxiSignMap,
    emissiveIntensity: 0.35,
    roughness: 0.35,
  });
  const taxiSign = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.24, 0.66), [
    signMat,
    signMat,
    blackTrim,
    blackTrim,
    blackTrim,
    blackTrim,
  ]);
  taxiSign.position.set(0.05, 1.88, 0);
  taxiSign.castShadow = true;
  taxi.add(taxiSign);

  // 6. Chrome roof luggage carrier bars
  const rackBase = new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.05, 1.15), chromeMat);
  rackBase.position.set(-0.56, 1.82, 0);
  taxi.add(rackBase);

  // 7. Chrome front & rear bumpers + radiator grille
  for (const bx of [2.3, -2.3]) {
    const bumper = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.18, 1.92), chromeMat);
    bumper.position.set(bx, 0.42, 0);
    taxi.add(bumper);
  }
  const grille = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.36, 0.92), chromeMat);
  grille.position.set(2.26, 0.72, 0);
  taxi.add(grille);

  // 8. Round twin Ambassador headlights with chrome bezels
  for (const hz of [-0.64, 0.64]) {
    const bezel = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 0.12, 14), chromeMat);
    bezel.rotation.z = Math.PI / 2;
    bezel.position.set(2.22, 0.84, hz);
    taxi.add(bezel);

    const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 10), headlightMat);
    lamp.position.set(2.26, 0.84, hz);
    taxi.add(lamp);

    // Rear tail lamps
    const tail = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.22, 0.18), taillightMat);
    tail.position.set(-2.26, 0.78, hz);
    taxi.add(tail);
  }

  // 9. West Bengal license plates (front & back)
  const plateMat = new THREE.MeshStandardMaterial({
    map: textures.licensePlateMap,
    roughness: 0.45,
  });
  for (const px of [2.36, -2.36]) {
    const plate = new THREE.Mesh(new THREE.PlaneGeometry(0.56, 0.16), plateMat);
    plate.position.set(px, 0.56, 0);
    plate.rotation.y = px > 0 ? Math.PI / 2 : -Math.PI / 2;
    taxi.add(plate);
  }

  // 10. Four rubber wheels with chrome Ambassador hubcaps
  const wheelCoords: [number, number][] = [
    [1.36, 0.88],
    [1.36, -0.88],
    [-1.36, 0.88],
    [-1.36, -0.88],
  ];
  const tireGeo = new THREE.CylinderGeometry(0.38, 0.38, 0.26, 18);
  tireGeo.rotateX(Math.PI / 2);
  const hubGeo = new THREE.CylinderGeometry(0.2, 0.2, 0.29, 14);
  hubGeo.rotateX(Math.PI / 2);

  for (const [wx, wz] of wheelCoords) {
    const tire = new THREE.Mesh(tireGeo, rubberMat);
    tire.position.set(wx, 0.38, wz);
    tire.castShadow = true;
    taxi.add(tire);

    const hub = new THREE.Mesh(hubGeo, chromeMat);
    hub.position.set(wx, 0.38, wz);
    taxi.add(hub);
  }

  addContactShadow(taxi, textures.contactShadowMap, 5.4, 2.7, 0.58);
  return taxi;
}

/**
 * Builds a traditional West Bengal Village Mud House (Matir Ghor) with Alpona dado,
 * veranda (daowa), bamboo pillars, pitched thatched chala roof, and clay kolshi pots.
 */
function buildMudHouse(
  textures: TextureBundle,
  width = 6.2,
  depth = 5.0,
  wallHeight = 3.0,
): THREE.Group {
  const house = new THREE.Group();

  const wallMat = new THREE.MeshStandardMaterial({
    map: textures.mudWallMap,
    bumpMap: textures.mudWallBump,
    bumpScale: 0.08,
    roughness: 0.92,
    metalness: 0.0,
  });
  const plinthMat = new THREE.MeshStandardMaterial({
    color: 0x875132,
    roughness: 0.94,
    metalness: 0.0,
  });
  const thatchMat = new THREE.MeshStandardMaterial({
    map: textures.thatchMap,
    color: 0xd1b37c,
    roughness: 0.96,
    metalness: 0.0,
  });
  const woodMat = new THREE.MeshStandardMaterial({
    color: 0x4d311e,
    roughness: 0.82,
    metalness: 0.05,
  });
  const bambooMat = new THREE.MeshStandardMaterial({
    color: 0x9b7c46,
    roughness: 0.72,
    metalness: 0.04,
  });
  const clayPotMat = new THREE.MeshStandardMaterial({
    color: 0xb64a2c,
    roughness: 0.7,
    metalness: 0.04,
  });
  const lanternGlowMat = new THREE.MeshStandardMaterial({
    color: 0xffd27a,
    emissive: 0xff9b2f,
    emissiveIntensity: 1.8,
    roughness: 0.3,
  });

  // 1. Raised earthen veranda plinth (daowa)
  const plinthH = 0.42;
  const plinth = new THREE.Mesh(
    new THREE.BoxGeometry(width + 1.1, plinthH, depth + 1.5),
    plinthMat,
  );
  plinth.position.set(0, plinthH * 0.5, 0.3);
  plinth.receiveShadow = true;
  plinth.castShadow = true;
  house.add(plinth);

  // 2. Main mud-plaster walls with Alpona motif band
  const body = new THREE.Mesh(new THREE.BoxGeometry(width, wallHeight, depth), wallMat);
  body.position.set(0, plinthH + wallHeight * 0.5, -0.15);
  body.castShadow = true;
  body.receiveShadow = true;
  house.add(body);

  // 3. Pitched Bengali Chala thatched roof (two beveled eaves + ridge beam)
  const roofH = 2.15;
  const roofShape = new THREE.Shape();
  const halfSpan = depth * 0.5 + 1.35;
  roofShape.moveTo(-halfSpan, 0);
  roofShape.lineTo(0, roofH);
  roofShape.lineTo(halfSpan, 0);
  roofShape.lineTo(halfSpan - 0.28, -0.22);
  roofShape.lineTo(0, roofH - 0.34);
  roofShape.lineTo(-halfSpan + 0.28, -0.22);
  roofShape.closePath();

  const roofGeo = new THREE.ExtrudeGeometry(roofShape, {
    depth: width + 1.5,
    bevelEnabled: true,
    bevelThickness: 0.14,
    bevelSize: 0.1,
    bevelSegments: 2,
  });
  roofGeo.rotateY(Math.PI / 2);
  roofGeo.translate(-(width + 1.5) * 0.5, plinthH + wallHeight - 0.16, 0.05);
  const roof = new THREE.Mesh(roofGeo, thatchMat);
  roof.castShadow = true;
  roof.receiveShadow = true;
  house.add(roof);

  // Triangular gable mud infill under roof
  const gableShape = new THREE.Shape();
  gableShape.moveTo(-depth * 0.5, 0);
  gableShape.lineTo(0, roofH - 0.28);
  gableShape.lineTo(depth * 0.5, 0);
  gableShape.closePath();
  const gableGeo = new THREE.ExtrudeGeometry(gableShape, {
    depth: width - 0.08,
    bevelEnabled: false,
  });
  gableGeo.rotateY(Math.PI / 2);
  gableGeo.translate(-(width - 0.08) * 0.5, plinthH + wallHeight - 0.05, -0.15);
  const gable = new THREE.Mesh(gableGeo, wallMat);
  house.add(gable);

  // Bamboo ridge pole
  const ridge = new THREE.Mesh(
    new THREE.CylinderGeometry(0.12, 0.12, width + 1.9, 8),
    bambooMat,
  );
  ridge.rotation.z = Math.PI / 2;
  ridge.position.set(0, plinthH + wallHeight + roofH - 0.08, 0.05);
  house.add(ridge);

  // 4. Front veranda bamboo support posts
  const postXs = [-width * 0.48, -width * 0.16, width * 0.16, width * 0.48];
  for (const px of postXs) {
    const post = new THREE.Mesh(
      new THREE.CylinderGeometry(0.08, 0.095, wallHeight, 8),
      bambooMat,
    );
    post.position.set(px, plinthH + wallHeight * 0.5, depth * 0.5 + 0.85);
    post.castShadow = true;
    house.add(post);
  }

  // 5. Wooden front door & frame
  const doorFrame = new THREE.Mesh(new THREE.BoxGeometry(1.36, 2.25, 0.18), woodMat);
  doorFrame.position.set(0, plinthH + 1.12, depth * 0.5 - 0.12);
  house.add(doorFrame);

  const doorPanel = new THREE.Mesh(
    new THREE.BoxGeometry(1.12, 2.08, 0.22),
    new THREE.MeshStandardMaterial({ color: 0x3a2315, roughness: 0.85 }),
  );
  doorPanel.position.set(0, plinthH + 1.06, depth * 0.5 - 0.11);
  house.add(doorPanel);

  // 6. Shuttered side & front windows
  const winPositions = [-width * 0.3, width * 0.3];
  for (const wx of winPositions) {
    const win = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.95, 0.18), woodMat);
    win.position.set(wx, plinthH + 1.65, depth * 0.5 - 0.12);
    house.add(win);

    const inner = new THREE.Mesh(
      new THREE.BoxGeometry(0.74, 0.74, 0.21),
      new THREE.MeshStandardMaterial({ color: 0x20150e, roughness: 0.9 }),
    );
    inner.position.set(wx, plinthH + 1.65, depth * 0.5 - 0.11);
    house.add(inner);
  }

  // 7. Terracotta water pots (Kolshi) using LatheGeometry on veranda
  const potProfile = [
    new THREE.Vector2(0.0, 0.0),
    new THREE.Vector2(0.18, 0.0),
    new THREE.Vector2(0.28, 0.18),
    new THREE.Vector2(0.26, 0.36),
    new THREE.Vector2(0.13, 0.48),
    new THREE.Vector2(0.16, 0.56),
  ];
  const potGeo = new THREE.LatheGeometry(potProfile, 14);
  const pot1 = new THREE.Mesh(potGeo, clayPotMat);
  pot1.position.set(-width * 0.36, plinthH, depth * 0.5 + 0.38);
  pot1.castShadow = true;
  house.add(pot1);

  const pot2 = new THREE.Mesh(potGeo, clayPotMat);
  pot2.scale.setScalar(0.8);
  pot2.position.set(-width * 0.26, plinthH, depth * 0.5 + 0.5);
  house.add(pot2);

  // 8. Hanging warm village oil lantern by the veranda
  const lantern = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.13, 0.26, 8), lanternGlowMat);
  lantern.position.set(width * 0.16, plinthH + wallHeight - 0.48, depth * 0.5 + 0.85);
  house.add(lantern);

  addContactShadow(house, textures.contactShadowMap, width + 2.4, depth + 2.6, 0.45);
  return house;
}

/**
 * Builds a realistic curved Coconut Palm Tree (Narkel Gach) using TubeGeometry + arched fronds + coconuts.
 */
function buildCoconutTree(
  textures: TextureBundle,
  height = 9.5,
  leanX = 1.1,
  leanZ = 0.6,
): { group: THREE.Group; crown: THREE.Group } {
  const tree = new THREE.Group();

  const trunkMat = new THREE.MeshStandardMaterial({
    map: textures.palmBarkMap,
    roughness: 0.9,
    metalness: 0.0,
  });
  const frondMat = new THREE.MeshStandardMaterial({
    map: textures.frondMap,
    alphaTest: 0.35,
    side: THREE.DoubleSide,
    roughness: 0.68,
    metalness: 0.02,
  });
  const coconutMat = new THREE.MeshStandardMaterial({
    color: 0x4b7826,
    roughness: 0.42,
    metalness: 0.05,
  });

  // 1. Curved organic trunk via TubeGeometry along CatmullRomCurve3
  const curve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, 0, 0),
    new THREE.Vector3(leanX * 0.25, height * 0.35, leanZ * 0.25),
    new THREE.Vector3(leanX * 0.72, height * 0.72, leanZ * 0.72),
    new THREE.Vector3(leanX, height, leanZ),
  ]);
  const trunkGeo = new THREE.TubeGeometry(curve, 12, 0.24, 8, false);
  // Gently taper trunk from base to top
  const posAttr = trunkGeo.attributes.position;
  for (let i = 0; i < posAttr.count; i++) {
    const y = posAttr.getY(i);
    const t = THREE.MathUtils.clamp(y / height, 0, 1);
    const center = curve.getPoint(t);
    const taper = THREE.MathUtils.lerp(1.22, 0.56, t);
    posAttr.setXYZ(
      i,
      center.x + (posAttr.getX(i) - center.x) * taper,
      y,
      center.z + (posAttr.getZ(i) - center.z) * taper,
    );
  }
  trunkGeo.computeVertexNormals();
  const trunk = new THREE.Mesh(trunkGeo, trunkMat);
  trunk.castShadow = true;
  trunk.receiveShadow = true;
  tree.add(trunk);

  // 2. Swaying crown group at the top of the trunk
  const crown = new THREE.Group();
  crown.position.set(leanX, height, leanZ);
  tree.add(crown);

  // Cluster of green Bengali coconuts (Daab) under crown
  const nutGeo = new THREE.SphereGeometry(0.19, 8, 8);
  nutGeo.scale(1, 1.18, 1);
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2;
    const nut = new THREE.Mesh(nutGeo, coconutMat);
    nut.position.set(Math.cos(a) * 0.28, -0.26 - (i % 2) * 0.14, Math.sin(a) * 0.28);
    crown.add(nut);
  }

  // 3. Curved palm frond geometry (bent PlaneGeometry)
  const frondGeo = new THREE.PlaneGeometry(3.6, 1.35, 8, 2);
  frondGeo.translate(1.8, 0, 0);
  const fp = frondGeo.attributes.position;
  for (let i = 0; i < fp.count; i++) {
    const fx = fp.getX(i);
    const fz = fp.getY(i); // before rotating flat
    const normX = fx / 3.6;
    const droopY = Math.sin(normX * Math.PI) * 0.55 - normX * normX * 1.15;
    const vFold = Math.abs(fz) * 0.18;
    fp.setXYZ(i, fx, droopY - vFold, fz);
  }
  frondGeo.computeVertexNormals();

  const frondCount = 10;
  for (let i = 0; i < frondCount; i++) {
    const angle = (i / frondCount) * Math.PI * 2 + (i % 2) * 0.18;
    const pitch = i % 2 === 0 ? 0.22 : -0.14;
    const frond = new THREE.Mesh(frondGeo, frondMat);
    frond.rotation.y = angle;
    frond.rotation.z = pitch;
    frond.castShadow = true;
    crown.add(frond);
  }

  addContactShadow(tree, textures.contactShadowMap, 3.0, 3.0, 0.38);
  return { group: tree, crown };
}

/**
 * Builds a traditional wooden Bengali river country boat (Nouka) floating near the Hooghly ghat.
 */
function buildRiverBoat(): THREE.Group {
  const boat = new THREE.Group();

  const woodDark = new THREE.MeshStandardMaterial({
    color: 0x3b2416,
    roughness: 0.85,
    metalness: 0.05,
  });
  const woodTrim = new THREE.MeshStandardMaterial({
    color: 0x8f3422,
    roughness: 0.72,
    metalness: 0.05,
  });
  const bambooCanopy = new THREE.MeshStandardMaterial({
    color: 0xb7965b,
    roughness: 0.92,
    side: THREE.DoubleSide,
  });

  // Curved hull
  const hull = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 0.55, 5.4, 10, 1, false, 0, Math.PI), woodDark);
  hull.rotation.z = Math.PI / 2;
  hull.rotation.x = Math.PI;
  hull.scale.set(1, 1, 0.82);
  hull.position.y = 0.25;
  boat.add(hull);

  // Raised pointed bow & stern prows
  for (const sx of [-2.95, 2.95]) {
    const prow = new THREE.Mesh(new THREE.ConeGeometry(0.42, 1.3, 6), woodTrim);
    prow.position.set(sx, 0.56, 0);
    prow.rotation.z = sx > 0 ? -Math.PI * 0.36 : Math.PI * 0.36;
    boat.add(prow);
  }

  // Arched bamboo chhoi (canopy) in middle of boat
  const canopy = new THREE.Mesh(
    new THREE.CylinderGeometry(0.92, 0.92, 2.2, 12, 1, true, -Math.PI * 0.45, Math.PI * 0.9),
    bambooCanopy,
  );
  canopy.rotation.z = Math.PI / 2;
  canopy.position.set(-0.2, 0.62, 0);
  boat.add(canopy);

  return boat;
}

/**
 * Analytical Red-Soil Laterite Hills elevation for শালবন ও লাল মাটির টিলা (West & NW sectors)
 * and gentle rolling outer Bengal countryside beyond the village/landmarks.
 * Guaranteed flat (0) across Village Square, Riverbank Ghat, Zamindar Bari, and Old Tram Depot.
 */
function sampleLateriteHillHeight(x: number, z: number): number {
  // Keep river channel, village square, ghat, Zamindar Bari estate, and Tram Depot completely level
  if (z > -76 && z < -6) return 0;
  if (x > -46 && x < 54 && z >= -18 && z < 46) return 0; // Village Square
  if (x > 64 && x < 134 && z > -14 && z < 56) return 0; // Zamindar Bari estate
  if (x > -88 && x < 88 && z < -70 && z > -196) return 0; // Old Tram Depot & Bazaar
  // Keep westbound & eastbound main heritage trails smooth
  if (x > -128 && x < 76 && z > 1 && z < 13) return 0;

  // Rarh Bengal laterite hill mounds & expanded countryside ridges across ±760m playable arena
  const hills: Array<[number, number, number, number]> = [
    // South-West Sal Forest & Red-Soil Hills (শালবন)
    [-92, 42, 6.4, 34],
    [-142, 66, 8.2, 42],
    [-190, 96, 7.6, 46],
    [-122, 118, 6.2, 38],
    [-176, 36, 5.8, 36],
    [-76, 84, 4.6, 28],
    [-226, 54, 7.4, 48],
    // Far West Rarh Laterite Highlands (রাঢ় লাল টিলা)
    [-345, 78, 9.6, 62],
    [-465, 165, 11.2, 74],
    [-585, 65, 10.4, 72],
    [-395, 295, 9.2, 68],
    [-570, 365, 11.8, 80],
    [-265, 435, 8.6, 66],
    // Far South Sundarban Fringe & Highland Mounds (সুন্দরবন প্রান্ত)
    [-20, 225, 5.8, 56],
    [136, 210, 6.4, 54],
    [-110, 365, 7.4, 64],
    [78, 395, 7.2, 66],
    [-190, 565, 9.2, 76],
    [160, 575, 8.8, 74],
    [15, 645, 7.8, 70],
    // Far East Meadows & Rolling Ridges (পূর্ব প্রান্তর)
    [195, 88, 6.2, 52],
    [325, 52, 7.8, 60],
    [455, 145, 9.4, 68],
    [350, 265, 8.2, 64],
    [555, 295, 10.6, 78],
    [585, 48, 9.0, 68],
    [420, 485, 9.8, 76],
    // North-West Sal Forest Hills & West Forestland across the river
    [-136, -124, 7.2, 40],
    [-188, -162, 8.4, 46],
    [-142, -196, 6.5, 38],
    [-234, -126, 7.8, 48],
    [-355, -175, 9.4, 66],
    [-490, -285, 11.0, 78],
    [-295, -395, 9.2, 68],
    [-565, -490, 11.6, 82],
    [-165, -540, 8.6, 70],
    // North-East Garden Bluffs & Distant Northern Ridges
    [224, -152, 6.6, 54],
    [355, -185, 8.4, 64],
    [255, -345, 9.0, 70],
    [485, -295, 10.4, 76],
    [575, -510, 11.2, 80],
    [85, -460, 7.8, 66],
    [-45, -610, 8.8, 74],
    [310, -590, 9.6, 74],
  ];

  let h = 0;
  for (let i = 0; i < hills.length; i++) {
    const [hx, hz, amp, sigma] = hills[i];
    const dx = x - hx;
    const dz = z - hz;
    const d2 = dx * dx + dz * dz;
    const cutoff = sigma * 3.1;
    if (d2 < cutoff * cutoff) {
      h += amp * Math.exp(-d2 / (2 * sigma * sigma));
    }
  }

  // Natural rolling perimeter ridge framing the outer playable boundary (|x| or |z| > 745)
  const edgeDist = Math.max(Math.abs(x), Math.abs(z));
  if (edgeDist > 745) {
    const rimT = Math.min(1, (edgeDist - 745) / 115);
    h += rimT * rimT * 16.5;
  }

  // Smooth river-edge feather so terrain meets the riverbank cleanly at y = 0
  let edgeMask = 1;
  if (z >= -6 && z < 6) {
    edgeMask = Math.min(edgeMask, (z - -6) / 12);
  } else if (z <= -76 && z > -90) {
    edgeMask = Math.min(edgeMask, (-76 - z) / 14);
  }
  return h * Math.max(0, Math.min(1, edgeMask));
}

/**
 * Computes red-soil laterite blend weight [0..1] for vertex coloring the Sal Forest & Rarh hills.
 */
function sampleLateriteSoilWeight(x: number, z: number, height: number): number {
  const inSwSalbon = x < -46 && x > -680 && z > -10 && z < 490;
  const inNwSalbon = x < -84 && x > -680 && z < -76 && z > -580;
  if (!inSwSalbon && !inNwSalbon) {
    return THREE.MathUtils.clamp((height - 3.6) * 0.11, 0, 0.42);
  }
  const edgeFade = inSwSalbon
    ? THREE.MathUtils.clamp((-46 - x) / 30, 0, 1)
    : THREE.MathUtils.clamp((-84 - x) / 30, 0, 1);
  return THREE.MathUtils.clamp(edgeFade * (0.58 + height * 0.075), 0, 1);
}

/**
 * Builds a subdivided 1000m+ Bengal ground mesh with baked laterite hills & red-soil vertex colors.
 */
function buildTerrainPlane(
  width: number,
  depth: number,
  segX: number,
  segZ: number,
  centerZ: number,
  textures: TextureBundle,
): THREE.Mesh {
  const geo = new THREE.PlaneGeometry(width, depth, segX, segZ);
  geo.rotateX(-Math.PI / 2);

  const pos = geo.attributes.position;
  const colors = new Float32Array(pos.count * 3);
  const grassTint = new THREE.Color(0xedf4e1); // crisp sunny daylight tint over groundMap
  const lateriteTint = new THREE.Color(0xc85c36); // rich Rarh Bengal reddish laterite soil
  const deepLaterite = new THREE.Color(0x9e3e22);
  const tmpColor = new THREE.Color();

  for (let i = 0; i < pos.count; i++) {
    const wx = pos.getX(i);
    const wz = pos.getZ(i) + centerZ;
    const h = sampleLateriteHillHeight(wx, wz);
    pos.setY(i, h);

    const redW = sampleLateriteSoilWeight(wx, wz, h);
    tmpColor.copy(grassTint).lerp(lateriteTint, redW);
    if (h > 4.5 && redW > 0.35) {
      tmpColor.lerp(deepLaterite, Math.min(0.45, (h - 4.5) * 0.1));
    }
    colors[i * 3] = tmpColor.r;
    colors[i * 3 + 1] = tmpColor.g;
    colors[i * 3 + 2] = tmpColor.b;
  }

  geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  geo.computeVertexNormals();

  // Scale UVs cleanly so the tiled ground texture stays crisp across 1180m terrain
  const uv = geo.attributes.uv;
  const repeatX = width / 26;
  const repeatZ = depth / 26;
  for (let i = 0; i < uv.count; i++) {
    uv.setXY(i, uv.getX(i) * repeatX, uv.getY(i) * repeatZ);
  }

  const mat = new THREE.MeshStandardMaterial({
    map: textures.groundMap,
    bumpMap: textures.groundBump,
    bumpScale: 0.12,
    roughness: 0.94,
    metalness: 0.0,
    vertexColors: true,
  });

  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.set(0, 0, centerZ);
  mesh.receiveShadow = true;
  return mesh;
}

/**
 * Builds the two walkable & drivable Howrah Bridge Crossing Approaches connecting the South
 * Village/Ghat bank (z = -11.5, y = 0) up to the Howrah Bridge Deck (z = -35.4..-44.6, y = 6.58)
 * and down onto the North Bank (z = -72.0, y = 0) straight into Old Tram Depot & Bazaar.
 */
function buildBridgeCrossingRamps(): THREE.Group {
  const group = new THREE.Group();
  const deckY = 6.58;
  const rampWidth = 8.0;

  const asphaltMat = new THREE.MeshStandardMaterial({
    color: 0x3f4348,
    roughness: 0.88,
    metalness: 0.06,
  });
  const railMat = new THREE.MeshStandardMaterial({
    color: 0x8e9aa3,
    roughness: 0.48,
    metalness: 0.72,
  });
  const pierMat = new THREE.MeshStandardMaterial({
    color: 0x8e8173,
    roughness: 0.92,
  });
  const stripeMat = new THREE.MeshStandardMaterial({
    color: 0xf4d268,
    roughness: 0.7,
  });

  const laneCenters = [-17.5, 17.5]; // Each 8m wide: [-21.5, -13.5] and [13.5, 21.5]

  const addSlopedSpan = (cx: number, z0: number, y0: number, z1: number, y1: number) => {
    const dz = z1 - z0;
    const dy = y1 - y0;
    const len = Math.hypot(dz, dy);
    const pitch = Math.atan2(dy, dz); // Note: Three.js BoxGeometry rotated around X

    const span = new THREE.Group();
    span.position.set(cx, (y0 + y1) * 0.5, (z0 + z1) * 0.5);
    span.rotation.x = -pitch;

    const slab = new THREE.Mesh(new THREE.BoxGeometry(rampWidth, 0.55, len + 0.4), asphaltMat);
    slab.position.y = -0.275;
    slab.castShadow = true;
    slab.receiveShadow = true;
    span.add(slab);

    // Center dashed yellow road stripe
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.03, len - 1.2), stripeMat);
    stripe.position.y = 0.02;
    span.add(stripe);

    // Twin steel safety guardrails
    for (const sx of [-rampWidth * 0.5 + 0.2, rampWidth * 0.5 - 0.2]) {
      const curb = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.95, len + 0.2), railMat);
      curb.position.set(sx, 0.45, 0);
      curb.castShadow = true;
      span.add(curb);
    }

    group.add(span);

    // Masonry support piers underneath the elevated approach span
    for (const t of [0.38, 0.74]) {
      const pz = THREE.MathUtils.lerp(z0, z1, t);
      const py = THREE.MathUtils.lerp(y0, y1, t);
      if (py > 1.2) {
        const pier = new THREE.Mesh(new THREE.BoxGeometry(rampWidth - 1.2, py + 1.8, 1.3), pierMat);
        pier.position.set(cx, (py - 1.8) * 0.5, pz);
        pier.castShadow = true;
        group.add(pier);
      }
    }
  };

  for (const cx of laneCenters) {
    // South approach ramp: Village Ghat (z = -11.5, y = 0) up to Bridge Deck (z = -35.4, y = 6.58)
    addSlopedSpan(cx, -11.5, 0.0, -35.4, deckY);
    // North descent ramp: Bridge Deck (z = -44.6, y = 6.58) down to Tram Depot Bank (z = -72.0, y = 0)
    addSlopedSpan(cx, -44.6, deckY, -72.0, 0.0);
  }

  return group;
}

/**
 * Analytical elevation for the Howrah Bridge deck and its North/South crossing ramps.
 * Returns null if (x, z) is not on a crossing ramp or bridge deck.
 */
function sampleBridgeCrossingHeight(x: number, z: number): number | null {
  const deckY = 6.58;
  const onWestLane = x >= -21.5 && x <= -13.5;
  const onEastLane = x >= 13.5 && x <= 21.5;

  // Main Howrah Bridge East-West deck (walkable across the iconic steel span!)
  if (x >= -66 && x <= 66 && z <= -35.2 && z >= -44.8) {
    return deckY;
  }

  if (onWestLane || onEastLane) {
    // South ramp: z from -11.5 (y=0) to -35.4 (y=6.58)
    if (z <= -11.5 && z >= -35.4) {
      const t = THREE.MathUtils.clamp((-11.5 - z) / (-11.5 - -35.4), 0, 1);
      return t * deckY;
    }
    // North ramp: z from -44.6 (y=6.58) down to -72.0 (y=0)
    if (z <= -44.6 && z >= -72.0) {
      const t = THREE.MathUtils.clamp((-44.6 - z) / (-44.6 - -72.0), 0, 1);
      return (1 - t) * deckY;
    }
  }

  return null;
}

/**
 * Builds the expanded 1000x1000 West Bengal Hooghly Riverbank Battle Royale World
 * featuring the Village, Howrah Bridge, Red-Soil Sal Forest & Hills, Abandoned Zamindar Bari,
 * Old Tram Depot & Bazaar, and Extended Riverbank Ghat with Wooden Boats.
 */
export function buildWestBengalWorld(textures: TextureBundle): WorldBuildResult {
  const worldGroup = new THREE.Group();
  const boxColliders: BoxCollider[] = [];
  const circleColliders: CircleCollider[] = [];
  const swayingPalms: SwayingPalm[] = [];
  const bobbingBoats: THREE.Group[] = [];
  const landmarkChestAnchors: ChestAnchor[] = [];
  const landmarkSanjibaniAnchors: Array<{ x: number; z: number }> = [];

  // 1. Bright sunny daytime sky dome (radius 1950 encompasses expanded 1520x1520 map & 820u Safe Zone cleanly)
  const skyGeo = new THREE.SphereGeometry(1950, 32, 20);
  const skyMat = new THREE.MeshBasicMaterial({
    map: textures.skyMap,
    side: THREE.BackSide,
    fog: false,
    depthWrite: false,
  });
  const skyDome = new THREE.Mesh(skyGeo, skyMat);
  worldGroup.add(skyDome);

  // 2. Expanded 1520x1520+ Playable Subdivided Terrain (South Bank z=-20..+860 + North Bank z=-950..-70)
  const southTerrain = buildTerrainPlane(1840, 880, 128, 68, 420, textures);
  worldGroup.add(southTerrain);

  const northTerrain = buildTerrainPlane(1840, 880, 128, 68, -510, textures);
  worldGroup.add(northTerrain);

  // Distant Kolkata skyline silhouettes pushed behind the expanded North perimeter (z = -805..-855)
  const skylineMat = new THREE.MeshStandardMaterial({
    color: 0x6f7582,
    roughness: 0.88,
    metalness: 0.05,
  });
  for (let i = -18; i <= 18; i++) {
    const h = 14 + ((Math.abs(i * 7 + 3) % 6) * 5.2);
    const w = 14 + ((Math.abs(i * 3) % 4) * 4.5);
    const bldg = new THREE.Mesh(new THREE.BoxGeometry(w, h, 14), skylineMat);
    bldg.position.set(i * 34, h * 0.5, -812 - (Math.abs(i) % 4) * 16);
    worldGroup.add(bldg);
  }

  // Dusty red-earth village lanes & connecting heritage roads to Sal Forest (West) and Zamindar Bari (East)
  const roadMat = new THREE.MeshStandardMaterial({
    color: 0xa5744a,
    roughness: 0.96,
    metalness: 0.0,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const mainLane = new THREE.Mesh(new THREE.PlaneGeometry(7.2, 54), roadMat);
  mainLane.rotation.x = -Math.PI / 2;
  mainLane.position.set(0, 0.03, 12);
  mainLane.receiveShadow = true;
  worldGroup.add(mainLane);

  // Extended East-West Heritage Road connecting Sal Forest (x = -124) <-> Village <-> Zamindar Bari (x = 78)
  const crossLane = new THREE.Mesh(new THREE.PlaneGeometry(202, 6.4), roadMat);
  crossLane.rotation.x = -Math.PI / 2;
  crossLane.position.set(-23, 0.035, 7);
  crossLane.receiveShadow = true;
  worldGroup.add(crossLane);

  // Branch drive leading into the Zamindar Bari grand West Portico (x = 76, z = 7 -> 22)
  const zamindarDrive = new THREE.Mesh(new THREE.PlaneGeometry(6.4, 24), roadMat);
  zamindarDrive.rotation.x = -Math.PI / 2;
  zamindarDrive.position.set(74, 0.038, 15);
  zamindarDrive.receiveShadow = true;
  worldGroup.add(zamindarDrive);

  // 3. Hooghly River Ghat Embankments (South + North Bank spanning full 1840m width) + Central Stone Steps
  const ghatStoneMat = new THREE.MeshStandardMaterial({
    color: 0x9b8d7e,
    roughness: 0.88,
    metalness: 0.04,
  });
  const embankment = new THREE.Mesh(new THREE.BoxGeometry(1840, 2.2, 4.2), ghatStoneMat);
  embankment.position.set(0, -0.95, -18.2);
  embankment.receiveShadow = true;
  worldGroup.add(embankment);

  const northEmbankment = new THREE.Mesh(new THREE.BoxGeometry(1840, 2.2, 4.2), ghatStoneMat);
  northEmbankment.position.set(0, -0.95, -71.5);
  northEmbankment.receiveShadow = true;
  worldGroup.add(northEmbankment);

  // Central Ghat descending steps
  for (let s = 0; s < 5; s++) {
    const step = new THREE.Mesh(new THREE.BoxGeometry(20, 0.36, 1.1), ghatStoneMat);
    step.position.set(0, -0.18 - s * 0.28, -19.2 - s * 0.95);
    step.receiveShadow = true;
    worldGroup.add(step);
  }

  // Low heritage Bengal red-brick parapet walls flanking center ghat (leaving bridge ramp portals open!)
  const parapetMat = new THREE.MeshStandardMaterial({
    color: 0x9a4b35,
    roughness: 0.85,
  });
  for (const side of [-1, 1]) {
    const wall = new THREE.Mesh(new THREE.BoxGeometry(16, 0.9, 0.6), parapetMat);
    wall.position.set(side * 30.5, 0.45, -17.6);
    wall.castShadow = true;
    wall.receiveShadow = true;
    worldGroup.add(wall);
  }

  // 4. Shimmering Hooghly River water spanning full 1840m East-West map width
  const waterUniforms = { uTime: { value: 0 } };
  const waterMat = new THREE.MeshStandardMaterial({
    color: 0x266578,
    roughness: 0.18,
    metalness: 0.4,
    bumpMap: textures.waterBump,
    bumpScale: 0.16,
  });
  waterMat.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = waterUniforms.uTime;
    shader.vertexShader =
      `uniform float uTime;\n` +
      shader.vertexShader.replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
         float waveA = sin(position.x * 0.14 + uTime * 1.45) * 0.11;
         float waveB = cos(position.y * 0.22 - uTime * 1.15) * 0.08;
         transformed.z += waveA + waveB;`,
      );
  };
  const riverMesh = new THREE.Mesh(new THREE.PlaneGeometry(1840, 56, 84, 16), waterMat);
  riverMesh.rotation.x = -Math.PI / 2;
  riverMesh.position.set(0, -1.25, -45);
  riverMesh.receiveShadow = true;
  worldGroup.add(riverMesh);

  // Original floating wooden country boat (Nouka) near the central ghat
  const boatGroup = buildRiverBoat();
  boatGroup.position.set(-8.5, -1.18, -26.2);
  boatGroup.rotation.y = 0.22;
  worldGroup.add(boatGroup);
  bobbingBoats.push(boatGroup);

  // 5. Iconic Howrah-style Cantilever Bridge + Walkable/Drivable North-South Crossing Ramps
  const bridge = buildHowrahBridge(textures);
  worldGroup.add(bridge);

  const crossingRamps = buildBridgeCrossingRamps();
  worldGroup.add(crossingRamps);

  // 6. Iconic Kolkata Yellow Ambassador Taxi parked near the village ghat road
  const taxi = buildYellowTaxi(textures);
  taxi.position.set(7.2, 0, -4.5);
  taxi.rotation.y = -0.35;
  worldGroup.add(taxi);
  circleColliders.push(
    { x: 6.1, z: -4.9, radius: 1.4, height: 1.85, kind: 'taxi' },
    { x: 8.3, z: -4.1, radius: 1.4, height: 1.85, kind: 'taxi' },
  );

  // 7. Village Mud Houses (Matir Ghor) arranged around the village square
  const houseSpecs = [
    { x: -16.5, z: -5.0, rotY: 0.35, w: 6.2, d: 4.8 },
    { x: -18.5, z: 14.5, rotY: 1.25, w: 6.6, d: 5.0 },
    { x: 18.0, z: 13.5, rotY: -1.35, w: 6.4, d: 5.0 },
    { x: -7.5, z: 26.5, rotY: 0.15, w: 6.2, d: 4.8 },
    { x: 11.5, z: 26.0, rotY: -0.25, w: 6.4, d: 5.0 },
    { x: 24.5, z: -5.5, rotY: -0.7, w: 6.0, d: 4.8 },
  ];

  for (const hs of houseSpecs) {
    const house = buildMudHouse(textures, hs.w, hs.d, 3.0);
    house.position.set(hs.x, 0, hs.z);
    house.rotation.y = hs.rotY;
    worldGroup.add(house);

    const approxR = Math.max(hs.w, hs.d) * 0.56;
    circleColliders.push({
      x: hs.x,
      z: hs.z,
      radius: approxR,
      height: 4.5,
      kind: 'house',
    });
  }

  // 8. Coconut Palm Trees (Narkel Gach) inside the village + scenic flanking groves
  const innerPalms: [number, number, number, number, number][] = [
    [-11.0, -13.5, 10.2, 1.2, -0.8],
    [11.4, -13.0, 9.6, -1.0, -0.9],
    [-25.5, -12.0, 10.8, 1.4, -0.4],
    [25.5, -12.5, 9.8, -1.2, 0.5],
    [-11.0, 4.5, 9.2, 0.9, 0.7],
    [13.0, 4.8, 10.4, -1.1, 0.6],
    [-26.0, 5.5, 10.6, 1.3, 0.4],
    [26.5, 5.0, 9.5, -0.9, -0.5],
    [-15.0, 23.0, 9.8, 0.7, 1.1],
    [2.5, 22.5, 10.5, -0.8, 0.9],
    [21.5, 23.5, 9.6, -1.0, 0.8],
    [-26.5, 22.0, 11.0, 1.1, -0.7],
  ];

  innerPalms.forEach(([x, z, h, lx, lz], idx) => {
    const { group, crown } = buildCoconutTree(textures, h, lx, lz);
    group.position.set(x, 0, z);
    worldGroup.add(group);
    swayingPalms.push({
      crown,
      phase: idx * 1.17,
      baseRotX: 0,
      baseRotZ: 0,
    });
    circleColliders.push({ x, z, radius: 0.62, height: h, kind: 'tree' });
  });

  // Outer Bengal village palms (keeping East/West heritage road corridors open!)
  for (let i = 0; i < 24; i++) {
    const angle = (i / 24) * Math.PI * 1.35 - Math.PI * 0.175;
    const radius = 38 + (i % 3) * 5;
    const x = Math.cos(angle) * radius;
    const z = Math.sin(angle) * radius + 10;
    if (z < -15) continue;
    if (z > 1 && z < 13) continue; // Keep westbound & eastbound landmark roads open
    const h = 9.0 + (i % 4) * 1.4;
    const { group, crown } = buildCoconutTree(
      textures,
      h,
      Math.cos(i) * 1.2,
      Math.sin(i) * 1.0,
    );
    group.position.set(x, sampleLateriteHillHeight(x, z), z);
    worldGroup.add(group);
    swayingPalms.push({ crown, phase: i * 0.73, baseRotX: 0, baseRotZ: 0 });
  }

  // 9. Instanced tropical bushes & hibiscus shrubs around village houses
  const bushCount = 68;
  const bushGeo = new THREE.DodecahedronGeometry(0.95, 1);
  const bushMat = new THREE.MeshStandardMaterial({
    color: 0x3b6e28,
    roughness: 0.88,
    metalness: 0.0,
  });
  const bushes = new THREE.InstancedMesh(bushGeo, bushMat, bushCount);
  const dummy = new THREE.Object3D();
  const color = new THREE.Color();
  const bushPalette = [0x336522, 0x457b2d, 0x2a561e, 0x558432];

  let bIdx = 0;
  for (let i = 0; i < bushCount; i++) {
    const isOuter = i >= 22;
    let bx: number;
    let bz: number;
    if (isOuter) {
      const a = ((i - 22) / (bushCount - 22)) * Math.PI * 1.32 - Math.PI * 0.16;
      const r = 34.5 + (i % 4) * 2.4;
      bx = Math.cos(a) * r;
      bz = Math.sin(a) * r + 10;
      if (bz < -15.5) bz = 36 + (i % 5) * 2;
      if (bz > 1.5 && bz < 12.5) bz += 10; // Clear roads
    } else {
      const hs = houseSpecs[i % houseSpecs.length];
      const ang = (i * 2.1) % (Math.PI * 2);
      bx = hs.x + Math.cos(ang) * 4.4;
      bz = hs.z + Math.sin(ang) * 4.2;
    }
    const s = 0.65 + (i % 5) * 0.22;
    const by = sampleLateriteHillHeight(bx, bz);
    dummy.position.set(bx, by + s * 0.55, bz);
    dummy.rotation.set(0, i * 0.9, 0);
    dummy.scale.set(s * 1.25, s * 0.78, s * 1.15);
    dummy.updateMatrix();
    bushes.setMatrixAt(bIdx, dummy.matrix);
    color.setHex(bushPalette[i % bushPalette.length]);
    bushes.setColorAt(bIdx, color);
    bIdx++;
  }
  bushes.instanceMatrix.needsUpdate = true;
  if (bushes.instanceColor) bushes.instanceColor.needsUpdate = true;
  bushes.computeBoundingSphere();
  worldGroup.add(bushes);

  // 10. Low tactical village crate cover clusters in the open square
  const crateMat = new THREE.MeshStandardMaterial({
    color: 0x8b623c,
    roughness: 0.88,
  });
  const coverPositions: [number, number, number][] = [
    [-6.5, 4.5, 0.2],
    [5.8, 14.5, -0.4],
    [-4.5, -10.5, 0.1],
  ];
  for (const [cx, cz, rot] of coverPositions) {
    const cluster = new THREE.Group();
    cluster.position.set(cx, 0, cz);
    cluster.rotation.y = rot;

    const c1 = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.95, 1.0), crateMat);
    c1.position.set(0, 0.475, 0);
    c1.castShadow = true;
    c1.receiveShadow = true;
    cluster.add(c1);

    const c2 = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.78, 0.95), crateMat);
    c2.position.set(1.15, 0.39, 0.15);
    c2.rotation.y = 0.25;
    c2.castShadow = true;
    cluster.add(c2);

    addContactShadow(cluster, textures.contactShadowMap, 3.2, 2.0, 0.42);
    worldGroup.add(cluster);
    circleColliders.push({ x: cx + 0.35, z: cz, radius: 1.35, height: 1.0, kind: 'prop' });
  }

  // ============================================================================
  // 11. FOUR EXPANDED WEST BENGAL LANDMARKS ACROSS THE 1000x1000 ARENA
  // ============================================================================

  // Landmark 1: শালবন ও লাল মাটির টিলা (Red-Soil Sal Forest & Hills — West / NW Sector)
  const salForest = buildSalForestAndHills(sampleLateriteHillHeight);
  worldGroup.add(salForest.group);
  circleColliders.push(...salForest.colliders);
  landmarkSanjibaniAnchors.push(...salForest.sanjibaniAnchors);
  landmarkChestAnchors.push(...salForest.chestAnchors);

  // Landmark 2: পুরনো জমিদার বাড়ি (Abandoned Zamindar Bari — East / NE Sector)
  const zamindarCenterX = 98;
  const zamindarCenterZ = 22;
  const zamindarBari = buildZamindarBari(zamindarCenterX, zamindarCenterZ);
  worldGroup.add(zamindarBari.group);
  circleColliders.push(...zamindarBari.colliders);
  landmarkChestAnchors.push(...zamindarBari.chestAnchors);
  landmarkSanjibaniAnchors.push(...zamindarBari.sanjibaniAnchors);

  // Landmark 3: পুরনো ট্রাম ডিপো ও বাজার (Old Tram Depot & Bazaar — North Bank across Bridge)
  const tramDepotCenterX = 0;
  const tramDepotCenterZ = -124;
  const tramDepot = buildOldTramDepotAndBazaar(tramDepotCenterX, tramDepotCenterZ, () =>
    buildYellowTaxi(textures),
  );
  worldGroup.add(tramDepot.group);
  circleColliders.push(...tramDepot.colliders);
  landmarkChestAnchors.push(...tramDepot.chestAnchors);
  landmarkSanjibaniAnchors.push(...tramDepot.sanjibaniAnchors);

  // Landmark 4: নদীর বাঁধানো ঘাট ও নৌকা (Extended Riverbank Ghat, Moored Boats & Huts)
  const extendedGhat = buildExtendedRiverGhat(buildRiverBoat);
  worldGroup.add(extendedGhat.group);
  circleColliders.push(...extendedGhat.colliders);
  bobbingBoats.push(...extendedGhat.bobbingBoats);
  landmarkChestAnchors.push(...extendedGhat.chestAnchors);
  landmarkSanjibaniAnchors.push(...extendedGhat.sanjibaniAnchors);

  // ============================================================================
  // 12. EXPANDED COUNTRYSIDE GROVES, FOLIAGE, ROCKS, COVER WALLS & OUTER OUTPOSTS
  //     (Batched via InstancedMesh for rock-solid mobile FPS across 1520x1520 map!)
  // ============================================================================
  const isBlockedForCountryside = (x: number, z: number): boolean => {
    // Keep Hooghly River, embankments, Village Square, Zamindar Bari, Tram Depot & roads open
    if (z > -82 && z < -8) return true;
    if (x > -52 && x < 58 && z >= -20 && z < 52) return true; // Village Square
    if (x > 60 && x < 142 && z > -16 && z < 64) return true; // Zamindar Bari
    if (x > -94 && x < 94 && z < -68 && z > -206) return true; // Old Tram Depot & Bazaar
    if (x > -135 && x < 82 && z > 0 && z < 14) return true; // Main East-West heritage road
    return false;
  };

  // Deterministic pseudo-random helper for repeatable organic Bengal landscape scatter
  let scatterSeed = 42197;
  const nextRand = () => {
    scatterSeed = (scatterSeed * 1664525 + 1013904223) >>> 0;
    return scatterSeed / 4294967296;
  };

  // 12a. Instanced Bengal Countryside Groves & Perimeter Forest (540 trees in just 2 draw calls!)
  const maxCountrysideTrees = 540;
  const oTrunkGeo = new THREE.CylinderGeometry(0.36, 0.58, 11.4, 6);
  oTrunkGeo.translate(0, 5.7, 0);
  const oCrownGeo = new THREE.DodecahedronGeometry(3.6, 1);
  const oTrunkMat = new THREE.MeshStandardMaterial({ color: 0x5d4634, roughness: 0.94 });
  const oCrownMat = new THREE.MeshStandardMaterial({ color: 0x39702c, roughness: 0.86 });
  const outerTrunks = new THREE.InstancedMesh(oTrunkGeo, oTrunkMat, maxCountrysideTrees);
  const outerCrowns = new THREE.InstancedMesh(oCrownGeo, oCrownMat, maxCountrysideTrees);
  const crownPalette = [0x2e6324, 0x3d752e, 0x4b7f32, 0x295721, 0x548536];

  let otPlaced = 0;
  // Clustered natural groves in playable countryside (r = 95..725)
  const groveCenters: Array<[number, number, number]> = [
    [-240, 150, 58],
    [-380, 95, 72],
    [-510, 220, 82],
    [-310, 340, 68],
    [-160, 290, 64],
    [-460, 480, 78],
    [-95, 495, 74],
    [70, 265, 62],
    [185, 165, 58],
    [310, 85, 68],
    [455, 195, 76],
    [290, 345, 70],
    [540, 395, 82],
    [135, 515, 72],
    [390, 560, 76],
    [-255, -245, 68],
    [-435, -185, 76],
    [-515, -395, 82],
    [-215, -455, 74],
    [215, -195, 66],
    [395, -235, 74],
    [285, -430, 72],
    [525, -415, 80],
    [35, -345, 68],
    [-55, -565, 76],
  ];

  for (const [gx, gz, gRadius] of groveCenters) {
    const treesInGrove = 12;
    for (let j = 0; j < treesInGrove && otPlaced < 320; j++) {
      const ang = nextRand() * Math.PI * 2;
      const dist = Math.sqrt(nextRand()) * gRadius;
      const tx = gx + Math.cos(ang) * dist;
      const tz = gz + Math.sin(ang) * dist;
      if (Math.abs(tx) > 730 || Math.abs(tz) > 730) continue;
      if (isBlockedForCountryside(tx, tz)) continue;
      const ty = sampleLateriteHillHeight(tx, tz);
      const sc = 0.82 + nextRand() * 0.42;

      dummy.position.set(tx, ty - 0.25, tz);
      dummy.rotation.set(0, nextRand() * Math.PI * 2, 0);
      dummy.scale.set(sc, sc * (0.9 + nextRand() * 0.25), sc);
      dummy.updateMatrix();
      outerTrunks.setMatrixAt(otPlaced, dummy.matrix);

      dummy.position.set(tx, ty + 10.2 * sc, tz);
      dummy.scale.set(sc * (1.05 + nextRand() * 0.22), sc * (0.82 + nextRand() * 0.2), sc * (1.05 + nextRand() * 0.22));
      dummy.updateMatrix();
      outerCrowns.setMatrixAt(otPlaced, dummy.matrix);
      color.setHex(crownPalette[otPlaced % crownPalette.length]);
      outerCrowns.setColorAt(otPlaced, color);

      // Register real trunk cover colliders on every 3rd grove tree to keep collision loop super lean on mobile
      if (j % 3 === 0) {
        circleColliders.push({ x: tx, z: tz, radius: 0.72 * sc, height: 10 * sc, kind: 'tree' });
      }
      otPlaced++;
    }
  }

  // Lush outer perimeter woodland rim (r = 745..865) framing the horizon naturally
  for (let i = 0; i < 300 && otPlaced < maxCountrysideTrees; i++) {
    const a = (i / 240) * Math.PI * 2 + (i % 7) * 0.11;
    const rad = 750 + nextRand() * 115;
    const tx = Math.cos(a) * rad;
    const tz = Math.sin(a) * rad;
    if (tz > -84 && tz < -10) continue;
    const ty = sampleLateriteHillHeight(tx, tz);
    const sc = 0.95 + nextRand() * 0.48;
    dummy.position.set(tx, ty - 0.3, tz);
    dummy.rotation.set(0, a, 0);
    dummy.scale.set(sc, sc, sc);
    dummy.updateMatrix();
    outerTrunks.setMatrixAt(otPlaced, dummy.matrix);

    dummy.position.set(tx, ty + 10.6 * sc, tz);
    dummy.scale.set(sc * 1.18, sc * 0.92, sc * 1.18);
    dummy.updateMatrix();
    outerCrowns.setMatrixAt(otPlaced, dummy.matrix);
    color.setHex(crownPalette[otPlaced % crownPalette.length]);
    outerCrowns.setColorAt(otPlaced, color);
    otPlaced++;
  }
  outerTrunks.count = otPlaced;
  outerCrowns.count = otPlaced;
  outerTrunks.instanceMatrix.needsUpdate = true;
  outerCrowns.instanceMatrix.needsUpdate = true;
  if (outerCrowns.instanceColor) outerCrowns.instanceColor.needsUpdate = true;
  outerTrunks.computeBoundingSphere();
  outerCrowns.computeBoundingSphere();
  worldGroup.add(outerTrunks, outerCrowns);

  // 12b. Wild Countryside Scrub & Fern Bushes (220 instances, 1 draw call)
  const wildBushCount = 220;
  const wildBushes = new THREE.InstancedMesh(bushGeo, bushMat, wildBushCount);
  let wbPlaced = 0;
  for (let i = 0; i < wildBushCount * 2 && wbPlaced < wildBushCount; i++) {
    const bx = (nextRand() - 0.5) * 1420;
    const bz = (nextRand() - 0.5) * 1420;
    if (isBlockedForCountryside(bx, bz)) continue;
    const s = 0.85 + nextRand() * 0.85;
    const by = sampleLateriteHillHeight(bx, bz);
    dummy.position.set(bx, by + s * 0.48, bz);
    dummy.rotation.set(0, nextRand() * Math.PI * 2, 0);
    dummy.scale.set(s * 1.35, s * 0.82, s * 1.25);
    dummy.updateMatrix();
    wildBushes.setMatrixAt(wbPlaced, dummy.matrix);
    color.setHex(bushPalette[wbPlaced % bushPalette.length]);
    wildBushes.setColorAt(wbPlaced, color);
    wbPlaced++;
  }
  wildBushes.count = wbPlaced;
  wildBushes.instanceMatrix.needsUpdate = true;
  if (wildBushes.instanceColor) wildBushes.instanceColor.needsUpdate = true;
  wildBushes.computeBoundingSphere();
  worldGroup.add(wildBushes);

  // 12c. Tactical Laterite Boulders & Rock Outcrops (92 instances with solid cover colliders, 1 draw call)
  const rockCount = 92;
  const rockGeo = new THREE.DodecahedronGeometry(1.45, 0);
  const rockMat = new THREE.MeshStandardMaterial({
    color: 0x8f6b54,
    roughness: 0.92,
    metalness: 0.04,
  });
  const rocks = new THREE.InstancedMesh(rockGeo, rockMat, rockCount);
  const rockPalette = [0x8b6750, 0x7b5a46, 0x9b543a, 0x756c63];
  let rPlaced = 0;
  for (let i = 0; i < rockCount * 3 && rPlaced < rockCount; i++) {
    const rx = (nextRand() - 0.5) * 1360;
    const rz = (nextRand() - 0.5) * 1360;
    if (isBlockedForCountryside(rx, rz)) continue;
    const sc = 0.9 + nextRand() * 0.95;
    const ry = sampleLateriteHillHeight(rx, rz);
    dummy.position.set(rx, ry + sc * 0.72, rz);
    dummy.rotation.set(nextRand() * 0.5, nextRand() * Math.PI * 2, nextRand() * 0.5);
    dummy.scale.set(sc * 1.35, sc * 0.95, sc * 1.15);
    dummy.updateMatrix();
    rocks.setMatrixAt(rPlaced, dummy.matrix);
    color.setHex(rockPalette[rPlaced % rockPalette.length]);
    rocks.setColorAt(rPlaced, color);
    circleColliders.push({
      x: rx,
      z: rz,
      radius: 1.55 * sc,
      height: 1.9 * sc,
      kind: 'boulder',
    });
    rPlaced++;
  }
  rocks.count = rPlaced;
  rocks.instanceMatrix.needsUpdate = true;
  if (rocks.instanceColor) rocks.instanceColor.needsUpdate = true;
  rocks.computeBoundingSphere();
  worldGroup.add(rocks);

  // 12d. Weathered Bengal Red-Brick Tactical Cover Walls scattered across clearings & trails (40 instances, 1 draw call)
  const wallCoverCount = 40;
  const coverWallGeo = new THREE.BoxGeometry(4.4, 1.45, 0.75);
  const coverWallMat = new THREE.MeshStandardMaterial({
    color: 0x9c533c,
    roughness: 0.9,
    metalness: 0.02,
  });
  const coverWalls = new THREE.InstancedMesh(coverWallGeo, coverWallMat, wallCoverCount);
  let wPlaced = 0;
  for (let i = 0; i < wallCoverCount * 3 && wPlaced < wallCoverCount; i++) {
    const wx = (nextRand() - 0.5) * 1240;
    const wz = (nextRand() - 0.5) * 1240;
    if (isBlockedForCountryside(wx, wz)) continue;
    const wy = sampleLateriteHillHeight(wx, wz);
    const rot = nextRand() * Math.PI;
    dummy.position.set(wx, wy + 0.7, wz);
    dummy.rotation.set(0, rot, 0);
    dummy.scale.set(0.9 + nextRand() * 0.35, 0.9 + nextRand() * 0.25, 1);
    dummy.updateMatrix();
    coverWalls.setMatrixAt(wPlaced, dummy.matrix);
    circleColliders.push({ x: wx, z: wz, radius: 1.95, height: 1.5, kind: 'prop' });
    wPlaced++;
  }
  coverWalls.count = wPlaced;
  coverWalls.instanceMatrix.needsUpdate = true;
  coverWalls.computeBoundingSphere();
  worldGroup.add(coverWalls);

  // 12e. Outer Rural Bengal Outpost Mud Huts + Reward Chests & Sanjibani Herbs across expanded quadrants
  const outerOutposts: Array<{ x: number; z: number; rotY: number }> = [
    { x: -245, z: 185, rotY: 0.5 },
    { x: -415, z: 270, rotY: 1.1 },
    { x: -115, z: 340, rotY: -0.3 },
    { x: 165, z: 280, rotY: -0.9 },
    { x: 345, z: 135, rotY: -1.4 },
    { x: 425, z: 365, rotY: 2.3 },
    { x: -285, z: -265, rotY: 0.8 },
    { x: 265, z: -255, rotY: -0.7 },
  ];
  for (const op of outerOutposts) {
    const oy = sampleLateriteHillHeight(op.x, op.z);
    const hut = buildMudHouse(textures, 6.2, 4.8, 3.0);
    hut.position.set(op.x, oy, op.z);
    hut.rotation.y = op.rotY;
    worldGroup.add(hut);
    circleColliders.push({ x: op.x, z: op.z, radius: 3.55, height: 4.5, kind: 'house' });
    // Place a Warrior Loot Chest & Sanjibani herb outside each distant rural outpost
    const frontX = op.x + Math.sin(op.rotY) * 5.2;
    const frontZ = op.z + Math.cos(op.rotY) * 5.2;
    landmarkChestAnchors.push({
      x: frontX,
      y: sampleLateriteHillHeight(frontX, frontZ),
      z: frontZ,
      rotY: op.rotY + Math.PI,
    });
    landmarkSanjibaniAnchors.push({
      x: op.x - Math.cos(op.rotY) * 6.0,
      z: op.z + Math.sin(op.rotY) * 6.0,
    });
  }

  // Unified Analytical Ground Elevation (Bridge Deck/Ramps + Zamindar Bari Stairs/Terrace + Laterite Hills)
  const getGroundHeight = (x: number, z: number, currentY?: number): number => {
    const bridgeY = sampleBridgeCrossingHeight(x, z);
    if (bridgeY !== null) return bridgeY;

    const zamindarY = zamindarBari.getTerraceHeight(x, z, currentY);
    if (zamindarY > 0) return zamindarY;

    return sampleLateriteHillHeight(x, z);
  };

  // Water collision test: blocks wading into deep Hooghly River except along bridge deck & crossing ramps
  const isWaterBlocked = (x: number, z: number): boolean => {
    if (z <= -70.5 || z >= -20.5) return false;
    return sampleBridgeCrossingHeight(x, z) === null;
  };

  // Dynamic Bengali Area Name for Top HUD Location Badge across the expanded 1520x1520 Bengal world
  const getLocationName = (x: number, z: number, currentY?: number): string => {
    const onBridge = sampleBridgeCrossingHeight(x, z) !== null;
    if (onBridge && (z < -17 || (currentY !== undefined && currentY > 1.2))) {
      return 'হাওড়া সেতু';
    }
    if (z < -70) {
      if (z < -200 && x >= 0) return 'উত্তর বাগানবাড়ি';
      if (z < -200 && x < 0) return 'পশ্চিম বনাঞ্চল';
      if (x < -86) return 'শালবন';
      return 'ট্রাম ডিপো';
    }
    if (z >= -23 && z <= -9.5 && Math.abs(x) <= 185) {
      return 'নদীর ঘাট';
    }
    if (z > 185) {
      if (x < -215) return 'রাঢ় লাল টিলা';
      if (x > 215) return 'পূর্ব প্রান্তর';
      return 'সুন্দরবন প্রান্ত';
    }
    if (x > 64 && x < 144 && z > -14 && z < 64) {
      return 'জমিদার বাড়ি';
    }
    if (x > 165) {
      return 'পূর্ব প্রান্তর';
    }
    if (x < -215) {
      return 'রাঢ় লাল টিলা';
    }
    if (x < -46) {
      return 'শালবন';
    }
    return 'বাংলার গ্রাম';
  };

  // Enemy spawn points broadly distributed across Village outskirts, 4 landmarks & expanded outer Bengal biomes
  const enemySpawnPoints = [
    // Village Perimeter & Riverbank Flanks
    new THREE.Vector3(-42, 0, -11),
    new THREE.Vector3(44, 0, -11),
    new THREE.Vector3(-46, 0, 26),
    new THREE.Vector3(48, 0, 24),
    new THREE.Vector3(-12, 0, 56),
    new THREE.Vector3(24, 0, 62),
    new THREE.Vector3(-68, 0, -13),
    new THREE.Vector3(72, 0, -13),
    // Sal Forest & Red-Soil Hills
    new THREE.Vector3(-92, sampleLateriteHillHeight(-92, 34), 34),
    new THREE.Vector3(-148, sampleLateriteHillHeight(-148, 72), 72),
    new THREE.Vector3(-210, sampleLateriteHillHeight(-210, 128), 128),
    new THREE.Vector3(-315, sampleLateriteHillHeight(-315, 92), 92),
    new THREE.Vector3(-385, sampleLateriteHillHeight(-385, 225), 225),
    new THREE.Vector3(-255, sampleLateriteHillHeight(-255, 290), 290),
    // Abandoned Zamindar Bari & East Meadows
    new THREE.Vector3(74, 0, 22),
    new THREE.Vector3(118, 0, 24),
    new THREE.Vector3(185, sampleLateriteHillHeight(185, 76), 76),
    new THREE.Vector3(285, sampleLateriteHillHeight(285, 42), 42),
    new THREE.Vector3(365, sampleLateriteHillHeight(365, 165), 165),
    new THREE.Vector3(250, sampleLateriteHillHeight(250, 265), 265),
    new THREE.Vector3(430, sampleLateriteHillHeight(430, 310), 310),
    // Far South Sundarban Fringe
    new THREE.Vector3(-95, sampleLateriteHillHeight(-95, 195), 195),
    new THREE.Vector3(42, sampleLateriteHillHeight(42, 225), 225),
    new THREE.Vector3(-145, sampleLateriteHillHeight(-145, 345), 345),
    new THREE.Vector3(125, sampleLateriteHillHeight(125, 365), 365),
    new THREE.Vector3(-20, sampleLateriteHillHeight(-20, 440), 440),
    // North Bank: Old Tram Depot, West Forestland & North Garden Estates
    new THREE.Vector3(-24, 0, -104),
    new THREE.Vector3(26, 0, -112),
    new THREE.Vector3(-128, sampleLateriteHillHeight(-128, -142), -142),
    new THREE.Vector3(-265, sampleLateriteHillHeight(-265, -230), -230),
    new THREE.Vector3(-375, sampleLateriteHillHeight(-375, -310), -310),
    new THREE.Vector3(175, sampleLateriteHillHeight(175, -165), -165),
    new THREE.Vector3(295, sampleLateriteHillHeight(295, -245), -245),
    new THREE.Vector3(65, sampleLateriteHillHeight(65, -335), -335),
  ];

  // Spread-out Wild Animal Habitats across the expanded map (95m–420m from spawn so players must hunt & track!)
  const wildAnimalHabitats: WildAnimalHabitatAnchor[] = [
    // Sundarban Tiger habitats (Sundarban Fringe, deep Sal Forest & dense groves)
    { x: -125, z: 235, areaBn: 'সুন্দরবন প্রান্ত', speciesHint: 'sundarban_tiger' },
    { x: 92, z: 275, areaBn: 'সুন্দরবন প্রান্ত', speciesHint: 'sundarban_tiger' },
    { x: -45, z: 385, areaBn: 'সুন্দরবন প্রান্ত', speciesHint: 'sundarban_tiger' },
    { x: -245, z: 165, areaBn: 'রাঢ় লাল টিলা', speciesHint: 'sundarban_tiger' },
    { x: 255, z: 335, areaBn: 'পূর্ব প্রান্তর', speciesHint: 'sundarban_tiger' },
    // Bengal Leopard habitats (Sal Forest hills, Rarh red-soil ridges & rocky groves)
    { x: -165, z: 88, areaBn: 'শালবন', speciesHint: 'bengal_leopard' },
    { x: -335, z: 110, areaBn: 'রাঢ় লাল টিলা', speciesHint: 'bengal_leopard' },
    { x: -365, z: 285, areaBn: 'রাঢ় লাল টিলা', speciesHint: 'bengal_leopard' },
    { x: 285, z: 155, areaBn: 'পূর্ব প্রান্তর', speciesHint: 'bengal_leopard' },
    { x: -225, z: -210, areaBn: 'পশ্চিম বনাঞ্চল', speciesHint: 'bengal_leopard' },
    // Bengal Guard Hound habitats (Zamindar outskirts, rural meadows, riverbank wilderness & north gardens)
    { x: 175, z: 72, areaBn: 'পূর্ব প্রান্তর', speciesHint: 'village_hound' },
    { x: 235, z: 205, areaBn: 'পূর্ব প্রান্তর', speciesHint: 'village_hound' },
    { x: 355, z: 75, areaBn: 'পূর্ব প্রান্তর', speciesHint: 'village_hound' },
    { x: -145, z: 185, areaBn: 'শালবন', speciesHint: 'village_hound' },
    { x: 145, z: -175, areaBn: 'উত্তর বাগানবাড়ি', speciesHint: 'village_hound' },
    { x: 265, z: -240, areaBn: 'উত্তর বাগানবাড়ি', speciesHint: 'village_hound' },
  ];

  const pickupAnchors = [
    new THREE.Vector3(3.2, 0, -6.5),
    new THREE.Vector3(-9.0, 0, 9.5),
    new THREE.Vector3(10.0, 0, 9.0),
    new THREE.Vector3(0.0, 0, 17.5),
    new THREE.Vector3(-78, sampleLateriteHillHeight(-78, 34), 34),
    new THREE.Vector3(98, 0.18, 28),
    new THREE.Vector3(8, 0, -112),
    new THREE.Vector3(-210, sampleLateriteHillHeight(-210, 155), 155),
    new THREE.Vector3(245, sampleLateriteHillHeight(245, 130), 130),
    new THREE.Vector3(-45, sampleLateriteHillHeight(-45, 255), 255),
    new THREE.Vector3(195, sampleLateriteHillHeight(195, -185), -185),
  ];

  return {
    worldGroup,
    boxColliders,
    circleColliders,
    swayingPalms,
    boatGroup,
    bobbingBoats,
    waterUniforms,
    waterBumpTexture: textures.waterBump,
    enemySpawnPoints,
    wildAnimalHabitats,
    pickupAnchors,
    landmarkChestAnchors,
    landmarkSanjibaniAnchors,
    playableBounds: { minX: -760, maxX: 760, minZ: -760, maxZ: 760 },
    getGroundHeight,
    isWaterBlocked,
    getLocationName,
  };
}
