import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import {
  buildExtendedRiverGhat,
  buildOldTramDepotAndBazaar,
  buildSalForestAndHills,
  buildZamindarBari,
  ChestAnchor,
} from './battleRoyaleAssets';
import {
  buildBurrabazarZone,
  buildChorBazaarZone,
  buildInstancedBicycles,
  buildInstancedMotorcycles,
  RideableTwoWheeler,
  TwoWheelerPlacement,
} from './kolkataMarkets';
import { TextureBundle } from './textures';
import { BoxCollider, CircleCollider, WildAnimalSpecies } from './types';

export interface SwayingPalm {
  crown: THREE.Group;
  phase: number;
  baseRotX: number;
  baseRotZ: number;
}

export interface WildAnimalHabitatAnchor {
  x: number;
  z: number;
  areaBn: string;
  speciesHint?: WildAnimalSpecies;
}

export interface WorldBuildResult {
  worldGroup: THREE.Group;
  boxColliders: BoxCollider[];
  circleColliders: CircleCollider[];
  swayingPalms: SwayingPalm[];
  boatGroup: THREE.Group;
  bobbingBoats: THREE.Group[];
  waterUniforms: { uTime: { value: number } };
  waterBumpTexture: THREE.CanvasTexture;
  enemySpawnPoints: THREE.Vector3[];
  wildAnimalHabitats: WildAnimalHabitatAnchor[];
  pickupAnchors: THREE.Vector3[];
  landmarkChestAnchors: ChestAnchor[];
  landmarkSanjibaniAnchors: Array<{ x: number; z: number }>;
  twoWheelers: RideableTwoWheeler[];
  playableBounds: { minX: number; maxX: number; minZ: number; maxZ: number };
  getGroundHeight: (x: number, z: number, currentY?: number) => number;
  isWaterBlocked: (x: number, z: number) => boolean;
  getLocationName: (x: number, z: number, currentY?: number) => string;
}

function addContactShadow(
  parent: THREE.Object3D,
  shadowMap: THREE.CanvasTexture,
  width: number,
  depth: number,
  opacity = 0.48,
): void {
  const geo = new THREE.PlaneGeometry(width, depth);
  geo.rotateX(-Math.PI / 2);
  const mat = new THREE.MeshBasicMaterial({
    map: shadowMap,
    transparent: true,
    opacity,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.y = 0.025;
  parent.add(mesh);
}

/**
 * Builds an iconic Howrah-style steel cantilever truss bridge spanning the Hooghly River.
 */
function buildHowrahBridge(textures: TextureBundle): THREE.Group {
  const bridge = new THREE.Group();
  bridge.position.set(0, 0, -40);

  const steelMat = new THREE.MeshStandardMaterial({
    map: textures.bridgeSteelMap,
    color: 0xa2aeb8,
    roughness: 0.36,
    metalness: 0.82,
    envMapIntensity: 1.15,
  });
  const darkSteelMat = new THREE.MeshStandardMaterial({
    color: 0x454f58,
    roughness: 0.46,
    metalness: 0.78,
    envMapIntensity: 1.05,
  });
  const deckMat = new THREE.MeshStandardMaterial({
    color: 0x3b3d40,
    roughness: 0.88,
    metalness: 0.05,
  });
  const stoneMat = new THREE.MeshStandardMaterial({
    color: 0x8f8274,
    roughness: 0.92,
    metalness: 0.02,
  });
  const lampGlowMat = new THREE.MeshStandardMaterial({
    color: 0xffdf99,
    emissive: 0xffae42,
    emissiveIntensity: 2.2,
    roughness: 0.25,
  });

  const deckY = 6.2;
  const totalLen = 136;
  const halfWidth = 4.6;

  // Roadway deck
  const deck = new THREE.Mesh(new THREE.BoxGeometry(totalLen, 0.75, halfWidth * 2), deckMat);
  deck.position.set(0, deckY, 0);
  deck.receiveShadow = true;
  bridge.add(deck);

  // Side curb girders
  for (const zSide of [-halfWidth, halfWidth]) {
    const girder = new THREE.Mesh(new THREE.BoxGeometry(totalLen, 1.05, 0.55), darkSteelMat);
    girder.position.set(0, deckY + 0.2, zSide);
    bridge.add(girder);
  }

  // Twin iconic Howrah Bridge main towers at x = -28 and x = +28
  const towerPositions = [-28, 28];
  const towerHeight = 25;

  for (const tx of towerPositions) {
    // Stone river masonry piers
    const pier = new THREE.Mesh(new THREE.BoxGeometry(6.2, 8.2, halfWidth * 2 + 3.2), stoneMat);
    pier.position.set(tx, 2.2, 0);
    bridge.add(pier);

    // Tapered twin steel tower legs on front & back of roadway
    for (const zSide of [-halfWidth, halfWidth]) {
      const leg = new THREE.Mesh(new THREE.BoxGeometry(1.7, towerHeight, 1.5), steelMat);
      leg.position.set(tx, deckY + towerHeight * 0.5 - 1.5, zSide);
      bridge.add(leg);

      // Decorative riveted crown finial atop tower
      const cap = new THREE.Mesh(new THREE.BoxGeometry(2.3, 1.1, 2.1), darkSteelMat);
      cap.position.set(tx, deckY + towerHeight - 1.2, zSide);
      bridge.add(cap);
    }

    // Overhead portal cross-beams & X-bracing linking front/back legs
    const beamHeights = [deckY + 8.5, deckY + 15.5, deckY + 21.8];
    for (const by of beamHeights) {
      const cross = new THREE.Mesh(new THREE.BoxGeometry(1.3, 1.25, halfWidth * 2 + 1.2), steelMat);
      cross.position.set(tx, by, 0);
      bridge.add(cross);
    }

    // Diagonal portal X-braces inside tower head
    const diagLen = Math.hypot(halfWidth * 2, 6.2);
    for (const dir of [-1, 1]) {
      const brace = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.42, diagLen), darkSteelMat);
      brace.position.set(tx, deckY + 18.6, 0);
      brace.rotation.x = dir * Math.atan2(6.2, halfWidth * 2);
      bridge.add(brace);
    }
  }

  // Classic cantilever curved upper truss chords (both front & back sides)
  // Profile height as a function of x: peaks over towers (±28), curves down to central suspended span and outer anchor spans
  const upperChordY = (x: number): number => {
    const ax = Math.abs(x);
    if (ax <= 28) {
      // Between towers: graceful catenary-like dip to central span
      const t = ax / 28; // 0 at center, 1 at tower
      return deckY + 7.2 + Math.pow(t, 2.15) * 16.0;
    } else {
      // Anchor arms sloping down toward riverbanks
      const t = Math.min(1, (ax - 28) / 36);
      return deckY + 23.2 - Math.pow(t, 0.88) * 18.5;
    }
  };

  const segments = 24;
  const xMin = -62;
  const xMax = 62;
  const dx = (xMax - xMin) / segments;
  const vA = new THREE.Vector3();
  const vB = new THREE.Vector3();
  const vMid = new THREE.Vector3();
  const upAxis = new THREE.Vector3(0, 1, 0);
  const quat = new THREE.Quaternion();

  const addStrut = (
    ax: number,
    ay: number,
    az: number,
    bx: number,
    by: number,
    bz: number,
    thickness: number,
    mat: THREE.Material,
  ) => {
    vA.set(ax, ay, az);
    vB.set(bx, by, bz);
    const len = vA.distanceTo(vB);
    if (len < 0.05) return;
    vMid.addVectors(vA, vB).multiplyScalar(0.5);
    const dir = vB.clone().sub(vA).normalize();
    quat.setFromUnitVectors(upAxis, dir);
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(thickness, len, thickness), mat);
    mesh.position.copy(vMid);
    mesh.quaternion.copy(quat);
    bridge.add(mesh);
  };

  for (const zSide of [-halfWidth, halfWidth]) {
    for (let i = 0; i < segments; i++) {
      const x0 = xMin + i * dx;
      const x1 = x0 + dx;
      const y0 = upperChordY(x0);
      const y1 = upperChordY(x1);

      // Upper chord member
      addStrut(x0, y0, zSide, x1, y1, zSide, 0.58, steelMat);
      // Vertical hanger post
      addStrut(x0, deckY, zSide, x0, y0, zSide, 0.34, darkSteelMat);
      // Alternating Warren/Pratt diagonal truss member
      if (i % 2 === 0) {
        addStrut(x0, deckY, zSide, x1, y1, zSide, 0.3, steelMat);
      } else {
        addStrut(x0, y0, zSide, x1, deckY, zSide, 0.3, steelMat);
      }
    }
    // Closing vertical strut
    addStrut(xMax, deckY, zSide, xMax, upperChordY(xMax), zSide, 0.34, darkSteelMat);
  }

  // Overhead wind-bracing cross struts between front and back upper chords
  for (let i = 3; i < segments - 2; i += 2) {
    const x = xMin + i * dx;
    const y = upperChordY(x);
    if (y > deckY + 8.0) {
      addStrut(x, y, -halfWidth, x, y, halfWidth, 0.34, darkSteelMat);
    }
  }

  // Warm glowing sodium bridge lamps along the deck
  for (let x = -52; x <= 52; x += 13) {
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 3.2, 6), darkSteelMat);
    post.position.set(x, deckY + 1.8, halfWidth - 0.3);
    bridge.add(post);

    const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.28, 8, 8), lampGlowMat);
    bulb.position.set(x, deckY + 3.45, halfWidth - 0.3);
    bridge.add(bulb);
  }

  return bridge;
}

/**
 * Builds an iconic Kolkata Yellow Hindustan Ambassador Taxi (12-part composite THREE.Group).
 */
function buildYellowTaxi(textures: TextureBundle): THREE.Group {
  const taxi = new THREE.Group();

  const yellowPaint = new THREE.MeshPhysicalMaterial({
    color: 0xf4bd14,
    roughness: 0.24,
    metalness: 0.18,
    clearcoat: 1.0,
    clearcoatRoughness: 0.12,
  });
  const blackTrim = new THREE.MeshStandardMaterial({
    color: 0x1b1c1f,
    roughness: 0.55,
    metalness: 0.2,
  });
  const chromeMat = new THREE.MeshStandardMaterial({
    color: 0xe6ebef,
    roughness: 0.16,
    metalness: 0.92,
  });
  const glassMat = new THREE.MeshPhysicalMaterial({
    color: 0x1d2b35,
    roughness: 0.12,
    metalness: 0.15,
    clearcoat: 1.0,
  });
  const rubberMat = new THREE.MeshStandardMaterial({
    color: 0x171717,
    roughness: 0.92,
    metalness: 0.02,
  });
  const headlightMat = new THREE.MeshStandardMaterial({
    color: 0xfff3c4,
    emissive: 0xffd275,
    emissiveIntensity: 1.4,
    roughness: 0.2,
  });
  const taillightMat = new THREE.MeshStandardMaterial({
    color: 0xd92626,
    emissive: 0xb51818,
    emissiveIntensity: 0.9,
    roughness: 0.25,
  });

  // 1. Classic rounded lower body hull using beveled ExtrudeGeometry (side profile)
  const hullShape = new THREE.Shape();
  hullShape.moveTo(-2.15, 0.36);
  hullShape.lineTo(2.15, 0.36);
  hullShape.quadraticCurveTo(2.3, 0.5, 2.22, 0.96);
  hullShape.lineTo(1.25, 1.08);
  hullShape.lineTo(-1.35, 1.08);
  hullShape.lineTo(-2.18, 0.94);
  hullShape.quadraticCurveTo(-2.3, 0.62, -2.15, 0.36);

  const hullGeo = new THREE.ExtrudeGeometry(hullShape, {
    depth: 1.66,
    bevelEnabled: true,
    bevelThickness: 0.12,
    bevelSize: 0.08,
    bevelSegments: 3,
  });
  hullGeo.translate(0, 0, -0.83);
  const hull = new THREE.Mesh(hullGeo, yellowPaint);
  hull.castShadow = true;
  hull.receiveShadow = true;
  taxi.add(hull);

  // 2. Classic black Kolkata taxi lower side band / rocker stripe
  const stripe = new THREE.Mesh(new THREE.BoxGeometry(4.36, 0.26, 1.9), blackTrim);
  stripe.position.set(0, 0.48, 0);
  taxi.add(stripe);

  // 3. Domed Ambassador greenhouse cabin
  const cabinShape = new THREE.Shape();
  cabinShape.moveTo(-1.26, 1.04);
  cabinShape.lineTo(1.12, 1.04);
  cabinShape.quadraticCurveTo(0.84, 1.64, 0.48, 1.7);
  cabinShape.lineTo(-0.76, 1.7);
  cabinShape.quadraticCurveTo(-1.12, 1.6, -1.26, 1.04);
  const cabinGeo = new THREE.ExtrudeGeometry(cabinShape, {
    depth: 1.44,
    bevelEnabled: true,
    bevelThickness: 0.1,
    bevelSize: 0.08,
    bevelSegments: 3,
  });
  cabinGeo.translate(0, 0, -0.72);
  const cabin = new THREE.Mesh(cabinGeo, yellowPaint);
  cabin.castShadow = true;
  taxi.add(cabin);

  // 4. Windshield, rear glass & side windows
  const sideGlass = new THREE.Mesh(new THREE.BoxGeometry(1.75, 0.44, 1.66), glassMat);
  sideGlass.position.set(-0.1, 1.35, 0);
  taxi.add(sideGlass);

  const frontBackGlass = new THREE.Mesh(new THREE.BoxGeometry(2.08, 0.42, 1.32), glassMat);
  frontBackGlass.position.set(-0.08, 1.34, 0);
  taxi.add(frontBackGlass);

  // 5. Roof "TAXI" illuminated sign box
  const signMat = new THREE.MeshStandardMaterial({
    map: textures.taxiSignMap,
    emissive: 0xffe07d,
    emissiveMap: textures.taxiSignMap,
    emissiveIntensity: 0.35,
    roughness: 0.35,
  });
  const taxiSign = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.24, 0.66), [
    signMat,
    signMat,
    blackTrim,
    blackTrim,
    blackTrim,
    blackTrim,
  ]);
  taxiSign.position.set(0.05, 1.88, 0);
  taxiSign.castShadow = true;
  taxi.add(taxiSign);

  // 6. Chrome roof luggage carrier bars
  const rackBase = new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.05, 1.15), chromeMat);
  rackBase.position.set(-0.56, 1.82, 0);
  taxi.add(rackBase);

  // 7. Chrome front & rear bumpers + radiator grille
  for (const bx of [2.3, -2.3]) {
    const bumper = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.18, 1.92), chromeMat);
    bumper.position.set(bx, 0.42, 0);
    taxi.add(bumper);
  }
  const grille = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.36, 0.92), chromeMat);
  grille.position.set(2.26, 0.72, 0);
  taxi.add(grille);

  // 8. Round twin Ambassador headlights with chrome bezels
  for (const hz of [-0.64, 0.64]) {
    const bezel = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 0.12, 14), chromeMat);
    bezel.rotation.z = Math.PI / 2;
    bezel.position.set(2.22, 0.84, hz);
    taxi.add(bezel);

    const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 10), headlightMat);
    lamp.position.set(2.26, 0.84, hz);
    taxi.add(lamp);

    // Rear tail lamps
    const tail = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.22, 0.18), taillightMat);
    tail.position.set(-2.26, 0.78, hz);
    taxi.add(tail);
  }

  // 9. West Bengal license plates (front & back)
  const plateMat = new THREE.MeshStandardMaterial({
    map: textures.licensePlateMap,
    roughness: 0.45,
  });
  for (const px of [2.36, -2.36]) {
    const plate = new THREE.Mesh(new THREE.PlaneGeometry(0.56, 0.16), plateMat);
    plate.position.set(px, 0.56, 0);
    plate.rotation.y = px > 0 ? Math.PI / 2 : -Math.PI / 2;
    taxi.add(plate);
  }

  // 10. Four rubber wheels with chrome Ambassador hubcaps
  const wheelCoords: [number, number][] = [
    [1.36, 0.88],
    [1.36, -0.88],
    [-1.36, 0.88],
    [-1.36, -0.88],
  ];
  const tireGeo = new THREE.CylinderGeometry(0.38, 0.38, 0.26, 18);
  tireGeo.rotateX(Math.PI / 2);
  const hubGeo = new THREE.CylinderGeometry(0.2, 0.2, 0.29, 14);
  hubGeo.rotateX(Math.PI / 2);

  for (const [wx, wz] of wheelCoords) {
    const tire = new THREE.Mesh(tireGeo, rubberMat);
    tire.position.set(wx, 0.38, wz);
    tire.castShadow = true;
    taxi.add(tire);

    const hub = new THREE.Mesh(hubGeo, chromeMat);
    hub.position.set(wx, 0.38, wz);
    taxi.add(hub);
  }

  addContactShadow(taxi, textures.contactShadowMap, 5.4, 2.7, 0.58);
  return taxi;
}

interface BuildingMaterialSet {
  wallMat: THREE.MeshStandardMaterial;
  plinthMat: THREE.MeshStandardMaterial;
  thatchMat: THREE.MeshStandardMaterial;
  woodMat: THREE.MeshStandardMaterial;
  darkWoodMat: THREE.MeshStandardMaterial;
  windowInnerMat: THREE.MeshStandardMaterial;
  bambooMat: THREE.MeshStandardMaterial;
  clayPotMat: THREE.MeshStandardMaterial;
  lanternGlowMat: THREE.MeshStandardMaterial;
  pakaPlasterMat: THREE.MeshStandardMaterial;
  pakaTrimMat: THREE.MeshStandardMaterial;
  pakaShutterMat: THREE.MeshStandardMaterial;
  pakaRoofTileMat: THREE.MeshStandardMaterial;
}

function createBuildingMaterials(textures: TextureBundle): BuildingMaterialSet {
  return {
    wallMat: new THREE.MeshStandardMaterial({
      map: textures.mudWallMap,
      bumpMap: textures.mudWallBump,
      bumpScale: 0.09,
      roughness: 0.9,
      metalness: 0.0,
    }),
    plinthMat: new THREE.MeshStandardMaterial({
      color: 0x854e2f,
      roughness: 0.94,
      metalness: 0.0,
    }),
    thatchMat: new THREE.MeshStandardMaterial({
      map: textures.thatchMap,
      color: 0xd4b57e,
      roughness: 0.95,
      metalness: 0.0,
    }),
    woodMat: new THREE.MeshStandardMaterial({
      color: 0x4f321e,
      roughness: 0.8,
      metalness: 0.05,
    }),
    darkWoodMat: new THREE.MeshStandardMaterial({
      color: 0x392214,
      roughness: 0.84,
      metalness: 0.04,
    }),
    windowInnerMat: new THREE.MeshStandardMaterial({
      color: 0x20150e,
      roughness: 0.9,
    }),
    bambooMat: new THREE.MeshStandardMaterial({
      color: 0x9e7f48,
      roughness: 0.72,
      metalness: 0.04,
    }),
    clayPotMat: new THREE.MeshStandardMaterial({
      color: 0xba4c2d,
      roughness: 0.68,
      metalness: 0.04,
    }),
    lanternGlowMat: new THREE.MeshStandardMaterial({
      color: 0xffd27a,
      emissive: 0xff9b2f,
      emissiveIntensity: 1.85,
      roughness: 0.3,
    }),
    pakaPlasterMat: new THREE.MeshStandardMaterial({
      map: textures.mudWallMap,
      bumpMap: textures.mudWallBump,
      bumpScale: 0.06,
      color: 0xffffff,
      roughness: 0.86,
      metalness: 0.02,
    }),
    pakaTrimMat: new THREE.MeshStandardMaterial({
      color: 0x9b543b,
      roughness: 0.88,
      metalness: 0.03,
    }),
    pakaShutterMat: new THREE.MeshStandardMaterial({
      color: 0x29563c, // iconic Bengali heritage bottle-green khorkhori louvered shutters
      roughness: 0.7,
      metalness: 0.06,
    }),
    pakaRoofTileMat: new THREE.MeshStandardMaterial({
      color: 0xa6462b,
      roughness: 0.84,
      metalness: 0.04,
    }),
  };
}

/**
 * Safely normalizes (non-indexed, uniform attributes) and merges an array of static geometries.
 */
function mergeNormalizedGeometries(
  parts: THREE.BufferGeometry[],
  keepUv = true,
): THREE.BufferGeometry {
  const normalized: THREE.BufferGeometry[] = [];
  for (let i = 0; i < parts.length; i++) {
    const src = parts[i];
    const g = src.index ? src.toNonIndexed() : src.clone();
    if (!g.getAttribute('normal')) g.computeVertexNormals();
    if (keepUv && !g.getAttribute('uv')) {
      const count = g.getAttribute('position').count;
      g.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(count * 2), 2));
    }
    for (const name of Object.keys(g.attributes)) {
      if (name !== 'position' && name !== 'normal' && (!keepUv || name !== 'uv')) {
        g.deleteAttribute(name);
      }
    }
    normalized.push(g);
    src.dispose();
  }
  const merged = mergeGeometries(normalized, false);
  for (const g of normalized) g.dispose();
  if (!merged) {
    throw new Error('Failed to merge normalized building geometries');
  }
  return merged;
}

/**
 * Registers a clean single- or twin-circle building footprint collider aligned to the building's Y rotation,
 * giving tight wall boundaries and smooth gliding corners without invisible air walls or corner trapping.
 */
function addBuildingFootprintColliders(
  colliders: CircleCollider[],
  cx: number,
  cz: number,
  width: number,
  depth: number,
  rotY: number,
  height: number,
  baseY: number,
): void {
  const cosR = Math.cos(rotY);
  const sinR = Math.sin(rotY);
  if (width > depth * 1.16) {
    const r = depth * 0.51;
    const offset = Math.max(0.55, (width - depth) * 0.44);
    for (const side of [-1, 1]) {
      const lx = side * offset;
      colliders.push({
        x: cx + lx * cosR,
        z: cz - lx * sinR,
        radius: r,
        height,
        baseY,
        kind: 'house',
      });
    }
  } else {
    colliders.push({
      x: cx,
      z: cz,
      radius: Math.max(width, depth) * 0.52,
      height,
      baseY,
      kind: 'house',
    });
  }
}

/**
 * Builds a traditional West Bengal Village Mud House (Matir Ghor) with Alpona dado,
 * generous veranda (daowa), bamboo pillars, pitched thatched chala roof, and clay kolshi pots.
 * Sized cleanly for our enlarged 1.16x–1.36x character scale and shares GPU materials.
 */
function buildMudHouse(
  textures: TextureBundle,
  mats: BuildingMaterialSet,
  width = 8.4,
  depth = 6.4,
  wallHeight = 4.1,
): THREE.Group {
  const house = new THREE.Group();

  // 1. Raised earthen veranda plinth (daowa) with subtle foundation skirt so sloped ground never gaps
  const plinthH = 0.54;
  const skirtDepth = 0.9;
  const plinth = new THREE.Mesh(
    new THREE.BoxGeometry(width + 1.45, plinthH + skirtDepth, depth + 1.9),
    mats.plinthMat,
  );
  plinth.position.set(0, (plinthH - skirtDepth) * 0.5, 0.36);
  plinth.receiveShadow = true;
  plinth.castShadow = true;
  house.add(plinth);

  // 2. Main mud-plaster walls with Alpona motif band
  const body = new THREE.Mesh(new THREE.BoxGeometry(width, wallHeight, depth), mats.wallMat);
  body.position.set(0, plinthH + wallHeight * 0.5, -0.18);
  body.castShadow = true;
  body.receiveShadow = true;
  house.add(body);

  // 3. Pitched Bengali Chala thatched roof (beveled eaves + ridge beam)
  const roofH = Math.max(2.55, wallHeight * 0.66);
  const roofShape = new THREE.Shape();
  const halfSpan = depth * 0.5 + 1.65;
  roofShape.moveTo(-halfSpan, 0);
  roofShape.lineTo(0, roofH);
  roofShape.lineTo(halfSpan, 0);
  roofShape.lineTo(halfSpan - 0.34, -0.26);
  roofShape.lineTo(0, roofH - 0.42);
  roofShape.lineTo(-halfSpan + 0.34, -0.26);
  roofShape.closePath();

  const roofGeo = new THREE.ExtrudeGeometry(roofShape, {
    depth: width + 1.85,
    bevelEnabled: true,
    bevelThickness: 0.16,
    bevelSize: 0.12,
    bevelSegments: 2,
  });
  roofGeo.rotateY(Math.PI / 2);
  roofGeo.translate(-(width + 1.85) * 0.5, plinthH + wallHeight - 0.18, 0.08);
  const roof = new THREE.Mesh(roofGeo, mats.thatchMat);
  roof.castShadow = true;
  roof.receiveShadow = true;
  house.add(roof);

  // Triangular gable mud infill under roof
  const gableShape = new THREE.Shape();
  gableShape.moveTo(-depth * 0.5, 0);
  gableShape.lineTo(0, roofH - 0.34);
  gableShape.lineTo(depth * 0.5, 0);
  gableShape.closePath();
  const gableGeo = new THREE.ExtrudeGeometry(gableShape, {
    depth: width - 0.1,
    bevelEnabled: false,
  });
  gableGeo.rotateY(Math.PI / 2);
  gableGeo.translate(-(width - 0.1) * 0.5, plinthH + wallHeight - 0.06, -0.18);
  const gable = new THREE.Mesh(gableGeo, mats.wallMat);
  house.add(gable);

  // Bamboo ridge pole + front veranda bamboo support posts
  const ridge = new THREE.Mesh(
    new THREE.CylinderGeometry(0.14, 0.14, width + 2.3, 8),
    mats.bambooMat,
  );
  ridge.rotation.z = Math.PI / 2;
  ridge.position.set(0, plinthH + wallHeight + roofH - 0.1, 0.08);
  house.add(ridge);

  const postXs = [-width * 0.48, -width * 0.16, width * 0.16, width * 0.48];
  for (const px of postXs) {
    const post = new THREE.Mesh(
      new THREE.CylinderGeometry(0.1, 0.12, wallHeight, 8),
      mats.bambooMat,
    );
    post.position.set(px, plinthH + wallHeight * 0.5, depth * 0.5 + 1.05);
    post.castShadow = true;
    house.add(post);
  }

  // 5. Tall wooden front door & frame proportioned to enlarged hero
  const doorFrame = new THREE.Mesh(new THREE.BoxGeometry(1.75, 2.85, 0.22), mats.woodMat);
  doorFrame.position.set(0, plinthH + 1.42, depth * 0.5 - 0.14);
  house.add(doorFrame);

  const doorPanel = new THREE.Mesh(new THREE.BoxGeometry(1.44, 2.64, 0.26), mats.darkWoodMat);
  doorPanel.position.set(0, plinthH + 1.34, depth * 0.5 - 0.12);
  house.add(doorPanel);

  // 6. Shuttered front windows
  const winPositions = [-width * 0.31, width * 0.31];
  for (const wx of winPositions) {
    const win = new THREE.Mesh(new THREE.BoxGeometry(1.22, 1.22, 0.22), mats.woodMat);
    win.position.set(wx, plinthH + 2.15, depth * 0.5 - 0.14);
    house.add(win);

    const inner = new THREE.Mesh(new THREE.BoxGeometry(0.96, 0.96, 0.26), mats.windowInnerMat);
    inner.position.set(wx, plinthH + 2.15, depth * 0.5 - 0.12);
    house.add(inner);
  }

  // 7. Terracotta water pots (Kolshi) using LatheGeometry on veranda
  const potProfile = [
    new THREE.Vector2(0.0, 0.0),
    new THREE.Vector2(0.22, 0.0),
    new THREE.Vector2(0.35, 0.22),
    new THREE.Vector2(0.32, 0.44),
    new THREE.Vector2(0.16, 0.6),
    new THREE.Vector2(0.2, 0.7),
  ];
  const potGeo = new THREE.LatheGeometry(potProfile, 12);
  const pot1 = new THREE.Mesh(potGeo, mats.clayPotMat);
  pot1.position.set(-width * 0.36, plinthH, depth * 0.5 + 0.46);
  pot1.castShadow = true;
  house.add(pot1);

  const pot2 = new THREE.Mesh(potGeo, mats.clayPotMat);
  pot2.scale.setScalar(0.8);
  pot2.position.set(-width * 0.25, plinthH, depth * 0.5 + 0.6);
  house.add(pot2);

  // 8. Hanging warm village oil lantern by the veranda
  const lantern = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.16, 0.32, 8), mats.lanternGlowMat);
  lantern.position.set(width * 0.16, plinthH + wallHeight - 0.56, depth * 0.5 + 1.05);
  house.add(lantern);

  addContactShadow(house, textures.contactShadowMap, width + 3.0, depth + 3.2, 0.48);
  return house;
}

interface InstancedBuildingPlacement {
  x: number;
  y: number;
  z: number;
  rotY: number;
  scale: number;
  tintHex: number;
}

/**
 * Renders dozens of large, multi-part Bengal Mud Houses (Matir Ghor) and Two-Story Bengal Brick Houses (Paka Bari)
 * across the expanded 1520x1520 map in just 8 total InstancedMesh draw calls for silky-smooth mobile FPS.
 */
function buildInstancedCountrysideBuildings(
  mats: BuildingMaterialSet,
  mudPlacements: InstancedBuildingPlacement[],
  pakaPlacements: InstancedBuildingPlacement[],
): THREE.Group {
  const group = new THREE.Group();
  const dummy = new THREE.Object3D();
  const tmpCol = new THREE.Color();

  // --- ARCHETYPE A: Large Rural Bengal Mud House (base 8.8m x 6.8m x 4.2m wall + 2.8m Chala roof) ---
  if (mudPlacements.length > 0) {
    const w = 8.8;
    const d = 6.8;
    const wallH = 4.2;
    const plinthH = 0.56;
    const skirtD = 2.0; // Deep foundation skirt embeds cleanly into sloped hillsides (zero floating corners!)
    const roofH = 2.85;

    // Part 1: Plinth & foundation skirt + veranda step
    const plinthParts: THREE.BufferGeometry[] = [];
    const plinthBox = new THREE.BoxGeometry(w + 1.5, plinthH + skirtD, d + 2.0);
    plinthBox.translate(0, (plinthH - skirtD) * 0.5, 0.38);
    plinthParts.push(plinthBox);
    const frontStep = new THREE.BoxGeometry(2.6, 0.32, 0.85);
    frontStep.translate(0, 0.16, d * 0.5 + 1.55);
    plinthParts.push(frontStep);
    const mudPlinthGeo = mergeNormalizedGeometries(plinthParts, false);

    // Part 2: Main mud-plaster walls + triangular gable infill (with UVs for mudWallMap + Alpona band)
    const wallParts: THREE.BufferGeometry[] = [];
    const mainWall = new THREE.BoxGeometry(w, wallH, d);
    mainWall.translate(0, plinthH + wallH * 0.5, -0.18);
    wallParts.push(mainWall);
    const gableShape = new THREE.Shape();
    gableShape.moveTo(-d * 0.5, 0);
    gableShape.lineTo(0, roofH - 0.35);
    gableShape.lineTo(d * 0.5, 0);
    gableShape.closePath();
    const gableGeo = new THREE.ExtrudeGeometry(gableShape, { depth: w - 0.12, bevelEnabled: false });
    gableGeo.rotateY(Math.PI / 2);
    gableGeo.translate(-(w - 0.12) * 0.5, plinthH + wallH - 0.06, -0.18);
    wallParts.push(gableGeo);
    const mudWallGeo = mergeNormalizedGeometries(wallParts, true);

    // Part 3: Pitched beveled Bengali Chala thatched roof
    const halfSpan = d * 0.5 + 1.75;
    const roofShape = new THREE.Shape();
    roofShape.moveTo(-halfSpan, 0);
    roofShape.lineTo(0, roofH);
    roofShape.lineTo(halfSpan, 0);
    roofShape.lineTo(halfSpan - 0.36, -0.28);
    roofShape.lineTo(0, roofH - 0.44);
    roofShape.lineTo(-halfSpan + 0.36, -0.28);
    roofShape.closePath();
    const mudRoofGeo = new THREE.ExtrudeGeometry(roofShape, {
      depth: w + 1.95,
      bevelEnabled: true,
      bevelThickness: 0.16,
      bevelSize: 0.12,
      bevelSegments: 2,
    });
    mudRoofGeo.rotateY(Math.PI / 2);
    mudRoofGeo.translate(-(w + 1.95) * 0.5, plinthH + wallH - 0.18, 0.08);

    // Part 4: Merged timber/bamboo details (veranda posts, ridge beam, front doorway & shutters, side windows)
    const trimParts: THREE.BufferGeometry[] = [];
    const ridge = new THREE.CylinderGeometry(0.14, 0.14, w + 2.4, 6);
    ridge.rotateZ(Math.PI / 2);
    ridge.translate(0, plinthH + wallH + roofH - 0.1, 0.08);
    trimParts.push(ridge);

    for (const px of [-w * 0.48, -w * 0.16, w * 0.16, w * 0.48]) {
      const post = new THREE.CylinderGeometry(0.1, 0.12, wallH, 6);
      post.translate(px, plinthH + wallH * 0.5, d * 0.5 + 1.08);
      trimParts.push(post);
    }
    const door = new THREE.BoxGeometry(1.85, 2.95, 0.28);
    door.translate(0, plinthH + 1.48, d * 0.5 - 0.14);
    trimParts.push(door);
    for (const wx of [-w * 0.31, w * 0.31]) {
      const winF = new THREE.BoxGeometry(1.26, 1.28, 0.28);
      winF.translate(wx, plinthH + 2.2, d * 0.5 - 0.14);
      trimParts.push(winF);
      const winB = new THREE.BoxGeometry(1.26, 1.28, 0.28);
      winB.translate(wx, plinthH + 2.2, -d * 0.5 - 0.22);
      trimParts.push(winB);
    }
    for (const sx of [-w * 0.5, w * 0.5]) {
      const sideWin = new THREE.BoxGeometry(0.28, 1.26, 1.32);
      sideWin.translate(sx, plinthH + 2.2, -0.18);
      trimParts.push(sideWin);
    }
    const mudTrimGeo = mergeNormalizedGeometries(trimParts, false);

    const n = mudPlacements.length;
    const imPlinth = new THREE.InstancedMesh(mudPlinthGeo, mats.plinthMat, n);
    const imWall = new THREE.InstancedMesh(mudWallGeo, mats.wallMat, n);
    const imRoof = new THREE.InstancedMesh(mudRoofGeo, mats.thatchMat, n);
    const imTrim = new THREE.InstancedMesh(mudTrimGeo, mats.woodMat, n);

    imPlinth.receiveShadow = true;
    imWall.castShadow = true;
    imWall.receiveShadow = true;
    imRoof.castShadow = true;
    imRoof.receiveShadow = true;

    for (let i = 0; i < n; i++) {
      const p = mudPlacements[i];
      dummy.position.set(p.x, p.y, p.z);
      dummy.rotation.set(0, p.rotY, 0);
      dummy.scale.setScalar(p.scale);
      dummy.updateMatrix();
      imPlinth.setMatrixAt(i, dummy.matrix);
      imWall.setMatrixAt(i, dummy.matrix);
      imRoof.setMatrixAt(i, dummy.matrix);
      imTrim.setMatrixAt(i, dummy.matrix);
      tmpCol.setHex(p.tintHex);
      imWall.setColorAt(i, tmpCol);
    }

    for (const im of [imPlinth, imWall, imRoof, imTrim]) {
      im.instanceMatrix.needsUpdate = true;
      if (im.instanceColor) im.instanceColor.needsUpdate = true;
      im.computeBoundingSphere();
      group.add(im);
    }
  }

  // --- ARCHETYPE B: Grand Two-Story Bengal Brick House (Paka Bari — 10.6m x 8.2m x 7.1m + rooftop parapet & balcony) ---
  if (pakaPlacements.length > 0) {
    const w = 10.6;
    const d = 8.2;
    const wallH = 6.9;
    const plinthH = 0.65;
    const skirtD = 2.2;

    // Part 1: Raised masonry plinth + deep hillside foundation + front porch steps + mid-floor cornice band
    const trimParts: THREE.BufferGeometry[] = [];
    const plinthBox = new THREE.BoxGeometry(w + 1.1, plinthH + skirtD, d + 1.4);
    plinthBox.translate(0, (plinthH - skirtD) * 0.5, 0.2);
    trimParts.push(plinthBox);
    const steps = new THREE.BoxGeometry(3.2, 0.42, 1.15);
    steps.translate(0, 0.21, d * 0.5 + 1.18);
    trimParts.push(steps);
    // Mid-floor projecting Bengal cornice belt
    const midCornice = new THREE.BoxGeometry(w + 0.55, 0.34, d + 0.55);
    midCornice.translate(0, plinthH + 3.45, 0);
    trimParts.push(midCornice);
    // Roofline cornice ledge
    const topCornice = new THREE.BoxGeometry(w + 0.72, 0.38, d + 0.72);
    topCornice.translate(0, plinthH + wallH, 0);
    trimParts.push(topCornice);
    // Front upper balcony slab & front verandah pillars
    const balconySlab = new THREE.BoxGeometry(w * 0.66, 0.26, 1.65);
    balconySlab.translate(0, plinthH + 3.42, d * 0.5 + 0.75);
    trimParts.push(balconySlab);
    const balconyRail = new THREE.BoxGeometry(w * 0.66, 0.95, 0.22);
    balconyRail.translate(0, plinthH + 4.02, d * 0.5 + 1.48);
    trimParts.push(balconyRail);
    for (const px of [-w * 0.3, 0, w * 0.3]) {
      const col = new THREE.BoxGeometry(0.36, 3.4, 0.36);
      col.translate(px, plinthH + 1.7, d * 0.5 + 1.25);
      trimParts.push(col);
    }
    const pakaTrimGeo = mergeNormalizedGeometries(trimParts, false);

    // Part 2: Main plastered two-story walls + 4 rooftop parapet walls + stair-head room (chhad ghar)
    const wallParts: THREE.BufferGeometry[] = [];
    const mainBody = new THREE.BoxGeometry(w, wallH, d);
    mainBody.translate(0, plinthH + wallH * 0.5, 0);
    wallParts.push(mainBody);
    // Rooftop parapet walls (gives authentic Bengali flat-roof silhouette)
    const paraH = 1.05;
    const paraY = plinthH + wallH + paraH * 0.5;
    const pFront = new THREE.BoxGeometry(w + 0.1, paraH, 0.36);
    pFront.translate(0, paraY, d * 0.5 - 0.18);
    wallParts.push(pFront);
    const pBack = new THREE.BoxGeometry(w + 0.1, paraH, 0.36);
    pBack.translate(0, paraY, -d * 0.5 + 0.18);
    wallParts.push(pBack);
    const pLeft = new THREE.BoxGeometry(0.36, paraH, d - 0.6);
    pLeft.translate(-w * 0.5 + 0.18, paraY, 0);
    wallParts.push(pLeft);
    const pRight = new THREE.BoxGeometry(0.36, paraH, d - 0.6);
    pRight.translate(w * 0.5 - 0.18, paraY, 0);
    wallParts.push(pRight);
    // Rooftop staircase room (চিলেকোঠা / Chilekotha)
    const chilekotha = new THREE.BoxGeometry(3.4, 2.35, 3.0);
    chilekotha.translate(-w * 0.24, plinthH + wallH + 1.18, -d * 0.18);
    wallParts.push(chilekotha);
    const pakaWallGeo = mergeNormalizedGeometries(wallParts, true);

    // Part 3: Heritage Bengali bottle-green louvered wooden doors & shutters across both floors & all 4 facades
    const shutterParts: THREE.BufferGeometry[] = [];
    // Grand front wooden doorway
    const frontDoor = new THREE.BoxGeometry(2.05, 3.05, 0.28);
    frontDoor.translate(0, plinthH + 1.52, d * 0.5 + 0.04);
    shutterParts.push(frontDoor);
    // Upper balcony door
    const upperDoor = new THREE.BoxGeometry(1.75, 2.75, 0.28);
    upperDoor.translate(0, plinthH + 4.92, d * 0.5 + 0.04);
    shutterParts.push(upperDoor);
    // Ground & 2nd floor front/back khorkhori shuttered windows
    for (const floorY of [plinthH + 2.05, plinthH + 5.2]) {
      for (const wx of [-w * 0.33, w * 0.33]) {
        const wF = new THREE.BoxGeometry(1.38, 1.72, 0.26);
        wF.translate(wx, floorY, d * 0.5 + 0.04);
        shutterParts.push(wF);
        const wB = new THREE.BoxGeometry(1.38, 1.72, 0.26);
        wB.translate(wx, floorY, -d * 0.5 - 0.04);
        shutterParts.push(wB);
      }
      // Side facade windows
      for (const sx of [-w * 0.5 - 0.04, w * 0.5 + 0.04]) {
        for (const wz of [-d * 0.22, d * 0.22]) {
          const wS = new THREE.BoxGeometry(0.26, 1.68, 1.32);
          wS.translate(sx, floorY, wz);
          shutterParts.push(wS);
        }
      }
    }
    const pakaShutterGeo = mergeNormalizedGeometries(shutterParts, false);

    // Part 4: Sloped terracotta sun-shade chhajjas (window awnings) & rooftop chilekotha roof cap
    const roofAccentParts: THREE.BufferGeometry[] = [];
    const chileCap = new THREE.BoxGeometry(3.9, 0.28, 3.5);
    chileCap.translate(-w * 0.24, plinthH + wallH + 2.42, -d * 0.18);
    roofAccentParts.push(chileCap);
    // Sloped balcony canopy
    const balcCanopy = new THREE.BoxGeometry(w * 0.72, 0.2, 1.85);
    balcCanopy.rotateX(0.22);
    balcCanopy.translate(0, plinthH + 6.52, d * 0.5 + 0.88);
    roofAccentParts.push(balcCanopy);
    // Window sun-shade ledges
    for (const floorY of [plinthH + 3.05, plinthH + 6.2]) {
      for (const wx of [-w * 0.33, w * 0.33]) {
        const shade = new THREE.BoxGeometry(1.72, 0.16, 0.58);
        shade.translate(wx, floorY, d * 0.5 + 0.26);
        roofAccentParts.push(shade);
      }
    }
    const pakaRoofGeo = mergeNormalizedGeometries(roofAccentParts, false);

    const n = pakaPlacements.length;
    const imTrim = new THREE.InstancedMesh(pakaTrimGeo, mats.pakaTrimMat, n);
    const imWall = new THREE.InstancedMesh(pakaWallGeo, mats.pakaPlasterMat, n);
    const imShutter = new THREE.InstancedMesh(pakaShutterGeo, mats.pakaShutterMat, n);
    const imRoof = new THREE.InstancedMesh(pakaRoofGeo, mats.pakaRoofTileMat, n);

    imTrim.receiveShadow = true;
    imWall.castShadow = true;
    imWall.receiveShadow = true;
    imRoof.castShadow = true;

    for (let i = 0; i < n; i++) {
      const p = pakaPlacements[i];
      dummy.position.set(p.x, p.y, p.z);
      dummy.rotation.set(0, p.rotY, 0);
      dummy.scale.setScalar(p.scale);
      dummy.updateMatrix();
      imTrim.setMatrixAt(i, dummy.matrix);
      imWall.setMatrixAt(i, dummy.matrix);
      imShutter.setMatrixAt(i, dummy.matrix);
      imRoof.setMatrixAt(i, dummy.matrix);
      tmpCol.setHex(p.tintHex);
      imWall.setColorAt(i, tmpCol);
    }

    for (const im of [imTrim, imWall, imShutter, imRoof]) {
      im.instanceMatrix.needsUpdate = true;
      if (im.instanceColor) im.instanceColor.needsUpdate = true;
      im.computeBoundingSphere();
      group.add(im);
    }
  }

  return group;
}

/**
 * Builds a realistic curved Coconut Palm Tree (Narkel Gach) using TubeGeometry + arched fronds + coconuts.
 */
function buildCoconutTree(
  textures: TextureBundle,
  height = 9.5,
  leanX = 1.1,
  leanZ = 0.6,
): { group: THREE.Group; crown: THREE.Group } {
  const tree = new THREE.Group();

  const trunkMat = new THREE.MeshStandardMaterial({
    map: textures.palmBarkMap,
    roughness: 0.9,
    metalness: 0.0,
  });
  const frondMat = new THREE.MeshStandardMaterial({
    map: textures.frondMap,
    alphaTest: 0.35,
    side: THREE.DoubleSide,
    roughness: 0.68,
    metalness: 0.02,
  });
  const coconutMat = new THREE.MeshStandardMaterial({
    color: 0x4b7826,
    roughness: 0.42,
    metalness: 0.05,
  });

  // 1. Curved organic trunk via TubeGeometry along CatmullRomCurve3
  const curve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, 0, 0),
    new THREE.Vector3(leanX * 0.25, height * 0.35, leanZ * 0.25),
    new THREE.Vector3(leanX * 0.72, height * 0.72, leanZ * 0.72),
    new THREE.Vector3(leanX, height, leanZ),
  ]);
  const trunkGeo = new THREE.TubeGeometry(curve, 12, 0.24, 8, false);
  // Gently taper trunk from base to top
  const posAttr = trunkGeo.attributes.position;
  for (let i = 0; i < posAttr.count; i++) {
    const y = posAttr.getY(i);
    const t = THREE.MathUtils.clamp(y / height, 0, 1);
    const center = curve.getPoint(t);
    const taper = THREE.MathUtils.lerp(1.22, 0.56, t);
    posAttr.setXYZ(
      i,
      center.x + (posAttr.getX(i) - center.x) * taper,
      y,
      center.z + (posAttr.getZ(i) - center.z) * taper,
    );
  }
  trunkGeo.computeVertexNormals();
  const trunk = new THREE.Mesh(trunkGeo, trunkMat);
  trunk.castShadow = true;
  trunk.receiveShadow = true;
  tree.add(trunk);

  // 2. Swaying crown group at the top of the trunk
  const crown = new THREE.Group();
  crown.position.set(leanX, height, leanZ);
  tree.add(crown);

  // Cluster of green Bengali coconuts (Daab) under crown
  const nutGeo = new THREE.SphereGeometry(0.19, 8, 8);
  nutGeo.scale(1, 1.18, 1);
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2;
    const nut = new THREE.Mesh(nutGeo, coconutMat);
    nut.position.set(Math.cos(a) * 0.28, -0.26 - (i % 2) * 0.14, Math.sin(a) * 0.28);
    crown.add(nut);
  }

  // 3. Curved palm frond geometry (bent PlaneGeometry)
  const frondGeo = new THREE.PlaneGeometry(3.6, 1.35, 8, 2);
  frondGeo.translate(1.8, 0, 0);
  const fp = frondGeo.attributes.position;
  for (let i = 0; i < fp.count; i++) {
    const fx = fp.getX(i);
    const fz = fp.getY(i); // before rotating flat
    const normX = fx / 3.6;
    const droopY = Math.sin(normX * Math.PI) * 0.55 - normX * normX * 1.15;
    const vFold = Math.abs(fz) * 0.18;
    fp.setXYZ(i, fx, droopY - vFold, fz);
  }
  frondGeo.computeVertexNormals();

  const frondCount = 10;
  for (let i = 0; i < frondCount; i++) {
    const angle = (i / frondCount) * Math.PI * 2 + (i % 2) * 0.18;
    const pitch = i % 2 === 0 ? 0.22 : -0.14;
    const frond = new THREE.Mesh(frondGeo, frondMat);
    frond.rotation.y = angle;
    frond.rotation.z = pitch;
    frond.castShadow = true;
    crown.add(frond);
  }

  addContactShadow(tree, textures.contactShadowMap, 3.0, 3.0, 0.38);
  return { group: tree, crown };
}

/**
 * Builds a traditional wooden Bengali river country boat (Nouka) floating near the Hooghly ghat.
 */
function buildRiverBoat(): THREE.Group {
  const boat = new THREE.Group();

  const woodDark = new THREE.MeshStandardMaterial({
    color: 0x3b2416,
    roughness: 0.85,
    metalness: 0.05,
  });
  const woodTrim = new THREE.MeshStandardMaterial({
    color: 0x8f3422,
    roughness: 0.72,
    metalness: 0.05,
  });
  const bambooCanopy = new THREE.MeshStandardMaterial({
    color: 0xb7965b,
    roughness: 0.92,
    side: THREE.DoubleSide,
  });

  // Curved hull
  const hull = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 0.55, 5.4, 10, 1, false, 0, Math.PI), woodDark);
  hull.rotation.z = Math.PI / 2;
  hull.rotation.x = Math.PI;
  hull.scale.set(1, 1, 0.82);
  hull.position.y = 0.25;
  boat.add(hull);

  // Raised pointed bow & stern prows
  for (const sx of [-2.95, 2.95]) {
    const prow = new THREE.Mesh(new THREE.ConeGeometry(0.42, 1.3, 6), woodTrim);
    prow.position.set(sx, 0.56, 0);
    prow.rotation.z = sx > 0 ? -Math.PI * 0.36 : Math.PI * 0.36;
    boat.add(prow);
  }

  // Arched bamboo chhoi (canopy) in middle of boat
  const canopy = new THREE.Mesh(
    new THREE.CylinderGeometry(0.92, 0.92, 2.2, 12, 1, true, -Math.PI * 0.45, Math.PI * 0.9),
    bambooCanopy,
  );
  canopy.rotation.z = Math.PI / 2;
  canopy.position.set(-0.2, 0.62, 0);
  boat.add(canopy);

  return boat;
}

/**
 * Analytical Red-Soil Laterite Hills elevation for শালবন ও লাল মাটির টিলা (West & NW sectors)
 * and gentle rolling outer Bengal countryside beyond the village/landmarks.
 * Guaranteed flat (0) across Village Square, Riverbank Ghat, Zamindar Bari, and Old Tram Depot.
 */
function sampleLateriteHillHeight(x: number, z: number): number {
  // Keep river channel, village square, ghat, Zamindar Bari estate, and Tram Depot completely level
  if (z > -76 && z < -6) return 0;
  if (x > -46 && x < 54 && z >= -18 && z < 46) return 0; // Village Square
  if (x > 64 && x < 134 && z > -14 && z < 56) return 0; // Zamindar Bari estate
  if (x > -88 && x < 88 && z < -70 && z > -196) return 0; // Old Tram Depot & Bazaar
  // Keep westbound & eastbound main heritage trails smooth
  if (x > -128 && x < 76 && z > 1 && z < 13) return 0;

  // Rarh Bengal laterite hill mounds & expanded countryside ridges across ±760m playable arena
  const hills: Array<[number, number, number, number]> = [
    // South-West Sal Forest & Red-Soil Hills (শালবন)
    [-92, 42, 6.4, 34],
    [-142, 66, 8.2, 42],
    [-190, 96, 7.6, 46],
    [-122, 118, 6.2, 38],
    [-176, 36, 5.8, 36],
    [-76, 84, 4.6, 28],
    [-226, 54, 7.4, 48],
    // Far West Rarh Laterite Highlands (রাঢ় লাল টিলা)
    [-345, 78, 9.6, 62],
    [-465, 165, 11.2, 74],
    [-585, 65, 10.4, 72],
    [-395, 295, 9.2, 68],
    [-570, 365, 11.8, 80],
    [-265, 435, 8.6, 66],
    // Far South Sundarban Fringe & Highland Mounds (সুন্দরবন প্রান্ত)
    [-20, 225, 5.8, 56],
    [136, 210, 6.4, 54],
    [-110, 365, 7.4, 64],
    [78, 395, 7.2, 66],
    [-190, 565, 9.2, 76],
    [160, 575, 8.8, 74],
    [15, 645, 7.8, 70],
    // Far East Meadows & Rolling Ridges (পূর্ব প্রান্তর)
    [195, 88, 6.2, 52],
    [325, 52, 7.8, 60],
    [455, 145, 9.4, 68],
    [350, 265, 8.2, 64],
    [555, 295, 10.6, 78],
    [585, 48, 9.0, 68],
    [420, 485, 9.8, 76],
    // North-West Sal Forest Hills & West Forestland across the river
    [-136, -124, 7.2, 40],
    [-188, -162, 8.4, 46],
    [-142, -196, 6.5, 38],
    [-234, -126, 7.8, 48],
    [-355, -175, 9.4, 66],
    [-490, -285, 11.0, 78],
    [-295, -395, 9.2, 68],
    [-565, -490, 11.6, 82],
    [-165, -540, 8.6, 70],
    // North-East Garden Bluffs & Distant Northern Ridges
    [224, -152, 6.6, 54],
    [355, -185, 8.4, 64],
    [255, -345, 9.0, 70],
    [485, -295, 10.4, 76],
    [575, -510, 11.2, 80],
    [85, -460, 7.8, 66],
    [-45, -610, 8.8, 74],
    [310, -590, 9.6, 74],
  ];

  let h = 0;
  for (let i = 0; i < hills.length; i++) {
    const [hx, hz, amp, sigma] = hills[i];
    const dx = x - hx;
    const dz = z - hz;
    const d2 = dx * dx + dz * dz;
    const cutoff = sigma * 3.1;
    if (d2 < cutoff * cutoff) {
      h += amp * Math.exp(-d2 / (2 * sigma * sigma));
    }
  }

  // Natural rolling perimeter ridge framing the outer playable boundary (|x| or |z| > 745)
  const edgeDist = Math.max(Math.abs(x), Math.abs(z));
  if (edgeDist > 745) {
    const rimT = Math.min(1, (edgeDist - 745) / 115);
    h += rimT * rimT * 16.5;
  }

  // Smooth river-edge and Kolkata market-plaza feathering so terrain meets riverbanks & urban pavements flush at y = 0
  const boxFlatMask = (minX: number, maxX: number, minZ: number, maxZ: number, feather: number) => {
    const dx = x < minX ? minX - x : x > maxX ? x - maxX : 0;
    const dz = z < minZ ? minZ - z : z > maxZ ? z - maxZ : 0;
    const d = Math.hypot(dx, dz);
    if (d <= 0) return 0;
    if (d >= feather) return 1;
    const t = d / feather;
    return t * t * (3 - 2 * t);
  };

  let edgeMask = 1;
  if (z >= -6 && z < 6) {
    edgeMask = Math.min(edgeMask, (z - -6) / 12);
  } else if (z <= -76 && z > -90) {
    edgeMask = Math.min(edgeMask, (-76 - z) / 14);
  }
  // Smoothly flatten Burrabazar (বড়বাজার) & Chor Bazaar (চোরবাজার) urban market plazas
  edgeMask = Math.min(edgeMask, boxFlatMask(74, 164, 68, 144, 20));
  edgeMask = Math.min(edgeMask, boxFlatMask(76, 150, -142, -76, 20));
  return h * Math.max(0, Math.min(1, edgeMask));
}

/**
 * Computes red-soil laterite blend weight [0..1] for vertex coloring the Sal Forest & Rarh hills.
 */
function sampleLateriteSoilWeight(x: number, z: number, height: number): number {
  const inSwSalbon = x < -46 && x > -680 && z > -10 && z < 490;
  const inNwSalbon = x < -84 && x > -680 && z < -76 && z > -580;
  if (!inSwSalbon && !inNwSalbon) {
    return THREE.MathUtils.clamp((height - 3.6) * 0.11, 0, 0.42);
  }
  const edgeFade = inSwSalbon
    ? THREE.MathUtils.clamp((-46 - x) / 30, 0, 1)
    : THREE.MathUtils.clamp((-84 - x) / 30, 0, 1);
  return THREE.MathUtils.clamp(edgeFade * (0.58 + height * 0.075), 0, 1);
}

/**
 * Builds a subdivided 1000m+ Bengal ground mesh with baked laterite hills & red-soil vertex colors.
 */
function buildTerrainPlane(
  width: number,
  depth: number,
  segX: number,
  segZ: number,
  centerZ: number,
  textures: TextureBundle,
): THREE.Mesh {
  const geo = new THREE.PlaneGeometry(width, depth, segX, segZ);
  geo.rotateX(-Math.PI / 2);

  const pos = geo.attributes.position;
  const colors = new Float32Array(pos.count * 3);
  const grassTint = new THREE.Color(0xdce9c4); // rich sunlit alluvial meadow tint
  const meadowDeepTint = new THREE.Color(0xb8cf98); // subtle shaded meadow trough variation
  const sunlitCrestTint = new THREE.Color(0xebe4be); // warm sunlit highland crest
  const lateriteTint = new THREE.Color(0xc45630); // rich Rarh Bengal reddish laterite soil
  const deepLaterite = new THREE.Color(0x94361c);
  const tmpColor = new THREE.Color();

  for (let i = 0; i < pos.count; i++) {
    const wx = pos.getX(i);
    const wz = pos.getZ(i) + centerZ;
    const h = sampleLateriteHillHeight(wx, wz);
    pos.setY(i, h);

    // Subtle organic meadow tonal variation so wide open countryside has natural depth
    const meadowWave = 0.5 + 0.5 * Math.sin(wx * 0.024 + wz * 0.017) * Math.cos(wx * 0.013 - wz * 0.028);
    tmpColor.copy(meadowDeepTint).lerp(grassTint, 0.35 + meadowWave * 0.65);
    if (h > 2.0) {
      tmpColor.lerp(sunlitCrestTint, Math.min(0.26, (h - 2.0) * 0.035));
    }

    const redW = sampleLateriteSoilWeight(wx, wz, h);
    tmpColor.lerp(lateriteTint, redW);
    if (h > 4.5 && redW > 0.35) {
      tmpColor.lerp(deepLaterite, Math.min(0.48, (h - 4.5) * 0.1));
    }
    colors[i * 3] = tmpColor.r;
    colors[i * 3 + 1] = tmpColor.g;
    colors[i * 3 + 2] = tmpColor.b;
  }

  geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  geo.computeVertexNormals();

  // Scale UVs cleanly so the tiled ground texture stays crisp across expanded terrain
  const uv = geo.attributes.uv;
  const repeatX = width / 24;
  const repeatZ = depth / 24;
  for (let i = 0; i < uv.count; i++) {
    uv.setXY(i, uv.getX(i) * repeatX, uv.getY(i) * repeatZ);
  }

  const mat = new THREE.MeshStandardMaterial({
    map: textures.groundMap,
    bumpMap: textures.groundBump,
    bumpScale: 0.24,
    roughness: 0.92,
    metalness: 0.0,
    vertexColors: true,
  });

  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.set(0, 0, centerZ);
  mesh.receiveShadow = true;
  return mesh;
}

/**
 * Builds the two walkable & drivable Howrah Bridge Crossing Approaches connecting the South
 * Village/Ghat bank (z = -11.5, y = 0) up to the Howrah Bridge Deck (z = -35.4..-44.6, y = 6.58)
 * and down onto the North Bank (z = -72.0, y = 0) straight into Old Tram Depot & Bazaar.
 */
function buildBridgeCrossingRamps(): THREE.Group {
  const group = new THREE.Group();
  const deckY = 6.58;
  const rampWidth = 8.0;

  const asphaltMat = new THREE.MeshStandardMaterial({
    color: 0x3f4348,
    roughness: 0.88,
    metalness: 0.06,
  });
  const railMat = new THREE.MeshStandardMaterial({
    color: 0x8e9aa3,
    roughness: 0.48,
    metalness: 0.72,
  });
  const pierMat = new THREE.MeshStandardMaterial({
    color: 0x8e8173,
    roughness: 0.92,
  });
  const stripeMat = new THREE.MeshStandardMaterial({
    color: 0xf4d268,
    roughness: 0.7,
  });

  const laneCenters = [-17.5, 17.5]; // Each 8m wide: [-21.5, -13.5] and [13.5, 21.5]

  const addSlopedSpan = (cx: number, z0: number, y0: number, z1: number, y1: number) => {
    const dz = z1 - z0;
    const dy = y1 - y0;
    const len = Math.hypot(dz, dy);
    const pitch = Math.atan2(dy, dz); // Note: Three.js BoxGeometry rotated around X

    const span = new THREE.Group();
    span.position.set(cx, (y0 + y1) * 0.5, (z0 + z1) * 0.5);
    span.rotation.x = -pitch;

    const slab = new THREE.Mesh(new THREE.BoxGeometry(rampWidth, 0.55, len + 0.4), asphaltMat);
    slab.position.y = -0.275;
    slab.castShadow = true;
    slab.receiveShadow = true;
    span.add(slab);

    // Center dashed yellow road stripe
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.03, len - 1.2), stripeMat);
    stripe.position.y = 0.02;
    span.add(stripe);

    // Twin steel safety guardrails
    for (const sx of [-rampWidth * 0.5 + 0.2, rampWidth * 0.5 - 0.2]) {
      const curb = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.95, len + 0.2), railMat);
      curb.position.set(sx, 0.45, 0);
      curb.castShadow = true;
      span.add(curb);
    }

    group.add(span);

    // Masonry support piers underneath the elevated approach span
    for (const t of [0.38, 0.74]) {
      const pz = THREE.MathUtils.lerp(z0, z1, t);
      const py = THREE.MathUtils.lerp(y0, y1, t);
      if (py > 1.2) {
        const pier = new THREE.Mesh(new THREE.BoxGeometry(rampWidth - 1.2, py + 1.8, 1.3), pierMat);
        pier.position.set(cx, (py - 1.8) * 0.5, pz);
        pier.castShadow = true;
        group.add(pier);
      }
    }
  };

  for (const cx of laneCenters) {
    // South approach ramp: Village Ghat (z = -11.5, y = 0) up to Bridge Deck (z = -35.4, y = 6.58)
    addSlopedSpan(cx, -11.5, 0.0, -35.4, deckY);
    // North descent ramp: Bridge Deck (z = -44.6, y = 6.58) down to Tram Depot Bank (z = -72.0, y = 0)
    addSlopedSpan(cx, -44.6, deckY, -72.0, 0.0);
  }

  return group;
}

/**
 * Analytical elevation for the Howrah Bridge deck and its North/South crossing ramps.
 * Returns null if (x, z) is not on a crossing ramp or bridge deck.
 */
function sampleBridgeCrossingHeight(x: number, z: number): number | null {
  const deckY = 6.58;
  const onWestLane = x >= -21.5 && x <= -13.5;
  const onEastLane = x >= 13.5 && x <= 21.5;

  // Main Howrah Bridge East-West deck (walkable across the iconic steel span!)
  if (x >= -66 && x <= 66 && z <= -35.2 && z >= -44.8) {
    return deckY;
  }

  if (onWestLane || onEastLane) {
    // South ramp: z from -11.5 (y=0) to -35.4 (y=6.58)
    if (z <= -11.5 && z >= -35.4) {
      const t = THREE.MathUtils.clamp((-11.5 - z) / (-11.5 - -35.4), 0, 1);
      return t * deckY;
    }
    // North ramp: z from -44.6 (y=6.58) down to -72.0 (y=0)
    if (z <= -44.6 && z >= -72.0) {
      const t = THREE.MathUtils.clamp((-44.6 - z) / (-44.6 - -72.0), 0, 1);
      return (1 - t) * deckY;
    }
  }

  return null;
}

/**
 * Builds the expanded 1000x1000 West Bengal Hooghly Riverbank Battle Royale World
 * featuring the Village, Howrah Bridge, Red-Soil Sal Forest & Hills, Abandoned Zamindar Bari,
 * Old Tram Depot & Bazaar, and Extended Riverbank Ghat with Wooden Boats.
 */
export function buildWestBengalWorld(textures: TextureBundle): WorldBuildResult {
  const worldGroup = new THREE.Group();
  const boxColliders: BoxCollider[] = [];
  const circleColliders: CircleCollider[] = [];
  const swayingPalms: SwayingPalm[] = [];
  const bobbingBoats: THREE.Group[] = [];
  const landmarkChestAnchors: ChestAnchor[] = [];
  const landmarkSanjibaniAnchors: Array<{ x: number; z: number }> = [];

  // 1. Bright sunny daytime sky dome (radius 1950 encompasses expanded 1520x1520 map & 820u Safe Zone cleanly)
  const skyGeo = new THREE.SphereGeometry(1950, 32, 20);
  const skyMat = new THREE.MeshBasicMaterial({
    map: textures.skyMap,
    side: THREE.BackSide,
    fog: false,
    depthWrite: false,
  });
  const skyDome = new THREE.Mesh(skyGeo, skyMat);
  worldGroup.add(skyDome);

  // 2. Expanded 1520x1520+ Playable Subdivided Terrain (South Bank z=-20..+860 + North Bank z=-950..-70)
  const southTerrain = buildTerrainPlane(1840, 880, 128, 68, 420, textures);
  worldGroup.add(southTerrain);

  const northTerrain = buildTerrainPlane(1840, 880, 128, 68, -510, textures);
  worldGroup.add(northTerrain);

  // Distant Kolkata skyline silhouettes pushed behind the expanded North perimeter (z = -805..-855)
  const skylineMat = new THREE.MeshStandardMaterial({
    color: 0x6f7582,
    roughness: 0.88,
    metalness: 0.05,
  });
  for (let i = -18; i <= 18; i++) {
    const h = 14 + ((Math.abs(i * 7 + 3) % 6) * 5.2);
    const w = 14 + ((Math.abs(i * 3) % 4) * 4.5);
    const bldg = new THREE.Mesh(new THREE.BoxGeometry(w, h, 14), skylineMat);
    bldg.position.set(i * 34, h * 0.5, -812 - (Math.abs(i) % 4) * 16);
    worldGroup.add(bldg);
  }

  // Dusty red-earth village lanes & connecting heritage roads to Sal Forest (West) and Zamindar Bari (East)
  const roadMat = new THREE.MeshStandardMaterial({
    color: 0x9c683e,
    bumpMap: textures.groundBump,
    bumpScale: 0.16,
    roughness: 0.94,
    metalness: 0.0,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const mainLane = new THREE.Mesh(new THREE.PlaneGeometry(7.2, 54), roadMat);
  mainLane.rotation.x = -Math.PI / 2;
  mainLane.position.set(0, 0.03, 12);
  mainLane.receiveShadow = true;
  worldGroup.add(mainLane);

  // Extended East-West Heritage Road connecting Sal Forest (x = -124) <-> Village <-> Zamindar Bari (x = 78)
  const crossLane = new THREE.Mesh(new THREE.PlaneGeometry(202, 6.4), roadMat);
  crossLane.rotation.x = -Math.PI / 2;
  crossLane.position.set(-23, 0.035, 7);
  crossLane.receiveShadow = true;
  worldGroup.add(crossLane);

  // Branch drive leading into Zamindar Bari & continuing south straight to Kolkata Burrabazar (বড়বাজার)
  const zamindarDrive = new THREE.Mesh(new THREE.PlaneGeometry(6.4, 108), roadMat);
  zamindarDrive.rotation.x = -Math.PI / 2;
  zamindarDrive.position.set(74, 0.038, 58);
  zamindarDrive.receiveShadow = true;
  worldGroup.add(zamindarDrive);

  // Connecting urban avenue spurs into Burrabazar West/North Gates & Chor Bazaar West Gate
  const urbanConnectorMat = new THREE.MeshStandardMaterial({
    color: 0x525150,
    roughness: 0.92,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const burraWestSpur = new THREE.Mesh(new THREE.PlaneGeometry(14, 7.2), urbanConnectorMat);
  burraWestSpur.rotation.x = -Math.PI / 2;
  burraWestSpur.position.set(76, 0.042, 107);
  burraWestSpur.receiveShadow = true;
  worldGroup.add(burraWestSpur);

  const burraNorthSpur = new THREE.Mesh(new THREE.PlaneGeometry(7.2, 24), urbanConnectorMat);
  burraNorthSpur.rotation.x = -Math.PI / 2;
  burraNorthSpur.position.set(116, 0.042, 64);
  burraNorthSpur.receiveShadow = true;
  worldGroup.add(burraNorthSpur);

  const chorWestSpur = new THREE.Mesh(new THREE.PlaneGeometry(14, 8.2), urbanConnectorMat);
  chorWestSpur.rotation.x = -Math.PI / 2;
  chorWestSpur.position.set(78, 0.041, -108);
  chorWestSpur.receiveShadow = true;
  worldGroup.add(chorWestSpur);

  // 3. Hooghly River Ghat Embankments (South + North Bank spanning full 1840m width) + Central Stone Steps
  const ghatStoneMat = new THREE.MeshStandardMaterial({
    color: 0x9b8d7e,
    roughness: 0.88,
    metalness: 0.04,
  });
  const embankment = new THREE.Mesh(new THREE.BoxGeometry(1840, 2.2, 4.2), ghatStoneMat);
  embankment.position.set(0, -0.95, -18.2);
  embankment.receiveShadow = true;
  worldGroup.add(embankment);

  const northEmbankment = new THREE.Mesh(new THREE.BoxGeometry(1840, 2.2, 4.2), ghatStoneMat);
  northEmbankment.position.set(0, -0.95, -71.5);
  northEmbankment.receiveShadow = true;
  worldGroup.add(northEmbankment);

  // Central Ghat descending steps
  for (let s = 0; s < 5; s++) {
    const step = new THREE.Mesh(new THREE.BoxGeometry(20, 0.36, 1.1), ghatStoneMat);
    step.position.set(0, -0.18 - s * 0.28, -19.2 - s * 0.95);
    step.receiveShadow = true;
    worldGroup.add(step);
  }

  // Low heritage Bengal red-brick parapet walls flanking center ghat (leaving bridge ramp portals open!)
  const parapetMat = new THREE.MeshStandardMaterial({
    color: 0x9a4b35,
    roughness: 0.85,
  });
  for (const side of [-1, 1]) {
    const wall = new THREE.Mesh(new THREE.BoxGeometry(16, 0.9, 0.6), parapetMat);
    wall.position.set(side * 30.5, 0.45, -17.6);
    wall.castShadow = true;
    wall.receiveShadow = true;
    worldGroup.add(wall);
  }

  // 4. Shimmering Hooghly River water spanning full 1840m East-West map width
  const waterUniforms = { uTime: { value: 0 } };
  const waterMat = new THREE.MeshStandardMaterial({
    color: 0x266578,
    roughness: 0.18,
    metalness: 0.4,
    bumpMap: textures.waterBump,
    bumpScale: 0.16,
  });
  waterMat.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = waterUniforms.uTime;
    shader.vertexShader =
      `uniform float uTime;\n` +
      shader.vertexShader.replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
         float waveA = sin(position.x * 0.14 + uTime * 1.45) * 0.11;
         float waveB = cos(position.y * 0.22 - uTime * 1.15) * 0.08;
         transformed.z += waveA + waveB;`,
      );
  };
  const riverMesh = new THREE.Mesh(new THREE.PlaneGeometry(1840, 56, 84, 16), waterMat);
  riverMesh.rotation.x = -Math.PI / 2;
  riverMesh.position.set(0, -1.25, -45);
  riverMesh.receiveShadow = true;
  worldGroup.add(riverMesh);

  // Original floating wooden country boat (Nouka) near the central ghat
  const boatGroup = buildRiverBoat();
  boatGroup.position.set(-8.5, -1.18, -26.2);
  boatGroup.rotation.y = 0.22;
  worldGroup.add(boatGroup);
  bobbingBoats.push(boatGroup);

  // 5. Iconic Howrah-style Cantilever Bridge + Walkable/Drivable North-South Crossing Ramps
  const bridge = buildHowrahBridge(textures);
  worldGroup.add(bridge);

  const crossingRamps = buildBridgeCrossingRamps();
  worldGroup.add(crossingRamps);

  // 6. Iconic Kolkata Yellow Ambassador Taxi parked near the village ghat road
  const taxi = buildYellowTaxi(textures);
  taxi.position.set(7.2, 0, -4.5);
  taxi.rotation.y = -0.35;
  worldGroup.add(taxi);
  circleColliders.push(
    { x: 6.1, z: -4.9, radius: 1.4, height: 1.85, kind: 'taxi' },
    { x: 8.3, z: -4.1, radius: 1.4, height: 1.85, kind: 'taxi' },
  );

  // Shared material set for all village houses & instanced regional buildings
  const buildingMats = createBuildingMaterials(textures);
  const buildingClearZones: Array<{ x: number; z: number; r: number }> = [];
  const isNearAnyBuilding = (x: number, z: number, extraPad = 0): boolean => {
    for (let i = 0; i < buildingClearZones.length; i++) {
      const bz = buildingClearZones[i];
      const minD = bz.r + extraPad;
      const dx = x - bz.x;
      const dz = z - bz.z;
      if (dx * dx + dz * dz < minD * minD) return true;
    }
    return false;
  };

  // 7. Enlarged Core Village Mud Houses (Matir Ghor) framing the village square cleanly around roads, bus route & lobby sightline
  const houseSpecs = [
    { x: -24.5, z: -4.2, rotY: 0.35, w: 8.4, d: 6.4, h: 4.1 },
    { x: -24.0, z: 19.5, rotY: 1.25, w: 8.8, d: 6.6, h: 4.2 },
    { x: 23.5, z: 18.8, rotY: -1.35, w: 8.6, d: 6.6, h: 4.1 },
    { x: -11.5, z: 32.5, rotY: 0.15, w: 8.6, d: 6.4, h: 4.1 },
    { x: 13.5, z: 32.0, rotY: -0.22, w: 8.8, d: 6.6, h: 4.2 },
    { x: 26.0, z: -6.2, rotY: -0.55, w: 8.0, d: 6.0, h: 4.0 },
  ];

  for (const hs of houseSpecs) {
    const house = buildMudHouse(textures, buildingMats, hs.w, hs.d, hs.h);
    house.position.set(hs.x, 0, hs.z);
    house.rotation.y = hs.rotY;
    worldGroup.add(house);

    addBuildingFootprintColliders(
      circleColliders,
      hs.x,
      hs.z,
      hs.w + 0.5,
      hs.d + 0.65,
      hs.rotY,
      hs.h + 2.6,
      0,
    );
    buildingClearZones.push({ x: hs.x, z: hs.z, r: Math.max(hs.w, hs.d) * 0.65 + 2.2 });
  }

  // 7b. Curated Village Outskirts Ring + 8 Regional West Bengal Settlements (52 large batched buildings in 8 draw calls!)
  const mudWallTints = [0xf7eedc, 0xf2e1c4, 0xead4b3, 0xf8e8cc, 0xe5cca6];
  const pakaFacadeTints = [0xf0d29c, 0xe8b88a, 0xede3cc, 0xdf9f7c, 0xe4c99e, 0xd8b489];

  const regionalBuildingBlueprints: Array<{
    x: number;
    z: number;
    rotY: number;
    kind: 'mud' | 'paka';
    scale?: number;
    loot?: boolean;
  }> = [
    // --- Village Outskirts Ring (expands central বাংলার গ্রাম smoothly without blocking roads or bus route) ---
    { x: -40, z: 24, rotY: 0.95, kind: 'paka', scale: 1.02 },
    { x: -34, z: 45, rotY: 0.45, kind: 'mud', scale: 1.06 },
    { x: -13, z: 55, rotY: 0.08, kind: 'paka', scale: 1.06 },
    { x: 19, z: 54, rotY: -0.15, kind: 'mud', scale: 1.05 },
    { x: 42, z: 36, rotY: -0.85, kind: 'paka', scale: 1.04 },
    { x: 47, z: 20, rotY: -1.35, kind: 'mud', scale: 1.02 },

    // --- Settlement 1: South Highway Bazaar & Compound (দক্ষিণ চক — rich mid-south tactical town) ---
    { x: -46, z: 122, rotY: 0.42, kind: 'paka', scale: 1.08, loot: true },
    { x: -20, z: 138, rotY: -0.25, kind: 'mud', scale: 1.1 },
    { x: -58, z: 156, rotY: 1.15, kind: 'mud', scale: 1.04 },
    { x: 38, z: 132, rotY: -0.6, kind: 'paka', scale: 1.06 },
    { x: 72, z: 152, rotY: -1.25, kind: 'paka', scale: 1.1, loot: true },
    { x: 48, z: 174, rotY: 0.25, kind: 'mud', scale: 1.08 },

    // --- Settlement 2: Salbon Foothill Hamlet (শালবন পাড়া — West/SW forest edge) ---
    { x: -118, z: 124, rotY: 0.75, kind: 'mud', scale: 1.06, loot: true },
    { x: -144, z: 146, rotY: 0.2, kind: 'paka', scale: 1.04 },
    { x: -112, z: 162, rotY: -0.5, kind: 'mud', scale: 1.02 },
    { x: -205, z: 68, rotY: 1.05, kind: 'paka', scale: 1.05 },
    { x: -232, z: 92, rotY: 0.38, kind: 'mud', scale: 1.08 },

    // --- Settlement 3: Rarh Red-Soil Village (রাঢ় গ্রাম — Far West laterite highlands) ---
    { x: -248, z: 186, rotY: 0.5, kind: 'mud', scale: 1.12, loot: true },
    { x: -282, z: 208, rotY: -0.35, kind: 'paka', scale: 1.08 },
    { x: -312, z: 184, rotY: 1.2, kind: 'mud', scale: 1.05 },
    { x: -415, z: 270, rotY: 1.1, kind: 'paka', scale: 1.12, loot: true },
    { x: -446, z: 296, rotY: 0.4, kind: 'mud', scale: 1.08 },
    { x: -392, z: 312, rotY: -0.65, kind: 'mud', scale: 1.04 },

    // --- Settlement 4: Sundarban Fringe Settlement (সুন্দরবন পল্লী — Far South) ---
    { x: -115, z: 340, rotY: -0.3, kind: 'mud', scale: 1.1, loot: true },
    { x: -148, z: 362, rotY: 0.55, kind: 'paka', scale: 1.08 },
    { x: -96, z: 378, rotY: -1.1, kind: 'mud', scale: 1.04 },
    { x: 165, z: 280, rotY: -0.9, kind: 'paka', scale: 1.08, loot: true },
    { x: 138, z: 308, rotY: 0.35, kind: 'mud', scale: 1.1 },
    { x: 184, z: 324, rotY: -1.4, kind: 'mud', scale: 1.04 },

    // --- Settlement 5: Purba Prantor Farmstead (পূর্ব প্রান্তর পাড়া — East Meadows) ---
    { x: 196, z: 118, rotY: -0.75, kind: 'paka', scale: 1.08, loot: true },
    { x: 224, z: 138, rotY: -1.3, kind: 'mud', scale: 1.06 },
    { x: 204, z: 162, rotY: 0.4, kind: 'mud', scale: 1.08 },
    { x: 345, z: 135, rotY: -1.4, kind: 'paka', scale: 1.12, loot: true },
    { x: 372, z: 164, rotY: -0.45, kind: 'paka', scale: 1.06 },
    { x: 332, z: 178, rotY: 0.8, kind: 'mud', scale: 1.08 },

    // --- Settlement 6: South-East River Estate (দক্ষিণ-পূর্ব গ্রাম — Far SE) ---
    { x: 425, z: 365, rotY: 2.3, kind: 'paka', scale: 1.12, loot: true },
    { x: 394, z: 390, rotY: 1.4, kind: 'mud', scale: 1.08 },
    { x: 268, z: 432, rotY: -0.5, kind: 'paka', scale: 1.06 },
    { x: 298, z: 454, rotY: 0.65, kind: 'mud', scale: 1.05 },

    // --- Settlement 7: Paschim Bonanchal Forest Outpost (পশ্চিম বনাঞ্চল — North-West across river) ---
    { x: -162, z: -178, rotY: 0.45, kind: 'paka', scale: 1.08, loot: true },
    { x: -194, z: -198, rotY: -0.35, kind: 'mud', scale: 1.08 },
    { x: -174, z: -222, rotY: 1.15, kind: 'mud', scale: 1.04 },
    { x: -285, z: -265, rotY: 0.8, kind: 'paka', scale: 1.12, loot: true },
    { x: -318, z: -290, rotY: 0.15, kind: 'mud', scale: 1.08 },
    { x: -272, z: -308, rotY: -0.75, kind: 'mud', scale: 1.05 },

    // --- Settlement 8: Uttar Baganbari Villas (উত্তর বাগানবাড়ি — North-East & Far North across river) ---
    { x: 158, z: -136, rotY: -0.85, kind: 'paka', scale: 1.1, loot: true },
    { x: 188, z: -158, rotY: -0.25, kind: 'mud', scale: 1.06 },
    { x: 164, z: -182, rotY: 0.65, kind: 'paka', scale: 1.05 },
    { x: 265, z: -255, rotY: -0.7, kind: 'paka', scale: 1.12, loot: true },
    { x: 298, z: -278, rotY: -1.3, kind: 'mud', scale: 1.08 },
    { x: 42, z: -282, rotY: 0.25, kind: 'paka', scale: 1.08 },
    { x: 74, z: -302, rotY: -0.55, kind: 'mud', scale: 1.06 },
  ];

  const instancedMudPlacements: InstancedBuildingPlacement[] = [];
  const instancedPakaPlacements: InstancedBuildingPlacement[] = [];

  regionalBuildingBlueprints.forEach((bp, idx) => {
    const scale = bp.scale ?? 1.0;
    const by = sampleLateriteHillHeight(bp.x, bp.z);
    if (bp.kind === 'mud') {
      instancedMudPlacements.push({
        x: bp.x,
        y: by,
        z: bp.z,
        rotY: bp.rotY,
        scale,
        tintHex: mudWallTints[idx % mudWallTints.length],
      });
      addBuildingFootprintColliders(
        circleColliders,
        bp.x,
        bp.z,
        9.2 * scale,
        7.3 * scale,
        bp.rotY,
        7.0 * scale,
        by,
      );
      buildingClearZones.push({ x: bp.x, z: bp.z, r: 7.4 * scale });
    } else {
      instancedPakaPlacements.push({
        x: bp.x,
        y: by,
        z: bp.z,
        rotY: bp.rotY,
        scale,
        tintHex: pakaFacadeTints[idx % pakaFacadeTints.length],
      });
      addBuildingFootprintColliders(
        circleColliders,
        bp.x,
        bp.z,
        11.0 * scale,
        8.8 * scale,
        bp.rotY,
        8.4 * scale,
        by,
      );
      buildingClearZones.push({ x: bp.x, z: bp.z, r: 8.6 * scale });
    }

    // Place a Warrior Loot Chest & Sanjibani herb outside key regional settlement compounds
    if (bp.loot) {
      const standoff = bp.kind === 'paka' ? 8.2 * scale : 6.8 * scale;
      const frontX = bp.x + Math.sin(bp.rotY) * standoff;
      const frontZ = bp.z + Math.cos(bp.rotY) * standoff;
      landmarkChestAnchors.push({
        x: frontX,
        y: sampleLateriteHillHeight(frontX, frontZ),
        z: frontZ,
        rotY: bp.rotY + Math.PI,
      });
      landmarkSanjibaniAnchors.push({
        x: bp.x - Math.cos(bp.rotY) * (standoff + 1.0),
        z: bp.z + Math.sin(bp.rotY) * (standoff + 1.0),
      });
    }
  });

  const regionalBuildingsGroup = buildInstancedCountrysideBuildings(
    buildingMats,
    instancedMudPlacements,
    instancedPakaPlacements,
  );
  worldGroup.add(regionalBuildingsGroup);

  // 8. Coconut Palm Trees (Narkel Gach) inside the village + scenic flanking groves (positioned cleanly clear of enlarged houses)
  const innerPalms: [number, number, number, number, number][] = [
    [-11.0, -13.5, 10.2, 1.2, -0.8],
    [11.4, -13.0, 9.6, -1.0, -0.9],
    [-25.5, -12.8, 10.8, 1.4, -0.4],
    [28.5, -14.8, 9.8, -1.2, 0.5],
    [-11.0, 4.5, 9.2, 0.9, 0.7],
    [13.0, 4.8, 10.4, -1.1, 0.6],
    [-26.5, 5.5, 10.6, 1.3, 0.4],
    [26.8, 5.2, 9.5, -0.9, -0.5],
    [-15.0, 23.0, 9.8, 0.7, 1.1],
    [2.5, 22.5, 10.5, -0.8, 0.9],
    [31.5, 26.5, 9.6, -1.0, 0.8],
    [-32.0, 14.5, 11.0, 1.1, -0.7],
  ];

  innerPalms.forEach(([x, z, h, lx, lz], idx) => {
    const { group, crown } = buildCoconutTree(textures, h, lx, lz);
    group.position.set(x, 0, z);
    worldGroup.add(group);
    swayingPalms.push({
      crown,
      phase: idx * 1.17,
      baseRotX: 0,
      baseRotZ: 0,
    });
    circleColliders.push({ x, z, radius: 0.62, height: h, baseY: 0, kind: 'tree' });
  });

  // Outer Bengal village palms (keeping East/West heritage road corridors and all village-ring buildings open!)
  for (let i = 0; i < 24; i++) {
    const angle = (i / 24) * Math.PI * 1.35 - Math.PI * 0.175;
    const radius = 38 + (i % 3) * 5;
    const x = Math.cos(angle) * radius;
    const z = Math.sin(angle) * radius + 10;
    if (z < -15) continue;
    if (z > 1 && z < 13) continue; // Keep westbound & eastbound landmark roads open
    if (isNearAnyBuilding(x, z, 2.2)) continue;
    const h = 9.0 + (i % 4) * 1.4;
    const { group, crown } = buildCoconutTree(
      textures,
      h,
      Math.cos(i) * 1.2,
      Math.sin(i) * 1.0,
    );
    group.position.set(x, sampleLateriteHillHeight(x, z), z);
    worldGroup.add(group);
    swayingPalms.push({ crown, phase: i * 0.73, baseRotX: 0, baseRotZ: 0 });
  }

  // 9. Instanced tropical bushes & hibiscus shrubs around village houses (kept cleanly outside enlarged footprints)
  const bushCount = 68;
  const bushGeo = new THREE.DodecahedronGeometry(0.95, 1);
  const bushMat = new THREE.MeshStandardMaterial({
    color: 0x3b6e28,
    roughness: 0.88,
    metalness: 0.0,
  });
  const bushes = new THREE.InstancedMesh(bushGeo, bushMat, bushCount);
  const dummy = new THREE.Object3D();
  const color = new THREE.Color();
  const bushPalette = [0x336522, 0x457b2d, 0x2a561e, 0x558432];

  let bIdx = 0;
  for (let i = 0; i < bushCount; i++) {
    const isOuter = i >= 22;
    let bx: number;
    let bz: number;
    if (isOuter) {
      const a = ((i - 22) / (bushCount - 22)) * Math.PI * 1.32 - Math.PI * 0.16;
      const r = 35.5 + (i % 4) * 2.6;
      bx = Math.cos(a) * r;
      bz = Math.sin(a) * r + 10;
      if (bz < -15.5) bz = 38 + (i % 5) * 2;
      if (bz > 1.5 && bz < 12.5) bz += 11; // Clear roads
      if (isNearAnyBuilding(bx, bz, 1.4)) continue;
    } else {
      const hs = houseSpecs[i % houseSpecs.length];
      const ang = (i * 2.1) % (Math.PI * 2);
      bx = hs.x + Math.cos(ang) * (hs.w * 0.56 + 1.35);
      bz = hs.z + Math.sin(ang) * (hs.d * 0.58 + 1.35);
      if (bz > 1.8 && bz < 12.2) continue;
    }
    const s = 0.65 + (i % 5) * 0.22;
    const by = sampleLateriteHillHeight(bx, bz);
    dummy.position.set(bx, by + s * 0.55, bz);
    dummy.rotation.set(0, i * 0.9, 0);
    dummy.scale.set(s * 1.25, s * 0.78, s * 1.15);
    dummy.updateMatrix();
    bushes.setMatrixAt(bIdx, dummy.matrix);
    color.setHex(bushPalette[i % bushPalette.length]);
    bushes.setColorAt(bIdx, color);
    bIdx++;
  }
  bushes.count = bIdx;
  bushes.instanceMatrix.needsUpdate = true;
  if (bushes.instanceColor) bushes.instanceColor.needsUpdate = true;
  bushes.computeBoundingSphere();
  worldGroup.add(bushes);

  // 10. Low tactical village crate cover clusters in the open square
  const crateMat = new THREE.MeshStandardMaterial({
    color: 0x8b623c,
    roughness: 0.88,
  });
  const coverPositions: [number, number, number][] = [
    [-6.5, 4.5, 0.2],
    [5.8, 14.5, -0.4],
    [-4.5, -10.5, 0.1],
  ];
  for (const [cx, cz, rot] of coverPositions) {
    const cluster = new THREE.Group();
    cluster.position.set(cx, 0, cz);
    cluster.rotation.y = rot;

    const c1 = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.95, 1.0), crateMat);
    c1.position.set(0, 0.475, 0);
    c1.castShadow = true;
    c1.receiveShadow = true;
    cluster.add(c1);

    const c2 = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.78, 0.95), crateMat);
    c2.position.set(1.15, 0.39, 0.15);
    c2.rotation.y = 0.25;
    c2.castShadow = true;
    cluster.add(c2);

    addContactShadow(cluster, textures.contactShadowMap, 3.2, 2.0, 0.42);
    worldGroup.add(cluster);
    circleColliders.push({ x: cx + 0.35, z: cz, radius: 1.35, height: 1.0, kind: 'prop' });
  }

  // ============================================================================
  // 11. FOUR EXPANDED WEST BENGAL LANDMARKS ACROSS THE 1000x1000 ARENA
  // ============================================================================

  // Landmark 1: শালবন ও লাল মাটির টিলা (Red-Soil Sal Forest & Hills — West / NW Sector)
  const salForest = buildSalForestAndHills(sampleLateriteHillHeight);
  worldGroup.add(salForest.group);
  circleColliders.push(...salForest.colliders);
  landmarkSanjibaniAnchors.push(...salForest.sanjibaniAnchors);
  landmarkChestAnchors.push(...salForest.chestAnchors);

  // Landmark 2: পুরনো জমিদার বাড়ি (Abandoned Zamindar Bari — East / NE Sector)
  const zamindarCenterX = 98;
  const zamindarCenterZ = 22;
  const zamindarBari = buildZamindarBari(zamindarCenterX, zamindarCenterZ);
  worldGroup.add(zamindarBari.group);
  circleColliders.push(...zamindarBari.colliders);
  landmarkChestAnchors.push(...zamindarBari.chestAnchors);
  landmarkSanjibaniAnchors.push(...zamindarBari.sanjibaniAnchors);

  // Landmark 3: পুরনো ট্রাম ডিপো ও বাজার (Old Tram Depot & Bazaar — North Bank across Bridge)
  const tramDepotCenterX = 0;
  const tramDepotCenterZ = -124;
  const tramDepot = buildOldTramDepotAndBazaar(tramDepotCenterX, tramDepotCenterZ, () =>
    buildYellowTaxi(textures),
  );
  worldGroup.add(tramDepot.group);
  circleColliders.push(...tramDepot.colliders);
  landmarkChestAnchors.push(...tramDepot.chestAnchors);
  landmarkSanjibaniAnchors.push(...tramDepot.sanjibaniAnchors);

  // Landmark 4: নদীর বাঁধানো ঘাট ও নৌকা (Extended Riverbank Ghat, Moored Boats & Huts)
  const extendedGhat = buildExtendedRiverGhat(buildRiverBoat);
  worldGroup.add(extendedGhat.group);
  circleColliders.push(...extendedGhat.colliders);
  bobbingBoats.push(...extendedGhat.bobbingBoats);
  landmarkChestAnchors.push(...extendedGhat.chestAnchors);
  landmarkSanjibaniAnchors.push(...extendedGhat.sanjibaniAnchors);

  // Landmark 5: কলকাতা বড়বাজার (Kolkata Burrabazar — Dense Wholesale Shophouses, Alleys & Market Cover)
  const burrabazarCenterX = 118;
  const burrabazarCenterZ = 105;
  const burrabazar = buildBurrabazarZone(burrabazarCenterX, burrabazarCenterZ);
  worldGroup.add(burrabazar.group);
  circleColliders.push(...burrabazar.colliders);
  landmarkChestAnchors.push(...burrabazar.chestAnchors);
  landmarkSanjibaniAnchors.push(...burrabazar.sanjibaniAnchors);

  // Landmark 6: চোরবাজার (Kolkata Chor Bazaar — Cluttered Scrap Stalls, Salvage Sheds, Drums & Tire Cover)
  const chorBazaarCenterX = 112;
  const chorBazaarCenterZ = -108;
  const chorBazaar = buildChorBazaarZone(chorBazaarCenterX, chorBazaarCenterZ);
  worldGroup.add(chorBazaar.group);
  circleColliders.push(...chorBazaar.colliders);
  landmarkChestAnchors.push(...chorBazaar.chestAnchors);
  landmarkSanjibaniAnchors.push(...chorBazaar.sanjibaniAnchors);

  // 11b. GPU-Instanced Classic Kolkata Bicycles (সাইকেল) & Motorcycles/Bikes (বাইক) across markets, streets & village edges
  const bicyclePlacements: TwoWheelerPlacement[] = [
    ...burrabazar.bicycleAnchors.map((b) => ({ ...b, y: 0.045 })),
    ...chorBazaar.bicycleAnchors.map((b) => ({ ...b, y: 0.042 })),
    // Village Square curbs & house verandas (kept clear of lobby sightline, WBTC bus corridor & roads)
    { x: -18.2, y: 0, z: -3.5, rotY: 0.38, colorIdx: 0 },
    { x: -17.8, y: 0, z: 19.8, rotY: 1.25, colorIdx: 1 },
    { x: 17.6, y: 0, z: 18.5, rotY: -1.35, colorIdx: 2 },
    { x: -12.2, y: 0, z: 26.8, rotY: 0.15, colorIdx: 3 },
    { x: 14.2, y: 0, z: 26.4, rotY: -0.25, colorIdx: 4 },
    { x: 20.2, y: 0, z: -5.8, rotY: -0.58, colorIdx: 1 },
    // Old Tram Depot & Bazaar promenade
    { x: -15.5, y: 0.06, z: -113.0, rotY: 0.12, colorIdx: 2 },
    { x: 14.5, y: 0.06, z: -113.5, rotY: -0.18, colorIdx: 0 },
    { x: 38.5, y: 0.04, z: -126.0, rotY: 1.45, colorIdx: 4 },
    { x: -24.0, y: 0.04, z: -106.0, rotY: 0.55, colorIdx: 3 },
    // Zamindar Bari outer drive & regional settlements
    { x: 70.5, y: 0, z: 18.5, rotY: 1.52, colorIdx: 0 },
    { x: 70.5, y: 0, z: 26.2, rotY: 1.38, colorIdx: 2 },
    { x: -39.5, y: sampleLateriteHillHeight(-39.5, 128), z: 128, rotY: 0.42, colorIdx: 1 },
    { x: 190, y: sampleLateriteHillHeight(190, 124), z: 124, rotY: -0.75, colorIdx: 3 },
  ];

  const motorcyclePlacements: TwoWheelerPlacement[] = [
    ...burrabazar.motorcycleAnchors.map((m) => ({ ...m, y: 0.045 })),
    ...chorBazaar.motorcycleAnchors.map((m) => ({ ...m, y: 0.042 })),
    // Village outskirts street curbs (clear of WBTC bus route z=8.2 & Yellow Taxi)
    { x: -15.5, y: 0, z: 13.8, rotY: 0.25, colorIdx: 0 },
    { x: 15.5, y: 0, z: -1.8, rotY: -0.42, colorIdx: 2 },
    { x: 16.5, y: 0, z: 13.8, rotY: 2.85, colorIdx: 3 },
    // Old Tram Depot & Bazaar edges
    { x: -24.0, y: 0.04, z: -114.0, rotY: 0.35, colorIdx: 1 },
    { x: 32.0, y: 0.04, z: -104.5, rotY: -0.45, colorIdx: 4 },
    { x: 52.0, y: 0.04, z: -118.0, rotY: 1.48, colorIdx: 5 },
    // Zamindar Bari road & regional towns
    { x: 69.5, y: 0, z: 11.5, rotY: 0.2, colorIdx: 0 },
    { x: 78.0, y: 0, z: 54.0, rotY: -1.35, colorIdx: 2 },
    { x: -36.0, y: sampleLateriteHillHeight(-36, 130), z: 130, rotY: 0.5, colorIdx: 1 },
    { x: 188, y: sampleLateriteHillHeight(188, 114), z: 114, rotY: -0.82, colorIdx: 4 },
  ];

  const bicycleBatch = buildInstancedBicycles(bicyclePlacements, circleColliders);
  const motorcycleBatch = buildInstancedMotorcycles(motorcyclePlacements, circleColliders);
  worldGroup.add(bicycleBatch.group);
  worldGroup.add(motorcycleBatch.group);
  const twoWheelers: RideableTwoWheeler[] = [
    ...bicycleBatch.vehicles,
    ...motorcycleBatch.vehicles,
  ];

  // ============================================================================
  // 12. EXPANDED COUNTRYSIDE GROVES, FOLIAGE, ROCKS, COVER WALLS & OUTER OUTPOSTS
  //     (Batched via InstancedMesh for rock-solid mobile FPS across 1520x1520 map!)
  // ============================================================================
  const isBlockedForCountryside = (x: number, z: number): boolean => {
    // Keep Hooghly River, embankments, Village Square, Zamindar Bari, Tram Depot, Burrabazar, Chor Bazaar & roads open
    if (z > -82 && z < -8) return true;
    if (x > -52 && x < 58 && z >= -20 && z < 52) return true; // Village Square
    if (x > 60 && x < 142 && z > -16 && z < 64) return true; // Zamindar Bari
    if (x > 70 && x < 168 && z > 64 && z < 148) return true; // Kolkata Burrabazar (বড়বাজার)
    if (x > 74 && x < 152 && z < -72 && z > -146) return true; // Chor Bazaar (চোরবাজার)
    if (x > -94 && x < 94 && z < -68 && z > -206) return true; // Old Tram Depot & Bazaar
    if (x > -135 && x < 82 && z > 0 && z < 14) return true; // Main East-West heritage road
    if (x > 68 && x < 82 && z > 12 && z < 116) return true; // Zamindar -> Burrabazar road corridor
    if (isNearAnyBuilding(x, z, 4.5)) return true; // Keep trees, rocks & cover walls out of houses and courtyards
    return false;
  };

  // Deterministic pseudo-random helper for repeatable organic Bengal landscape scatter
  let scatterSeed = 42197;
  const nextRand = () => {
    scatterSeed = (scatterSeed * 1664525 + 1013904223) >>> 0;
    return scatterSeed / 4294967296;
  };

  // 12a. Instanced Bengal Countryside Groves & Perimeter Forest (540 trees in just 2 draw calls!)
  const maxCountrysideTrees = 540;
  const oTrunkGeo = new THREE.CylinderGeometry(0.36, 0.58, 11.4, 6);
  oTrunkGeo.translate(0, 5.7, 0);
  const oCrownGeo = new THREE.DodecahedronGeometry(3.6, 1);
  const oTrunkMat = new THREE.MeshStandardMaterial({ color: 0x5d4634, roughness: 0.94 });
  const oCrownMat = new THREE.MeshStandardMaterial({ color: 0x39702c, roughness: 0.86 });
  const outerTrunks = new THREE.InstancedMesh(oTrunkGeo, oTrunkMat, maxCountrysideTrees);
  const outerCrowns = new THREE.InstancedMesh(oCrownGeo, oCrownMat, maxCountrysideTrees);
  const crownPalette = [0x2e6324, 0x3d752e, 0x4b7f32, 0x295721, 0x548536];

  let otPlaced = 0;
  // Clustered natural groves in playable countryside (r = 95..725)
  const groveCenters: Array<[number, number, number]> = [
    [-240, 150, 58],
    [-380, 95, 72],
    [-510, 220, 82],
    [-310, 340, 68],
    [-160, 290, 64],
    [-460, 480, 78],
    [-95, 495, 74],
    [70, 265, 62],
    [185, 165, 58],
    [310, 85, 68],
    [455, 195, 76],
    [290, 345, 70],
    [540, 395, 82],
    [135, 515, 72],
    [390, 560, 76],
    [-255, -245, 68],
    [-435, -185, 76],
    [-515, -395, 82],
    [-215, -455, 74],
    [215, -195, 66],
    [395, -235, 74],
    [285, -430, 72],
    [525, -415, 80],
    [35, -345, 68],
    [-55, -565, 76],
  ];

  for (const [gx, gz, gRadius] of groveCenters) {
    const treesInGrove = 12;
    for (let j = 0; j < treesInGrove && otPlaced < 320; j++) {
      const ang = nextRand() * Math.PI * 2;
      const dist = Math.sqrt(nextRand()) * gRadius;
      const tx = gx + Math.cos(ang) * dist;
      const tz = gz + Math.sin(ang) * dist;
      if (Math.abs(tx) > 730 || Math.abs(tz) > 730) continue;
      if (isBlockedForCountryside(tx, tz)) continue;
      const ty = sampleLateriteHillHeight(tx, tz);
      const sc = 0.82 + nextRand() * 0.42;

      dummy.position.set(tx, ty - 0.25, tz);
      dummy.rotation.set(0, nextRand() * Math.PI * 2, 0);
      dummy.scale.set(sc, sc * (0.9 + nextRand() * 0.25), sc);
      dummy.updateMatrix();
      outerTrunks.setMatrixAt(otPlaced, dummy.matrix);

      dummy.position.set(tx, ty + 10.2 * sc, tz);
      dummy.scale.set(sc * (1.05 + nextRand() * 0.22), sc * (0.82 + nextRand() * 0.2), sc * (1.05 + nextRand() * 0.22));
      dummy.updateMatrix();
      outerCrowns.setMatrixAt(otPlaced, dummy.matrix);
      color.setHex(crownPalette[otPlaced % crownPalette.length]);
      outerCrowns.setColorAt(otPlaced, color);

      // Register real trunk cover colliders on every 3rd grove tree to keep collision loop super lean on mobile
      if (j % 3 === 0) {
        circleColliders.push({ x: tx, z: tz, radius: 0.72 * sc, height: 10 * sc, baseY: ty, kind: 'tree' });
      }
      otPlaced++;
    }
  }

  // Lush outer perimeter woodland rim (r = 745..865) framing the horizon naturally
  for (let i = 0; i < 300 && otPlaced < maxCountrysideTrees; i++) {
    const a = (i / 240) * Math.PI * 2 + (i % 7) * 0.11;
    const rad = 750 + nextRand() * 115;
    const tx = Math.cos(a) * rad;
    const tz = Math.sin(a) * rad;
    if (tz > -84 && tz < -10) continue;
    const ty = sampleLateriteHillHeight(tx, tz);
    const sc = 0.95 + nextRand() * 0.48;
    dummy.position.set(tx, ty - 0.3, tz);
    dummy.rotation.set(0, a, 0);
    dummy.scale.set(sc, sc, sc);
    dummy.updateMatrix();
    outerTrunks.setMatrixAt(otPlaced, dummy.matrix);

    dummy.position.set(tx, ty + 10.6 * sc, tz);
    dummy.scale.set(sc * 1.18, sc * 0.92, sc * 1.18);
    dummy.updateMatrix();
    outerCrowns.setMatrixAt(otPlaced, dummy.matrix);
    color.setHex(crownPalette[otPlaced % crownPalette.length]);
    outerCrowns.setColorAt(otPlaced, color);
    otPlaced++;
  }
  outerTrunks.count = otPlaced;
  outerCrowns.count = otPlaced;
  outerTrunks.instanceMatrix.needsUpdate = true;
  outerCrowns.instanceMatrix.needsUpdate = true;
  if (outerCrowns.instanceColor) outerCrowns.instanceColor.needsUpdate = true;
  outerTrunks.computeBoundingSphere();
  outerCrowns.computeBoundingSphere();
  worldGroup.add(outerTrunks, outerCrowns);

  // 12b. Wild Countryside Scrub & Fern Bushes (220 instances, 1 draw call)
  const wildBushCount = 220;
  const wildBushes = new THREE.InstancedMesh(bushGeo, bushMat, wildBushCount);
  let wbPlaced = 0;
  for (let i = 0; i < wildBushCount * 2 && wbPlaced < wildBushCount; i++) {
    const bx = (nextRand() - 0.5) * 1420;
    const bz = (nextRand() - 0.5) * 1420;
    if (isBlockedForCountryside(bx, bz)) continue;
    const s = 0.85 + nextRand() * 0.85;
    const by = sampleLateriteHillHeight(bx, bz);
    dummy.position.set(bx, by + s * 0.48, bz);
    dummy.rotation.set(0, nextRand() * Math.PI * 2, 0);
    dummy.scale.set(s * 1.35, s * 0.82, s * 1.25);
    dummy.updateMatrix();
    wildBushes.setMatrixAt(wbPlaced, dummy.matrix);
    color.setHex(bushPalette[wbPlaced % bushPalette.length]);
    wildBushes.setColorAt(wbPlaced, color);
    wbPlaced++;
  }
  wildBushes.count = wbPlaced;
  wildBushes.instanceMatrix.needsUpdate = true;
  if (wildBushes.instanceColor) wildBushes.instanceColor.needsUpdate = true;
  wildBushes.computeBoundingSphere();
  worldGroup.add(wildBushes);

  // 12c. Tactical Laterite Boulders & Rock Outcrops (92 instances with solid cover colliders, 1 draw call)
  const rockCount = 92;
  const rockGeo = new THREE.DodecahedronGeometry(1.45, 0);
  const rockMat = new THREE.MeshStandardMaterial({
    color: 0x8f6b54,
    roughness: 0.92,
    metalness: 0.04,
  });
  const rocks = new THREE.InstancedMesh(rockGeo, rockMat, rockCount);
  const rockPalette = [0x8b6750, 0x7b5a46, 0x9b543a, 0x756c63];
  let rPlaced = 0;
  for (let i = 0; i < rockCount * 3 && rPlaced < rockCount; i++) {
    const rx = (nextRand() - 0.5) * 1360;
    const rz = (nextRand() - 0.5) * 1360;
    if (isBlockedForCountryside(rx, rz)) continue;
    const sc = 0.9 + nextRand() * 0.95;
    const ry = sampleLateriteHillHeight(rx, rz);
    dummy.position.set(rx, ry + sc * 0.72, rz);
    dummy.rotation.set(nextRand() * 0.5, nextRand() * Math.PI * 2, nextRand() * 0.5);
    dummy.scale.set(sc * 1.35, sc * 0.95, sc * 1.15);
    dummy.updateMatrix();
    rocks.setMatrixAt(rPlaced, dummy.matrix);
    color.setHex(rockPalette[rPlaced % rockPalette.length]);
    rocks.setColorAt(rPlaced, color);
    circleColliders.push({
      x: rx,
      z: rz,
      radius: 1.55 * sc,
      height: 1.9 * sc,
      baseY: ry,
      kind: 'boulder',
    });
    rPlaced++;
  }
  rocks.count = rPlaced;
  rocks.instanceMatrix.needsUpdate = true;
  if (rocks.instanceColor) rocks.instanceColor.needsUpdate = true;
  rocks.computeBoundingSphere();
  worldGroup.add(rocks);

  // 12d. Weathered Bengal Red-Brick Tactical Cover Walls scattered across clearings & trails (40 instances, 1 draw call)
  const wallCoverCount = 40;
  const coverWallGeo = new THREE.BoxGeometry(4.4, 1.45, 0.75);
  const coverWallMat = new THREE.MeshStandardMaterial({
    color: 0x9c533c,
    roughness: 0.9,
    metalness: 0.02,
  });
  const coverWalls = new THREE.InstancedMesh(coverWallGeo, coverWallMat, wallCoverCount);
  let wPlaced = 0;
  for (let i = 0; i < wallCoverCount * 3 && wPlaced < wallCoverCount; i++) {
    const wx = (nextRand() - 0.5) * 1240;
    const wz = (nextRand() - 0.5) * 1240;
    if (isBlockedForCountryside(wx, wz)) continue;
    const wy = sampleLateriteHillHeight(wx, wz);
    const rot = nextRand() * Math.PI;
    dummy.position.set(wx, wy + 0.7, wz);
    dummy.rotation.set(0, rot, 0);
    dummy.scale.set(0.9 + nextRand() * 0.35, 0.9 + nextRand() * 0.25, 1);
    dummy.updateMatrix();
    coverWalls.setMatrixAt(wPlaced, dummy.matrix);
    circleColliders.push({ x: wx, z: wz, radius: 1.95, height: 1.5, baseY: wy, kind: 'prop' });
    wPlaced++;
  }
  coverWalls.count = wPlaced;
  coverWalls.instanceMatrix.needsUpdate = true;
  coverWalls.computeBoundingSphere();
  worldGroup.add(coverWalls);

  // Unified Analytical Ground Elevation (Bridge Deck/Ramps + Zamindar Bari Stairs/Terrace + Laterite Hills)
  const getGroundHeight = (x: number, z: number, currentY?: number): number => {
    const bridgeY = sampleBridgeCrossingHeight(x, z);
    if (bridgeY !== null) return bridgeY;

    const zamindarY = zamindarBari.getTerraceHeight(x, z, currentY);
    if (zamindarY > 0) return zamindarY;

    return sampleLateriteHillHeight(x, z);
  };

  // Water collision test: blocks wading into deep Hooghly River except along bridge deck & crossing ramps
  const isWaterBlocked = (x: number, z: number): boolean => {
    if (z <= -70.5 || z >= -20.5) return false;
    return sampleBridgeCrossingHeight(x, z) === null;
  };

  // Dynamic Bengali Area Name for Top HUD Location Badge across the expanded 1520x1520 Bengal world
  const getLocationName = (x: number, z: number, currentY?: number): string => {
    const onBridge = sampleBridgeCrossingHeight(x, z) !== null;
    if (onBridge && (z < -17 || (currentY !== undefined && currentY > 1.2))) {
      return 'হাওড়া সেতু';
    }
    if (x >= 74 && x <= 164 && z >= 68 && z <= 144) {
      return 'বড়বাজার';
    }
    if (x >= 76 && x <= 150 && z <= -76 && z >= -142) {
      return 'চোরবাজার';
    }
    if (z < -70) {
      if (z < -200 && x >= 0) return 'উত্তর বাগানবাড়ি';
      if (z < -200 && x < 0) return 'পশ্চিম বনাঞ্চল';
      if (x < -86) return 'শালবন';
      return 'ট্রাম ডিপো';
    }
    if (z >= -23 && z <= -9.5 && Math.abs(x) <= 185) {
      return 'নদীর ঘাট';
    }
    if (z > 185) {
      if (x < -215) return 'রাঢ় লাল টিলা';
      if (x > 215) return 'পূর্ব প্রান্তর';
      return 'সুন্দরবন প্রান্ত';
    }
    if (x > 64 && x < 144 && z > -14 && z < 64) {
      return 'জমিদার বাড়ি';
    }
    if (x > 165) {
      return 'পূর্ব প্রান্তর';
    }
    if (x < -215) {
      return 'রাঢ় লাল টিলা';
    }
    if (x < -46) {
      return 'শালবন';
    }
    return 'বাংলার গ্রাম';
  };

  // Enemy spawn points broadly distributed across Village outskirts, 4 landmarks & expanded outer Bengal biomes
  const enemySpawnPoints = [
    // Village Perimeter & Riverbank Flanks (positioned cleanly outside village-ring building footprints)
    new THREE.Vector3(-42, 0, -11),
    new THREE.Vector3(44, 0, -11),
    new THREE.Vector3(-56, 0, 31),
    new THREE.Vector3(56, 0, 32),
    new THREE.Vector3(2, 0, 62),
    new THREE.Vector3(29, 0, 66),
    new THREE.Vector3(-68, 0, -13),
    new THREE.Vector3(72, 0, -13),
    // Sal Forest & Red-Soil Hills
    new THREE.Vector3(-92, sampleLateriteHillHeight(-92, 34), 34),
    new THREE.Vector3(-148, sampleLateriteHillHeight(-148, 72), 72),
    new THREE.Vector3(-210, sampleLateriteHillHeight(-210, 128), 128),
    new THREE.Vector3(-315, sampleLateriteHillHeight(-315, 92), 92),
    new THREE.Vector3(-385, sampleLateriteHillHeight(-385, 225), 225),
    new THREE.Vector3(-255, sampleLateriteHillHeight(-255, 290), 290),
    // Abandoned Zamindar Bari & East Meadows
    new THREE.Vector3(74, 0, 22),
    new THREE.Vector3(118, 0, 24),
    new THREE.Vector3(185, sampleLateriteHillHeight(185, 76), 76),
    new THREE.Vector3(285, sampleLateriteHillHeight(285, 42), 42),
    new THREE.Vector3(355, sampleLateriteHillHeight(355, 198), 198),
    new THREE.Vector3(250, sampleLateriteHillHeight(250, 265), 265),
    new THREE.Vector3(430, sampleLateriteHillHeight(430, 310), 310),
    // Far South Sundarban Fringe
    new THREE.Vector3(-95, sampleLateriteHillHeight(-95, 195), 195),
    new THREE.Vector3(42, sampleLateriteHillHeight(42, 225), 225),
    new THREE.Vector3(-145, sampleLateriteHillHeight(-145, 345), 345),
    new THREE.Vector3(125, sampleLateriteHillHeight(125, 365), 365),
    new THREE.Vector3(-20, sampleLateriteHillHeight(-20, 440), 440),
    // North Bank: Old Tram Depot, West Forestland & North Garden Estates
    new THREE.Vector3(-24, 0, -104),
    new THREE.Vector3(26, 0, -112),
    new THREE.Vector3(-128, sampleLateriteHillHeight(-128, -142), -142),
    new THREE.Vector3(-265, sampleLateriteHillHeight(-265, -230), -230),
    new THREE.Vector3(-375, sampleLateriteHillHeight(-375, -310), -310),
    new THREE.Vector3(175, sampleLateriteHillHeight(175, -165), -165),
    new THREE.Vector3(295, sampleLateriteHillHeight(295, -245), -245),
    new THREE.Vector3(65, sampleLateriteHillHeight(65, -335), -335),
    // Kolkata Burrabazar (বড়বাজার) & Chor Bazaar (চোরবাজার) tactical urban combat spawns
    ...burrabazar.enemySpawns,
    ...chorBazaar.enemySpawns,
  ];

  // Spread-out Wild Animal Habitats across the expanded map (95m–420m from spawn so players must hunt & track!)
  const wildAnimalHabitats: WildAnimalHabitatAnchor[] = [
    // Sundarban Tiger habitats (Sundarban Fringe, deep Sal Forest & dense groves)
    { x: -125, z: 235, areaBn: 'সুন্দরবন প্রান্ত', speciesHint: 'sundarban_tiger' },
    { x: 92, z: 275, areaBn: 'সুন্দরবন প্রান্ত', speciesHint: 'sundarban_tiger' },
    { x: -45, z: 385, areaBn: 'সুন্দরবন প্রান্ত', speciesHint: 'sundarban_tiger' },
    { x: -245, z: 165, areaBn: 'রাঢ় লাল টিলা', speciesHint: 'sundarban_tiger' },
    { x: 255, z: 335, areaBn: 'পূর্ব প্রান্তর', speciesHint: 'sundarban_tiger' },
    // Bengal Leopard habitats (Sal Forest hills, Rarh red-soil ridges & rocky groves)
    { x: -165, z: 88, areaBn: 'শালবন', speciesHint: 'bengal_leopard' },
    { x: -335, z: 110, areaBn: 'রাঢ় লাল টিলা', speciesHint: 'bengal_leopard' },
    { x: -365, z: 285, areaBn: 'রাঢ় লাল টিলা', speciesHint: 'bengal_leopard' },
    { x: 285, z: 155, areaBn: 'পূর্ব প্রান্তর', speciesHint: 'bengal_leopard' },
    { x: -225, z: -210, areaBn: 'পশ্চিম বনাঞ্চল', speciesHint: 'bengal_leopard' },
    // Bengal Guard Hound habitats (Zamindar outskirts, rural meadows, riverbank wilderness & north gardens)
    { x: 175, z: 72, areaBn: 'পূর্ব প্রান্তর', speciesHint: 'village_hound' },
    { x: 235, z: 205, areaBn: 'পূর্ব প্রান্তর', speciesHint: 'village_hound' },
    { x: 355, z: 75, areaBn: 'পূর্ব প্রান্তর', speciesHint: 'village_hound' },
    { x: -145, z: 185, areaBn: 'শালবন', speciesHint: 'village_hound' },
    { x: 145, z: -175, areaBn: 'উত্তর বাগানবাড়ি', speciesHint: 'village_hound' },
    { x: 248, z: -228, areaBn: 'উত্তর বাগানবাড়ি', speciesHint: 'village_hound' },
  ];

  const pickupAnchors = [
    new THREE.Vector3(3.2, 0, -6.5),
    new THREE.Vector3(-9.0, 0, 9.5),
    new THREE.Vector3(10.0, 0, 9.0),
    new THREE.Vector3(0.0, 0, 17.5),
    new THREE.Vector3(-78, sampleLateriteHillHeight(-78, 34), 34),
    new THREE.Vector3(98, 0.18, 28),
    new THREE.Vector3(8, 0, -112),
    new THREE.Vector3(-210, sampleLateriteHillHeight(-210, 155), 155),
    new THREE.Vector3(245, sampleLateriteHillHeight(245, 130), 130),
    new THREE.Vector3(-45, sampleLateriteHillHeight(-45, 255), 255),
    new THREE.Vector3(195, sampleLateriteHillHeight(195, -185), -185),
  ];

  return {
    worldGroup,
    boxColliders,
    circleColliders,
    swayingPalms,
    boatGroup,
    bobbingBoats,
    waterUniforms,
    waterBumpTexture: textures.waterBump,
    enemySpawnPoints,
    wildAnimalHabitats,
    pickupAnchors,
    landmarkChestAnchors,
    landmarkSanjibaniAnchors,
    twoWheelers,
    playableBounds: { minX: -760, maxX: 760, minZ: -760, maxZ: 760 },
    getGroundHeight,
    isWaterBlocked,
    getLocationName,
  };
}
