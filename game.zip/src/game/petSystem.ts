import * as THREE from 'three';
import {
  PetUpgradePlaceholder,
  TamedPetRecord,
  WildAnimalSpecies,
} from './types';

const STORAGE_KEY_PLAYER_ID = 'banglar_joddha_player_id_v1';
const STORAGE_KEY_PET_REGISTRY = 'banglar_joddha_pet_registry_v1';

// Tight golden capture ring radius — demands close-range nerve & positioning
export const TAME_GOLDEN_RING_RADIUS = 2.95;

export interface WildAnimalSpeciesMeta {
  species: WildAnimalSpecies;
  nameBn: string;
  titleBn: string;
  assistRoleBn: string;
  maxHp: number;
  subdueRatio: number; // HP fraction <= this (and > 0) enters subdued state
  moveSpeed: number;
  lungeSpeed: number;
  attackDamage: number;
  assistDamage: number;
  assistCooldown: number;
  bodyScale: number;
  coatHex: number;
  bellyHex: number;
  markingHex: number;
  eyeHex: number;
}

export const WILD_ANIMAL_CATALOG: Record<WildAnimalSpecies, WildAnimalSpeciesMeta> = {
  sundarban_tiger: {
    species: 'sundarban_tiger',
    nameBn: 'সুন্দরবনের বাঘ',
    titleBn: 'রয়্যাল বেঙ্গল সঙ্গী',
    assistRoleBn: 'শত্রুকে ঝাঁপিয়ে আঘাত ও সতর্কতা',
    maxHp: 280,
    subdueRatio: 0.22,
    moveSpeed: 6.8,
    lungeSpeed: 15.6,
    attackDamage: 26,
    assistDamage: 22,
    assistCooldown: 5.6,
    bodyScale: 1.12,
    coatHex: 0xde6f1c,
    bellyHex: 0xf7ebd4,
    markingHex: 0x161210,
    eyeHex: 0xffb830,
  },
  bengal_leopard: {
    species: 'bengal_leopard',
    nameBn: 'বাংলার চিতাবাঘ',
    titleBn: 'ক্ষিপ্র চিতা সঙ্গী',
    assistRoleBn: 'দ্রুত পাশ থেকে শত্রু বিচলিত করা',
    maxHp: 235,
    subdueRatio: 0.22,
    moveSpeed: 7.9,
    lungeSpeed: 16.8,
    attackDamage: 22,
    assistDamage: 18,
    assistCooldown: 4.8,
    bodyScale: 0.98,
    coatHex: 0xdfa63c,
    bellyHex: 0xf5ebd2,
    markingHex: 0x241910,
    eyeHex: 0xffe04a,
  },
  village_hound: {
    species: 'village_hound',
    nameBn: 'বাংলার প্রহরী কুকুর',
    titleBn: 'বিশ্বস্ত গ্রাম্য সঙ্গী',
    assistRoleBn: 'শত্রু শনাক্তকরণ ও কাছের আক্রমণ',
    maxHp: 210,
    subdueRatio: 0.22,
    moveSpeed: 7.2,
    lungeSpeed: 15.0,
    attackDamage: 20,
    assistDamage: 16,
    assistCooldown: 4.4,
    bodyScale: 0.92,
    coatHex: 0x9b5d31,
    bellyHex: 0xe6cda6,
    markingHex: 0x26170e,
    eyeHex: 0xffaa38,
  },
};

export const WILD_ANIMAL_SPECIES_LIST: WildAnimalSpecies[] = [
  'sundarban_tiger',
  'bengal_leopard',
  'village_hound',
];

function generatePlayerId(): string {
  const digits = Math.floor(10000 + Math.random() * 90000);
  return `BJ-${digits}`;
}

export function getOrCreatePlayerId(): string {
  try {
    const existing = localStorage.getItem(STORAGE_KEY_PLAYER_ID);
    if (existing && /^BJ-\d{5}$/.test(existing.trim())) {
      return existing.trim();
    }
    const created = generatePlayerId();
    localStorage.setItem(STORAGE_KEY_PLAYER_ID, created);
    return created;
  } catch {
    return 'BJ-10001';
  }
}

type PetRegistryMap = Record<string, TamedPetRecord>;

function readPetRegistry(): PetRegistryMap {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_PET_REGISTRY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as unknown;
    if (!parsed || typeof parsed !== 'object') return {};
    return parsed as PetRegistryMap;
  } catch {
    return {};
  }
}

function writePetRegistry(registry: PetRegistryMap): void {
  try {
    localStorage.setItem(STORAGE_KEY_PET_REGISTRY, JSON.stringify(registry));
  } catch {
    // Ignore storage quota/privacy mode errors
  }
}

export function loadPermanentPetForId(playerId: string): TamedPetRecord | null {
  const registry = readPetRegistry();
  const record = registry[playerId];
  if (!record || !WILD_ANIMAL_CATALOG[record.species]) {
    return null;
  }
  return record;
}

export function createInitialUpgradePlaceholder(): PetUpgradePlaceholder {
  return {
    level: 1,
    maxLevel: 5,
    xp: 0,
    nextLevelResourceName: 'বনজ ভেষজ ও স্বর্ণমুদ্রা',
    nextLevelResourceCost: 250,
    unlockedPerks: ['স্থায়ী সঙ্গী প্রহরা (স্তর ১)'],
    upgradeLockedReason: 'রিসোর্স-ভিত্তিক পোষা প্রাণী আপগ্রেড শীঘ্রই আসছে',
  };
}

/**
 * Persists a single lifetime pet for a given playerId.
 * Strictly refuses to overwrite if the playerId already owns a permanent pet.
 */
export function savePermanentPetForId(
  playerId: string,
  species: WildAnimalSpecies,
): TamedPetRecord | null {
  const registry = readPetRegistry();
  if (registry[playerId]) {
    // Lifetime one-pet lock: never replace or allow a second pet on the same ID
    return null;
  }
  const meta = WILD_ANIMAL_CATALOG[species];
  const record: TamedPetRecord = {
    playerId,
    species,
    nameBn: meta.nameBn,
    titleBn: meta.titleBn,
    tamedAtIso: new Date().toISOString(),
    bondStrength: 100,
    assistRoleBn: meta.assistRoleBn,
    upgrades: createInitialUpgradePlaceholder(),
  };
  registry[playerId] = record;
  writePetRegistry(registry);
  return record;
}

// --- Sculpted Organic Multi-Part 3D Quadruped Animal / Pet Rig (Zero BoxGeometry Cubes) ---

export interface AnimalRig {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  neckGroup: THREE.Group;
  headGroup: THREE.Group;
  frontLeftLeg: THREE.Group;
  frontRightLeg: THREE.Group;
  backLeftLeg: THREE.Group;
  backRightLeg: THREE.Group;
  tailPivot: THREE.Group;
  collarGroup: THREE.Group;
  eyeMaterials: THREE.MeshStandardMaterial[];
  flashMaterials: THREE.MeshStandardMaterial[];
  baseEmissives: THREE.Color[];
  hpBarBg: THREE.Mesh;
  hpBarFill: THREE.Mesh;
  subduedRing: THREE.Mesh;
  tameRing: THREE.Mesh;
}

export function buildAnimalRig(species: WildAnimalSpecies, isTamed = false): AnimalRig {
  const meta = WILD_ANIMAL_CATALOG[species];
  const s = meta.bodyScale;
  const isTiger = species === 'sundarban_tiger';
  const isLeopard = species === 'bengal_leopard';
  const isHound = species === 'village_hound';

  // Species-specific organic silhouette ratios
  const widthRatio = isTiger ? 1.06 : isLeopard ? 0.86 : 0.84;
  const lengthRatio = isTiger ? 1.04 : isLeopard ? 1.12 : 0.96;
  const legLengthRatio = isTiger ? 0.98 : isLeopard ? 1.05 : 1.02;

  const root = new THREE.Group();
  const bodyGroup = new THREE.Group();
  bodyGroup.position.set(0, 0.65 * s * legLengthRatio, 0);
  root.add(bodyGroup);

  const flashMaterials: THREE.MeshStandardMaterial[] = [];
  const baseEmissives: THREE.Color[] = [];
  const registerFlashMat = (mat: THREE.MeshStandardMaterial) => {
    flashMaterials.push(mat);
    baseEmissives.push(mat.emissive.clone());
    return mat;
  };

  // PBR Materials with distinct roughness variation for rich fur/nose/eye/collar contrast
  const coatMat = registerFlashMat(
    new THREE.MeshStandardMaterial({
      color: meta.coatHex,
      roughness: 0.82,
      metalness: 0.02,
    }),
  );
  const bellyMat = registerFlashMat(
    new THREE.MeshStandardMaterial({
      color: meta.bellyHex,
      roughness: 0.88,
      metalness: 0.01,
    }),
  );
  const markingMat = registerFlashMat(
    new THREE.MeshStandardMaterial({
      color: meta.markingHex,
      roughness: 0.86,
      metalness: 0.03,
    }),
  );
  const innerEarMat = new THREE.MeshStandardMaterial({
    color: isHound ? 0xc4826e : 0xdfb89c,
    roughness: 0.78,
    metalness: 0.02,
  });
  const noseMat = new THREE.MeshStandardMaterial({
    color: isTiger ? 0x2c1b1a : 0x151111,
    roughness: 0.28,
    metalness: 0.08,
  });
  const eyeMat = new THREE.MeshStandardMaterial({
    color: isTamed ? 0x52f2c8 : meta.eyeHex,
    emissive: isTamed ? 0x1aa88a : meta.eyeHex,
    emissiveIntensity: isTamed ? 0.52 : 0.72,
    roughness: 0.14,
    metalness: 0.1,
  });
  const pupilMat = new THREE.MeshStandardMaterial({
    color: 0x0b0908,
    roughness: 0.1,
    metalness: 0.05,
  });
  const clawMat = new THREE.MeshStandardMaterial({
    color: 0xede2cf,
    roughness: 0.42,
    metalness: 0.05,
  });

  // =========================================================================
  // 1. SCULPTED ORGANIC TORSO (Deep Ribcage + Tapered Waist + Muscular Rump)
  // =========================================================================
  const torsoGroup = new THREE.Group();
  torsoGroup.scale.set(widthRatio, 1, lengthRatio);
  bodyGroup.add(torsoGroup);

  // Broad muscular front ribcage (horizontal rounded capsule)
  const ribcage = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.225 * s, 0.34 * s, 7, 14),
    coatMat,
  );
  ribcage.rotation.x = Math.PI / 2;
  ribcage.scale.set(1.04, 1.0, 1.08);
  ribcage.position.set(0, 0.04 * s, 0.2 * s);
  ribcage.castShadow = true;
  ribcage.receiveShadow = true;
  torsoGroup.add(ribcage);

  // Sculpted shoulder blades / withers hump
  const withers = new THREE.Mesh(new THREE.SphereGeometry(0.195 * s, 12, 10), coatMat);
  withers.scale.set(1.05, 0.92, 1.15);
  withers.position.set(0, 0.12 * s, 0.31 * s);
  withers.castShadow = true;
  torsoGroup.add(withers);

  // Tapered athletic mid-torso / waist (tucked up higher on hound & leopard)
  const waistRadiusBack = isHound ? 0.145 * s : isLeopard ? 0.16 * s : 0.178 * s;
  const waist = new THREE.Mesh(
    new THREE.CylinderGeometry(waistRadiusBack, 0.215 * s, 0.42 * s, 12),
    coatMat,
  );
  waist.rotation.x = Math.PI / 2;
  waist.position.set(0, (isHound ? 0.045 : 0.025) * s, -0.05 * s);
  waist.castShadow = true;
  waist.receiveShadow = true;
  torsoGroup.add(waist);

  // Muscular rounded hindquarters / pelvis
  const pelvis = new THREE.Mesh(new THREE.SphereGeometry(0.215 * s, 12, 10), coatMat);
  pelvis.scale.set(0.98, 0.96, 1.24);
  pelvis.position.set(0, 0.03 * s, -0.32 * s);
  pelvis.castShadow = true;
  pelvis.receiveShadow = true;
  torsoGroup.add(pelvis);

  // Soft pale chest & underbelly contour
  const chestFront = new THREE.Mesh(new THREE.SphereGeometry(0.185 * s, 10, 9), bellyMat);
  chestFront.scale.set(0.9, 1.02, 0.95);
  chestFront.position.set(0, -0.04 * s, 0.38 * s);
  torsoGroup.add(chestFront);

  const bellyContour = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.135 * s, 0.56 * s, 6, 10),
    bellyMat,
  );
  bellyContour.rotation.x = Math.PI / 2;
  bellyContour.position.set(0, -0.095 * s, 0.02 * s);
  torsoGroup.add(bellyContour);

  // =========================================================================
  // 2. SPECIES-DISTINCT COAT MARKINGS (Curved Stripes / Rosettes / Saddle)
  // =========================================================================
  if (isTiger) {
    // Curved charcoal tiger stripes hugging the cylindrical torso & hindquarters
    const stripeSpecs: Array<{ z: number; rx: number; ry: number; tube: number; y: number }> = [
      { z: 0.34, rx: 0.232, ry: 0.228, tube: 0.024, y: 0.055 },
      { z: 0.20, rx: 0.236, ry: 0.235, tube: 0.027, y: 0.045 },
      { z: 0.06, rx: 0.218, ry: 0.22, tube: 0.025, y: 0.035 },
      { z: -0.08, rx: 0.195, ry: 0.198, tube: 0.024, y: 0.03 },
      { z: -0.22, rx: 0.206, ry: 0.206, tube: 0.025, y: 0.032 },
      { z: -0.36, rx: 0.198, ry: 0.192, tube: 0.023, y: 0.03 },
    ];
    for (const sp of stripeSpecs) {
      const arc = new THREE.Mesh(
        new THREE.TorusGeometry(sp.rx * s, sp.tube * s, 6, 16, Math.PI * 1.24),
        markingMat,
      );
      arc.position.set(0, sp.y * s, sp.z * s);
      // Orient open arc over the dorsal spine & down both flanks
      arc.rotation.z = -Math.PI * 0.12;
      arc.scale.set(1, sp.ry / sp.rx, 0.72);
      torsoGroup.add(arc);
    }
  } else if (isLeopard) {
    // Organic rosette clusters across shoulders, flanks, spine, and hindquarters
    const rosetteGeo = new THREE.TorusGeometry(0.036 * s, 0.013 * s, 5, 8);
    const dotGeo = new THREE.SphereGeometry(0.022 * s, 6, 5);
    const rosetteSpecs: Array<[number, number, number, number, number]> = [
      [-0.21, 0.11, 0.30, 0, Math.PI / 2],
      [0.21, 0.09, 0.27, 0, -Math.PI / 2],
      [-0.22, 0.02, 0.16, 0, Math.PI / 2],
      [0.22, 0.04, 0.12, 0, -Math.PI / 2],
      [-0.19, 0.12, -0.02, 0, Math.PI / 2],
      [0.19, 0.11, -0.06, 0, -Math.PI / 2],
      [-0.19, 0.03, -0.18, 0, Math.PI / 2],
      [0.19, 0.05, -0.20, 0, -Math.PI / 2],
      [-0.20, 0.10, -0.34, 0, Math.PI / 2],
      [0.20, 0.08, -0.36, 0, -Math.PI / 2],
      [0, 0.24, 0.22, Math.PI / 2, 0],
      [-0.06, 0.21, 0.02, Math.PI / 2, 0],
      [0.06, 0.21, -0.14, Math.PI / 2, 0],
      [0, 0.22, -0.32, Math.PI / 2, 0],
    ];
    for (const [rx, ry, rz, rotX, rotY] of rosetteSpecs) {
      const ring = new THREE.Mesh(rosetteGeo, markingMat);
      ring.position.set(rx * s, ry * s, rz * s);
      ring.rotation.set(rotX, rotY, 0);
      torsoGroup.add(ring);
    }
    const accentDots: Array<[number, number, number]> = [
      [-0.21, 0.15, 0.18],
      [0.21, 0.14, 0.04],
      [-0.18, 0.14, -0.25],
      [0.18, 0.14, -0.28],
    ];
    for (const [dx, dy, dz] of accentDots) {
      const dot = new THREE.Mesh(dotGeo, markingMat);
      dot.scale.set(0.6, 1, 1);
      dot.position.set(dx * s, dy * s, dz * s);
      torsoGroup.add(dot);
    }
  } else {
    // Guard Hound dark back saddle + warm neck ruff
    const saddle = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.18 * s, 0.42 * s, 6, 12),
      markingMat,
    );
    saddle.rotation.x = Math.PI / 2;
    saddle.scale.set(1.02, 1, 0.62);
    saddle.position.set(0, 0.14 * s, -0.02 * s);
    torsoGroup.add(saddle);
  }

  // =========================================================================
  // 3. SCULPTED NECK, WARRIOR GAMCHA COLLAR & SPECIES-AUTHENTIC HEAD
  // =========================================================================
  const neckGroup = new THREE.Group();
  neckGroup.position.set(0, 0.13 * s, 0.43 * s * lengthRatio);
  bodyGroup.add(neckGroup);

  const neckTopR = isTiger ? 0.15 * s : isLeopard ? 0.122 * s : 0.118 * s;
  const neckBotR = isTiger ? 0.195 * s : isLeopard ? 0.158 * s : 0.155 * s;
  const neckLen = isHound ? 0.34 * s : isLeopard ? 0.31 * s : 0.28 * s;
  const neck = new THREE.Mesh(
    new THREE.CylinderGeometry(neckTopR, neckBotR, neckLen, 12),
    coatMat,
  );
  neck.position.set(0, 0.07 * s, 0.08 * s);
  neck.rotation.x = isHound ? 0.56 : 0.72;
  neck.castShadow = true;
  neckGroup.add(neck);

  // Cream throat underside
  const throat = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.085 * s, 0.16 * s, 5, 8),
    bellyMat,
  );
  throat.position.set(0, -0.01 * s, 0.11 * s);
  throat.rotation.x = 0.68;
  neckGroup.add(throat);

  // Traditional Bengali Red-and-Gold Warrior Gamcha Collar (revealed once permanently tamed!)
  const collarGroup = new THREE.Group();
  collarGroup.position.set(0, 0.06 * s, 0.08 * s);
  collarGroup.visible = isTamed;
  neckGroup.add(collarGroup);

  const collarBandMat = new THREE.MeshStandardMaterial({
    color: 0xc81e24,
    roughness: 0.52,
    metalness: 0.08,
  });
  const collarGoldMat = new THREE.MeshStandardMaterial({
    color: 0xffcf48,
    emissive: 0x7c4b00,
    emissiveIntensity: 0.35,
    roughness: 0.22,
    metalness: 0.86,
  });
  const collarBand = new THREE.Mesh(
    new THREE.TorusGeometry((neckBotR + neckTopR) * 0.52, 0.038 * s, 8, 18),
    collarBandMat,
  );
  collarBand.rotation.x = Math.PI / 2 - 0.55;
  collarGroup.add(collarBand);

  const collarMedallion = new THREE.Mesh(
    new THREE.SphereGeometry(0.048 * s, 10, 8),
    collarGoldMat,
  );
  collarMedallion.position.set(0, -0.11 * s, 0.15 * s);
  collarGroup.add(collarMedallion);

  const collarSash = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.025 * s, 0.16 * s, 4, 8),
    collarBandMat,
  );
  collarSash.position.set(0.09 * s, -0.08 * s, -0.08 * s);
  collarSash.rotation.set(-0.6, 0, -0.45);
  collarGroup.add(collarSash);

  // Head pivot
  const headGroup = new THREE.Group();
  headGroup.position.set(0, (isHound ? 0.2 : 0.16) * s, (isHound ? 0.18 : 0.21) * s);
  neckGroup.add(headGroup);

  // Sculpted Cranium
  const cranium = new THREE.Mesh(new THREE.SphereGeometry(0.185 * s, 14, 12), coatMat);
  if (isTiger) {
    cranium.scale.set(1.12, 0.96, 1.05);
  } else if (isLeopard) {
    cranium.scale.set(0.94, 0.88, 1.04);
  } else {
    cranium.scale.set(0.86, 0.88, 1.1);
  }
  cranium.castShadow = true;
  headGroup.add(cranium);

  if (isHound) {
    // Distinct tapered canine muzzle + nasal bridge + lower jaw
    const muzzle = new THREE.Mesh(
      new THREE.CylinderGeometry(0.068 * s, 0.11 * s, 0.24 * s, 10),
      coatMat,
    );
    muzzle.rotation.x = Math.PI / 2;
    muzzle.position.set(0, -0.03 * s, 0.21 * s);
    muzzle.castShadow = true;
    headGroup.add(muzzle);

    const muzzleTip = new THREE.Mesh(new THREE.SphereGeometry(0.072 * s, 10, 8), bellyMat);
    muzzleTip.scale.set(1.0, 0.82, 0.9);
    muzzleTip.position.set(0, -0.04 * s, 0.31 * s);
    headGroup.add(muzzleTip);

    const lowerJaw = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.048 * s, 0.14 * s, 5, 8),
      bellyMat,
    );
    lowerJaw.rotation.x = Math.PI / 2;
    lowerJaw.position.set(0, -0.095 * s, 0.19 * s);
    headGroup.add(lowerJaw);

    const nose = new THREE.Mesh(new THREE.SphereGeometry(0.042 * s, 8, 8), noseMat);
    nose.scale.set(1.15, 0.82, 0.78);
    nose.position.set(0, -0.015 * s, 0.35 * s);
    headGroup.add(nose);

    // Tall pointed alert guard-dog ears with warm inner ear cones
    const outerEarGeo = new THREE.ConeGeometry(0.068 * s, 0.19 * s, 7);
    const innerEarGeo = new THREE.ConeGeometry(0.042 * s, 0.14 * s, 6);
    for (const side of [-1, 1]) {
      const earPivot = new THREE.Group();
      earPivot.position.set(side * 0.1 * s, 0.14 * s, -0.01 * s);
      earPivot.rotation.set(0.16, side * 0.12, -side * 0.18);
      const outerEar = new THREE.Mesh(outerEarGeo, markingMat);
      outerEar.position.y = 0.08 * s;
      earPivot.add(outerEar);
      const innerEar = new THREE.Mesh(innerEarGeo, innerEarMat);
      innerEar.position.set(0, 0.075 * s, 0.022 * s);
      earPivot.add(innerEar);
      headGroup.add(earPivot);
    }
  } else {
    // Sculpted Big-Cat Feline Head (Tiger & Leopard)
    const muzzleBridge = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.085 * s, 0.12 * s, 6, 10),
      coatMat,
    );
    muzzleBridge.rotation.x = Math.PI / 2;
    muzzleBridge.scale.set(1.06, 0.88, 1);
    muzzleBridge.position.set(0, -0.025 * s, 0.17 * s);
    muzzleBridge.castShadow = true;
    headGroup.add(muzzleBridge);

    // Twin whisker/muzzle pads (signature feline silhouette)
    const padGeo = new THREE.SphereGeometry(0.064 * s, 9, 8);
    for (const side of [-1, 1]) {
      const pad = new THREE.Mesh(padGeo, bellyMat);
      pad.scale.set(0.95, 0.86, 1.05);
      pad.position.set(side * 0.056 * s, -0.06 * s, 0.225 * s);
      headGroup.add(pad);
    }

    // Chin / lower jaw
    const chin = new THREE.Mesh(new THREE.SphereGeometry(0.062 * s, 8, 8), bellyMat);
    chin.scale.set(1.05, 0.72, 1.15);
    chin.position.set(0, -0.105 * s, 0.185 * s);
    headGroup.add(chin);

    // Wide feline nose
    const nose = new THREE.Mesh(new THREE.SphereGeometry(0.044 * s, 8, 8), noseMat);
    nose.scale.set(1.25, 0.78, 0.72);
    nose.position.set(0, -0.02 * s, 0.27 * s);
    headGroup.add(nose);

    // Tiger signature fluffy white cheek ruffs + dark forehead stripes
    if (isTiger) {
      const ruffGeo = new THREE.SphereGeometry(0.095 * s, 9, 8);
      for (const side of [-1, 1]) {
        const ruff = new THREE.Mesh(ruffGeo, bellyMat);
        ruff.scale.set(0.85, 0.92, 0.72);
        ruff.position.set(side * 0.17 * s, -0.045 * s, 0.03 * s);
        headGroup.add(ruff);

        const cheekStripe = new THREE.Mesh(
          new THREE.CapsuleGeometry(0.015 * s, 0.075 * s, 4, 6),
          markingMat,
        );
        cheekStripe.rotation.z = side * 1.15;
        cheekStripe.position.set(side * 0.165 * s, 0.01 * s, 0.075 * s);
        headGroup.add(cheekStripe);
      }

      // Forehead crown stripes
      for (const side of [-0.055, 0, 0.055]) {
        const brow = new THREE.Mesh(
          new THREE.CapsuleGeometry(0.014 * s, 0.075 * s, 4, 6),
          markingMat,
        );
        brow.rotation.x = Math.PI / 2 - 0.35;
        brow.position.set(side * s, 0.155 * s, 0.06 * s);
        headGroup.add(brow);
      }
    } else {
      // Leopard facial spots on forehead/cheeks
      const faceSpotGeo = new THREE.SphereGeometry(0.018 * s, 6, 5);
      for (const [fx, fy, fz] of [
        [-0.08, 0.12, 0.09],
        [0.08, 0.12, 0.09],
        [0, 0.145, 0.07],
        [-0.14, 0.01, 0.08],
        [0.14, 0.01, 0.08],
      ]) {
        const fs = new THREE.Mesh(faceSpotGeo, markingMat);
        fs.position.set(fx * s, fy * s, fz * s);
        headGroup.add(fs);
      }
    }

    // Rounded big-cat ears with cream inner ear & white rear ear-spot
    const catEarGeo = new THREE.SphereGeometry(0.068 * s, 9, 8);
    const catInnerGeo = new THREE.SphereGeometry(0.044 * s, 7, 7);
    for (const side of [-1, 1]) {
      const ear = new THREE.Mesh(catEarGeo, markingMat);
      ear.scale.set(0.95, 1.02, 0.45);
      ear.position.set(side * 0.145 * s, 0.155 * s, -0.025 * s);
      ear.rotation.z = -side * 0.25;
      headGroup.add(ear);

      const earInner = new THREE.Mesh(catInnerGeo, innerEarMat);
      earInner.scale.set(0.9, 0.92, 0.35);
      earInner.position.set(side * 0.14 * s, 0.15 * s, -0.005 * s);
      earInner.rotation.z = -side * 0.25;
      headGroup.add(earInner);
    }
  }

  // Expressive Glowing Eyes with Dark Slit/Round Pupils
  const eyeGeo = new THREE.SphereGeometry(0.032 * s, 10, 8);
  const pupilGeo = new THREE.SphereGeometry(0.016 * s, 7, 7);
  const eyeX = isTiger ? 0.095 : isLeopard ? 0.082 : 0.074;
  const eyeZ = isHound ? 0.145 : 0.155;
  for (const side of [-1, 1]) {
    const eye = new THREE.Mesh(eyeGeo, eyeMat);
    eye.position.set(side * eyeX * s, 0.042 * s, eyeZ * s);
    headGroup.add(eye);

    const pupil = new THREE.Mesh(pupilGeo, pupilMat);
    pupil.scale.set(isHound ? 1 : 0.62, 1.1, 0.7);
    pupil.position.set(side * eyeX * s, 0.042 * s, (eyeZ + 0.022) * s);
    headGroup.add(pupil);
  }

  // =========================================================================
  // 4. FOUR ARTICULATED ORGANIC QUADRUPED LIMBS (Thigh + Joint + Shin + Paw)
  // =========================================================================
  const buildLeg = (xPos: number, zPos: number, isBack: boolean) => {
    const pivot = new THREE.Group();
    pivot.position.set(xPos, -0.06 * s, zPos);
    bodyGroup.add(pivot);

    const upperR = (isBack ? 0.088 : 0.078) * s * (isTiger ? 1.08 : 0.92);
    const upperLen = 0.24 * s * legLengthRatio;
    const upper = new THREE.Mesh(
      new THREE.CapsuleGeometry(upperR, upperLen, 6, 10),
      coatMat,
    );
    upper.position.set(0, -upperLen * 0.52, isBack ? -0.02 * s : 0.01 * s);
    upper.rotation.x = isBack ? 0.24 : -0.08;
    upper.castShadow = true;
    pivot.add(upper);

    // Knee / Hock rounded joint
    const jointY = -upperLen * 1.06;
    const jointZ = isBack ? -0.055 * s : 0.02 * s;
    const joint = new THREE.Mesh(
      new THREE.SphereGeometry(upperR * 0.76, 8, 8),
      coatMat,
    );
    joint.position.set(0, jointY, jointZ);
    pivot.add(joint);

    // Tapered muscular lower shin
    const lowerLen = 0.26 * s * legLengthRatio;
    const lower = new THREE.Mesh(
      new THREE.CylinderGeometry(upperR * 0.68, upperR * 0.54, lowerLen, 9),
      isHound ? bellyMat : coatMat,
    );
    lower.position.set(0, jointY - lowerLen * 0.48, jointZ + (isBack ? 0.045 * s : 0.005 * s));
    lower.rotation.x = isBack ? -0.22 : 0.06;
    lower.castShadow = true;
    pivot.add(lower);

    // Leg markings (tiger stripes or leopard spots on upper limb)
    if (isTiger) {
      const legBand = new THREE.Mesh(
        new THREE.TorusGeometry(upperR * 0.96, 0.014 * s, 5, 10),
        markingMat,
      );
      legBand.rotation.x = Math.PI / 2;
      legBand.position.set(0, -upperLen * 0.45, isBack ? -0.02 * s : 0.01 * s);
      pivot.add(legBand);
    }

    // Sculpted rounded paw with toe silhouette
    const pawY = jointY - lowerLen - 0.015 * s;
    const pawZ = jointZ + (isBack ? 0.085 * s : 0.038 * s);
    const paw = new THREE.Mesh(
      new THREE.SphereGeometry(upperR * 0.84, 9, 8),
      isTiger ? bellyMat : markingMat,
    );
    paw.scale.set(1.04, 0.56, 1.32);
    paw.position.set(0, pawY, pawZ);
    paw.castShadow = true;
    pivot.add(paw);

    // Subtle claw accents at front of paw
    for (const cOff of [-0.024, 0, 0.024]) {
      const claw = new THREE.Mesh(new THREE.ConeGeometry(0.01 * s, 0.028 * s, 5), clawMat);
      claw.rotation.x = Math.PI * 0.58;
      claw.position.set(cOff * s, pawY - 0.012 * s, pawZ + upperR * 1.05);
      pivot.add(claw);
    }

    return pivot;
  };

  const frontLegX = 0.165 * s * widthRatio;
  const backLegX = 0.16 * s * widthRatio;
  const frontLeftLeg = buildLeg(-frontLegX, 0.34 * s * lengthRatio, false);
  const frontRightLeg = buildLeg(frontLegX, 0.34 * s * lengthRatio, false);
  const backLeftLeg = buildLeg(-backLegX, -0.35 * s * lengthRatio, true);
  const backRightLeg = buildLeg(backLegX, -0.35 * s * lengthRatio, true);

  // =========================================================================
  // 5. CURVED MULTI-SEGMENT ORGANIC TAIL
  // =========================================================================
  const tailPivot = new THREE.Group();
  tailPivot.position.set(0, 0.1 * s, -0.52 * s * lengthRatio);
  bodyGroup.add(tailPivot);

  if (isHound) {
    // Alert upturned curved canine tail
    const seg1 = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.044 * s, 0.22 * s, 5, 8),
      coatMat,
    );
    seg1.rotation.x = 0.85;
    seg1.position.set(0, 0.08 * s, -0.1 * s);
    tailPivot.add(seg1);

    const seg2 = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.036 * s, 0.2 * s, 5, 8),
      markingMat,
    );
    seg2.rotation.x = 0.35;
    seg2.position.set(0, 0.24 * s, -0.19 * s);
    tailPivot.add(seg2);
  } else {
    // Long graceful sweeping feline tail (extra-long for Bengal Leopard, ringed for Tiger)
    const tailLenScale = isLeopard ? 1.24 : 1.05;
    const seg1 = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.042 * s, 0.26 * s * tailLenScale, 5, 8),
      coatMat,
    );
    seg1.rotation.x = -1.2;
    seg1.position.set(0, -0.06 * s, -0.15 * s * tailLenScale);
    tailPivot.add(seg1);

    const seg2 = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.035 * s, 0.24 * s * tailLenScale, 5, 8),
      coatMat,
    );
    seg2.rotation.x = -0.82;
    seg2.position.set(0, -0.12 * s, -0.38 * s * tailLenScale);
    tailPivot.add(seg2);

    const seg3 = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.028 * s, 0.2 * s * tailLenScale, 5, 8),
      isTiger ? markingMat : bellyMat,
    );
    seg3.rotation.x = -0.35;
    seg3.position.set(0, -0.06 * s, -0.56 * s * tailLenScale);
    tailPivot.add(seg3);

    if (isTiger) {
      for (const tz of [-0.14, -0.28, -0.42]) {
        const ring = new THREE.Mesh(
          new THREE.TorusGeometry(0.039 * s, 0.013 * s, 5, 10),
          markingMat,
        );
        ring.position.set(0, -0.09 * s, tz * s * tailLenScale);
        tailPivot.add(ring);
      }
    }
  }

  // =========================================================================
  // 6. SOFT GROUND CONTACT SHADOW & GOLDEN CAPTURE ZONE RINGS
  // =========================================================================
  const shadowMat = new THREE.MeshBasicMaterial({
    color: 0x090706,
    transparent: true,
    opacity: 0.36,
    depthWrite: false,
  });
  const contactShadow = new THREE.Mesh(new THREE.CircleGeometry(0.72 * s, 20), shadowMat);
  contactShadow.rotation.x = -Math.PI / 2;
  contactShadow.position.y = 0.025;
  root.add(contactShadow);

  const subduedRingMat = new THREE.MeshBasicMaterial({
    color: 0xffd24c,
    transparent: true,
    opacity: 0.9,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const subduedRing = new THREE.Mesh(
    new THREE.RingGeometry(TAME_GOLDEN_RING_RADIUS - 0.28, TAME_GOLDEN_RING_RADIUS, 44),
    subduedRingMat,
  );
  subduedRing.rotation.x = -Math.PI / 2;
  subduedRing.position.y = 0.06;
  const subduedFillMat = new THREE.MeshBasicMaterial({
    color: 0xffd24c,
    transparent: true,
    opacity: 0.14,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const subduedFill = new THREE.Mesh(
    new THREE.CircleGeometry(TAME_GOLDEN_RING_RADIUS - 0.28, 44),
    subduedFillMat,
  );
  subduedFill.position.z = -0.005;
  subduedRing.add(subduedFill);
  subduedRing.visible = false;
  root.add(subduedRing);

  const tameRingMat = new THREE.MeshBasicMaterial({
    color: 0x3ef5c5,
    transparent: true,
    opacity: 0.94,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const tameRing = new THREE.Mesh(
    new THREE.RingGeometry(TAME_GOLDEN_RING_RADIUS, TAME_GOLDEN_RING_RADIUS + 0.26, 44),
    tameRingMat,
  );
  tameRing.rotation.x = -Math.PI / 2;
  tameRing.position.y = 0.08;
  tameRing.visible = false;
  root.add(tameRing);

  // =========================================================================
  // 7. WORLD-SPACE FLOATING HEALTH BAR WITH 22% SUBDUE THRESHOLD NOTCH
  // =========================================================================
  const hpBarBg = new THREE.Mesh(
    new THREE.PlaneGeometry(1.32, 0.14),
    new THREE.MeshBasicMaterial({ color: 0x1a120d, side: THREE.DoubleSide }),
  );
  hpBarBg.position.set(0, 1.54 * s, 0);
  hpBarBg.visible = false;
  root.add(hpBarBg);

  const hpBarFill = new THREE.Mesh(
    new THREE.PlaneGeometry(1.26, 0.09),
    new THREE.MeshBasicMaterial({ color: 0xf05232, side: THREE.DoubleSide }),
  );
  hpBarFill.position.set(0, 0, 0.01);
  hpBarBg.add(hpBarFill);

  // Threshold notch showing the tight 22% subdued capture window
  const notch = new THREE.Mesh(
    new THREE.PlaneGeometry(0.035, 0.16),
    new THREE.MeshBasicMaterial({ color: 0xffe478, side: THREE.DoubleSide }),
  );
  notch.position.set(-0.63 + 1.26 * meta.subdueRatio, 0, 0.02);
  hpBarBg.add(notch);

  return {
    root,
    bodyGroup,
    neckGroup,
    headGroup,
    frontLeftLeg,
    frontRightLeg,
    backLeftLeg,
    backRightLeg,
    tailPivot,
    collarGroup,
    eyeMaterials: [eyeMat],
    flashMaterials,
    baseEmissives,
    hpBarBg,
    hpBarFill,
    subduedRing,
    tameRing,
  };
}

export function animateAnimalRig(
  rig: AnimalRig,
  species: WildAnimalSpecies,
  dt: number,
  worldTime: number,
  walkPhase: number,
  moveBlend: number,
  options: {
    isSubdued?: boolean;
    isLunging?: boolean;
    isTaming?: boolean;
    isTamed?: boolean;
    flinchPulse?: number;
  } = {},
): void {
  const s = WILD_ANIMAL_CATALOG[species].bodyScale;
  const legLengthRatio =
    species === 'sundarban_tiger' ? 0.98 : species === 'bengal_leopard' ? 1.05 : 1.02;
  const {
    isSubdued = false,
    isLunging = false,
    isTaming = false,
    isTamed = false,
    flinchPulse = 0,
  } = options;

  const w = THREE.MathUtils.clamp(moveBlend, 0, 1);
  const sinP = Math.sin(walkPhase);
  const cosP = Math.cos(walkPhase);
  const stride = (isLunging ? 0.88 : isSubdued ? 0.36 : 0.66) * w;

  // Quadruped diagonal gallop/trot leg phase
  const flTarget = sinP * stride - (isSubdued ? 0.22 : 0);
  const frTarget = -sinP * stride - (isSubdued ? 0.14 : 0);
  const blTarget = -sinP * stride * 0.92 + (isSubdued ? 0.18 : 0);
  const brTarget = sinP * stride * 0.92 + (isSubdued ? 0.12 : 0);

  rig.frontLeftLeg.rotation.x = THREE.MathUtils.damp(rig.frontLeftLeg.rotation.x, flTarget, 16, dt);
  rig.frontRightLeg.rotation.x = THREE.MathUtils.damp(rig.frontRightLeg.rotation.x, frTarget, 16, dt);
  rig.backLeftLeg.rotation.x = THREE.MathUtils.damp(rig.backLeftLeg.rotation.x, blTarget, 16, dt);
  rig.backRightLeg.rotation.x = THREE.MathUtils.damp(rig.backRightLeg.rotation.x, brTarget, 16, dt);

  const breathRate = isSubdued ? 6.0 : isTamed ? 2.4 : 3.4;
  const breath = Math.sin(worldTime * breathRate);

  const baseBodyY = 0.65 * s * legLengthRatio;
  const targetBodyY =
    baseBodyY +
    Math.abs(cosP) * 0.068 * s * w -
    (isSubdued ? 0.13 * s : 0) +
    (isLunging ? 0.12 * s : 0) +
    breath * (isSubdued ? 0.02 : 0.008) * s;

  const targetBodyPitch =
    (isLunging ? -0.24 : 0) +
    (isSubdued ? 0.15 : 0) +
    cosP * 0.075 * w -
    flinchPulse * 0.2;

  rig.bodyGroup.position.y = THREE.MathUtils.damp(rig.bodyGroup.position.y, targetBodyY, 15, dt);
  rig.bodyGroup.rotation.x = THREE.MathUtils.damp(rig.bodyGroup.rotation.x, targetBodyPitch, 14, dt);
  rig.bodyGroup.rotation.z = THREE.MathUtils.damp(
    rig.bodyGroup.rotation.z,
    sinP * 0.048 * w + (isSubdued ? Math.sin(worldTime * 8.2) * 0.032 : 0) + flinchPulse * 0.18,
    14,
    dt,
  );

  // Head & neck posture
  const targetHeadPitch =
    (isSubdued ? 0.34 + breath * 0.09 : 0) +
    (isTaming ? 0.12 : 0) +
    (isLunging ? -0.2 : 0) -
    flinchPulse * 0.28;
  const targetHeadYaw = isTamed
    ? Math.sin(worldTime * 1.4) * 0.16 * (1 - w * 0.6)
    : isSubdued
      ? Math.sin(worldTime * 3.4) * 0.16
      : Math.sin(worldTime * 2.1) * 0.09;

  rig.headGroup.rotation.x = THREE.MathUtils.damp(rig.headGroup.rotation.x, targetHeadPitch, 14, dt);
  rig.headGroup.rotation.y = THREE.MathUtils.damp(rig.headGroup.rotation.y, targetHeadYaw, 12, dt);

  // Expressive tail motion
  const tailYaw = isTamed
    ? Math.sin(worldTime * (5.2 + w * 3.5)) * 0.4
    : isSubdued
      ? Math.sin(worldTime * 2.4) * 0.1
      : Math.sin(worldTime * 7.0) * 0.32;
  const tailPitch = isTamed ? 0.26 : isSubdued ? -0.38 : 0.12;
  rig.tailPivot.rotation.y = THREE.MathUtils.damp(rig.tailPivot.rotation.y, tailYaw, 14, dt);
  rig.tailPivot.rotation.x = THREE.MathUtils.damp(rig.tailPivot.rotation.x, tailPitch, 12, dt);

  // Subdued & Taming ground rings
  rig.subduedRing.visible = isSubdued && !isTamed;
  if (rig.subduedRing.visible) {
    const pulse = 0.94 + Math.sin(worldTime * 5.6) * 0.07;
    rig.subduedRing.scale.set(pulse, pulse, 1);
    rig.subduedRing.rotation.z = worldTime * 1.05;
  }

  rig.tameRing.visible = isTaming && !isTamed;
  if (rig.tameRing.visible) {
    const pulse = 0.92 + Math.sin(worldTime * 10.0) * 0.08;
    rig.tameRing.scale.set(pulse, pulse, 1);
    rig.tameRing.rotation.z = -worldTime * 2.5;
  }
}
