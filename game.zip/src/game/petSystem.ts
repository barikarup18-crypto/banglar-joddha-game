import * as THREE from 'three';
import { getAnimalTextureSet } from './animalTextures';
import {
  AnimalHeartTier,
  AnimalHeartWallet,
  PetCombatStats,
  PetUpgradePlaceholder,
  PlayerProgressionState,
  TamedPetRecord,
  WildAnimalSpecies,
} from './types';

const STORAGE_KEY_PLAYER_ID = 'banglar_joddha_player_id_v1';
const STORAGE_KEY_PLAYER_PROGRESS = 'banglar_joddha_player_progression_v1';
const STORAGE_KEY_PET_REGISTRY = 'banglar_joddha_pet_registry_v1';
const STORAGE_KEY_ANIMAL_HEARTS = 'banglar_joddha_animal_hearts_v1';

// Tight golden capture ring radius — demands close-range nerve & positioning
export const TAME_GOLDEN_RING_RADIUS = 2.95;

export const PLAYER_MAX_LEVEL = 1000;
export const PET_MAX_LEVEL = 1000;

// Unified Animal Heart level-up cost scaling for both Player & Pet (LV 1 -> LV 1000): 10 -> 30 -> 50 -> 70 ...
export function getLevelUpHeartCost(level: number, maxLevel = PLAYER_MAX_LEVEL): number {
  const lv = Math.max(1, Math.min(maxLevel, Math.round(level)));
  if (lv >= maxLevel) return 0;
  return 10 + (lv - 1) * 20;
}

// Legacy XP table retained for backward-compatible type hydration (mid-match XP is disabled)
export const PET_LEVEL_UP_XP_REQUIREMENTS: Record<number, number> = {
  1: 120,
  2: 220,
  3: 340,
  4: 480,
};

export interface AnimalHeartTierMeta {
  tier: AnimalHeartTier;
  nameBn: string;
  shortNameBn: string;
  rarityEn: 'Common' | 'Rare' | 'Epic' | 'Legendary';
  value: number;
  colorHex: number;
  emissiveHex: number;
  ringHex: number;
}

export const ANIMAL_HEART_TIERS: Record<AnimalHeartTier, AnimalHeartTierMeta> = {
  1: {
    tier: 1,
    nameBn: 'সাধারণ এনিমেল হার্ট',
    shortNameBn: 'সাধারণ',
    rarityEn: 'Common',
    value: 1,
    colorHex: 0xef5368,
    emissiveHex: 0xb81f38,
    ringHex: 0xffa6b2,
  },
  2: {
    tier: 2,
    nameBn: 'দুর্লভ এনিমেল হার্ট',
    shortNameBn: 'দুর্লভ',
    rarityEn: 'Rare',
    value: 5,
    colorHex: 0x3bb2ff,
    emissiveHex: 0x1068d6,
    ringHex: 0x9ce3ff,
  },
  3: {
    tier: 3,
    nameBn: 'মহাকাব্যিক এনিমেল হার্ট',
    shortNameBn: 'মহাকাব্যিক',
    rarityEn: 'Epic',
    value: 15,
    colorHex: 0xc84dff,
    emissiveHex: 0x8619e0,
    ringHex: 0xebb0ff,
  },
  4: {
    tier: 4,
    nameBn: 'কিংবদন্তি এনিমেল হার্ট',
    shortNameBn: 'কিংবদন্তি',
    rarityEn: 'Legendary',
    value: 50,
    colorHex: 0xffb829,
    emissiveHex: 0xff5a1f,
    ringHex: 0xfff08a,
  },
};

export const ANIMAL_HEART_TIER_ORDER: AnimalHeartTier[] = [1, 2, 3, 4];

export function clampAnimalHeartTier(level: number): AnimalHeartTier {
  const clamped = Math.max(1, Math.min(4, Math.round(level)));
  return clamped as AnimalHeartTier;
}

/**
 * Rolls one of the 4 Animal Heart rarity tiers (Common=1, Rare=5, Epic=15, Legendary=50).
 * Higher tiers (Rare, Epic, Legendary) are noticeably scarce and tied to tougher selected species.
 */
export function rollAnimalHeartDropTier(
  luckBias = 0,
  species?: WildAnimalSpecies,
): AnimalHeartTier {
  const bias = Math.max(0, Math.min(0.45, luckBias));
  const maxTier: AnimalHeartTier = species ? WILD_ANIMAL_CATALOG[species].maxHeartTier : 4;

  // Noticeably scarce high-tier odds: Common ~72-82%, Rare ~14-20%, Epic ~2-6%, Legendary ~0.8-1.8% (apex only)
  const legendChance = maxTier >= 4 ? 0.008 + bias * 0.022 : 0;
  const epicChance =
    maxTier >= 3 ? 0.032 + bias * 0.062 : maxTier === 2 ? 0.012 + bias * 0.016 : 0;
  const rareChance = maxTier >= 2 ? 0.145 + bias * 0.135 : 0;

  const r = Math.random();
  if (r < legendChance) return 4;
  if (r < legendChance + epicChance) return 3;
  if (r < legendChance + epicChance + rareChance) return 2;
  return 1;
}

export interface WildAnimalSpeciesMeta {
  species: WildAnimalSpecies;
  nameBn: string;
  titleBn: string;
  assistRoleBn: string;
  maxHp: number;
  subdueRatio: number; // HP fraction <= this (and > 0) enters subdued state
  fleeHpRatio: number; // HP fraction <= this triggers wounded flee/retreat behavior
  dodgeChance: number; // Balanced per-shot bullet evade probability when off cooldown
  dodgeCooldown: number; // Minimum seconds between bullet dodges
  moveSpeed: number;
  lungeSpeed: number;
  attackDamage: number;
  assistDamage: number;
  assistCooldown: number;
  bodyScale: number;
  coatHex: number;
  bellyHex: number;
  markingHex: number;
  eyeHex: number;
  canCarryAnimalHeart: boolean;
  maxHeartTier: AnimalHeartTier;
  heartLuckBonus: number;
}

export const WILD_ANIMAL_CATALOG: Record<WildAnimalSpecies, WildAnimalSpeciesMeta> = {
  sundarban_tiger: {
    species: 'sundarban_tiger',
    nameBn: 'রয়্যাল টাইগার',
    titleBn: 'রয়্যাল বেঙ্গল সঙ্গী',
    assistRoleBn: 'শত্রুকে ঝাঁপিয়ে আঘাত ও সতর্কতা',
    maxHp: 490,
    subdueRatio: 0.22,
    fleeHpRatio: 0.27,
    dodgeChance: 0.28,
    dodgeCooldown: 3.5,
    moveSpeed: 6.8,
    lungeSpeed: 15.6,
    attackDamage: 26,
    assistDamage: 22,
    assistCooldown: 5.6,
    bodyScale: 1.32,
    coatHex: 0xc26526,
    bellyHex: 0xe6dac4,
    markingHex: 0x1a1411,
    eyeHex: 0xd99b2e,
    canCarryAnimalHeart: true,
    maxHeartTier: 4,
    heartLuckBonus: 0.16,
  },
  gorilla_king: {
    species: 'gorilla_king',
    nameBn: 'গরিলা রাজা',
    titleBn: 'অরণ্যের মহাবলী সঙ্গী',
    assistRoleBn: 'প্রচণ্ড বজ্রমুষ্টি আঘাত ও বুক চাপড়ানো গর্জন',
    maxHp: 620,
    subdueRatio: 0.22,
    fleeHpRatio: 0.25,
    dodgeChance: 0.14,
    dodgeCooldown: 5.0,
    moveSpeed: 6.1,
    lungeSpeed: 13.8,
    attackDamage: 32,
    assistDamage: 28,
    assistCooldown: 5.8,
    bodyScale: 1.48,
    coatHex: 0x222123,
    bellyHex: 0x8e9399,
    markingHex: 0x141315,
    eyeHex: 0xb8762c,
    canCarryAnimalHeart: true,
    maxHeartTier: 4,
    heartLuckBonus: 0.22,
  },
  ajagar_python: {
    species: 'ajagar_python',
    nameBn: 'অজগর সাপ',
    titleBn: 'গুহার বিষধর অজগর সঙ্গী',
    assistRoleBn: 'নিঃশব্দে পেঁচিয়ে ধরা ও হঠাৎ ছোবল',
    maxHp: 440,
    subdueRatio: 0.22,
    fleeHpRatio: 0.28,
    dodgeChance: 0.22,
    dodgeCooldown: 4.1,
    moveSpeed: 5.8,
    lungeSpeed: 13.2,
    attackDamage: 24,
    assistDamage: 21,
    assistCooldown: 5.0,
    bodyScale: 1.24,
    coatHex: 0x5d583a,
    bellyHex: 0xc9bc8e,
    markingHex: 0x261d13,
    eyeHex: 0xc9962b,
    canCarryAnimalHeart: true,
    maxHeartTier: 2,
    heartLuckBonus: 0.08,
  },
  lion_king: {
    species: 'lion_king',
    nameBn: 'সিংহ রাজা',
    titleBn: 'রাজকীয় বনরাজ সঙ্গী',
    assistRoleBn: 'রাজকীয় গর্জন ও প্রবল নখরের আঘাত',
    maxHp: 560,
    subdueRatio: 0.22,
    fleeHpRatio: 0.26,
    dodgeChance: 0.24,
    dodgeCooldown: 3.9,
    moveSpeed: 7.0,
    lungeSpeed: 15.8,
    attackDamage: 29,
    assistDamage: 25,
    assistCooldown: 5.4,
    bodyScale: 1.38,
    coatHex: 0xbe8e4b,
    bellyHex: 0xe6d6b6,
    markingHex: 0x452715,
    eyeHex: 0xcf942c,
    canCarryAnimalHeart: true,
    maxHeartTier: 4,
    heartLuckBonus: 0.24,
  },
  giant_spider: {
    species: 'giant_spider',
    nameBn: 'ভয়ংকর মাকড়সা',
    titleBn: 'অন্ধকার গুহার মাকড়সা সঙ্গী',
    assistRoleBn: 'ক্ষিপ্র অষ্টপদ আক্রমণ ও বিষদাঁতের কামড়',
    maxHp: 355,
    subdueRatio: 0.22,
    fleeHpRatio: 0.3,
    dodgeChance: 0.32,
    dodgeCooldown: 3.2,
    moveSpeed: 7.4,
    lungeSpeed: 15.2,
    attackDamage: 22,
    assistDamage: 19,
    assistCooldown: 4.5,
    bodyScale: 1.18,
    coatHex: 0x252124,
    bellyHex: 0x3b3130,
    markingHex: 0x8f2524,
    eyeHex: 0xa62028,
    canCarryAnimalHeart: false,
    maxHeartTier: 1,
    heartLuckBonus: 0,
  },
  wild_boar: {
    species: 'wild_boar',
    nameBn: 'বন্য শূকর',
    titleBn: 'শালবনের দন্তাল সঙ্গী',
    assistRoleBn: 'তীক্ষ্ণ দাঁতের ধাক্কা ও ক্ষিপ্র পাল্টা আঘাত',
    maxHp: 410,
    subdueRatio: 0.22,
    fleeHpRatio: 0.28,
    dodgeChance: 0.16,
    dodgeCooldown: 4.4,
    moveSpeed: 6.9,
    lungeSpeed: 14.8,
    attackDamage: 24,
    assistDamage: 20,
    assistCooldown: 5.0,
    bodyScale: 1.16,
    coatHex: 0x4a3b30,
    bellyHex: 0x6b5849,
    markingHex: 0x231b15,
    eyeHex: 0xb06c28,
    canCarryAnimalHeart: false,
    maxHeartTier: 1,
    heartLuckBonus: 0,
  },
  bengal_bear: {
    species: 'bengal_bear',
    nameBn: 'বন্য ভালুক',
    titleBn: 'পাহাড়ি গুহার ভালুক সঙ্গী',
    assistRoleBn: 'ভারী থাবার প্রহার ও দুর্ভেদ্য ঢাল',
    maxHp: 580,
    subdueRatio: 0.22,
    fleeHpRatio: 0.26,
    dodgeChance: 0.12,
    dodgeCooldown: 5.2,
    moveSpeed: 5.9,
    lungeSpeed: 13.4,
    attackDamage: 30,
    assistDamage: 26,
    assistCooldown: 5.8,
    bodyScale: 1.4,
    coatHex: 0x261e1a,
    bellyHex: 0xdccaa8,
    markingHex: 0x16110e,
    eyeHex: 0xb0732a,
    canCarryAnimalHeart: true,
    maxHeartTier: 3,
    heartLuckBonus: 0.12,
  },
  bengal_leopard: {
    species: 'bengal_leopard',
    nameBn: 'বাংলার চিতাবাঘ',
    titleBn: 'ক্ষিপ্র চিতা সঙ্গী',
    assistRoleBn: 'দ্রুত পাশ থেকে শত্রু বিচলিত করা',
    maxHp: 375,
    subdueRatio: 0.22,
    fleeHpRatio: 0.3,
    dodgeChance: 0.34,
    dodgeCooldown: 3.1,
    moveSpeed: 7.9,
    lungeSpeed: 16.8,
    attackDamage: 22,
    assistDamage: 18,
    assistCooldown: 4.8,
    bodyScale: 1.16,
    coatHex: 0xc59348,
    bellyHex: 0xe6dac2,
    markingHex: 0x241910,
    eyeHex: 0xd1a93b,
    canCarryAnimalHeart: false,
    maxHeartTier: 1,
    heartLuckBonus: 0,
  },
  village_hound: {
    species: 'village_hound',
    nameBn: 'বাংলার প্রহরী কুকুর',
    titleBn: 'বিশ্বস্ত গ্রাম্য সঙ্গী',
    assistRoleBn: 'শত্রু শনাক্তকরণ ও কাছের আক্রমণ',
    maxHp: 335,
    subdueRatio: 0.22,
    fleeHpRatio: 0.3,
    dodgeChance: 0.26,
    dodgeCooldown: 3.6,
    moveSpeed: 7.2,
    lungeSpeed: 15.0,
    attackDamage: 20,
    assistDamage: 16,
    assistCooldown: 4.4,
    bodyScale: 1.09,
    coatHex: 0x915b35,
    bellyHex: 0xdcc6a3,
    markingHex: 0x2a1c13,
    eyeHex: 0xb8762c,
    canCarryAnimalHeart: false,
    maxHeartTier: 1,
    heartLuckBonus: 0,
  },
};

export const WILD_ANIMAL_SPECIES_LIST: WildAnimalSpecies[] = [
  'gorilla_king',
  'ajagar_python',
  'lion_king',
  'giant_spider',
  'sundarban_tiger',
  'wild_boar',
  'bengal_bear',
  'bengal_leopard',
  'village_hound',
];

function generatePlayerId(): string {
  const digits = Math.floor(10000 + Math.random() * 90000);
  return `BJ-${digits}`;
}

export function getOrCreatePlayerId(): string {
  try {
    const existing = localStorage.getItem(STORAGE_KEY_PLAYER_ID);
    if (existing && /^BJ-\d{5}$/.test(existing.trim())) {
      return existing.trim();
    }
    const created = generatePlayerId();
    localStorage.setItem(STORAGE_KEY_PLAYER_ID, created);
    return created;
  } catch {
    return 'BJ-10001';
  }
}

type PetRegistryMap = Record<string, TamedPetRecord>;

function readPetRegistry(): PetRegistryMap {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_PET_REGISTRY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as unknown;
    if (!parsed || typeof parsed !== 'object') return {};
    return parsed as PetRegistryMap;
  } catch {
    return {};
  }
}

function writePetRegistry(registry: PetRegistryMap): void {
  try {
    localStorage.setItem(STORAGE_KEY_PET_REGISTRY, JSON.stringify(registry));
  } catch {
    // Ignore storage quota/privacy mode errors
  }
}

export function computePetStats(
  species: WildAnimalSpecies,
  level: number,
): PetCombatStats {
  const meta = WILD_ANIMAL_CATALOG[species];
  const lv = Math.max(1, Math.min(PET_MAX_LEVEL, Math.round(level)));
  const step = lv - 1;
  return {
    maxHp: Math.round(meta.maxHp + step * 28),
    attackDamage: Math.round(meta.assistDamage + step * 4),
    moveSpeed: Number((meta.moveSpeed + Math.min(7.5, step * 0.18)).toFixed(1)),
    assistCooldown: Number(Math.max(1.2, meta.assistCooldown - step * 0.06).toFixed(2)),
  };
}

export function getPlayerXpToNext(level: number): number {
  const lv = Math.max(1, Math.min(PLAYER_MAX_LEVEL, Math.round(level)));
  if (lv >= PLAYER_MAX_LEVEL) return 0;
  return Math.round(100 + (lv - 1) * 55 + Math.pow(lv - 1, 1.55) * 18);
}

export function computePlayerMaxHealth(level: number): number {
  const lv = Math.max(1, Math.min(PLAYER_MAX_LEVEL, Math.round(level)));
  return 100 + (lv - 1) * 10;
}

export function computePlayerWeaponDamageMult(level: number): number {
  const lv = Math.max(1, Math.min(PLAYER_MAX_LEVEL, Math.round(level)));
  return Number((1 + (lv - 1) * 0.05).toFixed(2));
}

// Animal Heart cost to manually level up the player in the lobby (LV 1 -> LV 1000: 10 -> 30 -> 50 -> ...)
export function getNextPlayerUpgradeCost(level: number): number {
  return getLevelUpHeartCost(level, PLAYER_MAX_LEVEL);
}

export function createPlayerProgressionState(level = 1, xp = 0): PlayerProgressionState {
  const lv = Math.max(1, Math.min(PLAYER_MAX_LEVEL, Math.round(level)));
  const xpToNext = getPlayerXpToNext(lv);
  const clampedXp = lv >= PLAYER_MAX_LEVEL ? 0 : Math.max(0, Math.floor(xp));
  const weaponDamageMult = computePlayerWeaponDamageMult(lv);
  return {
    level: lv,
    maxLevel: PLAYER_MAX_LEVEL,
    xp: xpToNext > 0 ? Math.min(clampedXp, Math.max(0, xpToNext - 1)) : 0,
    xpToNext,
    maxHealth: computePlayerMaxHealth(lv),
    weaponDamageMult,
    weaponDamageBonusPct: Math.round((weaponDamageMult - 1) * 100),
  };
}

interface StoredPlayerProgressEntry {
  level: number;
  xp: number;
}

type PlayerProgressMap = Record<string, StoredPlayerProgressEntry>;

function readPlayerProgressMap(): PlayerProgressMap {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_PLAYER_PROGRESS);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as unknown;
    if (!parsed || typeof parsed !== 'object') return {};
    return parsed as PlayerProgressMap;
  } catch {
    return {};
  }
}

function writePlayerProgressMap(map: PlayerProgressMap): void {
  try {
    localStorage.setItem(STORAGE_KEY_PLAYER_PROGRESS, JSON.stringify(map));
  } catch {
    // Ignore storage quota/privacy mode errors
  }
}

export function loadPlayerProgressionForId(playerId: string): PlayerProgressionState {
  const map = readPlayerProgressMap();
  const entry = map[playerId];
  if (!entry || typeof entry !== 'object') {
    return createPlayerProgressionState(1, 0);
  }
  return createPlayerProgressionState(Number(entry.level) || 1, Number(entry.xp) || 0);
}

export interface PlayerXpGrantResult {
  state: PlayerProgressionState;
  prevLevel: number;
  leveledUp: boolean;
  levelsGained: number;
  hpGain: number;
  prevDmgBonusPct: number;
}

export function grantPlayerXpForId(playerId: string, xpAmount: number): PlayerXpGrantResult {
  const current = loadPlayerProgressionForId(playerId);
  const prevLevel = current.level;
  const prevMaxHealth = current.maxHealth;
  const prevDmgBonusPct = current.weaponDamageBonusPct;
  const addXp = Math.max(0, Math.floor(xpAmount));

  if (addXp <= 0 || current.level >= PLAYER_MAX_LEVEL) {
    return {
      state: current,
      prevLevel,
      leveledUp: false,
      levelsGained: 0,
      hpGain: 0,
      prevDmgBonusPct,
    };
  }

  let lv = current.level;
  let xp = current.xp + addXp;
  while (lv < PLAYER_MAX_LEVEL) {
    const needed = getPlayerXpToNext(lv);
    if (needed <= 0 || xp < needed) break;
    xp -= needed;
    lv += 1;
  }
  if (lv >= PLAYER_MAX_LEVEL) {
    xp = 0;
  }

  const nextState = createPlayerProgressionState(lv, xp);
  const map = readPlayerProgressMap();
  map[playerId] = { level: nextState.level, xp: nextState.xp };
  writePlayerProgressMap(map);

  return {
    state: nextState,
    prevLevel,
    leveledUp: nextState.level > prevLevel,
    levelsGained: nextState.level - prevLevel,
    hpGain: nextState.maxHealth - prevMaxHealth,
    prevDmgBonusPct,
  };
}

export function getPetXpToNext(level: number): number {
  const lv = Math.max(1, Math.min(PET_MAX_LEVEL, Math.round(level)));
  if (lv >= PET_MAX_LEVEL) return 0;
  return PET_LEVEL_UP_XP_REQUIREMENTS[lv] ?? 0;
}

export function getNextPetUpgradeCost(level: number): number {
  return getLevelUpHeartCost(level, PET_MAX_LEVEL);
}

function getUnlockedPerksForLevel(level: number): string[] {
  const perks: string[] = ['স্থায়ী সঙ্গী প্রহরা (স্তর ১)'];
  if (level >= 2) perks.push('তেজস্বী ক্ষিপ্রতা · গতি ও আঘাত বৃদ্ধি (স্তর ২+)');
  if (level >= 10) perks.push('দুর্দান্ত প্রাণশক্তি · বর্ধিত স্বাস্থ্য ও শক্তি (স্তর ১০+)');
  if (level >= 50) perks.push('বজ্র ঝাঁপ · দ্রুততর আক্রমণ কুলডাউন (স্তর ৫০+)');
  if (level >= 200) perks.push('মহাকাব্যিক বাংলার সঙ্গী · অপ্রতিরোধ্য শক্তি (স্তর ২০০+)');
  if (level >= 1000) perks.push('কিংবদন্তি সর্বোচ্চ স্তর · স্তর ১০০০ পূর্ণ!');
  return perks;
}

export function createUpgradeStateForLevel(level: number, currentXp = 0): PetUpgradePlaceholder {
  const lv = Math.max(1, Math.min(PET_MAX_LEVEL, Math.round(level)));
  const nextCost = getNextPetUpgradeCost(lv);
  const xpToNext = getPetXpToNext(lv);
  const clampedXp = lv >= PET_MAX_LEVEL ? 0 : Math.max(0, Math.floor(currentXp));
  return {
    level: lv,
    maxLevel: PET_MAX_LEVEL,
    xp: xpToNext > 0 ? Math.min(clampedXp, Math.max(0, xpToNext - 1)) : 0,
    xpToNext,
    nextLevelResourceName: 'এনিমেল হার্ট',
    nextLevelResourceCost: nextCost,
    unlockedPerks: getUnlockedPerksForLevel(lv),
    upgradeLockedReason:
      lv >= PET_MAX_LEVEL
        ? 'সর্বোচ্চ স্তর (স্তর ১০০০) পূর্ণ হয়েছে'
        : 'লবির এনিমেল হার্ট প্যানেল থেকে সঙ্গী লেভেল-আপ করুন',
  };
}

export function createInitialUpgradePlaceholder(): PetUpgradePlaceholder {
  return createUpgradeStateForLevel(1, 0);
}

function normalizePetRecord(raw: TamedPetRecord): TamedPetRecord {
  const meta = WILD_ANIMAL_CATALOG[raw.species];
  const level = Math.max(
    1,
    Math.min(PET_MAX_LEVEL, Math.round(raw.upgrades?.level || 1)),
  );
  const stats = computePetStats(raw.species, level);
  // Migrate older records cleanly without treating legacy cumulative (lv-1)*100 as current XP progress
  const hasExplicitXpToNext = typeof raw.upgrades?.xpToNext === 'number';
  const storedXp = hasExplicitXpToNext ? Math.max(0, Math.floor(raw.upgrades?.xp || 0)) : 0;
  return {
    ...raw,
    nameBn: raw.nameBn || meta.nameBn,
    titleBn: raw.titleBn || meta.titleBn,
    assistRoleBn: raw.assistRoleBn || meta.assistRoleBn,
    bondStrength: Math.min(100 + (level - 1) * 25, Math.max(100, raw.bondStrength || 100)),
    stats,
    upgrades: createUpgradeStateForLevel(level, storedXp),
  };
}

export function loadPermanentPetForId(playerId: string): TamedPetRecord | null {
  const registry = readPetRegistry();
  const record = registry[playerId];
  if (!record || !WILD_ANIMAL_CATALOG[record.species]) {
    return null;
  }
  const normalized = normalizePetRecord(record);
  if (
    !record.stats ||
    record.upgrades?.nextLevelResourceName !== 'এনিমেল হার্ট' ||
    typeof record.upgrades?.xpToNext !== 'number'
  ) {
    registry[playerId] = normalized;
    writePetRegistry(registry);
  }
  return normalized;
}

/**
 * Persists a single lifetime pet for a given playerId.
 * Strictly refuses to overwrite if the playerId already owns a permanent pet.
 */
export function savePermanentPetForId(
  playerId: string,
  species: WildAnimalSpecies,
): TamedPetRecord | null {
  const registry = readPetRegistry();
  if (registry[playerId]) {
    // Lifetime one-pet lock: never replace or allow a second pet on the same ID
    return null;
  }
  const meta = WILD_ANIMAL_CATALOG[species];
  const record: TamedPetRecord = {
    playerId,
    species,
    nameBn: meta.nameBn,
    titleBn: meta.titleBn,
    tamedAtIso: new Date().toISOString(),
    bondStrength: 100,
    assistRoleBn: meta.assistRoleBn,
    stats: computePetStats(species, 1),
    upgrades: createUpgradeStateForLevel(1),
  };
  registry[playerId] = record;
  writePetRegistry(registry);
  return record;
}

// --- Per-Player Animal Heart Wallet Persistence (localStorage) ---

type HeartWalletMap = Record<string, AnimalHeartWallet>;

export function createEmptyAnimalHeartWallet(): AnimalHeartWallet {
  return {
    totalValue: 0,
    totalCount: 0,
    tiers: { 1: 0, 2: 0, 3: 0, 4: 0 },
  };
}

function decomposeValueIntoTiers(totalValue: number): Record<AnimalHeartTier, number> {
  const tiers: Record<AnimalHeartTier, number> = { 1: 0, 2: 0, 3: 0, 4: 0 };
  let rem = Math.max(0, Math.floor(totalValue));
  for (const tier of [4, 3, 2, 1] as AnimalHeartTier[]) {
    const val = ANIMAL_HEART_TIERS[tier].value;
    const count = Math.floor(rem / val);
    tiers[tier] = count;
    rem -= count * val;
  }
  return tiers;
}

function computeWalletTotalsFromTiers(
  tiers: Record<AnimalHeartTier, number>,
): { totalValue: number; totalCount: number } {
  let totalValue = 0;
  let totalCount = 0;
  for (const tier of ANIMAL_HEART_TIER_ORDER) {
    const count = Math.max(0, Math.floor(tiers[tier] || 0));
    tiers[tier] = count;
    totalCount += count;
    totalValue += count * ANIMAL_HEART_TIERS[tier].value;
  }
  return { totalValue, totalCount };
}

function normalizeHeartWallet(raw: Partial<AnimalHeartWallet> | undefined): AnimalHeartWallet {
  const base = createEmptyAnimalHeartWallet();
  if (!raw || typeof raw !== 'object') return base;

  const rawTiers = (raw.tiers ?? {}) as Record<number, unknown>;
  const tiers: Record<AnimalHeartTier, number> = {
    1: Math.max(0, Math.floor(Number(rawTiers[1] ?? 0))),
    2: Math.max(0, Math.floor(Number(rawTiers[2] ?? 0))),
    3: Math.max(0, Math.floor(Number(rawTiers[3] ?? 0))),
    4: Math.max(0, Math.floor(Number(rawTiers[4] ?? 0))),
  };
  const storedTotalValue = Math.max(0, Math.floor(Number(raw.totalValue ?? 0)));
  const hasLegacyTier5 = Number(rawTiers[5] ?? 0) > 0;
  const currentSum = computeWalletTotalsFromTiers(tiers);

  // Keep totalValue and tier counts 100% consistent (migrates legacy 5-tier wallets cleanly)
  if (hasLegacyTier5 || currentSum.totalValue !== storedTotalValue) {
    const reconciledTiers = decomposeValueIntoTiers(storedTotalValue);
    const reconciledTotals = computeWalletTotalsFromTiers(reconciledTiers);
    return {
      totalValue: reconciledTotals.totalValue,
      totalCount: reconciledTotals.totalCount,
      tiers: reconciledTiers,
    };
  }

  return {
    totalValue: currentSum.totalValue,
    totalCount: currentSum.totalCount,
    tiers,
  };
}

/**
 * Spends `cost` across the 4 Animal Heart tiers cleanly, making exact lower-tier change
 * whenever a higher-tier heart must be broken down so tier counts and totalValue always match.
 */
function spendAnimalHeartsAcrossTiers(
  wallet: AnimalHeartWallet,
  cost: number,
): AnimalHeartWallet | null {
  const spend = Math.max(0, Math.floor(cost));
  if (spend <= 0 || wallet.totalValue < spend) {
    return null;
  }

  const tiers: Record<AnimalHeartTier, number> = {
    1: wallet.tiers[1] || 0,
    2: wallet.tiers[2] || 0,
    3: wallet.tiers[3] || 0,
    4: wallet.tiers[4] || 0,
  };

  let remaining = spend;

  // Step 1: Consume hearts whose value <= remaining (highest fitting tier first)
  for (const tier of [4, 3, 2, 1] as AnimalHeartTier[]) {
    const val = ANIMAL_HEART_TIERS[tier].value;
    if (val <= remaining && tiers[tier] > 0) {
      const take = Math.min(tiers[tier], Math.floor(remaining / val));
      tiers[tier] -= take;
      remaining -= take * val;
    }
  }

  // Step 2: If remainder persists, break the smallest available higher-tier heart and return exact change
  if (remaining > 0) {
    let broken = false;
    for (const tier of [1, 2, 3, 4] as AnimalHeartTier[]) {
      const val = ANIMAL_HEART_TIERS[tier].value;
      if (tiers[tier] > 0 && val >= remaining) {
        tiers[tier] -= 1;
        let change = val - remaining;
        remaining = 0;
        for (const cTier of [4, 3, 2, 1] as AnimalHeartTier[]) {
          const cVal = ANIMAL_HEART_TIERS[cTier].value;
          if (change >= cVal) {
            const addCount = Math.floor(change / cVal);
            tiers[cTier] += addCount;
            change -= addCount * cVal;
          }
        }
        broken = true;
        break;
      }
    }
    if (!broken) {
      // Fallback exact reconciliation from totalValue
      const fallbackTiers = decomposeValueIntoTiers(wallet.totalValue - spend);
      const fallbackTotals = computeWalletTotalsFromTiers(fallbackTiers);
      return {
        totalValue: fallbackTotals.totalValue,
        totalCount: fallbackTotals.totalCount,
        tiers: fallbackTiers,
      };
    }
  }

  const totals = computeWalletTotalsFromTiers(tiers);
  return {
    totalValue: totals.totalValue,
    totalCount: totals.totalCount,
    tiers,
  };
}

function readHeartWalletMap(): HeartWalletMap {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_ANIMAL_HEARTS);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as unknown;
    if (!parsed || typeof parsed !== 'object') return {};
    return parsed as HeartWalletMap;
  } catch {
    return {};
  }
}

function writeHeartWalletMap(map: HeartWalletMap): void {
  try {
    localStorage.setItem(STORAGE_KEY_ANIMAL_HEARTS, JSON.stringify(map));
  } catch {
    // Ignore storage quota/privacy mode errors
  }
}

export function loadAnimalHeartsForId(playerId: string): AnimalHeartWallet {
  const map = readHeartWalletMap();
  return normalizeHeartWallet(map[playerId]);
}

export function addAnimalHeartForId(
  playerId: string,
  tier: AnimalHeartTier,
): { wallet: AnimalHeartWallet; tierMeta: AnimalHeartTierMeta } {
  const map = readHeartWalletMap();
  const wallet = normalizeHeartWallet(map[playerId]);
  const tierMeta = ANIMAL_HEART_TIERS[tier];
  wallet.tiers[tier] = (wallet.tiers[tier] || 0) + 1;
  const totals = computeWalletTotalsFromTiers(wallet.tiers);
  wallet.totalValue = totals.totalValue;
  wallet.totalCount = totals.totalCount;
  map[playerId] = wallet;
  writeHeartWalletMap(map);
  return { wallet, tierMeta };
}

export interface PetUpgradeResult {
  pet: TamedPetRecord;
  wallet: AnimalHeartWallet;
  prevStats: PetCombatStats;
  costPaid: number;
}

/**
 * Spends accumulated Animal Heart value across tiers to level up the player's single permanent pet (LV 1 -> LV 1000).
 * Persists both the updated pet level/stats and remaining Animal Hearts per playerId.
 */
export function upgradePermanentPetForId(playerId: string): PetUpgradeResult | null {
  const registry = readPetRegistry();
  const existing = registry[playerId];
  if (!existing || !WILD_ANIMAL_CATALOG[existing.species]) {
    return null;
  }
  const normalized = normalizePetRecord(existing);
  const currentLevel = normalized.upgrades.level;
  if (currentLevel >= PET_MAX_LEVEL) {
    return null;
  }
  const cost = getNextPetUpgradeCost(currentLevel);
  if (cost <= 0) {
    return null;
  }

  const walletMap = readHeartWalletMap();
  const wallet = normalizeHeartWallet(walletMap[playerId]);
  const nextWallet = spendAnimalHeartsAcrossTiers(wallet, cost);
  if (!nextWallet) {
    return null;
  }

  const prevStats = { ...normalized.stats };
  const nextLevel = currentLevel + 1;
  const nextStats = computePetStats(normalized.species, nextLevel);
  const updatedPet: TamedPetRecord = {
    ...normalized,
    bondStrength: 100 + Math.min(999, nextLevel - 1) * 25,
    stats: nextStats,
    upgrades: createUpgradeStateForLevel(nextLevel, 0),
  };

  walletMap[playerId] = nextWallet;
  registry[playerId] = updatedPet;

  writeHeartWalletMap(walletMap);
  writePetRegistry(registry);

  return {
    pet: updatedPet,
    wallet: nextWallet,
    prevStats,
    costPaid: cost,
  };
}

export interface PlayerHeartUpgradeResult {
  state: PlayerProgressionState;
  wallet: AnimalHeartWallet;
  prevLevel: number;
  hpGain: number;
  prevDmgBonusPct: number;
  costPaid: number;
}

/**
 * Spends accumulated Animal Heart value across tiers in the lobby to manually level up the player (LV 1 -> LV 1000).
 * Persists both the updated player level/stats and remaining Animal Hearts per playerId.
 */
export function upgradePlayerWithAnimalHeartsForId(
  playerId: string,
): PlayerHeartUpgradeResult | null {
  const current = loadPlayerProgressionForId(playerId);
  if (current.level >= PLAYER_MAX_LEVEL) {
    return null;
  }
  const cost = getNextPlayerUpgradeCost(current.level);
  if (cost <= 0) {
    return null;
  }

  const walletMap = readHeartWalletMap();
  const wallet = normalizeHeartWallet(walletMap[playerId]);
  const nextWallet = spendAnimalHeartsAcrossTiers(wallet, cost);
  if (!nextWallet) {
    return null;
  }

  const prevLevel = current.level;
  const prevMaxHealth = current.maxHealth;
  const prevDmgBonusPct = current.weaponDamageBonusPct;
  const nextState = createPlayerProgressionState(prevLevel + 1, 0);

  walletMap[playerId] = nextWallet;
  writeHeartWalletMap(walletMap);

  const progressMap = readPlayerProgressMap();
  progressMap[playerId] = { level: nextState.level, xp: 0 };
  writePlayerProgressMap(progressMap);

  return {
    state: nextState,
    wallet: nextWallet,
    prevLevel,
    hpGain: nextState.maxHealth - prevMaxHealth,
    prevDmgBonusPct,
    costPaid: cost,
  };
}

export interface PetXpGrantResult {
  pet: TamedPetRecord;
  prevLevel: number;
  leveledUp: boolean;
  prevStats: PetCombatStats;
}

/**
 * Grants XP to the player's permanent tamed pet (from Animal Heart pickups & gameplay XP).
 * Automatically levels up the pet (up to PET_MAX_LEVEL), scales combat/movement stats, and persists to localStorage.
 */
export function grantPetXpForId(playerId: string, xpAmount: number): PetXpGrantResult | null {
  const registry = readPetRegistry();
  const existing = registry[playerId];
  if (!existing || !WILD_ANIMAL_CATALOG[existing.species]) {
    return null;
  }
  const normalized = normalizePetRecord(existing);
  const prevLevel = normalized.upgrades.level;
  const prevStats = { ...normalized.stats };
  const addXp = Math.max(0, Math.floor(xpAmount));

  if (addXp <= 0 || prevLevel >= PET_MAX_LEVEL) {
    return {
      pet: normalized,
      prevLevel,
      leveledUp: false,
      prevStats,
    };
  }

  let lv = prevLevel;
  let xp = normalized.upgrades.xp + addXp;
  while (lv < PET_MAX_LEVEL) {
    const needed = getPetXpToNext(lv);
    if (needed <= 0 || xp < needed) break;
    xp -= needed;
    lv += 1;
  }
  if (lv >= PET_MAX_LEVEL) {
    xp = 0;
  }

  const nextStats = computePetStats(normalized.species, lv);
  const updatedPet: TamedPetRecord = {
    ...normalized,
    bondStrength: 100 + (lv - 1) * 25,
    stats: nextStats,
    upgrades: createUpgradeStateForLevel(lv, xp),
  };

  registry[playerId] = updatedPet;
  writePetRegistry(registry);

  return {
    pet: updatedPet,
    prevLevel,
    leveledUp: lv > prevLevel,
    prevStats,
  };
}

// --- Sculpted Organic Multi-Part 3D Quadruped Animal / Pet Rig (Zero BoxGeometry Cubes) ---

export interface AnimalRig {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  neckGroup: THREE.Group;
  headGroup: THREE.Group;
  frontLeftLeg: THREE.Group;
  frontRightLeg: THREE.Group;
  backLeftLeg: THREE.Group;
  backRightLeg: THREE.Group;
  tailPivot: THREE.Group;
  collarGroup: THREE.Group;
  eyeMaterials: THREE.MeshStandardMaterial[];
  flashMaterials: THREE.MeshStandardMaterial[];
  baseEmissives: THREE.Color[];
  hpBarBg: THREE.Mesh;
  hpBarFill: THREE.Mesh;
  subduedRing: THREE.Mesh;
  tameRing: THREE.Mesh;
  heartAuraRing: THREE.Mesh;
  petLevelRing: THREE.Mesh;
  bodyPlan: 'quadruped' | 'gorilla' | 'python' | 'spider';
  extraLegs?: THREE.Group[];
  snakeSegments?: THREE.Group[];
}

// Shared cached soft contact shadow texture (created once, zero runtime GC)
let cachedAnimalShadowTex: THREE.CanvasTexture | null = null;

function getAnimalContactShadowTexture(): THREE.CanvasTexture {
  if (cachedAnimalShadowTex) return cachedAnimalShadowTex;
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(64, 64, 10, 64, 64, 62);
  grad.addColorStop(0, 'rgba(10, 8, 6, 0.58)');
  grad.addColorStop(0.55, 'rgba(10, 8, 6, 0.30)');
  grad.addColorStop(1, 'rgba(10, 8, 6, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 128, 128);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.ClampToEdgeWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.needsUpdate = true;
  cachedAnimalShadowTex = tex;
  return tex;
}

function attachAnimalOverlays(
  root: THREE.Group,
  s: number,
  widthRatio: number,
  lengthRatio: number,
  hpBarY: number,
  subdueRatio: number,
): {
  hpBarBg: THREE.Mesh;
  hpBarFill: THREE.Mesh;
  subduedRing: THREE.Mesh;
  tameRing: THREE.Mesh;
  heartAuraRing: THREE.Mesh;
  petLevelRing: THREE.Mesh;
} {
  const shadowMat = new THREE.MeshBasicMaterial({
    map: getAnimalContactShadowTexture(),
    transparent: true,
    opacity: 0.88,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const contactShadow = new THREE.Mesh(
    new THREE.PlaneGeometry(1.48 * s * widthRatio, 1.88 * s * lengthRatio),
    shadowMat,
  );
  contactShadow.rotation.x = -Math.PI / 2;
  contactShadow.position.y = 0.026;
  root.add(contactShadow);

  const subduedRingMat = new THREE.MeshBasicMaterial({
    color: 0xffd24c,
    transparent: true,
    opacity: 0.9,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const subduedRing = new THREE.Mesh(
    new THREE.RingGeometry(TAME_GOLDEN_RING_RADIUS - 0.28, TAME_GOLDEN_RING_RADIUS, 44),
    subduedRingMat,
  );
  subduedRing.rotation.x = -Math.PI / 2;
  subduedRing.position.y = 0.06;
  const subduedFill = new THREE.Mesh(
    new THREE.CircleGeometry(TAME_GOLDEN_RING_RADIUS - 0.28, 44),
    new THREE.MeshBasicMaterial({
      color: 0xffd24c,
      transparent: true,
      opacity: 0.14,
      side: THREE.DoubleSide,
      depthWrite: false,
    }),
  );
  subduedFill.position.z = -0.005;
  subduedRing.add(subduedFill);
  subduedRing.visible = false;
  root.add(subduedRing);

  const tameRing = new THREE.Mesh(
    new THREE.RingGeometry(TAME_GOLDEN_RING_RADIUS, TAME_GOLDEN_RING_RADIUS + 0.26, 44),
    new THREE.MeshBasicMaterial({
      color: 0x3ef5c5,
      transparent: true,
      opacity: 0.94,
      side: THREE.DoubleSide,
      depthWrite: false,
    }),
  );
  tameRing.rotation.x = -Math.PI / 2;
  tameRing.position.y = 0.08;
  tameRing.visible = false;
  root.add(tameRing);

  const hpBarBg = new THREE.Mesh(
    new THREE.PlaneGeometry(1.32, 0.14),
    new THREE.MeshBasicMaterial({ color: 0x1a120d, side: THREE.DoubleSide }),
  );
  hpBarBg.position.set(0, hpBarY, 0);
  hpBarBg.visible = false;
  root.add(hpBarBg);

  const hpBarFill = new THREE.Mesh(
    new THREE.PlaneGeometry(1.26, 0.09),
    new THREE.MeshBasicMaterial({ color: 0xf05232, side: THREE.DoubleSide }),
  );
  hpBarFill.position.set(0, 0, 0.01);
  hpBarBg.add(hpBarFill);

  const notch = new THREE.Mesh(
    new THREE.PlaneGeometry(0.035, 0.16),
    new THREE.MeshBasicMaterial({ color: 0xffe478, side: THREE.DoubleSide }),
  );
  notch.position.set(-0.63 + 1.26 * subdueRatio, 0, 0.02);
  hpBarBg.add(notch);

  const heartAuraRing = new THREE.Mesh(
    new THREE.RingGeometry(0.95 * s, 1.24 * s, 32),
    new THREE.MeshBasicMaterial({
      color: 0xff456b,
      transparent: true,
      opacity: 0.78,
      side: THREE.DoubleSide,
      depthWrite: false,
    }),
  );
  heartAuraRing.rotation.x = -Math.PI / 2;
  heartAuraRing.position.y = 0.055;
  heartAuraRing.visible = false;
  root.add(heartAuraRing);

  const petLevelRing = new THREE.Mesh(
    new THREE.RingGeometry(0.76 * s, 0.96 * s, 32),
    new THREE.MeshBasicMaterial({
      color: 0x4df5b8,
      transparent: true,
      opacity: 0.62,
      side: THREE.DoubleSide,
      depthWrite: false,
    }),
  );
  petLevelRing.rotation.x = -Math.PI / 2;
  petLevelRing.position.y = 0.045;
  petLevelRing.visible = false;
  root.add(petLevelRing);

  return { hpBarBg, hpBarFill, subduedRing, tameRing, heartAuraRing, petLevelRing };
}

function buildPythonRig(meta: WildAnimalSpeciesMeta, isTamed: boolean): AnimalRig {
  const s = meta.bodyScale;
  const root = new THREE.Group();
  const bodyGroup = new THREE.Group();
  bodyGroup.position.set(0, 0.145 * s, 0);
  root.add(bodyGroup);

  const flashMaterials: THREE.MeshStandardMaterial[] = [];
  const baseEmissives: THREE.Color[] = [];
  const reg = (mat: THREE.MeshStandardMaterial) => {
    flashMaterials.push(mat);
    baseEmissives.push(mat.emissive.clone());
    return mat;
  };
  const tex = getAnimalTextureSet(meta.species);
  const scaleMat = reg(
    new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: tex.coatMap,
      bumpMap: tex.bumpMap,
      bumpScale: 0.058,
      roughness: 0.48,
      metalness: 0.06,
    }),
  );
  const bellyMat = reg(
    new THREE.MeshStandardMaterial({
      color: meta.bellyHex,
      bumpMap: tex.bumpMap,
      bumpScale: 0.028,
      roughness: 0.58,
      metalness: 0.04,
    }),
  );
  const darkHeadMat = reg(
    new THREE.MeshStandardMaterial({
      color: 0x362f20,
      bumpMap: tex.bumpMap,
      bumpScale: 0.044,
      roughness: 0.5,
      metalness: 0.06,
    }),
  );
  const eyeMat = new THREE.MeshStandardMaterial({
    color: isTamed ? 0x45cca8 : meta.eyeHex,
    emissive: isTamed ? 0x157d66 : meta.eyeHex,
    emissiveIntensity: isTamed ? 0.34 : 0.08,
    roughness: 0.08,
    metalness: 0.1,
  });
  const slitMat = new THREE.MeshStandardMaterial({
    color: 0x0a0807,
    roughness: 0.06,
  });
  const tongueMat = new THREE.MeshStandardMaterial({
    color: 0x7c1c24,
    roughness: 0.26,
    metalness: 0.06,
  });

  const neckGroup = new THREE.Group();
  neckGroup.position.set(0, 0.135 * s, 0.88 * s);
  bodyGroup.add(neckGroup);

  const headGroup = new THREE.Group();
  headGroup.position.set(0, 0.075 * s, 0.17 * s);
  neckGroup.add(headGroup);

  // Sculpted angular Indian Rock Python head with brow ridges, tapered snout & dark spear-head mark
  const skull = new THREE.Mesh(new THREE.SphereGeometry(0.142 * s, 11, 9), scaleMat);
  skull.scale.set(1.16, 0.56, 1.48);
  skull.castShadow = true;
  headGroup.add(skull);

  const crownShield = new THREE.Mesh(new THREE.ConeGeometry(0.088 * s, 0.24 * s, 5), darkHeadMat);
  crownShield.rotation.x = Math.PI / 2;
  crownShield.scale.set(1.0, 0.35, 1.0);
  crownShield.position.set(0, 0.058 * s, 0.04 * s);
  headGroup.add(crownShield);

  const snout = new THREE.Mesh(new THREE.CapsuleGeometry(0.066 * s, 0.15 * s, 5, 9), scaleMat);
  snout.rotation.x = Math.PI / 2;
  snout.scale.set(1.04, 0.62, 1.0);
  snout.position.set(0, -0.012 * s, 0.165 * s);
  headGroup.add(snout);

  const jaw = new THREE.Mesh(new THREE.SphereGeometry(0.105 * s, 8, 7), bellyMat);
  jaw.scale.set(1.0, 0.38, 1.38);
  jaw.position.set(0, -0.052 * s, 0.065 * s);
  headGroup.add(jaw);

  // Supraorbital brow ridges + natural glossy amber eyes with vertical slit pupils
  const eyeGeo = new THREE.SphereGeometry(0.025 * s, 8, 7);
  const slitGeo = new THREE.BoxGeometry(0.008 * s, 0.03 * s, 0.012 * s);
  const browGeo = new THREE.CapsuleGeometry(0.016 * s, 0.075 * s, 3, 6);
  for (const side of [-1, 1]) {
    const brow = new THREE.Mesh(browGeo, darkHeadMat);
    brow.rotation.x = Math.PI / 2;
    brow.rotation.y = side * 0.22;
    brow.position.set(side * 0.082 * s, 0.045 * s, 0.115 * s);
    headGroup.add(brow);

    const eye = new THREE.Mesh(eyeGeo, eyeMat);
    eye.position.set(side * 0.09 * s, 0.025 * s, 0.112 * s);
    headGroup.add(eye);

    const slit = new THREE.Mesh(slitGeo, slitMat);
    slit.position.set(side * 0.095 * s, 0.025 * s, 0.132 * s);
    headGroup.add(slit);
  }

  // Slender dark-crimson forked tongue
  const tongueStem = new THREE.Mesh(new THREE.CapsuleGeometry(0.006 * s, 0.11 * s, 3, 5), tongueMat);
  tongueStem.rotation.x = Math.PI / 2;
  tongueStem.position.set(0, -0.026 * s, 0.295 * s);
  headGroup.add(tongueStem);
  for (const side of [-1, 1]) {
    const fork = new THREE.Mesh(new THREE.CapsuleGeometry(0.004 * s, 0.045 * s, 2, 4), tongueMat);
    fork.rotation.x = Math.PI / 2;
    fork.rotation.y = side * 0.42;
    fork.position.set(side * 0.014 * s, -0.026 * s, 0.362 * s);
    headGroup.add(fork);
  }

  // Tamed collar around neck
  const collarGroup = new THREE.Group();
  collarGroup.visible = isTamed;
  const collarBand = new THREE.Mesh(
    new THREE.TorusGeometry(0.118 * s, 0.026 * s, 6, 14),
    new THREE.MeshStandardMaterial({ color: 0xb02226, roughness: 0.56 }),
  );
  collarBand.position.set(0, 0.04 * s, 0.02 * s);
  collarGroup.add(collarBand);
  neckGroup.add(collarGroup);

  // 10 smoothly overlapping tapered serpentine body segments with seamless reticulated scale texture
  const snakeSegments: THREE.Group[] = [];
  const segRadii = [0.116, 0.145, 0.165, 0.172, 0.164, 0.148, 0.128, 0.104, 0.078, 0.05];
  const segZ = [0.72, 0.46, 0.18, -0.1, -0.38, -0.66, -0.93, -1.18, -1.42, -1.64];
  for (let i = 0; i < segRadii.length; i++) {
    const segGroup = new THREE.Group();
    segGroup.position.set(0, 0, segZ[i] * s);
    const r = segRadii[i] * s;
    const segMesh = new THREE.Mesh(new THREE.CapsuleGeometry(r, 0.22 * s, 6, 10), scaleMat);
    segMesh.rotation.x = Math.PI / 2;
    segMesh.scale.set(1.08, 1.0, 0.84);
    segMesh.castShadow = true;
    segMesh.receiveShadow = true;
    segGroup.add(segMesh);

    const bellyPlate = new THREE.Mesh(new THREE.CapsuleGeometry(r * 0.72, 0.19 * s, 4, 8), bellyMat);
    bellyPlate.rotation.x = Math.PI / 2;
    bellyPlate.position.y = -r * 0.38;
    segGroup.add(bellyPlate);

    bodyGroup.add(segGroup);
    snakeSegments.push(segGroup);
  }

  const tailPivot = snakeSegments[snakeSegments.length - 1];
  const dummyLeg = () => new THREE.Group();
  const overlays = attachAnimalOverlays(root, s, 0.92, 1.58, 1.06 * s, meta.subdueRatio);

  return {
    root,
    bodyGroup,
    neckGroup,
    headGroup,
    frontLeftLeg: dummyLeg(),
    frontRightLeg: dummyLeg(),
    backLeftLeg: dummyLeg(),
    backRightLeg: dummyLeg(),
    tailPivot,
    collarGroup,
    eyeMaterials: [eyeMat],
    flashMaterials,
    baseEmissives,
    ...overlays,
    bodyPlan: 'python',
    snakeSegments,
  };
}

function buildSpiderRig(meta: WildAnimalSpeciesMeta, isTamed: boolean): AnimalRig {
  const s = meta.bodyScale;
  const root = new THREE.Group();
  const bodyGroup = new THREE.Group();
  bodyGroup.position.set(0, 0.45 * s, 0);
  root.add(bodyGroup);

  const flashMaterials: THREE.MeshStandardMaterial[] = [];
  const baseEmissives: THREE.Color[] = [];
  const reg = (mat: THREE.MeshStandardMaterial) => {
    flashMaterials.push(mat);
    baseEmissives.push(mat.emissive.clone());
    return mat;
  };
  const tex = getAnimalTextureSet(meta.species);
  const chitinMat = reg(
    new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: tex.coatMap,
      bumpMap: tex.bumpMap,
      bumpScale: 0.056,
      roughness: 0.54,
      metalness: 0.1,
    }),
  );
  const darkJointMat = reg(
    new THREE.MeshStandardMaterial({
      color: 0x221d1c,
      bumpMap: tex.bumpMap,
      bumpScale: 0.038,
      roughness: 0.6,
      metalness: 0.08,
    }),
  );
  const fangMat = reg(
    new THREE.MeshStandardMaterial({
      color: 0x1a1514,
      roughness: 0.32,
      metalness: 0.16,
    }),
  );
  const eyeMat = new THREE.MeshStandardMaterial({
    color: isTamed ? 0x45cca8 : meta.eyeHex,
    emissive: isTamed ? 0x157d66 : meta.eyeHex,
    emissiveIntensity: isTamed ? 0.34 : 0.1,
    roughness: 0.08,
    metalness: 0.14,
  });

  // Grounded sculpted cephalothorax (carapace) + pedicel waist + textured bulbous abdomen
  const cephalo = new THREE.Mesh(new THREE.SphereGeometry(0.23 * s, 12, 10), chitinMat);
  cephalo.scale.set(1.06, 0.68, 1.18);
  cephalo.position.set(0, 0.02 * s, 0.19 * s);
  cephalo.castShadow = true;
  cephalo.receiveShadow = true;
  bodyGroup.add(cephalo);

  const pedicel = new THREE.Mesh(new THREE.CylinderGeometry(0.075 * s, 0.085 * s, 0.12 * s, 8), darkJointMat);
  pedicel.rotation.x = Math.PI / 2;
  pedicel.position.set(0, 0.03 * s, -0.05 * s);
  bodyGroup.add(pedicel);

  const abdomen = new THREE.Mesh(new THREE.SphereGeometry(0.35 * s, 13, 11), chitinMat);
  abdomen.scale.set(1.02, 0.88, 1.34);
  abdomen.position.set(0, 0.11 * s, -0.37 * s);
  abdomen.castShadow = true;
  abdomen.receiveShadow = true;
  bodyGroup.add(abdomen);

  // Subtle paired silk spinnerets at rear tip of abdomen
  for (const side of [-1, 1]) {
    const spinneret = new THREE.Mesh(new THREE.ConeGeometry(0.024 * s, 0.095 * s, 6), darkJointMat);
    spinneret.rotation.x = -Math.PI * 0.56;
    spinneret.rotation.z = side * 0.22;
    spinneret.position.set(side * 0.048 * s, 0.04 * s, -0.82 * s);
    bodyGroup.add(spinneret);
  }

  const neckGroup = new THREE.Group();
  neckGroup.position.set(0, 0.015 * s, 0.39 * s);
  bodyGroup.add(neckGroup);

  const headGroup = new THREE.Group();
  neckGroup.add(headGroup);

  // Realistic clustered glossy arachnid eyes (2 large median eyes + 6 secondary eyes)
  const bigEyeGeo = new THREE.SphereGeometry(0.029 * s, 8, 7);
  const smallEyeGeo = new THREE.SphereGeometry(0.017 * s, 6, 5);
  for (const [ex, ey, ez, big] of [
    [-0.046, 0.044, 0.078, true],
    [0.046, 0.044, 0.078, true],
    [-0.105, 0.036, 0.042, false],
    [0.105, 0.036, 0.042, false],
    [-0.074, 0.078, 0.052, false],
    [0.074, 0.078, 0.052, false],
    [-0.026, 0.082, 0.072, false],
    [0.026, 0.082, 0.072, false],
  ] as Array<[number, number, number, boolean]>) {
    const eMesh = new THREE.Mesh(big ? bigEyeGeo : smallEyeGeo, eyeMat);
    eMesh.position.set(ex * s, ey * s, ez * s);
    headGroup.add(eMesh);
  }

  // Twin curved chelicerae + venomous fangs + segmented sensory pedipalps
  for (const side of [-1, 1]) {
    const chelicera = new THREE.Mesh(new THREE.CapsuleGeometry(0.042 * s, 0.075 * s, 4, 7), darkJointMat);
    chelicera.position.set(side * 0.062 * s, -0.025 * s, 0.088 * s);
    chelicera.rotation.x = 0.25;
    headGroup.add(chelicera);

    const fang = new THREE.Mesh(new THREE.ConeGeometry(0.022 * s, 0.135 * s, 6), fangMat);
    fang.rotation.x = Math.PI * 0.82;
    fang.rotation.z = -side * 0.26;
    fang.position.set(side * 0.056 * s, -0.095 * s, 0.112 * s);
    headGroup.add(fang);

    // Pedipalp (front feeler limb)
    const palpBase = new THREE.Mesh(new THREE.CapsuleGeometry(0.024 * s, 0.13 * s, 4, 6), chitinMat);
    palpBase.position.set(side * 0.14 * s, -0.01 * s, 0.11 * s);
    palpBase.rotation.set(0.62, side * 0.35, -side * 0.28);
    headGroup.add(palpBase);

    const palpTip = new THREE.Mesh(new THREE.CapsuleGeometry(0.018 * s, 0.11 * s, 4, 6), darkJointMat);
    palpTip.position.set(side * 0.175 * s, -0.09 * s, 0.2 * s);
    palpTip.rotation.set(0.18, side * 0.18, side * 0.15);
    headGroup.add(palpTip);
  }

  const collarGroup = new THREE.Group();
  collarGroup.visible = isTamed;
  const collarBand = new THREE.Mesh(
    new THREE.TorusGeometry(0.165 * s, 0.026 * s, 6, 14),
    new THREE.MeshStandardMaterial({ color: 0xb02226, roughness: 0.56 }),
  );
  collarBand.position.set(0, 0.04 * s, -0.05 * s);
  collarGroup.add(collarBand);
  bodyGroup.add(collarGroup);

  // 8 articulated multi-segment arachnid legs (coxa + rising femur + patella joint + tapered tibia/tarsus)
  const buildSpiderLeg = (side: -1 | 1, zOff: number, yawSpread: number, lengthMult: number) => {
    const pivot = new THREE.Group();
    pivot.position.set(side * 0.2 * s, 0.015 * s, zOff * s);
    pivot.rotation.y = yawSpread;
    bodyGroup.add(pivot);

    const coxa = new THREE.Mesh(new THREE.SphereGeometry(0.044 * s, 6, 6), darkJointMat);
    coxa.position.set(side * 0.04 * s, 0.01 * s, 0);
    pivot.add(coxa);

    // Rising femur
    const femurLen = 0.36 * s * lengthMult;
    const femur = new THREE.Mesh(new THREE.CapsuleGeometry(0.033 * s, femurLen, 4, 7), chitinMat);
    femur.position.set(side * 0.21 * s * lengthMult, 0.175 * s * lengthMult, 0);
    femur.rotation.z = side * 0.86;
    femur.castShadow = true;
    pivot.add(femur);

    // Patella knee joint
    const knee = new THREE.Mesh(new THREE.SphereGeometry(0.036 * s, 6, 6), darkJointMat);
    knee.position.set(side * 0.4 * s * lengthMult, 0.33 * s * lengthMult, 0);
    pivot.add(knee);

    // Descending slender tibia + metatarsus/tarsus claw tip
    const tibiaLen = 0.84 * s * lengthMult;
    const tibia = new THREE.Mesh(new THREE.CylinderGeometry(0.028 * s, 0.011 * s, tibiaLen, 6), chitinMat);
    tibia.position.set(side * 0.56 * s * lengthMult, -0.05 * s, 0);
    tibia.rotation.z = -side * 0.36;
    tibia.castShadow = true;
    pivot.add(tibia);

    return pivot;
  };

  const legZ = [0.28, 0.16, 0.04, -0.08];
  const legSpread = [0.5, 0.17, -0.18, -0.54];
  const legLens = [1.06, 0.96, 0.94, 1.08];
  const leftLegs: THREE.Group[] = [];
  const rightLegs: THREE.Group[] = [];
  for (let i = 0; i < 4; i++) {
    leftLegs.push(buildSpiderLeg(-1, legZ[i], legSpread[i], legLens[i]));
    rightLegs.push(buildSpiderLeg(1, legZ[i], -legSpread[i], legLens[i]));
  }

  const tailPivot = new THREE.Group();
  tailPivot.position.set(0, 0.11 * s, -0.8 * s);
  bodyGroup.add(tailPivot);

  const overlays = attachAnimalOverlays(root, s, 1.25, 1.15, 1.26 * s, meta.subdueRatio);
  return {
    root,
    bodyGroup,
    neckGroup,
    headGroup,
    frontLeftLeg: leftLegs[0],
    frontRightLeg: rightLegs[0],
    backLeftLeg: leftLegs[3],
    backRightLeg: rightLegs[3],
    extraLegs: [leftLegs[1], rightLegs[1], leftLegs[2], rightLegs[2]],
    tailPivot,
    collarGroup,
    eyeMaterials: [eyeMat],
    flashMaterials,
    baseEmissives,
    ...overlays,
    bodyPlan: 'spider',
  };
}

function buildGorillaRig(meta: WildAnimalSpeciesMeta, isTamed: boolean): AnimalRig {
  const s = meta.bodyScale;
  const root = new THREE.Group();
  const bodyGroup = new THREE.Group();
  bodyGroup.position.set(0, 0.78 * s, 0);
  root.add(bodyGroup);

  const flashMaterials: THREE.MeshStandardMaterial[] = [];
  const baseEmissives: THREE.Color[] = [];
  const reg = (mat: THREE.MeshStandardMaterial) => {
    flashMaterials.push(mat);
    baseEmissives.push(mat.emissive.clone());
    return mat;
  };
  const tex = getAnimalTextureSet(meta.species);
  const darkFur = reg(
    new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: tex.coatMap,
      bumpMap: tex.bumpMap,
      bumpScale: 0.06,
      roughness: 0.92,
      metalness: 0.01,
    }),
  );
  const silverBackMat = reg(
    new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: tex.accentMap ?? tex.coatMap,
      bumpMap: tex.bumpMap,
      bumpScale: 0.052,
      roughness: 0.9,
      metalness: 0.02,
    }),
  );
  const faceSkinMat = reg(
    new THREE.MeshStandardMaterial({
      color: 0x1d1a1a,
      bumpMap: tex.skinBumpMap ?? tex.bumpMap,
      bumpScale: 0.042,
      roughness: 0.68,
      metalness: 0.03,
    }),
  );
  const eyeMat = new THREE.MeshStandardMaterial({
    color: isTamed ? 0x45cca8 : meta.eyeHex,
    emissive: isTamed ? 0x157d66 : meta.eyeHex,
    emissiveIntensity: isTamed ? 0.34 : 0.07,
    roughness: 0.1,
    metalness: 0.1,
  });
  const pupilMat = new THREE.MeshStandardMaterial({
    color: 0x0a0908,
    roughness: 0.06,
  });

  // Broad hunched gorilla barrel chest + bare leathery pectoral plate + silverback saddle
  const chest = new THREE.Mesh(new THREE.CapsuleGeometry(0.31 * s, 0.36 * s, 7, 12), darkFur);
  chest.rotation.x = 0.78;
  chest.scale.set(1.2, 1.0, 1.08);
  chest.position.set(0, 0.22 * s, 0.14 * s);
  chest.castShadow = true;
  chest.receiveShadow = true;
  bodyGroup.add(chest);

  // Subtle bare dark leathery pectoral chest patch (anatomical silverback detail)
  const pecPatch = new THREE.Mesh(new THREE.SphereGeometry(0.19 * s, 9, 8), faceSkinMat);
  pecPatch.scale.set(1.22, 0.92, 0.45);
  pecPatch.position.set(0, 0.2 * s, 0.41 * s);
  bodyGroup.add(pecPatch);

  // Frosted silverback upper-back mantle & trapezius slope
  const silverMantle = new THREE.Mesh(new THREE.SphereGeometry(0.3 * s, 11, 9), silverBackMat);
  silverMantle.scale.set(1.16, 0.76, 1.28);
  silverMantle.position.set(0, 0.31 * s, -0.07 * s);
  silverMantle.castShadow = true;
  silverMantle.receiveShadow = true;
  bodyGroup.add(silverMantle);

  const hips = new THREE.Mesh(new THREE.SphereGeometry(0.24 * s, 10, 8), darkFur);
  hips.scale.set(1.08, 0.94, 1.02);
  hips.position.set(0, -0.08 * s, -0.24 * s);
  hips.castShadow = true;
  bodyGroup.add(hips);

  const neckGroup = new THREE.Group();
  neckGroup.position.set(0, 0.44 * s, 0.3 * s);
  bodyGroup.add(neckGroup);

  // Thick muscular trapezius neck hump connecting shoulders to skull
  const trapHump = new THREE.Mesh(new THREE.SphereGeometry(0.22 * s, 9, 8), darkFur);
  trapHump.scale.set(1.15, 0.75, 0.96);
  trapHump.position.set(0, -0.04 * s, -0.08 * s);
  neckGroup.add(trapHump);

  const collarGroup = new THREE.Group();
  collarGroup.visible = isTamed;
  const collarBand = new THREE.Mesh(
    new THREE.TorusGeometry(0.22 * s, 0.036 * s, 7, 16),
    new THREE.MeshStandardMaterial({ color: 0xb02226, roughness: 0.56 }),
  );
  collarBand.rotation.x = Math.PI / 2 - 0.35;
  collarGroup.add(collarBand);
  neckGroup.add(collarGroup);

  const headGroup = new THREE.Group();
  headGroup.position.set(0, 0.13 * s, 0.08 * s);
  neckGroup.add(headGroup);

  // Sculpted silverback cranium with sagittal crest, heavy brow ridge, flattened nose & prognathous jaw
  const skull = new THREE.Mesh(new THREE.SphereGeometry(0.19 * s, 12, 10), darkFur);
  skull.scale.set(1.04, 1.1, 1.06);
  skull.castShadow = true;
  headGroup.add(skull);

  const crest = new THREE.Mesh(new THREE.SphereGeometry(0.112 * s, 9, 7), darkFur);
  crest.scale.set(0.68, 0.88, 1.18);
  crest.position.set(0, 0.165 * s, -0.035 * s);
  headGroup.add(crest);

  // Heavy protruding supraorbital brow ridge casting realistic shade over recessed eyes
  const brow = new THREE.Mesh(new THREE.CapsuleGeometry(0.046 * s, 0.175 * s, 5, 9), faceSkinMat);
  brow.rotation.z = Math.PI / 2;
  brow.scale.set(1.0, 0.82, 1.15);
  brow.position.set(0, 0.064 * s, 0.158 * s);
  headGroup.add(brow);

  // Broad flattened gorilla nose bridge + twin nostrils
  const nosePad = new THREE.Mesh(new THREE.SphereGeometry(0.056 * s, 8, 7), faceSkinMat);
  nosePad.scale.set(1.38, 0.72, 0.78);
  nosePad.position.set(0, -0.012 * s, 0.215 * s);
  headGroup.add(nosePad);

  const nostrilGeo = new THREE.SphereGeometry(0.014 * s, 5, 5);
  for (const side of [-1, 1]) {
    const nostril = new THREE.Mesh(nostrilGeo, pupilMat);
    nostril.position.set(side * 0.03 * s, -0.02 * s, 0.252 * s);
    headGroup.add(nostril);
  }

  // Muscular prognathous jaw & chin
  const faceJaw = new THREE.Mesh(new THREE.SphereGeometry(0.128 * s, 10, 8), faceSkinMat);
  faceJaw.scale.set(1.06, 0.88, 1.12);
  faceJaw.position.set(0, -0.072 * s, 0.145 * s);
  headGroup.add(faceJaw);

  for (const side of [-1, 1]) {
    // Deep-set natural eyes tucked under the brow ridge
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.021 * s, 8, 7), eyeMat);
    eye.position.set(side * 0.056 * s, 0.028 * s, 0.176 * s);
    headGroup.add(eye);

    const pupil = new THREE.Mesh(new THREE.SphereGeometry(0.011 * s, 6, 6), pupilMat);
    pupil.position.set(side * 0.056 * s, 0.028 * s, 0.193 * s);
    headGroup.add(pupil);

    const ear = new THREE.Mesh(new THREE.SphereGeometry(0.044 * s, 6, 6), faceSkinMat);
    ear.scale.set(0.42, 0.92, 0.78);
    ear.position.set(side * 0.188 * s, 0.018 * s, -0.005 * s);
    headGroup.add(ear);
  }

  // Huge muscular knuckle-walking arms with sculpted deltoids and leathery knuckles
  const buildArm = (side: -1 | 1) => {
    const pivot = new THREE.Group();
    pivot.position.set(side * 0.37 * s, 0.32 * s, 0.21 * s);
    bodyGroup.add(pivot);

    const deltoid = new THREE.Mesh(new THREE.SphereGeometry(0.155 * s, 9, 8), darkFur);
    deltoid.scale.set(1.05, 0.95, 1.05);
    deltoid.position.set(side * 0.01 * s, 0.0, 0.01 * s);
    deltoid.castShadow = true;
    pivot.add(deltoid);

    const upper = new THREE.Mesh(new THREE.CapsuleGeometry(0.128 * s, 0.37 * s, 6, 10), darkFur);
    upper.position.set(side * 0.045 * s, -0.23 * s, 0.04 * s);
    upper.rotation.z = -side * 0.11;
    upper.castShadow = true;
    pivot.add(upper);

    const forearm = new THREE.Mesh(new THREE.CapsuleGeometry(0.12 * s, 0.42 * s, 6, 10), darkFur);
    forearm.position.set(side * 0.055 * s, -0.66 * s, 0.075 * s);
    forearm.castShadow = true;
    pivot.add(forearm);

    const fist = new THREE.Mesh(new THREE.SphereGeometry(0.122 * s, 9, 8), faceSkinMat);
    fist.scale.set(1.08, 0.76, 1.22);
    fist.position.set(side * 0.055 * s, -0.98 * s, 0.115 * s);
    fist.castShadow = true;
    pivot.add(fist);
    return pivot;
  };

  // Stout muscular gorilla hind legs
  const buildHindLeg = (side: -1 | 1) => {
    const pivot = new THREE.Group();
    pivot.position.set(side * 0.22 * s, -0.14 * s, -0.24 * s);
    bodyGroup.add(pivot);

    const thigh = new THREE.Mesh(new THREE.CapsuleGeometry(0.118 * s, 0.24 * s, 5, 9), darkFur);
    thigh.position.set(0, -0.18 * s, 0.02 * s);
    thigh.castShadow = true;
    pivot.add(thigh);

    const shin = new THREE.Mesh(new THREE.CapsuleGeometry(0.094 * s, 0.24 * s, 5, 8), darkFur);
    shin.position.set(0, -0.44 * s, -0.02 * s);
    shin.castShadow = true;
    pivot.add(shin);

    const foot = new THREE.Mesh(new THREE.SphereGeometry(0.098 * s, 8, 7), faceSkinMat);
    foot.scale.set(1.06, 0.5, 1.38);
    foot.position.set(0, -0.6 * s, 0.05 * s);
    pivot.add(foot);
    return pivot;
  };

  const frontLeftLeg = buildArm(-1);
  const frontRightLeg = buildArm(1);
  const backLeftLeg = buildHindLeg(-1);
  const backRightLeg = buildHindLeg(1);
  const tailPivot = new THREE.Group();
  bodyGroup.add(tailPivot);

  const overlays = attachAnimalOverlays(root, s, 1.25, 1.05, 1.82 * s, meta.subdueRatio);
  return {
    root,
    bodyGroup,
    neckGroup,
    headGroup,
    frontLeftLeg,
    frontRightLeg,
    backLeftLeg,
    backRightLeg,
    tailPivot,
    collarGroup,
    eyeMaterials: [eyeMat],
    flashMaterials,
    baseEmissives,
    ...overlays,
    bodyPlan: 'gorilla',
  };
}

export function buildAnimalRig(species: WildAnimalSpecies, isTamed = false): AnimalRig {
  const meta = WILD_ANIMAL_CATALOG[species];
  if (species === 'ajagar_python') return buildPythonRig(meta, isTamed);
  if (species === 'giant_spider') return buildSpiderRig(meta, isTamed);
  if (species === 'gorilla_king') return buildGorillaRig(meta, isTamed);

  const s = meta.bodyScale;
  const isTiger = species === 'sundarban_tiger';
  const isLion = species === 'lion_king';
  const isBoar = species === 'wild_boar';
  const isBear = species === 'bengal_bear';
  const isLeopard = species === 'bengal_leopard';
  const isHound = species === 'village_hound';

  // Species-specific organic silhouette ratios
  const widthRatio = isBear
    ? 1.26
    : isBoar
      ? 1.14
      : isLion
        ? 1.12
        : isTiger
          ? 1.06
          : isLeopard
            ? 0.86
            : 0.84;
  const lengthRatio = isBoar
    ? 0.88
    : isBear
      ? 0.98
      : isLion
        ? 1.06
        : isTiger
          ? 1.04
          : isLeopard
            ? 1.12
            : 0.96;
  const legLengthRatio = isBoar
    ? 0.78
    : isBear
      ? 0.88
      : isLion
        ? 1.0
        : isTiger
          ? 0.98
          : isLeopard
            ? 1.05
            : 1.02;

  const root = new THREE.Group();
  const bodyGroup = new THREE.Group();
  bodyGroup.position.set(0, 0.65 * s * legLengthRatio, 0);
  root.add(bodyGroup);

  const flashMaterials: THREE.MeshStandardMaterial[] = [];
  const baseEmissives: THREE.Color[] = [];
  const registerFlashMat = (mat: THREE.MeshStandardMaterial) => {
    flashMaterials.push(mat);
    baseEmissives.push(mat.emissive.clone());
    return mat;
  };

  const tex = getAnimalTextureSet(species);

  // Semi-realistic PBR Materials with cached procedural species fur maps & micro-relief bump
  const coatMat = registerFlashMat(
    new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: tex.coatMap,
      bumpMap: tex.bumpMap,
      bumpScale: isBear || isBoar ? 0.058 : 0.048,
      roughness: isBear || isBoar ? 0.93 : 0.89,
      metalness: 0.01,
    }),
  );
  const bellyMat = registerFlashMat(
    new THREE.MeshStandardMaterial({
      color: meta.bellyHex,
      bumpMap: tex.bumpMap,
      bumpScale: 0.032,
      roughness: 0.91,
      metalness: 0.01,
    }),
  );
  const markingMat = registerFlashMat(
    new THREE.MeshStandardMaterial({
      color: isLion && tex.accentMap ? 0xffffff : meta.markingHex,
      map: isLion && tex.accentMap ? tex.accentMap : null,
      bumpMap: tex.bumpMap,
      bumpScale: isLion ? 0.056 : 0.038,
      roughness: 0.91,
      metalness: 0.01,
    }),
  );
  const innerEarMat = new THREE.MeshStandardMaterial({
    color: isHound || isBoar ? 0x8a5f52 : 0xb08f7b,
    roughness: 0.86,
    metalness: 0.01,
  });
  const noseMat = new THREE.MeshStandardMaterial({
    color: isBoar ? 0x4f3a36 : isTiger || isLion ? 0x261918 : 0x141111,
    roughness: 0.34,
    metalness: 0.06,
  });
  const eyeMat = new THREE.MeshStandardMaterial({
    color: isTamed ? 0x45cca8 : meta.eyeHex,
    emissive: isTamed ? 0x157d66 : meta.eyeHex,
    emissiveIntensity: isTamed ? 0.34 : 0.08,
    roughness: 0.08,
    metalness: 0.1,
  });
  const pupilMat = new THREE.MeshStandardMaterial({
    color: 0x0a0807,
    roughness: 0.06,
    metalness: 0.06,
  });
  const clawMat = new THREE.MeshStandardMaterial({
    color: isBoar ? 0x26201c : isBear ? 0x3b3129 : 0xdccfb9,
    roughness: 0.42,
    metalness: 0.06,
  });
  const tuskMat = new THREE.MeshStandardMaterial({
    color: 0xe6dbc4,
    roughness: 0.34,
    metalness: 0.05,
  });

  // =========================================================================
  // 1. SCULPTED ORGANIC TORSO (Deep Ribcage + Tapered Waist + Muscular Rump)
  // =========================================================================
  const torsoGroup = new THREE.Group();
  torsoGroup.scale.set(widthRatio, 1, lengthRatio);
  bodyGroup.add(torsoGroup);

  // Broad muscular front ribcage (horizontal rounded capsule)
  const ribcage = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.225 * s, 0.34 * s, 7, 14),
    coatMat,
  );
  ribcage.rotation.x = Math.PI / 2;
  ribcage.scale.set(1.04, 1.0, 1.08);
  ribcage.position.set(0, 0.04 * s, 0.2 * s);
  ribcage.castShadow = true;
  ribcage.receiveShadow = true;
  torsoGroup.add(ribcage);

  // Sculpted shoulder blades / withers hump
  const withers = new THREE.Mesh(new THREE.SphereGeometry(0.195 * s, 12, 10), coatMat);
  withers.scale.set(1.05, 0.92, 1.15);
  withers.position.set(0, 0.12 * s, 0.31 * s);
  withers.castShadow = true;
  torsoGroup.add(withers);

  // Tapered athletic mid-torso / waist (tucked up higher on hound & leopard)
  const waistRadiusBack = isHound ? 0.145 * s : isLeopard ? 0.16 * s : 0.178 * s;
  const waist = new THREE.Mesh(
    new THREE.CylinderGeometry(waistRadiusBack, 0.215 * s, 0.42 * s, 12),
    coatMat,
  );
  waist.rotation.x = Math.PI / 2;
  waist.position.set(0, (isHound ? 0.045 : 0.025) * s, -0.05 * s);
  waist.castShadow = true;
  waist.receiveShadow = true;
  torsoGroup.add(waist);

  // Muscular rounded hindquarters / pelvis
  const pelvis = new THREE.Mesh(new THREE.SphereGeometry(0.215 * s, 12, 10), coatMat);
  pelvis.scale.set(0.98, 0.96, 1.24);
  pelvis.position.set(0, 0.03 * s, -0.32 * s);
  pelvis.castShadow = true;
  pelvis.receiveShadow = true;
  torsoGroup.add(pelvis);

  // Soft pale chest & underbelly contour
  const chestFront = new THREE.Mesh(new THREE.SphereGeometry(0.185 * s, 10, 9), bellyMat);
  chestFront.scale.set(0.9, 1.02, 0.95);
  chestFront.position.set(0, -0.04 * s, 0.38 * s);
  torsoGroup.add(chestFront);

  const bellyContour = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.135 * s, 0.56 * s, 6, 10),
    bellyMat,
  );
  bellyContour.rotation.x = Math.PI / 2;
  bellyContour.position.set(0, -0.095 * s, 0.02 * s);
  torsoGroup.add(bellyContour);

  // =========================================================================
  // 2. SPECIES-DISTINCT STRUCTURAL COAT FEATURES (Tiger/Leopard markings are
  //    handled cleanly by seamless procedural fur textures — zero floating rings!)
  // =========================================================================
  if (isBoar) {
    // Wild Boar coarse bristled dorsal crest along spine
    const crest = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.06 * s, 0.62 * s, 5, 8),
      markingMat,
    );
    crest.rotation.x = Math.PI / 2;
    crest.scale.set(0.48, 1.0, 1.38);
    crest.position.set(0, 0.235 * s, 0.06 * s);
    torsoGroup.add(crest);
  } else if (isBear) {
    // Bengal / Himalayan Bear cream V-shaped chest crescent & heavy shoulder hump
    const bearHump = new THREE.Mesh(new THREE.SphereGeometry(0.21 * s, 10, 8), coatMat);
    bearHump.scale.set(1.06, 0.85, 1.15);
    bearHump.position.set(0, 0.175 * s, 0.26 * s);
    bearHump.castShadow = true;
    torsoGroup.add(bearHump);

    const crescent = new THREE.Mesh(
      new THREE.TorusGeometry(0.14 * s, 0.032 * s, 6, 12, Math.PI * 0.86),
      bellyMat,
    );
    crescent.rotation.z = Math.PI * 1.07;
    crescent.position.set(0, 0.01 * s, 0.43 * s);
    torsoGroup.add(crescent);
  } else if (isLion) {
    // Lion King sculpted shaggy shoulder cape & deep chest mane foundation
    const shoulderCape = new THREE.Mesh(new THREE.SphereGeometry(0.275 * s, 11, 9), markingMat);
    shoulderCape.scale.set(1.08, 1.06, 1.05);
    shoulderCape.position.set(0, 0.11 * s, 0.36 * s);
    shoulderCape.castShadow = true;
    torsoGroup.add(shoulderCape);

    const chestMane = new THREE.Mesh(new THREE.ConeGeometry(0.185 * s, 0.34 * s, 9), markingMat);
    chestMane.rotation.x = Math.PI + 0.26;
    chestMane.scale.set(1.05, 1.0, 0.78);
    chestMane.position.set(0, -0.06 * s, 0.43 * s);
    chestMane.castShadow = true;
    torsoGroup.add(chestMane);
  } else if (isHound) {
    // Guard Hound dark back saddle
    const saddle = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.175 * s, 0.42 * s, 6, 11),
      markingMat,
    );
    saddle.rotation.x = Math.PI / 2;
    saddle.scale.set(1.01, 1, 0.6);
    saddle.position.set(0, 0.14 * s, -0.02 * s);
    torsoGroup.add(saddle);
  }

  // =========================================================================
  // 3. SCULPTED NECK, WARRIOR GAMCHA COLLAR & SPECIES-AUTHENTIC HEAD
  // =========================================================================
  const neckGroup = new THREE.Group();
  neckGroup.position.set(0, 0.13 * s, 0.43 * s * lengthRatio);
  bodyGroup.add(neckGroup);

  const neckTopR = isTiger ? 0.15 * s : isLeopard ? 0.122 * s : 0.118 * s;
  const neckBotR = isTiger ? 0.195 * s : isLeopard ? 0.158 * s : 0.155 * s;
  const neckLen = isHound ? 0.34 * s : isLeopard ? 0.31 * s : 0.28 * s;
  const neck = new THREE.Mesh(
    new THREE.CylinderGeometry(neckTopR, neckBotR, neckLen, 12),
    coatMat,
  );
  neck.position.set(0, 0.07 * s, 0.08 * s);
  neck.rotation.x = isHound ? 0.56 : 0.72;
  neck.castShadow = true;
  neckGroup.add(neck);

  // Cream throat underside
  const throat = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.085 * s, 0.16 * s, 5, 8),
    bellyMat,
  );
  throat.position.set(0, -0.01 * s, 0.11 * s);
  throat.rotation.x = 0.68;
  neckGroup.add(throat);

  // Traditional Bengali Red-and-Gold Warrior Gamcha Collar (revealed once permanently tamed!)
  const collarGroup = new THREE.Group();
  collarGroup.position.set(0, 0.06 * s, 0.08 * s);
  collarGroup.visible = isTamed;
  neckGroup.add(collarGroup);

  const collarBandMat = new THREE.MeshStandardMaterial({
    color: 0xc81e24,
    roughness: 0.52,
    metalness: 0.08,
  });
  const collarGoldMat = new THREE.MeshStandardMaterial({
    color: 0xffcf48,
    emissive: 0x7c4b00,
    emissiveIntensity: 0.35,
    roughness: 0.22,
    metalness: 0.86,
  });
  const collarBand = new THREE.Mesh(
    new THREE.TorusGeometry((neckBotR + neckTopR) * 0.52, 0.038 * s, 8, 18),
    collarBandMat,
  );
  collarBand.rotation.x = Math.PI / 2 - 0.55;
  collarGroup.add(collarBand);

  const collarMedallion = new THREE.Mesh(
    new THREE.SphereGeometry(0.048 * s, 10, 8),
    collarGoldMat,
  );
  collarMedallion.position.set(0, -0.11 * s, 0.15 * s);
  collarGroup.add(collarMedallion);

  const collarSash = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.025 * s, 0.16 * s, 4, 8),
    collarBandMat,
  );
  collarSash.position.set(0.09 * s, -0.08 * s, -0.08 * s);
  collarSash.rotation.set(-0.6, 0, -0.45);
  collarGroup.add(collarSash);

  // Head pivot
  const headGroup = new THREE.Group();
  headGroup.position.set(0, (isHound ? 0.2 : 0.16) * s, (isHound ? 0.18 : 0.21) * s);
  neckGroup.add(headGroup);

  // Sculpted Cranium
  const cranium = new THREE.Mesh(new THREE.SphereGeometry(0.185 * s, 14, 12), coatMat);
  if (isTiger) {
    cranium.scale.set(1.12, 0.96, 1.05);
  } else if (isLeopard) {
    cranium.scale.set(0.94, 0.88, 1.04);
  } else {
    cranium.scale.set(0.86, 0.88, 1.1);
  }
  cranium.castShadow = true;
  headGroup.add(cranium);

  if (isBoar) {
    // Elongated sloping boar head + flat snout disc + twin curved ivory tusks
    const boarSnout = new THREE.Mesh(
      new THREE.CylinderGeometry(0.072 * s, 0.135 * s, 0.28 * s, 10),
      coatMat,
    );
    boarSnout.rotation.x = Math.PI / 2 + 0.16;
    boarSnout.position.set(0, -0.055 * s, 0.21 * s);
    boarSnout.castShadow = true;
    headGroup.add(boarSnout);

    const snoutDisc = new THREE.Mesh(new THREE.CylinderGeometry(0.076 * s, 0.076 * s, 0.04 * s, 10), noseMat);
    snoutDisc.rotation.x = Math.PI / 2;
    snoutDisc.position.set(0, -0.08 * s, 0.355 * s);
    headGroup.add(snoutDisc);

    // Twin curved ivory war tusks curving upward from snout cheeks
    const tuskGeo = new THREE.ConeGeometry(0.023 * s, 0.18 * s, 6);
    for (const side of [-1, 1]) {
      const tusk = new THREE.Mesh(tuskGeo, tuskMat);
      tusk.position.set(side * 0.095 * s, -0.05 * s, 0.26 * s);
      tusk.rotation.set(0.28, 0, -side * 0.48);
      headGroup.add(tusk);

      const ear = new THREE.Mesh(new THREE.ConeGeometry(0.055 * s, 0.13 * s, 6), markingMat);
      ear.position.set(side * 0.13 * s, 0.15 * s, -0.02 * s);
      ear.rotation.z = -side * 0.32;
      headGroup.add(ear);
    }
  } else if (isBear) {
    // Broad blunt bear snout + thick muzzle + rounded ears
    const bearMuzzle = new THREE.Mesh(
      new THREE.CylinderGeometry(0.078 * s, 0.125 * s, 0.2 * s, 10),
      bellyMat,
    );
    bearMuzzle.rotation.x = Math.PI / 2;
    bearMuzzle.position.set(0, -0.04 * s, 0.19 * s);
    bearMuzzle.castShadow = true;
    headGroup.add(bearMuzzle);

    const nose = new THREE.Mesh(new THREE.SphereGeometry(0.048 * s, 8, 8), noseMat);
    nose.scale.set(1.2, 0.85, 0.8);
    nose.position.set(0, -0.02 * s, 0.3 * s);
    headGroup.add(nose);

    const bearEarGeo = new THREE.SphereGeometry(0.068 * s, 8, 7);
    for (const side of [-1, 1]) {
      const ear = new THREE.Mesh(bearEarGeo, coatMat);
      ear.scale.set(0.95, 0.95, 0.45);
      ear.position.set(side * 0.155 * s, 0.155 * s, -0.02 * s);
      headGroup.add(ear);
    }
  } else if (isHound) {
    // Distinct tapered canine muzzle + nasal bridge + lower jaw
    const muzzle = new THREE.Mesh(
      new THREE.CylinderGeometry(0.068 * s, 0.11 * s, 0.24 * s, 10),
      coatMat,
    );
    muzzle.rotation.x = Math.PI / 2;
    muzzle.position.set(0, -0.03 * s, 0.21 * s);
    muzzle.castShadow = true;
    headGroup.add(muzzle);

    const muzzleTip = new THREE.Mesh(new THREE.SphereGeometry(0.072 * s, 10, 8), bellyMat);
    muzzleTip.scale.set(1.0, 0.82, 0.9);
    muzzleTip.position.set(0, -0.04 * s, 0.31 * s);
    headGroup.add(muzzleTip);

    const lowerJaw = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.048 * s, 0.14 * s, 5, 8),
      bellyMat,
    );
    lowerJaw.rotation.x = Math.PI / 2;
    lowerJaw.position.set(0, -0.095 * s, 0.19 * s);
    headGroup.add(lowerJaw);

    const nose = new THREE.Mesh(new THREE.SphereGeometry(0.042 * s, 8, 8), noseMat);
    nose.scale.set(1.15, 0.82, 0.78);
    nose.position.set(0, -0.015 * s, 0.35 * s);
    headGroup.add(nose);

    // Tall pointed alert guard-dog ears with warm inner ear cones
    const outerEarGeo = new THREE.ConeGeometry(0.068 * s, 0.19 * s, 7);
    const innerEarGeo = new THREE.ConeGeometry(0.042 * s, 0.14 * s, 6);
    for (const side of [-1, 1]) {
      const earPivot = new THREE.Group();
      earPivot.position.set(side * 0.1 * s, 0.14 * s, -0.01 * s);
      earPivot.rotation.set(0.16, side * 0.12, -side * 0.18);
      const outerEar = new THREE.Mesh(outerEarGeo, markingMat);
      outerEar.position.y = 0.08 * s;
      earPivot.add(outerEar);
      const innerEar = new THREE.Mesh(innerEarGeo, innerEarMat);
      innerEar.position.set(0, 0.075 * s, 0.022 * s);
      earPivot.add(innerEar);
      headGroup.add(earPivot);
    }
  } else {
    // Sculpted Big-Cat Feline Head (Tiger, Lion King & Leopard)
    const muzzleBridge = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.085 * s, 0.12 * s, 6, 10),
      coatMat,
    );
    muzzleBridge.rotation.x = Math.PI / 2;
    muzzleBridge.scale.set(1.06, 0.88, 1);
    muzzleBridge.position.set(0, -0.025 * s, 0.17 * s);
    muzzleBridge.castShadow = true;
    headGroup.add(muzzleBridge);

    // Twin whisker/muzzle pads (signature feline silhouette)
    const padGeo = new THREE.SphereGeometry(0.064 * s, 9, 8);
    for (const side of [-1, 1]) {
      const pad = new THREE.Mesh(padGeo, bellyMat);
      pad.scale.set(0.95, 0.86, 1.05);
      pad.position.set(side * 0.056 * s, -0.06 * s, 0.225 * s);
      headGroup.add(pad);
    }

    // Chin / lower jaw
    const chin = new THREE.Mesh(new THREE.SphereGeometry(0.062 * s, 8, 8), bellyMat);
    chin.scale.set(1.05, 0.72, 1.15);
    chin.position.set(0, -0.105 * s, 0.185 * s);
    headGroup.add(chin);

    // Wide feline nose
    const nose = new THREE.Mesh(new THREE.SphereGeometry(0.044 * s, 8, 8), noseMat);
    nose.scale.set(1.25, 0.78, 0.72);
    nose.position.set(0, -0.02 * s, 0.27 * s);
    headGroup.add(nose);

    if (isLion) {
      // Sculpted layered shaggy Lion King mane (organic swept-back locks framing crown, cheeks & jaw)
      const maneCrown = new THREE.Mesh(new THREE.SphereGeometry(0.235 * s, 11, 9), markingMat);
      maneCrown.scale.set(1.12, 1.12, 1.02);
      maneCrown.position.set(0, 0.04 * s, -0.095 * s);
      maneCrown.castShadow = true;
      headGroup.add(maneCrown);

      const tuftGeo = new THREE.ConeGeometry(0.092 * s, 0.26 * s, 7);
      const maneTuftCount = 10;
      for (let t = 0; t < maneTuftCount; t++) {
        const ang = (t / maneTuftCount) * Math.PI * 2;
        const radX = 0.215 * s;
        const radY = 0.225 * s;
        const tuft = new THREE.Mesh(tuftGeo, markingMat);
        tuft.position.set(Math.sin(ang) * radX, Math.cos(ang) * radY + 0.01 * s, -0.075 * s);
        // Sweep locks backward along the neck & shoulders for a natural feline silhouette
        tuft.rotation.set(-Math.PI * 0.44 + Math.cos(ang) * 0.24, 0, -ang);
        tuft.scale.set(1.05, 1.0 + (t % 2) * 0.14, 0.72);
        tuft.castShadow = true;
        headGroup.add(tuft);
      }

      const throatBeard = new THREE.Mesh(new THREE.ConeGeometry(0.115 * s, 0.24 * s, 7), markingMat);
      throatBeard.rotation.x = Math.PI - 0.35;
      throatBeard.position.set(0, -0.18 * s, 0.04 * s);
      headGroup.add(throatBeard);
    } else if (isTiger) {
      // Sculpted pale-cream Sundarbans tiger cheek ruffs
      const ruffGeo = new THREE.SphereGeometry(0.095 * s, 9, 8);
      for (const side of [-1, 1]) {
        const ruff = new THREE.Mesh(ruffGeo, bellyMat);
        ruff.scale.set(0.84, 0.9, 0.7);
        ruff.position.set(side * 0.168 * s, -0.048 * s, 0.028 * s);
        headGroup.add(ruff);
      }
    }

    // Rounded big-cat ears with cream inner ear
    const catEarGeo = new THREE.SphereGeometry(0.066 * s, 9, 8);
    const catInnerGeo = new THREE.SphereGeometry(0.042 * s, 7, 7);
    for (const side of [-1, 1]) {
      const ear = new THREE.Mesh(catEarGeo, isLion ? coatMat : markingMat);
      ear.scale.set(0.95, 1.0, 0.45);
      ear.position.set(side * 0.145 * s, 0.155 * s, -0.025 * s);
      ear.rotation.z = -side * 0.24;
      headGroup.add(ear);

      const earInner = new THREE.Mesh(catInnerGeo, innerEarMat);
      earInner.scale.set(0.88, 0.9, 0.34);
      earInner.position.set(side * 0.14 * s, 0.15 * s, -0.005 * s);
      earInner.rotation.z = -side * 0.24;
      headGroup.add(earInner);
    }
  }

  // Sculpted natural brow ridges + glossy eyes with dark slit/round pupils
  const eyeGeo = new THREE.SphereGeometry(0.029 * s, 10, 8);
  const pupilGeo = new THREE.SphereGeometry(0.015 * s, 7, 7);
  const browRidgeGeo = new THREE.CapsuleGeometry(0.018 * s, 0.056 * s, 4, 6);
  const eyeX = isTiger || isLion ? 0.092 : isLeopard ? 0.08 : 0.072;
  const eyeZ = isHound ? 0.145 : 0.154;
  for (const side of [-1, 1]) {
    const browRidge = new THREE.Mesh(browRidgeGeo, coatMat);
    browRidge.rotation.z = Math.PI / 2 - side * 0.24;
    browRidge.position.set(side * eyeX * s, 0.074 * s, (eyeZ - 0.008) * s);
    headGroup.add(browRidge);

    const eye = new THREE.Mesh(eyeGeo, eyeMat);
    eye.position.set(side * eyeX * s, 0.042 * s, eyeZ * s);
    headGroup.add(eye);

    const pupil = new THREE.Mesh(pupilGeo, pupilMat);
    pupil.scale.set(isHound || isBear || isBoar ? 1 : 0.56, 1.08, 0.7);
    pupil.position.set(side * eyeX * s, 0.042 * s, (eyeZ + 0.02) * s);
    headGroup.add(pupil);
  }

  // =========================================================================
  // 4. FOUR ARTICULATED ORGANIC QUADRUPED LIMBS (Thigh + Joint + Shin + Paw)
  // =========================================================================
  const buildLeg = (xPos: number, zPos: number, isBack: boolean) => {
    const pivot = new THREE.Group();
    pivot.position.set(xPos, -0.06 * s, zPos);
    bodyGroup.add(pivot);

    const upperR = (isBack ? 0.088 : 0.078) * s * (isTiger ? 1.08 : 0.92);
    const upperLen = 0.24 * s * legLengthRatio;
    const upper = new THREE.Mesh(
      new THREE.CapsuleGeometry(upperR, upperLen, 6, 10),
      coatMat,
    );
    upper.position.set(0, -upperLen * 0.52, isBack ? -0.02 * s : 0.01 * s);
    upper.rotation.x = isBack ? 0.24 : -0.08;
    upper.castShadow = true;
    pivot.add(upper);

    // Knee / Hock rounded joint
    const jointY = -upperLen * 1.06;
    const jointZ = isBack ? -0.055 * s : 0.02 * s;
    const joint = new THREE.Mesh(
      new THREE.SphereGeometry(upperR * 0.76, 8, 8),
      coatMat,
    );
    joint.position.set(0, jointY, jointZ);
    pivot.add(joint);

    // Tapered muscular lower shin
    const lowerLen = 0.26 * s * legLengthRatio;
    const lower = new THREE.Mesh(
      new THREE.CylinderGeometry(upperR * 0.68, upperR * 0.54, lowerLen, 9),
      isHound ? bellyMat : coatMat,
    );
    lower.position.set(0, jointY - lowerLen * 0.48, jointZ + (isBack ? 0.045 * s : 0.005 * s));
    lower.rotation.x = isBack ? -0.22 : 0.06;
    lower.castShadow = true;
    pivot.add(lower);

    // Sculpted rounded paw (or cloven dark hooves for Wild Boar)
    const pawY = jointY - lowerLen - 0.015 * s;
    const pawZ = jointZ + (isBack ? 0.085 * s : 0.038 * s);
    if (isBoar) {
      const hoof = new THREE.Mesh(
        new THREE.CylinderGeometry(upperR * 0.56, upperR * 0.68, 0.08 * s, 8),
        clawMat,
      );
      hoof.position.set(0, pawY - 0.01 * s, pawZ);
      hoof.castShadow = true;
      pivot.add(hoof);
    } else {
      const paw = new THREE.Mesh(
        new THREE.SphereGeometry(upperR * 0.84, 9, 8),
        isTiger ? bellyMat : isBear ? coatMat : markingMat,
      );
      paw.scale.set(1.04, 0.56, 1.32);
      paw.position.set(0, pawY, pawZ);
      paw.castShadow = true;
      pivot.add(paw);

      // Claws at front of paw (heavier curved digger claws for Bengal Bear)
      const clawLen = isBear ? 0.046 * s : 0.026 * s;
      const clawRad = isBear ? 0.012 * s : 0.009 * s;
      for (const cOff of [-0.024, 0, 0.024]) {
        const claw = new THREE.Mesh(new THREE.ConeGeometry(clawRad, clawLen, 5), clawMat);
        claw.rotation.x = Math.PI * 0.58;
        claw.position.set(cOff * s, pawY - 0.012 * s, pawZ + upperR * 1.05);
        pivot.add(claw);
      }
    }

    return pivot;
  };

  const frontLegX = 0.165 * s * widthRatio;
  const backLegX = 0.16 * s * widthRatio;
  const frontLeftLeg = buildLeg(-frontLegX, 0.34 * s * lengthRatio, false);
  const frontRightLeg = buildLeg(frontLegX, 0.34 * s * lengthRatio, false);
  const backLeftLeg = buildLeg(-backLegX, -0.35 * s * lengthRatio, true);
  const backRightLeg = buildLeg(backLegX, -0.35 * s * lengthRatio, true);

  // =========================================================================
  // 5. CURVED MULTI-SEGMENT ORGANIC TAIL
  // =========================================================================
  const tailPivot = new THREE.Group();
  tailPivot.position.set(0, 0.1 * s, -0.52 * s * lengthRatio);
  bodyGroup.add(tailPivot);

  if (isBear || isBoar) {
    // Short stubby tail for Bear & Wild Boar
    const stub = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.042 * s, isBoar ? 0.14 * s : 0.08 * s, 4, 7),
      markingMat,
    );
    stub.rotation.x = -0.8;
    stub.position.set(0, -0.04 * s, -0.08 * s);
    tailPivot.add(stub);
  } else if (isHound) {
    // Alert upturned curved canine tail
    const seg1 = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.044 * s, 0.22 * s, 5, 8),
      coatMat,
    );
    seg1.rotation.x = 0.85;
    seg1.position.set(0, 0.08 * s, -0.1 * s);
    tailPivot.add(seg1);

    const seg2 = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.036 * s, 0.2 * s, 5, 8),
      markingMat,
    );
    seg2.rotation.x = 0.35;
    seg2.position.set(0, 0.24 * s, -0.19 * s);
    tailPivot.add(seg2);
  } else {
    // Long graceful sweeping feline tail (extra-long for Leopard, ringed for Tiger, tufted for Lion)
    const tailLenScale = isLeopard ? 1.24 : 1.05;
    const seg1 = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.042 * s, 0.26 * s * tailLenScale, 5, 8),
      coatMat,
    );
    seg1.rotation.x = -1.2;
    seg1.position.set(0, -0.06 * s, -0.15 * s * tailLenScale);
    tailPivot.add(seg1);

    const seg2 = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.035 * s, 0.24 * s * tailLenScale, 5, 8),
      coatMat,
    );
    seg2.rotation.x = -0.82;
    seg2.position.set(0, -0.12 * s, -0.38 * s * tailLenScale);
    tailPivot.add(seg2);

    const seg3 = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.028 * s, 0.2 * s * tailLenScale, 5, 8),
      isTiger || isLion ? markingMat : bellyMat,
    );
    seg3.rotation.x = -0.35;
    seg3.position.set(0, -0.06 * s, -0.56 * s * tailLenScale);
    tailPivot.add(seg3);

    if (isLion) {
      const tuft = new THREE.Mesh(new THREE.ConeGeometry(0.056 * s, 0.14 * s, 7), markingMat);
      tuft.rotation.x = -Math.PI * 0.48;
      tuft.position.set(0, -0.025 * s, -0.68 * s * tailLenScale);
      tailPivot.add(tuft);
    }
  }

  const overlays = attachAnimalOverlays(
    root,
    s,
    widthRatio,
    lengthRatio,
    1.54 * s,
    meta.subdueRatio,
  );

  return {
    root,
    bodyGroup,
    neckGroup,
    headGroup,
    frontLeftLeg,
    frontRightLeg,
    backLeftLeg,
    backRightLeg,
    tailPivot,
    collarGroup,
    eyeMaterials: [eyeMat],
    flashMaterials,
    baseEmissives,
    ...overlays,
    bodyPlan: 'quadruped',
  };
}

/**
 * Applies capped visual stature & milestone aura feedback for a leveled-up permanent pet (LV 1 -> LV 1000).
 */
export function applyPetLevelVisuals(rig: AnimalRig, level: number): void {
  const lv = Math.max(1, Math.min(PET_MAX_LEVEL, Math.round(level)));
  const scaleBoost = 1 + Math.min(0.24, (lv - 1) * 0.015);
  rig.root.scale.setScalar(scaleBoost);

  const ringMat = rig.petLevelRing.material as THREE.MeshBasicMaterial;
  if (lv <= 1) {
    rig.petLevelRing.visible = false;
  } else {
    rig.petLevelRing.visible = true;
    const auraColor =
      lv >= 500
        ? 0xff5a1f
        : lv >= 200
          ? 0xffd24c
          : lv >= 50
            ? 0xd966ff
            : lv >= 10
              ? 0x4fd2ff
              : 0x4df5b8;
    ringMat.color.setHex(auraColor);
    ringMat.opacity = Math.min(0.84, 0.44 + Math.min(10, lv - 1) * 0.04);
  }
}

/**
 * Builds a lightweight sculpted 3D Animal Heart crystal drop mesh (beveled extruded heart + halo ring).
 * Grounded cleanly above y = 0 so it hovers smoothly over terrain without clipping.
 */
let sharedHeartGeo: THREE.ExtrudeGeometry | null = null;

function getSharedHeartGeometry(): THREE.ExtrudeGeometry {
  if (sharedHeartGeo) return sharedHeartGeo;
  const shape = new THREE.Shape();
  shape.moveTo(0, -0.34);
  shape.bezierCurveTo(0.06, -0.26, 0.36, -0.04, 0.36, 0.16);
  shape.bezierCurveTo(0.36, 0.34, 0.18, 0.42, 0.06, 0.32);
  shape.bezierCurveTo(0.02, 0.28, 0.0, 0.24, 0.0, 0.2);
  shape.bezierCurveTo(0.0, 0.24, -0.02, 0.28, -0.06, 0.32);
  shape.bezierCurveTo(-0.18, 0.42, -0.36, 0.34, -0.36, 0.16);
  shape.bezierCurveTo(-0.36, -0.04, -0.06, -0.26, 0, -0.34);

  const geo = new THREE.ExtrudeGeometry(shape, {
    steps: 1,
    depth: 0.14,
    bevelEnabled: true,
    bevelThickness: 0.06,
    bevelSize: 0.05,
    bevelSegments: 2,
    curveSegments: 10,
  });
  geo.center();
  sharedHeartGeo = geo;
  return geo;
}

export function buildAnimalHeartPickupMesh(tier: AnimalHeartTier): THREE.Group {
  const meta = ANIMAL_HEART_TIERS[tier];
  const group = new THREE.Group();
  const tierScale = 0.92 + (tier - 1) * 0.085;

  const heartMat = new THREE.MeshStandardMaterial({
    color: meta.colorHex,
    emissive: meta.emissiveHex,
    emissiveIntensity: 0.85 + tier * 0.12,
    roughness: 0.22,
    metalness: 0.25,
  });
  const heartMesh = new THREE.Mesh(getSharedHeartGeometry(), heartMat);
  heartMesh.scale.setScalar(tierScale);
  heartMesh.position.y = 0.72;
  group.add(heartMesh);

  const haloMat = new THREE.MeshBasicMaterial({
    color: meta.ringHex,
    transparent: true,
    opacity: 0.86,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const haloRing = new THREE.Mesh(new THREE.TorusGeometry(0.46 * tierScale, 0.028, 8, 24), haloMat);
  haloRing.position.y = 0.72;
  haloRing.rotation.x = Math.PI * 0.38;
  group.add(haloRing);

  const groundRing = new THREE.Mesh(
    new THREE.RingGeometry(0.42, 0.62, 24),
    new THREE.MeshBasicMaterial({
      color: meta.colorHex,
      transparent: true,
      opacity: 0.58,
      side: THREE.DoubleSide,
      depthWrite: false,
    }),
  );
  groundRing.rotation.x = -Math.PI / 2;
  groundRing.position.y = 0.05;
  group.add(groundRing);

  return group;
}

export function animateAnimalRig(
  rig: AnimalRig,
  species: WildAnimalSpecies,
  dt: number,
  worldTime: number,
  walkPhase: number,
  moveBlend: number,
  options: {
    isSubdued?: boolean;
    isLunging?: boolean;
    isTaming?: boolean;
    isTamed?: boolean;
    flinchPulse?: number;
  } = {},
): void {
  const s = WILD_ANIMAL_CATALOG[species].bodyScale;
  const {
    isSubdued = false,
    isLunging = false,
    isTaming = false,
    isTamed = false,
    flinchPulse = 0,
  } = options;

  const w = THREE.MathUtils.clamp(moveBlend, 0, 1);
  const sinP = Math.sin(walkPhase);
  const cosP = Math.cos(walkPhase);
  const breathRate = isSubdued ? 6.0 : isTamed ? 2.4 : 3.4;
  const breath = Math.sin(worldTime * breathRate);

  if (rig.bodyPlan === 'python') {
    // Undulating sinusoidal slither across all serpent segments + raised coiled head
    const segs = rig.snakeSegments ?? [];
    const amp = (0.09 + 0.19 * w) * s;
    const freq = 0.85;
    const phaseBase = w > 0.05 ? walkPhase * 1.15 : worldTime * 1.9;
    for (let i = 0; i < segs.length; i++) {
      const wave = Math.sin(phaseBase - i * freq);
      segs[i].position.x = wave * amp * (0.45 + i * 0.14);
      segs[i].rotation.y = Math.cos(phaseBase - i * freq) * (0.14 + 0.22 * w);
    }
    const baseY = 0.15 * s;
    rig.bodyGroup.position.y = THREE.MathUtils.damp(
      rig.bodyGroup.position.y,
      baseY + (isLunging ? 0.12 * s : 0),
      12,
      dt,
    );
    rig.neckGroup.position.y = THREE.MathUtils.damp(
      rig.neckGroup.position.y,
      (isSubdued ? 0.05 : isLunging ? 0.38 : 0.18 + breath * 0.03) * s,
      12,
      dt,
    );
    rig.headGroup.rotation.y = Math.sin(worldTime * 2.4) * 0.22;
    rig.headGroup.rotation.x = THREE.MathUtils.damp(
      rig.headGroup.rotation.x,
      (isSubdued ? 0.22 : isLunging ? -0.18 : 0) - flinchPulse * 0.25,
      12,
      dt,
    );
  } else if (rig.bodyPlan === 'spider') {
    // Alternating tetrapod 8-leg arachnid skitter gait + menacing low abdomen bounce
    const skitter = (0.14 + 0.42 * w) * (isSubdued ? 0.45 : 1);
    const s1 = Math.sin(walkPhase * 1.35) * skitter;
    const s2 = -s1;
    rig.frontLeftLeg.rotation.z = THREE.MathUtils.damp(rig.frontLeftLeg.rotation.z, s1, 18, dt);
    rig.frontRightLeg.rotation.z = THREE.MathUtils.damp(rig.frontRightLeg.rotation.z, s2, 18, dt);
    rig.backLeftLeg.rotation.z = THREE.MathUtils.damp(rig.backLeftLeg.rotation.z, s2, 18, dt);
    rig.backRightLeg.rotation.z = THREE.MathUtils.damp(rig.backRightLeg.rotation.z, s1, 18, dt);
    if (rig.extraLegs && rig.extraLegs.length === 4) {
      rig.extraLegs[0].rotation.z = THREE.MathUtils.damp(rig.extraLegs[0].rotation.z, s2, 18, dt);
      rig.extraLegs[1].rotation.z = THREE.MathUtils.damp(rig.extraLegs[1].rotation.z, s1, 18, dt);
      rig.extraLegs[2].rotation.z = THREE.MathUtils.damp(rig.extraLegs[2].rotation.z, s1, 18, dt);
      rig.extraLegs[3].rotation.z = THREE.MathUtils.damp(rig.extraLegs[3].rotation.z, s2, 18, dt);
    }
    const targetY =
      0.46 * s + Math.abs(cosP) * 0.04 * s * w - (isSubdued ? 0.1 * s : 0) + breath * 0.012 * s;
    rig.bodyGroup.position.y = THREE.MathUtils.damp(rig.bodyGroup.position.y, targetY, 15, dt);
    rig.bodyGroup.rotation.x = THREE.MathUtils.damp(
      rig.bodyGroup.rotation.x,
      (isLunging ? -0.18 : 0) - flinchPulse * 0.2,
      14,
      dt,
    );
  } else if (rig.bodyPlan === 'gorilla') {
    // Heavy silverback knuckle-walk alternating arm & leg stride + subtle chest-heave
    const stride = (isLunging ? 0.72 : isSubdued ? 0.28 : 0.56) * w;
    rig.frontLeftLeg.rotation.x = THREE.MathUtils.damp(
      rig.frontLeftLeg.rotation.x,
      sinP * stride + (isLunging ? -0.65 : 0),
      14,
      dt,
    );
    rig.frontRightLeg.rotation.x = THREE.MathUtils.damp(
      rig.frontRightLeg.rotation.x,
      -sinP * stride + (isLunging ? -0.65 : 0),
      14,
      dt,
    );
    rig.backLeftLeg.rotation.x = THREE.MathUtils.damp(
      rig.backLeftLeg.rotation.x,
      -sinP * stride * 0.82,
      14,
      dt,
    );
    rig.backRightLeg.rotation.x = THREE.MathUtils.damp(
      rig.backRightLeg.rotation.x,
      sinP * stride * 0.82,
      14,
      dt,
    );
    const targetY =
      0.78 * s +
      Math.abs(cosP) * 0.055 * s * w -
      (isSubdued ? 0.14 * s : 0) +
      breath * 0.018 * s;
    rig.bodyGroup.position.y = THREE.MathUtils.damp(rig.bodyGroup.position.y, targetY, 14, dt);
    rig.bodyGroup.rotation.z = THREE.MathUtils.damp(
      rig.bodyGroup.rotation.z,
      sinP * 0.075 * w + flinchPulse * 0.15,
      12,
      dt,
    );
    rig.headGroup.rotation.y = THREE.MathUtils.damp(
      rig.headGroup.rotation.y,
      Math.sin(worldTime * 1.6) * 0.14,
      10,
      dt,
    );
  } else {
    const legLengthRatio =
      species === 'wild_boar'
        ? 0.78
        : species === 'bengal_bear'
          ? 0.88
          : species === 'lion_king'
            ? 1.0
            : species === 'sundarban_tiger'
              ? 0.98
              : species === 'bengal_leopard'
                ? 1.05
                : 1.02;
    const stride = (isLunging ? 0.88 : isSubdued ? 0.36 : 0.66) * w;

    // Quadruped diagonal gallop/trot leg phase
    const flTarget = sinP * stride - (isSubdued ? 0.22 : 0);
    const frTarget = -sinP * stride - (isSubdued ? 0.14 : 0);
    const blTarget = -sinP * stride * 0.92 + (isSubdued ? 0.18 : 0);
    const brTarget = sinP * stride * 0.92 + (isSubdued ? 0.12 : 0);

    rig.frontLeftLeg.rotation.x = THREE.MathUtils.damp(rig.frontLeftLeg.rotation.x, flTarget, 16, dt);
    rig.frontRightLeg.rotation.x = THREE.MathUtils.damp(rig.frontRightLeg.rotation.x, frTarget, 16, dt);
    rig.backLeftLeg.rotation.x = THREE.MathUtils.damp(rig.backLeftLeg.rotation.x, blTarget, 16, dt);
    rig.backRightLeg.rotation.x = THREE.MathUtils.damp(rig.backRightLeg.rotation.x, brTarget, 16, dt);

    const baseBodyY = 0.65 * s * legLengthRatio;
    const targetBodyY =
      baseBodyY +
      Math.abs(cosP) * 0.068 * s * w -
      (isSubdued ? 0.13 * s : 0) +
      (isLunging ? 0.12 * s : 0) +
      breath * (isSubdued ? 0.02 : 0.008) * s;

    const targetBodyPitch =
      (isLunging ? -0.24 : 0) +
      (isSubdued ? 0.15 : 0) +
      cosP * 0.075 * w -
      flinchPulse * 0.2;

    rig.bodyGroup.position.y = THREE.MathUtils.damp(rig.bodyGroup.position.y, targetBodyY, 15, dt);
    rig.bodyGroup.rotation.x = THREE.MathUtils.damp(rig.bodyGroup.rotation.x, targetBodyPitch, 14, dt);
    rig.bodyGroup.rotation.z = THREE.MathUtils.damp(
      rig.bodyGroup.rotation.z,
      sinP * 0.048 * w + (isSubdued ? Math.sin(worldTime * 8.2) * 0.032 : 0) + flinchPulse * 0.18,
      14,
      dt,
    );

    const targetHeadPitch =
      (isSubdued ? 0.34 + breath * 0.09 : 0) +
      (isTaming ? 0.12 : 0) +
      (isLunging ? -0.2 : 0) -
      flinchPulse * 0.28;
    const targetHeadYaw = isTamed
      ? Math.sin(worldTime * 1.4) * 0.16 * (1 - w * 0.6)
      : isSubdued
        ? Math.sin(worldTime * 3.4) * 0.16
        : Math.sin(worldTime * 2.1) * 0.09;

    rig.headGroup.rotation.x = THREE.MathUtils.damp(rig.headGroup.rotation.x, targetHeadPitch, 14, dt);
    rig.headGroup.rotation.y = THREE.MathUtils.damp(rig.headGroup.rotation.y, targetHeadYaw, 12, dt);

    const tailYaw = isTamed
      ? Math.sin(worldTime * (5.2 + w * 3.5)) * 0.4
      : isSubdued
        ? Math.sin(worldTime * 2.4) * 0.1
        : Math.sin(worldTime * 7.0) * 0.32;
    const tailPitch = isTamed ? 0.26 : isSubdued ? -0.38 : 0.12;
    rig.tailPivot.rotation.y = THREE.MathUtils.damp(rig.tailPivot.rotation.y, tailYaw, 14, dt);
    rig.tailPivot.rotation.x = THREE.MathUtils.damp(rig.tailPivot.rotation.x, tailPitch, 12, dt);
  }

  // Subdued & Taming ground rings
  rig.subduedRing.visible = isSubdued && !isTamed;
  if (rig.subduedRing.visible) {
    const pulse = 0.94 + Math.sin(worldTime * 5.6) * 0.07;
    rig.subduedRing.scale.set(pulse, pulse, 1);
    rig.subduedRing.rotation.z = worldTime * 1.05;
  }

  rig.tameRing.visible = isTaming && !isTamed;
  if (rig.tameRing.visible) {
    const pulse = 0.92 + Math.sin(worldTime * 10.0) * 0.08;
    rig.tameRing.scale.set(pulse, pulse, 1);
    rig.tameRing.rotation.z = -worldTime * 2.5;
  }

  if (rig.heartAuraRing.visible) {
    const hPulse = 0.92 + Math.sin(worldTime * 4.4) * 0.09;
    rig.heartAuraRing.scale.set(hPulse, hPulse, 1);
    rig.heartAuraRing.rotation.z = worldTime * 0.9;
  }

  if (rig.petLevelRing.visible) {
    const pPulse = 0.95 + Math.sin(worldTime * 3.1) * 0.05;
    rig.petLevelRing.scale.set(pPulse, pPulse, 1);
    rig.petLevelRing.rotation.z = -worldTime * 0.65;
  }
}
