import * as THREE from 'three';
import {
  buildBajraGolaMesh,
  buildBanglarFala,
  buildSanjibaniPlant,
  buildTrishulSniper,
} from './battleRoyaleAssets';
import { TextureBundle } from './textures';
import { EnemyArchetype, PickupKind } from './types';

export interface HeroRig {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  upperBodyGroup: THREE.Group;
  headGroup: THREE.Group;
  hairTuft: THREE.Group;
  kurtaHem: THREE.Mesh;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  leftKnee: THREE.Group;
  rightKnee: THREE.Group;
  leftAnkle: THREE.Group;
  rightAnkle: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  gamchaTail: THREE.Mesh;
  gamchaMaterial: THREE.MeshStandardMaterial;
  rifleGroup: THREE.Group;
  shotgunGroup: THREE.Group;
  trishulGroup: THREE.Group;
  falaGroup: THREE.Group;
  armorVestOverlay: THREE.Mesh;
  muzzlePoint: THREE.Object3D;
  muzzleFlash: THREE.Mesh;
  muzzleLight: THREE.PointLight;
  recoilGroup: THREE.Group;
  setBlink: (amount: number) => void;
  updateGamchaCloth: (
    dt: number,
    time: number,
    localVelX: number,
    localVelY: number,
    localVelZ: number,
    yawRate: number,
    windBoost: number,
  ) => void;
}

export interface EnemyRig {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  upperBodyGroup: THREE.Group;
  headGroup: THREE.Group;
  hairTuft: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  leftKnee: THREE.Group;
  rightKnee: THREE.Group;
  leftAnkle: THREE.Group;
  rightAnkle: THREE.Group;
  leftArm: THREE.Group;
  weaponPivot: THREE.Group;
  muzzlePoint: THREE.Object3D;
  telegraphGlow: THREE.Mesh;
  hpBarBg: THREE.Mesh;
  hpBarFill: THREE.Mesh;
  flashMaterials: THREE.MeshStandardMaterial[];
  baseEmissives: THREE.Color[];
  setBlink: (amount: number) => void;
  updateCloth: (
    dt: number,
    time: number,
    speed: number,
    yawRate: number,
    windBoost: number,
  ) => void;
}

// Module-level reusable math helpers (zero GC inside builders/updates)
const _up = new THREE.Vector3(0, 1, 0);
const _dir = new THREE.Vector3();
const _mid = new THREE.Vector3();
const _quat = new THREE.Quaternion();

function addActorShadow(parent: THREE.Object3D, shadowMap: THREE.CanvasTexture, size = 1.35): void {
  const geo = new THREE.PlaneGeometry(size, size);
  geo.rotateX(-Math.PI / 2);
  const mat = new THREE.MeshBasicMaterial({
    map: shadowMap,
    transparent: true,
    opacity: 0.56,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.y = 0.025;
  parent.add(mesh);
}

// ============================================================================
// Realistic PBR Materials (Skin Subsurface Shader, Woven Fabric, Hair, Leather)
// ============================================================================

/**
 * Realistic human PBR skin material using MeshPhysicalMaterial with skin-pore bump,
 * soft velvet sheen, natural epidermal clearcoat, and an injected warm subsurface
 * scattering (SSS) wrap-lighting term so cheeks, jawline, ears, and forearms glow warmly.
 */
function createRealisticSkinMaterial(
  baseHex: number,
  textures: TextureBundle,
  isFace = false,
): THREE.MeshPhysicalMaterial {
  const mat = new THREE.MeshPhysicalMaterial({
    color: baseHex,
    map: isFace ? textures.faceAlbedoMap : textures.skinAlbedoMap,
    roughness: isFace ? 0.58 : 0.64,
    metalness: 0.0,
    bumpMap: textures.skinBumpMap,
    bumpScale: isFace ? 0.0048 : 0.0056,
    sheen: 0.16,
    sheenRoughness: 0.84,
    sheenColor: new THREE.Color(0xd9a282),
    clearcoat: 0.02,
    clearcoatRoughness: 0.72,
  });

  mat.onBeforeCompile = (shader) => {
    shader.fragmentShader = shader.fragmentShader.replace(
      '#include <lights_fragment_end>',
      `
      #include <lights_fragment_end>
      vec3 sssNormal = normalize( normal );
      vec3 sssView = normalize( vViewPosition );
      float sssRim = pow( 1.0 - clamp( dot( sssNormal, sssView ), 0.0, 1.0 ), 2.6 );
      float sssWrap = clamp( dot( sssNormal, normalize( vec3( 0.45, 0.55, 0.35 ) ) ) * 0.5 + 0.5, 0.0, 1.0 );
      reflectedLight.indirectDiffuse += vec3( 0.08, 0.028, 0.015 ) * ( 0.35 + 0.65 * sssRim ) * sssWrap;
      `,
    );
  };
  mat.customProgramCacheKey = () =>
    isFace ? 'bengal-realistic-face-sss-v3' : 'bengal-realistic-skin-sss-v3';

  return mat;
}

function createClothMaterial(
  colorHex: number,
  textures: TextureBundle,
  options?: {
    map?: THREE.Texture;
    roughness?: number;
    sheen?: number;
    sheenColor?: number;
    side?: THREE.Side;
    bumpScale?: number;
  },
): THREE.MeshPhysicalMaterial {
  return new THREE.MeshPhysicalMaterial({
    color: colorHex,
    map: options?.map ?? null,
    roughness: options?.roughness ?? 0.92,
    metalness: 0.0,
    bumpMap: textures.fabricBumpMap,
    bumpScale: options?.bumpScale ?? 0.013,
    sheen: options?.sheen ?? 0.22,
    sheenRoughness: 0.88,
    sheenColor: new THREE.Color(options?.sheenColor ?? 0xd8cfc2),
    side: options?.side ?? THREE.FrontSide,
  });
}

function createHairMaterial(colorHex = 0x161311): THREE.MeshPhysicalMaterial {
  return new THREE.MeshPhysicalMaterial({
    color: colorHex,
    roughness: 0.68,
    metalness: 0.02,
    sheen: 0.18,
    sheenRoughness: 0.62,
    sheenColor: new THREE.Color(0x463c35),
  });
}

// ============================================================================
// Sculpted Organic Humanoid Geometry Generators (Lathe + Analytical Sculpting)
// ============================================================================

/**
 * Generates an anatomical human pelvis / hip bridge so the lower torso connects
 * seamlessly to both hips with zero gap during sprinting, kneeling, or sitting.
 */
function createContouredPelvisGeometry(widthMult = 1.0): THREE.BufferGeometry {
  const profile: THREE.Vector2[] = [
    new THREE.Vector2(0.001, 0.0),
    new THREE.Vector2(0.118, 0.025),
    new THREE.Vector2(0.156, 0.08),
    new THREE.Vector2(0.168, 0.14),
    new THREE.Vector2(0.158, 0.19),
    new THREE.Vector2(0.001, 0.21),
  ];
  const geo = new THREE.LatheGeometry(profile, 22);
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i) * 1.12 * widthMult;
    const y = pos.getY(i);
    let z = pos.getZ(i) * 0.78;
    // Gentle posterior gluteal contour
    if (z < -0.02) {
      const ny = THREE.MathUtils.clamp(y / 0.2, 0, 1);
      z -= Math.sin(ny * Math.PI) * 0.018;
    }
    pos.setXYZ(i, x, y, z);
  }
  geo.computeVertexNormals();
  return geo;
}

/**
 * Generates an anatomically contoured human torso from waist/pelvis (y=0) to shoulder crest (y=0.58)
 * with natural clavicular slope, athletic chest-to-waist ratio, lumbar curve, and dorsal definition.
 */
function createContouredTorsoGeometry(widthMult = 1.0, depthMult = 1.0): THREE.BufferGeometry {
  const profile: THREE.Vector2[] = [
    new THREE.Vector2(0.001, 0.0),
    new THREE.Vector2(0.136, 0.02),
    new THREE.Vector2(0.152, 0.07), // hips / iliac crest
    new THREE.Vector2(0.143, 0.14), // lower waist
    new THREE.Vector2(0.139, 0.21), // tapered athletic waist
    new THREE.Vector2(0.154, 0.29), // lower ribcage / obliques
    new THREE.Vector2(0.174, 0.37), // mid chest / lats
    new THREE.Vector2(0.186, 0.45), // natural pectorals / upper lats
    new THREE.Vector2(0.181, 0.505), // clavicular shoulder socket line
    new THREE.Vector2(0.134, 0.555), // smooth trapezius slope
    new THREE.Vector2(0.079, 0.585), // neck collar base
    new THREE.Vector2(0.001, 0.592),
  ];

  const geo = new THREE.LatheGeometry(profile, 28);
  const pos = geo.attributes.position;

  for (let i = 0; i < pos.count; i++) {
    let x = pos.getX(i);
    const y = pos.getY(i);
    let z = pos.getZ(i);

    const ny = THREE.MathUtils.clamp(y / 0.59, 0, 1);

    // Realistic elliptical human torso cross-section aligned cleanly to upper shoulder sockets
    const xScale = (1.03 + ny * 0.11) * widthMult;
    const zScale = (0.7 - Math.abs(ny - 0.65) * 0.06) * depthMult;
    x *= xScale;
    z *= zScale;

    // Anatomical S-curve along spine (gentle lumbar curve, confident chest posture)
    const spineShift = Math.sin((ny - 0.24) * Math.PI) * 0.014;
    z += spineShift;

    // Pectoral fullness on front upper chest + subtle sternum valley at x = 0
    if (z > 0.02 && ny > 0.48 && ny < 0.88) {
      const chestBell = Math.sin(((ny - 0.48) / 0.4) * Math.PI);
      const pecX = Math.exp(-Math.pow((Math.abs(x) - 0.092) / 0.074, 2));
      const sternumDip = Math.exp(-Math.pow(x / 0.032, 2)) * 0.009;
      z += chestBell * (pecX * 0.021 - sternumDip);
    }

    // Subtle dorsal spine groove & shoulder-blade definition along back
    if (z < -0.02 && ny > 0.18 && ny < 0.88) {
      const backBell = Math.sin(((ny - 0.18) / 0.7) * Math.PI);
      const spineGroove = Math.exp(-Math.pow(x / 0.035, 2)) * 0.012;
      const scapula = ny > 0.55 ? Math.exp(-Math.pow((Math.abs(x) - 0.098) / 0.058, 2)) * 0.011 : 0;
      z += backBell * (spineGroove - scapula);
    }

    // Subtle lower abdominal contour
    if (z > 0.01 && ny > 0.12 && ny < 0.45) {
      const absCurve = Math.sin(((ny - 0.12) / 0.33) * Math.PI);
      z += absCurve * 0.007 * Math.exp(-Math.pow(x / 0.1, 2));
    }

    pos.setXYZ(i, x, y, z);
  }

  geo.computeVertexNormals();
  return geo;
}

/**
 * Generates an organic sculpted limb segment (thigh, calf, upper arm, forearm, neck)
 * along the +Y axis from y = 0 to y = length using LatheGeometry + elliptical muscle contour.
 */
function createContouredLimbGeometry(
  profilePairs: Array<[number, number]>, // [normalizedT (0..1), radius]
  length: number,
  xScale = 1.0,
  zScale = 1.0,
  radialSegments = 18,
  muscleBulgeZ = 0,
): THREE.BufferGeometry {
  const pts: THREE.Vector2[] = [];
  pts.push(new THREE.Vector2(0.001, 0));
  for (const [t, r] of profilePairs) {
    pts.push(new THREE.Vector2(Math.max(0.002, r), t * length));
  }
  pts.push(new THREE.Vector2(0.001, length));

  const geo = new THREE.LatheGeometry(pts, radialSegments);
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i) * xScale;
    const y = pos.getY(i);
    let z = pos.getZ(i) * zScale;

    if (muscleBulgeZ !== 0) {
      const ny = y / Math.max(0.001, length);
      z += Math.sin(ny * Math.PI) * muscleBulgeZ;
    }

    pos.setXYZ(i, x, y, z);
  }
  geo.computeVertexNormals();
  return geo;
}

/**
 * Generates a realistic sculpted human head geometry starting from a subdivided SphereGeometry,
 * carving authentic cranial volume, tapered angular jawline, chin, brow ridge, cheekbones,
 * recessed eye sockets (orbital cavities), and nasal-philtrum contour.
 */
function createSculptedHeadGeometry(): THREE.BufferGeometry {
  const geo = new THREE.SphereGeometry(0.112, 32, 26);
  const pos = geo.attributes.position;

  for (let i = 0; i < pos.count; i++) {
    let x = pos.getX(i);
    let y = pos.getY(i);
    let z = pos.getZ(i);

    // Overall realistic human cranium proportions (slightly taller & deeper front-to-back)
    x *= 0.89;
    y *= 1.13;
    z *= 1.02;

    const absX = Math.abs(x);

    // 1. Cranial back (occiput) slightly rounded upward & backward
    if (y > 0.015 && z < 0.01) {
      const craniumT = THREE.MathUtils.clamp((y - 0.015) / 0.1, 0, 1);
      z -= craniumT * 0.012;
      x *= 1.0 + craniumT * 0.04;
    }

    // 2. Temple narrowing beside the forehead
    if (y > 0.015 && y < 0.08 && z > -0.01 && absX > 0.055) {
      const templeW = Math.exp(-Math.pow((y - 0.042) / 0.028, 2)) * Math.exp(-Math.pow((z - 0.025) / 0.035, 2));
      x *= 1.0 - templeW * 0.085;
    }

    // 3. Tapered angular jawline & sculpted chin (y < -0.015)
    if (y < -0.015) {
      const jawT = THREE.MathUtils.clamp((-0.015 - y) / 0.115, 0, 1);
      // Narrow smoothly toward chin tip while preserving defined jaw corners near z ~ 0.0
      const frontFactor = THREE.MathUtils.clamp((z + 0.04) / 0.13, 0, 1);
      const jawNarrow = 1.0 - jawT * (0.28 + frontFactor * 0.24);
      x *= jawNarrow;

      // Sculpt distinct chin projection at front bottom
      if (z > 0.01) {
        const chinBell = Math.exp(-Math.pow((y + 0.105) / 0.028, 2)) * Math.exp(-Math.pow(x / 0.034, 2));
        z += chinBell * 0.024;
        y -= chinBell * 0.008;
      }

      // Tuck underside of skull smoothly into neck at back-bottom
      if (z < -0.01) {
        z += jawT * 0.036;
      }

      // Slight defined jaw angle (gonion)
      const gonion =
        Math.exp(-Math.pow((y + 0.068) / 0.022, 2)) *
        Math.exp(-Math.pow((z - 0.008) / 0.028, 2)) *
        THREE.MathUtils.clamp((absX - 0.04) / 0.04, 0, 1);
      x += Math.sign(x) * gonion * 0.01;
    }

    // 4. Brow ridge overhang above eyes
    if (z > 0.055 && y > 0.018 && y < 0.052) {
      const brow =
        Math.exp(-Math.pow((y - 0.033) / 0.013, 2)) *
        Math.exp(-Math.pow(x / 0.058, 2));
      z += brow * 0.014;
    }

    // 5. Recessed eye orbits (carved cavities so realistic eyes sit naturally inside the skull)
    if (z > 0.055) {
      const leftEyeDist = Math.hypot((x + 0.034) / 0.022, (y - 0.009) / 0.016);
      const rightEyeDist = Math.hypot((x - 0.034) / 0.022, (y - 0.009) / 0.016);
      const orbitDepth = Math.exp(-leftEyeDist * leftEyeDist) + Math.exp(-rightEyeDist * rightEyeDist);
      z -= orbitDepth * 0.018;
    }

    // 6. Cheekbone prominence (zygomatic arch below outer eyes)
    if (z > 0.02 && y > -0.042 && y < 0.005) {
      const cheek =
        Math.exp(-Math.pow((absX - 0.058) / 0.024, 2)) *
        Math.exp(-Math.pow((y + 0.017) / 0.018, 2));
      x += Math.sign(x) * cheek * 0.0085;
      z += cheek * 0.009;
    }

    // 7. Subtle hollow below cheekbones (sculpted athletic cheeks)
    if (z > 0.02 && y < -0.035 && y > -0.082) {
      const hollow =
        Math.exp(-Math.pow((absX - 0.054) / 0.02, 2)) *
        Math.exp(-Math.pow((y + 0.056) / 0.02, 2));
      x -= Math.sign(x) * hollow * 0.006;
      z -= hollow * 0.004;
    }

    // 8. Mouth barrel / philtrum subtle anterior curve
    if (z > 0.06 && y < -0.032 && y > -0.086) {
      const mouthMound =
        Math.exp(-Math.pow((y + 0.058) / 0.024, 2)) *
        Math.exp(-Math.pow(x / 0.038, 2));
      z += mouthMound * 0.009;
    }

    pos.setXYZ(i, x, y, z);
  }

  geo.computeVertexNormals();
  return geo;
}

type HairStyle = 'hero-sweep' | 'scout-crop' | 'rusher-wavy' | 'heavy-fade';

/**
 * Builds natural layered Bengali hair with feathered hairline, tapered sides/nape,
 * textured crown locks, and a wind-reactive front hair tuft for subtle motion.
 */
function buildShortFadeHair(
  hairMat: THREE.MeshPhysicalMaterial,
  fadeMat: THREE.MeshStandardMaterial,
  style: HairStyle = 'hero-sweep',
): { hairGroup: THREE.Group; hairTuft: THREE.Group } {
  const hairGroup = new THREE.Group();

  // 1. Natural tapered lower sides & occiput hugging the skull cleanly
  const fadeGeo = new THREE.SphereGeometry(0.107, 26, 20, 0, Math.PI * 2, 0.05, Math.PI * 0.56);
  const fPos = fadeGeo.attributes.position;
  for (let i = 0; i < fPos.count; i++) {
    let x = fPos.getX(i) * 0.915;
    let y = fPos.getY(i) * 1.115;
    let z = fPos.getZ(i) * 1.035;

    // Push hairline cleanly back over forehead so brows and temples stay open
    if (z > 0.042) {
      const browCut = THREE.MathUtils.clamp((0.068 - y) / 0.06, 0, 1);
      z -= browCut * 0.032;
      y += browCut * 0.014;
    }
    if (z < -0.03) {
      y -= style === 'rusher-wavy' ? 0.018 : 0.01;
    }
    fPos.setXYZ(i, x, y, z);
  }
  fadeGeo.computeVertexNormals();
  const fadeCap = new THREE.Mesh(fadeGeo, fadeMat);
  fadeCap.position.set(0, 0.008, -0.006);
  fadeCap.castShadow = true;
  hairGroup.add(fadeCap);

  // 2. Textured natural crown volume
  const topScaleY = style === 'heavy-fade' ? 0.86 : style === 'rusher-wavy' ? 1.0 : 0.95;
  const topGeo = new THREE.SphereGeometry(0.104, 24, 16, 0, Math.PI * 2, 0, Math.PI * 0.45);
  const tPos = topGeo.attributes.position;
  for (let i = 0; i < tPos.count; i++) {
    let x = tPos.getX(i) * 0.88;
    let y = tPos.getY(i) * topScaleY;
    let z = tPos.getZ(i) * 1.04;

    const wave =
      Math.sin(x * 76 + z * 30) * 0.0042 +
      Math.cos(z * 60 - x * 34) * 0.003;
    const frontLift = z > 0.02 ? THREE.MathUtils.clamp((z - 0.02) / 0.08, 0, 1) * 0.016 : 0;
    y += wave + frontLift;
    tPos.setXYZ(i, x, y, z);
  }
  topGeo.computeVertexNormals();
  const topCrop = new THREE.Mesh(topGeo, hairMat);
  topCrop.position.set(0, 0.034, -0.002);
  topCrop.castShadow = true;
  hairGroup.add(topCrop);

  // 3. Layered swept hair locks across crown & hairline
  const lockSpecs: Array<{
    pts: [number, number, number][];
    radius: number;
  }> = [
    {
      pts: [
        [-0.048, 0.082, 0.072],
        [-0.026, 0.118, 0.048],
        [-0.012, 0.132, -0.005],
        [-0.018, 0.114, -0.068],
      ],
      radius: 0.019,
    },
    {
      pts: [
        [-0.01, 0.086, 0.082],
        [0.008, 0.126, 0.052],
        [0.018, 0.136, -0.008],
        [0.012, 0.118, -0.072],
      ],
      radius: 0.021,
    },
    {
      pts: [
        [0.028, 0.084, 0.076],
        [0.045, 0.12, 0.044],
        [0.048, 0.128, -0.012],
        [0.038, 0.108, -0.07],
      ],
      radius: 0.019,
    },
    {
      pts: [
        [0.058, 0.076, 0.054],
        [0.072, 0.104, 0.022],
        [0.068, 0.108, -0.034],
      ],
      radius: 0.016,
    },
    {
      pts: [
        [-0.066, 0.072, 0.048],
        [-0.076, 0.098, 0.016],
        [-0.07, 0.104, -0.036],
      ],
      radius: 0.015,
    },
  ];

  if (style === 'rusher-wavy') {
    lockSpecs.push(
      {
        pts: [
          [-0.052, 0.048, -0.078],
          [-0.062, 0.005, -0.095],
          [-0.048, -0.032, -0.088],
        ],
        radius: 0.016,
      },
      {
        pts: [
          [0.052, 0.048, -0.078],
          [0.062, 0.005, -0.095],
          [0.048, -0.032, -0.088],
        ],
        radius: 0.016,
      },
    );
  }

  for (const spec of lockSpecs) {
    const curve = new THREE.CatmullRomCurve3(
      spec.pts.map(([px, py, pz]) => new THREE.Vector3(px, py, pz)),
    );
    const lockGeo = new THREE.TubeGeometry(curve, 12, spec.radius * 0.82, 8, false);
    lockGeo.computeVertexNormals();
    const lock = new THREE.Mesh(lockGeo, hairMat);
    lock.castShadow = true;
    hairGroup.add(lock);
  }

  // 4. Wind-reactive front swept fringe tuft (pivoted cleanly at forehead hairline)
  const hairTuft = new THREE.Group();
  hairTuft.position.set(0.012, 0.094, 0.076);
  const tuftSpecs: Array<[number, number, number][]> = [
    [
      [0, 0, 0],
      [-0.016, 0.012, 0.016],
      [-0.034, -0.006, 0.022],
    ],
    [
      [0.014, -0.002, -0.004],
      [0.002, 0.009, 0.015],
      [-0.012, -0.011, 0.021],
    ],
  ];
  for (const pts of tuftSpecs) {
    const curve = new THREE.CatmullRomCurve3(pts.map(([x, y, z]) => new THREE.Vector3(x, y, z)));
    const tuftGeo = new THREE.TubeGeometry(curve, 8, style === 'heavy-fade' ? 0.008 : 0.011, 6, false);
    const mesh = new THREE.Mesh(tuftGeo, hairMat);
    mesh.castShadow = true;
    hairTuft.add(mesh);
  }
  hairGroup.add(hairTuft);

  // 5. Clean tapered sideburns
  for (const side of [-1, 1]) {
    const sideburn = new THREE.Mesh(new THREE.CapsuleGeometry(0.0058, 0.035, 4, 6), fadeMat);
    sideburn.position.set(side * 0.091, 0.012, 0.024);
    sideburn.rotation.x = 0.14;
    sideburn.scale.set(0.45, 1, 1.25);
    hairGroup.add(sideburn);
  }

  return { hairGroup, hairTuft };
}

interface DetailedHeadBuild {
  headGroup: THREE.Group;
  hairTuft: THREE.Group;
  setBlink: (amount: number) => void;
}

/**
 * Builds a realistic human head with anatomical neck, sculpted cranium/jaw,
 * facial complexion map, recessed glossy eyes with corneal catchlights + blinking eyelids,
 * expressive eyebrows, multi-part nose, natural lips, ears, layered hair, and optional facial hair.
 */
function buildDetailedHumanHead(options: {
  skinMat: THREE.MeshPhysicalMaterial;
  faceSkinMat: THREE.MeshPhysicalMaterial;
  hairMat: THREE.MeshPhysicalMaterial;
  fadeMat: THREE.MeshStandardMaterial;
  hairStyle?: HairStyle;
  hasMoustache?: boolean;
  hasFullBeard?: boolean;
  hasStubble?: boolean;
  irisHex?: number;
  lipHex?: number;
  browFierce?: number;
}): DetailedHeadBuild {
  const headGroup = new THREE.Group();

  // 1. Sculpted anatomical neck (well-proportioned length seating head cleanly on collar)
  const neckGeo = createContouredLimbGeometry(
    [
      [0.0, 0.068],
      [0.28, 0.056],
      [0.62, 0.052],
      [0.88, 0.054],
      [1.0, 0.05],
    ],
    0.135,
    0.96,
    1.04,
    18,
    0.005,
  );
  const neck = new THREE.Mesh(neckGeo, options.skinMat);
  neck.position.set(0, -0.172, -0.008);
  neck.castShadow = true;
  headGroup.add(neck);

  // 2. Sculpted cranium, cheekbones, orbital cavities, jawline & chin with face complexion map
  const craniumGeo = createSculptedHeadGeometry();
  const cranium = new THREE.Mesh(craniumGeo, options.faceSkinMat);
  cranium.castShadow = true;
  cranium.receiveShadow = true;
  headGroup.add(cranium);

  // 3. Detailed Realistic Eyes (Warm Sclera + Iris + Pupil + Corneal Catchlight + Blinking Eyelids)
  const scleraMat = new THREE.MeshPhysicalMaterial({
    color: 0xf4eee6,
    roughness: 0.12,
    metalness: 0.0,
    clearcoat: 1.0,
    clearcoatRoughness: 0.05,
  });
  const irisMat = new THREE.MeshPhysicalMaterial({
    color: options.irisHex ?? 0x2c190f,
    roughness: 0.16,
    metalness: 0.05,
    clearcoat: 1.0,
    clearcoatRoughness: 0.04,
  });
  const pupilMat = new THREE.MeshBasicMaterial({ color: 0x080606 });
  const catchlightMat = new THREE.MeshBasicMaterial({ color: 0xfffbf2 });
  const lashMat = new THREE.MeshStandardMaterial({ color: 0x16110e, roughness: 0.85 });

  const blinkCaps: THREE.Mesh[] = [];

  for (const side of [-1, 1]) {
    const eyeGroup = new THREE.Group();
    eyeGroup.position.set(side * 0.034, 0.011, 0.088);
    eyeGroup.rotation.y = side * 0.11;
    headGroup.add(eyeGroup);

    const eyeball = new THREE.Mesh(new THREE.SphereGeometry(0.0145, 16, 14), scleraMat);
    eyeGroup.add(eyeball);

    const iris = new THREE.Mesh(new THREE.SphereGeometry(0.0082, 14, 10), irisMat);
    iris.scale.set(1, 1, 0.42);
    iris.position.set(0, 0, 0.012);
    eyeGroup.add(iris);

    const pupil = new THREE.Mesh(new THREE.SphereGeometry(0.0044, 12, 8), pupilMat);
    pupil.scale.set(1, 1, 0.38);
    pupil.position.set(0, 0, 0.014);
    eyeGroup.add(pupil);

    // Subtle corneal catchlight spark for natural living gaze
    const catchlight = new THREE.Mesh(new THREE.SphereGeometry(0.0017, 6, 6), catchlightMat);
    catchlight.position.set(0.0028, 0.0032, 0.0154);
    eyeGroup.add(catchlight);

    // Animated upper-eyelid blink shell hugging eyeball radius (rotates forward on blink)
    const blinkLidGeo = new THREE.SphereGeometry(0.0156, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.56);
    const blinkLid = new THREE.Mesh(blinkLidGeo, options.skinMat);
    blinkLid.rotation.x = -0.78; // open resting position
    eyeGroup.add(blinkLid);
    blinkCaps.push(blinkLid);

    // Sculpted upper eyelid fold + dark lash line
    const upperLidCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.016, -0.001, 0.006),
      new THREE.Vector3(-0.006, 0.0084, 0.0138),
      new THREE.Vector3(0.006, 0.0084, 0.0138),
      new THREE.Vector3(0.016, -0.001, 0.006),
    ]);
    const upperLid = new THREE.Mesh(
      new THREE.TubeGeometry(upperLidCurve, 10, 0.0036, 7, false),
      options.skinMat,
    );
    eyeGroup.add(upperLid);

    const lashLine = new THREE.Mesh(
      new THREE.TubeGeometry(upperLidCurve, 10, 0.0018, 6, false),
      lashMat,
    );
    lashLine.position.set(0, -0.0018, 0.0016);
    eyeGroup.add(lashLine);

    // Subtle lower eyelid rim
    const lowerLidCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.014, -0.002, 0.006),
      new THREE.Vector3(0, -0.0076, 0.0128),
      new THREE.Vector3(0.014, -0.002, 0.006),
    ]);
    const lowerLid = new THREE.Mesh(
      new THREE.TubeGeometry(lowerLidCurve, 8, 0.0026, 6, false),
      options.skinMat,
    );
    eyeGroup.add(lowerLid);

    // 4. Sculpted Natural Eyebrows
    const fierce = options.browFierce ?? 0.0038;
    const browCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(side * 0.013, 0.032 - fierce, 0.105),
      new THREE.Vector3(side * 0.034, 0.038, 0.104),
      new THREE.Vector3(side * 0.056, 0.034 + fierce * 0.35, 0.092),
    ]);
    const browGeo = new THREE.TubeGeometry(browCurve, 10, 0.0041, 7, false);
    const brow = new THREE.Mesh(browGeo, options.hairMat);
    headGroup.add(brow);
  }

  // 5. Sculpted Multi-Part Human Nose (bridge + rounded tip + alar nostril wings)
  const noseGroup = new THREE.Group();
  headGroup.add(noseGroup);

  const bridgeCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, 0.023, 0.103),
    new THREE.Vector3(0, -0.004, 0.113),
    new THREE.Vector3(0, -0.026, 0.121),
  ]);
  const bridgeGeo = new THREE.TubeGeometry(bridgeCurve, 10, 0.0086, 8, false);
  bridgeGeo.scale(0.84, 1.0, 1.04);
  const noseBridge = new THREE.Mesh(bridgeGeo, options.skinMat);
  noseBridge.castShadow = true;
  noseGroup.add(noseBridge);

  const noseTip = new THREE.Mesh(new THREE.SphereGeometry(0.0112, 14, 12), options.skinMat);
  noseTip.scale.set(1.06, 0.85, 1.06);
  noseTip.position.set(0, -0.028, 0.119);
  noseGroup.add(noseTip);

  const nostrilDarkMat = new THREE.MeshStandardMaterial({ color: 0x4b2c20, roughness: 0.9 });
  for (const side of [-1, 1]) {
    const wing = new THREE.Mesh(new THREE.SphereGeometry(0.0084, 10, 8), options.skinMat);
    wing.scale.set(0.95, 0.72, 1.08);
    wing.position.set(side * 0.011, -0.032, 0.111);
    noseGroup.add(wing);

    const nostril = new THREE.Mesh(new THREE.SphereGeometry(0.0035, 8, 6), nostrilDarkMat);
    nostril.scale.set(1.2, 0.45, 1.3);
    nostril.position.set(side * 0.007, -0.037, 0.113);
    noseGroup.add(nostril);
  }

  // 6. Sculpted Mouth & Natural Lips
  const lipMat = new THREE.MeshPhysicalMaterial({
    color: options.lipHex ?? 0x9c6252,
    roughness: 0.44,
    metalness: 0.0,
    sheen: 0.28,
    clearcoat: 0.12,
    clearcoatRoughness: 0.44,
  });
  const mouthLineMat = new THREE.MeshStandardMaterial({ color: 0x4c2920, roughness: 0.8 });

  const upperLipCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-0.022, -0.062, 0.097),
    new THREE.Vector3(-0.008, -0.0585, 0.106),
    new THREE.Vector3(0.0, -0.0605, 0.107),
    new THREE.Vector3(0.008, -0.0585, 0.106),
    new THREE.Vector3(0.022, -0.062, 0.097),
  ]);
  const upperLip = new THREE.Mesh(
    new THREE.TubeGeometry(upperLipCurve, 12, 0.0044, 7, false),
    lipMat,
  );
  headGroup.add(upperLip);

  const lowerLipCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-0.019, -0.064, 0.097),
    new THREE.Vector3(-0.007, -0.0685, 0.1065),
    new THREE.Vector3(0.007, -0.0685, 0.1065),
    new THREE.Vector3(0.019, -0.064, 0.097),
  ]);
  const lowerLip = new THREE.Mesh(
    new THREE.TubeGeometry(lowerLipCurve, 10, 0.0052, 7, false),
    lipMat,
  );
  headGroup.add(lowerLip);

  const mouthCreaseCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-0.021, -0.063, 0.098),
    new THREE.Vector3(0.0, -0.0635, 0.108),
    new THREE.Vector3(0.021, -0.063, 0.098),
  ]);
  const mouthCrease = new THREE.Mesh(
    new THREE.TubeGeometry(mouthCreaseCurve, 8, 0.0014, 5, false),
    mouthLineMat,
  );
  headGroup.add(mouthCrease);

  // Optional sharp trimmed Bengali hero moustache & jaw stubble / full beard
  if (options.hasMoustache) {
    for (const side of [-1, 1]) {
      const stacheCurve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(side * 0.002, -0.047, 0.111),
        new THREE.Vector3(side * 0.015, -0.049, 0.109),
        new THREE.Vector3(side * 0.029, -0.056, 0.099),
      ]);
      const stacheGeo = new THREE.TubeGeometry(stacheCurve, 10, options.hasFullBeard ? 0.0054 : 0.0042, 7, false);
      const stacheHalf = new THREE.Mesh(stacheGeo, options.hairMat);
      headGroup.add(stacheHalf);
    }
  }

  if (options.hasFullBeard) {
    const beardCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.068, -0.048, 0.026),
      new THREE.Vector3(-0.046, -0.096, 0.066),
      new THREE.Vector3(0.0, -0.112, 0.092),
      new THREE.Vector3(0.046, -0.096, 0.066),
      new THREE.Vector3(0.068, -0.048, 0.026),
    ]);
    const beardGeo = new THREE.TubeGeometry(beardCurve, 18, 0.013, 8, false);
    const beard = new THREE.Mesh(beardGeo, options.hairMat);
    headGroup.add(beard);
  } else if (options.hasStubble) {
    const stubbleCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.062, -0.062, 0.025),
      new THREE.Vector3(-0.04, -0.094, 0.064),
      new THREE.Vector3(0.0, -0.106, 0.088),
      new THREE.Vector3(0.04, -0.094, 0.064),
      new THREE.Vector3(0.062, -0.062, 0.025),
    ]);
    const stubbleGeo = new THREE.TubeGeometry(stubbleCurve, 16, 0.0054, 6, false);
    const stubble = new THREE.Mesh(stubbleGeo, options.fadeMat);
    headGroup.add(stubble);
  }

  // 7. Sculpted Ears
  for (const side of [-1, 1]) {
    const earGroup = new THREE.Group();
    earGroup.position.set(side * 0.095, -0.008, -0.008);
    earGroup.rotation.y = side * -0.34;
    earGroup.rotation.z = side * -0.12;
    headGroup.add(earGroup);

    const earShell = new THREE.Mesh(new THREE.TorusGeometry(0.019, 0.0056, 8, 14, Math.PI * 1.45), options.skinMat);
    earShell.rotation.z = side === 1 ? -Math.PI * 0.55 : Math.PI * 0.1;
    earShell.scale.set(0.72, 1.25, 0.72);
    earGroup.add(earShell);

    const earLobe = new THREE.Mesh(new THREE.SphereGeometry(0.0092, 10, 8), options.skinMat);
    earLobe.scale.set(0.62, 1.15, 0.78);
    earLobe.position.set(0, -0.017, 0.002);
    earGroup.add(earLobe);
  }

  // 8. Layered Natural Bengali Hair + Wind-Reactive Front Tuft
  const { hairGroup, hairTuft } = buildShortFadeHair(
    options.hairMat,
    options.fadeMat,
    options.hairStyle ?? 'hero-sweep',
  );
  headGroup.add(hairGroup);

  const setBlink = (amount: number): void => {
    const a = THREE.MathUtils.clamp(amount, 0, 1);
    // Open = -0.78 rad, Closed = +0.58 rad covering the iris cleanly
    const rx = THREE.MathUtils.lerp(-0.78, 0.58, a);
    for (let i = 0; i < blinkCaps.length; i++) {
      blinkCaps[i].rotation.x = rx;
    }
  };

  return { headGroup, hairTuft, setBlink };
}

// ============================================================================
// Articulated Hands with Individual Fingers
// ============================================================================

/**
 * Builds an anatomically contoured hand with palm, thumb pad, and 5 articulated fingers
 * (each finger composed of proximal + curled distal phalanges + knuckle joints).
 * Local space: wrist at (0,0,0), fingers extending along +Y, palm facing -X (for right) / +X (for left).
 */
function buildArticulatedHand(
  side: -1 | 1, // -1 = left hand, +1 = right hand
  skinMat: THREE.MeshPhysicalMaterial,
  pose: 'grip' | 'cradle' | 'relaxed',
  gloveMat?: THREE.MeshStandardMaterial,
): THREE.Group {
  const hand = new THREE.Group();
  const palmMat = gloveMat ?? skinMat;

  // Sculpted beveled palm
  const palmShape = new THREE.Shape();
  palmShape.moveTo(-0.033, 0.0);
  palmShape.quadraticCurveTo(-0.039, 0.042, -0.036, 0.078);
  palmShape.lineTo(0.036, 0.078);
  palmShape.quadraticCurveTo(0.039, 0.042, 0.033, 0.0);
  palmShape.closePath();

  const palmGeo = new THREE.ExtrudeGeometry(palmShape, {
    depth: 0.02,
    bevelEnabled: true,
    bevelThickness: 0.007,
    bevelSize: 0.006,
    bevelSegments: 3,
  });
  palmGeo.translate(0, 0, -0.01);
  palmGeo.computeVertexNormals();
  const palm = new THREE.Mesh(palmGeo, palmMat);
  palm.castShadow = true;
  hand.add(palm);

  // Thenar (thumb base) muscular mound
  const thenar = new THREE.Mesh(new THREE.SphereGeometry(0.018, 10, 8), palmMat);
  thenar.scale.set(0.85, 1.35, 0.85);
  thenar.position.set(-side * 0.024, 0.028, 0.012);
  hand.add(thenar);

  // 4 Articulated Fingers (Index, Middle, Ring, Pinky)
  const fingerSpecs = [
    { name: 'index', x: -side * 0.026, len1: 0.036, len2: 0.028, r: 0.0082 },
    { name: 'middle', x: -side * 0.009, len1: 0.041, len2: 0.031, r: 0.0084 },
    { name: 'ring', x: side * 0.009, len1: 0.037, len2: 0.028, r: 0.0079 },
    { name: 'pinky', x: side * 0.026, len1: 0.029, len2: 0.022, r: 0.0068 },
  ];

  for (let i = 0; i < fingerSpecs.length; i++) {
    const f = fingerSpecs[i];
    const fingerRoot = new THREE.Group();
    fingerRoot.position.set(f.x, 0.078, 0.002);

    // Curl angles based on pose (right trigger finger extended slightly forward on 'grip')
    let curl1 = 0.25;
    let curl2 = 0.35;
    if (pose === 'grip') {
      if (i === 0) {
        curl1 = 0.34; // trigger finger poised cleanly along trigger guard
        curl2 = 0.42;
      } else {
        curl1 = 0.92 + i * 0.06;
        curl2 = 1.05;
      }
    } else if (pose === 'cradle') {
      curl1 = 0.52 + i * 0.05;
      curl2 = 0.64;
    }

    fingerRoot.rotation.x = curl1;
    hand.add(fingerRoot);

    // Knuckle joint
    const knuckle = new THREE.Mesh(new THREE.SphereGeometry(f.r * 1.04, 8, 8), skinMat);
    fingerRoot.add(knuckle);

    // Proximal phalanx
    const phalanx1 = new THREE.Mesh(
      new THREE.CapsuleGeometry(f.r * 0.92, f.len1 * 0.55, 4, 8),
      skinMat,
    );
    phalanx1.position.y = f.len1 * 0.5;
    fingerRoot.add(phalanx1);

    // Distal phalanx group (articulated middle/tip curl)
    const distalGroup = new THREE.Group();
    distalGroup.position.y = f.len1;
    distalGroup.rotation.x = curl2;
    fingerRoot.add(distalGroup);

    const phalanx2 = new THREE.Mesh(
      new THREE.CapsuleGeometry(f.r * 0.78, f.len2 * 0.55, 4, 8),
      skinMat,
    );
    phalanx2.position.y = f.len2 * 0.5;
    distalGroup.add(phalanx2);
  }

  // Opposable Articulated Thumb (2 segments)
  const thumbRoot = new THREE.Group();
  thumbRoot.position.set(-side * 0.036, 0.036, 0.012);
  if (pose === 'grip') {
    thumbRoot.rotation.set(0.45, side * 0.55, side * 0.62);
  } else if (pose === 'cradle') {
    thumbRoot.rotation.set(0.32, side * 0.4, side * 0.48);
  } else {
    thumbRoot.rotation.set(0.2, side * 0.3, side * 0.35);
  }
  hand.add(thumbRoot);

  const thumbSeg1 = new THREE.Mesh(new THREE.CapsuleGeometry(0.0098, 0.022, 4, 8), skinMat);
  thumbSeg1.position.y = 0.016;
  thumbRoot.add(thumbSeg1);

  const thumbDistal = new THREE.Group();
  thumbDistal.position.y = 0.032;
  thumbDistal.rotation.x = pose === 'grip' ? 0.58 : 0.32;
  thumbRoot.add(thumbDistal);

  const thumbSeg2 = new THREE.Mesh(new THREE.CapsuleGeometry(0.0085, 0.018, 4, 8), skinMat);
  thumbSeg2.position.y = 0.014;
  thumbDistal.add(thumbSeg2);

  return hand;
}

// ============================================================================
// Multi-Part Sculpted Combat Boots & Articulated Legs
// ============================================================================

/**
 * Builds a detailed tactical combat boot with high-top ankle shaft, contoured leather vamp,
 * reinforced rounded toe cap, speed-lace straps, and thick lugged rubber outsole.
 * Pivot at ankle top (y = 0); outsole bottom touches y = -0.14 exactly.
 */
function buildCombatBoot(
  leatherMat: THREE.MeshStandardMaterial,
  soleMat: THREE.MeshStandardMaterial,
  metalMat: THREE.MeshStandardMaterial,
): THREE.Group {
  const boot = new THREE.Group();

  // 1. High-top laced ankle cuff (LatheGeometry tapering smoothly over ankle)
  const shaftGeo = createContouredLimbGeometry(
    [
      [0.0, 0.056],
      [0.35, 0.054],
      [0.72, 0.06],
      [1.0, 0.064],
    ],
    0.135,
    0.92,
    1.12,
    16,
  );
  const shaft = new THREE.Mesh(shaftGeo, leatherMat);
  shaft.position.set(0, -0.095, -0.008);
  shaft.castShadow = true;
  boot.add(shaft);

  // Padded collar rim at boot top
  const collar = new THREE.Mesh(new THREE.TorusGeometry(0.058, 0.012, 8, 16), soleMat);
  collar.rotation.x = Math.PI / 2;
  collar.scale.set(0.95, 1.12, 1.0);
  collar.position.set(0, 0.038, -0.008);
  boot.add(collar);

  // 2. Contoured instep & reinforced toe vamp
  const vampGeo = new THREE.SphereGeometry(0.064, 18, 14);
  vampGeo.scale(0.98, 0.68, 1.65);
  const vamp = new THREE.Mesh(vampGeo, leatherMat);
  vamp.position.set(0, -0.088, 0.062);
  vamp.castShadow = true;
  boot.add(vamp);

  // Reinforced rubber toe bumper cap
  const toeCapGeo = new THREE.SphereGeometry(0.058, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.65);
  toeCapGeo.scale(0.94, 0.62, 1.05);
  const toeCap = new THREE.Mesh(toeCapGeo, soleMat);
  toeCap.position.set(0, -0.096, 0.115);
  boot.add(toeCap);

  // 3. Thick lugged tactical outsole + heel block (bottom flush at y = -0.14)
  const soleShape = new THREE.Shape();
  soleShape.moveTo(-0.052, -0.072);
  soleShape.quadraticCurveTo(-0.058, 0.02, -0.062, 0.085);
  soleShape.quadraticCurveTo(-0.06, 0.172, 0.0, 0.184);
  soleShape.quadraticCurveTo(0.06, 0.172, 0.062, 0.085);
  soleShape.quadraticCurveTo(0.058, 0.02, 0.052, -0.072);
  soleShape.quadraticCurveTo(0.0, -0.086, -0.052, -0.072);

  const soleGeo = new THREE.ExtrudeGeometry(soleShape, {
    depth: 0.028,
    bevelEnabled: true,
    bevelThickness: 0.004,
    bevelSize: 0.004,
    bevelSegments: 2,
  });
  soleGeo.rotateX(Math.PI / 2);
  const sole = new THREE.Mesh(soleGeo, soleMat);
  sole.position.set(0, -0.108, 0.0);
  sole.castShadow = true;
  boot.add(sole);

  // Tactical speed-laces & metal lace eyelets along the front tongue
  for (let l = 0; l < 4; l++) {
    const ly = -0.062 + l * 0.024;
    const lz = 0.058 - l * 0.004;
    const lace = new THREE.Mesh(new THREE.CapsuleGeometry(0.004, 0.044, 3, 6), soleMat);
    lace.rotation.z = Math.PI / 2;
    lace.position.set(0, ly, lz);
    boot.add(lace);

    for (const sx of [-0.028, 0.028]) {
      const eyelet = new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.004, 0.006, 6), metalMat);
      eyelet.rotation.x = Math.PI / 2;
      eyelet.position.set(sx, ly, lz - 0.002);
      boot.add(eyelet);
    }
  }

  return boot;
}

/**
 * Builds an anatomically sculpted articulated leg (hip -> contoured thigh + cargo pocket
 * -> articulated knee + molded tactical knee pad -> contoured calf -> combat boot).
 * Hip pivot at y = 0.90; combat boot sole rests cleanly on y = 0.00.
 */
function buildSculptedLeg(options: {
  xOff: number;
  pantsMat: THREE.MeshStandardMaterial;
  kneePadMat: THREE.MeshStandardMaterial;
  bootLeatherMat: THREE.MeshStandardMaterial;
  bootSoleMat: THREE.MeshStandardMaterial;
  metalMat: THREE.MeshStandardMaterial;
  thicknessMult?: number;
  hasDropHolster?: boolean;
}): { hip: THREE.Group; knee: THREE.Group; ankle: THREE.Group } {
  const mult = options.thicknessMult ?? 1.0;
  const hip = new THREE.Group();
  hip.position.set(options.xOff, 0.9, 0);

  // Hip joint sphere so leg swings cleanly inside pelvis/tunic hem
  const hipCap = new THREE.Mesh(new THREE.SphereGeometry(0.095 * mult, 14, 12), options.pantsMat);
  hipCap.scale.set(0.96, 1.0, 1.04);
  hip.add(hipCap);

  // Sculpted thigh (quadriceps + hamstring taper from hip 0 down to knee -0.41)
  const thighGeo = createContouredLimbGeometry(
    [
      [0.0, 0.066 * mult], // knee top
      [0.25, 0.078 * mult],
      [0.58, 0.094 * mult], // full quadriceps
      [0.85, 0.098 * mult], // upper thigh
      [1.0, 0.092 * mult], // hip socket
    ],
    0.41,
    0.95,
    1.08,
    20,
    0.008,
  );
  const thigh = new THREE.Mesh(thighGeo, options.pantsMat);
  thigh.position.y = -0.41;
  thigh.castShadow = true;
  hip.add(thigh);

  // Sculpted tactical cargo pocket on outer thigh
  const sideSign = Math.sign(options.xOff) || 1;
  const pocketShape = new THREE.Shape();
  pocketShape.moveTo(-0.052, -0.065);
  pocketShape.lineTo(0.052, -0.065);
  pocketShape.lineTo(0.056, 0.055);
  pocketShape.lineTo(-0.056, 0.055);
  pocketShape.closePath();

  const pocketGeo = new THREE.ExtrudeGeometry(pocketShape, {
    depth: 0.018,
    bevelEnabled: true,
    bevelThickness: 0.005,
    bevelSize: 0.005,
    bevelSegments: 2,
  });
  const pocket = new THREE.Mesh(pocketGeo, options.pantsMat);
  pocket.rotation.y = sideSign * (Math.PI / 2);
  pocket.position.set(sideSign * (0.082 * mult), -0.22, 0.005);
  pocket.castShadow = true;
  hip.add(pocket);

  // Optional tactical drop-leg utility strap on right thigh
  if (options.hasDropHolster) {
    const strap = new THREE.Mesh(
      new THREE.TorusGeometry(0.092 * mult, 0.01, 6, 18),
      options.kneePadMat,
    );
    strap.rotation.x = Math.PI / 2;
    strap.scale.set(0.96, 1.1, 1.0);
    strap.position.set(0, -0.17, 0);
    hip.add(strap);
  }

  // Articulated Knee Group at local y = -0.41
  const knee = new THREE.Group();
  knee.position.set(0, -0.41, 0);
  hip.add(knee);

  const kneeJoint = new THREE.Mesh(new THREE.SphereGeometry(0.067 * mult, 14, 12), options.pantsMat);
  knee.add(kneeJoint);

  // Molded tactical knee pad shell + elastic strap
  const padGeo = new THREE.SphereGeometry(0.052 * mult, 14, 12, 0, Math.PI * 2, 0, Math.PI * 0.55);
  padGeo.rotateX(Math.PI / 2);
  padGeo.scale(0.95, 1.24, 0.68);
  const kneePad = new THREE.Mesh(padGeo, options.kneePadMat);
  kneePad.position.set(0, -0.01, 0.055 * mult);
  kneePad.castShadow = true;
  knee.add(kneePad);

  const kneeStrap = new THREE.Mesh(
    new THREE.TorusGeometry(0.066 * mult, 0.009, 6, 16),
    options.kneePadMat,
  );
  kneeStrap.rotation.x = Math.PI / 2;
  kneeStrap.position.set(0, -0.015, 0);
  knee.add(kneeStrap);

  // Sculpted lower leg / cargo trouser calf tucked into combat boot (knee 0 down to ankle -0.35)
  const calfGeo = createContouredLimbGeometry(
    [
      [0.0, 0.052 * mult], // ankle tuck
      [0.25, 0.061 * mult],
      [0.62, 0.075 * mult], // gastrocnemius calf belly
      [0.88, 0.071 * mult],
      [1.0, 0.065 * mult], // knee bottom
    ],
    0.35,
    0.95,
    1.06,
    18,
    -0.009, // calf muscle protrudes subtly backward
  );
  const calf = new THREE.Mesh(calfGeo, options.pantsMat);
  calf.position.y = -0.35;
  calf.castShadow = true;
  knee.add(calf);

  // Articulated Ankle Pivot at local y = -0.35 (combat boot sole touches -0.35 - 0.14 = -0.49 -> y = 0.00!)
  const ankle = new THREE.Group();
  ankle.position.set(0, -0.35, 0);
  knee.add(ankle);

  const boot = buildCombatBoot(options.bootLeatherMat, options.bootSoleMat, options.metalMat);
  ankle.add(boot);

  return { hip, knee, ankle };
}

// ============================================================================
// Watertight Two-Bone Sculpted Arm + Rolled Sleeve + Articulated Hand Builder
// ============================================================================

function orientSegment(
  mesh: THREE.Object3D,
  start: THREE.Vector3,
  end: THREE.Vector3,
): number {
  _dir.subVectors(end, start);
  const len = _dir.length();
  _mid.copy(start);
  mesh.position.copy(_mid);
  if (len > 0.0001) {
    _dir.divideScalar(len);
    _quat.setFromUnitVectors(_up, _dir);
    mesh.quaternion.copy(_quat);
  }
  return len;
}

function buildSculptedArm(options: {
  side: -1 | 1;
  shoulderWorld: THREE.Vector3;
  elbowWorld: THREE.Vector3;
  wristWorld: THREE.Vector3;
  sleeveMat: THREE.MeshStandardMaterial;
  skinMat: THREE.MeshPhysicalMaterial;
  handPose: 'grip' | 'cradle' | 'relaxed';
  handRollOffset?: number;
  rolledSleeve?: boolean;
  fullSleeve?: boolean;
  watchMat?: THREE.MeshStandardMaterial;
  gloveMat?: THREE.MeshStandardMaterial;
  thicknessMult?: number;
}): THREE.Group {
  const mult = options.thicknessMult ?? 1.0;
  // Outer root stays at local (0, 0, 0) so small animation offsets on leftArm/rightArm.position
  // never detach the shoulder from the upper torso joint!
  const armRoot = new THREE.Group();
  const shoulderPivot = new THREE.Group();
  shoulderPivot.position.copy(options.shoulderWorld);
  armRoot.add(shoulderPivot);

  // Local coordinates relative to upper shoulder joint
  const p0 = new THREE.Vector3(0, 0, 0);
  const pElbow = options.elbowWorld.clone().sub(options.shoulderWorld);
  const pWrist = options.wristWorld.clone().sub(options.shoulderWorld);

  // Clavicle-to-deltoid shoulder socket cap blending the sleeve smoothly into the upper torso yoke
  const socketCap = new THREE.Mesh(new THREE.SphereGeometry(0.068 * mult, 16, 14), options.sleeveMat);
  socketCap.scale.set(1.08, 0.96, 1.04);
  socketCap.position.set(-options.side * 0.028 * mult, 0.008, 0.002);
  socketCap.castShadow = true;
  shoulderPivot.add(socketCap);

  // Sculpted deltoid shoulder cap anchored cleanly at the upper shoulder joint
  const deltoid = new THREE.Mesh(new THREE.SphereGeometry(0.068 * mult, 16, 14), options.sleeveMat);
  deltoid.scale.set(0.94, 1.06, 1.04);
  deltoid.castShadow = true;
  shoulderPivot.add(deltoid);

  // Upper arm (shoulder -> elbow)
  const upperLen = p0.distanceTo(pElbow);
  const upperGeo = createContouredLimbGeometry(
    [
      [0.0, 0.065 * mult], // deltoid base
      [0.32, 0.059 * mult], // bicep belly
      [0.68, 0.053 * mult],
      [1.0, 0.046 * mult], // elbow
    ],
    upperLen,
    0.96,
    1.04,
    16,
  );
  const upperMesh = new THREE.Mesh(upperGeo, options.sleeveMat);
  orientSegment(upperMesh, p0, pElbow);
  upperMesh.castShadow = true;
  shoulderPivot.add(upperMesh);

  // Rolled-up tactical kurta cuff near elbow (for Hero / Rusher)
  if (options.rolledSleeve) {
    const cuffHolder = new THREE.Group();
    orientSegment(cuffHolder, p0, pElbow);
    const cuff = new THREE.Mesh(
      new THREE.TorusGeometry(0.05 * mult, 0.011 * mult, 8, 16),
      options.sleeveMat,
    );
    cuff.rotation.x = Math.PI / 2;
    cuff.position.y = upperLen * 0.88;
    cuffHolder.add(cuff);
    shoulderPivot.add(cuffHolder);
  }

  // Sculpted elbow joint
  const elbowJoint = new THREE.Mesh(
    new THREE.SphereGeometry(0.045 * mult, 12, 10),
    options.fullSleeve ? options.sleeveMat : options.skinMat,
  );
  elbowJoint.position.copy(pElbow);
  shoulderPivot.add(elbowJoint);

  // Forearm (elbow -> wrist) with realistic brachioradialis muscular taper
  const foreLen = pElbow.distanceTo(pWrist);
  const foreGeo = createContouredLimbGeometry(
    [
      [0.0, 0.046 * mult], // elbow
      [0.26, 0.051 * mult], // brachioradialis muscle bulge
      [0.64, 0.041 * mult],
      [1.0, 0.033 * mult], // tapered wrist
    ],
    foreLen,
    0.96,
    1.05,
    16,
  );
  const foreMesh = new THREE.Mesh(
    foreGeo,
    options.fullSleeve ? options.sleeveMat : options.skinMat,
  );
  orientSegment(foreMesh, pElbow, pWrist);
  foreMesh.castShadow = true;
  shoulderPivot.add(foreMesh);

  // Optional rugged field wristwatch on left wrist
  if (options.watchMat) {
    const watchHolder = new THREE.Group();
    orientSegment(watchHolder, pElbow, pWrist);
    const strap = new THREE.Mesh(
      new THREE.TorusGeometry(0.036 * mult, 0.006, 6, 14),
      options.watchMat,
    );
    strap.rotation.x = Math.PI / 2;
    strap.position.y = foreLen * 0.86;
    watchHolder.add(strap);

    const dial = new THREE.Mesh(
      new THREE.CylinderGeometry(0.016, 0.016, 0.008, 12),
      options.watchMat,
    );
    dial.rotation.z = Math.PI / 2;
    dial.position.set(-0.036 * mult, foreLen * 0.86, 0.006);
    watchHolder.add(dial);
    shoulderPivot.add(watchHolder);
  }

  // Articulated Hand with 5 fingers anchored directly at the wrist
  const handMount = new THREE.Group();
  orientSegment(handMount, pElbow, pWrist);
  handMount.position.copy(pWrist);
  const hand = buildArticulatedHand(options.side, options.skinMat, options.handPose, options.gloveMat);
  if (options.handRollOffset) {
    hand.rotation.y = options.handRollOffset;
  }
  handMount.add(hand);
  shoulderPivot.add(handMount);

  return armRoot;
}

// ============================================================================
// Physics-Animated Cloth Red-and-White Gamcha System (Verlet + Constraints)
// ============================================================================

interface GamchaClothController {
  tailMesh: THREE.Mesh;
  update: (
    dt: number,
    time: number,
    localVelX: number,
    localVelY: number,
    localVelZ: number,
    yawRate: number,
    windBoost: number,
  ) => void;
}

/**
 * Builds the hero's traditional Bengali red-and-white checkered gamcha draped organically
 * around his collar/shoulder plus a real-time Verlet cloth-physics trailing tail mesh
 * with woven fringe, wind turbulence, movement inertia, turning whip, and torso collision avoidance.
 * Mounted inside upperBodyGroup (pivoted at lumbar waist y = 0.94).
 */
function createGamchaClothSystem(
  upperBodyGroup: THREE.Group,
  gamchaMat: THREE.MeshPhysicalMaterial,
): GamchaClothController {
  const WY = 0.94; // upperBodyGroup lumbar waist offset

  // 1. Sculpted draped neck collar wrap (two organic overlapping curved cloth folds)
  const collarPts1 = [
    new THREE.Vector3(-0.112, 1.488 - WY, 0.045),
    new THREE.Vector3(-0.055, 1.456 - WY, 0.118),
    new THREE.Vector3(0.045, 1.46 - WY, 0.115),
    new THREE.Vector3(0.11, 1.486 - WY, 0.048),
    new THREE.Vector3(0.115, 1.5 - WY, -0.045),
    new THREE.Vector3(0.045, 1.508 - WY, -0.102),
    new THREE.Vector3(-0.068, 1.502 - WY, -0.098),
    new THREE.Vector3(-0.125, 1.49 - WY, -0.032),
  ];
  const collarCurve1 = new THREE.CatmullRomCurve3(collarPts1, true);
  const collarGeo1 = new THREE.TubeGeometry(collarCurve1, 32, 0.029, 10, true);
  collarGeo1.computeVertexNormals();
  const collarFold1 = new THREE.Mesh(collarGeo1, gamchaMat);
  collarFold1.castShadow = true;
  upperBodyGroup.add(collarFold1);

  // Secondary shoulder drape fold flowing over the left collarbone & shoulder blade
  const drapeCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0.055, 1.425 - WY, 0.124),
    new THREE.Vector3(-0.065, 1.396 - WY, 0.144),
    new THREE.Vector3(-0.152, 1.468 - WY, 0.092),
    new THREE.Vector3(-0.18, 1.488 - WY, -0.015),
    new THREE.Vector3(-0.15, 1.458 - WY, -0.122),
  ]);
  const drapeGeo = new THREE.TubeGeometry(drapeCurve, 22, 0.035, 10, false);
  drapeGeo.computeVertexNormals();
  const shoulderDrape = new THREE.Mesh(drapeGeo, gamchaMat);
  shoulderDrape.castShadow = true;
  upperBodyGroup.add(shoulderDrape);

  // Front chest sash panel hugging the left chest diagonally down toward the waist belt
  const sashCols = 5;
  const sashRows = 10;
  const sashGeo = new THREE.PlaneGeometry(0.16, 0.56, sashCols - 1, sashRows - 1);
  const sPos = sashGeo.attributes.position;
  const sashBaseZ = new Float32Array(sashCols * sashRows);
  for (let r = 0; r < sashRows; r++) {
    const v = r / (sashRows - 1);
    for (let c = 0; c < sashCols; c++) {
      const u = c / (sashCols - 1) - 0.5;
      const idx = r * sashCols + c;
      const x = THREE.MathUtils.lerp(-0.142, 0.048, v) + u * (0.142 + v * 0.02);
      const y = THREE.MathUtils.lerp(1.48 - WY, 0.96 - WY, v);
      const chestCurve = Math.sin(v * Math.PI) * 0.044;
      const fold = Math.sin(u * Math.PI * 2.5 + v * 3.0) * 0.008;
      const z = 0.126 + chestCurve - Math.abs(x) * 0.18 + fold;
      sashBaseZ[idx] = z;
      sPos.setXYZ(idx, x, y, z);
    }
  }
  sashGeo.computeVertexNormals();
  const chestSash = new THREE.Mesh(sashGeo, gamchaMat);
  chestSash.castShadow = true;
  upperBodyGroup.add(chestSash);

  // 2. Real-Time Verlet Physics Cloth Tail hanging over & behind left shoulder
  const COLS = 8;
  const ROWS = 15;
  const COUNT = COLS * ROWS;
  const clothWidth = 0.24;
  const clothLength = 0.9;
  const dxRest = clothWidth / (COLS - 1);
  const dyRest = clothLength / (ROWS - 1);
  const diagRest = Math.hypot(dxRest, dyRest);

  const tailGeo = new THREE.PlaneGeometry(clothWidth, clothLength, COLS - 1, ROWS - 1);
  const curr = new Float32Array(COUNT * 3);
  const prev = new Float32Array(COUNT * 3);
  const pinned = new Uint8Array(COUNT);

  const posAttr = tailGeo.attributes.position as THREE.BufferAttribute;
  for (let r = 0; r < ROWS; r++) {
    const vr = r / (ROWS - 1);
    for (let c = 0; c < COLS; c++) {
      const uc = c / (COLS - 1) - 0.5;
      const i = r * COLS + c;
      const i3 = i * 3;
      const x = -0.142 + uc * clothWidth * (1.0 + vr * 0.15) - vr * 0.028;
      const y = 1.458 - WY - r * dyRest * 0.96;
      const z = -0.132 - Math.sin(vr * Math.PI * 0.65) * 0.088 - Math.abs(uc) * 0.024;

      curr[i3] = x;
      curr[i3 + 1] = y;
      curr[i3 + 2] = z;
      prev[i3] = x;
      prev[i3 + 1] = y;
      prev[i3 + 2] = z;

      if (r === 0) pinned[i] = 1;
      posAttr.setXYZ(i, x, y, z);
    }
  }
  tailGeo.computeVertexNormals();

  const tailMesh = new THREE.Mesh(tailGeo, gamchaMat);
  tailMesh.castShadow = true;
  tailMesh.frustumCulled = false;
  upperBodyGroup.add(tailMesh);

  // Subtle handloom cotton fringe tassels trailing along the bottom edge of the gamcha
  const fringeMat = new THREE.MeshStandardMaterial({
    color: 0xf4ece0,
    roughness: 0.92,
  });
  const fringeGeo = new THREE.CylinderGeometry(0.0045, 0.0025, 0.068, 5);
  fringeGeo.translate(0, -0.034, 0);
  const tassels: THREE.Mesh[] = [];
  for (let c = 0; c < COLS; c++) {
    const tassel = new THREE.Mesh(fringeGeo, fringeMat);
    tassel.frustumCulled = false;
    upperBodyGroup.add(tassel);
    tassels.push(tassel);
  }

  // Flat constraint pair index lists (structural + shear + bend)
  const cA: number[] = [];
  const cB: number[] = [];
  const cRest: number[] = [];
  const addConstraint = (a: number, b: number, rest: number) => {
    cA.push(a);
    cB.push(b);
    cRest.push(rest);
  };

  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      const i = r * COLS + c;
      if (c + 1 < COLS) addConstraint(i, i + 1, dxRest);
      if (r + 1 < ROWS) addConstraint(i, i + COLS, dyRest);
      if (c + 1 < COLS && r + 1 < ROWS) {
        addConstraint(i, i + COLS + 1, diagRest);
        addConstraint(i + 1, i + COLS, diagRest);
      }
      if (r + 2 < ROWS) addConstraint(i, i + COLS * 2, dyRest * 2);
    }
  }
  const constraintCount = cA.length;

  // Back/torso ellipsoid collision center & radii in upperBodyGroup local space
  const colCx = 0.0;
  const colCy = 1.15 - WY;
  const colCz = -0.015;
  const colRx = 0.228;
  const colRy = 0.38;
  const colRz = 0.16;

  const update = (
    dt: number,
    time: number,
    localVelX: number,
    localVelY: number,
    localVelZ: number,
    yawRate: number,
    windBoost: number,
  ): void => {
    const stepDt = Math.min(dt, 0.032);
    const dtSq = stepDt * stepDt;
    const damping = 0.946;

    // 1. Subtle wind & breathing flutter on front chest sash lower folds
    for (let r = 2; r < sashRows; r++) {
      const v = r / (sashRows - 1);
      const amp = v * v * (0.0045 + windBoost * 0.0055);
      for (let c = 0; c < sashCols; c++) {
        const idx = r * sashCols + c;
        const ripple = Math.sin(time * 4.4 - r * 0.55 + c * 0.7) * amp;
        sPos.setZ(idx, sashBaseZ[idx] + ripple);
      }
    }
    sPos.needsUpdate = true;

    // 2. Verlet integration with gravity, Bengal breeze gusts, movement drag & turn whip
    for (let r = 1; r < ROWS; r++) {
      const vr = r / (ROWS - 1);
      const airExposure = 0.36 + vr * 0.88;

      for (let c = 0; c < COLS; c++) {
        const i = r * COLS + c;
        const i3 = i * 3;
        const x = curr[i3];
        const y = curr[i3 + 1];
        const z = curr[i3 + 2];

        const vx = (x - prev[i3]) * damping;
        const vy = (y - prev[i3 + 1]) * damping;
        const vz = (z - prev[i3 + 2]) * damping;

        prev[i3] = x;
        prev[i3 + 1] = y;
        prev[i3 + 2] = z;

        const wave1 = Math.sin(time * 5.0 - r * 0.45 + c * 0.34);
        const wave2 = Math.cos(time * 8.2 - r * 0.68 - c * 0.52);
        const gust = 1.0 + 0.42 * Math.sin(time * 1.8 + c * 0.22);

        const breezeZ = (-2.4 - windBoost * 9.2) * gust + wave1 * (1.85 + windBoost * 2.5);
        const breezeX = (-0.78 + wave2 * (1.42 + windBoost * 1.85)) * airExposure;
        const breezeY = Math.sin(time * 6.2 - r * 0.48) * (0.65 + windBoost * 1.45) * vr;

        const dragX = (-localVelX * 1.72 - yawRate * 2.2 * vr) * airExposure;
        const dragY = (-localVelY * 1.25) * airExposure;
        const dragZ = (-localVelZ * 1.92 - Math.abs(yawRate) * 1.45 * vr) * airExposure;

        curr[i3] = x + vx + (breezeX + dragX) * dtSq;
        curr[i3 + 1] = y + vy + (-10.6 + breezeY + dragY) * dtSq;
        curr[i3 + 2] = z + vz + (breezeZ * airExposure + dragZ) * dtSq;
      }
    }

    // 3. Iterative distance constraints + torso ellipsoid push-out
    for (let iter = 0; iter < 4; iter++) {
      for (let k = 0; k < constraintCount; k++) {
        const ia = cA[k];
        const ib = cB[k];
        const a3 = ia * 3;
        const b3 = ib * 3;

        const dx = curr[b3] - curr[a3];
        const dy = curr[b3 + 1] - curr[a3 + 1];
        const dz = curr[b3 + 2] - curr[a3 + 2];
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz) || 0.0001;
        const diff = (dist - cRest[k]) / dist;

        const pinA = pinned[ia];
        const pinB = pinned[ib];
        if (pinA && pinB) continue;

        if (pinA) {
          curr[b3] -= dx * diff;
          curr[b3 + 1] -= dy * diff;
          curr[b3 + 2] -= dz * diff;
        } else if (pinB) {
          curr[a3] += dx * diff;
          curr[a3 + 1] += dy * diff;
          curr[a3 + 2] += dz * diff;
        } else {
          const half = diff * 0.5;
          curr[a3] += dx * half;
          curr[a3 + 1] += dy * half;
          curr[a3 + 2] += dz * half;
          curr[b3] -= dx * half;
          curr[b3 + 1] -= dy * half;
          curr[b3 + 2] -= dz * half;
        }
      }

      for (let i = COLS; i < COUNT; i++) {
        const i3 = i * 3;
        const ex = (curr[i3] - colCx) / colRx;
        const ey = (curr[i3 + 1] - colCy) / colRy;
        const ez = (curr[i3 + 2] - colCz) / colRz;
        const dSq = ex * ex + ey * ey + ez * ez;
        if (dSq < 1.0 && dSq > 0.0001) {
          const inv = 1.0 / Math.sqrt(dSq);
          curr[i3] = colCx + ex * inv * colRx;
          curr[i3 + 1] = colCy + ey * inv * colRy;
          curr[i3 + 2] = Math.min(curr[i3 + 2], colCz + ez * inv * colRz - 0.012);
        }
        if (curr[i3 + 1] < 0.08 - WY) {
          curr[i3 + 1] = 0.08 - WY;
        }
      }
    }

    // 4. Upload deformed positions to GPU, recompute smooth normals & align bottom fringe tassels
    const arr = posAttr.array as Float32Array;
    arr.set(curr);
    posAttr.needsUpdate = true;
    tailGeo.computeVertexNormals();

    const lastRow = ROWS - 1;
    const prevRow = ROWS - 2;
    for (let c = 0; c < COLS; c++) {
      const iCur = (lastRow * COLS + c) * 3;
      const iPrev = (prevRow * COLS + c) * 3;
      const tassel = tassels[c];
      tassel.position.set(curr[iCur], curr[iCur + 1], curr[iCur + 2]);
      _dir.set(
        curr[iCur] - curr[iPrev],
        curr[iCur + 1] - curr[iPrev + 1],
        curr[iCur + 2] - curr[iPrev + 2],
      );
      if (_dir.lengthSq() > 0.00001) {
        _dir.normalize();
        // Tassel cylinder points along -Y from anchor, so orient -up toward travel direction
        _quat.setFromUnitVectors(_up, _dir.negate());
        tassel.quaternion.copy(_quat);
      }
    }
  };

  return { tailMesh, update };
}

/**
 * Lightweight zero-GC procedural flowing cloth ribbon for enemy scarves,
 * headband tails, and warrior shoulder shawls responding to speed, turns, and breeze.
 */
function createFlowingClothRibbon(options: {
  parent: THREE.Object3D;
  material: THREE.Material;
  anchor: THREE.Vector3;
  width: number;
  length: number;
  cols?: number;
  rows?: number;
  phaseOffset?: number;
  spreadX?: number;
}): (time: number, speed: number, yawRate: number, windBoost: number) => void {
  const COLS = options.cols ?? 4;
  const ROWS = options.rows ?? 9;
  const geo = new THREE.PlaneGeometry(options.width, options.length, COLS - 1, ROWS - 1);
  const pos = geo.attributes.position as THREE.BufferAttribute;
  const mesh = new THREE.Mesh(geo, options.material);
  mesh.castShadow = true;
  mesh.frustumCulled = false;
  options.parent.add(mesh);

  const ax = options.anchor.x;
  const ay = options.anchor.y;
  const az = options.anchor.z;
  const phase = options.phaseOffset ?? 0;
  const spreadX = options.spreadX ?? 0;

  const update = (time: number, speed: number, yawRate: number, windBoost: number): void => {
    const flow = THREE.MathUtils.clamp(speed * 0.12 + windBoost * 0.55, 0.12, 1.45);
    const freq = 4.6 + speed * 0.55;
    for (let r = 0; r < ROWS; r++) {
      const vr = r / (ROWS - 1);
      const lift = vr * vr * flow * 0.42;
      const backZ = az - vr * (0.08 + flow * 0.34) - Math.sin(vr * Math.PI * 0.7) * 0.04;
      const dropY = ay - vr * options.length * (1.0 - lift * 0.48);
      const waveX =
        Math.sin(time * freq - vr * 3.8 + phase) * vr * (0.032 + flow * 0.042) -
        yawRate * vr * vr * 0.095 +
        spreadX * vr;
      const waveZ = Math.cos(time * (freq * 1.18) - vr * 4.4 + phase) * vr * (0.018 + flow * 0.028);

      for (let c = 0; c < COLS; c++) {
        const uc = c / (COLS - 1) - 0.5;
        const idx = r * COLS + c;
        const x = ax + uc * options.width * (1 + vr * 0.15) + waveX;
        const y = dropY + Math.sin(time * 3.2 - vr * 2.5 + uc * 1.8) * vr * 0.015;
        const z = backZ + waveZ - Math.abs(uc) * 0.018;
        pos.setXYZ(idx, x, y, z);
      }
    }
    pos.needsUpdate = true;
    geo.computeVertexNormals();
  };

  update(0, 0, 0, 0.25);
  return update;
}

// ============================================================================
// Detailed Multi-Part Tactical Firearms (Carbine Rifle & Pump-Action Shotgun)
// ============================================================================

function buildDetailedCarbine(
  gunMetalMat: THREE.MeshStandardMaterial,
  gunDarkMat: THREE.MeshStandardMaterial,
  gunWoodMat: THREE.MeshStandardMaterial,
): THREE.Group {
  const rifle = new THREE.Group();

  // Sculpted stock with rubber buttpad
  const stockShape = new THREE.Shape();
  stockShape.moveTo(0, 0.035);
  stockShape.lineTo(-0.28, 0.02);
  stockShape.lineTo(-0.29, -0.09);
  stockShape.lineTo(-0.18, -0.068);
  stockShape.lineTo(0, -0.02);
  stockShape.closePath();

  const stockGeo = new THREE.ExtrudeGeometry(stockShape, {
    depth: 0.044,
    bevelEnabled: true,
    bevelThickness: 0.007,
    bevelSize: 0.006,
    bevelSegments: 2,
  });
  stockGeo.rotateY(Math.PI / 2);
  stockGeo.translate(-0.022, -0.015, 0.0);
  const stock = new THREE.Mesh(stockGeo, gunWoodMat);
  stock.castShadow = true;
  rifle.add(stock);

  // Angled ergonomic pistol grip positioned precisely inside the hero's right hand
  const grip = new THREE.Mesh(new THREE.CapsuleGeometry(0.024, 0.095, 5, 10), gunDarkMat);
  grip.position.set(0, -0.068, 0.025);
  grip.rotation.x = -0.32;
  rifle.add(grip);

  // Trigger guard loop
  const guard = new THREE.Mesh(new THREE.TorusGeometry(0.025, 0.0045, 6, 12), gunMetalMat);
  guard.rotation.y = Math.PI / 2;
  guard.position.set(0, -0.048, 0.085);
  rifle.add(guard);

  // Beveled steel receiver body + top Picatinny rail
  const receiverShape = new THREE.Shape();
  receiverShape.moveTo(-0.032, -0.042);
  receiverShape.lineTo(0.032, -0.042);
  receiverShape.lineTo(0.035, 0.028);
  receiverShape.lineTo(0.024, 0.046);
  receiverShape.lineTo(-0.024, 0.046);
  receiverShape.lineTo(-0.035, 0.028);
  receiverShape.closePath();

  const receiverGeo = new THREE.ExtrudeGeometry(receiverShape, {
    depth: 0.34,
    bevelEnabled: true,
    bevelThickness: 0.006,
    bevelSize: 0.005,
    bevelSegments: 2,
  });
  const receiver = new THREE.Mesh(receiverGeo, gunMetalMat);
  receiver.position.set(0, 0.012, -0.02);
  receiver.castShadow = true;
  rifle.add(receiver);

  // Compact tactical reflex optic sight on top rail
  const opticHousing = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.075, 12), gunDarkMat);
  opticHousing.rotation.x = Math.PI / 2;
  opticHousing.position.set(0, 0.082, 0.12);
  rifle.add(opticHousing);

  const opticMount = new THREE.Mesh(new THREE.BoxGeometry(0.032, 0.024, 0.048), gunMetalMat);
  opticMount.position.set(0, 0.064, 0.12);
  rifle.add(opticMount);

  // Curved tactical rifle magazine
  const magCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, -0.02, 0.21),
    new THREE.Vector3(0, -0.11, 0.23),
    new THREE.Vector3(0, -0.19, 0.275),
  ]);
  const magGeo = new THREE.TubeGeometry(magCurve, 8, 0.024, 8, false);
  magGeo.translate(0, 0, -0.23);
  magGeo.scale(0.65, 1.0, 1.3);
  magGeo.translate(0, 0, 0.23);
  const mag = new THREE.Mesh(magGeo, gunDarkMat);
  mag.castShadow = true;
  rifle.add(mag);

  // Contoured wooden/tactical ribbed handguard (cradled by left hand)
  const handguard = new THREE.Mesh(new THREE.CylinderGeometry(0.031, 0.034, 0.28, 12), gunWoodMat);
  handguard.rotation.x = Math.PI / 2;
  handguard.scale.set(0.95, 1.0, 1.15);
  handguard.position.set(0, 0.012, 0.44);
  handguard.castShadow = true;
  rifle.add(handguard);

  // Gas block + front sight post
  const frontSight = new THREE.Mesh(new THREE.BoxGeometry(0.014, 0.056, 0.032), gunMetalMat);
  frontSight.position.set(0, 0.052, 0.64);
  rifle.add(frontSight);

  // Fluted barrel + tactical flash hider muzzle brake
  const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.018, 0.42, 12), gunMetalMat);
  barrel.rotation.x = Math.PI / 2;
  barrel.position.set(0, 0.026, 0.72);
  barrel.castShadow = true;
  rifle.add(barrel);

  const muzzleBrake = new THREE.Mesh(new THREE.CylinderGeometry(0.021, 0.019, 0.068, 10), gunDarkMat);
  muzzleBrake.rotation.x = Math.PI / 2;
  muzzleBrake.position.set(0, 0.026, 0.93);
  rifle.add(muzzleBrake);

  return rifle;
}

function buildDetailedShotgun(
  gunMetalMat: THREE.MeshStandardMaterial,
  gunDarkMat: THREE.MeshStandardMaterial,
  gunWoodMat: THREE.MeshStandardMaterial,
): THREE.Group {
  const shotgun = new THREE.Group();

  const brassMat = new THREE.MeshStandardMaterial({
    color: 0xdca73c,
    roughness: 0.24,
    metalness: 0.9,
  });
  const shellRedMat = new THREE.MeshStandardMaterial({
    color: 0xb82222,
    roughness: 0.42,
    metalness: 0.05,
  });

  // Ergonomic walnut shotgun stock
  const stockShape = new THREE.Shape();
  stockShape.moveTo(0.02, 0.028);
  stockShape.lineTo(-0.3, -0.01);
  stockShape.lineTo(-0.31, -0.115);
  stockShape.lineTo(-0.14, -0.07);
  stockShape.lineTo(0.02, -0.035);
  stockShape.closePath();

  const stockGeo = new THREE.ExtrudeGeometry(stockShape, {
    depth: 0.048,
    bevelEnabled: true,
    bevelThickness: 0.008,
    bevelSize: 0.007,
    bevelSegments: 2,
  });
  stockGeo.rotateY(Math.PI / 2);
  stockGeo.translate(-0.024, -0.015, 0.0);
  const stock = new THREE.Mesh(stockGeo, gunWoodMat);
  stock.castShadow = true;
  shotgun.add(stock);

  // Beveled heavy steel receiver
  const receiver = new THREE.Mesh(new THREE.BoxGeometry(0.072, 0.105, 0.3), gunMetalMat);
  receiver.position.set(0, 0.014, 0.14);
  receiver.castShadow = true;
  shotgun.add(receiver);

  // Side-saddle carrier with 4 red/brass 12-gauge shells
  for (let s = 0; s < 4; s++) {
    const sz = 0.065 + s * 0.036;
    const shellBody = new THREE.Mesh(new THREE.CylinderGeometry(0.011, 0.011, 0.052, 8), shellRedMat);
    shellBody.position.set(0.044, 0.012, sz);
    shotgun.add(shellBody);
    const shellBrass = new THREE.Mesh(new THREE.CylinderGeometry(0.0115, 0.0115, 0.018, 8), brassMat);
    shellBrass.position.set(0.044, -0.018, sz);
    shotgun.add(shellBrass);
  }

  // Ribbed walnut pump-action forend (aligned cleanly with left hand)
  const pump = new THREE.Mesh(new THREE.CylinderGeometry(0.038, 0.038, 0.25, 14), gunWoodMat);
  pump.rotation.x = Math.PI / 2;
  pump.position.set(0, -0.008, 0.45);
  pump.castShadow = true;
  shotgun.add(pump);

  // Heavy upper 12-gauge barrel + under-barrel tubular magazine + barrel clamp
  const topBarrel = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.024, 0.62, 12), gunMetalMat);
  topBarrel.rotation.x = Math.PI / 2;
  topBarrel.position.set(0, 0.036, 0.6);
  topBarrel.castShadow = true;
  shotgun.add(topBarrel);

  const magTube = new THREE.Mesh(new THREE.CylinderGeometry(0.019, 0.019, 0.54, 10), gunDarkMat);
  magTube.rotation.x = Math.PI / 2;
  magTube.position.set(0, -0.006, 0.56);
  shotgun.add(magTube);

  const beadSight = new THREE.Mesh(new THREE.SphereGeometry(0.007, 8, 8), brassMat);
  beadSight.position.set(0, 0.06, 0.88);
  shotgun.add(beadSight);

  return shotgun;
}

// ============================================================================
// Bengali Hero Builder (Realistic Sculpted Human + Tactical Gear + Cloth Gamcha)
// ============================================================================

/**
 * Builds the Bengali Hero ("ভানু") as a realistic, anatomically sculpted 3D human character:
 * smooth contoured torso & muscular limbs, PBR skin shader with subsurface warmth, detailed
 * facial features (eyes, brows, nose, lips, ears, trimmed moustache, short fade hair),
 * articulated 5-finger hands, combat boots, tactical kurta + chest rig, swappable rifle/shotgun,
 * and a real-time Verlet physics-animated red-and-white checkered gamcha.
 */
export function buildBengaliHero(textures: TextureBundle): HeroRig {
  const root = new THREE.Group();
  addActorShadow(root, textures.contactShadowMap, 1.48);

  const bodyGroup = new THREE.Group();
  root.add(bodyGroup);

  const WY = 0.94; // Anatomical lumbar waist pivot height
  const upperBodyGroup = new THREE.Group();
  upperBodyGroup.position.set(0, WY, 0);
  bodyGroup.add(upperBodyGroup);

  // Realistic PBR Material Suite (natural warm golden-wheat Bengali skin + varied cloth/leather/metal)
  const skinMat = createRealisticSkinMaterial(0xcf976f, textures, false);
  const faceSkinMat = createRealisticSkinMaterial(0xd19a72, textures, true);
  const hairMat = createHairMaterial(0x191412);
  const fadeMat = new THREE.MeshStandardMaterial({
    color: 0x2a211d,
    roughness: 0.88,
    metalness: 0.0,
    bumpMap: textures.skinBumpMap,
    bumpScale: 0.003,
  });
  const kurtaMat = createClothMaterial(0xf3ebdc, textures, {
    map: textures.clothAlbedoMap,
    roughness: 0.88,
    sheen: 0.44,
    sheenColor: 0xfff8ed,
    bumpScale: 0.011,
  });
  const tacticalRigMat = new THREE.MeshStandardMaterial({
    color: 0x2f362d,
    map: textures.tacticalWeaveMap,
    roughness: 0.82,
    metalness: 0.06,
    bumpMap: textures.fabricBumpMap,
    bumpScale: 0.013,
  });
  const pantsMat = new THREE.MeshStandardMaterial({
    color: 0x2a323b,
    map: textures.tacticalWeaveMap,
    roughness: 0.85,
    metalness: 0.02,
    bumpMap: textures.fabricBumpMap,
    bumpScale: 0.012,
  });
  const kneePadMat = new THREE.MeshStandardMaterial({
    color: 0x1b1e21,
    roughness: 0.56,
    metalness: 0.14,
  });
  const bootLeatherMat = new THREE.MeshStandardMaterial({
    color: 0x4b3222,
    map: textures.leatherAlbedoMap,
    roughness: 0.46,
    metalness: 0.05,
    bumpMap: textures.skinBumpMap,
    bumpScale: 0.007,
  });
  const bootSoleMat = new THREE.MeshStandardMaterial({
    color: 0x171819,
    roughness: 0.92,
    metalness: 0.02,
  });
  const beltLeatherMat = new THREE.MeshStandardMaterial({
    color: 0x573a25,
    map: textures.leatherAlbedoMap,
    roughness: 0.48,
    metalness: 0.05,
    bumpMap: textures.skinBumpMap,
    bumpScale: 0.006,
  });
  const metalBuckleMat = new THREE.MeshStandardMaterial({
    color: 0x8e969d,
    roughness: 0.28,
    metalness: 0.88,
  });
  const gamchaMat = createClothMaterial(0xffffff, textures, {
    map: textures.gamchaMap,
    roughness: 0.84,
    sheen: 0.56,
    sheenColor: 0xffe4df,
    side: THREE.DoubleSide,
    bumpScale: 0.012,
  });
  const gunMetalMat = new THREE.MeshStandardMaterial({
    color: 0x2d3238,
    roughness: 0.3,
    metalness: 0.84,
  });
  const gunDarkMat = new THREE.MeshStandardMaterial({
    color: 0x1c1f23,
    roughness: 0.48,
    metalness: 0.45,
  });
  const gunWoodMat = new THREE.MeshStandardMaterial({
    color: 0x6f3e21,
    roughness: 0.58,
    metalness: 0.05,
  });

  // 1. Articulated Sculpted Legs + Pelvis Bridge + Combat Boots
  const pelvis = new THREE.Mesh(createContouredPelvisGeometry(1.0), pantsMat);
  pelvis.position.set(0, 0.77, 0);
  pelvis.castShadow = true;
  bodyGroup.add(pelvis);

  const leftLegBuild = buildSculptedLeg({
    xOff: -0.112,
    pantsMat,
    kneePadMat,
    bootLeatherMat,
    bootSoleMat,
    metalMat: metalBuckleMat,
  });
  const rightLegBuild = buildSculptedLeg({
    xOff: 0.112,
    pantsMat,
    kneePadMat,
    bootLeatherMat,
    bootSoleMat,
    metalMat: metalBuckleMat,
    hasDropHolster: true,
  });
  bodyGroup.add(leftLegBuild.hip, rightLegBuild.hip);

  // Sculpted pleated lower kurta hem pivoted cleanly at waist (y = 0.94) so it sways gently with stride
  const hemProfile: THREE.Vector2[] = [
    new THREE.Vector2(0.184, 0.0),
    new THREE.Vector2(0.176, 0.08),
    new THREE.Vector2(0.166, 0.16),
    new THREE.Vector2(0.158, 0.22),
  ];
  const hemGeo = new THREE.LatheGeometry(hemProfile, 28);
  const hPos = hemGeo.attributes.position;
  for (let i = 0; i < hPos.count; i++) {
    const x = hPos.getX(i);
    const y = hPos.getY(i);
    const z = hPos.getZ(i);
    const ang = Math.atan2(z, x);
    const pleat = 1.0 + Math.sin(ang * 8) * 0.025 * (1 - y / 0.22);
    hPos.setXYZ(i, x * 1.11 * pleat, y - 0.2, z * 0.78 * pleat);
  }
  hemGeo.computeVertexNormals();
  const kurtaHem = new THREE.Mesh(hemGeo, kurtaMat);
  kurtaHem.position.set(0, WY, 0);
  kurtaHem.castShadow = true;
  bodyGroup.add(kurtaHem);

  // 2. Sculpted Contoured Upper Body (mounted inside lumbar upperBodyGroup)
  const torsoGeo = createContouredTorsoGeometry(1.0, 1.0);
  const torso = new THREE.Mesh(torsoGeo, kurtaMat);
  torso.position.set(0, 0.91 - WY, 0);
  torso.castShadow = true;
  torso.receiveShadow = true;
  upperBodyGroup.add(torso);

  // Mandarin collar & buttoned front placket
  const collarRing = new THREE.Mesh(new THREE.CylinderGeometry(0.084, 0.092, 0.044, 20, 1, true), kurtaMat);
  collarRing.position.set(0, 1.495 - WY, -0.005);
  upperBodyGroup.add(collarRing);

  const placket = new THREE.Mesh(new THREE.BoxGeometry(0.036, 0.24, 0.012), kurtaMat);
  placket.position.set(0, 1.37 - WY, 0.13);
  upperBodyGroup.add(placket);
  for (let b = 0; b < 3; b++) {
    const btn = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.005, 8), beltLeatherMat);
    btn.rotation.x = Math.PI / 2;
    btn.position.set(0, 1.44 - WY - b * 0.055, 0.138);
    upperBodyGroup.add(btn);
  }

  // 3. Tactical Chest Rig, MOLLE Mag Pouches & Rugged Utility Belt
  const beltGeo = new THREE.TorusGeometry(0.165, 0.021, 10, 28);
  beltGeo.rotateX(Math.PI / 2);
  beltGeo.scale(1.06, 1.1, 0.74);
  const waistBelt = new THREE.Mesh(beltGeo, beltLeatherMat);
  waistBelt.position.set(0, 0.0, 0.004);
  waistBelt.castShadow = true;
  upperBodyGroup.add(waistBelt);

  const buckle = new THREE.Mesh(new THREE.BoxGeometry(0.056, 0.042, 0.022), metalBuckleMat);
  buckle.position.set(0, 0.0, 0.132);
  upperBodyGroup.add(buckle);

  for (const sx of [-0.18, 0.18]) {
    const pouch = new THREE.Mesh(new THREE.BoxGeometry(0.054, 0.092, 0.076), tacticalRigMat);
    pouch.position.set(sx, -0.02, 0.02);
    pouch.castShadow = true;
    upperBodyGroup.add(pouch);

    const pouchStrap = new THREE.Mesh(new THREE.BoxGeometry(0.058, 0.016, 0.08), beltLeatherMat);
    pouchStrap.position.set(sx, 0.01, 0.02);
    upperBodyGroup.add(pouchStrap);
  }

  // Rear lumbar field utility / medkit pouch on waist belt
  const rearPack = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.095, 0.068), tacticalRigMat);
  rearPack.position.set(0, -0.01, -0.145);
  rearPack.castShadow = true;
  upperBodyGroup.add(rearPack);

  const vestPlateGeo = new THREE.CylinderGeometry(0.184, 0.164, 0.25, 22, 1, false);
  vestPlateGeo.scale(1.11, 1.0, 0.76);
  const vestPlate = new THREE.Mesh(vestPlateGeo, tacticalRigMat);
  vestPlate.position.set(0, 1.21 - WY, 0.006);
  vestPlate.castShadow = true;
  upperBodyGroup.add(vestPlate);

  // Horizontal stitched MOLLE webbing strips across upper chest carrier
  for (const wy of [1.26, 1.298]) {
    const molleStrip = new THREE.Mesh(new THREE.BoxGeometry(0.215, 0.015, 0.014), kneePadMat);
    molleStrip.position.set(0, wy - WY, 0.146);
    upperBodyGroup.add(molleStrip);
  }

  // Subtle glowing sapphire-blue Raksha Kabach (Body Armor) shield plate overlay when armor > 0
  const armorOverlayGeo = new THREE.CylinderGeometry(0.191, 0.171, 0.268, 22, 1, false);
  armorOverlayGeo.scale(1.12, 1.0, 0.78);
  const armorOverlayMat = new THREE.MeshStandardMaterial({
    color: 0x2692ff,
    emissive: 0x1668d4,
    emissiveIntensity: 0.75,
    roughness: 0.28,
    metalness: 0.65,
    transparent: true,
    opacity: 0.58,
  });
  const armorVestOverlay = new THREE.Mesh(armorOverlayGeo, armorOverlayMat);
  armorVestOverlay.position.set(0, 1.215 - WY, 0.008);
  armorVestOverlay.visible = false;
  upperBodyGroup.add(armorVestOverlay);

  for (let m = -1; m <= 1; m++) {
    const magPouch = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.112, 0.036), tacticalRigMat);
    magPouch.position.set(m * 0.066, 1.16 - WY, 0.142 - Math.abs(m) * 0.012);
    magPouch.rotation.y = m * 0.18;
    magPouch.castShadow = true;
    upperBodyGroup.add(magPouch);

    const flap = new THREE.Mesh(new THREE.BoxGeometry(0.051, 0.031, 0.04), kneePadMat);
    flap.position.set(m * 0.066, 1.21 - WY, 0.145 - Math.abs(m) * 0.012);
    flap.rotation.y = m * 0.18;
    upperBodyGroup.add(flap);
  }

  const strapCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0.112, 1.32 - WY, 0.118),
    new THREE.Vector3(0.128, 1.478 - WY, 0.042),
    new THREE.Vector3(0.124, 1.478 - WY, -0.062),
    new THREE.Vector3(0.106, 1.32 - WY, -0.112),
  ]);
  const rStrapGeo = new THREE.TubeGeometry(strapCurve, 16, 0.02, 8, false);
  rStrapGeo.scale(1.0, 1.0, 0.92);
  const rStrap = new THREE.Mesh(rStrapGeo, tacticalRigMat);
  upperBodyGroup.add(rStrap);

  // Metallic carabiner / D-ring + compact field radio handset on right strap
  const dRing = new THREE.Mesh(new THREE.TorusGeometry(0.016, 0.0038, 6, 12), metalBuckleMat);
  dRing.position.set(0.122, 1.33 - WY, 0.13);
  upperBodyGroup.add(dRing);

  const radioClip = new THREE.Mesh(new THREE.BoxGeometry(0.038, 0.06, 0.024), kneePadMat);
  radioClip.position.set(0.126, 1.38 - WY, 0.116);
  upperBodyGroup.add(radioClip);

  const radioAnt = new THREE.Mesh(new THREE.CylinderGeometry(0.0028, 0.0036, 0.085, 5), kneePadMat);
  radioAnt.position.set(0.138, 1.445 - WY, 0.114);
  upperBodyGroup.add(radioAnt);

  // 4. Detailed Sculpted Bengali Hero Head seated at true ~7.4-head human proportion
  const headBuild = buildDetailedHumanHead({
    skinMat,
    faceSkinMat,
    hairMat,
    fadeMat,
    hairStyle: 'hero-sweep',
    hasMoustache: true,
    hasStubble: true,
    irisHex: 0x2c180e,
    lipHex: 0x9c6252,
    browFierce: 0.004,
  });
  headBuild.headGroup.position.set(0, 1.66 - WY, 0.005);
  upperBodyGroup.add(headBuild.headGroup);

  // 5. Physics-Animated Cloth Red-and-White Checkered Gamcha (in upperBodyGroup space)
  const gamchaCloth = createGamchaClothSystem(upperBodyGroup, gamchaMat);

  // 6. Sculpted Muscular Arms + Rolled Kurta Sleeves + Articulated 5-Finger Hands
  // Anchored cleanly to the upper shoulder joints of the torso (y = 1.415 -> 0.475 above lumbar waist)
  const leftArm = buildSculptedArm({
    side: -1,
    shoulderWorld: new THREE.Vector3(-0.202, 1.415 - WY, -0.004),
    elbowWorld: new THREE.Vector3(-0.145, 1.185 - WY, 0.19),
    wristWorld: new THREE.Vector3(0.068, 1.215 - WY, 0.422),
    sleeveMat: kurtaMat,
    skinMat,
    handPose: 'cradle',
    handRollOffset: 0.95,
    rolledSleeve: true,
    watchMat: kneePadMat,
  });
  upperBodyGroup.add(leftArm);

  const rightArm = buildSculptedArm({
    side: 1,
    shoulderWorld: new THREE.Vector3(0.202, 1.415 - WY, -0.004),
    elbowWorld: new THREE.Vector3(0.242, 1.158 - WY, 0.072),
    wristWorld: new THREE.Vector3(0.12, 1.192 - WY, 0.258),
    sleeveMat: kurtaMat,
    skinMat,
    handPose: 'grip',
    handRollOffset: -1.35,
    rolledSleeve: true,
  });
  upperBodyGroup.add(rightArm);

  // 7. Detailed Swappable Multi-Part Weapon Rig aligned cleanly to the articulated hands
  const recoilGroup = new THREE.Group();
  recoilGroup.position.set(0.115, 1.25 - WY, 0.27);
  upperBodyGroup.add(recoilGroup);

  const rifleGroup = buildDetailedCarbine(gunMetalMat, gunDarkMat, gunWoodMat);
  recoilGroup.add(rifleGroup);

  const shotgunGroup = buildDetailedShotgun(gunMetalMat, gunDarkMat, gunWoodMat);
  shotgunGroup.visible = false;
  recoilGroup.add(shotgunGroup);

  const trishulGroup = buildTrishulSniper(gunMetalMat, gunDarkMat, gunWoodMat);
  trishulGroup.visible = false;
  recoilGroup.add(trishulGroup);

  const falaGroup = buildBanglarFala();
  falaGroup.visible = false;
  recoilGroup.add(falaGroup);

  const muzzlePoint = new THREE.Object3D();
  muzzlePoint.position.set(0, 0.028, 0.97);
  recoilGroup.add(muzzlePoint);

  const flashMat = new THREE.MeshBasicMaterial({
    color: 0xffd36b,
    transparent: true,
    opacity: 0.92,
  });
  const muzzleFlash = new THREE.Mesh(new THREE.ConeGeometry(0.13, 0.4, 6), flashMat);
  muzzleFlash.rotation.x = Math.PI / 2;
  muzzleFlash.position.set(0, 0.028, 1.12);
  muzzleFlash.visible = false;
  recoilGroup.add(muzzleFlash);

  const muzzleLight = new THREE.PointLight(0xffb84d, 0, 8, 2);
  muzzleLight.position.set(0, 0.1, 1.05);
  recoilGroup.add(muzzleLight);

  return {
    root,
    bodyGroup,
    upperBodyGroup,
    headGroup: headBuild.headGroup,
    hairTuft: headBuild.hairTuft,
    kurtaHem,
    leftLeg: leftLegBuild.hip,
    rightLeg: rightLegBuild.hip,
    leftKnee: leftLegBuild.knee,
    rightKnee: rightLegBuild.knee,
    leftAnkle: leftLegBuild.ankle,
    rightAnkle: rightLegBuild.ankle,
    leftArm,
    rightArm,
    gamchaTail: gamchaCloth.tailMesh,
    gamchaMaterial: gamchaMat,
    rifleGroup,
    shotgunGroup,
    trishulGroup,
    falaGroup,
    armorVestOverlay,
    muzzlePoint,
    muzzleFlash,
    muzzleLight,
    recoilGroup,
    setBlink: headBuild.setBlink,
    updateGamchaCloth: gamchaCloth.update,
  };
}

// ============================================================================
// Realistic 3D Human Enemy Characters (Scout, Rusher, Heavy)
// ============================================================================

/**
 * Builds an articulated realistic 3D human enemy fighter with sculpted torso/limbs,
 * lumbar spine hierarchy, natural Bengali skin tones, expressive blinking eyes,
 * layered hair, flowing cloth scarf/headband/shawl, combat boots, and world-space HP bar.
 */
export function buildEnemyBot(
  archetype: EnemyArchetype,
  textures: TextureBundle,
): EnemyRig {
  const root = new THREE.Group();
  const scale = archetype === 'heavy' ? 1.16 : archetype === 'rusher' ? 0.96 : 1.02;
  addActorShadow(root, textures.contactShadowMap, 1.32 * scale);

  const bodyGroup = new THREE.Group();
  bodyGroup.scale.setScalar(scale);
  root.add(bodyGroup);

  const WY = 0.94;
  const upperBodyGroup = new THREE.Group();
  upperBodyGroup.position.set(0, WY, 0);
  bodyGroup.add(upperBodyGroup);

  // Natural varied Bengali human skin tones & grounded weathered tactical palettes
  const skinHex =
    archetype === 'heavy' ? 0xa8714e : archetype === 'rusher' ? 0xd29c74 : 0xbf845c;
  const jacketHex =
    archetype === 'heavy' ? 0x2b2927 : archetype === 'rusher' ? 0x453226 : 0x252d36;
  const rigHex =
    archetype === 'heavy' ? 0x52372c : archetype === 'rusher' ? 0x735837 : 0x622e30;
  const pantsHex =
    archetype === 'heavy' ? 0x232527 : archetype === 'rusher' ? 0x38322a : 0x1e2329;

  const skinMat = createRealisticSkinMaterial(skinHex, textures, false);
  const faceSkinMat = createRealisticSkinMaterial(skinHex, textures, true);
  const hairMat = createHairMaterial(archetype === 'rusher' ? 0x1d1612 : 0x141212);
  const fadeMat = new THREE.MeshStandardMaterial({
    color: 0x251f1b,
    roughness: 0.88,
  });
  const jacketMat = new THREE.MeshStandardMaterial({
    color: jacketHex,
    map: textures.clothAlbedoMap,
    roughness: 0.82,
    metalness: 0.05,
    bumpMap: textures.fabricBumpMap,
    bumpScale: 0.011,
  });
  const rigMat = new THREE.MeshStandardMaterial({
    color: rigHex,
    map: textures.tacticalWeaveMap,
    roughness: archetype === 'heavy' ? 0.56 : 0.74,
    metalness: archetype === 'heavy' ? 0.26 : 0.08,
    bumpMap: textures.fabricBumpMap,
    bumpScale: 0.011,
  });
  const pantsMat = new THREE.MeshStandardMaterial({
    color: pantsHex,
    map: textures.tacticalWeaveMap,
    roughness: 0.86,
    metalness: 0.03,
    bumpMap: textures.fabricBumpMap,
    bumpScale: 0.011,
  });
  const kneePadMat = new THREE.MeshStandardMaterial({
    color: 0x1a1c1f,
    roughness: 0.58,
    metalness: 0.16,
  });
  const bootLeatherMat = new THREE.MeshStandardMaterial({
    color: 0x2b231e,
    map: textures.leatherAlbedoMap,
    roughness: 0.48,
    metalness: 0.06,
    bumpMap: textures.skinBumpMap,
    bumpScale: 0.006,
  });
  const bootSoleMat = new THREE.MeshStandardMaterial({
    color: 0x121315,
    roughness: 0.92,
  });
  const gloveMat = new THREE.MeshStandardMaterial({
    color: 0x242220,
    map: textures.leatherAlbedoMap,
    roughness: 0.72,
    metalness: 0.05,
  });
  const gunMat = new THREE.MeshStandardMaterial({
    color: 0x222529,
    roughness: 0.34,
    metalness: 0.82,
  });

  const flashMaterials: THREE.MeshStandardMaterial[] = [
    jacketMat,
    rigMat,
    skinMat,
    faceSkinMat,
    pantsMat,
  ];
  const baseEmissives = flashMaterials.map((m) => m.emissive.clone());

  const thicknessMult = archetype === 'heavy' ? 1.14 : archetype === 'rusher' ? 0.94 : 1.0;

  // 1. Sculpted Pelvis + Legs + Cargo Pants + Knee Pads + Combat Boots
  const pelvis = new THREE.Mesh(createContouredPelvisGeometry(thicknessMult), pantsMat);
  pelvis.position.set(0, 0.77, 0);
  pelvis.castShadow = true;
  bodyGroup.add(pelvis);

  const leftLegBuild = buildSculptedLeg({
    xOff: -0.112 * thicknessMult,
    pantsMat,
    kneePadMat,
    bootLeatherMat,
    bootSoleMat,
    metalMat: gunMat,
    thicknessMult,
  });
  const rightLegBuild = buildSculptedLeg({
    xOff: 0.112 * thicknessMult,
    pantsMat,
    kneePadMat,
    bootLeatherMat,
    bootSoleMat,
    metalMat: gunMat,
    thicknessMult,
  });
  bodyGroup.add(leftLegBuild.hip, rightLegBuild.hip);

  // 2. Sculpted Contoured Torso + Tactical Plate Carrier inside upperBodyGroup
  const enemyWidthMult = archetype === 'heavy' ? 1.14 : archetype === 'rusher' ? 0.96 : 1.02;
  const torsoGeo = createContouredTorsoGeometry(
    enemyWidthMult,
    archetype === 'heavy' ? 1.12 : 1.0,
  );
  const torso = new THREE.Mesh(torsoGeo, jacketMat);
  torso.position.set(0, 0.91 - WY, 0);
  torso.castShadow = true;
  upperBodyGroup.add(torso);

  const vestGeo = new THREE.CylinderGeometry(
    0.186 * thicknessMult,
    0.166 * thicknessMult,
    archetype === 'heavy' ? 0.34 : 0.26,
    20,
  );
  vestGeo.scale(1.12, 1.0, 0.77);
  const vest = new THREE.Mesh(vestGeo, rigMat);
  vest.position.set(0, 1.225 - WY, 0.008);
  vest.castShadow = true;
  upperBodyGroup.add(vest);

  const beltGeo = new THREE.TorusGeometry(0.168 * thicknessMult, 0.021, 8, 22);
  beltGeo.rotateX(Math.PI / 2);
  beltGeo.scale(1.06, 1.0, 0.76);
  const belt = new THREE.Mesh(beltGeo, kneePadMat);
  belt.position.set(0, 0.0, 0.004);
  upperBodyGroup.add(belt);

  for (let p = -1; p <= 1; p++) {
    const pouch = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.098, 0.042), kneePadMat);
    pouch.position.set(p * 0.07 * thicknessMult, 1.18 - WY, 0.144 * thicknessMult);
    pouch.rotation.y = p * 0.2;
    upperBodyGroup.add(pouch);
  }

  if (archetype === 'heavy') {
    for (const sx of [-1, 1]) {
      const pauldronGeo = new THREE.SphereGeometry(0.122, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.62);
      pauldronGeo.scale(0.94, 0.82, 1.1);
      const pauldron = new THREE.Mesh(pauldronGeo, rigMat);
      pauldron.position.set(sx * 0.245, 1.425 - WY, -0.002);
      pauldron.rotation.z = -sx * 0.42;
      pauldron.castShadow = true;
      upperBodyGroup.add(pauldron);
    }
    const gorget = new THREE.Mesh(new THREE.TorusGeometry(0.118, 0.026, 8, 18), rigMat);
    gorget.rotation.x = Math.PI / 2;
    gorget.position.set(0, 1.495 - WY, 0.005);
    upperBodyGroup.add(gorget);
  }

  // 3. Expressive Sculpted Human Head + Natural Bengali/Tactical Gear + Flowing Cloth
  const headBuild = buildDetailedHumanHead({
    skinMat,
    faceSkinMat,
    hairMat,
    fadeMat,
    hairStyle:
      archetype === 'heavy'
        ? 'heavy-fade'
        : archetype === 'rusher'
          ? 'rusher-wavy'
          : 'scout-crop',
    hasMoustache: archetype === 'heavy' || archetype === 'scout',
    hasFullBeard: archetype === 'heavy',
    hasStubble: archetype !== 'heavy',
    irisHex: 0x26150c,
    lipHex: archetype === 'rusher' ? 0x9b6454 : 0x8d5747,
    browFierce: archetype === 'rusher' ? 0.0058 : 0.0046,
  });
  const headGroup = headBuild.headGroup;
  headGroup.position.set(0, 1.66 - WY, 0.005);
  upperBodyGroup.add(headGroup);

  const clothUpdaters: Array<(time: number, speed: number, yawRate: number, windBoost: number) => void> = [];

  if (archetype === 'heavy') {
    // Open-face matte ballistic helmet + brow visor rim + dust goggles + chinstrap + rugged warrior shawl
    const helmGeo = new THREE.SphereGeometry(0.126, 20, 14, 0, Math.PI * 2, 0, Math.PI * 0.54);
    helmGeo.scale(0.94, 1.04, 1.08);
    const helmet = new THREE.Mesh(helmGeo, rigMat);
    helmet.position.set(0, 0.028, -0.005);
    helmet.castShadow = true;
    headGroup.add(helmet);

    const goggleBand = new THREE.Mesh(new THREE.TorusGeometry(0.118, 0.011, 6, 18), kneePadMat);
    goggleBand.rotation.x = Math.PI / 2;
    goggleBand.scale.set(0.96, 1.06, 1.0);
    goggleBand.position.set(0, 0.064, -0.002);
    headGroup.add(goggleBand);

    const goggleVisor = new THREE.Mesh(
      new THREE.BoxGeometry(0.105, 0.036, 0.022),
      new THREE.MeshStandardMaterial({ color: 0x1e252c, roughness: 0.18, metalness: 0.42 }),
    );
    goggleVisor.position.set(0, 0.068, 0.116);
    headGroup.add(goggleVisor);

    const chinStrapCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.092, -0.005, 0.015),
      new THREE.Vector3(-0.056, -0.095, 0.052),
      new THREE.Vector3(0.0, -0.118, 0.072),
      new THREE.Vector3(0.056, -0.095, 0.052),
      new THREE.Vector3(0.092, -0.005, 0.015),
    ]);
    const chinStrap = new THREE.Mesh(new THREE.TubeGeometry(chinStrapCurve, 14, 0.006, 6, false), kneePadMat);
    headGroup.add(chinStrap);

    const shawlMat = createClothMaterial(0x521d1a, textures, {
      roughness: 0.88,
      sheen: 0.45,
      sheenColor: 0xb86658,
      side: THREE.DoubleSide,
    });
    const shawlCollar = new THREE.Mesh(new THREE.TorusGeometry(0.145, 0.026, 8, 22), shawlMat);
    shawlCollar.rotation.x = Math.PI / 2;
    shawlCollar.scale.set(1.12, 0.92, 1.0);
    shawlCollar.position.set(0, 1.49 - WY, -0.01);
    upperBodyGroup.add(shawlCollar);

    clothUpdaters.push(
      createFlowingClothRibbon({
        parent: upperBodyGroup,
        material: shawlMat,
        anchor: new THREE.Vector3(-0.06, 1.46 - WY, -0.155),
        width: 0.28,
        length: 0.62,
        phaseOffset: 0.6,
      }),
    );
  } else if (archetype === 'scout') {
    // Sleek dark translucent aviator sunglasses + woven Bengali cotton neck scarf with flowing back tail
    const lensMat = new THREE.MeshPhysicalMaterial({
      color: 0x161c22,
      roughness: 0.12,
      metalness: 0.25,
      clearcoat: 1.0,
      transparent: true,
      opacity: 0.78,
    });
    const frameMat = new THREE.MeshStandardMaterial({
      color: 0x2b2e33,
      roughness: 0.3,
      metalness: 0.82,
    });
    for (const side of [-1, 1]) {
      const lens = new THREE.Mesh(new THREE.SphereGeometry(0.022, 12, 10), lensMat);
      lens.scale.set(1.15, 0.72, 0.28);
      lens.position.set(side * 0.034, 0.011, 0.105);
      lens.rotation.y = side * 0.18;
      headGroup.add(lens);
    }
    const bridge = new THREE.Mesh(new THREE.BoxGeometry(0.024, 0.0045, 0.005), frameMat);
    bridge.position.set(0, 0.015, 0.109);
    headGroup.add(bridge);

    const scarfMat = createClothMaterial(0x7c2026, textures, {
      roughness: 0.86,
      sheen: 0.48,
      sheenColor: 0xe6a29a,
      side: THREE.DoubleSide,
    });
    const scarfWrap = new THREE.Mesh(new THREE.TorusGeometry(0.098, 0.024, 8, 20), scarfMat);
    scarfWrap.rotation.x = Math.PI / 2;
    scarfWrap.position.set(0, 1.495 - WY, -0.004);
    upperBodyGroup.add(scarfWrap);

    clothUpdaters.push(
      createFlowingClothRibbon({
        parent: upperBodyGroup,
        material: scarfMat,
        anchor: new THREE.Vector3(0.04, 1.47 - WY, -0.125),
        width: 0.15,
        length: 0.56,
        phaseOffset: 1.4,
      }),
    );
  } else {
    // Rusher: traditional knotted crimson-ochre Bengali headband with twin flowing tails + green gamcha drape
    const bandMat = createClothMaterial(0xb8291e, textures, {
      roughness: 0.84,
      sheen: 0.5,
      sheenColor: 0xffb38a,
      side: THREE.DoubleSide,
    });
    const headband = new THREE.Mesh(new THREE.TorusGeometry(0.104, 0.014, 8, 22), bandMat);
    headband.rotation.x = Math.PI / 2 + 0.12;
    headband.scale.set(0.92, 1.06, 1.0);
    headband.position.set(0, 0.056, -0.002);
    headGroup.add(headband);

    const knot = new THREE.Mesh(new THREE.SphereGeometry(0.018, 8, 8), bandMat);
    knot.position.set(0, 0.042, -0.108);
    headGroup.add(knot);

    clothUpdaters.push(
      createFlowingClothRibbon({
        parent: headGroup,
        material: bandMat,
        anchor: new THREE.Vector3(-0.014, 0.038, -0.114),
        width: 0.042,
        length: 0.34,
        cols: 3,
        rows: 7,
        phaseOffset: 0.2,
        spreadX: -0.035,
      }),
      createFlowingClothRibbon({
        parent: headGroup,
        material: bandMat,
        anchor: new THREE.Vector3(0.014, 0.038, -0.114),
        width: 0.042,
        length: 0.29,
        cols: 3,
        rows: 7,
        phaseOffset: 1.8,
        spreadX: 0.035,
      }),
    );

    const rusherGamchaMat = createClothMaterial(0xffffff, textures, {
      map: textures.gamchaGreenMap,
      roughness: 0.86,
      sheen: 0.45,
      side: THREE.DoubleSide,
    });
    const neckWrap = new THREE.Mesh(new THREE.TorusGeometry(0.095, 0.022, 8, 18), rusherGamchaMat);
    neckWrap.rotation.x = Math.PI / 2;
    neckWrap.position.set(0, 1.495 - WY, -0.004);
    upperBodyGroup.add(neckWrap);
  }

  // 4. Sculpted Support Left Arm + Articulated Hand (anchored to upper left shoulder joint)
  const sx = 0.202 * enemyWidthMult;
  const leftArm = buildSculptedArm({
    side: -1,
    shoulderWorld: new THREE.Vector3(-sx, 1.415 - WY, -0.004),
    elbowWorld: new THREE.Vector3(-0.145 * thicknessMult, 1.19 - WY, 0.185),
    wristWorld: new THREE.Vector3(0.082, 1.235 - WY, 0.415),
    sleeveMat: jacketMat,
    skinMat,
    handPose: 'cradle',
    handRollOffset: 0.95,
    rolledSleeve: archetype === 'rusher',
    fullSleeve: archetype !== 'rusher',
    gloveMat,
    thicknessMult,
  });
  upperBodyGroup.add(leftArm);

  // 5. Weapon Pivot (Right Arm + Trigger Hand + Archetype Tactical Firearm) inside upperBodyGroup
  const weaponPivot = new THREE.Group();
  weaponPivot.position.set(0.14, 1.265 - WY, 0.22);
  upperBodyGroup.add(weaponPivot);

  const rightArm = buildSculptedArm({
    side: 1,
    shoulderWorld: new THREE.Vector3(sx - 0.14, 1.415 - 1.265, -0.004 - 0.22),
    elbowWorld: new THREE.Vector3(sx - 0.098, -0.105, -0.148),
    wristWorld: new THREE.Vector3(0.008, -0.052, 0.052),
    sleeveMat: jacketMat,
    skinMat,
    handPose: 'grip',
    handRollOffset: -1.35,
    rolledSleeve: archetype === 'rusher',
    fullSleeve: archetype !== 'rusher',
    gloveMat,
    thicknessMult,
  });
  weaponPivot.add(rightArm);

  const gunLen = archetype === 'heavy' ? 0.68 : archetype === 'rusher' ? 0.42 : 0.54;
  const gunReceiver = new THREE.Mesh(new THREE.BoxGeometry(0.068, 0.105, gunLen * 0.58), gunMat);
  gunReceiver.position.set(0, 0.01, 0.2);
  gunReceiver.castShadow = true;
  weaponPivot.add(gunReceiver);

  const gunGrip = new THREE.Mesh(new THREE.CapsuleGeometry(0.022, 0.085, 4, 8), kneePadMat);
  gunGrip.position.set(0, -0.062, 0.07);
  gunGrip.rotation.x = -0.32;
  weaponPivot.add(gunGrip);

  const gunBarrel = new THREE.Mesh(
    new THREE.CylinderGeometry(
      archetype === 'heavy' ? 0.024 : 0.016,
      archetype === 'heavy' ? 0.028 : 0.018,
      gunLen * 0.65,
      10,
    ),
    gunMat,
  );
  gunBarrel.rotation.x = Math.PI / 2;
  gunBarrel.position.set(0, 0.024, 0.2 + gunLen * 0.52);
  gunBarrel.castShadow = true;
  weaponPivot.add(gunBarrel);

  if (archetype === 'heavy') {
    const drum = new THREE.Mesh(new THREE.CylinderGeometry(0.072, 0.072, 0.09, 14), rigMat);
    drum.rotation.z = Math.PI / 2;
    drum.position.set(0, -0.075, 0.28);
    weaponPivot.add(drum);
  } else {
    const mag = new THREE.Mesh(new THREE.BoxGeometry(0.036, 0.16, 0.064), kneePadMat);
    mag.position.set(0, -0.085, 0.24);
    mag.rotation.x = 0.2;
    weaponPivot.add(mag);
  }

  const muzzlePoint = new THREE.Object3D();
  muzzlePoint.position.set(0, 0.024, 0.2 + gunLen * 0.88);
  weaponPivot.add(muzzlePoint);

  const telegraphGlow = new THREE.Mesh(
    new THREE.SphereGeometry(0.11, 10, 10),
    new THREE.MeshBasicMaterial({ color: 0xff5a2b, transparent: true, opacity: 0.9 }),
  );
  telegraphGlow.position.copy(muzzlePoint.position);
  telegraphGlow.visible = false;
  weaponPivot.add(telegraphGlow);

  // Floating world-space health bar above enemy
  const hpBarBg = new THREE.Mesh(
    new THREE.PlaneGeometry(0.95, 0.12),
    new THREE.MeshBasicMaterial({ color: 0x1a1210, side: THREE.DoubleSide }),
  );
  hpBarBg.position.set(0, 2.22 * scale, 0);
  hpBarBg.visible = false;
  root.add(hpBarBg);

  const hpFillGeo = new THREE.PlaneGeometry(0.89, 0.075);
  hpFillGeo.translate(0.445, 0, 0);
  const hpBarFill = new THREE.Mesh(
    hpFillGeo,
    new THREE.MeshBasicMaterial({ color: 0xe83b2e, side: THREE.DoubleSide }),
  );
  hpBarFill.position.set(-0.445, 0, 0.01);
  hpBarBg.add(hpBarFill);

  const updateCloth = (
    _dt: number,
    time: number,
    speed: number,
    yawRate: number,
    windBoost: number,
  ): void => {
    for (let i = 0; i < clothUpdaters.length; i++) {
      clothUpdaters[i](time, speed, yawRate, windBoost);
    }
  };

  return {
    root,
    bodyGroup,
    upperBodyGroup,
    headGroup,
    hairTuft: headBuild.hairTuft,
    leftLeg: leftLegBuild.hip,
    rightLeg: rightLegBuild.hip,
    leftKnee: leftLegBuild.knee,
    rightKnee: rightLegBuild.knee,
    leftAnkle: leftLegBuild.ankle,
    rightAnkle: rightLegBuild.ankle,
    leftArm,
    weaponPivot,
    muzzlePoint,
    telegraphGlow,
    hpBarBg,
    hpBarFill,
    flashMaterials,
    baseEmissives,
    setBlink: headBuild.setBlink,
    updateCloth,
  };
}

// ============================================================================
// Tactical Supply Pickups (Health Medkit & Ammo Crate)
// ============================================================================

export function buildPickupMesh(kind: PickupKind): THREE.Group {
  if (kind === 'sanjibani') {
    return buildSanjibaniPlant().root;
  }

  const group = new THREE.Group();

  if (kind === 'armor') {
    // Glowing sapphire-blue Raksha Kabach (Body Armor) tactical shield plate
    const plateMat = new THREE.MeshStandardMaterial({
      color: 0x1b6ed6,
      emissive: 0x104ba6,
      emissiveIntensity: 0.85,
      roughness: 0.28,
      metalness: 0.65,
    });
    const brassRimMat = new THREE.MeshStandardMaterial({
      color: 0xf0c252,
      roughness: 0.24,
      metalness: 0.88,
    });
    const shield = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.22, 0.44, 6), plateMat);
    shield.scale.set(1.1, 1.0, 0.48);
    shield.position.y = 0.46;
    shield.castShadow = true;
    group.add(shield);

    const crest = new THREE.Mesh(new THREE.OctahedronGeometry(0.14, 0), brassRimMat);
    crest.position.set(0, 0.48, 0.14);
    group.add(crest);

    const ring = new THREE.Mesh(
      new THREE.RingGeometry(0.46, 0.62, 20),
      new THREE.MeshBasicMaterial({
        color: 0x42a5ff,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.78,
        depthWrite: false,
      }),
    );
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.04;
    group.add(ring);
    return group;
  }

  if (kind === 'grenade') {
    const gola = buildBajraGolaMesh();
    gola.scale.setScalar(1.35);
    gola.position.y = 0.42;
    group.add(gola);

    const ring = new THREE.Mesh(
      new THREE.RingGeometry(0.42, 0.56, 20),
      new THREE.MeshBasicMaterial({
        color: 0xff7b2e,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.75,
        depthWrite: false,
      }),
    );
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.04;
    group.add(ring);
    return group;
  }

  // Ammo supply crate
  const boxMat = new THREE.MeshStandardMaterial({
    color: 0x3b4d2b,
    roughness: 0.45,
    metalness: 0.25,
    emissive: 0x523f12,
    emissiveIntensity: 0.45,
  });
  const accentMat = new THREE.MeshStandardMaterial({
    color: 0xf4bd14,
    emissive: 0xe8a812,
    emissiveIntensity: 1.1,
    roughness: 0.3,
  });

  const crate = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.44, 0.48), boxMat);
  crate.position.y = 0.42;
  crate.castShadow = true;
  group.add(crate);

  const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.66, 0.12, 0.52), accentMat);
  stripe.position.y = 0.44;
  group.add(stripe);

  const ring = new THREE.Mesh(
    new THREE.RingGeometry(0.48, 0.62, 20),
    new THREE.MeshBasicMaterial({
      color: 0xf7c538,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.72,
      depthWrite: false,
    }),
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.04;
  group.add(ring);

  return group;
}
