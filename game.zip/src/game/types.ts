export type GamePhase = 'title' | 'playing' | 'paused' | 'gameover';

export type GameMode = 'survival' | 'pet_taming';

export type BusMode = 'none' | 'riding_intro' | 'driving';

export type GamchaStyle = 'red-white' | 'green-white';

// Strictly original Bengali weapon IDs
export type WeaponType = 'agni47' | 'kalbhairav' | 'trishul' | 'fala';

export type EnemyArchetype = 'scout' | 'heavy' | 'rusher';

export type PickupKind = 'sanjibani' | 'armor' | 'ammo' | 'grenade';

export interface WeaponMeta {
  id: WeaponType;
  slot: 1 | 2 | 3 | 4;
  name: string;
  shortName: string;
  isMelee: boolean;
  hasScope: boolean;
  magSize: number;
  startReserve: number;
  maxReserve: number;
  baseDamage: number;
  fireCooldown: number;
  reloadDuration: number;
  bulletSpeed: number;
  pellets: number;
  spread: number;
}

export const WEAPON_CATALOG: Record<WeaponType, WeaponMeta> = {
  agni47: {
    id: 'agni47',
    slot: 1,
    name: 'অগ্নি-৪৭',
    shortName: 'অগ্নি-৪৭',
    isMelee: false,
    hasScope: false,
    magSize: 24,
    startReserve: 96,
    maxReserve: 192,
    baseDamage: 30,
    fireCooldown: 0.135,
    reloadDuration: 1.15,
    bulletSpeed: 76,
    pellets: 1,
    spread: 0.013,
  },
  kalbhairav: {
    id: 'kalbhairav',
    slot: 2,
    name: 'কালভৈরব',
    shortName: 'কালভৈরব',
    isMelee: false,
    hasScope: false,
    magSize: 8,
    startReserve: 32,
    maxReserve: 64,
    baseDamage: 20,
    fireCooldown: 0.56,
    reloadDuration: 1.35,
    bulletSpeed: 66,
    pellets: 5,
    spread: 0.095,
  },
  trishul: {
    id: 'trishul',
    slot: 3,
    name: 'ত্রিশূল স্নাইপার',
    shortName: 'ত্রিশূল',
    isMelee: false,
    hasScope: true,
    magSize: 5,
    startReserve: 20,
    maxReserve: 45,
    baseDamage: 56,
    fireCooldown: 0.92,
    reloadDuration: 1.55,
    bulletSpeed: 118,
    pellets: 1,
    spread: 0.002,
  },
  fala: {
    id: 'fala',
    slot: 4,
    name: 'বাংলার ফলা',
    shortName: 'ফলা',
    isMelee: true,
    hasScope: false,
    magSize: 0,
    startReserve: 0,
    maxReserve: 0,
    baseDamage: 46,
    fireCooldown: 0.36,
    reloadDuration: 0,
    bulletSpeed: 0,
    pellets: 1,
    spread: 0,
  },
};

export const WEAPON_SLOT_ORDER: WeaponType[] = ['agni47', 'kalbhairav', 'trishul', 'fala'];

export interface WeaponSlotSnapshot {
  ammo: number;
  maxAmmo: number;
  reserve: number;
}

export type WildAnimalSpecies = 'sundarban_tiger' | 'bengal_leopard' | 'village_hound';

export interface PetUpgradePlaceholder {
  level: number;
  maxLevel: number;
  xp: number;
  nextLevelResourceName: string;
  nextLevelResourceCost: number;
  unlockedPerks: string[];
  upgradeLockedReason: string;
}

export interface TamedPetRecord {
  playerId: string;
  species: WildAnimalSpecies;
  nameBn: string;
  titleBn: string;
  tamedAtIso: string;
  bondStrength: number;
  assistRoleBn: string;
  upgrades: PetUpgradePlaceholder;
}

export interface WildAnimalHudState {
  species: WildAnimalSpecies;
  nameBn: string;
  areaBn: string;
  hp: number;
  maxHp: number;
  subdueRatio: number;
  isSubdued: boolean;
  canTame: boolean;
  distance: number;
  bearingDeg: number;
  blockedByLifetimeLimit: boolean;
}

export interface HudSnapshot {
  phase: GamePhase;
  gameMode: GameMode;
  busMode: BusMode;
  nearBus: boolean;
  nearChest: boolean;
  busZoneLabel: string | null;
  busSpeedKmh: number;
  busRouteProgress: number;
  busInteriorCam: boolean;
  busExitSlowing: boolean;
  health: number;
  maxHealth: number;
  armor: number;
  maxArmor: number;
  activeWeapon: WeaponType;
  weapons: Record<WeaponType, WeaponSlotSnapshot>;
  scopeActive: boolean;
  ammo: number;
  maxAmmo: number;
  reserveAmmo: number;
  isReloading: boolean;
  reloadProgress: number;
  sanjibaniCount: number;
  sanjibaniCollected: number;
  maxSanjibani: number;
  isHealing: boolean;
  healProgress: number;
  grenadeCount: number;
  maxGrenades: number;
  headshots: number;
  bodyshots: number;
  stormPhase: number;
  stormCountdown: number;
  stormShrinking: boolean;
  outsideStorm: boolean;
  outsideStormRemaining: number;
  stormTeleportFlash: number;
  stormRadius: number;
  locationName: string;
  score: number;
  highScore: number;
  kills: number;
  wave: number;
  enemiesRemaining: number;
  waveBanner: string | null;
  damageFlash: number;
  damageAngle: number | null;
  hitMarker: number;
  hitMarkerKill: boolean;
  hitMarkerHeadshot: boolean;
  reticleSpread: number;
  muted: boolean;
  sprintRatio: number;
  isCrouching: boolean;
  isJumping: boolean;
  pickupToast: string | null;
  playerId: string;
  permanentPet: TamedPetRecord | null;
  wildAnimal: WildAnimalHudState | null;
  tamingActive: boolean;
  tamingProgress: number;
  tamingStatusText: string | null;
}

export interface CircleCollider {
  x: number;
  z: number;
  radius: number;
  height: number;
  kind: 'house' | 'tree' | 'taxi' | 'prop' | 'ruin' | 'tram' | 'boulder' | 'stall';
}

export interface BoxCollider {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  height: number;
  kind: 'house' | 'taxi' | 'wall';
}

export interface VirtualInputState {
  moveX: number; // -1..1 (right positive)
  moveY: number; // -1..1 (forward positive)
  shooting: boolean;
  sprinting: boolean;
  reloadJustPressed: boolean;
  lookDeltaX: number;
  lookDeltaY: number;
}

// --- Apsara Bengali Shadow Companion, Friends & Mission Types ---

export type ApsaraVoiceState = 'idle' | 'listening' | 'speaking';

export type FriendRelationStatus =
  | 'friend'
  | 'incoming_request'
  | 'request_sent'
  | 'suggested';

export type FriendPresence = 'online' | 'in_match' | 'offline';

export interface FriendEntry {
  id: string;
  name: string;
  aliases: string[];
  level: number;
  status: FriendRelationStatus;
  presence: FriendPresence;
  invitedToSquad: boolean;
  district: string;
}

export type MissionId = 'headshots_3' | 'kills_5' | 'sanjibani_5';

export interface MissionProgress {
  id: MissionId;
  title: string;
  target: number;
  progress: number;
  rewardCoins: number;
  unlockTitle: string;
  claimed: boolean;
}

export interface ApsaraProgressState {
  goldCoins: number;
  diamonds: number;
  lastDailyClaimDate: string | null;
  dailyStreak: number;
  missions: MissionProgress[];
  unlockedTitles: string[];
  activeTitle: string;
  auraBoostUnlocked: boolean;
}

