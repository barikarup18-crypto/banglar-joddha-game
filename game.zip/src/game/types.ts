export type GamePhase = 'title' | 'playing' | 'paused' | 'gameover';

export type GameMode = 'survival' | 'pet_taming';

export type BusMode = 'none' | 'riding_intro' | 'driving';

export type TwoWheelerKind = 'bicycle' | 'motorcycle';

export type GamchaStyle = 'red-white' | 'green-white';

export type HeroOutfitId =
  | 'classic_khadi'
  | 'sundarban_ranger'
  | 'royal_indigo'
  | 'agni_marigold'
  | 'kalboishakhi_noir'
  | 'hooghly_emerald';

export interface HeroOutfitMeta {
  id: HeroOutfitId;
  nameBn: string;
  subtitleBn: string;
  kurtaHex: number;
  kurtaSheenHex: number;
  pantsHex: number;
  rigHex: number;
  swatchTop: string;
  swatchBottom: string;
  swatchAccent: string;
  defaultGamcha: GamchaStyle;
}

export const HERO_OUTFIT_CATALOG: Record<HeroOutfitId, HeroOutfitMeta> = {
  classic_khadi: {
    id: 'classic_khadi',
    nameBn: 'ঐতিহ্যবাহী খাদি',
    subtitleBn: 'হুগলি তীরের মূল পোশাক',
    kurtaHex: 0xf3ebdc,
    kurtaSheenHex: 0xfff8ed,
    pantsHex: 0x2a323b,
    rigHex: 0x2f362d,
    swatchTop: '#f3ebdc',
    swatchBottom: '#2a323b',
    swatchAccent: '#c82026',
    defaultGamcha: 'red-white',
  },
  sundarban_ranger: {
    id: 'sundarban_ranger',
    nameBn: 'সুন্দরবন রেঞ্জার',
    subtitleBn: 'ঘন জঙ্গল ও শিকারী সাজ',
    kurtaHex: 0x455a3e,
    kurtaSheenHex: 0x8ea883,
    pantsHex: 0x252c22,
    rigHex: 0x4e3924,
    swatchTop: '#455a3e',
    swatchBottom: '#252c22',
    swatchAccent: '#1f8a46',
    defaultGamcha: 'green-white',
  },
  royal_indigo: {
    id: 'royal_indigo',
    nameBn: 'নীলকণ্ঠ কমান্ডো',
    subtitleBn: 'গাঢ় নীল ট্যাকটিক্যাল কুর্তা',
    kurtaHex: 0x293d61,
    kurtaSheenHex: 0x6c8cc2,
    pantsHex: 0x1d222c,
    rigHex: 0x3b4352,
    swatchTop: '#293d61',
    swatchBottom: '#1d222c',
    swatchAccent: '#56beff',
    defaultGamcha: 'red-white',
  },
  agni_marigold: {
    id: 'agni_marigold',
    nameBn: 'বসন্ত অগ্নি',
    subtitleBn: 'সোনালি গেরুয়া উৎসবী সাজ',
    kurtaHex: 0xd98924,
    kurtaSheenHex: 0xffd180,
    pantsHex: 0x2e2119,
    rigHex: 0x52251b,
    swatchTop: '#d98924',
    swatchBottom: '#2e2119',
    swatchAccent: '#ffd25a',
    defaultGamcha: 'red-white',
  },
  kalboishakhi_noir: {
    id: 'kalboishakhi_noir',
    nameBn: 'কালবৈশাখী ছায়া',
    subtitleBn: 'নিশাচর কালো রণসজ্জা',
    kurtaHex: 0x24272e,
    kurtaSheenHex: 0x5e6575,
    pantsHex: 0x16181d,
    rigHex: 0x521d24,
    swatchTop: '#24272e',
    swatchBottom: '#16181d',
    swatchAccent: '#ef4444',
    defaultGamcha: 'red-white',
  },
  hooghly_emerald: {
    id: 'hooghly_emerald',
    nameBn: 'হুগলি পান্না',
    subtitleBn: 'সবুজ পান্না ও বালিয়াড়ি প্যান্ট',
    kurtaHex: 0x1e5c47,
    kurtaSheenHex: 0x62b89a,
    pantsHex: 0x5d513d,
    rigHex: 0x2b3636,
    swatchTop: '#1e5c47',
    swatchBottom: '#5d513d',
    swatchAccent: '#4df5b8',
    defaultGamcha: 'green-white',
  },
};

export const HERO_OUTFIT_ORDER: HeroOutfitId[] = [
  'classic_khadi',
  'sundarban_ranger',
  'royal_indigo',
  'agni_marigold',
  'kalboishakhi_noir',
  'hooghly_emerald',
];

export interface LoadoutPreset {
  id: string;
  slot: 1 | 2 | 3;
  nameBn: string;
  outfit: HeroOutfitId;
  gamchaStyle: GamchaStyle;
  weaponType: WeaponType;
  gameMode: GameMode;
}

// Strictly original Bengali weapon IDs
export type WeaponType = 'agni47' | 'kalbhairav' | 'trishul' | 'fala';

export type EnemyArchetype = 'scout' | 'heavy' | 'rusher';

export type PickupKind = 'sanjibani' | 'armor' | 'ammo' | 'grenade';

export interface WeaponMeta {
  id: WeaponType;
  slot: 1 | 2 | 3 | 4;
  name: string;
  shortName: string;
  isMelee: boolean;
  hasScope: boolean;
  magSize: number;
  startReserve: number;
  maxReserve: number;
  baseDamage: number;
  fireCooldown: number;
  reloadDuration: number;
  bulletSpeed: number;
  pellets: number;
  spread: number;
}

export const WEAPON_CATALOG: Record<WeaponType, WeaponMeta> = {
  agni47: {
    id: 'agni47',
    slot: 1,
    name: 'অগ্নি-৪৭',
    shortName: 'অগ্নি-৪৭',
    isMelee: false,
    hasScope: false,
    magSize: 24,
    startReserve: 96,
    maxReserve: 192,
    baseDamage: 30,
    fireCooldown: 0.135,
    reloadDuration: 1.15,
    bulletSpeed: 76,
    pellets: 1,
    spread: 0.013,
  },
  kalbhairav: {
    id: 'kalbhairav',
    slot: 2,
    name: 'কালভৈরব',
    shortName: 'কালভৈরব',
    isMelee: false,
    hasScope: false,
    magSize: 8,
    startReserve: 32,
    maxReserve: 64,
    baseDamage: 20,
    fireCooldown: 0.56,
    reloadDuration: 1.35,
    bulletSpeed: 66,
    pellets: 5,
    spread: 0.095,
  },
  trishul: {
    id: 'trishul',
    slot: 3,
    name: 'ত্রিশূল স্নাইপার',
    shortName: 'ত্রিশূল',
    isMelee: false,
    hasScope: true,
    magSize: 5,
    startReserve: 20,
    maxReserve: 45,
    baseDamage: 56,
    fireCooldown: 0.92,
    reloadDuration: 1.55,
    bulletSpeed: 118,
    pellets: 1,
    spread: 0.002,
  },
  fala: {
    id: 'fala',
    slot: 4,
    name: 'বাংলার ফলা',
    shortName: 'ফলা',
    isMelee: true,
    hasScope: false,
    magSize: 0,
    startReserve: 0,
    maxReserve: 0,
    baseDamage: 46,
    fireCooldown: 0.36,
    reloadDuration: 0,
    bulletSpeed: 0,
    pellets: 1,
    spread: 0,
  },
};

export const WEAPON_SLOT_ORDER: WeaponType[] = ['agni47', 'kalbhairav', 'trishul', 'fala'];

export interface WeaponSlotSnapshot {
  ammo: number;
  maxAmmo: number;
  reserve: number;
}

export type WildAnimalSpecies =
  | 'sundarban_tiger'
  | 'bengal_leopard'
  | 'village_hound'
  | 'gorilla_king'
  | 'ajagar_python'
  | 'lion_king'
  | 'giant_spider'
  | 'wild_boar'
  | 'bengal_bear';

export type AnimalHeartTier = 1 | 2 | 3 | 4;

export interface PetCombatStats {
  maxHp: number;
  attackDamage: number;
  moveSpeed: number;
  assistCooldown: number;
}

export interface AnimalHeartWallet {
  totalValue: number;
  totalCount: number;
  tiers: Record<AnimalHeartTier, number>;
}

export interface PetUpgradePlaceholder {
  level: number;
  maxLevel: number;
  xp: number;
  xpToNext: number;
  nextLevelResourceName: string;
  nextLevelResourceCost: number;
  unlockedPerks: string[];
  upgradeLockedReason: string;
}

export interface PlayerProgressionState {
  level: number;
  maxLevel: number;
  xp: number;
  xpToNext: number;
  maxHealth: number;
  weaponDamageMult: number;
  weaponDamageBonusPct: number;
}

export interface LevelUpFeedback {
  target: 'player' | 'pet' | 'both';
  playerLevel: number;
  playerHpGain: number;
  playerDmgBonusPct: number;
  petNameBn?: string;
  petLevel?: number;
  petHpGain?: number;
  petDmgGain?: number;
  petSpeedGain?: number;
  seq: number;
}

export interface TamedPetRecord {
  playerId: string;
  species: WildAnimalSpecies;
  nameBn: string;
  titleBn: string;
  tamedAtIso: string;
  bondStrength: number;
  assistRoleBn: string;
  stats: PetCombatStats;
  upgrades: PetUpgradePlaceholder;
}

export interface WildAnimalHudState {
  species: WildAnimalSpecies;
  nameBn: string;
  areaBn: string;
  level: number;
  hasAnimalHeart: boolean;
  heartTier: AnimalHeartTier | null;
  heartValue: number;
  heartTierNameBn: string | null;
  hp: number;
  maxHp: number;
  subdueRatio: number;
  isSubdued: boolean;
  canTame: boolean;
  distance: number;
  bearingDeg: number;
  blockedByLifetimeLimit: boolean;
}

export interface RadarBlip {
  x: number; // -1..1 right of camera forward
  y: number; // -1..1 forward of camera (+1 = up/ahead)
  kind: 'enemy' | 'heavy' | 'wild' | 'wild_heart' | 'pet';
  clamped: boolean;
}

export interface HudSnapshot {
  phase: GamePhase;
  gameMode: GameMode;
  busMode: BusMode;
  nearBus: boolean;
  ridingVehicle: TwoWheelerKind | null;
  nearVehicle: TwoWheelerKind | null;
  vehicleSpeedKmh: number;
  nearChest: boolean;
  busZoneLabel: string | null;
  busSpeedKmh: number;
  busRouteProgress: number;
  busInteriorCam: boolean;
  busExitSlowing: boolean;
  health: number;
  maxHealth: number;
  armor: number;
  maxArmor: number;
  activeWeapon: WeaponType;
  weapons: Record<WeaponType, WeaponSlotSnapshot>;
  scopeActive: boolean;
  ammo: number;
  maxAmmo: number;
  reserveAmmo: number;
  isReloading: boolean;
  reloadProgress: number;
  sanjibaniCount: number;
  sanjibaniCollected: number;
  maxSanjibani: number;
  isHealing: boolean;
  healProgress: number;
  grenadeCount: number;
  maxGrenades: number;
  headshots: number;
  bodyshots: number;
  stormPhase: number;
  stormCountdown: number;
  stormShrinking: boolean;
  outsideStorm: boolean;
  outsideStormRemaining: number;
  stormTeleportFlash: number;
  stormRadius: number;
  locationName: string;
  score: number;
  highScore: number;
  kills: number;
  wave: number;
  enemiesRemaining: number;
  maxMapEnemies: number;
  matchVictory: boolean;
  radarBlips: RadarBlip[];
  radarNorthDeg: number;
  waveBanner: string | null;
  damageFlash: number;
  damageAngle: number | null;
  hitMarker: number;
  hitMarkerKill: boolean;
  hitMarkerHeadshot: boolean;
  reticleSpread: number;
  muted: boolean;
  sprintRatio: number;
  isSprinting: boolean;
  isCrouching: boolean;
  isJumping: boolean;
  pickupToast: string | null;
  playerId: string;
  playerLevel: number;
  playerMaxLevel: number;
  playerXp: number;
  playerXpToNext: number;
  weaponDamageBonusPct: number;
  levelUpNotice: LevelUpFeedback | null;
  permanentPet: TamedPetRecord | null;
  animalHearts: AnimalHeartWallet;
  petHp: number;
  petMaxHp: number;
  wildAnimal: WildAnimalHudState | null;
  tamingActive: boolean;
  tamingProgress: number;
  tamingStatusText: string | null;
}

export interface CircleCollider {
  x: number;
  z: number;
  radius: number;
  height: number;
  baseY?: number;
  kind: 'house' | 'tree' | 'taxi' | 'prop' | 'ruin' | 'tram' | 'boulder' | 'stall';
}

export interface BoxCollider {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  height: number;
  kind: 'house' | 'taxi' | 'wall';
}

export interface VirtualInputState {
  moveX: number; // -1..1 (right positive)
  moveY: number; // -1..1 (forward positive)
  shooting: boolean;
  sprinting: boolean;
  reloadJustPressed: boolean;
  lookDeltaX: number;
  lookDeltaY: number;
}

// --- Apsara Bengali Shadow Companion, Friends & Mission Types ---

export type ApsaraVoiceState = 'idle' | 'listening' | 'speaking';

export type FriendRelationStatus =
  | 'friend'
  | 'incoming_request'
  | 'request_sent'
  | 'suggested';

export type FriendPresence = 'online' | 'in_match' | 'offline';

export interface FriendEntry {
  id: string;
  name: string;
  aliases: string[];
  level: number;
  status: FriendRelationStatus;
  presence: FriendPresence;
  invitedToSquad: boolean;
  district: string;
}

export type MissionId = 'headshots_3' | 'kills_5' | 'sanjibani_5';

export interface MissionProgress {
  id: MissionId;
  title: string;
  target: number;
  progress: number;
  rewardCoins: number;
  unlockTitle: string;
  claimed: boolean;
}

export interface ApsaraProgressState {
  goldCoins: number;
  diamonds: number;
  lastDailyClaimDate: string | null;
  dailyStreak: number;
  missions: MissionProgress[];
  unlockedTitles: string[];
  activeTitle: string;
  auraBoostUnlocked: boolean;
}

