import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { GameAudio } from './audio';
import {
  buildBajraGolaMesh,
  buildKalboishakhiStormWall,
  buildWarriorChest,
  createFloatingDamageSprite,
  KalboishakhiStormRig,
  WarriorChestRig,
} from './battleRoyaleAssets';
import {
  buildWbtcBus,
  BusRouteData,
  createBusIntroRoute,
  WbtcBusRig,
} from './bus';
import {
  buildBengaliHero,
  buildEnemyBot,
  buildPickupMesh,
  EnemyRig,
  HeroRig,
} from './characters';
import { RideableTwoWheeler } from './kolkataMarkets';
import {
  ANIMAL_HEART_TIERS,
  addAnimalHeartForId,
  AnimalRig,
  animateAnimalRig,
  applyPetLevelVisuals,
  buildAnimalHeartPickupMesh,
  buildAnimalRig,
  clampAnimalHeartTier,
  getOrCreatePlayerId,
  loadAnimalHeartsForId,
  loadPermanentPetForId,
  loadPlayerProgressionForId,
  rollAnimalHeartDropTier,
  savePermanentPetForId,
  TAME_GOLDEN_RING_RADIUS,
  upgradePermanentPetForId,
  upgradePlayerWithAnimalHeartsForId,
  WILD_ANIMAL_CATALOG,
  WILD_ANIMAL_SPECIES_LIST,
} from './petSystem';
import { GraphicsQuality } from './settings';
import { createTextureBundle, TextureBundle } from './textures';
import {
  AnimalHeartTier,
  AnimalHeartWallet,
  BusMode,
  CircleCollider,
  EnemyArchetype,
  GamchaStyle,
  GameMode,
  GamePhase,
  HERO_OUTFIT_CATALOG,
  HeroOutfitId,
  HudSnapshot,
  LevelUpFeedback,
  PickupKind,
  PlayerProgressionState,
  RadarBlip,
  TamedPetRecord,
  VirtualInputState,
  WEAPON_CATALOG,
  WEAPON_SLOT_ORDER,
  WeaponSlotSnapshot,
  WeaponType,
  WildAnimalHudState,
  WildAnimalSpecies,
} from './types';
import { buildWestBengalWorld, WorldBuildResult } from './worldBuilder';

interface ActiveEnemy {
  id: number;
  archetype: EnemyArchetype;
  rig: EnemyRig;
  hp: number;
  maxHp: number;
  speed: number;
  radius: number;
  fireRange: number;
  fireCooldown: number;
  telegraphTimer: number;
  strafeDir: number;
  strafeTimer: number;
  walkPhase: number;
  hitFlashTimer: number;
  dying: boolean;
  deathTimer: number;
  knockback: THREE.Vector3;
  // Bus riding, smooth jump landing & 2-second post-landing safe phase
  busSeatIndex: number; // -1 when on foot or jumping
  busDropT: number;
  jumpingFromBus: boolean;
  jumpProgress: number;
  jumpDuration: number;
  jumpStart: THREE.Vector3;
  jumpEnd: THREE.Vector3;
  jumpPeakY: number;
  postLandingSafeTimer: number; // 2.0s after touching y=0 before enemy can aim or shoot
  // Natural human animation states (damped yaw, cloth lag, recoil, blinking, landing cushion)
  prevYaw: number;
  yawRate: number;
  recoil: number;
  blinkTimer: number;
  blinkPhase: number;
  moveBlend: number;
  landingCrouch: number;
  deathSide: number;
  // Tactical cover AI, smooth velocity, combat posture & hit-flinch feedback
  velX: number;
  velZ: number;
  tacticState: 'advance' | 'seek_cover' | 'hold_cover' | 'flank';
  tacticTimer: number;
  coverX: number;
  coverZ: number;
  hasCoverSpot: boolean;
  coverPeekTimer: number;
  coverPeeking: boolean;
  coverCrouch: number;
  aimBlend: number;
  flinchTimer: number;
  flinchHead: boolean;
  flinchSide: number;
  burstRemaining: number;
  burstDelay: number;
}

interface Bullet {
  active: boolean;
  fromPlayer: boolean;
  mesh: THREE.Mesh;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  life: number;
  damage: number;
  sourceX: number;
  sourceZ: number;
}

interface ImpactFlash {
  active: boolean;
  mesh: THREE.Mesh;
  material: THREE.MeshBasicMaterial;
  life: number;
  maxLife: number;
  maxScale: number;
}

interface Particle {
  active: boolean;
  mesh: THREE.Mesh;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  life: number;
  maxLife: number;
  scale: number;
}

interface PickupItem {
  id: number;
  kind: PickupKind;
  mesh: THREE.Group;
  pos: THREE.Vector3;
  life: number;
}

interface LootChestItem {
  id: number;
  rig: WarriorChestRig;
  pos: THREE.Vector3;
  opened: boolean;
  openProgress: number;
  life: number;
}

interface ThrownGrenade {
  id: number;
  mesh: THREE.Group;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  fuseTimer: number;
}

interface FloatingDamageText {
  sprite: THREE.Sprite;
  texture: THREE.CanvasTexture;
  material: THREE.SpriteMaterial;
  pos: THREE.Vector3;
  velY: number;
  life: number;
  maxLife: number;
  baseScaleX: number;
  baseScaleY: number;
}

interface ExplosionShockwave {
  mesh: THREE.Mesh;
  life: number;
  maxLife: number;
}

interface ActiveWildAnimal {
  id: number;
  species: WildAnimalSpecies;
  rig: AnimalRig;
  level: number;
  attackDamage: number;
  isHeartBearer: boolean;
  heartTier: AnimalHeartTier | null;
  heartValue: number;
  hp: number;
  maxHp: number;
  subdueRatio: number;
  radius: number;
  pos: THREE.Vector3;
  velX: number;
  velZ: number;
  yaw: number;
  walkPhase: number;
  moveBlend: number;
  state: 'roam' | 'rest' | 'provoked' | 'flee' | 'subdued' | 'dead';
  stateTimer: number;
  attackCooldown: number;
  subduedRecoveryTimer: number;
  hitFlashTimer: number;
  flinchTimer: number;
  deathTimer: number;
  subduedAnnounced: boolean;
  fleeAnnounced: boolean;
  fleeWeaveSign: number;
  evadeTimer: number;
  evadeDir: number;
  evadeCooldown: number;
  bulletDodgeCooldown: number;
  bulletDodgeWindow: number;
  dodgeVelX: number;
  dodgeVelZ: number;
  homeX: number;
  homeZ: number;
  roamTargetX: number;
  roamTargetZ: number;
  roamRadius: number;
  discovered: boolean;
  provoked: boolean;
  aggroTimer: number;
  lastDamagedTimer: number;
  cueTimer: number;
  emberTimer: number;
  lungeBurstTimer: number;
  lungeBurstCooldown: number;
  areaBn: string;
}

interface ActiveAnimalHeartDrop {
  id: number;
  tier: AnimalHeartTier;
  value: number;
  mesh: THREE.Group;
  pos: THREE.Vector3;
  life: number;
}

interface ActivePetCompanion {
  record: TamedPetRecord;
  rig: AnimalRig;
  hp: number;
  maxHp: number;
  pos: THREE.Vector3;
  velX: number;
  velZ: number;
  yaw: number;
  walkPhase: number;
  moveBlend: number;
  assistState: 'follow' | 'dash' | 'return';
  assistTargetId: number | null;
  assistTargetWild: boolean;
  assistTargetWildId: number | null;
  assistCooldown: number;
  assistTimer: number;
  retreatHealTimer: number;
  placedOnFoot: boolean;
}

// Pre-allocated zero-GC scratch helpers
const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _v3 = new THREE.Vector3();
const _v4 = new THREE.Vector3();
const _v5 = new THREE.Vector3();
const _v6 = new THREE.Vector3();
const _camTarget = new THREE.Vector3();
const _camDesired = new THREE.Vector3();
const _lookAtPt = new THREE.Vector3();

const STORAGE_KEY_HIGHSCORE = 'banglar_joddha_high_score_v1';

const BENGALI_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
export function toBengaliNumber(n: number): string {
  return String(Math.max(0, Math.floor(n)))
    .split('')
    .map((ch) => {
      const code = ch.charCodeAt(0) - 48;
      return code >= 0 && code <= 9 ? BENGALI_DIGITS[code] : ch;
    })
    .join('');
}

export class GameEngine {
  private container: HTMLElement;
  private onHudUpdate: (snapshot: HudSnapshot) => void;
  private isSoftwareGl: boolean;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private ambientLight: THREE.AmbientLight;
  private hemiLight: THREE.HemisphereLight;
  private sunLight: THREE.DirectionalLight;
  private rimLight: THREE.DirectionalLight;
  private frontFillLight: THREE.DirectionalLight;
  private caveTorchLight: THREE.PointLight;
  private baseEnvironmentIntensity = 0.38;
  private caveMoodBlend = 0;
  private caveDripTimer = 3.5;
  private wildernessCueGlobalCooldown = 2.0;
  private rareWhisperCooldown = 4.0;
  private rideDustTimer = 0;
  private readonly dayFogColor = new THREE.Color(0xb5bcb9);
  private readonly caveFogColor = new THREE.Color(0x13171e);
  private readonly daySkyColor = new THREE.Color(0x76899a);
  private readonly caveSkyColor = new THREE.Color(0x0f1319);
  private textures: TextureBundle;
  private world: WorldBuildResult;
  private bus: WbtcBusRig;
  private busRoute: BusRouteData;
  private hero: HeroRig;
  private audio: GameAudio;

  // Game state
  private phase: GamePhase = 'title';
  private gameMode: GameMode = 'survival';
  private busMode: BusMode = 'none';
  private busAutoDriving = false;
  private busRouteT = 0;
  private busPos = new THREE.Vector3(-13, 0, 8.2);
  private busYaw = -Math.PI / 2;
  private busSpeed = 0;
  private busSteerAngle = 0;
  private busZoneLabel: string | null = null;
  private nearBus = false;
  // Rideable Kolkata Bicycles (সাইকেল) & Motorcycles/Bikes (বাইক)
  private activeTwoWheeler: RideableTwoWheeler | null = null;
  private nearTwoWheeler: RideableTwoWheeler | null = null;
  private ridePos = new THREE.Vector3();
  private rideYaw = 0;
  private rideSpeed = 0;
  private rideSteer = 0;
  private rideLean = 0;
  private ridePitch = 0;
  private ridePedalPhase = 0;
  // Realistic WBTC Bus Interior Camera & Direct Ground Exit (Braking + Bi-Fold Door Open, No Parachute)
  private busInteriorCam = true;
  private busExitSlowing = false;
  private busExitSlowTimer = 0;
  private readonly busExitSlowDuration = 0.54;
  private busDoorOpenAmount = 0;
  private busDoorAutoHoldTimer = 0;
  private busInteriorLookYaw = 0;
  private heroDoorwayWorld = new THREE.Vector3();
  // Short grounded hop arc when stepping/jumping directly onto bridge or road from open bus door
  private heroJumpingFromBus = false;
  private heroJumpProgress = 0;
  private heroJumpDuration = 0.26;
  private heroJumpStart = new THREE.Vector3();
  private heroJumpEnd = new THREE.Vector3();
  private heroJumpPeakY = 1.2;

  private gamchaStyle: GamchaStyle = 'red-white';
  private heroOutfit: HeroOutfitId = 'classic_khadi';
  private heroKurtaMat: THREE.MeshPhysicalMaterial | null = null;
  private heroPantsMat: THREE.MeshStandardMaterial | null = null;
  private heroRigMat: THREE.MeshStandardMaterial | null = null;
  private weaponType: WeaponType = 'agni47';
  private weaponSlots: Record<WeaponType, WeaponSlotSnapshot> = {
    agni47: {
      ammo: WEAPON_CATALOG.agni47.magSize,
      maxAmmo: WEAPON_CATALOG.agni47.magSize,
      reserve: WEAPON_CATALOG.agni47.startReserve,
    },
    kalbhairav: {
      ammo: WEAPON_CATALOG.kalbhairav.magSize,
      maxAmmo: WEAPON_CATALOG.kalbhairav.magSize,
      reserve: WEAPON_CATALOG.kalbhairav.startReserve,
    },
    trishul: {
      ammo: WEAPON_CATALOG.trishul.magSize,
      maxAmmo: WEAPON_CATALOG.trishul.magSize,
      reserve: WEAPON_CATALOG.trishul.startReserve,
    },
    fala: { ammo: 0, maxAmmo: 0, reserve: 0 },
  };
  private scopeActive = false;
  private currentFov = 68;
  private meleeSlashTimer = 0;

  private heroPos = new THREE.Vector3(0, 0, 7.2);
  private readonly heroWorldScale = 1.16;
  private prevHeroPos = new THREE.Vector3(0, 0, 7.2);
  private prevHeroYaw = 0.28;
  private heroYaw = 0.28; // heroic 3/4 stance facing lobby camera
  private lobbyHeroYaw = 0.28;
  private lobbyHeroTargetYaw = 0.28;
  private lobbyShowcasePulse = 0;
  private heroWalkPhase = 0;
  private heroWalkWeight = 0;
  private heroSprintWeight = 0;
  private heroAimWeight = 0;
  private heroAimPitch = 0;
  private heroTurnLean = 0;
  private heroStrafeBlend = 0;
  private heroForwardBlend = 0;
  private heroVelX = 0;
  private heroVelZ = 0;
  private heroSpeedMult = 1.0;
  private heroFireHoldTimer = 0;
  private heroLandingCrouch = 0;
  private heroJumpOffset = 0;
  private heroVerticalVel = 0;
  private heroAirBlend = 0;
  private isCrouching = false;
  private heroCrouchBlend = 0;
  private heroBlinkTimer = 2.6;
  private heroBlinkPhase = 0;
  private heroRecoil = 0;
  private muzzleFlashTimer = 0;
  private health = 100;
  private maxHealth = 100;
  private armor = 0;
  private readonly maxArmor = 50;
  private isReloading = false;
  private reloadTimer = 0;
  private reloadDuration = 1.15;
  private fireCooldown = 0;
  private sprintStamina = 1.0;
  private sprintToggled = false;
  private sprintHasMovedSinceToggle = false;
  private sprintIdleTimer = 0;
  private customHudEditing = false;

  // Sanjibani Healing Plants & Bajra Gola Grenades
  private sanjibaniCount = 1;
  private sanjibaniCollected = 0;
  private readonly maxSanjibani = 5;
  private isHealing = false;
  private healTimer = 0;
  private readonly healDuration = 3.0;
  private grenadeCount = 1;
  private readonly maxGrenades = 3;

  // Warrior Loot Chests proximity
  private nearChest = false;
  private nearestChest: LootChestItem | null = null;

  // Headshot & Body Shot counters
  private headshots = 0;
  private bodyshots = 0;
  private hitMarkerHeadshot = false;

  // Kalboishakhi Shrinking Safe Zone (starts full-map at 780u across expanded 1520x1520 map, contracts in 4 stages every 90s)
  private stormRig!: KalboishakhiStormRig;
  private stormCenter = new THREE.Vector2(0, 6);
  private readonly initialStormRadius = 780;
  private readonly stormPhaseInterval = 90;
  private stormPhase = 1;
  private stormRadius = 780;
  private stormStartRadius = 780;
  private stormTargetRadius = 780;
  private stormCountdown = 90;
  private stormShrinking = false;
  private stormShrinkElapsed = 0;
  private readonly stormShrinkDuration = 22;
  private readonly outsideStormDuration = 60;
  private outsideStorm = false;
  private outsideStormElapsed = 0;
  private stormDrainTimer = 0;
  private stormTeleportFlash = 0;

  private score = 0;
  private highScore = 0;
  private kills = 0;
  private wave = 1;
  private readonly maxMapEnemies = 40;
  private totalEnemiesSpawned = 0;
  private matchVictory = false;
  private waveEnemiesToSpawn: EnemyArchetype[] = [];
  private waveSpawnTimer = 0;
  private waveBreakTimer = 0;
  private waveBanner: string | null = null;
  private waveBannerTimer = 0;
  private pickupToast: string | null = null;
  private pickupToastTimer = 0;

  // Juice, Lobby & Camera Transition
  private camYaw = Math.PI; // looking north (-Z) toward the river & bridge
  private camPitch = 0.2;
  private camShake = 0;
  private camRecoilPitch = 0;
  private camRecoilYaw = 0;
  private camSprintBlend = 0;
  private reticleSpread = 0;
  private hitstopTimer = 0;
  private damageFlash = 0;
  private damageAngle: number | null = null;
  private damageSourcePos = new THREE.Vector3();
  private hasDamageSource = false;
  private hitMarker = 0;
  private hitMarkerKill = false;
  private titleTime = 0;
  private worldTime = 0;
  private introTransitionProgress = 1; // < 1 while sweeping from lobby into gameplay
  private readonly introTransitionDuration = 0.92;
  private introStartCamPos = new THREE.Vector3();
  private introStartLookAt = new THREE.Vector3();
  private lobbyDragActive = false;
  private lobbyDragPointerId: number | null = null;
  private lobbyLastDragX = 0;

  // Entities & Pools
  private enemies: ActiveEnemy[] = [];
  private nextEnemyId = 1;
  private pickups: PickupItem[] = [];
  private nextPickupId = 1;
  private chests: LootChestItem[] = [];
  private nextChestId = 1;
  private grenades: ThrownGrenade[] = [];
  private nextGrenadeId = 1;
  private floatingDamages: FloatingDamageText[] = [];
  private shockwaves: ExplosionShockwave[] = [];
  private bullets: Bullet[] = [];
  private particles: Particle[] = [];
  private impactFlashes: ImpactFlash[] = [];

  // Challenging Animal-to-Pet Taming, Lifetime One-Pet Companion, Player Level-Up & Selective Animal Hearts (per Player ID)
  private playerId: string;
  private playerProgression: PlayerProgressionState;
  private levelUpNotice: LevelUpFeedback | null = null;
  private levelUpNoticeTimer = 0;
  private levelUpSeq = 0;
  private permanentPet: TamedPetRecord | null = null;
  private animalHearts: AnimalHeartWallet;
  private animalHeartDrops: ActiveAnimalHeartDrop[] = [];
  private nextHeartDropId = 1;
  private heartBearerStreak = 0;
  private petCompanion: ActivePetCompanion | null = null;
  private wildAnimals: ActiveWildAnimal[] = [];
  private nextWildAnimalId = 1;
  private tamingTargetId: number | null = null;
  private wildAnimalRespawnTimer = 10.0;
  private wildAnimalSpawnIndex = 0;
  private tamingActive = false;
  private tamingProgress = 0;
  private readonly tamingDuration = 4.5;
  private tamingStartHeroPos = new THREE.Vector3();
  private tamingStatusText: string | null = null;
  private tamingStatusTimer = 0;
  private tamingTickAccum = 0;
  private tamingResistStage = 0;

  // Input state (including mobile 2-finger pinch-to-zoom)
  private keysHeld = new Set<string>();
  private mouseShootHeld = false;
  private dragLookActive = false;
  private dragPointerId: number | null = null;
  private lastDragX = 0;
  private lastDragY = 0;
  private activeTouchPointers = new Map<number, { x: number; y: number }>();
  private lastPinchDist: number | null = null;
  private pinchFovOffset = 0;
  private virtualInput: VirtualInputState = {
    moveX: 0,
    moveY: 0,
    shooting: false,
    sprinting: false,
    reloadJustPressed: false,
    lookDeltaX: 0,
    lookDeltaY: 0,
  };

  // Player Settings (Sensitivity & Mobile Graphics Quality)
  private generalSensitivity = 50;
  private scopeSensitivity = 45;
  private graphicsQuality: GraphicsQuality = 'medium';

  // Loop & lifecycle
  private disposed = false;
  private frameId = 0;
  private lastFrameMs = 0;
  private hudEmitAccum = 0;
  private resizeObserver: ResizeObserver | null = null;
  private orientationResizeTimer: number | null = null;

  constructor(container: HTMLElement, onHudUpdate: (snapshot: HudSnapshot) => void) {
    this.container = container;
    this.onHudUpdate = onHudUpdate;
    this.audio = new GameAudio();
    this.playerId = getOrCreatePlayerId();
    this.playerProgression = loadPlayerProgressionForId(this.playerId);
    this.maxHealth = this.playerProgression.maxHealth;
    this.health = this.maxHealth;
    this.permanentPet = loadPermanentPetForId(this.playerId);
    this.animalHearts = loadAnimalHeartsForId(this.playerId);

    try {
      const saved = localStorage.getItem(STORAGE_KEY_HIGHSCORE);
      if (saved) this.highScore = Math.max(0, parseInt(saved, 10) || 0);
    } catch {
      // ignore storage restrictions
    }

    // Software WebGL detection from GPU renderer string (never user agent)
    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 0.98;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 1.35));
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);

    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    container.appendChild(this.renderer.domElement);

    // Scene & grounded humid late-afternoon Bengal atmosphere (muted slate sky + dusty horizon depth across 1520x1520 map)
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x76899a);
    this.scene.fog = new THREE.FogExp2(0xb5bcb9, 0.00105);

    // Mandatory studio environment map via RoomEnvironment on all devices (restrained intensity keeps shadows rich & matte)
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    const envScene = new RoomEnvironment();
    this.scene.environment = pmrem.fromScene(envScene, 0.04).texture;
    this.scene.environmentIntensity = 0.38;
    envScene.dispose();
    pmrem.dispose();

    // Camera (FOV 68° for expansive full-screen mobile landscape view; far plane 3400 covers full 1520x1520 map + sky dome from any corner)
    const aspect =
      (container.clientWidth || window.innerWidth) /
      Math.max(1, container.clientHeight || window.innerHeight);
    this.camera = new THREE.PerspectiveCamera(68, aspect, 0.2, 3400);

    // Grounded gritty late-afternoon Bengal daylight rig (angled warm sun + deep earth bounce + crisp shadow contrast)
    this.ambientLight = new THREE.AmbientLight(0xd8d2c6, 0.07);
    this.scene.add(this.ambientLight);

    this.hemiLight = new THREE.HemisphereLight(0x8ea2b5, 0x362d23, 0.56);
    this.scene.add(this.hemiLight);

    // Single reusable zero-shadow warm lantern light activated smoothly only when exploring inside moody rocky caves
    this.caveTorchLight = new THREE.PointLight(0xf5a156, 0, 17, 1.85);
    this.caveTorchLight.castShadow = false;
    this.scene.add(this.caveTorchLight);

    this.sunLight = new THREE.DirectionalLight(0xffe5bd, 2.85);
    this.sunLight.position.set(46, 36, -28);
    this.sunLight.castShadow = !this.isSoftwareGl;
    this.sunLight.shadow.mapSize.set(1024, 1024);
    this.sunLight.shadow.radius = 2.1;
    const d = 32;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.sunLight.shadow.camera.near = 4;
    this.sunLight.shadow.camera.far = 140;
    this.sunLight.shadow.bias = -0.0004;
    this.sunLight.shadow.normalBias = 0.022;
    this.scene.add(this.sunLight);
    this.scene.add(this.sunLight.target);

    // Cool atmospheric rim light + restrained warm ground bounce so folds, stone, and fur retain gritty depth
    this.rimLight = new THREE.DirectionalLight(0x87a3bd, 0.36);
    this.rimLight.position.set(-34, 22, -40);
    this.scene.add(this.rimLight);

    this.frontFillLight = new THREE.DirectionalLight(0xd4bfa1, 0.14);
    this.frontFillLight.position.set(16, 16, 26);
    this.scene.add(this.frontFillLight);

    // Procedural Textures, World, WBTC Passenger Bus & Hero
    this.textures = createTextureBundle(this.renderer);
    this.world = buildWestBengalWorld(this.textures);
    this.scene.add(this.world.worldGroup);

    this.busRoute = createBusIntroRoute();
    this.scene.add(this.busRoute.rampMesh);

    this.bus = buildWbtcBus(this.textures);
    this.bus.root.position.set(-13, 0, 8.2);
    this.scene.add(this.bus.root);

    this.hero = buildBengaliHero(this.textures);
    this.hero.root.position.copy(this.heroPos);
    this.hero.root.rotation.y = this.heroYaw;
    this.hero.root.scale.setScalar(this.heroWorldScale);
    this.scene.add(this.hero.root);

    // Cache shared PBR outfit material references for instant zero-allocation live 3D dress switching
    if (this.hero.kurtaHem.material instanceof THREE.MeshPhysicalMaterial) {
      this.heroKurtaMat = this.hero.kurtaHem.material;
    }
    this.hero.leftLeg.traverse((obj) => {
      if (this.heroPantsMat) return;
      if (obj instanceof THREE.Mesh && obj.material instanceof THREE.MeshStandardMaterial) {
        if (obj.material.color.getHex() === 0x2a323b) {
          this.heroPantsMat = obj.material;
        }
      }
    });
    this.hero.upperBodyGroup.traverse((obj) => {
      if (this.heroRigMat) return;
      if (obj instanceof THREE.Mesh && obj.material instanceof THREE.MeshStandardMaterial) {
        if (obj.material.color.getHex() === 0x2f362d) {
          this.heroRigMat = obj.material;
        }
      }
    });

    // Restore player's permanent lifetime companion (if already tamed on this Player ID)
    if (this.permanentPet) {
      this.spawnPermanentPetCompanion(this.permanentPet);
    }

    // Kalboishakhi Shrinking Storm Wall (hidden in title lobby, active during match)
    this.stormRig = buildKalboishakhiStormWall();
    this.stormRig.root.visible = false;
    this.scene.add(this.stormRig.root);

    // Pre-allocate bullet & particle pools
    this.initPools();

    // Pre-warm shaders on GPU (skip on software WebGL)
    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.bindEvents();
    this.audio.setLobbyMusicActive(true);
    this.emitHud();

    this.lastFrameMs = performance.now();
    this.tick();
  }

  private initPools(): void {
    // High-readability elongated golden-white player tracers & crisp orange-red enemy tracers
    const playerBulletGeo = new THREE.BoxGeometry(0.055, 0.055, 1.35);
    const enemyBulletGeo = new THREE.SphereGeometry(0.13, 6, 6);
    const playerBulletMat = new THREE.MeshBasicMaterial({ color: 0xfff0a8 });
    const enemyBulletMat = new THREE.MeshBasicMaterial({ color: 0xff4224 });

    for (let i = 0; i < 52; i++) {
      const isPlayer = i < 30;
      const mesh = new THREE.Mesh(
        isPlayer ? playerBulletGeo : enemyBulletGeo,
        isPlayer ? playerBulletMat : enemyBulletMat,
      );
      mesh.visible = false;
      this.scene.add(mesh);
      this.bullets.push({
        active: false,
        fromPlayer: isPlayer,
        mesh,
        pos: new THREE.Vector3(),
        vel: new THREE.Vector3(),
        life: 0,
        damage: isPlayer ? 34 : 11,
        sourceX: 0,
        sourceZ: 0,
      });
    }

    const partGeo = new THREE.BoxGeometry(0.13, 0.13, 0.13);
    for (let i = 0; i < 84; i++) {
      const mat = new THREE.MeshBasicMaterial({ color: 0xffb84d });
      const mesh = new THREE.Mesh(partGeo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.particles.push({
        active: false,
        mesh,
        pos: new THREE.Vector3(),
        vel: new THREE.Vector3(),
        life: 0,
        maxLife: 0.4,
        scale: 1,
      });
    }

    // Pooled 3D impact burst rings for unmistakable hit confirmation on enemies & cover
    const ringGeo = new THREE.RingGeometry(0.11, 0.24, 16);
    for (let i = 0; i < 14; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xffe066,
        transparent: true,
        opacity: 0.9,
        side: THREE.DoubleSide,
        depthWrite: false,
      });
      const mesh = new THREE.Mesh(ringGeo, mat);
      mesh.visible = false;
      mesh.renderOrder = 20;
      this.scene.add(mesh);
      this.impactFlashes.push({
        active: false,
        mesh,
        material: mat,
        life: 0,
        maxLife: 0.16,
        maxScale: 1.5,
      });
    }
  }

  // --- Public API for React UI ---

  public setGamchaStyle(style: GamchaStyle, silent = false): void {
    this.gamchaStyle = style;
    this.hero.gamchaMaterial.map =
      style === 'green-white' ? this.textures.gamchaGreenMap : this.textures.gamchaMap;
    this.hero.gamchaMaterial.needsUpdate = true;
    if (!silent) {
      this.lobbyShowcasePulse = 1.0;
      this.audio.unlock();
      this.audio.playPickup('health');
    }
  }

  public setHeroOutfit(outfitId: HeroOutfitId, silent = false): void {
    const meta = HERO_OUTFIT_CATALOG[outfitId] ?? HERO_OUTFIT_CATALOG.classic_khadi;
    this.heroOutfit = meta.id;
    if (this.heroKurtaMat) {
      this.heroKurtaMat.color.setHex(meta.kurtaHex);
      this.heroKurtaMat.sheenColor.setHex(meta.kurtaSheenHex);
      this.heroKurtaMat.needsUpdate = true;
    }
    if (this.heroPantsMat) {
      this.heroPantsMat.color.setHex(meta.pantsHex);
      this.heroPantsMat.needsUpdate = true;
    }
    if (this.heroRigMat) {
      this.heroRigMat.color.setHex(meta.rigHex);
      this.heroRigMat.needsUpdate = true;
    }
    if (!silent) {
      this.lobbyShowcasePulse = 1.0;
      this.audio.unlock();
      this.audio.playPickup('health');
    }
  }

  private syncHeroWeaponVisibility(): void {
    const showWeapon = this.activeTwoWheeler === null;
    this.hero.rifleGroup.visible = showWeapon && this.weaponType === 'agni47';
    this.hero.shotgunGroup.visible = showWeapon && this.weaponType === 'kalbhairav';
    this.hero.trishulGroup.visible = showWeapon && this.weaponType === 'trishul';
    this.hero.falaGroup.visible = showWeapon && this.weaponType === 'fala';
  }

  public setWeaponType(weapon: WeaponType, silent = false): void {
    if (this.activeTwoWheeler !== null) return;
    this.weaponType = weapon;
    this.syncHeroWeaponVisibility();
    this.hero.muzzlePoint.position.set(
      0,
      0.028,
      weapon === 'trishul' ? 1.28 : weapon === 'kalbhairav' ? 0.92 : 0.97,
    );

    // Cancel reload when switching weapons; keep zoom smoothly synced
    this.isReloading = false;
    this.reloadTimer = 0;
    this.reloadDuration = WEAPON_CATALOG[weapon].reloadDuration || 1.15;
    if (weapon === 'fala') {
      this.scopeActive = false;
      this.pinchFovOffset = 0;
    }

    if (!silent) {
      this.lobbyShowcasePulse = 1.0;
      this.audio.unlock();
      this.audio.playReload();
    }
    this.emitHud();
  }

  public toggleScope(): void {
    if (this.phase !== 'playing' || this.busMode !== 'none' || this.activeTwoWheeler !== null) return;
    this.scopeActive = !this.scopeActive;
    this.pinchFovOffset = 0;
    if (this.scopeActive) {
      this.isHealing = false;
      this.cancelSprintToggle();
    }
    this.emitHud();
  }

  public useSanjibani(): void {
    if (
      this.phase !== 'playing' ||
      this.busMode !== 'none' ||
      this.heroJumpingFromBus ||
      this.activeTwoWheeler !== null
    ) {
      return;
    }
    if (this.isHealing) return;
    if (this.sanjibaniCount <= 0) {
      this.pickupToast = 'সঞ্জীবনী গাছ নেই!';
      this.pickupToastTimer = 1.4;
      this.emitHud();
      return;
    }
    if (this.health >= this.maxHealth) {
      this.pickupToast = 'স্বাস্থ্য ইতিমধ্যেই পূর্ণ!';
      this.pickupToastTimer = 1.4;
      this.emitHud();
      return;
    }
    this.audio.unlock();
    this.isHealing = true;
    this.healTimer = this.healDuration;
    this.scopeActive = false;
    this.isReloading = false;
    this.cancelSprintToggle();
    this.pickupToast = 'সঞ্জীবনী গাছ ব্যবহার হচ্ছে...';
    this.pickupToastTimer = 1.5;
    this.emitHud();
  }

  public throwGrenade(): void {
    if (
      this.phase !== 'playing' ||
      this.busMode !== 'none' ||
      this.heroJumpingFromBus ||
      this.activeTwoWheeler !== null
    ) {
      return;
    }
    if (this.grenadeCount <= 0) {
      this.pickupToast = 'বজ্র গোলা নেই!';
      this.pickupToastTimer = 1.4;
      this.emitHud();
      return;
    }

    this.audio.unlock();
    this.audio.playGrenadeThrow();
    this.grenadeCount--;
    this.isHealing = false;
    this.scopeActive = false;
    if (this.tamingActive) {
      this.cancelTaming('বজ্র গোলা ছোড়ায় বশ করার চেষ্টা ব্যাহত!');
    }

    const mesh = buildBajraGolaMesh();
    const startPos = new THREE.Vector3(this.heroPos.x, 1.55, this.heroPos.z);
    const camForward = _v1.set(0, 0, -1).applyQuaternion(this.camera.quaternion).normalize();
    startPos.addScaledVector(camForward, 0.75);
    mesh.position.copy(startPos);
    this.scene.add(mesh);

    // Smooth parabolic lob trajectory
    const vel = camForward.clone().multiplyScalar(15.5);
    vel.y = Math.max(5.8, vel.y + 5.6);

    this.grenades.push({
      id: this.nextGrenadeId++,
      mesh,
      pos: startPos,
      vel,
      fuseTimer: 3.0,
    });

    this.pickupToast = 'বজ্র গোলা নিক্ষেপ!';
    this.pickupToastTimer = 1.4;
    this.emitHud();
  }

  public openNearestChest(): void {
    if (
      this.phase !== 'playing' ||
      this.busMode !== 'none' ||
      this.heroJumpingFromBus ||
      this.activeTwoWheeler !== null
    ) {
      return;
    }
    const chest = this.nearestChest;
    if (!chest || chest.opened) return;
    if (chest.pos.distanceTo(this.heroPos) > 3.6) return;

    chest.opened = true;
    this.nearChest = false;
    this.nearestChest = null;
    this.audio.unlock();
    this.audio.playChestOpen();

    // Golden treasure spark burst
    this.spawnParticles(_v1.set(chest.pos.x, 0.75, chest.pos.z), 0xffd24a, 16, 5.2);

    // Rich Battle Royale loot bundle: Ammo + Raksha Kabach + Sanjibani + Bajra Gola + Weapon Supply
    const rewards: string[] = [];

    // 1. Raksha Kabach (50-pt blue Shield Bar)
    if (this.armor < this.maxArmor) {
      this.armor = this.maxArmor;
      this.hero.armorVestOverlay.visible = true;
      rewards.push('রক্ষা কবচ +৫০');
    }

    // 2. Sanjibani Healing Plant (up to 5)
    if (this.sanjibaniCount < this.maxSanjibani) {
      this.sanjibaniCount = Math.min(this.maxSanjibani, this.sanjibaniCount + 1);
      this.sanjibaniCollected++;
      rewards.push('সঞ্জীবনী +১');
    }

    // 3. Bajra Gola Grenade (up to 3)
    if (this.grenadeCount < this.maxGrenades) {
      this.grenadeCount = Math.min(this.maxGrenades, this.grenadeCount + 1);
      rewards.push('বজ্র গোলা +১');
    }

    // 4. Weapon & Ammo top-up (random spotlight weapon + active firearm refill)
    const featuredList: WeaponType[] = ['agni47', 'kalbhairav', 'trishul'];
    const featured = featuredList[chest.id % featuredList.length];
    const featMeta = WEAPON_CATALOG[featured];
    const featSlot = this.weaponSlots[featured];
    const addAmt = featured === 'trishul' ? 6 : featured === 'kalbhairav' ? 8 : 24;
    featSlot.reserve = Math.min(featMeta.maxReserve, featSlot.reserve + addAmt);
    rewards.push(`${featMeta.shortName} গুলি +${toBengaliNumber(addAmt)}`);

    // Also top up active weapon reserve if different
    if (this.weaponType !== 'fala' && this.weaponType !== featured) {
      const aMeta = WEAPON_CATALOG[this.weaponType];
      const aSlot = this.weaponSlots[this.weaponType];
      aSlot.reserve = Math.min(aMeta.maxReserve, aSlot.reserve + aMeta.magSize);
    }

    this.score += 40;
    this.checkHighScore();
    this.pickupToast = `সিন্দুক: ${rewards.slice(0, 3).join(' · ')}`;
    this.pickupToastTimer = 2.6;
    this.emitHud();
  }

  public setGameMode(mode: GameMode): void {
    this.gameMode = mode;
    this.emitHud();
  }

  public startTamingWildAnimal(): void {
    if (
      this.phase !== 'playing' ||
      this.gameMode !== 'pet_taming' ||
      this.busMode !== 'none' ||
      this.heroJumpingFromBus ||
      this.activeTwoWheeler !== null
    ) {
      return;
    }
    if (this.tamingActive) return;

    // Strict lifetime one-pet rule per Player ID
    if (this.permanentPet !== null) {
      this.audio.unlock();
      this.audio.playTameFail();
      this.pickupToast = 'এই আইডি-তে ইতিমধ্যেই আজীবনের স্থায়ী সঙ্গী আছে!';
      this.pickupToastTimer = 2.6;
      this.emitHud();
      return;
    }

    // Find nearest alive wild animal to tame
    let nearestSubdued: ActiveWildAnimal | null = null;
    let nearestSubduedDist = Infinity;
    let nearestAlive: ActiveWildAnimal | null = null;
    let nearestAliveDist = Infinity;
    for (const wa of this.wildAnimals) {
      if (wa.state === 'dead' || wa.hp <= 0) continue;
      const d = Math.hypot(wa.pos.x - this.heroPos.x, wa.pos.z - this.heroPos.z);
      if (d < nearestAliveDist) {
        nearestAliveDist = d;
        nearestAlive = wa;
      }
      if (wa.state === 'subdued' && d < nearestSubduedDist) {
        nearestSubduedDist = d;
        nearestSubdued = wa;
      }
    }

    const wa = nearestSubdued ?? nearestAlive;
    if (!wa) return;

    if (wa.state !== 'subdued') {
      if (nearestAliveDist <= 26) {
        this.audio.unlock();
        this.pickupToast = 'বশ করতে হলে প্রাণীটিকে না মেরে ২২% এর নিচে দুর্বল করুন!';
        this.pickupToastTimer = 2.1;
        this.emitHud();
      }
      return;
    }

    const dist = Math.hypot(wa.pos.x - this.heroPos.x, wa.pos.z - this.heroPos.z);
    if (dist > TAME_GOLDEN_RING_RADIUS) {
      this.audio.unlock();
      this.pickupToast = 'বশ করতে সোনালি বলয়ের ভেতরে প্রবেশ করুন!';
      this.pickupToastTimer = 1.7;
      this.emitHud();
      return;
    }

    this.audio.unlock();
    this.tamingActive = true;
    this.tamingTargetId = wa.id;
    this.tamingProgress = 0;
    this.tamingTickAccum = 0;
    this.tamingResistStage = 0;
    this.tamingStartHeroPos.copy(this.heroPos);
    this.isReloading = false;
    this.isHealing = false;
    this.scopeActive = false;
    this.cancelSprintToggle();
    this.mouseShootHeld = false;
    this.virtualInput.shooting = false;
    this.tamingStatusText = 'এক চুলও নড়বেন না — ৪.৫ সেকেন্ড স্থির থাকুন!';
    this.tamingStatusTimer = 4.8;
    this.audio.playTameTick(0);
    this.emitHud();
  }

  private cancelTaming(reasonBn: string, playFailSound = true): void {
    if (!this.tamingActive) return;
    this.tamingActive = false;
    this.tamingTargetId = null;
    this.tamingProgress = 0;
    this.tamingTickAccum = 0;
    this.tamingResistStage = 0;
    this.tamingStatusText = reasonBn;
    this.tamingStatusTimer = 2.4;
    this.pickupToast = reasonBn;
    this.pickupToastTimer = 2.4;
    if (playFailSound) {
      this.audio.playTameFail();
    }
    this.emitHud();
  }

  public startGame(mode?: GameMode): void {
    if (mode) {
      this.gameMode = mode;
    }
    this.audio.unlock();
    this.clearDynamicEntities();
    this.resetAllTwoWheelers();
    this.resetCaveAtmosphere();

    const comingFromLobby = this.phase === 'title';
    const isPetTamingMode = this.gameMode === 'pet_taming';

    this.phase = 'playing';
    this.audio.setLobbyMusicActive(false);
    this.busMode = isPetTamingMode ? 'none' : 'riding_intro';
    this.busAutoDriving = !isPetTamingMode;
    this.busRouteT = 0.03;
    this.busSpeed = 12;
    this.busSteerAngle = 0;
    this.busInteriorCam = true;
    this.busExitSlowing = false;
    this.busExitSlowTimer = 0;
    this.busDoorOpenAmount = 0;
    this.busDoorAutoHoldTimer = 0;
    this.busInteriorLookYaw = 0;
    this.bus.interior.setDoorOpenAmount(0);
    this.bus.interior.introDriverGroup.visible = true;
    this.nearBus = false;
    this.nearChest = false;
    this.nearestChest = null;
    this.heroJumpingFromBus = false;
    this.heroJumpProgress = 0;

    this.camYaw = Math.PI * 0.5;
    this.camPitch = 0.24;
    this.scopeActive = false;
    this.pinchFovOffset = 0;
    this.activeTouchPointers.clear();
    this.lastPinchDist = null;
    this.currentFov = 68;
    this.camera.fov = 68;
    this.camera.updateProjectionMatrix();
    this.meleeSlashTimer = 0;

    this.maxHealth = this.playerProgression.maxHealth;
    this.health = this.maxHealth;
    this.levelUpNotice = null;
    this.levelUpNoticeTimer = 0;
    this.armor = 0;
    this.hero.armorVestOverlay.visible = false;
    this.sanjibaniCount = 1;
    this.sanjibaniCollected = 0;
    this.isHealing = false;
    this.healTimer = 0;
    this.grenadeCount = 1;
    this.headshots = 0;
    this.bodyshots = 0;
    this.hitMarkerHeadshot = false;

    // Reset all 4 weapon slots cleanly from WEAPON_CATALOG
    for (const wId of WEAPON_SLOT_ORDER) {
      const m = WEAPON_CATALOG[wId];
      this.weaponSlots[wId] = {
        ammo: m.magSize,
        maxAmmo: m.magSize,
        reserve: m.startReserve,
      };
    }
    this.setWeaponType(this.weaponType);

    this.isReloading = false;
    this.reloadTimer = 0;
    this.fireCooldown = 0;
    this.sprintStamina = 1;
    this.cancelSprintToggle();
    this.score = 0;
    this.kills = 0;
    this.wave = 1;
    this.totalEnemiesSpawned = 0;
    this.matchVictory = false;
    this.damageFlash = 0;
    this.damageAngle = null;
    this.hasDamageSource = false;
    this.hitMarker = 0;
    this.camShake = 0;
    this.camRecoilPitch = 0;
    this.camRecoilYaw = 0;
    this.camSprintBlend = 0;
    this.reticleSpread = 0;
    this.pickupToast = null;
    this.lobbyDragActive = false;
    this.lobbyDragPointerId = null;
    this.wildAnimalRespawnTimer = 10.0;
    this.tamingActive = false;
    this.tamingTargetId = null;
    this.tamingProgress = 0;
    this.tamingStatusText = null;
    this.tamingStatusTimer = 0;
    if (this.petCompanion) {
      this.petCompanion.rig.root.visible = false;
      this.petCompanion.placedOnFoot = false;
      this.petCompanion.assistState = 'follow';
      this.petCompanion.assistTargetId = null;
      this.petCompanion.assistTargetWild = false;
      this.petCompanion.assistTargetWildId = null;
      this.petCompanion.retreatHealTimer = 0;
      this.petCompanion.hp = this.petCompanion.record.stats.maxHp;
      this.petCompanion.maxHp = this.petCompanion.record.stats.maxHp;
      this.petCompanion.assistCooldown = 2.0;
    }

    // Reset Kalboishakhi Shrinking Safe Zone (full-map 780u start across 1520x1520 world, 4 stages every 90 seconds)
    this.stormCenter.set((Math.random() - 0.5) * 44, 24 + (Math.random() - 0.5) * 44);
    this.stormPhase = 1;
    this.stormRadius = this.initialStormRadius;
    this.stormStartRadius = this.initialStormRadius;
    this.stormTargetRadius = this.initialStormRadius;
    this.stormCountdown = this.stormPhaseInterval;
    this.stormShrinking = false;
    this.stormShrinkElapsed = 0;
    this.outsideStorm = false;
    this.outsideStormElapsed = 0;
    this.stormDrainTimer = 0;
    this.stormTeleportFlash = 0;
    this.stormRig.root.visible = true;
    this.stormRig.root.position.set(this.stormCenter.x, 0, this.stormCenter.y);
    this.stormRig.wallMesh.scale.set(this.stormRadius, 1, this.stormRadius);
    this.stormRig.groundRing.scale.set(this.stormRadius, this.stormRadius, 1);

    this.hero.bodyGroup.scale.set(1, 1, 1);
    this.hero.bodyGroup.position.set(0, 0, 0);
    this.hero.bodyGroup.rotation.set(0, 0, 0);
    this.hero.upperBodyGroup.position.set(0, 0.94, 0);
    this.hero.upperBodyGroup.rotation.set(0, 0, 0);
    this.hero.headGroup.rotation.set(0, 0, 0);
    this.hero.hairTuft.rotation.set(0, 0, 0);
    this.hero.kurtaHem.rotation.set(0, 0, 0);
    this.hero.leftLeg.rotation.set(0, 0, 0);
    this.hero.rightLeg.rotation.set(0, 0, 0);
    this.hero.leftArm.position.set(0, 0, 0);
    this.hero.rightArm.position.set(0, 0, 0);
    this.hero.recoilGroup.position.set(0.115, 0.31, 0.27);
    this.hero.recoilGroup.rotation.set(0, 0, 0);
    this.heroWalkWeight = 0;
    this.heroSprintWeight = 0;
    this.heroAimWeight = 0;
    this.heroAimPitch = 0;
    this.heroTurnLean = 0;
    this.heroStrafeBlend = 0;
    this.heroForwardBlend = 0;
    this.heroVelX = 0;
    this.heroVelZ = 0;
    this.heroSpeedMult = 1.0;
    this.heroFireHoldTimer = 0;
    this.heroLandingCrouch = 0;
    this.heroJumpOffset = 0;
    this.heroVerticalVel = 0;
    this.heroAirBlend = 0;
    this.isCrouching = false;
    this.heroCrouchBlend = 0;

    // Spawn Warrior Loot Chests ('যোদ্ধা সিন্দুক') near village mud houses & along the riverbank
    this.spawnInitialWorldLoot();

    if (isPetTamingMode) {
      // Dedicated Pet Taming Mode: deploy directly on foot in the West Bengal village clearing
      // with zero Survival enemy waves or Kalboishakhi storm, focused purely on the taming challenge!
      this.stormRig.root.visible = false;
      this.busPos.set(-13, 0, 8.2);
      this.busYaw = -Math.PI / 2;
      this.bus.root.position.copy(this.busPos);
      this.bus.root.rotation.set(0, this.busYaw, 0);

      this.heroPos.set(0, 0, 14.0);
      this.heroPos.y = this.world.getGroundHeight(this.heroPos.x, this.heroPos.z, 0);
      this.prevHeroPos.copy(this.heroPos);
      this.heroYaw = Math.PI;
      this.prevHeroYaw = Math.PI;
      this.camYaw = Math.PI;
      this.camPitch = 0.2;
      this.hero.root.position.copy(this.heroPos);
      this.hero.root.rotation.set(0, this.heroYaw, 0);
      this.hero.root.scale.setScalar(this.heroWorldScale);
      this.hero.leftKnee.rotation.x = 0;
      this.hero.rightKnee.rotation.x = 0;
      this.hero.leftAnkle.rotation.x = 0;
      this.hero.rightAnkle.rotation.x = 0;

      this.waveEnemiesToSpawn = [];
      this.wildAnimalRespawnTimer = 14.0;
      this.spawnScatteredWildAnimals(14);

      if (this.permanentPet) {
        this.waveBanner = 'জঙ্গল, গুহা, পাহাড়, জলাভূমি, ধ্বংসাবশেষ ও তৃণভূমিতে প্রাণীরা লুকিয়ে আছে — খুঁজে বের করুন!';
      } else {
        this.waveBanner = 'পাহাড়, জলাভূমি, ধ্বংসাবশেষ, তৃণভূমি ও গুহায় প্রাণী খুঁজুন — দুর্বল করে বশ করুন!';
      }
      this.waveBannerTimer = 4.2;
      this.introTransitionProgress = 1;
      this.emitHud();
      return;
    }

    // Survival Mode: position the WBTC bus at the west end of the Howrah-style bridge
    this.positionBusOnIntroRoute(this.busRouteT);

    // Seat hero inside the hollow WBTC bus cabin facing forward down the aisle (keep 1.0x scale inside bus cabin to prevent roof clipping)
    this.bus.root.updateMatrixWorld(true);
    this.bus.heroIntroSeat.getWorldPosition(this.heroPos);
    this.hero.root.position.copy(this.heroPos);
    this.heroYaw = this.busYaw;
    this.hero.root.rotation.set(0, this.heroYaw, 0);
    this.hero.root.scale.setScalar(1.0);
    this.hero.leftLeg.rotation.x = -1.16;
    this.hero.rightLeg.rotation.x = -1.16;
    this.hero.leftKnee.rotation.x = 1.16;
    this.hero.rightKnee.rotation.x = 1.16;
    this.hero.leftAnkle.rotation.x = 0.08;
    this.hero.rightAnkle.rotation.x = 0.08;

    // Load Wave 1 AI enemies onto the WBTC bus so they ride across the bridge & exit cleanly along the village road
    this.waveEnemiesToSpawn = [];
    const dropTs = [0.64, 0.70, 0.76, 0.82, 0.88, 0.94];
    const introTypes: EnemyArchetype[] = ['scout', 'scout', 'rusher', 'scout', 'rusher', 'scout'];
    for (let i = 0; i < introTypes.length; i++) {
      this.spawnEnemyOnBus(introTypes[i], i, dropTs[i]);
    }
    // Also queue outer-countryside patrols so players explore and track down distant enemies across the expanded map
    this.waveEnemiesToSpawn.push('scout', 'rusher', 'scout', 'heavy');
    this.waveSpawnTimer = 4.5;

    // Scatter secluded non-chasing wildlife inside deep forests & caves for optional exploration
    this.spawnScatteredWildAnimals(6);

    this.waveBanner = 'WBTC বাস — হাওড়া সেতু পারাপার';
    this.waveBannerTimer = 3.0;
    this.audio.playBusHorn();

    if (comingFromLobby) {
      // Smoothly sweep camera from the lobby hero right onto the moving WBTC bus!
      this.introStartCamPos.copy(this.camera.position);
      this.introStartLookAt.set(0.15, 1.25, -4.0);
      this.introTransitionProgress = 0;
    } else {
      this.introTransitionProgress = 1;
    }

    this.emitHud();
  }

  public toggleBusCameraView(): void {
    if (this.phase !== 'playing' || this.busMode !== 'riding_intro') return;
    this.busInteriorCam = !this.busInteriorCam;
    this.busInteriorLookYaw = 0;
    this.emitHud();
  }

  public exitBus(): void {
    if (this.phase !== 'playing') return;
    if (this.busMode === 'none') return;

    this.audio.unlock();
    this.bus.root.updateMatrixWorld(true);

    if (this.busMode === 'riding_intro') {
      // Realistic direct ground exit: briefly slow the WBTC bus, hiss air-brakes, swing side door open,
      // then hop straight onto the Howrah Bridge or road surface (no parachute!)
      if (this.busExitSlowing) return;
      this.busExitSlowing = true;
      this.busExitSlowTimer = this.busExitSlowDuration;
      this.audio.playBusDoorBrake();
      this.pickupToast = 'বাস থামছে... দরজা খুলছে';
      this.pickupToastTimer = 1.1;
      this.emitHud();
      return;
    }

    if (this.busMode === 'driving') {
      // Quick grounded hop-out beside the bus onto guaranteed clear road/bridge surface
      this.audio.playBusDoorBrake();
      this.audio.playBusJump();
      this.busDoorAutoHoldTimer = 1.1;
      this.bus.interior.heroDoorwayAnchor.getWorldPosition(this.heroJumpStart);
      this.findSafeBusExitPosition(this.heroJumpEnd, 0.62, 1, 0, false);

      this.heroJumpPeakY = Math.max(this.heroJumpStart.y, this.heroJumpEnd.y) + 0.36;
      this.heroJumpDuration = 0.24;
      this.heroJumpProgress = 0;
      this.heroJumpingFromBus = true;

      this.heroYaw = this.busYaw - Math.PI * 0.5;
      this.hero.root.rotation.set(0, this.heroYaw, 0);
      this.hero.root.scale.setScalar(this.heroWorldScale);
      this.camYaw = this.busYaw;
      this.busMode = 'none';
      this.pickupToast = 'বাস থেকে নেমেছেন';
      this.pickupToastTimer = 1.6;
      this.emitHud();
    }
  }

  private executeDirectGroundExit(): void {
    if (this.busMode !== 'riding_intro') return;

    this.busExitSlowing = false;
    this.busExitSlowTimer = 0;
    this.busDoorAutoHoldTimer = 1.25;
    this.audio.playBusJump();
    this.bus.root.updateMatrixWorld(true);

    // Launch hero directly from the open side passenger doorway onto the bridge deck or village road (zero parachute!)
    this.bus.interior.heroDoorwayAnchor.getWorldPosition(this.heroJumpStart);
    this.findSafeBusExitPosition(this.heroJumpEnd, 0.66, 1, 0, true);

    const dropDiff = Math.abs(this.heroJumpStart.y - this.heroJumpEnd.y);
    this.heroJumpPeakY = Math.max(this.heroJumpStart.y, this.heroJumpEnd.y) + 0.42;
    this.heroJumpDuration = dropDiff > 1.8 ? 0.38 : 0.25;
    this.heroJumpProgress = 0;
    this.heroJumpingFromBus = true;

    this.heroYaw = this.busYaw;
    this.hero.root.rotation.set(0, this.heroYaw, 0);
    this.hero.root.scale.setScalar(this.heroWorldScale);
    this.busMode = 'none';
    this.camYaw = this.busYaw;
    this.camPitch = 0.2;
    this.pickupToast = 'বাস থেকে নেমেছেন — লড়াই শুরু!';
    this.pickupToastTimer = 2.0;
    this.emitHud();
  }

  public enterBus(): void {
    if (
      this.phase !== 'playing' ||
      this.busMode !== 'none' ||
      this.heroJumpingFromBus ||
      this.activeTwoWheeler !== null
    ) {
      return;
    }
    if (this.busAutoDriving) return;
    const dist = this.heroPos.distanceTo(this.busPos);
    if (dist > 6.2) return;

    this.audio.unlock();
    this.audio.playBusHorn();
    this.busMode = 'driving';
    this.hero.root.scale.setScalar(1.0);
    this.busDoorAutoHoldTimer = 0.65;
    this.bus.interior.introDriverGroup.visible = false;
    this.nearBus = false;
    this.nearTwoWheeler = null;
    this.nearChest = false;
    this.isReloading = false;
    this.isHealing = false;
    this.scopeActive = false;
    this.cancelSprintToggle();
    this.isCrouching = false;
    this.heroCrouchBlend = 0;
    this.heroJumpOffset = 0;
    this.heroVerticalVel = 0;
    this.heroAirBlend = 0;
    if (this.tamingActive) {
      this.cancelTaming('বাসে ওঠায় বশ করার চেষ্টা ব্যাহত!');
    }
    this.mouseShootHeld = false;
    this.virtualInput.shooting = false;
    this.pickupToast = 'WBTC বাস চালাচ্ছেন!';
    this.pickupToastTimer = 2.0;
    this.emitHud();
  }

  private resetAllTwoWheelers(): void {
    this.activeTwoWheeler = null;
    this.nearTwoWheeler = null;
    this.rideSpeed = 0;
    this.rideSteer = 0;
    this.rideLean = 0;
    this.ridePitch = 0;
    this.ridePedalPhase = 0;
    for (const v of this.world.twoWheelers) {
      v.reset();
    }
    this.syncHeroWeaponVisibility();
  }

  public mountNearestTwoWheeler(): void {
    if (
      this.phase !== 'playing' ||
      this.busMode !== 'none' ||
      this.heroJumpingFromBus ||
      this.activeTwoWheeler !== null
    ) {
      return;
    }

    // Prefer already-tracked nearest vehicle, or scan within 3.4m
    let target: RideableTwoWheeler | null = null;
    let bestDistSq = 3.4 * 3.4;
    for (const v of this.world.twoWheelers) {
      const dx = v.x - this.heroPos.x;
      const dz = v.z - this.heroPos.z;
      const dSq = dx * dx + dz * dz;
      if (dSq < bestDistSq && Math.abs(v.y - this.heroPos.y) < 2.2) {
        bestDistSq = dSq;
        target = v;
      }
    }
    if (!target) return;

    this.audio.unlock();
    this.audio.playBusJump();

    // Disable mounted vehicle's own static prop collider while riding
    const col = this.world.circleColliders[target.colliderIndex];
    if (col) {
      col.radius = 0;
    }

    this.activeTwoWheeler = target;
    this.nearTwoWheeler = null;
    this.nearBus = false;
    this.nearChest = false;
    this.nearestChest = null;

    this.ridePos.set(target.x, target.y, target.z);
    this.rideYaw = target.yaw;
    this.rideSpeed = 0;
    this.rideSteer = 0;
    this.rideLean = 0;
    this.ridePitch = 0;
    this.ridePedalPhase = 0;

    // Align camera smoothly behind the bicycle/motorcycle
    this.camYaw = this.rideYaw;
    this.camPitch = 0.2;

    // Clear all on-foot combat & movement actions (exploration/traversal only while mounted)
    this.isReloading = false;
    this.reloadTimer = 0;
    this.isHealing = false;
    this.scopeActive = false;
    this.pinchFovOffset = 0;
    this.cancelSprintToggle();
    this.isCrouching = false;
    this.heroCrouchBlend = 0;
    this.heroJumpOffset = 0;
    this.heroVerticalVel = 0;
    this.heroAirBlend = 0;
    this.heroVelX = 0;
    this.heroVelZ = 0;
    this.heroFireHoldTimer = 0;
    this.mouseShootHeld = false;
    this.virtualInput.shooting = false;
    if (this.tamingActive) {
      this.cancelTaming('যানবাহনে ওঠায় বশ করার চেষ্টা ব্যাহত!');
    }

    // Fit hero cleanly to bicycle/motorcycle seat proportions & hide weapon while riding
    this.hero.root.scale.setScalar(1.02);
    this.syncHeroWeaponVisibility();
    this.hero.muzzleFlash.visible = false;
    this.hero.muzzleLight.intensity = 0;

    this.pickupToast =
      target.kind === 'motorcycle'
        ? 'বাইকে উঠেছেন — ভ্রমণ মোড'
        : 'সাইকেলে উঠেছেন — ভ্রমণ মোড';
    this.pickupToastTimer = 1.9;
    this.emitHud();
  }

  public dismountTwoWheeler(silent = false): void {
    const v = this.activeTwoWheeler;
    if (!v) return;

    // Park the bicycle/motorcycle cleanly on the ground with its natural kickstand lean
    const parkY = this.world.getGroundHeight(this.ridePos.x, this.ridePos.z, this.ridePos.y);
    const parkedLean = v.kind === 'motorcycle' ? 0.13 : 0.11;
    v.setTransform(this.ridePos.x, parkY, this.ridePos.z, this.rideYaw, 0, parkedLean);

    // Restore static cover collider at the new parked spot
    const col = this.world.circleColliders[v.colliderIndex];
    if (col) {
      col.x = this.ridePos.x;
      col.z = this.ridePos.z;
      col.baseY = parkY;
      col.radius = v.baseColliderRadius;
    }

    // Place hero safely beside the left side of the parked vehicle (fallback right/rear if blocked)
    const fwdX = Math.sin(this.rideYaw);
    const fwdZ = Math.cos(this.rideYaw);
    const rightX = -fwdZ;
    const rightZ = fwdX;
    const candidates: Array<[number, number]> = [
      [this.ridePos.x - rightX * 1.25, this.ridePos.z - rightZ * 1.25],
      [this.ridePos.x + rightX * 1.25, this.ridePos.z + rightZ * 1.25],
      [this.ridePos.x - fwdX * 1.45, this.ridePos.z - fwdZ * 1.45],
    ];
    let chosenX = candidates[0][0];
    let chosenZ = candidates[0][1];
    for (const [cx, cz] of candidates) {
      if (!this.world.isWaterBlocked(cx, cz)) {
        chosenX = cx;
        chosenZ = cz;
        break;
      }
    }

    this.heroPos.set(chosenX, parkY, chosenZ);
    this.resolveCircleWorldCollision(this.heroPos, 0.62, true);
    this.heroPos.y = this.world.getGroundHeight(this.heroPos.x, this.heroPos.z, parkY);
    this.prevHeroPos.copy(this.heroPos);

    this.activeTwoWheeler = null;
    this.rideSpeed = 0;
    this.rideSteer = 0;
    this.rideLean = 0;
    this.ridePitch = 0;
    this.ridePedalPhase = 0;

    // Restore full on-foot hero scale, posture & active weapon
    this.heroYaw = this.rideYaw;
    this.prevHeroYaw = this.heroYaw;
    this.heroVelX = 0;
    this.heroVelZ = 0;
    this.hero.root.position.copy(this.heroPos);
    this.hero.root.rotation.set(0, this.heroYaw, 0);
    this.hero.root.scale.setScalar(this.heroWorldScale);
    this.hero.bodyGroup.position.set(0, 0, 0);
    this.hero.bodyGroup.rotation.set(0, 0, 0);
    this.hero.upperBodyGroup.position.set(0, 0.94, 0);
    this.hero.upperBodyGroup.rotation.set(0, 0, 0);
    this.hero.leftLeg.rotation.set(0, 0, 0);
    this.hero.rightLeg.rotation.set(0, 0, 0);
    this.hero.leftKnee.rotation.set(0, 0, 0);
    this.hero.rightKnee.rotation.set(0, 0, 0);
    this.hero.leftAnkle.rotation.set(0, 0, 0);
    this.hero.rightAnkle.rotation.set(0, 0, 0);
    this.hero.leftArm.position.set(0, 0, 0);
    this.hero.rightArm.position.set(0, 0, 0);
    this.hero.headGroup.rotation.set(0, 0, 0);
    this.syncHeroWeaponVisibility();

    if (!silent) {
      this.audio.unlock();
      this.audio.playBusJump();
      this.pickupToast =
        v.kind === 'motorcycle' ? 'বাইক থেকে নেমেছেন' : 'সাইকেল থেকে নেমেছেন';
      this.pickupToastTimer = 1.6;
      this.emitHud();
    }
  }

  public honkBusHorn(): void {
    if (this.phase !== 'playing' || this.busMode === 'none') return;
    this.audio.unlock();
    this.audio.playBusHorn();
  }

  public setCustomHudEditing(editing: boolean): void {
    this.customHudEditing = editing;
    this.mouseShootHeld = false;
    this.virtualInput.shooting = false;
    this.virtualInput.moveX = 0;
    this.virtualInput.moveY = 0;
    this.dragLookActive = false;
    this.dragPointerId = null;
    this.activeTouchPointers.clear();
    this.lastPinchDist = null;
    this.lobbyDragActive = false;
    this.lobbyDragPointerId = null;
    this.cancelSprintToggle();
    if (editing) {
      this.keysHeld.clear();
      this.safeExitPointerLock();
    }
    this.emitHud();
  }

  public setPaused(paused: boolean): void {
    if (paused && this.phase === 'playing') {
      this.phase = 'paused';
      this.keysHeld.clear();
      this.mouseShootHeld = false;
      this.virtualInput.shooting = false;
      this.virtualInput.moveX = 0;
      this.virtualInput.moveY = 0;
      this.dragLookActive = false;
      this.dragPointerId = null;
      this.activeTouchPointers.clear();
      this.lastPinchDist = null;
      this.cancelSprintToggle();
      this.safeExitPointerLock();
      this.emitHud();
    } else if (!paused && this.phase === 'paused') {
      this.phase = 'playing';
      this.lastFrameMs = performance.now();
      this.emitHud();
    }
  }

  public togglePause(): void {
    if (this.phase === 'playing') {
      this.setPaused(true);
    } else if (this.phase === 'paused') {
      this.setPaused(false);
    }
  }

  public setSensitivity(general: number, scope: number): void {
    this.generalSensitivity = THREE.MathUtils.clamp(general, 0, 100);
    this.scopeSensitivity = THREE.MathUtils.clamp(scope, 0, 100);
  }

  private getGeneralLookFactor(): number {
    return 0.15 + (this.generalSensitivity / 100) * 1.85;
  }

  private getScopeLookFactor(): number {
    return 0.08 + (this.scopeSensitivity / 100) * 0.92;
  }

  private getPixelRatioCap(): number {
    if (this.isSoftwareGl) return 1;
    const dpr = window.devicePixelRatio || 1;
    if (this.graphicsQuality === 'low') return Math.min(dpr, 1.0);
    if (this.graphicsQuality === 'medium') return Math.min(dpr, 1.35);
    return Math.min(dpr, 1.75);
  }

  private applyShadowMapSize(size: number, radius: number, frustumHalf = 32): void {
    if (
      this.sunLight.shadow.mapSize.x !== size ||
      this.sunLight.shadow.mapSize.y !== size
    ) {
      if (this.sunLight.shadow.map) {
        this.sunLight.shadow.map.dispose();
        this.sunLight.shadow.map = null;
      }
      this.sunLight.shadow.mapSize.set(size, size);
    }
    this.sunLight.shadow.radius = radius;
    this.sunLight.shadow.camera.left = -frustumHalf;
    this.sunLight.shadow.camera.right = frustumHalf;
    this.sunLight.shadow.camera.top = frustumHalf;
    this.sunLight.shadow.camera.bottom = -frustumHalf;
    this.sunLight.shadow.camera.updateProjectionMatrix();
    this.sunLight.shadow.needsUpdate = true;
    this.renderer.shadowMap.needsUpdate = true;
  }

  public setGraphicsQuality(quality: GraphicsQuality): void {
    this.graphicsQuality = quality;
    this.renderer.setPixelRatio(this.getPixelRatioCap());

    if (quality === 'low') {
      this.baseEnvironmentIntensity = 0.32;
      this.scene.environmentIntensity = this.baseEnvironmentIntensity * (1 - this.caveMoodBlend * 0.62);
      this.renderer.toneMappingExposure = 1.0;
      this.renderer.shadowMap.enabled = false;
      this.sunLight.castShadow = false;
      this.renderer.shadowMap.needsUpdate = true;
    } else if (quality === 'medium') {
      this.baseEnvironmentIntensity = 0.38;
      this.scene.environmentIntensity = this.baseEnvironmentIntensity * (1 - this.caveMoodBlend * 0.62);
      this.renderer.toneMappingExposure = 0.98;
      if (this.isSoftwareGl) {
        this.renderer.shadowMap.enabled = false;
        this.sunLight.castShadow = false;
        this.renderer.shadowMap.needsUpdate = true;
      } else {
        this.renderer.shadowMap.enabled = true;
        this.sunLight.castShadow = true;
        this.applyShadowMapSize(1024, 2.1, 32);
      }
    } else {
      this.baseEnvironmentIntensity = 0.42;
      this.scene.environmentIntensity = this.baseEnvironmentIntensity * (1 - this.caveMoodBlend * 0.62);
      this.renderer.toneMappingExposure = 0.97;
      if (this.isSoftwareGl) {
        this.renderer.shadowMap.enabled = false;
        this.sunLight.castShadow = false;
        this.renderer.shadowMap.needsUpdate = true;
      } else {
        this.renderer.shadowMap.enabled = true;
        this.sunLight.castShadow = true;
        this.applyShadowMapSize(2048, 2.4, 40);
      }
    }

    const w = this.container.clientWidth || window.innerWidth;
    const h = Math.max(1, this.container.clientHeight || window.innerHeight);
    this.renderer.setSize(w, h, false);
  }

  public setAudioSettings(enabled: boolean, volumePercent: number): void {
    const vol = THREE.MathUtils.clamp(volumePercent / 100, 0, 1);
    this.audio.setSfxVolume(vol);
    this.audio.setMuted(!enabled);
    this.emitHud();
  }

  private safeExitPointerLock(): void {
    try {
      if (document.pointerLockElement === this.renderer.domElement) {
        document.exitPointerLock();
      }
    } catch {
      // Ignore iframe/browser pointer-lock exit rejections
    }
  }

  private updateHeroBlink(dt: number): void {
    if (this.heroBlinkPhase > 0) {
      this.heroBlinkPhase += dt / 0.16;
      if (this.heroBlinkPhase >= 1) {
        this.heroBlinkPhase = 0;
        this.hero.setBlink(0);
      } else {
        this.hero.setBlink(Math.pow(Math.sin(this.heroBlinkPhase * Math.PI), 0.85));
      }
    } else {
      this.heroBlinkTimer -= dt;
      if (this.heroBlinkTimer <= 0) {
        this.heroBlinkPhase = 0.001;
        this.heroBlinkTimer = 2.6 + Math.random() * 3.1;
      }
    }
  }

  private resetCaveAtmosphere(): void {
    this.caveMoodBlend = 0;
    this.caveDripTimer = 2.6;
    this.wildernessCueGlobalCooldown = 0;
    this.rareWhisperCooldown = 0;
    this.rideDustTimer = 0;
    this.sunLight.intensity = 2.85;
    this.hemiLight.intensity = 0.56;
    this.ambientLight.intensity = 0.07;
    this.rimLight.intensity = 0.36;
    this.frontFillLight.intensity = 0.14;
    this.scene.environmentIntensity = this.baseEnvironmentIntensity;
    if (this.scene.fog instanceof THREE.FogExp2) {
      this.scene.fog.color.copy(this.dayFogColor);
      this.scene.fog.density = 0.00105;
    }
    if (this.scene.background instanceof THREE.Color) {
      this.scene.background.copy(this.daySkyColor);
    }
    this.caveTorchLight.intensity = 0;
  }

  public returnToTitle(): void {
    this.clearDynamicEntities();
    this.resetAllTwoWheelers();
    this.resetCaveAtmosphere();
    this.phase = 'title';
    this.matchVictory = false;
    this.audio.setLobbyMusicActive(true);
    this.busMode = 'none';
    this.busAutoDriving = false;
    this.busInteriorCam = true;
    this.busExitSlowing = false;
    this.busExitSlowTimer = 0;
    this.busDoorOpenAmount = 0;
    this.busDoorAutoHoldTimer = 0;
    this.busInteriorLookYaw = 0;
    this.bus.interior.setDoorOpenAmount(0);
    this.bus.interior.introDriverGroup.visible = true;
    this.heroJumpingFromBus = false;
    this.nearBus = false;
    this.nearChest = false;
    this.nearestChest = null;
    this.scopeActive = false;
    this.isHealing = false;
    this.armor = 0;
    this.hero.armorVestOverlay.visible = false;
    this.stormRig.root.visible = false;
    this.outsideStorm = false;
    this.outsideStormElapsed = 0;
    this.stormDrainTimer = 0;
    this.stormTeleportFlash = 0;
    this.currentFov = 68;
    this.camera.fov = 68;
    this.camera.updateProjectionMatrix();
    this.heroPos.set(0, 0, 7.2);
    this.lobbyHeroYaw = 0.28;
    this.lobbyHeroTargetYaw = 0.28;
    this.heroYaw = 0.28;
    this.hero.root.position.copy(this.heroPos);
    this.hero.root.rotation.set(0, this.lobbyHeroYaw, 0);
    this.hero.root.scale.setScalar(this.heroWorldScale);
    this.hero.bodyGroup.position.set(0, 0, 0);
    this.hero.bodyGroup.rotation.set(0, 0, 0);
    this.hero.upperBodyGroup.position.set(0, 0.94, 0);
    this.hero.upperBodyGroup.rotation.set(0, 0, 0);
    this.hero.leftLeg.rotation.set(0, 0, 0);
    this.hero.rightLeg.rotation.set(0, 0, 0);
    this.hero.leftKnee.rotation.set(0, 0, 0);
    this.hero.rightKnee.rotation.set(0, 0, 0);
    this.hero.leftAnkle.rotation.set(0, 0, 0);
    this.hero.rightAnkle.rotation.set(0, 0, 0);
    this.hero.headGroup.rotation.set(0, 0, 0);
    this.hero.hairTuft.rotation.set(0, 0, 0);
    this.hero.kurtaHem.rotation.set(0, 0, 0);
    this.hero.leftArm.position.set(0, 0, 0);
    this.hero.rightArm.position.set(0, 0, 0);
    this.hero.recoilGroup.position.set(0.115, 0.31, 0.27);
    this.hero.recoilGroup.rotation.set(0, 0, 0);
    this.hero.setBlink(0);
    this.heroWalkWeight = 0;
    this.heroSprintWeight = 0;
    this.heroAimWeight = 0;
    this.heroAimPitch = 0;
    this.heroTurnLean = 0;
    this.heroStrafeBlend = 0;
    this.heroForwardBlend = 0;
    this.heroVelX = 0;
    this.heroVelZ = 0;
    this.heroSpeedMult = 1.0;
    this.heroFireHoldTimer = 0;
    this.heroLandingCrouch = 0;
    this.heroJumpOffset = 0;
    this.heroVerticalVel = 0;
    this.heroAirBlend = 0;
    this.isCrouching = false;
    this.heroCrouchBlend = 0;
    this.cancelSprintToggle();
    this.camRecoilPitch = 0;
    this.camRecoilYaw = 0;
    this.camSprintBlend = 0;
    this.reticleSpread = 0;
    this.damageAngle = null;
    this.hasDamageSource = false;
    this.prevHeroPos.copy(this.heroPos);
    this.prevHeroYaw = this.lobbyHeroYaw;
    this.introTransitionProgress = 1;
    this.safeExitPointerLock();
    this.emitHud();
  }

  public toggleMute(): void {
    this.audio.unlock();
    this.audio.toggleMute();
    this.emitHud();
  }

  private cancelSprintToggle(): void {
    this.sprintToggled = false;
    this.sprintHasMovedSinceToggle = false;
    this.sprintIdleTimer = 0;
    this.virtualInput.sprinting = false;
  }

  public setVirtualMove(x: number, y: number): void {
    this.virtualInput.moveX = THREE.MathUtils.clamp(x, -1, 1);
    this.virtualInput.moveY = THREE.MathUtils.clamp(y, -1, 1);
  }

  public setVirtualShoot(active: boolean): void {
    if (this.customHudEditing || this.activeTwoWheeler !== null) {
      this.virtualInput.shooting = false;
      return;
    }
    if (active) this.audio.unlock();
    this.virtualInput.shooting = active;
  }

  public setVirtualSprint(active: boolean): void {
    if (!active) {
      this.cancelSprintToggle();
      return;
    }
    if (!this.sprintToggled) {
      this.toggleSprint();
    }
  }

  public toggleSprint(): void {
    this.audio.unlock();
    if (
      this.phase !== 'playing' ||
      this.busMode !== 'none' ||
      this.heroJumpingFromBus ||
      this.activeTwoWheeler !== null
    ) {
      return;
    }
    if (this.sprintToggled) {
      this.cancelSprintToggle();
      this.emitHud();
      return;
    }
    if (this.sprintStamina <= 0.1) {
      this.emitHud();
      return;
    }
    this.sprintToggled = true;
    this.virtualInput.sprinting = true;
    this.sprintIdleTimer = 0;
    const moveNow =
      Math.hypot(this.virtualInput.moveX, this.virtualInput.moveY) > 0.2 ||
      this.keysHeld.has('KeyW') ||
      this.keysHeld.has('ArrowUp');
    this.sprintHasMovedSinceToggle = moveNow;
    this.isCrouching = false;
    this.scopeActive = false;
    this.isHealing = false;
    this.emitHud();
  }

  public triggerReload(): void {
    if (this.activeTwoWheeler !== null) return;
    this.audio.unlock();
    this.virtualInput.reloadJustPressed = true;
  }

  public triggerJump(): void {
    this.audio.unlock();
    if (
      this.phase !== 'playing' ||
      this.busMode !== 'none' ||
      this.heroJumpingFromBus ||
      this.activeTwoWheeler !== null
    ) {
      return;
    }
    if (this.heroJumpOffset > 0.05) return;

    // Jumping smoothly exits crouch & healing, and breaks stationary taming channel
    this.isCrouching = false;
    this.isHealing = false;
    if (this.tamingActive) {
      this.cancelTaming('লাফ দেওয়ায় বশ করার চেষ্টা ব্যাহত!');
    }
    this.heroVerticalVel = 6.9;
    this.heroJumpOffset = 0.02;
    this.audio.playBusJump();
    this.emitHud();
  }

  public toggleCrouch(): void {
    this.audio.unlock();
    if (
      this.phase !== 'playing' ||
      this.busMode !== 'none' ||
      this.heroJumpingFromBus ||
      this.activeTwoWheeler !== null
    ) {
      return;
    }
    this.isCrouching = !this.isCrouching;
    if (this.isCrouching) {
      this.cancelSprintToggle();
    }
    this.emitHud();
  }

  // --- Wave & Entity Management ---

  private clearDynamicEntities(): void {
    for (const e of this.enemies) {
      this.scene.remove(e.rig.root);
    }
    this.enemies = [];
    for (const p of this.pickups) {
      this.scene.remove(p.mesh);
    }
    this.pickups = [];
    for (const c of this.chests) {
      this.scene.remove(c.rig.root);
    }
    this.chests = [];
    this.nearChest = false;
    this.nearestChest = null;
    for (const g of this.grenades) {
      this.scene.remove(g.mesh);
    }
    this.grenades = [];
    for (const fd of this.floatingDamages) {
      this.scene.remove(fd.sprite);
      fd.texture.dispose();
      fd.material.dispose();
    }
    this.floatingDamages = [];
    for (const sw of this.shockwaves) {
      this.scene.remove(sw.mesh);
      sw.mesh.geometry.dispose();
      (sw.mesh.material as THREE.Material).dispose();
    }
    this.shockwaves = [];
    for (const b of this.bullets) {
      b.active = false;
      b.mesh.visible = false;
    }
    for (const pt of this.particles) {
      pt.active = false;
      pt.mesh.visible = false;
    }
    for (const fl of this.impactFlashes) {
      fl.active = false;
      fl.mesh.visible = false;
    }
    for (const wa of this.wildAnimals) {
      this.scene.remove(wa.rig.root);
    }
    this.wildAnimals = [];
    this.tamingTargetId = null;
    for (const drop of this.animalHeartDrops) {
      this.scene.remove(drop.mesh);
    }
    this.animalHeartDrops = [];
    this.tamingActive = false;
    this.tamingProgress = 0;
    this.tamingStatusText = null;
    this.tamingStatusTimer = 0;
  }

  private spawnInitialWorldLoot(): void {
    // 1. Warrior Loot Chests ('যোদ্ধা সিন্দুক') beside village mud house verandas & along Hooghly riverbank
    const chestSpots: Array<[number, number, number]> = [
      // Village house porch / veranda spots (outside house circle collider so player walks right up)
      [-12.2, -1.6, 0.35],
      [-13.4, 15.8, 1.25],
      [13.0, 14.5, -1.35],
      [-6.8, 21.8, 0.15],
      [10.2, 21.2, -0.25],
      // Hooghly Riverbank ghat chests
      [-7.8, -14.2, 0.0],
      [8.6, -14.0, 0.0],
    ];
    for (const [cx, cz, rotY] of chestSpots) {
      this.spawnWarriorChest(cx, cz, rotY);
    }

    // Landmark Warrior Loot Chests (Sal Forest, Zamindar Bari downstairs & 2nd-floor terrace, Tram Depot, Extended Ghat)
    for (const anchor of this.world.landmarkChestAnchors) {
      this.spawnWarriorChest(anchor.x, anchor.z, anchor.rotY, anchor.y);
    }

    // 2. Glowing emerald Sanjibani medicinal herb plants ('সঞ্জীবনী গাছ') across grassy village terrain
    const plantSpots: Array<[number, number]> = [
      [-10.5, -10.0],
      [11.8, -9.8],
      [-9.5, 9.8],
      [10.2, 8.8],
      [-1.8, 18.2],
      [-22.5, 4.5],
      [22.5, 4.2],
      [3.5, -12.5],
    ];
    for (const [px, pz] of plantSpots) {
      this.spawnPickup(px, pz, 'sanjibani', true);
    }

    // Extra Sanjibani medicinal herbs across Sal Forest hills, Zamindar Bari garden, Tram Depot & Riverbank Ghat
    for (const herb of this.world.landmarkSanjibaniAnchors) {
      this.spawnPickup(herb.x, herb.z, 'sanjibani', true);
    }

    // 3. Initial Raksha Kabach armor pickups near Village Taxi, Zamindar Bari courtyard & Tram Depot
    this.spawnPickup(3.2, -6.5, 'armor', true);
    this.spawnPickup(98.0, 25.5, 'armor', true);
    this.spawnPickup(0.0, -110.0, 'armor', true);
  }

  private spawnWarriorChest(x: number, z: number, rotY = 0, forcedY?: number): void {
    const pos = new THREE.Vector3(x, forcedY ?? 0, z);
    if (forcedY === undefined) {
      this.resolveCircleWorldCollision(pos, 0.72, false);
      pos.y = this.world.getGroundHeight(pos.x, pos.z);
    } else {
      pos.y = forcedY;
    }

    const rig = buildWarriorChest();
    rig.root.position.copy(pos);
    rig.root.rotation.y = rotY;
    this.scene.add(rig.root);

    this.chests.push({
      id: this.nextChestId++,
      rig,
      pos,
      opened: false,
      openProgress: 0,
      life: 600,
    });
  }

  private spawnFloatingDamage(worldPos: THREE.Vector3, amount: number, isHeadshot: boolean): void {
    const label = `-${toBengaliNumber(amount)}`;
    const { sprite, texture, material } = createFloatingDamageSprite(label, isHeadshot);
    const pos = worldPos.clone();
    pos.x += (Math.random() - 0.5) * 0.32;
    pos.y += isHeadshot ? 0.35 : 0.2;
    pos.z += (Math.random() - 0.5) * 0.32;
    sprite.position.copy(pos);
    this.scene.add(sprite);

    this.floatingDamages.push({
      sprite,
      texture,
      material,
      pos,
      velY: isHeadshot ? 1.85 : 1.35,
      life: isHeadshot ? 1.05 : 0.85,
      maxLife: isHeadshot ? 1.05 : 0.85,
      baseScaleX: sprite.scale.x,
      baseScaleY: sprite.scale.y,
    });
  }

  private beginWave(waveNum: number): void {
    const remainingBudget = Math.max(0, this.maxMapEnemies - this.totalEnemiesSpawned);
    if (remainingBudget <= 0) {
      this.waveEnemiesToSpawn = [];
      return;
    }

    this.wave = waveNum;
    const desiredCount = Math.min(12, 6 + waveNum * 2);
    const totalCount = Math.min(remainingBudget, desiredCount);
    const queue: EnemyArchetype[] = [];

    for (let i = 0; i < totalCount; i++) {
      const r = Math.random();
      if (waveNum >= 3 && r < 0.25) {
        queue.push('heavy');
      } else if (waveNum >= 2 && r < 0.52) {
        queue.push('rusher');
      } else {
        queue.push('scout');
      }
    }

    this.waveEnemiesToSpawn = queue;
    this.waveSpawnTimer = 0.6;
    this.waveBanner = `তরঙ্গ ${toBengaliNumber(waveNum)} · বাকি শত্রু ${toBengaliNumber(remainingBudget)}`;
    this.waveBannerTimer = 2.6;
    this.audio.playWaveStart();

    // Refresh helpful Battle Royale loot near the village square at start of waves >= 2
    if (waveNum >= 2) {
      const anchor = this.world.pickupAnchors[waveNum % this.world.pickupAnchors.length];
      this.spawnWarriorChest(anchor.x, anchor.z, Math.random() * Math.PI * 2);
      const plantAnchor = this.world.pickupAnchors[(waveNum + 2) % this.world.pickupAnchors.length];
      this.spawnPickup(plantAnchor.x, plantAnchor.z, 'sanjibani');
    }
  }

  private spawnEnemy(archetype: EnemyArchetype): void {
    const aliveCount = this.enemies.filter((e) => !e.dying).length;
    if (aliveCount >= this.maxMapEnemies || this.totalEnemiesSpawned >= this.maxMapEnemies) {
      return;
    }
    this.totalEnemiesSpawned++;
    // Distribute enemies across the expanded map inside the safe storm zone so players must search, flank & track them
    const heroNorth = this.heroPos.z < -45;
    const nearBridge = Math.abs(this.heroPos.x) < 80 && Math.abs(this.heroPos.z + 40) < 55;
    const maxStormR = Math.max(38, this.stormRadius - 12);
    const minSearchDist = this.stormRadius > 140 ? 56 : Math.min(34, maxStormR * 0.45);
    const maxPreferredDist = this.stormRadius > 240 ? 225 : maxStormR;

    const inSafeZone = this.world.enemySpawnPoints.filter((pt) => {
      const dStorm = Math.hypot(pt.x - this.stormCenter.x, pt.z - this.stormCenter.y);
      return dStorm <= maxStormR;
    });
    const poolBase = inSafeZone.length > 0 ? inSafeZone : this.world.enemySpawnPoints;

    // Prefer same bank of the Hooghly River (unless hero is near Howrah Bridge) so bots engage reliably without river stalls
    const sameBank = nearBridge
      ? poolBase
      : poolBase.filter((pt) => (pt.z < -45) === heroNorth);
    const bankPool = sameBank.length > 0 ? sameBank : poolBase;

    // Prefer well-spaced mid-to-long range sectors (56m–225m) rather than right next to the player
    const idealPool = bankPool.filter((pt) => {
      const d = Math.hypot(pt.x - this.heroPos.x, pt.z - this.heroPos.z);
      return d >= minSearchDist && d <= maxPreferredDist;
    });
    const fallbackPool = bankPool.filter(
      (pt) => Math.hypot(pt.x - this.heroPos.x, pt.z - this.heroPos.z) >= minSearchDist * 0.65,
    );
    const finalPool =
      idealPool.length > 0
        ? idealPool
        : fallbackPool.length > 0
          ? fallbackPool
          : bankPool;

    // Sample multiple candidates and pick one well separated from existing enemies for natural map spread
    let bestPt = finalPool[Math.floor(Math.random() * finalPool.length)];
    let bestScore = -Infinity;
    const tries = Math.min(6, finalPool.length);
    for (let t = 0; t < tries; t++) {
      const pt = finalPool[Math.floor(Math.random() * finalPool.length)];
      let nearestEnemyDist = 140;
      for (const existing of this.enemies) {
        if (existing.dying) continue;
        const dE = Math.hypot(
          pt.x - existing.rig.root.position.x,
          pt.z - existing.rig.root.position.z,
        );
        if (dE < nearestEnemyDist) nearestEnemyDist = dE;
      }
      const dHero = Math.hypot(pt.x - this.heroPos.x, pt.z - this.heroPos.z);
      const score = nearestEnemyDist * 1.15 + Math.min(dHero, 180) * 0.45 + Math.random() * 24;
      if (score > bestScore) {
        bestScore = score;
        bestPt = pt;
      }
    }

    const rig = buildEnemyBot(archetype, this.textures);
    const scale = archetype === 'heavy' ? 1.36 : archetype === 'rusher' ? 1.16 : 1.22;
    rig.bodyGroup.scale.setScalar(scale);
    rig.hpBarBg.position.y = 2.15 * scale;
    const enemyRadius = archetype === 'heavy' ? 0.78 : 0.62;
    const bounds = this.world.playableBounds;
    const spawnPos = new THREE.Vector3(
      THREE.MathUtils.clamp(bestPt.x + (Math.random() - 0.5) * 9.0, bounds.minX + 8, bounds.maxX - 8),
      0,
      THREE.MathUtils.clamp(bestPt.z + (Math.random() - 0.5) * 9.0, bounds.minZ + 8, bounds.maxZ - 8),
    );
    this.resolveCircleWorldCollision(spawnPos, enemyRadius, false);
    spawnPos.y = this.world.getGroundHeight(spawnPos.x, spawnPos.z, 0);
    rig.root.position.copy(spawnPos);
    this.scene.add(rig.root);

    const waveHpScale = 1 + (this.wave - 1) * 0.12;
    const maxHp =
      archetype === 'heavy'
        ? Math.round(140 * waveHpScale)
        : archetype === 'rusher'
          ? Math.round(60 * waveHpScale)
          : Math.round(82 * waveHpScale);

    const speed =
      archetype === 'heavy'
        ? 3.1
        : archetype === 'rusher'
          ? 6.1
          : 4.35;

    this.enemies.push({
      id: this.nextEnemyId++,
      archetype,
      rig,
      hp: maxHp,
      maxHp,
      speed,
      radius: enemyRadius,
      fireRange: archetype === 'rusher' ? 14 : 26,
      fireCooldown: 1.0 + Math.random() * 1.0,
      telegraphTimer: 0,
      strafeDir: Math.random() > 0.5 ? 1 : -1,
      strafeTimer: 1.4 + Math.random() * 1.8,
      walkPhase: Math.random() * Math.PI * 2,
      hitFlashTimer: 0,
      dying: false,
      deathTimer: 0,
      knockback: new THREE.Vector3(),
      busSeatIndex: -1,
      busDropT: -1,
      jumpingFromBus: false,
      jumpProgress: 1,
      jumpDuration: 0.45,
      jumpStart: new THREE.Vector3(),
      jumpEnd: new THREE.Vector3(),
      jumpPeakY: 1.8,
      postLandingSafeTimer: 0.6,
      prevYaw: rig.root.rotation.y,
      yawRate: 0,
      recoil: 0,
      blinkTimer: 1.5 + Math.random() * 3.5,
      blinkPhase: 0,
      moveBlend: 0,
      landingCrouch: 0,
      deathSide: Math.random() > 0.5 ? 1 : -1,
      velX: 0,
      velZ: 0,
      tacticState: archetype === 'rusher' ? 'flank' : 'advance',
      tacticTimer: 1.4 + Math.random() * 1.6,
      coverX: spawnPos.x,
      coverZ: spawnPos.z,
      hasCoverSpot: false,
      coverPeekTimer: 1.2 + Math.random() * 1.0,
      coverPeeking: true,
      coverCrouch: 0,
      aimBlend: 0,
      flinchTimer: 0,
      flinchHead: false,
      flinchSide: 1,
      burstRemaining: 0,
      burstDelay: 0,
    });
  }

  private spawnEnemyOnBus(archetype: EnemyArchetype, seatIndex: number, dropT: number): void {
    const aliveCount = this.enemies.filter((e) => !e.dying).length;
    if (aliveCount >= this.maxMapEnemies || this.totalEnemiesSpawned >= this.maxMapEnemies) {
      return;
    }
    this.totalEnemiesSpawned++;
    const rig = buildEnemyBot(archetype, this.textures);
    // Keep bus passengers at 1.0x scale inside the cabin; scale up smoothly when they step off the bus
    rig.bodyGroup.scale.setScalar(1.0);
    this.scene.add(rig.root);

    const maxHp = archetype === 'rusher' ? 60 : 82;
    const speed = archetype === 'rusher' ? 5.9 : 4.25;

    this.enemies.push({
      id: this.nextEnemyId++,
      archetype,
      rig,
      hp: maxHp,
      maxHp,
      speed,
      radius: 0.55,
      fireRange: archetype === 'rusher' ? 14 : 26,
      fireCooldown: 1.1 + Math.random() * 0.8,
      telegraphTimer: 0,
      strafeDir: Math.random() > 0.5 ? 1 : -1,
      strafeTimer: 1.4 + Math.random() * 1.6,
      walkPhase: Math.random() * Math.PI * 2,
      hitFlashTimer: 0,
      dying: false,
      deathTimer: 0,
      knockback: new THREE.Vector3(),
      busSeatIndex: seatIndex % this.bus.enemySeats.length,
      busDropT: dropT,
      jumpingFromBus: false,
      jumpProgress: 0,
      jumpDuration: 0.52,
      jumpStart: new THREE.Vector3(),
      jumpEnd: new THREE.Vector3(),
      jumpPeakY: 2.0,
      postLandingSafeTimer: 2.0,
      prevYaw: 0,
      yawRate: 0,
      recoil: 0,
      blinkTimer: 1.2 + Math.random() * 3.6,
      blinkPhase: 0,
      moveBlend: 0,
      landingCrouch: 0,
      deathSide: Math.random() > 0.5 ? 1 : -1,
      velX: 0,
      velZ: 0,
      tacticState: archetype === 'rusher' ? 'flank' : 'advance',
      tacticTimer: 1.5 + Math.random() * 1.5,
      coverX: 0,
      coverZ: 0,
      hasCoverSpot: false,
      coverPeekTimer: 1.2 + Math.random() * 1.0,
      coverPeeking: true,
      coverCrouch: 0,
      aimBlend: 0,
      flinchTimer: 0,
      flinchHead: false,
      flinchSide: 1,
      burstRemaining: 0,
      burstDelay: 0,
    });
  }

  private positionBusOnIntroRoute(t: number): void {
    const clampedT = THREE.MathUtils.clamp(t, 0, 1);
    this.busRoute.curve.getPointAt(clampedT, this.busPos);
    const lookT = Math.min(1, clampedT + 0.012);
    this.busRoute.curve.getPointAt(lookT, _v1);

    if (clampedT >= 0.995) {
      // Keep final west-facing heading at village bus stop
      _v1.set(this.busPos.x - 1, this.busPos.y, this.busPos.z);
    }

    this.bus.root.position.copy(this.busPos);
    this.bus.root.lookAt(_v1);
    this.busYaw = Math.atan2(_v1.x - this.busPos.x, _v1.z - this.busPos.z);

    if (clampedT < 0.35) {
      this.busZoneLabel = 'হাওড়া সেতু';
    } else if (clampedT < 0.62) {
      this.busZoneLabel = 'হুগলি ঘাট র‍্যাম্প';
    } else if (clampedT < 0.82) {
      this.busZoneLabel = 'হলুদ ট্যাক্সি চক';
    } else {
      this.busZoneLabel = 'মাটির গ্রাম সড়ক';
    }
  }

  private spawnPickup(x: number, z: number, kind: PickupKind, persistent = false): void {
    const mesh = buildPickupMesh(kind);
    const py = this.world.getGroundHeight(x, z);
    mesh.position.set(x, py, z);
    this.scene.add(mesh);
    this.pickups.push({
      id: this.nextPickupId++,
      kind,
      mesh,
      pos: new THREE.Vector3(x, py, z),
      life: persistent ? 600 : 32,
    });
  }

  private spawnParticles(pos: THREE.Vector3, colorHex: number, count: number, speed = 5.5): void {
    let spawned = 0;
    for (const p of this.particles) {
      if (p.active) continue;
      p.active = true;
      p.pos.copy(pos);
      p.vel.set(
        (Math.random() - 0.5) * speed * 2,
        1.5 + Math.random() * speed,
        (Math.random() - 0.5) * speed * 2,
      );
      p.maxLife = 0.24 + Math.random() * 0.26;
      p.life = p.maxLife;
      p.scale = 0.7 + Math.random() * 0.9;
      (p.mesh.material as THREE.MeshBasicMaterial).color.setHex(colorHex);
      p.mesh.position.copy(p.pos);
      p.mesh.scale.setScalar(p.scale);
      p.mesh.visible = true;
      spawned++;
      if (spawned >= count) break;
    }
  }

  private spawnImpactFlash(
    pos: THREE.Vector3,
    colorHex: number,
    maxScale = 1.6,
    duration = 0.16,
  ): void {
    for (let i = 0; i < this.impactFlashes.length; i++) {
      const fl = this.impactFlashes[i];
      if (fl.active) continue;
      fl.active = true;
      fl.maxLife = duration;
      fl.life = duration;
      fl.maxScale = maxScale;
      fl.material.color.setHex(colorHex);
      fl.material.opacity = 0.95;
      fl.mesh.position.copy(pos);
      fl.mesh.scale.setScalar(0.35);
      fl.mesh.lookAt(this.camera.position);
      fl.mesh.visible = true;
      return;
    }
  }

  private spawnBullet(
    fromPlayer: boolean,
    origin: THREE.Vector3,
    direction: THREE.Vector3,
    speed: number,
    damage: number,
    sourceX = origin.x,
    sourceZ = origin.z,
  ): void {
    for (const b of this.bullets) {
      if (b.active || b.fromPlayer !== fromPlayer) continue;
      b.active = true;
      b.pos.copy(origin);
      b.vel.copy(direction).normalize().multiplyScalar(speed);
      b.life = 1.65;
      b.damage = damage;
      b.sourceX = sourceX;
      b.sourceZ = sourceZ;
      b.mesh.position.copy(origin);
      _v1.copy(origin).add(b.vel);
      b.mesh.lookAt(_v1);
      b.mesh.visible = true;
      return;
    }
  }

  // --- Combat & Firing ---

  private getEnemyScale(e: ActiveEnemy): number {
    return e.archetype === 'heavy' ? 1.36 : e.archetype === 'rusher' ? 1.16 : 1.22;
  }

  private attemptStartReload(): void {
    if (this.activeTwoWheeler !== null || this.busMode !== 'none') return;
    const meta = WEAPON_CATALOG[this.weaponType];
    if (meta.isMelee) return;
    const slot = this.weaponSlots[this.weaponType];
    if (this.isReloading || slot.ammo >= slot.maxAmmo || slot.reserve <= 0) return;
    this.isReloading = true;
    this.reloadDuration = meta.reloadDuration;
    this.reloadTimer = this.reloadDuration;
    this.isHealing = false;
    this.scopeActive = false;
    this.audio.playReload();
  }

  private performMeleeSlash(): void {
    const meta = WEAPON_CATALOG.fala;
    this.fireCooldown = meta.fireCooldown;
    this.meleeSlashTimer = 0.24;
    this.heroRecoil = 0.6;
    this.isHealing = false;
    this.cancelSprintToggle();
    if (this.tamingActive) {
      this.cancelTaming('আক্রমণ করায় বশ করার চেষ্টা ব্যাহত!');
    }
    this.audio.playWeaponShot('fala');

    // Align hero forward with camera aim
    this.heroYaw = this.camYaw;
    this.hero.root.rotation.y = this.heroYaw;
    const fwdX = Math.sin(this.camYaw);
    const fwdZ = Math.cos(this.camYaw);
    const heroChest = _v5.set(
      this.heroPos.x,
      this.heroPos.y + 1.5 - this.heroCrouchBlend * 0.36,
      this.heroPos.z,
    );

    // Check grounded enemies within fast melee slash arc (3.3m reach, wide front cone)
    for (const e of this.enemies) {
      if (e.dying || e.busSeatIndex >= 0 || e.jumpingFromBus) continue;
      const dx = e.rig.root.position.x - this.heroPos.x;
      const dz = e.rig.root.position.z - this.heroPos.z;
      const dist = Math.hypot(dx, dz);
      if (dist > 3.35) continue;
      const dot = (dx * fwdX + dz * fwdZ) / Math.max(0.001, dist);
      if (dot < 0.28) continue;

      const s = this.getEnemyScale(e);
      const targetPt = _v3.set(e.rig.root.position.x, 1.35 * s, e.rig.root.position.z);
      if (!this.hasLineOfSight(heroChest, targetPt)) continue;

      // High-aim slash (camPitch < 0.14) lands a lethal critical headshot slash!
      const isHead = this.camPitch < 0.12;
      const hitPos = _v6.set(
        e.rig.root.position.x,
        isHead ? 1.78 * s : 1.25 * s,
        e.rig.root.position.z,
      );
      _v4.set(fwdX, 0, fwdZ);
      this.damageEnemy(e, this.getScaledPlayerDamage(meta.baseDamage), _v4, isHead, hitPos);
      this.camShake = Math.min(0.28, this.camShake + 0.08);
    }

    // Melee slash can also strike any nearby wild animal (caution: can kill if already weak!)
    for (const wa of this.wildAnimals) {
      if (wa.state === 'dead') continue;
      const dx = wa.pos.x - this.heroPos.x;
      const dz = wa.pos.z - this.heroPos.z;
      const dist = Math.hypot(dx, dz);
      if (dist <= 3.5) {
        const dot = (dx * fwdX + dz * fwdZ) / Math.max(0.001, dist);
        if (dot >= 0.25) {
          const hitPos = _v6.set(wa.pos.x, wa.pos.y + 0.78, wa.pos.z);
          if (this.hasLineOfSight(heroChest, hitPos)) {
            _v4.set(fwdX, 0, fwdZ);
            this.damageWildAnimal(wa, this.getScaledPlayerDamage(meta.baseDamage * 0.65), _v4, hitPos);
            this.camShake = Math.min(0.28, this.camShake + 0.07);
          }
        }
      }
    }
  }

  private firePlayerWeapon(): void {
    if (this.isReloading || this.fireCooldown > 0) return;
    const meta = WEAPON_CATALOG[this.weaponType];

    // Slot 4 — বাংলার ফলা (fast silent melee slash)
    if (meta.isMelee) {
      this.performMeleeSlash();
      return;
    }

    const slot = this.weaponSlots[this.weaponType];
    if (slot.ammo <= 0) {
      this.fireCooldown = 0.28;
      this.audio.playDryFire();
      if (slot.reserve > 0) this.attemptStartReload();
      return;
    }

    // Firing cancels healing, sprint toggle & active taming cleanly and holds braced combat stance briefly
    this.isHealing = false;
    this.cancelSprintToggle();
    if (this.tamingActive) {
      this.cancelTaming('গুলি চালানোয় বশ করার চেষ্টা ব্যাহত!');
    }
    this.heroFireHoldTimer = 0.45;

    slot.ammo--;
    this.fireCooldown = meta.fireCooldown;
    this.heroRecoil =
      this.weaponType === 'trishul' ? 1.85 : this.weaponType === 'kalbhairav' ? 1.65 : 1.05;
    this.muzzleFlashTimer = this.weaponType === 'agni47' ? 0.055 : 0.09;
    this.camShake = Math.min(
      0.38,
      this.camShake +
        (this.weaponType === 'trishul'
          ? 0.2
          : this.weaponType === 'kalbhairav'
            ? 0.18
            : 0.08),
    );

    // Tactile PUBG/Free Fire camera recoil kick (crouching steadies recoil noticeably!)
    const crouchRecoilFactor = 1 - this.heroCrouchBlend * 0.28;
    const recoilScale = (this.scopeActive ? 0.58 : 1.0) * crouchRecoilFactor;
    const pitchKick =
      this.weaponType === 'trishul' ? 0.052 : this.weaponType === 'kalbhairav' ? 0.044 : 0.017;
    const yawKick =
      (Math.random() - 0.5) *
      (this.weaponType === 'kalbhairav' ? 0.022 : this.weaponType === 'trishul' ? 0.014 : 0.011);
    this.camRecoilPitch = Math.min(0.11, this.camRecoilPitch + pitchKick * recoilScale);
    this.camRecoilYaw = THREE.MathUtils.clamp(
      this.camRecoilYaw + yawKick * recoilScale,
      -0.035,
      0.035,
    );
    this.reticleSpread = Math.min(
      1.0,
      this.reticleSpread +
        (this.weaponType === 'kalbhairav' ? 0.52 : this.weaponType === 'trishul' ? 0.4 : 0.22) *
          crouchRecoilFactor,
    );
    this.audio.playWeaponShot(this.weaponType);

    // Determine world aim direction from center camera ray
    const camForward = _v1.set(0, 0, -1).applyQuaternion(this.camera.quaternion).normalize();
    const maxAimDist = this.weaponType === 'trishul' ? 90 : 50;
    const aimTarget = _v2.copy(this.camera.position).addScaledVector(camForward, maxAimDist);
    const heroChest = _v5.set(
      this.heroPos.x,
      this.heroPos.y + 1.5 - this.heroCrouchBlend * 0.36,
      this.heroPos.z,
    );

    // Respect solid obstacles along camera sightline first
    const obsT = this.segmentFirstObstacleT(this.camera.position, aimTarget, true);
    if (obsT < 1) {
      aimTarget.lerpVectors(this.camera.position, aimTarget, obsT);
    }

    // Precision aim-assist that preserves player's Head vs Body aim!
    // When scoped with Trishul Sniper, use tighter cone (0.992) so exact crosshair placement rules;
    // on hip-fire use forgiving cone (0.955) and choose Head if crosshair points closer to head than chest.
    const assistThreshold = this.scopeActive ? 0.992 : 0.955;
    let bestTargetPt: THREE.Vector3 | null = null;
    let bestDot = assistThreshold;

    for (const e of this.enemies) {
      if (e.dying || e.busSeatIndex >= 0 || e.jumpingFromBus) continue;
      const s = this.getEnemyScale(e);
      const ey = e.rig.root.position.y;

      // Evaluate both Head (1.74 * s) and Chest (1.16 * s) centers against camera sightline
      const headY = ey + 1.74 * s;
      const chestY = ey + 1.16 * s;

      for (const yAim of [headY, chestY]) {
        _v3.set(e.rig.root.position.x, yAim, e.rig.root.position.z);
        const toPt = _v4.subVectors(_v3, this.camera.position);
        const dist = toPt.length();
        if (dist > maxAimDist || dist < 1.0) continue;
        toPt.divideScalar(dist);
        const dot = toPt.dot(camForward);
        // Tiny preference for head when aimed cleanly at head height
        const scoreDot = yAim === headY ? dot + 0.0015 : dot;
        if (scoreDot > bestDot && this.hasLineOfSight(heroChest, _v3)) {
          bestDot = scoreDot;
          if (!bestTargetPt) bestTargetPt = new THREE.Vector3();
          bestTargetPt.copy(_v3);
        }
      }
    }

    // Also evaluate discovered/nearby wild animals in aim-assist cone (only when close enough to spot)
    for (const wa of this.wildAnimals) {
      if (wa.state === 'dead') continue;
      const bodyS = WILD_ANIMAL_CATALOG[wa.species].bodyScale;
      _v3.set(wa.pos.x, wa.pos.y + 0.72 * bodyS, wa.pos.z);
      const toPt = _v4.subVectors(_v3, this.camera.position);
      const dist = toPt.length();
      if (dist <= Math.min(maxAimDist, 42) && dist >= 1.0) {
        toPt.divideScalar(dist);
        const dot = toPt.dot(camForward);
        if (dot > bestDot && this.hasLineOfSight(heroChest, _v3)) {
          bestDot = dot;
          if (!bestTargetPt) bestTargetPt = new THREE.Vector3();
          bestTargetPt.copy(_v3);
        }
      }
    }

    if (bestTargetPt) {
      aimTarget.copy(bestTargetPt);
    }

    // Align hero facing cleanly with shot direction
    const dx = aimTarget.x - this.heroPos.x;
    const dz = aimTarget.z - this.heroPos.z;
    this.heroYaw = Math.atan2(dx, dz);
    this.hero.root.rotation.y = this.heroYaw;
    this.hero.root.updateMatrixWorld(true);

    // Fire from muzzle (or hero chest if hugging a wall so shots never spawn inside cover)
    const muzzleWorld = _v3;
    this.hero.muzzlePoint.getWorldPosition(muzzleWorld);
    if (this.segmentFirstObstacleT(heroChest, muzzleWorld, true) < 1) {
      muzzleWorld.copy(heroChest);
    }

    const effectiveSpread = this.scopeActive ? meta.spread * 0.25 : meta.spread;
    for (let p = 0; p < meta.pellets; p++) {
      const bulletDir = _v4.subVectors(aimTarget, muzzleWorld).normalize();
      if (effectiveSpread > 0) {
        bulletDir.x += (Math.random() - 0.5) * effectiveSpread;
        bulletDir.y += (Math.random() - 0.5) * effectiveSpread * 0.6;
        bulletDir.z += (Math.random() - 0.5) * effectiveSpread;
        bulletDir.normalize();
      }
      this.spawnBullet(
        true,
        muzzleWorld,
        bulletDir,
        meta.bulletSpeed,
        this.getScaledPlayerDamage(meta.baseDamage),
      );
    }

    this.spawnParticles(
      muzzleWorld,
      this.weaponType === 'trishul' ? 0xfff0a8 : 0xffd166,
      this.weaponType === 'kalbhairav' ? 7 : 4,
      this.weaponType === 'kalbhairav' ? 3.8 : 2.8,
    );

    if (slot.ammo === 0 && slot.reserve > 0) {
      this.attemptStartReload();
    }
  }

  // --- Collision, Safe Bus Exit & Line-of-Sight Helpers ---

  private pushOutOfBusHull(pos: THREE.Vector3, actorRadius: number, forceCheck = false): void {
    if (!forceCheck && this.busPos.y >= 1.15) return;
    const fwdX = Math.sin(this.busYaw);
    const fwdZ = Math.cos(this.busYaw);
    // 3 overlapping circles covering full 8.4m x 2.6m WBTC bus hull with zero mid-body gap
    const offsets = [-2.65, 0.0, 2.65];
    const busCircleR = 1.48;
    for (let k = 0; k < offsets.length; k++) {
      const bx = this.busPos.x + fwdX * offsets[k];
      const bz = this.busPos.z + fwdZ * offsets[k];
      const dx = pos.x - bx;
      const dz = pos.z - bz;
      const minDist = actorRadius + busCircleR;
      const distSq = dx * dx + dz * dz;
      if (distSq < minDist * minDist) {
        if (distSq > 0.0001) {
          const dist = Math.sqrt(distSq);
          const push = minDist - dist;
          pos.x += (dx / dist) * push;
          pos.z += (dz / dist) * push;
        } else {
          // Exactly centered: push cleanly out to the right-side doorway
          pos.x += -fwdZ * minDist;
          pos.z += fwdX * minDist;
        }
      }
    }
  }

  private findSafeBusExitPosition(
    out: THREE.Vector3,
    actorRadius: number,
    preferSideSign = 1,
    alongOffset = 0,
    isIntroRoute = false,
  ): void {
    const fwdX = Math.sin(this.busYaw);
    const fwdZ = Math.cos(this.busYaw);
    // Local -X (right-side animated passenger doorway) in world XZ is (-fwdZ, fwdX)
    const doorRightX = -fwdZ;
    const doorRightZ = fwdX;
    const bounds = this.world.playableBounds;

    // 1. Direct Howrah Bridge Deck Exit (NO parachute — hop straight onto the bridge road surface beside the open door!)
    const onHowrahBridgeDeck =
      this.busPos.y > 4.2 &&
      Math.abs(this.busPos.z + 40) < 6.0 &&
      this.busPos.x >= -62 &&
      this.busPos.x <= 62;
    if (onHowrahBridgeDeck) {
      const bx = THREE.MathUtils.clamp(this.busPos.x + fwdX * (1.7 + alongOffset), -62, 62);
      const bz = THREE.MathUtils.clamp(
        this.busPos.z + doorRightZ * (preferSideSign * 2.48),
        -43.9,
        -36.1,
      );
      out.set(bx, 6.58, bz);
      return;
    }

    // 2. Eastern Viaduct Approach Ramp Exit: step safely onto solid East Ghat road (never into river water)
    if (isIntroRoute && this.busPos.y > 0.65) {
      const gx = THREE.MathUtils.clamp(this.busPos.x - 4.5 + alongOffset * 0.6, 22, 42);
      const gz = THREE.MathUtils.clamp(Math.max(this.busPos.z + 2.5, -17.0), -17.0, 18.0);
      out.set(gx, 0, gz);
      this.resolveCircleWorldCollision(out, actorRadius, false);
      out.y = this.world.getGroundHeight(out.x, out.z, 0);
      return;
    }

    // 3. Direct Road / Ground Exit right outside the open side passenger doorway
    const candidates: Array<[number, number]> = [
      [preferSideSign * 2.85, 1.9 + alongOffset],
      [preferSideSign * 3.85, 0.5 + alongOffset],
      [-preferSideSign * 2.95, 1.6 + alongOffset],
      [preferSideSign * 3.35, -2.1 + alongOffset],
      [0, -5.2],
    ];

    for (let c = 0; c < candidates.length; c++) {
      const [lat, fwd] = candidates[c];
      const cx = THREE.MathUtils.clamp(
        this.busPos.x + doorRightX * lat + fwdX * fwd,
        bounds.minX + 1.8,
        bounds.maxX - 1.8,
      );
      const cz = THREE.MathUtils.clamp(
        this.busPos.z + doorRightZ * lat + fwdZ * fwd,
        bounds.minZ + 1.5,
        bounds.maxZ - 1.8,
      );

      const refY = this.world.getGroundHeight(cx, cz, this.busPos.y);
      out.set(cx, refY, cz);
      this.resolveCircleWorldCollision(out, actorRadius, false);
      if (this.busPos.y < 1.35) {
        this.pushOutOfBusHull(out, actorRadius + 0.45, true);
        this.resolveCircleWorldCollision(out, actorRadius, false);
      }

      let clearOfBus = true;
      if (this.busPos.y < 1.35) {
        for (const off of [-2.65, 0.0, 2.65]) {
          const dx = out.x - (this.busPos.x + fwdX * off);
          const dz = out.z - (this.busPos.z + fwdZ * off);
          if (dx * dx + dz * dz < (actorRadius + 1.52) * (actorRadius + 1.52)) {
            clearOfBus = false;
            break;
          }
        }
      }
      if (clearOfBus) {
        out.y = this.world.getGroundHeight(out.x, out.z, this.busPos.y);
        return;
      }
    }

    // Final guaranteed push-out fallback
    if (this.busPos.y < 1.35) {
      this.pushOutOfBusHull(out, actorRadius + 0.7, true);
    }
    out.x = THREE.MathUtils.clamp(out.x, bounds.minX + 1.5, bounds.maxX - 1.5);
    out.z = THREE.MathUtils.clamp(out.z, bounds.minZ + 1.5, bounds.maxZ - 1.5);
    out.y = this.world.getGroundHeight(out.x, out.z, this.busPos.y);
  }

  private resolveCircleWorldCollision(
    pos: THREE.Vector3,
    actorRadius: number,
    includeBusHull = true,
  ): void {
    const bounds = this.world.playableBounds;
    pos.x = THREE.MathUtils.clamp(pos.x, bounds.minX, bounds.maxX);
    pos.z = THREE.MathUtils.clamp(pos.z, bounds.minZ, bounds.maxZ);

    // Hooghly River water barrier: allow crossing via the Howrah Bridge deck & North/South ramps,
    // while keeping actors safely on bridge guardrails or riverbanks everywhere else
    if (this.world.isWaterBlocked(pos.x, pos.z)) {
      if (pos.y > 1.2) {
        // Actor is elevated on bridge/ramps — clamp cleanly back inside the nearest guardrail lane
        if (pos.z <= -35.2 && pos.z >= -44.8) {
          pos.x = THREE.MathUtils.clamp(pos.x, -65.2, 65.2);
          pos.z = THREE.MathUtils.clamp(pos.z, -44.2, -35.8);
        } else if (pos.x < 0) {
          pos.x = THREE.MathUtils.clamp(pos.x, -20.9, -14.1);
        } else {
          pos.x = THREE.MathUtils.clamp(pos.x, 14.1, 20.9);
        }
      } else {
        // Ground-level riverbank edge: gently block wading into deep river water
        pos.z = pos.z > -45.5 ? -20.4 : -70.6;
      }
    }

    // When walking atop the 2nd-floor Zamindar Bari rooftop terrace (y >= 2.8),
    // skip ground-floor partition wall colliders underneath while staying inside the terrace roof
    const onZamindarTerrace =
      pos.y >= 2.8 && pos.x >= 80 && pos.x <= 116 && pos.z >= 7 && pos.z <= 37;

    const colliders: CircleCollider[] = this.world.circleColliders;
    let hadCollision = false;
    for (let i = 0; i < colliders.length; i++) {
      const c = colliders[i];
      if (onZamindarTerrace && c.kind === 'ruin' && c.height <= 4.7) continue;
      const dx = pos.x - c.x;
      const dz = pos.z - c.z;
      const minDist = actorRadius + c.radius;
      const distSq = dx * dx + dz * dz;
      if (distSq < minDist * minDist && distSq > 0.00001) {
        const dist = Math.sqrt(distSq);
        const push = minDist - dist;
        pos.x += (dx / dist) * push;
        pos.z += (dz / dist) * push;
        hadCollision = true;
      }
    }
    // Lightweight second pass only on contact so actors glide cleanly around twin-circle building corners without snagging
    if (hadCollision) {
      for (let i = 0; i < colliders.length; i++) {
        const c = colliders[i];
        if (onZamindarTerrace && c.kind === 'ruin' && c.height <= 4.7) continue;
        const dx = pos.x - c.x;
        const dz = pos.z - c.z;
        const minDist = actorRadius + c.radius;
        const distSq = dx * dx + dz * dz;
        if (distSq < minDist * minDist && distSq > 0.00001) {
          const dist = Math.sqrt(distSq);
          const push = minDist - dist;
          pos.x += (dx / dist) * push;
          pos.z += (dz / dist) * push;
        }
      }
    }

    // Solid 3-circle hull collision against the WBTC bus whenever it is on village ground
    if (includeBusHull && this.busPos.y < 1.15) {
      this.pushOutOfBusHull(pos, actorRadius, false);
    }

    pos.x = THREE.MathUtils.clamp(pos.x, bounds.minX, bounds.maxX);
    pos.z = THREE.MathUtils.clamp(pos.z, bounds.minZ, bounds.maxZ);
  }

  /**
   * Parametric XZ ray-segment vs vertical cylinder intersection.
   * Returns earliest t in [0, 1] where segment A->B enters circle (cx, cz, r) within [minY, maxY], or Infinity.
   */
  private segmentHitsCylinderT(
    a: THREE.Vector3,
    b: THREE.Vector3,
    cx: number,
    cz: number,
    radius: number,
    minY: number,
    maxY: number,
  ): number {
    const dx = b.x - a.x;
    const dz = b.z - a.z;
    const fx = a.x - cx;
    const fz = a.z - cz;
    const rSq = radius * radius;
    const aLenSq = dx * dx + dz * dz;

    if (aLenSq < 1e-8) {
      if (fx * fx + fz * fz <= rSq && a.y >= minY && a.y <= maxY) return 0;
      return Infinity;
    }

    const cVal = fx * fx + fz * fz - rSq;
    if (cVal <= 0) {
      if (a.y >= minY && a.y <= maxY) return 0;
    }

    const bVal = 2 * (fx * dx + fz * dz);
    const disc = bVal * bVal - 4 * aLenSq * cVal;
    if (disc < 0) return Infinity;

    const sqrtD = Math.sqrt(disc);
    const t1 = (-bVal - sqrtD) / (2 * aLenSq);
    if (t1 >= 0 && t1 <= 1) {
      const yAt = a.y + (b.y - a.y) * t1;
      if (yAt >= minY && yAt <= maxY) return t1;
    }

    const t2 = (-bVal + sqrtD) / (2 * aLenSq);
    if (t1 < 0 && t2 >= 0) {
      const yAt = a.y;
      if (yAt >= minY && yAt <= maxY) return 0;
    }
    return Infinity;
  }

  /**
   * Returns earliest t in [0, 1] where 3D segment A->B hits ground, mud houses, taxi, trees,
   * cover crates, riverbank parapet walls, or the solid WBTC bus hull; returns Infinity if clear.
   */
  private segmentFirstObstacleT(
    a: THREE.Vector3,
    b: THREE.Vector3,
    includeBus = true,
  ): number {
    let bestT = Infinity;

    // Terrain surface hit check (respects laterite hills & bridge ramps)
    const groundB = this.world.getGroundHeight(b.x, b.z) + 0.05;
    if (b.y <= groundB && a.y > groundB) {
      const tG = (groundB - a.y) / (b.y - a.y);
      if (tG >= 0 && tG <= 1 && tG < bestT) bestT = tG;
    } else if (b.y <= groundB && a.y <= groundB) {
      return 0;
    }

    // All world obstacles (mud houses, brick paka houses, Zamindar Bari ruins, vintage trams, stalls, boulders, trees, taxis, crates)
    const colliders = this.world.circleColliders;
    for (let i = 0; i < colliders.length; i++) {
      const c = colliders[i];
      const baseY =
        c.baseY !== undefined
          ? c.baseY
          : c.kind === 'boulder' || c.kind === 'tree' || c.kind === 'house'
            ? this.world.getGroundHeight(c.x, c.z)
            : 0;
      const t = this.segmentHitsCylinderT(a, b, c.x, c.z, c.radius, baseY, baseY + c.height);
      if (t < bestT) bestT = t;
    }

    // Riverbank brick parapet walls (z = -17.6, height = 0.95)
    if ((a.z > -17.3 && b.z < -17.9) || (a.z < -17.9 && b.z > -17.3)) {
      const tW = (-17.6 - a.z) / (b.z - a.z);
      if (tW >= 0 && tW <= 1 && tW < bestT) {
        const wx = a.x + (b.x - a.x) * tW;
        const wy = a.y + (b.y - a.y) * tW;
        if (Math.abs(wx) > 10 && Math.abs(wx) < 46 && wy <= 0.95) {
          bestT = tW;
        }
      }
    }

    // Solid WBTC bus hull (3 circles along length, height = 3.4m)
    if (includeBus && this.busPos.y < 1.2) {
      const fwdX = Math.sin(this.busYaw);
      const fwdZ = Math.cos(this.busYaw);
      for (const off of [-2.65, 0.0, 2.65]) {
        const bx = this.busPos.x + fwdX * off;
        const bz = this.busPos.z + fwdZ * off;
        const tB = this.segmentHitsCylinderT(a, b, bx, bz, 1.48, 0, 3.45);
        if (tB < bestT) bestT = tB;
      }
    }

    return bestT;
  }

  private hasLineOfSight(from: THREE.Vector3, to: THREE.Vector3): boolean {
    return this.segmentFirstObstacleT(from, to, true) === Infinity;
  }

  // --- Simulation Update ---

  private update(dt: number): void {
    this.worldTime += dt;

    // Ambient world animation (water ripples, swaying coconut palms, bobbing country boat)
    this.world.waterUniforms.uTime.value = this.worldTime;
    this.world.waterBumpTexture.offset.x = (this.worldTime * 0.03) % 1;
    this.world.waterBumpTexture.offset.y = (this.worldTime * 0.015) % 1;

    for (const palm of this.world.swayingPalms) {
      palm.crown.rotation.z = Math.sin(this.worldTime * 1.35 + palm.phase) * 0.045;
      palm.crown.rotation.x = Math.cos(this.worldTime * 1.05 + palm.phase) * 0.035;
    }

    for (let i = 0; i < this.world.bobbingBoats.length; i++) {
      const boat = this.world.bobbingBoats[i];
      const phase = i * 0.95;
      boat.position.y = -1.18 + Math.sin(this.worldTime * 1.55 + phase) * 0.09;
      boat.rotation.z = Math.sin(this.worldTime * 1.25 + phase) * 0.045;
    }

    if (this.phase === 'title') {
      this.titleTime += dt;
      // Free Fire-style 3D Main Lobby: hero stands center-stage in front of West Bengal village,
      // Yellow Ambassador Taxi, coconut palms, Hooghly River, and Howrah-style bridge.
      this.hero.root.position.set(0, 0, 7.2);

      // Scenic background WBTC bus gliding slowly across the Howrah-style bridge in the lobby!
      const lobbyBusT = 0.02 + ((this.titleTime * 0.025) % 0.3);
      this.positionBusOnIntroRoute(lobbyBusT);
      for (const w of this.bus.wheels) {
        w.rotation.x += dt * 4.5;
      }

      // Continuous smooth 360-degree turntable rotation from frame 1 (pauses cleanly while dragging)
      if (!this.lobbyDragActive) {
        this.lobbyHeroTargetYaw += dt * 0.44;
      }
      const prevYaw = this.lobbyHeroYaw;
      const yawDamp = 1 - Math.exp(-10 * dt);
      this.lobbyHeroYaw += (this.lobbyHeroTargetYaw - this.lobbyHeroYaw) * yawDamp;
      this.hero.root.rotation.y = this.lobbyHeroYaw;
      const lobbyYawRate = (this.lobbyHeroYaw - prevYaw) / Math.max(0.001, dt);

      // Lifelike idle breathing, subtle contrapposto weight shift, calm gaze, blinking & breeze
      this.lobbyShowcasePulse = Math.max(0, this.lobbyShowcasePulse - dt * 3.5);
      const breathPhase = this.titleTime * 2.05;
      const breath = Math.sin(breathPhase);
      const swayPhase = this.titleTime * 0.82;
      const popScale = 1 + Math.sin(this.lobbyShowcasePulse * Math.PI) * 0.036;

      this.hero.bodyGroup.position.y = breath * 0.004;
      this.hero.bodyGroup.rotation.y = 0;
      this.hero.bodyGroup.rotation.z = Math.sin(swayPhase) * 0.015;
      this.hero.bodyGroup.scale.set(popScale, popScale, popScale);

      // Thoracic breathing & subtle upper-body posture shift anchored at lumbar waist
      this.hero.upperBodyGroup.position.y = 0.94 + breath * 0.0095;
      this.hero.upperBodyGroup.rotation.x = Math.sin(breathPhase - 0.55) * 0.018;
      this.hero.upperBodyGroup.rotation.y = Math.sin(swayPhase * 0.85) * 0.055;
      this.hero.upperBodyGroup.rotation.z = Math.cos(swayPhase) * 0.014;

      // Natural relaxed contrapposto stance (feet planted cleanly, knees subtly soft)
      this.hero.leftLeg.rotation.x = -0.045;
      this.hero.leftLeg.rotation.z = 0;
      this.hero.rightLeg.rotation.x = 0.05;
      this.hero.rightLeg.rotation.z = 0;
      this.hero.leftKnee.rotation.x = 0.08;
      this.hero.rightKnee.rotation.x = 0.045;
      this.hero.leftAnkle.rotation.x = -0.035;
      this.hero.rightAnkle.rotation.x = -0.09;

      // Calm attentive head motion, involuntary blinking & subtle river-breeze hair/kurta flutter
      this.hero.headGroup.rotation.y =
        Math.sin(this.titleTime * 0.72) * 0.11 + Math.sin(this.titleTime * 1.75) * 0.022;
      this.hero.headGroup.rotation.x = Math.sin(this.titleTime * 1.25) * 0.028 - breath * 0.01;
      this.hero.headGroup.rotation.z = Math.sin(this.titleTime * 0.58) * 0.022;
      this.hero.hairTuft.rotation.x = Math.sin(this.worldTime * 3.2) * 0.032;
      this.hero.hairTuft.rotation.z = Math.cos(this.worldTime * 2.6) * 0.028;
      this.hero.kurtaHem.rotation.x = Math.sin(this.worldTime * 2.3) * 0.024;
      this.hero.kurtaHem.rotation.z = Math.cos(this.worldTime * 1.8) * 0.018;
      this.updateHeroBlink(dt);

      // Subtle breathing settle on arms & carried weapon
      this.hero.leftArm.position.set(0, breath * 0.0045, 0);
      this.hero.rightArm.position.set(0, breath * 0.0045, 0);
      this.hero.recoilGroup.position.set(0.115, 0.31 + breath * 0.0055, 0.27);
      this.hero.recoilGroup.rotation.set(Math.sin(this.titleTime * 1.6) * 0.02, 0, 0);

      // Real-time Verlet cloth simulation on the red-and-white gamcha (Hooghly river breeze + drag-spin whip!)
      this.hero.updateGamchaCloth(dt, this.worldTime, 0, 0, 0, lobbyYawRate, 0.28);

      // Permanent tamed pet companion stands proudly beside the hero in the 3D Main Lobby
      if (this.petCompanion) {
        const pc = this.petCompanion;
        pc.rig.root.visible = true;
        pc.pos.set(-1.62, 0, 7.66);
        pc.rig.root.position.copy(pc.pos);
        pc.yaw = 0.42 + Math.sin(this.titleTime * 0.55) * 0.08;
        pc.rig.root.rotation.set(0, pc.yaw, 0);
        pc.rig.hpBarBg.visible = false;
        animateAnimalRig(pc.rig, pc.record.species, dt, this.worldTime, 0, 0, {
          isTamed: true,
        });
      }

      // Keep shadow frustum locked cleanly on the lobby hero & village square
      this.sunLight.position.set(38, 52, -20);
      this.sunLight.target.position.set(0, 0, 4);

      // Heroic front-facing lobby camera with gentle atmospheric float (framed cleanly for 1.16x hero & larger companion)
      const swayX = Math.sin(this.titleTime * 0.45) * 0.16;
      const swayY = Math.cos(this.titleTime * 0.65) * 0.045;
      this.camera.position.set(-0.2 + swayX, 1.64 + swayY, 11.45);
      this.camera.lookAt(0.12, 1.44, -4.0);
      return;
    }

    if (this.phase !== 'playing') {
      return;
    }

    // Brief hitstop on heavy kill impact for tactile weight
    if (this.hitstopTimer > 0) {
      this.hitstopTimer = Math.max(0, this.hitstopTimer - dt);
      return;
    }

    // Decay UI / feedback / recoil timers
    this.damageFlash = Math.max(0, this.damageFlash - dt * 2.15);
    if (this.damageFlash <= 0.02) {
      this.hasDamageSource = false;
      this.damageAngle = null;
    }
    this.hitMarker = Math.max(0, this.hitMarker - dt * 4.4);
    this.camShake = Math.max(0, this.camShake - dt * 1.9);
    this.camRecoilPitch = THREE.MathUtils.damp(this.camRecoilPitch, 0, 14.5, dt);
    this.camRecoilYaw = THREE.MathUtils.damp(this.camRecoilYaw, 0, 15.5, dt);
    if (Math.abs(this.camRecoilPitch) < 0.0004) this.camRecoilPitch = 0;
    if (Math.abs(this.camRecoilYaw) < 0.0004) this.camRecoilYaw = 0;
    this.heroFireHoldTimer = Math.max(0, this.heroFireHoldTimer - dt);
    if (this.waveBannerTimer > 0) {
      this.waveBannerTimer -= dt;
      if (this.waveBannerTimer <= 0) this.waveBanner = null;
    }
    if (this.pickupToastTimer > 0) {
      this.pickupToastTimer -= dt;
      if (this.pickupToastTimer <= 0) this.pickupToast = null;
    }

    // Camera keyboard orbit assist (Q/E) + touch drag look driven by General & Scope sensitivity sliders
    const generalLook = this.getGeneralLookFactor();
    const lookMult = this.scopeActive ? this.getScopeLookFactor() : generalLook;
    if (this.busMode === 'riding_intro' && this.busInteriorCam) {
      // Allow subtle left/right cabin window glancing over the Howrah Bridge & landmarks
      if (this.keysHeld.has('KeyQ')) this.busInteriorLookYaw += 1.6 * generalLook * dt;
      if (this.keysHeld.has('KeyE')) this.busInteriorLookYaw -= 1.6 * generalLook * dt;
      if (this.virtualInput.lookDeltaX !== 0 || this.virtualInput.lookDeltaY !== 0) {
        this.busInteriorLookYaw -= this.virtualInput.lookDeltaX * 0.0045 * generalLook;
        this.virtualInput.lookDeltaX = 0;
        this.virtualInput.lookDeltaY = 0;
      }
      this.busInteriorLookYaw = THREE.MathUtils.clamp(this.busInteriorLookYaw, -0.68, 0.68);
    } else {
      if (this.keysHeld.has('KeyQ')) this.camYaw += 2.2 * lookMult * dt;
      if (this.keysHeld.has('KeyE')) this.camYaw -= 2.2 * lookMult * dt;
      if (this.virtualInput.lookDeltaX !== 0 || this.virtualInput.lookDeltaY !== 0) {
        this.camYaw -= this.virtualInput.lookDeltaX * 0.0055 * lookMult;
        this.camPitch = THREE.MathUtils.clamp(
          this.camPitch + this.virtualInput.lookDeltaY * 0.0042 * lookMult,
          -0.18,
          0.65,
        );
        this.virtualInput.lookDeltaX = 0;
        this.virtualInput.lookDeltaY = 0;
      }
    }

    // Read unified movement / steering input (Keyboard WASD / Arrows + Virtual Touch Joystick)
    let moveRight = this.virtualInput.moveX;
    let moveForward = this.virtualInput.moveY;
    if (this.keysHeld.has('KeyD') || this.keysHeld.has('ArrowRight')) moveRight += 1;
    if (this.keysHeld.has('KeyA') || this.keysHeld.has('ArrowLeft')) moveRight -= 1;
    if (this.keysHeld.has('KeyW') || this.keysHeld.has('ArrowUp')) moveForward += 1;
    if (this.keysHeld.has('KeyS') || this.keysHeld.has('ArrowDown')) moveForward -= 1;

    const moveLen = Math.hypot(moveRight, moveForward);
    if (moveLen > 1) {
      moveRight /= moveLen;
      moveForward /= moveLen;
    }

    // --- 1. Update WBTC Passenger Bus (Auto Intro Route OR Player Driving OR Coasting Stop) ---
    if (this.busDoorAutoHoldTimer > 0) {
      this.busDoorAutoHoldTimer = Math.max(0, this.busDoorAutoHoldTimer - dt);
    }
    const targetDoorOpen = this.busExitSlowing || this.busDoorAutoHoldTimer > 0 ? 1 : 0;
    this.busDoorOpenAmount += (targetDoorOpen - this.busDoorOpenAmount) * (1 - Math.exp(-11 * dt));
    this.bus.interior.setDoorOpenAmount(this.busDoorOpenAmount);
    this.bus.interior.introDriverGroup.visible = this.busAutoDriving && this.busMode !== 'driving';

    if (this.busAutoDriving) {
      const prevPos = _v2.copy(this.busPos);
      // Smoothly decelerate as the bus approaches its final stop OR briefly brakes when player taps 'বাস থেকে নামুন'
      const endSlowDown =
        this.busRouteT > 0.88 ? THREE.MathUtils.lerp(1.0, 0.35, (this.busRouteT - 0.88) / 0.12) : 1.0;
      const exitBrakeMult = this.busExitSlowing
        ? THREE.MathUtils.lerp(0.14, 0.85, Math.max(0, this.busExitSlowTimer / this.busExitSlowDuration))
        : 1.0;
      this.busRouteT = Math.min(1.0, this.busRouteT + dt * 0.046 * endSlowDown * exitBrakeMult);
      this.positionBusOnIntroRoute(this.busRouteT);

      const movedDist = this.busPos.distanceTo(prevPos);
      this.busSpeed = movedDist / Math.max(0.001, dt);
      for (const w of this.bus.wheels) {
        w.rotation.x += movedDist / 0.54;
      }
      this.bus.chassisGroup.position.y = Math.sin(this.worldTime * 14) * (this.busExitSlowing ? 0.007 : 0.016);

      this.bus.root.updateMatrixWorld(true);

      // Update & auto-drop AI enemy passengers riding seated inside the bus cabin along the route
      for (const e of this.enemies) {
        if (e.dying || e.busSeatIndex < 0) continue;
        if (this.busRouteT >= e.busDropT) {
          this.dropEnemyFromBus(e);
        } else {
          this.bus.enemySeats[e.busSeatIndex].getWorldPosition(e.rig.root.position);
          e.rig.root.rotation.y = this.busYaw;
        }
      }

      // Complete braking + door-opening exit sequence once bus has slowed & side door swung open
      if (this.busExitSlowing && this.busMode === 'riding_intro') {
        this.busExitSlowTimer -= dt;
        if (this.busExitSlowTimer <= 0) {
          this.executeDirectGroundExit();
        }
      }

      // Auto-exit hero at the very end of the route if they stayed on until the last village stop
      if (this.busRouteT >= 0.999) {
        this.busAutoDriving = false;
        this.busSpeed = 0;
        this.bus.chassisGroup.position.y = 0;
        this.bus.root.rotation.set(0, this.busYaw, 0);
        // Drop any straggling bus enemies safely
        for (const e of this.enemies) {
          if (!e.dying && e.busSeatIndex >= 0) this.dropEnemyFromBus(e);
        }
        if (this.busMode === 'riding_intro') {
          this.executeDirectGroundExit();
        }
      }
    } else if (this.busMode === 'driving') {
      // Player-controlled WBTC bus driving around the West Bengal village!
      const accel = 14.5;
      const maxFwd = 15.0;
      const maxRev = -6.0;

      if (Math.abs(moveForward) > 0.05) {
        this.busSpeed += moveForward * accel * dt;
      } else {
        this.busSpeed *= Math.exp(-3.4 * dt);
        if (Math.abs(this.busSpeed) < 0.08) this.busSpeed = 0;
      }
      this.busSpeed = THREE.MathUtils.clamp(this.busSpeed, maxRev, maxFwd);

      const targetSteer = -moveRight * 0.48;
      this.busSteerAngle += (targetSteer - this.busSteerAngle) * (1 - Math.exp(-10 * dt));
      for (const pivot of this.bus.frontWheelPivots) {
        pivot.rotation.y = this.busSteerAngle;
      }

      if (Math.abs(this.busSpeed) > 0.25) {
        const turnSign = this.busSpeed >= 0 ? 1 : -1;
        const turnFactor = Math.min(1, Math.abs(this.busSpeed) / 6.0);
        this.busYaw += this.busSteerAngle * 2.15 * turnFactor * turnSign * dt;
      }

      const bFwdX = Math.sin(this.busYaw);
      const bFwdZ = Math.cos(this.busYaw);
      const prevX = this.busPos.x;
      const prevZ = this.busPos.z;

      this.busPos.x += bFwdX * this.busSpeed * dt;
      this.busPos.z += bFwdZ * this.busSpeed * dt;

      // Keep drivable bus cleanly inside the 1000x1000 map & slide off houses/trees/taxi/river edge
      this.resolveCircleWorldCollision(this.busPos, 1.85, false);
      const busGroundY = this.world.getGroundHeight(this.busPos.x, this.busPos.z, this.busPos.y);
      this.busPos.y += (busGroundY - this.busPos.y) * Math.min(1, dt * 16);

      const actualDist = Math.hypot(this.busPos.x - prevX, this.busPos.z - prevZ);
      if (Math.abs(this.busSpeed) > 2.5 && actualDist < Math.abs(this.busSpeed) * dt * 0.35) {
        this.busSpeed *= 0.55; // gentle bumper bounce on impact
      }

      // Compute gentle road slope pitch for hills & Howrah Bridge crossing ramps
      const frontY = this.world.getGroundHeight(this.busPos.x + bFwdX * 2.4, this.busPos.z + bFwdZ * 2.4, this.busPos.y);
      const backY = this.world.getGroundHeight(this.busPos.x - bFwdX * 2.4, this.busPos.z - bFwdZ * 2.4, this.busPos.y);
      const slopePitch = -Math.atan2(frontY - backY, 4.8);

      this.bus.root.position.copy(this.busPos);
      this.bus.root.rotation.set(slopePitch, this.busYaw, 0);
      this.bus.chassisGroup.rotation.z = -this.busSteerAngle * Math.min(1, Math.abs(this.busSpeed) / 12) * 0.08;
      this.bus.chassisGroup.position.y = Math.sin(this.worldTime * 16) * (Math.abs(this.busSpeed) > 1 ? 0.02 : 0.005);

      const wheelSpin = (this.busSpeed * dt) / 0.54;
      for (const w of this.bus.wheels) {
        w.rotation.x += wheelSpin;
      }

      // Ram enemy bots with the bus!
      if (Math.abs(this.busSpeed) > 4.2) {
        for (const e of this.enemies) {
          if (e.dying || e.busSeatIndex >= 0) continue;
          const dx = e.rig.root.position.x - this.busPos.x;
          const dz = e.rig.root.position.z - this.busPos.z;
          if (dx * dx + dz * dz < 3.1 * 3.1) {
            _v4.set(bFwdX * this.busSpeed, 0, bFwdZ * this.busSpeed);
            _v6.set(e.rig.root.position.x, 1.2, e.rig.root.position.z);
            this.damageEnemy(e, 95, _v4, false, _v6);
            this.camShake = Math.min(0.36, this.camShake + 0.16);
          }
        }
      }

      this.bus.root.updateMatrixWorld(true);
    } else {
      // Bus coasting smoothly to a stop when unmanned on village ground
      if (Math.abs(this.busSpeed) > 0.05) {
        this.busSpeed *= Math.exp(-4.5 * dt);
        const bFwdX = Math.sin(this.busYaw);
        const bFwdZ = Math.cos(this.busYaw);
        this.busPos.x += bFwdX * this.busSpeed * dt;
        this.busPos.z += bFwdZ * this.busSpeed * dt;
        this.resolveCircleWorldCollision(this.busPos, 1.85, false);
        this.busPos.y = this.world.getGroundHeight(this.busPos.x, this.busPos.z, this.busPos.y);
        this.bus.root.position.copy(this.busPos);
        for (const w of this.bus.wheels) {
          w.rotation.x += (this.busSpeed * dt) / 0.54;
        }
      } else {
        this.busSpeed = 0;
      }
      this.bus.chassisGroup.rotation.z *= Math.exp(-8 * dt);
      this.bus.chassisGroup.position.y *= Math.exp(-8 * dt);
    }

    // Sway overhead bus hand-straps naturally with cabin speed and braking inertia
    const strapAmp = 0.04 + Math.min(0.18, Math.abs(this.busSpeed) * 0.012);
    const brakeTilt = this.busExitSlowing ? 0.28 : 0;
    for (let s = 0; s < this.bus.interior.hangingStraps.length; s++) {
      const strap = this.bus.interior.hangingStraps[s];
      strap.rotation.x = brakeTilt + Math.sin(this.worldTime * 4.2 + s * 0.75) * strapAmp;
      strap.rotation.z = Math.cos(this.worldTime * 3.1 + s * 0.55) * strapAmp * 0.65;
    }

    // --- 2. Update Hero Position, Mode & Actions ---
    const fwdX = Math.sin(this.camYaw);
    const fwdZ = Math.cos(this.camYaw);
    const rightX = -fwdZ;
    const rightZ = fwdX;

    if (this.busMode === 'riding_intro') {
      // Hero rides seated inside the hollow WBTC bus cabin, then stands & steps to the opening door when exiting
      this.bus.heroIntroSeat.getWorldPosition(this.heroPos);
      let sitBlend = 1;
      if (this.busExitSlowing) {
        this.bus.interior.heroDoorwayAnchor.getWorldPosition(this.heroDoorwayWorld);
        const stepT = THREE.MathUtils.clamp(
          1 - this.busExitSlowTimer / Math.max(0.01, this.busExitSlowDuration),
          0,
          1,
        );
        const smoothStep = stepT * stepT * (3 - 2 * stepT);
        this.heroPos.lerp(this.heroDoorwayWorld, smoothStep);
        this.heroYaw = this.busYaw - smoothStep * (Math.PI * 0.42);
        sitBlend = 1 - smoothStep;
      } else {
        this.heroYaw = this.busYaw;
      }
      const roadVib = Math.sin(this.worldTime * 14.5) * 0.0055 * sitBlend;
      const busBreath = Math.sin(this.worldTime * 2.15) * 0.007;
      this.hero.leftLeg.rotation.x = THREE.MathUtils.damp(this.hero.leftLeg.rotation.x, -1.16 * sitBlend, 14, dt);
      this.hero.leftLeg.rotation.z = THREE.MathUtils.damp(this.hero.leftLeg.rotation.z, 0, 14, dt);
      this.hero.rightLeg.rotation.x = THREE.MathUtils.damp(this.hero.rightLeg.rotation.x, -1.16 * sitBlend, 14, dt);
      this.hero.rightLeg.rotation.z = THREE.MathUtils.damp(this.hero.rightLeg.rotation.z, 0, 14, dt);
      this.hero.leftKnee.rotation.x = THREE.MathUtils.damp(this.hero.leftKnee.rotation.x, 1.16 * sitBlend, 14, dt);
      this.hero.rightKnee.rotation.x = THREE.MathUtils.damp(this.hero.rightKnee.rotation.x, 1.16 * sitBlend, 14, dt);
      this.hero.leftAnkle.rotation.x = THREE.MathUtils.damp(this.hero.leftAnkle.rotation.x, 0.08 * sitBlend, 14, dt);
      this.hero.rightAnkle.rotation.x = THREE.MathUtils.damp(this.hero.rightAnkle.rotation.x, 0.08 * sitBlend, 14, dt);
      this.hero.bodyGroup.position.y = roadVib;
      this.hero.bodyGroup.rotation.y = THREE.MathUtils.damp(this.hero.bodyGroup.rotation.y, 0, 12, dt);
      this.hero.bodyGroup.rotation.z = THREE.MathUtils.damp(this.hero.bodyGroup.rotation.z, 0, 10, dt);
      this.hero.upperBodyGroup.position.y = 0.94 + busBreath;
      this.hero.upperBodyGroup.rotation.x = THREE.MathUtils.damp(
        this.hero.upperBodyGroup.rotation.x,
        this.busExitSlowing ? 0.14 : 0.03 + busBreath * 1.4,
        10,
        dt,
      );
      this.hero.upperBodyGroup.rotation.y = THREE.MathUtils.damp(
        this.hero.upperBodyGroup.rotation.y,
        Math.sin(this.worldTime * 0.7) * 0.05 * sitBlend,
        8,
        dt,
      );
      this.hero.upperBodyGroup.rotation.z = THREE.MathUtils.damp(this.hero.upperBodyGroup.rotation.z, 0, 10, dt);
      this.hero.root.position.copy(this.heroPos);
      this.hero.root.rotation.set(0, this.heroYaw, 0);
      this.hero.headGroup.rotation.set(
        Math.sin(this.worldTime * 1.1) * 0.03,
        Math.sin(this.worldTime * 0.85) * 0.18,
        Math.sin(this.worldTime * 0.65) * 0.025,
      );
      this.hero.hairTuft.rotation.x = Math.sin(this.worldTime * 4.8) * 0.04;
      this.hero.kurtaHem.rotation.x = Math.sin(this.worldTime * 3.1) * 0.025;
      this.updateHeroBlink(dt);
      this.hero.updateGamchaCloth(dt, this.worldTime, 0.35, 0, this.busSpeed * 0.28, 0, 0.42);
      this.hero.muzzleFlash.visible = false;
      this.hero.muzzleLight.intensity = 0;
      this.nearBus = false;
      this.nearTwoWheeler = null;
    } else if (this.busMode === 'driving') {
      // Hero sits visibly in the right-hand-drive cab behind the steering wheel!
      this.bus.heroDriverSeat.getWorldPosition(this.heroPos);
      this.hero.root.position.copy(this.heroPos);
      this.heroYaw = this.busYaw;
      this.hero.root.rotation.set(0, this.heroYaw, 0);
      this.hero.leftLeg.rotation.x = -1.08;
      this.hero.leftLeg.rotation.z = 0;
      this.hero.rightLeg.rotation.x = -1.08;
      this.hero.rightLeg.rotation.z = 0;
      this.hero.leftKnee.rotation.x = 1.08;
      this.hero.rightKnee.rotation.x = 1.08;
      this.hero.leftAnkle.rotation.x = 0.06;
      this.hero.rightAnkle.rotation.x = 0.06;
      this.hero.bodyGroup.position.y = Math.sin(this.worldTime * 15) * (Math.abs(this.busSpeed) > 1 ? 0.008 : 0.003);
      this.hero.bodyGroup.rotation.y = 0;
      this.hero.bodyGroup.rotation.z = 0;
      this.hero.upperBodyGroup.position.y = 0.94 + Math.sin(this.worldTime * 2.2) * 0.006;
      this.hero.upperBodyGroup.rotation.set(
        0.06,
        -this.busSteerAngle * 0.16,
        -this.busSteerAngle * 0.08,
      );
      this.hero.headGroup.rotation.set(0, -this.busSteerAngle * 0.45, 0);
      this.hero.hairTuft.rotation.x = Math.sin(this.worldTime * 5.2) * 0.035;
      this.updateHeroBlink(dt);
      this.hero.updateGamchaCloth(dt, this.worldTime, 0, 0, this.busSpeed * 0.25, 0, 0.35);
      this.hero.muzzleFlash.visible = false;
      this.hero.muzzleLight.intensity = 0;
      this.nearBus = false;
      this.nearTwoWheeler = null;
    } else if (this.heroJumpingFromBus) {
      // Direct grounded hop onto the Howrah Bridge deck or village road (no parachute!)
      const prevY = this.heroPos.y;
      this.heroJumpProgress = Math.min(1, this.heroJumpProgress + dt / this.heroJumpDuration);
      const t = this.heroJumpProgress;
      this.heroPos.lerpVectors(this.heroJumpStart, this.heroJumpEnd, t);
      const arc = 4 * t * (1 - t);
      const baseY = THREE.MathUtils.lerp(this.heroJumpStart.y, this.heroJumpEnd.y, t);
      const lift = Math.max(0.2, this.heroJumpPeakY - (this.heroJumpStart.y + this.heroJumpEnd.y) * 0.5);
      this.heroPos.y = baseY + arc * lift;
      this.hero.root.position.copy(this.heroPos);
      // Athletic mid-air stride & forward balance lean
      this.hero.leftLeg.rotation.x = THREE.MathUtils.damp(this.hero.leftLeg.rotation.x, -0.44, 15, dt);
      this.hero.rightLeg.rotation.x = THREE.MathUtils.damp(this.hero.rightLeg.rotation.x, 0.34, 15, dt);
      this.hero.leftKnee.rotation.x = THREE.MathUtils.damp(this.hero.leftKnee.rotation.x, 0.62, 15, dt);
      this.hero.rightKnee.rotation.x = THREE.MathUtils.damp(this.hero.rightKnee.rotation.x, 0.38, 15, dt);
      this.hero.leftAnkle.rotation.x = THREE.MathUtils.damp(this.hero.leftAnkle.rotation.x, 0.22, 15, dt);
      this.hero.rightAnkle.rotation.x = THREE.MathUtils.damp(this.hero.rightAnkle.rotation.x, 0.28, 15, dt);
      this.hero.upperBodyGroup.rotation.x = THREE.MathUtils.damp(this.hero.upperBodyGroup.rotation.x, 0.2, 12, dt);
      this.hero.kurtaHem.rotation.x = THREE.MathUtils.damp(this.hero.kurtaHem.rotation.x, 0.24, 12, dt);
      this.hero.hairTuft.rotation.x = -0.12;
      this.updateHeroBlink(dt);
      const vertVel = (this.heroPos.y - prevY) / Math.max(0.001, dt);
      this.hero.updateGamchaCloth(dt, this.worldTime, 0, vertVel * 0.6, 3.8, 0, 1.2);

      if (this.heroJumpProgress >= 1) {
        this.heroJumpingFromBus = false;
        this.resolveCircleWorldCollision(this.heroPos, 0.62, true);
        this.heroPos.y = this.world.getGroundHeight(
          this.heroPos.x,
          this.heroPos.z,
          this.heroJumpEnd.y,
        );
        this.hero.root.position.copy(this.heroPos);
        this.heroLandingCrouch = 1.0; // Smooth athletic knee-bend impact absorption on landing
        this.camShake = Math.min(0.22, this.camShake + 0.1);
        this.spawnParticles(this.heroPos, 0xd8a872, 10, 3.8);
      }
      this.nearBus = false;
      this.nearTwoWheeler = null;
    } else if (this.activeTwoWheeler) {
      // Smooth Bicycle (সাইকেল) & Motorcycle/Bike (বাইক) Exploration & Traversal (no combat while mounted)
      const vehicle = this.activeTwoWheeler;
      const isMoto = vehicle.kind === 'motorcycle';
      const maxFwd = isMoto ? 19.2 : 12.8;
      const maxRev = isMoto ? -4.5 : -3.4;
      const accel = isMoto ? 17.5 : 11.8;
      const brakeDecel = isMoto ? 26.0 : 19.5;
      const coastDamp = isMoto ? 2.5 : 3.2;
      const turnRate = isMoto ? 2.5 : 2.75;
      const colRadius = isMoto ? 0.78 : 0.62;
      const maxLean = isMoto ? 0.32 : 0.23;
      const wheelBase = isMoto ? 1.44 : 1.24;

      if (Math.abs(moveForward) > 0.05) {
        const opposing =
          (moveForward > 0 && this.rideSpeed < -0.2) ||
          (moveForward < 0 && this.rideSpeed > 0.2);
        this.rideSpeed += moveForward * (opposing ? brakeDecel : accel) * dt;
      } else {
        this.rideSpeed *= Math.exp(-coastDamp * dt);
        if (Math.abs(this.rideSpeed) < 0.06) this.rideSpeed = 0;
      }
      this.rideSpeed = THREE.MathUtils.clamp(this.rideSpeed, maxRev, maxFwd);

      const targetSteer = -moveRight;
      this.rideSteer = THREE.MathUtils.damp(this.rideSteer, targetSteer, 12, dt);

      if (Math.abs(this.rideSteer) > 0.02) {
        // Gentle low-speed handlebar pivot keeps narrow Burrabazar & Chor Bazaar alleys effortless
        const turnSign = this.rideSpeed < -0.55 ? -1 : 1;
        const speedTurnFactor = 0.44 + 0.56 * Math.min(1, Math.abs(this.rideSpeed) / 4.2);
        this.rideYaw += this.rideSteer * turnRate * speedTurnFactor * turnSign * dt;
      }

      const bFwdX = Math.sin(this.rideYaw);
      const bFwdZ = Math.cos(this.rideYaw);
      const prevX = this.ridePos.x;
      const prevZ = this.ridePos.z;

      this.ridePos.x += bFwdX * this.rideSpeed * dt;
      this.ridePos.z += bFwdZ * this.rideSpeed * dt;

      // Clean collision sliding around buildings, Burrabazar, Chor Bazaar, trees, river & bounds
      this.resolveCircleWorldCollision(this.ridePos, colRadius, false);
      const groundY = this.world.getGroundHeight(this.ridePos.x, this.ridePos.z, this.ridePos.y);
      this.ridePos.y += (groundY - this.ridePos.y) * Math.min(1, dt * 18);

      const actualDist = Math.hypot(this.ridePos.x - prevX, this.ridePos.z - prevZ);
      if (Math.abs(this.rideSpeed) > 2.2 && actualDist < Math.abs(this.rideSpeed) * dt * 0.32) {
        this.rideSpeed *= 0.55;
      }

      // Compute hill/bridge slope pitch & responsive cornering lean
      const frontY = this.world.getGroundHeight(
        this.ridePos.x + bFwdX * (wheelBase * 0.5),
        this.ridePos.z + bFwdZ * (wheelBase * 0.5),
        this.ridePos.y,
      );
      const backY = this.world.getGroundHeight(
        this.ridePos.x - bFwdX * (wheelBase * 0.5),
        this.ridePos.z - bFwdZ * (wheelBase * 0.5),
        this.ridePos.y,
      );
      const targetPitch = THREE.MathUtils.clamp(Math.atan2(frontY - backY, wheelBase), -0.34, 0.34);
      this.ridePitch = THREE.MathUtils.damp(this.ridePitch, targetPitch, 12, dt);

      const leanSpeedRatio = Math.min(1, Math.abs(this.rideSpeed) / (isMoto ? 8.5 : 6.0));
      const targetLean = moveRight * maxLean * leanSpeedRatio;
      this.rideLean = THREE.MathUtils.damp(this.rideLean, targetLean, 10, dt);

      // Update instanced bicycle/motorcycle GPU matrix (zero extra draw calls!)
      vehicle.setTransform(
        this.ridePos.x,
        this.ridePos.y,
        this.ridePos.z,
        this.rideYaw,
        this.ridePitch,
        this.rideLean,
      );

      // Subtle biome-matched rear-wheel dust/marsh splash trail while riding fast across the map
      this.rideDustTimer -= dt;
      if (Math.abs(this.rideSpeed) > (isMoto ? 7.2 : 6.0) && this.rideDustTimer <= 0) {
        this.rideDustTimer = isMoto ? 0.14 : 0.2;
        const loc = this.world.getLocationName(this.ridePos.x, this.ridePos.z, this.ridePos.y);
        const trailColor =
          loc === 'জলাভূমি ও বিল'
            ? 0x5d8f7e
            : loc === 'উন্মুক্ত তৃণভূমি'
              ? 0xd6c978
              : loc === 'শালবন' || loc === 'পাথুরে পাহাড়'
                ? 0xc46b42
                : 0xc9b492;
        this.spawnParticles(
          _v1.set(
            this.ridePos.x - bFwdX * 0.85,
            this.ridePos.y + 0.16,
            this.ridePos.z - bFwdZ * 0.85,
          ),
          trailColor,
          isMoto ? 3 : 2,
          isMoto ? 2.4 : 1.7,
        );
      }

      // Gently auto-align chase camera behind heading while riding (still allows free look drag anytime!)
      if (!this.dragLookActive && Math.abs(this.rideSpeed) > 0.9) {
        let yawDiff = this.rideYaw - this.camYaw;
        while (yawDiff > Math.PI) yawDiff -= Math.PI * 2;
        while (yawDiff < -Math.PI) yawDiff += Math.PI * 2;
        const alignRate = this.rideSpeed >= 0 ? 4.8 : 1.8;
        this.camYaw += yawDiff * (1 - Math.exp(-alignRate * dt));
      }

      // Seat Bengali hero cleanly onto the saddle/bench with authentic riding/pedaling animation
      const seatBack = isMoto ? -0.22 : -0.24;
      const seatYOffset = isMoto ? -0.04 : 0.08;
      this.prevHeroPos.copy(this.heroPos);
      this.heroPos.set(
        this.ridePos.x + bFwdX * seatBack,
        this.ridePos.y + seatYOffset,
        this.ridePos.z + bFwdZ * seatBack,
      );
      this.heroYaw = this.rideYaw;
      this.hero.root.position.copy(this.heroPos);
      this.hero.root.rotation.set(0, this.heroYaw, 0);

      const roadVib = Math.sin(this.worldTime * (isMoto ? 26 : 15)) * (Math.abs(this.rideSpeed) > 0.8 ? 0.008 : 0.002);
      this.hero.bodyGroup.position.set(0, roadVib, 0);
      this.hero.bodyGroup.rotation.set(-this.ridePitch * 0.45, 0, this.rideLean * 0.72);
      this.hero.upperBodyGroup.position.y = 0.94;
      this.hero.upperBodyGroup.rotation.set(
        isMoto ? 0.26 : 0.22,
        this.rideSteer * 0.14,
        this.rideLean * 0.18,
      );
      this.hero.headGroup.rotation.set(-0.08, this.rideSteer * 0.28, -this.rideLean * 0.25);

      if (isMoto) {
        // Motorcycle sporty seated straddle posture
        this.hero.leftLeg.rotation.set(-0.92, 0, 0.15);
        this.hero.rightLeg.rotation.set(-0.92, 0, -0.15);
        this.hero.leftKnee.rotation.set(1.06, 0, 0);
        this.hero.rightKnee.rotation.set(1.06, 0, 0);
        this.hero.leftAnkle.rotation.set(0.12, 0, 0);
        this.hero.rightAnkle.rotation.set(0.12, 0, 0);
      } else {
        // Bicycle rhythmic pedaling animation synced to travel speed
        this.ridePedalPhase += this.rideSpeed * dt * 2.35;
        const pedalAmp = Math.min(1, Math.abs(this.rideSpeed) / 2.2);
        const sP = Math.sin(this.ridePedalPhase) * pedalAmp;
        this.hero.leftLeg.rotation.set(-0.76 + sP * 0.42, 0, 0.08);
        this.hero.rightLeg.rotation.set(-0.76 - sP * 0.42, 0, -0.08);
        this.hero.leftKnee.rotation.set(0.86 - sP * 0.36, 0, 0);
        this.hero.rightKnee.rotation.set(0.86 + sP * 0.36, 0, 0);
        this.hero.leftAnkle.rotation.set(0.14 + sP * 0.15, 0, 0);
        this.hero.rightAnkle.rotation.set(0.14 - sP * 0.15, 0, 0);
      }

      // Arms reaching naturally toward the handlebars
      this.hero.leftArm.position.set(0.05, 0.03, 0.14);
      this.hero.rightArm.position.set(-0.05, 0.03, 0.14);
      this.hero.hairTuft.rotation.x = -Math.min(0.28, Math.abs(this.rideSpeed) * 0.015);
      this.hero.kurtaHem.rotation.x = Math.min(0.32, Math.abs(this.rideSpeed) * 0.018);

      this.updateHeroBlink(dt);
      this.hero.updateGamchaCloth(
        dt,
        this.worldTime,
        0,
        0,
        Math.max(0.4, Math.abs(this.rideSpeed) * 0.85),
        this.rideSteer * 1.4,
        isMoto ? 1.15 : 0.72,
      );
      this.hero.muzzleFlash.visible = false;
      this.hero.muzzleLight.intensity = 0;
      this.nearBus = false;
      this.nearTwoWheeler = null;
      this.sprintStamina = Math.min(1, this.sprintStamina + dt * 0.35);
    } else {
      // Standard on-foot third-person tactical shooter movement, strafe, sprint, jump & crouch transitions
      const isShooting = this.mouseShootHeld || this.virtualInput.shooting;
      const isCombatLock = isShooting || this.scopeActive || this.heroFireHoldTimer > 0;

      // Tap-to-toggle mobile sprint (Free Fire style) + keyboard Shift hold-to-sprint
      // Automatically turns off if player stops moving, pulls backward, enters combat/crouch/heal/taming, or depletes stamina
      const keyboardShiftHeld = this.keysHeld.has('ShiftLeft') || this.keysHeld.has('ShiftRight');
      if (this.sprintToggled) {
        if (isCombatLock || this.isHealing || this.isCrouching || this.tamingActive) {
          this.cancelSprintToggle();
        } else if (moveLen > 0.2 && moveForward > 0.12) {
          this.sprintHasMovedSinceToggle = true;
          this.sprintIdleTimer = 0;
        } else if (moveForward < -0.25) {
          this.cancelSprintToggle();
        } else if (moveLen < 0.14) {
          this.sprintIdleTimer += dt;
          const idleLimit = this.sprintHasMovedSinceToggle ? 0.22 : 2.2;
          if (this.sprintIdleTimer >= idleLimit) {
            this.cancelSprintToggle();
          }
        }
      }

      const wantsSprint =
        (keyboardShiftHeld || this.sprintToggled) &&
        moveLen > 0.2 &&
        moveForward > 0.12 &&
        !isCombatLock &&
        !this.isHealing;
      const isSprinting = wantsSprint && this.sprintStamina > 0.04;
      if (isSprinting) {
        if (this.isCrouching) this.isCrouching = false;
        this.sprintStamina = Math.max(0, this.sprintStamina - dt * 0.4);
        if (this.sprintStamina <= 0.02 && this.sprintToggled) {
          this.cancelSprintToggle();
        }
      } else {
        this.sprintStamina = Math.min(1, this.sprintStamina + dt * 0.3);
        if (this.sprintToggled && this.sprintHasMovedSinceToggle && this.sprintStamina <= 0.04) {
          this.cancelSprintToggle();
        }
      }

      // Smoothly transition speed multipliers across sprint, tactical jog, crouch-walk, strafe, ADS & healing
      let targetSpeedMult = 1.0;
      if (this.isCrouching) {
        targetSpeedMult = this.isHealing ? 0.44 : this.scopeActive ? 0.5 : 0.58;
      } else if (this.isHealing) {
        targetSpeedMult = 0.54;
      } else if (this.scopeActive) {
        targetSpeedMult = 0.62;
      } else if (isSprinting) {
        targetSpeedMult = 1.44;
      } else if (isCombatLock) {
        targetSpeedMult = moveForward < -0.2 ? 0.72 : 0.84;
      } else if (moveForward < -0.25) {
        targetSpeedMult = 0.84;
      } else if (Math.abs(moveRight) > 0.65 && Math.abs(moveForward) < 0.35) {
        targetSpeedMult = 0.92;
      }
      this.heroSpeedMult = THREE.MathUtils.damp(this.heroSpeedMult, targetSpeedMult, 10.5, dt);

      const moveSpeed = 7.4 * this.heroSpeedMult;
      const desiredVx = (fwdX * moveForward + rightX * moveRight) * moveSpeed;
      const desiredVz = (fwdZ * moveForward + rightZ * moveRight) * moveSpeed;

      // Grounded acceleration / deceleration damping (slightly lighter steering control while airborne)
      const accelRate = this.heroJumpOffset > 0.05 ? 6.5 : moveLen > 0.05 ? 14.5 : 13.0;
      this.heroVelX = THREE.MathUtils.damp(this.heroVelX, desiredVx, accelRate, dt);
      this.heroVelZ = THREE.MathUtils.damp(this.heroVelZ, desiredVz, accelRate, dt);
      if (moveLen <= 0.04 && Math.hypot(this.heroVelX, this.heroVelZ) < 0.06) {
        this.heroVelX = 0;
        this.heroVelZ = 0;
      }

      this.prevHeroPos.copy(this.heroPos);
      this.prevHeroYaw = this.heroYaw;

      this.heroPos.x += this.heroVelX * dt;
      this.heroPos.z += this.heroVelZ * dt;
      this.resolveCircleWorldCollision(this.heroPos, 0.62, true);
      const prevGroundY = this.heroPos.y - this.heroJumpOffset;
      const targetGroundY = this.world.getGroundHeight(this.heroPos.x, this.heroPos.z, prevGroundY);
      let groundedY = targetGroundY;
      if (Math.abs(targetGroundY - prevGroundY) > 1.85) {
        groundedY = THREE.MathUtils.lerp(prevGroundY, targetGroundY, Math.min(1, dt * 14));
      }

      // Smooth athletic jump arc physics & crisp landing absorption
      if (this.heroJumpOffset > 0 || this.heroVerticalVel > 0) {
        this.heroVerticalVel -= 18.5 * dt;
        this.heroJumpOffset += this.heroVerticalVel * dt;
        if (this.heroJumpOffset <= 0) {
          this.heroJumpOffset = 0;
          this.heroVerticalVel = 0;
          this.heroLandingCrouch = Math.max(this.heroLandingCrouch, 0.62);
          this.spawnParticles(
            _v1.set(this.heroPos.x, groundedY + 0.05, this.heroPos.z),
            0xd8a872,
            6,
            2.6,
          );
        }
      }
      this.heroPos.y = groundedY + this.heroJumpOffset;
      this.hero.root.position.copy(this.heroPos);

      // Proximity check for re-entering & driving the WBTC bus ('বাসে উঠুন')
      this.nearBus =
        !this.busAutoDriving &&
        this.heroPos.distanceTo(this.busPos) < 5.8;

      // Proximity check for mounting a nearby Kolkata Bicycle (সাইকেল) or Motorcycle (বাইক)
      let closestTwoWheeler: RideableTwoWheeler | null = null;
      let closestDistSq = 3.25 * 3.25;
      for (const v of this.world.twoWheelers) {
        const dx = v.x - this.heroPos.x;
        const dz = v.z - this.heroPos.z;
        const dSq = dx * dx + dz * dz;
        if (dSq < closestDistSq && Math.abs(v.y - this.heroPos.y) < 2.2) {
          closestDistSq = dSq;
          closestTwoWheeler = v;
        }
      }
      this.nearTwoWheeler = closestTwoWheeler;

      // Smooth tactical hero facing: locks briskly to crosshair during combat, flows naturally with travel otherwise
      const velSpeed = Math.hypot(this.heroVelX, this.heroVelZ);
      const desiredYaw = isCombatLock
        ? this.camYaw
        : moveLen > 0.14 && velSpeed > 0.5
          ? Math.atan2(this.heroVelX, this.heroVelZ)
          : this.camYaw;

      let yawDiff = desiredYaw - this.heroYaw;
      while (yawDiff > Math.PI) yawDiff -= Math.PI * 2;
      while (yawDiff < -Math.PI) yawDiff += Math.PI * 2;
      const turnRate = isCombatLock ? 20.5 : moveLen > 0.14 ? 12.0 : 4.2;
      this.heroYaw += yawDiff * (1 - Math.exp(-turnRate * dt));
      this.hero.root.rotation.set(0, this.heroYaw, 0);

      // Convert actual grounded velocity into hero local space for gait, strafe leaning & Verlet gamcha cloth
      const worldVx = (this.heroPos.x - this.prevHeroPos.x) / Math.max(0.001, dt);
      const worldVz = (this.heroPos.z - this.prevHeroPos.z) / Math.max(0.001, dt);
      const actualSpeed = Math.hypot(worldVx, worldVz);
      const sinY = Math.sin(this.heroYaw);
      const cosY = Math.cos(this.heroYaw);
      const localVelZ = worldVx * sinY + worldVz * cosY;
      const localVelX = worldVx * cosY - worldVz * sinY;
      let dYaw = this.heroYaw - this.prevHeroYaw;
      while (dYaw > Math.PI) dYaw -= Math.PI * 2;
      while (dYaw < -Math.PI) dYaw += Math.PI * 2;
      const yawRate = dYaw / Math.max(0.001, dt);

      // Smoothly damped locomotion, sprint, aim, strafe, forward & landing weights (zero snapping!)
      const speedNorm = THREE.MathUtils.clamp(actualSpeed / 7.4, 0, 1.5);
      const isMoving = actualSpeed > 0.25;
      this.heroWalkWeight = THREE.MathUtils.damp(
        this.heroWalkWeight,
        isMoving ? Math.min(1, speedNorm * 1.16) : 0,
        12.0,
        dt,
      );
      this.heroSprintWeight = THREE.MathUtils.damp(
        this.heroSprintWeight,
        isSprinting && speedNorm > 0.82 ? 1 : 0,
        7.5,
        dt,
      );
      this.camSprintBlend = THREE.MathUtils.damp(
        this.camSprintBlend,
        isSprinting && speedNorm > 0.78 ? 1 : 0,
        6.5,
        dt,
      );
      this.heroAimWeight = THREE.MathUtils.damp(
        this.heroAimWeight,
        isCombatLock ? 1 : 0,
        14.5,
        dt,
      );
      this.heroLandingCrouch = THREE.MathUtils.damp(this.heroLandingCrouch, 0, 9.5, dt);
      this.heroCrouchBlend = THREE.MathUtils.damp(
        this.heroCrouchBlend,
        this.isCrouching && this.heroJumpOffset <= 0.04 ? 1 : 0,
        12.5,
        dt,
      );
      this.heroAirBlend = THREE.MathUtils.damp(
        this.heroAirBlend,
        this.heroJumpOffset > 0.04 ? 1 : 0,
        14.0,
        dt,
      );
      this.heroTurnLean = THREE.MathUtils.damp(
        this.heroTurnLean,
        THREE.MathUtils.clamp(yawRate * 0.032, -0.14, 0.14),
        10,
        dt,
      );
      this.heroStrafeBlend = THREE.MathUtils.damp(
        this.heroStrafeBlend,
        THREE.MathUtils.clamp(localVelX / 7.2, -1, 1),
        11,
        dt,
      );
      this.heroForwardBlend = THREE.MathUtils.damp(
        this.heroForwardBlend,
        THREE.MathUtils.clamp(localVelZ / 7.4, -1, 1.45),
        11,
        dt,
      );
      this.heroAimPitch = THREE.MathUtils.damp(
        this.heroAimPitch,
        THREE.MathUtils.clamp(this.camPitch - this.camRecoilPitch, -0.45, 0.55),
        16,
        dt,
      );

      // Dynamic reticle spread: crouching tightens aim noticeably; jumping blooms spread briefly
      const crouchTighten = 1 - this.heroCrouchBlend * 0.42;
      const baseReticleSpread = this.scopeActive
        ? (0.04 + speedNorm * 0.12) * crouchTighten + this.heroAirBlend * 0.16
        : (0.08 + speedNorm * 0.28 + this.heroSprintWeight * 0.26 + this.heroLandingCrouch * 0.14) *
            crouchTighten +
          this.heroAirBlend * 0.24;
      this.reticleSpread = THREE.MathUtils.damp(
        this.reticleSpread,
        Math.min(1.0, baseReticleSpread),
        this.scopeActive ? 12 : 9.5,
        dt,
      );

      // Advance biomechanical gait phase proportionally to actual ground speed (paused mid-air)
      const strideDir = this.heroForwardBlend < -0.18 ? -1 : 1;
      if (this.heroWalkWeight > 0.02 && this.heroAirBlend < 0.65) {
        const cadence = 6.0 + actualSpeed * 0.64;
        this.heroWalkPhase += dt * cadence * strideDir;
      }

      const w = this.heroWalkWeight * (1 - this.heroAirBlend * 0.85);
      const sp = this.heroSprintWeight * (1 - this.heroAirBlend);
      const aim = this.heroAimWeight;
      const landCrouch = this.heroLandingCrouch;
      const stanceCrouch = this.heroCrouchBlend;
      const air = this.heroAirBlend;
      const crouch = Math.min(1.2, landCrouch * 0.72 + stanceCrouch);
      const strafeMag = Math.abs(this.heroStrafeBlend);
      const aimBrace = aim * (1 - sp * 0.8);

      // Biomechanical lower-body gait + athletic tactical crouch + tucked mid-air jump pose
      const strideAmp = (0.5 + sp * 0.24) * (1 - aim * 0.18) * (1 - strafeMag * 0.18) * (1 - stanceCrouch * 0.38);
      const sinP = Math.sin(this.heroWalkPhase);
      const cosP = Math.cos(this.heroWalkPhase);
      const lSwingLift = Math.max(0, Math.sin(this.heroWalkPhase + 0.88));
      const rSwingLift = Math.max(0, -Math.sin(this.heroWalkPhase + 0.88));
      const lStanceFlex = Math.max(0, -Math.sin(this.heroWalkPhase - 0.25)) * 0.14;
      const rStanceFlex = Math.max(0, Math.sin(this.heroWalkPhase - 0.25)) * 0.14;

      const lHipGround =
        THREE.MathUtils.lerp(-0.04 - aimBrace * 0.06, sinP * strideAmp, w) -
        landCrouch * 0.36 -
        stanceCrouch * 0.76;
      const rHipGround =
        THREE.MathUtils.lerp(0.05 + aimBrace * 0.05, -sinP * strideAmp, w) -
        landCrouch * 0.32 -
        stanceCrouch * 0.62;
      const lHipTarget = THREE.MathUtils.lerp(lHipGround, -0.46, air);
      const rHipTarget = THREE.MathUtils.lerp(rHipGround, 0.24, air);

      const strafeSplay = this.heroStrafeBlend * aim * w;
      const lHipRollTarget = THREE.MathUtils.clamp(
        0.03 * aimBrace + stanceCrouch * 0.08 + sinP * 0.16 * strafeSplay + Math.max(0, -strafeSplay) * 0.08,
        -0.22,
        0.24,
      );
      const rHipRollTarget = THREE.MathUtils.clamp(
        -0.03 * aimBrace - stanceCrouch * 0.08 - sinP * 0.16 * strafeSplay - Math.max(0, strafeSplay) * 0.08,
        -0.24,
        0.22,
      );
      const lKneeGround =
        THREE.MathUtils.lerp(
          0.075 + aimBrace * 0.12,
          lSwingLift * (0.74 + sp * 0.32) + lStanceFlex + 0.07 + aimBrace * 0.06,
          w,
        ) +
        landCrouch * 0.68 +
        stanceCrouch * 1.38;
      const rKneeGround =
        THREE.MathUtils.lerp(
          0.055 + aimBrace * 0.11,
          rSwingLift * (0.74 + sp * 0.32) + rStanceFlex + 0.07 + aimBrace * 0.06,
          w,
        ) +
        landCrouch * 0.62 +
        stanceCrouch * 1.24;
      const lKneeTarget = THREE.MathUtils.lerp(lKneeGround, 0.72, air);
      const rKneeTarget = THREE.MathUtils.lerp(rKneeGround, 0.46, air);

      const lAnkleGround =
        THREE.MathUtils.lerp(-0.03 - aimBrace * 0.05, Math.sin(this.heroWalkPhase - 0.32) * (0.28 + sp * 0.14), w) -
        landCrouch * 0.28 -
        stanceCrouch * 0.56;
      const rAnkleGround =
        THREE.MathUtils.lerp(-0.05 - aimBrace * 0.05, -Math.sin(this.heroWalkPhase - 0.32) * (0.28 + sp * 0.14), w) -
        landCrouch * 0.24 -
        stanceCrouch * 0.5;
      const lAnkleTarget = THREE.MathUtils.lerp(lAnkleGround, 0.24, air);
      const rAnkleTarget = THREE.MathUtils.lerp(rAnkleGround, 0.28, air);

      this.hero.leftLeg.rotation.x = THREE.MathUtils.damp(this.hero.leftLeg.rotation.x, lHipTarget, 18, dt);
      this.hero.leftLeg.rotation.z = THREE.MathUtils.damp(this.hero.leftLeg.rotation.z, lHipRollTarget, 14, dt);
      this.hero.rightLeg.rotation.x = THREE.MathUtils.damp(this.hero.rightLeg.rotation.x, rHipTarget, 18, dt);
      this.hero.rightLeg.rotation.z = THREE.MathUtils.damp(this.hero.rightLeg.rotation.z, rHipRollTarget, 14, dt);
      this.hero.leftKnee.rotation.x = THREE.MathUtils.damp(this.hero.leftKnee.rotation.x, lKneeTarget, 18, dt);
      this.hero.rightKnee.rotation.x = THREE.MathUtils.damp(this.hero.rightKnee.rotation.x, rKneeTarget, 18, dt);
      this.hero.leftAnkle.rotation.x = THREE.MathUtils.damp(this.hero.leftAnkle.rotation.x, lAnkleTarget, 16, dt);
      this.hero.rightAnkle.rotation.x = THREE.MathUtils.damp(this.hero.rightAnkle.rotation.x, rAnkleTarget, 16, dt);

      // Pelvis vertical double-bounce, combat-strafe hip lead, tactical crouch drop & landing squash
      const pelvisYTarget =
        Math.abs(cosP) * (0.04 + sp * 0.024) * w -
        aimBrace * 0.036 -
        landCrouch * 0.15 -
        stanceCrouch * 0.34 +
        (1 - w) * (1 - air) * Math.sin(this.worldTime * 2.15) * 0.003;
      const pelvisYawTarget = THREE.MathUtils.clamp(
        this.heroStrafeBlend * 0.28 * aim * w - aimBrace * 0.09,
        -0.34,
        0.34,
      );
      const pelvisRollTarget =
        sinP * (0.028 + sp * 0.018) * w +
        this.heroTurnLean * 0.35 -
        this.heroStrafeBlend * 0.045 * w +
        (1 - w) * Math.sin(this.worldTime * 0.9) * 0.008;
      this.hero.bodyGroup.position.y = THREE.MathUtils.damp(this.hero.bodyGroup.position.y, pelvisYTarget, 16, dt);
      this.hero.bodyGroup.rotation.y = THREE.MathUtils.damp(this.hero.bodyGroup.rotation.y, pelvisYawTarget, 13, dt);
      this.hero.bodyGroup.rotation.z = THREE.MathUtils.damp(this.hero.bodyGroup.rotation.z, pelvisRollTarget, 12, dt);

      // 3-second Sanjibani medicinal plant healing progression (+50% of max HP, minimum +50)
      if (this.isHealing) {
        this.healTimer -= dt;
        if (this.healTimer <= 0) {
          this.isHealing = false;
          this.sanjibaniCount = Math.max(0, this.sanjibaniCount - 1);
          const healAmt = Math.max(50, Math.round(this.maxHealth * 0.5));
          this.health = Math.min(this.maxHealth, this.health + healAmt);
          this.audio.playHealComplete();
          this.spawnParticles(_v1.set(this.heroPos.x, 1.15, this.heroPos.z), 0x26f28a, 14, 4.0);
          this.pickupToast = `সঞ্জীবনী গাছ: স্বাস্থ্য +${toBengaliNumber(healAmt)}`;
          this.pickupToastTimer = 2.0;
        }
      }

      // Reloading & firing
      if (this.virtualInput.reloadJustPressed) {
        this.virtualInput.reloadJustPressed = false;
        this.attemptStartReload();
      }
      if (this.isReloading) {
        this.reloadTimer -= dt;
        if (this.reloadTimer <= 0) {
          const slot = this.weaponSlots[this.weaponType];
          const needed = slot.maxAmmo - slot.ammo;
          const load = Math.min(needed, slot.reserve);
          slot.ammo += load;
          slot.reserve -= load;
          this.isReloading = false;
        }
      }

      this.fireCooldown = Math.max(0, this.fireCooldown - dt);
      if (isShooting) {
        this.firePlayerWeapon();
      }

      // Weapon recoil, Banglar Fala melee slash swing, reload & healing upper-body kinematics
      this.heroRecoil = THREE.MathUtils.damp(this.heroRecoil, 0, 14.5, dt);
      if (this.heroRecoil < 0.002) this.heroRecoil = 0;

      let slashActive = false;
      let slashSwing = 0;
      let slashTorsoYaw = 0;
      let slashT = 0;
      if (this.meleeSlashTimer > 0) {
        slashActive = true;
        this.meleeSlashTimer = Math.max(0, this.meleeSlashTimer - dt);
        slashT = 1 - this.meleeSlashTimer / 0.24;
        slashSwing = Math.sin(slashT * Math.PI);
        slashTorsoYaw = (0.5 - slashT) * 0.56;
      }

      const breathSpeed = 2.2 + sp * 2.4 + w * 0.8;
      const breathVal = Math.sin(this.worldTime * breathSpeed);
      const sprintRelax = sp * (1 - aim * 0.85) * (slashActive ? 0 : 1);

      // Lumbar upper-body articulation: counter-rotates cleanly against strafe hips to keep rifle locked on target
      const spinePitchTarget =
        0.045 * w +
        0.15 * sprintRelax +
        aimBrace * 0.045 +
        crouch * 0.2 +
        this.heroAimPitch * (0.18 + 0.26 * aim) -
        this.heroRecoil * 0.085 +
        (this.isHealing ? 0.13 : 0) +
        (slashActive ? slashSwing * 0.16 : 0) +
        breathVal * 0.011 * (1 - aim * 0.65);
      const spineYawTarget =
        -this.hero.bodyGroup.rotation.y * (0.85 * aim + 0.25) -
        sinP * (0.1 + sp * 0.07) * w * (1 - aim * 0.78) +
        slashTorsoYaw +
        (this.isReloading ? -0.1 : 0);
      const spineRollTarget =
        this.heroTurnLean * 0.65 -
        this.heroStrafeBlend * (0.065 + aim * 0.03) * w +
        (slashActive ? -slashSwing * 0.09 : 0);

      this.hero.upperBodyGroup.position.y = THREE.MathUtils.damp(
        this.hero.upperBodyGroup.position.y,
        0.94 + breathVal * (0.007 + sp * 0.004),
        14,
        dt,
      );
      this.hero.upperBodyGroup.rotation.x = THREE.MathUtils.damp(
        this.hero.upperBodyGroup.rotation.x,
        spinePitchTarget,
        15,
        dt,
      );
      this.hero.upperBodyGroup.rotation.y = THREE.MathUtils.damp(
        this.hero.upperBodyGroup.rotation.y,
        spineYawTarget,
        16,
        dt,
      );
      this.hero.upperBodyGroup.rotation.z = THREE.MathUtils.damp(
        this.hero.upperBodyGroup.rotation.z,
        spineRollTarget,
        13,
        dt,
      );

      // Vestibulo-ocular head stabilization (counter-rotates against torso twist & tracks aim pitch cleanly)
      const headYawTarget =
        -(this.hero.upperBodyGroup.rotation.y + this.hero.bodyGroup.rotation.y) * 0.7 +
        THREE.MathUtils.clamp(yawDiff * 0.22, -0.25, 0.25) +
        (1 - w) * (1 - aim) * Math.sin(this.worldTime * 0.78) * 0.06;
      const headPitchTarget =
        -this.hero.upperBodyGroup.rotation.x * 0.55 +
        this.heroAimPitch * 0.44 +
        (this.isHealing ? 0.12 : 0);
      const headRollTarget = -this.hero.upperBodyGroup.rotation.z * 0.45;
      this.hero.headGroup.rotation.x = THREE.MathUtils.damp(this.hero.headGroup.rotation.x, headPitchTarget, 16, dt);
      this.hero.headGroup.rotation.y = THREE.MathUtils.damp(this.hero.headGroup.rotation.y, headYawTarget, 16, dt);
      this.hero.headGroup.rotation.z = THREE.MathUtils.damp(this.hero.headGroup.rotation.z, headRollTarget, 14, dt);

      // Subtle wind & gait flutter on front swept hair tuft + lower kurta hem + natural eye blinking
      this.hero.hairTuft.rotation.x = THREE.MathUtils.damp(
        this.hero.hairTuft.rotation.x,
        -speedNorm * 0.065 + Math.sin(this.worldTime * (4.2 + actualSpeed * 0.6)) * (0.022 + speedNorm * 0.03),
        14,
        dt,
      );
      this.hero.hairTuft.rotation.z = THREE.MathUtils.damp(
        this.hero.hairTuft.rotation.z,
        -this.heroTurnLean * 0.5 + Math.cos(this.worldTime * 3.4) * 0.025,
        12,
        dt,
      );
      this.hero.kurtaHem.rotation.x = THREE.MathUtils.damp(
        this.hero.kurtaHem.rotation.x,
        0.04 + speedNorm * 0.095 + Math.abs(sinP) * 0.045 * w,
        14,
        dt,
      );
      this.hero.kurtaHem.rotation.z = THREE.MathUtils.damp(
        this.hero.kurtaHem.rotation.z,
        sinP * 0.055 * w - this.heroTurnLean * 0.45,
        14,
        dt,
      );
      this.updateHeroBlink(dt);

      // Smooth weapon & arm kinematics (figure-8 walk bob, tactical sprint carry, ADS raise, recoil kick, reload dip)
      const fig8X = Math.sin(this.heroWalkPhase) * (0.012 + sp * 0.014) * w * (1 - aim * 0.72);
      const fig8Y = Math.abs(cosP) * (0.012 + sp * 0.012) * w * (1 - aim * 0.74) + breathVal * 0.004;

      if (slashActive) {
        this.hero.recoilGroup.position.set(0.115 - slashSwing * 0.04, 0.31 + slashSwing * 0.035, 0.27 + slashSwing * 0.26);
        this.hero.recoilGroup.rotation.set(-slashSwing * 0.42, (slashT - 0.5) * -1.45, -slashSwing * 0.28);
        this.hero.rightArm.position.set(0, slashSwing * 0.022, slashSwing * 0.042);
        this.hero.leftArm.position.set(0, -slashSwing * 0.01, -slashSwing * 0.02);
      } else {
        const reloadProgress = this.isReloading
          ? THREE.MathUtils.clamp(1 - this.reloadTimer / Math.max(0.01, this.reloadDuration), 0, 1)
          : 0;
        const reloadDip = this.isReloading ? Math.sin(reloadProgress * Math.PI) : 0;

        const targetWeaponX = 0.115 + fig8X - sprintRelax * 0.036 - reloadDip * 0.02;
        const targetWeaponY =
          0.31 + fig8Y + aim * 0.034 - sprintRelax * 0.042 - reloadDip * 0.055 - (this.isHealing ? 0.05 : 0);
        const targetWeaponZ =
          0.27 - this.heroRecoil * 0.088 + aim * 0.024 - sprintRelax * 0.028;
        const targetWeaponPitch =
          -this.heroRecoil * 0.18 +
          this.heroAimPitch * 0.26 * aim +
          sprintRelax * 0.18 +
          reloadDip * 0.28 +
          (this.isHealing ? 0.26 : 0);
        const targetWeaponYaw =
          -sprintRelax * 0.3 - (this.isHealing ? 0.24 : 0) + reloadDip * 0.16;
        const targetWeaponRoll = reloadDip * 0.36 + sprintRelax * 0.15;

        this.hero.recoilGroup.position.x = THREE.MathUtils.damp(this.hero.recoilGroup.position.x, targetWeaponX, 18, dt);
        this.hero.recoilGroup.position.y = THREE.MathUtils.damp(this.hero.recoilGroup.position.y, targetWeaponY, 18, dt);
        this.hero.recoilGroup.position.z = THREE.MathUtils.damp(this.hero.recoilGroup.position.z, targetWeaponZ, 24, dt);
        this.hero.recoilGroup.rotation.x = THREE.MathUtils.damp(this.hero.recoilGroup.rotation.x, targetWeaponPitch, 20, dt);
        this.hero.recoilGroup.rotation.y = THREE.MathUtils.damp(this.hero.recoilGroup.rotation.y, targetWeaponYaw, 16, dt);
        this.hero.recoilGroup.rotation.z = THREE.MathUtils.damp(this.hero.recoilGroup.rotation.z, targetWeaponRoll, 16, dt);

        // Subtle synchronized arm micro-follow so hands stay seated on weapon through recoil & stride
        const armRecoilZ = -this.heroRecoil * 0.038;
        const armFollowY = fig8Y * 0.65 + aim * 0.016 - reloadDip * 0.025;
        this.hero.leftArm.position.x = THREE.MathUtils.damp(this.hero.leftArm.position.x, fig8X * 0.5, 16, dt);
        this.hero.leftArm.position.y = THREE.MathUtils.damp(this.hero.leftArm.position.y, armFollowY - reloadDip * 0.02, 16, dt);
        this.hero.leftArm.position.z = THREE.MathUtils.damp(this.hero.leftArm.position.z, armRecoilZ - reloadDip * 0.028, 20, dt);
        this.hero.rightArm.position.x = THREE.MathUtils.damp(this.hero.rightArm.position.x, fig8X * 0.45, 16, dt);
        this.hero.rightArm.position.y = THREE.MathUtils.damp(this.hero.rightArm.position.y, armFollowY, 16, dt);
        this.hero.rightArm.position.z = THREE.MathUtils.damp(this.hero.rightArm.position.z, armRecoilZ, 22, dt);
      }

      this.hero.updateGamchaCloth(
        dt,
        this.worldTime,
        localVelX,
        this.heroVerticalVel * 0.55,
        localVelZ,
        yawRate,
        this.heroAirBlend > 0.2 ? 0.9 : isSprinting ? 0.95 : moveLen > 0.1 ? 0.45 : 0.18,
      );

      if (this.muzzleFlashTimer > 0) {
        this.muzzleFlashTimer -= dt;
        this.hero.muzzleFlash.visible = true;
        this.hero.muzzleFlash.rotation.z = Math.random() * Math.PI * 2;
        this.hero.muzzleLight.intensity = 5.0;
      } else {
        this.hero.muzzleFlash.visible = false;
        this.hero.muzzleLight.intensity = 0;
      }
    }

    // Live directional incoming-damage indicator angle relative to current camera orientation
    if (this.hasDamageSource && this.damageFlash > 0.02) {
      const dmgDx = this.damageSourcePos.x - this.heroPos.x;
      const dmgDz = this.damageSourcePos.z - this.heroPos.z;
      const dotFwd = dmgDx * fwdX + dmgDz * fwdZ;
      const dotRight = dmgDx * rightX + dmgDz * rightZ;
      this.damageAngle = Math.atan2(dotRight, dotFwd);
    }

    // Keep shadow frustum centered around active subject (bus or hero)
    const focusPos = this.busMode !== 'none' ? this.busPos : this.heroPos;
    this.sunLight.position.set(focusPos.x + 46, 36, focusPos.z - 28);
    this.sunLight.target.position.copy(focusPos);

    // Moody Cave Atmosphere: smoothly dim daylight, tighten misty cavern fog & flicker warm lantern glow inside caves
    const targetCaveDepth =
      this.busMode === 'none' ? this.world.getCaveDepthFactor(focusPos.x, focusPos.z) : 0;
    this.caveMoodBlend = THREE.MathUtils.damp(this.caveMoodBlend, targetCaveDepth, 4.4, dt);
    if (this.caveMoodBlend > 0.005) {
      const c = this.caveMoodBlend;
      this.sunLight.intensity = THREE.MathUtils.lerp(2.85, 0.44, c);
      this.hemiLight.intensity = THREE.MathUtils.lerp(0.56, 0.22, c);
      this.ambientLight.intensity = THREE.MathUtils.lerp(0.07, 0.06, c);
      this.rimLight.intensity = THREE.MathUtils.lerp(0.36, 0.12, c);
      this.frontFillLight.intensity = THREE.MathUtils.lerp(0.14, 0.04, c);
      this.scene.environmentIntensity = this.baseEnvironmentIntensity * (1 - c * 0.65);
      if (this.scene.fog instanceof THREE.FogExp2) {
        this.scene.fog.color.copy(this.dayFogColor).lerp(this.caveFogColor, c * 0.92);
        this.scene.fog.density = THREE.MathUtils.lerp(0.00105, 0.018, c * c);
      }
      if (this.scene.background instanceof THREE.Color) {
        this.scene.background.copy(this.daySkyColor).lerp(this.caveSkyColor, c * 0.85);
      }
      const flicker =
        0.92 +
        0.08 * Math.sin(this.worldTime * 9.5) * Math.cos(this.worldTime * 5.3);
      this.caveTorchLight.intensity = c * 2.5 * flicker;
      this.caveTorchLight.position.set(focusPos.x, focusPos.y + 1.95, focusPos.z);

      // Periodic echoing cave water-drip ambience while deep inside a cavern
      if (c > 0.35) {
        this.caveDripTimer -= dt;
        if (this.caveDripTimer <= 0) {
          this.caveDripTimer = 4.6 + Math.random() * 4.2;
          this.audio.playCaveAmbienceDrop(c);
        }
      }
    } else if (this.caveTorchLight.intensity > 0) {
      this.resetCaveAtmosphere();
    }

    // Wave spawning & progression (Survival Mode only; paused while Wave 1 intro bus is still dropping enemies)
    if (this.gameMode === 'survival' && (!this.busAutoDriving || this.wave > 1)) {
      this.updateWaves(dt);
    }

    // Update mode-appropriate systems: enemies (Survival), wild animals (Pet Taming Mode only),
    // permanent pet companion (both modes), bullets, pickups, chests, grenades, damage text, storm & FX
    if (this.tamingStatusTimer > 0) {
      this.tamingStatusTimer -= dt;
      if (this.tamingStatusTimer <= 0 && !this.tamingActive) {
        this.tamingStatusText = null;
      }
    }
    this.updateEnemies(dt);
    if (this.gameMode === 'pet_taming') {
      this.updateWildAnimal(dt);
    }
    this.updateAnimalHeartDrops(dt);
    this.updatePetCompanion(dt);
    this.updateBullets(dt);
    this.updatePickups(dt);
    this.updateChests(dt);
    this.updateGrenades(dt);
    this.updateFloatingDamages(dt);
    if (this.gameMode === 'survival') {
      this.updateKalboishakhiStorm(dt);
    }
    this.updateParticles(dt);
    this.updateImpactFlashes(dt);

    // --- 3. Camera Rig (Bus Interior Cabin View / Bus Exterior Chase / Driving / Third-Person Shooter) ---
    if (this.busMode === 'riding_intro') {
      if (this.busInteriorCam) {
        // Realistic Bus Interior View: positioned inside the aisle looking forward past seated rivals,
        // overhead grab rails, driver cabin, and clear panoramic windows over the Howrah Bridge & landmarks
        this.bus.interior.interiorCamPos.getWorldPosition(_camDesired);
        _camDesired.y += Math.sin(this.worldTime * 15) * 0.008;

        this.bus.interior.interiorCamLook.getWorldPosition(_lookAtPt);
        if (Math.abs(this.busInteriorLookYaw) > 0.001) {
          const lx = _lookAtPt.x - _camDesired.x;
          const lz = _lookAtPt.z - _camDesired.z;
          const cosG = Math.cos(this.busInteriorLookYaw);
          const sinG = Math.sin(this.busInteriorLookYaw);
          _lookAtPt.x = _camDesired.x + lx * cosG + lz * sinG;
          _lookAtPt.z = _camDesired.z - lx * sinG + lz * cosG;
        }
      } else {
        // Exterior View toggle: sweeping side-rear chase camera showing the WBTC bus & Howrah Bridge
        const bFwdX = Math.sin(this.busYaw);
        const bFwdZ = Math.cos(this.busYaw);
        const bRightX = -bFwdZ;
        const bRightZ = bFwdX;

        _camDesired.set(
          this.busPos.x - bFwdX * 11.5 - bRightX * 4.8,
          this.busPos.y + 5.1,
          this.busPos.z - bFwdZ * 11.5 - bRightZ * 4.8,
        );
        _lookAtPt.set(
          this.busPos.x + bFwdX * 3.5,
          this.busPos.y + 1.8,
          this.busPos.z + bFwdZ * 3.5,
        );
      }
    } else if (this.busMode === 'driving') {
      // Responsive vehicle chase camera behind the player-driven WBTC bus
      const bFwdX = Math.sin(this.busYaw);
      const bFwdZ = Math.cos(this.busYaw);
      _camDesired.set(
        this.busPos.x - bFwdX * 12.2,
        this.busPos.y + 5.2,
        this.busPos.z - bFwdZ * 12.2,
      );
      _lookAtPt.set(
        this.busPos.x + bFwdX * 5.0,
        this.busPos.y + 1.8,
        this.busPos.z + bFwdZ * 5.0,
      );
    } else if (this.activeTwoWheeler) {
      // Smooth chase camera behind the ridden Kolkata Bicycle or Motorcycle with obstacle pullback
      const isMoto = this.activeTwoWheeler.kind === 'motorcycle';
      const cFwdX = Math.sin(this.camYaw);
      const cFwdZ = Math.cos(this.camYaw);
      const speedRatio = Math.min(1, Math.abs(this.rideSpeed) / (isMoto ? 19.2 : 12.8));
      const camDist = (isMoto ? 5.55 : 4.75) + speedRatio * 0.55;
      const camHeight = (isMoto ? 2.48 : 2.36) + this.camPitch * 1.85;

      _camDesired.set(
        this.ridePos.x - cFwdX * camDist,
        Math.max(this.ridePos.y + 1.45, this.ridePos.y + camHeight),
        this.ridePos.z - cFwdZ * camDist,
      );
      _lookAtPt.set(
        this.ridePos.x + cFwdX * 8.5,
        this.ridePos.y + 1.45 - this.camPitch * 3.4,
        this.ridePos.z + cFwdZ * 8.5,
      );

      // Keep narrow Burrabazar & Chor Bazaar shopfronts from obstructing the rider's view
      _v1.set(this.ridePos.x, this.ridePos.y + 1.55, this.ridePos.z);
      const camObsT = this.segmentFirstObstacleT(_v1, _camDesired, true);
      if (camObsT < 1) {
        const safeT = Math.max(0.32, camObsT - 0.14);
        _camDesired.lerpVectors(_v1, _camDesired, safeT);
      }
    } else {
      // Tactical Third-Person Shooter Camera (PUBG Mobile / Free Fire MAX scale & over-shoulder presence)
      const effYaw = this.camYaw + this.camRecoilYaw;
      const effPitch = THREE.MathUtils.clamp(this.camPitch - this.camRecoilPitch, -0.24, 0.72);
      const effFwdX = Math.sin(effYaw);
      const effFwdZ = Math.cos(effYaw);
      const effRightX = -effFwdZ;
      const effRightZ = effFwdX;

      const combatZoom = this.heroAimWeight * (this.scopeActive ? 0 : 1);
      const crouchCamDrop = this.heroCrouchBlend * 0.48;
      const gaitSwayX =
        Math.sin(this.heroWalkPhase) * 0.022 * this.heroWalkWeight * (1 - this.heroAimWeight * 0.7);
      const gaitSwayY =
        Math.abs(Math.cos(this.heroWalkPhase)) * 0.024 * this.heroWalkWeight * (1 - this.heroAimWeight * 0.72);

      if (this.scopeActive && this.weaponType === 'trishul') {
        // Crisp over-shoulder Trishul Sniper 4x optic alignment
        _camDesired.set(
          this.heroPos.x - effFwdX * 1.15 + effRightX * 0.44,
          this.heroPos.y + 1.84 - crouchCamDrop,
          this.heroPos.z - effFwdZ * 1.15 + effRightZ * 0.44,
        );
        _lookAtPt.set(
          this.heroPos.x + effFwdX * 38 + effRightX * 0.24,
          this.heroPos.y + 1.84 - crouchCamDrop - effPitch * 15.5,
          this.heroPos.z + effFwdZ * 38 + effRightZ * 0.24,
        );
      } else if (this.scopeActive) {
        // Tight Tactical Over-Shoulder ADS Zoom-In (জুম ইন) for Agni-47 / Kalbhairav
        const camDist = 2.38;
        const shoulderRight = 0.6;
        const camHeight = 1.92 - crouchCamDrop + effPitch * 1.15;
        _camDesired.set(
          this.heroPos.x - effFwdX * camDist + effRightX * shoulderRight,
          this.heroPos.y + camHeight,
          this.heroPos.z - effFwdZ * camDist + effRightZ * shoulderRight,
        );
        _camDesired.y = Math.max(this.heroPos.y + 1.42 - crouchCamDrop * 0.75, _camDesired.y);

        _lookAtPt.set(
          this.heroPos.x + effFwdX * 28 + effRightX * 0.28,
          this.heroPos.y + 1.72 - crouchCamDrop - effPitch * 9.5,
          this.heroPos.z + effFwdZ * 28 + effRightZ * 0.28,
        );
      } else {
        // Closer, eye-level tactical Over-the-Shoulder Camera aligned for 1.16x hero & larger enemies/pets
        const pinchZoomRatio = THREE.MathUtils.clamp(-this.pinchFovOffset / 24, 0, 1);
        const camDist =
          THREE.MathUtils.lerp(4.05, 2.8, pinchZoomRatio) +
          this.camSprintBlend * 0.34 -
          combatZoom * 0.22 -
          this.heroCrouchBlend * 0.16;
        const shoulderRight =
          THREE.MathUtils.lerp(0.72, 0.56, pinchZoomRatio) - combatZoom * 0.04 + gaitSwayX;
        const camHeight =
          THREE.MathUtils.lerp(2.04, 1.86, pinchZoomRatio) -
          crouchCamDrop +
          effPitch * 1.72 +
          gaitSwayY -
          combatZoom * 0.04;
        _camDesired.set(
          this.heroPos.x - effFwdX * camDist + effRightX * shoulderRight,
          this.heroPos.y + camHeight,
          this.heroPos.z - effFwdZ * camDist + effRightZ * shoulderRight,
        );
        _camDesired.y = Math.max(this.heroPos.y + 1.32 - crouchCamDrop * 0.75, _camDesired.y);

        _lookAtPt.set(
          this.heroPos.x + effFwdX * 20 + effRightX * 0.32,
          this.heroPos.y + 1.68 - crouchCamDrop - effPitch * 5.6,
          this.heroPos.z + effFwdZ * 20 + effRightZ * 0.32,
        );
      }

      // Smooth camera obstacle pullback so walls, houses, trees, or bus hull never block the view
      if (!(this.scopeActive && this.weaponType === 'trishul')) {
        _v1.set(
          this.heroPos.x + effRightX * 0.38,
          this.heroPos.y + 1.76 - crouchCamDrop,
          this.heroPos.z + effRightZ * 0.38,
        );
        const camObsT = this.segmentFirstObstacleT(_v1, _camDesired, true);
        if (camObsT < 1) {
          const safeT = Math.max(0.28, camObsT - 0.14);
          _camDesired.lerpVectors(_v1, _camDesired, safeT);
        }
      }
    }

    // Smoothly damp camera FOV (bus cabin 68°, Trishul 4x 22°, Tactical OTS ADS 44°, Bike speed boost, Normal 68°)
    const isOnFootCam = this.busMode === 'none' && this.activeTwoWheeler === null;
    const combatFovPull = isOnFootCam && !this.scopeActive ? this.heroAimWeight * 2.6 : 0;
    const sprintFovBoost = isOnFootCam && !this.scopeActive ? this.camSprintBlend * 3.8 : 0;
    const bikeFovBoost = this.activeTwoWheeler
      ? Math.min(6.0, Math.abs(this.rideSpeed) * (this.activeTwoWheeler.kind === 'motorcycle' ? 0.3 : 0.22))
      : 0;
    const baseFov =
      this.busMode === 'riding_intro' && this.busInteriorCam
        ? 68
        : isOnFootCam && this.scopeActive
          ? this.weaponType === 'trishul'
            ? 22
            : 44
          : 68 + sprintFovBoost + bikeFovBoost - combatFovPull;
    const targetFov = isOnFootCam
      ? THREE.MathUtils.clamp(baseFov + this.pinchFovOffset, 22, 76)
      : baseFov;
    if (Math.abs(this.currentFov - targetFov) > 0.05) {
      this.currentFov += (targetFov - this.currentFov) * (1 - Math.exp(-13 * dt));
      this.camera.fov = this.currentFov;
      this.camera.updateProjectionMatrix();
    }

    if (this.introTransitionProgress < 1) {
      this.introTransitionProgress = Math.min(
        1,
        this.introTransitionProgress + dt / this.introTransitionDuration,
      );
      const t = this.introTransitionProgress;
      const ease = t * t * (3 - 2 * t);

      this.camera.position.lerpVectors(this.introStartCamPos, _camDesired, ease);
      if (!(this.busMode === 'riding_intro' && this.busInteriorCam)) {
        this.camera.position.y += Math.sin(ease * Math.PI) * 2.4;
      }
      _camTarget.lerpVectors(this.introStartLookAt, _lookAtPt, ease);
      this.camera.lookAt(_camTarget);
    } else {
      const inBusCabin = this.busMode === 'riding_intro' && this.busInteriorCam;
      const posRate = inBusCabin
        ? 28
        : this.busMode !== 'none'
          ? 6.5
          : this.activeTwoWheeler
            ? 10.5
            : this.scopeActive
              ? 21
              : 15;
      const lookRate = inBusCabin ? 26 : this.scopeActive ? 25 : 18;
      const camDamp = 1 - Math.exp(-posRate * dt);
      this.camera.position.lerp(_camDesired, camDamp);

      if (this.camShake > 0.005) {
        this.camera.position.x += (Math.random() - 0.5) * this.camShake;
        this.camera.position.y += (Math.random() - 0.5) * this.camShake;
      }

      _camTarget.lerp(_lookAtPt, 1 - Math.exp(-lookRate * dt));
      this.camera.lookAt(_camTarget);
    }
  }

  private dropEnemyFromBus(e: ActiveEnemy): void {
    const prevSeat = e.busSeatIndex;
    e.busSeatIndex = -1;
    e.rig.telegraphGlow.visible = false;
    e.telegraphTimer = 0;

    // Apply full grounded combat scale & hitbox radius as enemy exits the WBTC bus
    const groundScale = this.getEnemyScale(e);
    e.rig.bodyGroup.scale.setScalar(groundScale);
    e.rig.hpBarBg.position.y = 2.15 * groundScale;
    e.radius = e.archetype === 'heavy' ? 0.78 : 0.62;

    // Swing side passenger door briefly open and launch rival warrior cleanly from the doorway
    this.busDoorAutoHoldTimer = Math.max(this.busDoorAutoHoldTimer, 0.72);
    this.bus.interior.heroDoorwayAnchor.getWorldPosition(e.jumpStart);

    // Spread slightly along the road so multiple exiting bots never stack or clip inside bus
    const sideSign = 1;
    const spread = ((prevSeat % 3) - 1) * 1.15;
    this.findSafeBusExitPosition(e.jumpEnd, e.radius + 0.2, sideSign, spread, true);

    e.jumpPeakY = Math.max(e.jumpStart.y, e.jumpEnd.y) + 0.42;
    e.jumpDuration = Math.abs(e.jumpStart.y - e.jumpEnd.y) > 1.8 ? 0.42 : 0.28;
    e.jumpProgress = 0;
    e.jumpingFromBus = true;
    // Full 2.0-second safe phase begins AFTER landing cleanly on the ground!
    e.postLandingSafeTimer = 2.0;
  }

  private updateWaves(dt: number): void {
    const aliveEnemies = this.enemies.filter((e) => !e.dying).length;

    if (this.waveEnemiesToSpawn.length > 0) {
      const maxSimultaneous = Math.min(this.maxMapEnemies, Math.min(10, 5 + this.wave));
      if (aliveEnemies < maxSimultaneous && this.totalEnemiesSpawned < this.maxMapEnemies) {
        this.waveSpawnTimer -= dt;
        if (this.waveSpawnTimer <= 0) {
          const next = this.waveEnemiesToSpawn.shift()!;
          this.spawnEnemy(next);
          this.waveSpawnTimer = Math.max(0.7, 1.75 - this.wave * 0.12);
        }
      } else if (this.totalEnemiesSpawned >= this.maxMapEnemies) {
        this.waveEnemiesToSpawn = [];
      }
    } else if (aliveEnemies === 0) {
      if (this.totalEnemiesSpawned >= this.maxMapEnemies) {
        // All 40 enemies on the map have been defeated — Match Victory!
        this.score += 500;
        this.checkHighScore();
        this.matchVictory = true;
        this.waveBanner = `বিজয়! ${toBengaliNumber(this.maxMapEnemies)} জন শত্রু পরাজিত!`;
        this.waveBannerTimer = 4.0;
        this.audio.playTameSuccess();
        this.phase = 'gameover';
        this.mouseShootHeld = false;
        this.virtualInput.shooting = false;
        this.safeExitPointerLock();
        this.emitHud();
        return;
      }

      if (this.waveBreakTimer <= 0) {
        this.waveBreakTimer = 2.5;
        this.waveBanner = `তরঙ্গ ${toBengaliNumber(this.wave)} সম্পূর্ণ!`;
        this.waveBannerTimer = 2.2;
        this.score += 150 * this.wave;
        this.checkHighScore();
      } else {
        this.waveBreakTimer -= dt;
        if (this.waveBreakTimer <= 0) {
          this.beginWave(this.wave + 1);
        }
      }
    }
  }

  private updateEnemies(dt: number): void {
    const playerProtectedInBus = this.busMode !== 'none' || this.heroJumpingFromBus;

    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];

      // Natural eye blinking for every human fighter
      if (!e.dying) {
        if (e.blinkPhase > 0) {
          e.blinkPhase += dt / 0.16;
          if (e.blinkPhase >= 1) {
            e.blinkPhase = 0;
            e.rig.setBlink(0);
          } else {
            e.rig.setBlink(Math.pow(Math.sin(e.blinkPhase * Math.PI), 0.85));
          }
        } else {
          e.blinkTimer -= dt;
          if (e.blinkTimer <= 0) {
            e.blinkPhase = 0.001;
            e.blinkTimer = 2.4 + Math.random() * 3.4;
          }
        }
      }

      // Enemies currently seated inside the WBTC bus cabin never aim, shoot, or move independently
      if (e.busSeatIndex >= 0) {
        e.rig.telegraphGlow.visible = false;
        e.telegraphTimer = 0;
        e.rig.leftLeg.rotation.x = -1.15;
        e.rig.rightLeg.rotation.x = -1.15;
        e.rig.leftKnee.rotation.x = 1.15;
        e.rig.rightKnee.rotation.x = 1.15;
        e.rig.leftAnkle.rotation.x = 0.08;
        e.rig.rightAnkle.rotation.x = 0.08;
        e.rig.upperBodyGroup.position.y = 0.94 + Math.sin(this.worldTime * 2.1 + e.id) * 0.006;
        e.rig.upperBodyGroup.rotation.set(0.03, Math.sin(this.worldTime * 0.6 + e.id) * 0.05, 0);
        e.rig.headGroup.rotation.set(0, Math.sin(this.worldTime * 0.9 + e.id * 1.4) * 0.18, 0);
        e.rig.updateCloth(dt, this.worldTime, this.busSpeed * 0.25, 0, 0.36);
        continue;
      }

      if (e.dying) {
        e.deathTimer += dt;
        const t = Math.min(1, e.deathTimer / 0.44);
        const easeOut = 1 - Math.pow(1 - t, 3);
        const buckle = Math.sin(Math.min(1, e.deathTimer / 0.24) * Math.PI * 0.5);
        // Natural buckling-knee staggered collapse instead of rigid plank tilt
        e.rig.leftKnee.rotation.x = THREE.MathUtils.lerp(e.rig.leftKnee.rotation.x, 1.05 * buckle, Math.min(1, dt * 14));
        e.rig.rightKnee.rotation.x = THREE.MathUtils.lerp(e.rig.rightKnee.rotation.x, 0.72 * buckle, Math.min(1, dt * 14));
        e.rig.leftLeg.rotation.x = THREE.MathUtils.lerp(e.rig.leftLeg.rotation.x, -0.45 * buckle, Math.min(1, dt * 14));
        e.rig.rightLeg.rotation.x = THREE.MathUtils.lerp(e.rig.rightLeg.rotation.x, -0.22 * buckle, Math.min(1, dt * 14));
        e.rig.upperBodyGroup.rotation.x = easeOut * 0.34;
        e.rig.upperBodyGroup.rotation.z = easeOut * 0.22 * e.deathSide;
        e.rig.bodyGroup.rotation.x = -Math.PI * 0.47 * easeOut;
        e.rig.bodyGroup.rotation.z = 0.18 * e.deathSide * easeOut;
        e.rig.bodyGroup.position.y = -0.18 * easeOut;
        e.rig.setBlink(1);
        e.rig.updateCloth(dt, this.worldTime, 0, 0, 0.08);
        e.rig.hpBarBg.visible = false;
        e.rig.telegraphGlow.visible = false;
        if (e.deathTimer > 1.15) {
          this.scene.remove(e.rig.root);
          this.enemies.splice(i, 1);
        }
        continue;
      }

      // Direct grounded hop from open bus side door onto bridge/road before entering combat
      if (e.jumpingFromBus) {
        e.jumpProgress = Math.min(1, e.jumpProgress + dt / e.jumpDuration);
        const t = e.jumpProgress;
        e.rig.root.position.lerpVectors(e.jumpStart, e.jumpEnd, t);
        const arc = 4 * t * (1 - t);
        const baseY = THREE.MathUtils.lerp(e.jumpStart.y, e.jumpEnd.y, t);
        const lift = Math.max(0.18, e.jumpPeakY - (e.jumpStart.y + e.jumpEnd.y) * 0.5);
        e.rig.root.position.y = baseY + arc * lift;
        e.rig.leftLeg.rotation.x = THREE.MathUtils.damp(e.rig.leftLeg.rotation.x, -0.42, 14, dt);
        e.rig.rightLeg.rotation.x = THREE.MathUtils.damp(e.rig.rightLeg.rotation.x, 0.32, 14, dt);
        e.rig.leftKnee.rotation.x = THREE.MathUtils.damp(e.rig.leftKnee.rotation.x, 0.58, 14, dt);
        e.rig.rightKnee.rotation.x = THREE.MathUtils.damp(e.rig.rightKnee.rotation.x, 0.34, 14, dt);
        e.rig.leftAnkle.rotation.x = 0.2;
        e.rig.rightAnkle.rotation.x = 0.25;
        e.rig.upperBodyGroup.rotation.x = THREE.MathUtils.damp(e.rig.upperBodyGroup.rotation.x, 0.18, 12, dt);
        e.rig.updateCloth(dt, this.worldTime, 4.2, 0, 0.85);
        e.rig.telegraphGlow.visible = false;
        e.telegraphTimer = 0;

        if (e.jumpProgress >= 1) {
          e.jumpingFromBus = false;
          this.resolveCircleWorldCollision(e.rig.root.position, e.radius, true);
          e.rig.root.position.y = this.world.getGroundHeight(
            e.rig.root.position.x,
            e.rig.root.position.z,
            e.jumpEnd.y,
          );
          e.landingCrouch = 1.0;
          e.prevYaw = e.rig.root.rotation.y;
          e.postLandingSafeTimer = 2.0; // Strictly 2 seconds after landing on ground before aiming/shooting
          this.spawnParticles(e.rig.root.position, 0xd8a872, 7, 3.6);
        }
        continue;
      }

      // Keep grounded enemies cleanly seated on laterite hills, bridge ramps, and courtyard floors
      e.rig.root.position.y = this.world.getGroundHeight(
        e.rig.root.position.x,
        e.rig.root.position.z,
        e.rig.root.position.y,
      );

      // Count down 2-second post-landing safe timer
      if (e.postLandingSafeTimer > 0) {
        e.postLandingSafeTimer = Math.max(0, e.postLandingSafeTimer - dt);
      }

      // Hit flash & flinch recovery
      if (e.flinchTimer > 0) {
        e.flinchTimer = Math.max(0, e.flinchTimer - dt);
      }
      if (e.hitFlashTimer > 0) {
        e.hitFlashTimer -= dt;
        if (e.hitFlashTimer <= 0) {
          e.rig.flashMaterials.forEach((m, idx) => {
            m.emissive.copy(e.rig.baseEmissives[idx]);
          });
          e.rig.bodyGroup.scale.setScalar(this.getEnemyScale(e));
        }
      }

      // Billboard floating health bar toward camera
      if (e.rig.hpBarBg.visible) {
        e.rig.hpBarBg.lookAt(this.camera.position);
      }

      const toHeroX = this.heroPos.x - e.rig.root.position.x;
      const toHeroZ = this.heroPos.z - e.rig.root.position.z;
      const dist = Math.hypot(toHeroX, toHeroZ) || 0.001;
      const dirX = toHeroX / dist;
      const dirZ = toHeroZ / dist;

      // Check solid wall / obstacle line-of-sight before aiming or shooting
      _v5.set(e.rig.root.position.x, e.rig.root.position.y + 1.32 * this.getEnemyScale(e), e.rig.root.position.z);
      _v6.set(this.heroPos.x, this.heroPos.y + 1.42 - this.heroCrouchBlend * 0.36, this.heroPos.z);
      const hasLOS = !playerProtectedInBus && dist <= e.fireRange && this.hasLineOfSight(_v5, _v6);

      const isRusher = e.archetype === 'rusher';
      const isHeavy = e.archetype === 'heavy';
      const desiredRange = isRusher ? 6.2 : isHeavy ? 11.8 : 14.0;

      e.strafeTimer -= dt;
      if (e.strafeTimer <= 0) {
        e.strafeDir = -e.strafeDir;
        e.strafeTimer = 1.4 + Math.random() * 1.9;
      }

      // Tactical state transitions: advance -> seek nearby cover -> hold/peek cover -> flank
      e.tacticTimer -= dt;
      if (!playerProtectedInBus && e.postLandingSafeTimer <= 0) {
        if (e.tacticState === 'hold_cover') {
          const distToCover = Math.hypot(
            e.coverX - e.rig.root.position.x,
            e.coverZ - e.rig.root.position.z,
          );
          if (!e.hasCoverSpot || distToCover > 3.6 || dist < 5.5 || dist > e.fireRange + 4) {
            e.hasCoverSpot = false;
            e.tacticState = isRusher ? 'flank' : 'advance';
            e.tacticTimer = 1.8 + Math.random() * 1.5;
          } else {
            e.coverPeekTimer -= dt;
            if (e.coverPeekTimer <= 0) {
              e.coverPeeking = !e.coverPeeking;
              e.coverPeekTimer = e.coverPeeking
                ? 1.5 + Math.random() * 1.2
                : 0.9 + Math.random() * 0.9;
            }
            if (e.tacticTimer <= 0) {
              e.hasCoverSpot = false;
              e.tacticState = Math.random() < 0.55 ? 'flank' : 'advance';
              e.tacticTimer = 2.2 + Math.random() * 1.8;
            }
          }
        } else if (e.tacticState === 'seek_cover') {
          if (!e.hasCoverSpot) {
            e.hasCoverSpot = this.findCoverSpotForEnemy(e);
            if (!e.hasCoverSpot) {
              e.tacticState = isRusher ? 'flank' : 'advance';
              e.tacticTimer = 1.8 + Math.random() * 1.2;
            }
          }
          if (e.hasCoverSpot) {
            const distToCover = Math.hypot(
              e.coverX - e.rig.root.position.x,
              e.coverZ - e.rig.root.position.z,
            );
            if (distToCover < 0.85) {
              e.tacticState = 'hold_cover';
              e.tacticTimer = 3.2 + Math.random() * 2.4;
              e.coverPeeking = false;
              e.coverPeekTimer = 0.65 + Math.random() * 0.55;
            } else if (e.tacticTimer <= 0) {
              e.hasCoverSpot = false;
              e.tacticState = 'flank';
              e.tacticTimer = 2.0 + Math.random() * 1.4;
            }
          }
        } else if (e.tacticTimer <= 0) {
          // Periodically pick tactical cover or flanking maneuver based on archetype & range
          const coverChance = isRusher ? 0.22 : isHeavy ? 0.55 : 0.65;
          if (dist > 7.5 && dist < e.fireRange + 6 && Math.random() < coverChance) {
            e.hasCoverSpot = this.findCoverSpotForEnemy(e);
            if (e.hasCoverSpot) {
              e.tacticState = 'seek_cover';
              e.tacticTimer = 3.2;
            } else {
              e.tacticState = Math.random() < 0.5 ? 'flank' : 'advance';
              e.tacticTimer = 2.0 + Math.random() * 1.6;
            }
          } else {
            e.tacticState = isRusher ? 'flank' : Math.random() < 0.5 ? 'flank' : 'advance';
            e.tacticTimer = 2.0 + Math.random() * 1.6;
          }
        }
      }

      const isBracingFire =
        (e.telegraphTimer > 0 || e.burstRemaining > 0) &&
        !playerProtectedInBus &&
        e.postLandingSafeTimer <= 0 &&
        hasLOS;
      const isDuckingCover =
        e.tacticState === 'hold_cover' && !e.coverPeeking && !isBracingFire;

      let moveX = 0;
      let moveZ = 0;
      let desiredSpeedScale = 1.0;

      if (playerProtectedInBus || e.postLandingSafeTimer > 0) {
        // Patrol & spread out cleanly around the village during the safe drop-in phase
        moveX += -dirZ * e.strafeDir * 0.72 + dirX * 0.28;
        moveZ += dirX * e.strafeDir * 0.72 + dirZ * 0.28;
        desiredSpeedScale = 0.88;
      } else if (e.tacticState === 'seek_cover' && e.hasCoverSpot) {
        // Sprint deliberately toward chosen cover node
        const cx = e.coverX - e.rig.root.position.x;
        const cz = e.coverZ - e.rig.root.position.z;
        const cDist = Math.hypot(cx, cz) || 0.001;
        moveX += cx / cDist;
        moveZ += cz / cDist;
        desiredSpeedScale = 1.12;
      } else if (e.tacticState === 'hold_cover' && e.hasCoverSpot) {
        if (e.coverPeeking) {
          // Step slightly to the flank edge of cover to establish clean firing line
          const peekX = e.coverX - dirZ * e.strafeDir * 1.35;
          const peekZ = e.coverZ + dirX * e.strafeDir * 1.35;
          const dx = peekX - e.rig.root.position.x;
          const dz = peekZ - e.rig.root.position.z;
          const d = Math.hypot(dx, dz);
          if (d > 0.22) {
            moveX += dx / d;
            moveZ += dz / d;
            desiredSpeedScale = isBracingFire ? 0.3 : 0.78;
          } else {
            desiredSpeedScale = 0;
          }
        } else {
          // Tuck tightly behind cover node and duck
          const dx = e.coverX - e.rig.root.position.x;
          const dz = e.coverZ - e.rig.root.position.z;
          const d = Math.hypot(dx, dz);
          if (d > 0.2) {
            moveX += dx / d;
            moveZ += dz / d;
            desiredSpeedScale = 0.75;
          } else {
            desiredSpeedScale = 0;
          }
        }
      } else if (!hasLOS) {
        // Actively flank around blocking walls/houses/taxi to gain a clean shot
        moveX += dirX * 0.62 - dirZ * e.strafeDir * 0.88;
        moveZ += dirZ * 0.62 + dirX * e.strafeDir * 0.88;
        desiredSpeedScale = isRusher ? 1.08 : 0.96;
      } else {
        // Open-ground combat movement: advance/hold optimal weapon range & plant feet when bracing shots
        if (dist > desiredRange + 1.5) {
          moveX += dirX * (e.tacticState === 'flank' ? 0.78 : 1.0);
          moveZ += dirZ * (e.tacticState === 'flank' ? 0.78 : 1.0);
        } else if (dist < desiredRange - 2.4) {
          moveX -= dirX * 0.55;
          moveZ -= dirZ * 0.55;
        }
        const strafeWeight = e.tacticState === 'flank' ? 0.82 : 0.48;
        moveX += -dirZ * e.strafeDir * strafeWeight;
        moveZ += dirX * e.strafeDir * strafeWeight;
        desiredSpeedScale = isBracingFire ? (isRusher ? 0.52 : 0.28) : 0.92;
      }

      // Soft separation between grounded enemies so they never stack
      for (let j = 0; j < this.enemies.length; j++) {
        if (i === j || this.enemies[j].dying || this.enemies[j].busSeatIndex >= 0) continue;
        const other = this.enemies[j];
        const sx = e.rig.root.position.x - other.rig.root.position.x;
        const sz = e.rig.root.position.z - other.rig.root.position.z;
        const sDistSq = sx * sx + sz * sz;
        if (sDistSq < 3.8 && sDistSq > 0.001) {
          const sDist = Math.sqrt(sDistSq);
          moveX += (sx / sDist) * 1.15;
          moveZ += (sz / sDist) * 1.15;
        }
      }

      const prevEx = e.rig.root.position.x;
      const prevEz = e.rig.root.position.z;
      const mLen = Math.hypot(moveX, moveZ);
      let targetVx = 0;
      let targetVz = 0;
      if (mLen > 0.02 && desiredSpeedScale > 0.01) {
        const invM = 1 / mLen;
        targetVx = moveX * invM * e.speed * desiredSpeedScale;
        targetVz = moveZ * invM * e.speed * desiredSpeedScale;
      }

      // Smooth damped enemy ground velocity for crisp, human acceleration/deceleration
      e.velX = THREE.MathUtils.damp(e.velX, targetVx, 8.8, dt);
      e.velZ = THREE.MathUtils.damp(e.velZ, targetVz, 8.8, dt);
      e.rig.root.position.x += e.velX * dt;
      e.rig.root.position.z += e.velZ * dt;

      // Smoothly damped facing yaw (faces travel when sprinting to cover, locks on hero during engagement)
      let targetYaw = e.rig.root.rotation.y;
      const enemyVelSpeed = Math.hypot(e.velX, e.velZ);
      if (
        (playerProtectedInBus || e.postLandingSafeTimer > 0 || e.tacticState === 'seek_cover') &&
        enemyVelSpeed > 0.65 &&
        !isBracingFire
      ) {
        targetYaw = Math.atan2(e.velX, e.velZ);
      } else {
        targetYaw = Math.atan2(dirX, dirZ);
      }
      let eYawDiff = targetYaw - e.rig.root.rotation.y;
      while (eYawDiff > Math.PI) eYawDiff -= Math.PI * 2;
      while (eYawDiff < -Math.PI) eYawDiff += Math.PI * 2;
      e.prevYaw = e.rig.root.rotation.y;
      e.rig.root.rotation.y += eYawDiff * (1 - Math.exp(-(isBracingFire ? 15.0 : 10.0) * dt));
      let eDYaw = e.rig.root.rotation.y - e.prevYaw;
      while (eDYaw > Math.PI) eDYaw -= Math.PI * 2;
      while (eDYaw < -Math.PI) eDYaw += Math.PI * 2;
      e.yawRate = THREE.MathUtils.damp(e.yawRate, eDYaw / Math.max(0.001, dt), 12, dt);

      // Apply knockback decay
      if (e.knockback.lengthSq() > 0.01) {
        e.rig.root.position.addScaledVector(e.knockback, dt);
        e.knockback.multiplyScalar(Math.exp(-10 * dt));
      }

      this.resolveCircleWorldCollision(e.rig.root.position, e.radius, true);
      e.rig.root.position.y = this.world.getGroundHeight(
        e.rig.root.position.x,
        e.rig.root.position.z,
        e.rig.root.position.y,
      );

      // Smooth biomechanical gait, cover crouch, braced combat stance, hit-flinch & cloth for enemy fighter
      const actualMoveSpeed =
        Math.hypot(e.rig.root.position.x - prevEx, e.rig.root.position.z - prevEz) / Math.max(0.001, dt);
      e.moveBlend = THREE.MathUtils.damp(
        e.moveBlend,
        actualMoveSpeed > 0.3 ? Math.min(1, actualMoveSpeed / Math.max(1, e.speed)) : 0,
        10.5,
        dt,
      );
      e.landingCrouch = THREE.MathUtils.damp(e.landingCrouch, 0, 9.5, dt);
      e.coverCrouch = THREE.MathUtils.damp(e.coverCrouch, isDuckingCover ? 1 : 0, 9.0, dt);
      e.aimBlend = THREE.MathUtils.damp(
        e.aimBlend,
        isBracingFire || (hasLOS && e.tacticState === 'hold_cover' && e.coverPeeking) ? 1 : 0,
        11.0,
        dt,
      );
      e.recoil = THREE.MathUtils.damp(e.recoil, 0, 15, dt);

      if (e.moveBlend > 0.02) {
        e.walkPhase += dt * (4.8 + actualMoveSpeed * 0.94);
      }

      const ew = e.moveBlend;
      const ec = Math.min(1, e.landingCrouch + e.coverCrouch * 0.85);
      const ea = e.aimBlend;
      const eSprinting = (isRusher || e.tacticState === 'seek_cover') && ew > 0.72 && ea < 0.35 ? 1 : 0;
      const eSin = Math.sin(e.walkPhase);
      const eCos = Math.cos(e.walkPhase);
      const eStride = (isHeavy ? 0.42 : isRusher ? 0.66 : 0.54) * (1 - ea * 0.24) * (1 - e.coverCrouch * 0.35);
      const eLeftLift = Math.max(0, Math.sin(e.walkPhase + 0.85));
      const eRightLift = Math.max(0, -Math.sin(e.walkPhase + 0.85));

      // Hit-flinch spring impulse (head snaps back on headshot; shoulder/torso jerks on body hit)
      const flinchMax = e.flinchHead ? 0.24 : 0.16;
      const flinchPulse =
        e.flinchTimer > 0 ? Math.sin((e.flinchTimer / flinchMax) * Math.PI) : 0;

      e.rig.leftLeg.rotation.x = THREE.MathUtils.damp(
        e.rig.leftLeg.rotation.x,
        THREE.MathUtils.lerp(-0.05 - ea * 0.08, eSin * eStride, ew) - ec * 0.44,
        16,
        dt,
      );
      e.rig.rightLeg.rotation.x = THREE.MathUtils.damp(
        e.rig.rightLeg.rotation.x,
        THREE.MathUtils.lerp(0.05 + ea * 0.06, -eSin * eStride, ew) - ec * 0.38,
        16,
        dt,
      );
      e.rig.leftKnee.rotation.x = THREE.MathUtils.damp(
        e.rig.leftKnee.rotation.x,
        THREE.MathUtils.lerp(0.07 + ea * 0.14, eLeftLift * (isRusher ? 0.92 : 0.74) + 0.08 + ea * 0.08, ew) +
          ec * 0.82,
        16,
        dt,
      );
      e.rig.rightKnee.rotation.x = THREE.MathUtils.damp(
        e.rig.rightKnee.rotation.x,
        THREE.MathUtils.lerp(0.05 + ea * 0.12, eRightLift * (isRusher ? 0.92 : 0.74) + 0.08 + ea * 0.08, ew) +
          ec * 0.76,
        16,
        dt,
      );
      e.rig.leftAnkle.rotation.x = THREE.MathUtils.damp(
        e.rig.leftAnkle.rotation.x,
        THREE.MathUtils.lerp(-0.02 - ea * 0.06, Math.sin(e.walkPhase - 0.3) * 0.26, ew) - ec * 0.34,
        15,
        dt,
      );
      e.rig.rightAnkle.rotation.x = THREE.MathUtils.damp(
        e.rig.rightAnkle.rotation.x,
        THREE.MathUtils.lerp(-0.02 - ea * 0.06, -Math.sin(e.walkPhase - 0.3) * 0.26, ew) - ec * 0.28,
        15,
        dt,
      );

      e.rig.bodyGroup.position.y = THREE.MathUtils.damp(
        e.rig.bodyGroup.position.y,
        Math.abs(eCos) * (isHeavy ? 0.028 : 0.045) * ew - ea * 0.045 - ec * 0.24,
        15,
        dt,
      );
      e.rig.bodyGroup.rotation.y = THREE.MathUtils.damp(
        e.rig.bodyGroup.rotation.y,
        -ea * 0.14 + flinchPulse * 0.14 * e.flinchSide,
        14,
        dt,
      );
      e.rig.bodyGroup.rotation.z = THREE.MathUtils.damp(
        e.rig.bodyGroup.rotation.z,
        eSin * (isHeavy ? 0.02 : 0.034) * ew + flinchPulse * 0.08 * e.flinchSide,
        13,
        dt,
      );

      const eBreath = Math.sin(this.worldTime * (2.2 + ew * 1.4) + e.id);
      e.rig.upperBodyGroup.position.y = 0.94 + eBreath * 0.007;
      e.rig.upperBodyGroup.rotation.x = THREE.MathUtils.damp(
        e.rig.upperBodyGroup.rotation.x,
        (eSprinting ? 0.18 : isRusher ? 0.12 : 0.055) * ew +
          ec * 0.24 +
          ea * 0.075 -
          e.recoil * 0.1 -
          flinchPulse * (e.flinchHead ? 0.26 : 0.16),
        16,
        dt,
      );
      e.rig.upperBodyGroup.rotation.y = THREE.MathUtils.damp(
        e.rig.upperBodyGroup.rotation.y,
        ea * 0.14 - eSin * (ea > 0.4 ? 0.025 : 0.11) * ew + flinchPulse * 0.22 * e.flinchSide,
        15,
        dt,
      );
      e.rig.upperBodyGroup.rotation.z = THREE.MathUtils.damp(
        e.rig.upperBodyGroup.rotation.z,
        THREE.MathUtils.clamp(e.yawRate * 0.024, -0.09, 0.09) + flinchPulse * 0.14 * e.flinchSide,
        14,
        dt,
      );

      e.rig.headGroup.rotation.y = THREE.MathUtils.damp(
        e.rig.headGroup.rotation.y,
        -(e.rig.upperBodyGroup.rotation.y + e.rig.bodyGroup.rotation.y) * 0.68 +
          THREE.MathUtils.clamp(eYawDiff * 0.22, -0.24, 0.24) +
          (e.flinchHead ? flinchPulse * 0.34 * e.flinchSide : 0),
        16,
        dt,
      );
      e.rig.headGroup.rotation.x = THREE.MathUtils.damp(
        e.rig.headGroup.rotation.x,
        -e.rig.upperBodyGroup.rotation.x * 0.52 - (e.flinchHead ? flinchPulse * 0.42 : 0),
        16,
        dt,
      );
      e.rig.hairTuft.rotation.x = Math.sin(this.worldTime * (4.0 + actualMoveSpeed * 0.5) + e.id) * (0.02 + ew * 0.035);

      // Clearer weapon posture: raised shoulder-braced aim during bursts, low-ready sprint carry when rushing/moving to cover
      e.rig.weaponPivot.position.y = THREE.MathUtils.damp(
        e.rig.weaponPivot.position.y,
        0.24 + ea * 0.045 - eSprinting * 0.045 - e.coverCrouch * 0.04,
        16,
        dt,
      );
      e.rig.weaponPivot.position.z = THREE.MathUtils.damp(
        e.rig.weaponPivot.position.z,
        0.22 - e.recoil * 0.075 + ea * 0.035 - eSprinting * 0.02,
        22,
        dt,
      );
      e.rig.weaponPivot.rotation.x = THREE.MathUtils.damp(
        e.rig.weaponPivot.rotation.x,
        -e.recoil * 0.2 + (ea > 0.3 ? -0.05 * ea : (eSprinting ? 0.2 : 0.05) * ew) + Math.abs(eCos) * 0.022 * ew,
        20,
        dt,
      );
      e.rig.weaponPivot.rotation.y = THREE.MathUtils.damp(
        e.rig.weaponPivot.rotation.y,
        -eSprinting * 0.28 - e.coverCrouch * 0.22,
        15,
        dt,
      );
      e.rig.leftArm.position.z = THREE.MathUtils.damp(e.rig.leftArm.position.z, -e.recoil * 0.035, 20, dt);
      e.rig.leftArm.position.y = THREE.MathUtils.damp(e.rig.leftArm.position.y, Math.abs(eCos) * 0.01 * ew + ea * 0.015, 16, dt);

      // Update enemy flowing scarf / headband tails / warrior shoulder shawl
      e.rig.updateCloth(dt, this.worldTime, actualMoveSpeed, e.yawRate, 0.22);

      // Combat firing with tactical bursts ONLY when on-foot, safe timer expired, peeking/open, AND clear line-of-sight!
      const canEngage =
        !playerProtectedInBus &&
        e.postLandingSafeTimer <= 0 &&
        hasLOS &&
        !isDuckingCover;
      if (canEngage) {
        if (e.burstRemaining > 0) {
          e.rig.telegraphGlow.visible = false;
          e.burstDelay -= dt;
          if (e.burstDelay <= 0) {
            this.fireEnemyShot(e, dist);
            e.burstRemaining--;
            e.burstDelay = isHeavy ? 0.26 : isRusher ? 0.18 : 0.22;
            if (e.burstRemaining <= 0) {
              e.fireCooldown = isHeavy
                ? 1.7
                : isRusher
                  ? 1.2
                  : Math.max(1.15, 1.9 - this.wave * 0.055);
            }
          }
        } else if (e.telegraphTimer > 0) {
          e.telegraphTimer -= dt;
          e.rig.telegraphGlow.visible = true;
          const pulse = 0.8 + (1 - e.telegraphTimer / 0.45) * 0.72;
          e.rig.telegraphGlow.scale.setScalar(pulse);
          if (e.telegraphTimer <= 0) {
            e.rig.telegraphGlow.visible = false;
            this.fireEnemyShot(e, dist);
            // Short 2-3 round tactical bursts feel much closer to real mobile shooter engagements
            e.burstRemaining = isHeavy ? 2 : 1;
            e.burstDelay = isHeavy ? 0.26 : isRusher ? 0.18 : 0.22;
          }
        } else {
          e.fireCooldown -= dt;
          if (e.fireCooldown <= 0) {
            e.telegraphTimer = isHeavy ? 0.52 : 0.38;
          }
        }
      } else {
        e.rig.telegraphGlow.visible = false;
        e.telegraphTimer = 0;
        e.burstRemaining = 0;
      }
    }
  }

  private findCoverSpotForEnemy(e: ActiveEnemy): boolean {
    const ex = e.rig.root.position.x;
    const ez = e.rig.root.position.z;
    const hx = this.heroPos.x;
    const hz = this.heroPos.z;
    const colliders = this.world.circleColliders;
    const bounds = this.world.playableBounds;

    let bestScore = Infinity;
    let bestX = 0;
    let bestZ = 0;
    let found = false;

    for (let i = 0; i < colliders.length; i++) {
      const c = colliders[i];
      if (c.height < 1.15 || c.radius < 0.45) continue;

      const dEnemyX = c.x - ex;
      const dEnemyZ = c.z - ez;
      const dEnemySq = dEnemyX * dEnemyX + dEnemyZ * dEnemyZ;
      if (dEnemySq < 4.0 || dEnemySq > 18.0 * 18.0) continue;

      const fromHeroX = c.x - hx;
      const fromHeroZ = c.z - hz;
      const fromHeroDist = Math.hypot(fromHeroX, fromHeroZ);
      if (fromHeroDist < 6.5 || fromHeroDist > e.fireRange + 3.0) continue;

      // Shelter point directly behind obstacle away from the player
      const standOff = c.radius + e.radius + 0.5;
      const spotX = c.x + (fromHeroX / fromHeroDist) * standOff;
      const spotZ = c.z + (fromHeroZ / fromHeroDist) * standOff;

      if (
        spotX < bounds.minX + 2 ||
        spotX > bounds.maxX - 2 ||
        spotZ < bounds.minZ + 2 ||
        spotZ > bounds.maxZ - 2 ||
        this.world.isWaterBlocked(spotX, spotZ)
      ) {
        continue;
      }

      // Ensure cover spot sits cleanly outside neighboring building/obstacle footprints so bots never wedge against walls
      let blockedSpot = false;
      for (let k = 0; k < colliders.length; k++) {
        if (k === i) continue;
        const o = colliders[k];
        const minClear = o.radius + e.radius + 0.15;
        const odx = spotX - o.x;
        const odz = spotZ - o.z;
        if (odx * odx + odz * odz < minClear * minClear) {
          blockedSpot = true;
          break;
        }
      }
      if (blockedSpot) continue;

      // Skip spots already claimed by another living enemy
      let occupied = false;
      for (let j = 0; j < this.enemies.length; j++) {
        const o = this.enemies[j];
        if (o === e || o.dying || !o.hasCoverSpot) continue;
        const odx = o.coverX - spotX;
        const odz = o.coverZ - spotZ;
        if (odx * odx + odz * odz < 4.5) {
          occupied = true;
          break;
        }
      }
      if (occupied) continue;

      const dEnemy = Math.sqrt(dEnemySq);
      const idealHeroDist = e.archetype === 'heavy' ? 12.0 : 14.0;
      const score = dEnemy + Math.abs(fromHeroDist - idealHeroDist) * 0.65;
      if (score < bestScore) {
        bestScore = score;
        bestX = spotX;
        bestZ = spotZ;
        found = true;
      }
    }

    if (found) {
      e.coverX = bestX;
      e.coverZ = bestZ;
    }
    return found;
  }

  private fireEnemyShot(e: ActiveEnemy, distToHero: number): void {
    // Defense-in-depth: never fire while player is inside/jumping from bus or enemy safe timer active
    if (this.busMode !== 'none' || this.heroJumpingFromBus || e.postLandingSafeTimer > 0) return;

    e.rig.root.updateMatrixWorld(true);
    const muzzleWorld = _v1;
    e.rig.muzzlePoint.getWorldPosition(muzzleWorld);

    const aimTarget = _v2.set(
      this.heroPos.x,
      this.heroPos.y + 1.42 - this.heroCrouchBlend * 0.36,
      this.heroPos.z,
    );
    // Verify clean line of sight from actual weapon muzzle too (never shoot through walls!)
    if (!this.hasLineOfSight(muzzleWorld, aimTarget)) return;

    const dir = _v3.subVectors(aimTarget, muzzleWorld).normalize();

    // Fair dodgeable inaccuracy so movement & cover matter
    const spread = e.archetype === 'heavy' ? 0.055 : 0.08;
    dir.x += (Math.random() - 0.5) * spread;
    dir.y += (Math.random() - 0.5) * 0.032;
    dir.z += (Math.random() - 0.5) * spread;
    dir.normalize();

    const dmg = e.archetype === 'heavy' ? 11 : e.archetype === 'rusher' ? 8 : 8;
    const speed = e.archetype === 'heavy' ? 24 : 28;
    e.recoil = 1.0;
    this.spawnBullet(
      false,
      muzzleWorld,
      dir,
      speed,
      dmg,
      e.rig.root.position.x,
      e.rig.root.position.z,
    );
    this.audio.playEnemyShot(distToHero);
  }

  private updateBullets(dt: number): void {
    for (const b of this.bullets) {
      if (!b.active) continue;
      b.life -= dt;

      // Swept continuous segment [prevPos -> nextPos] prevents tunneling through enemies OR solid walls!
      const prevPos = _v5.copy(b.pos);
      b.pos.addScaledVector(b.vel, dt);
      b.mesh.position.copy(b.pos);

      if (b.life <= 0) {
        b.active = false;
        b.mesh.visible = false;
        continue;
      }

      const obsT = this.segmentFirstObstacleT(prevPos, b.pos, true);

      if (b.fromPlayer) {
        // Find earliest swept hit against separate Head vs Body hitboxes BEFORE any solid wall/obstacle
        let hitEnemy: ActiveEnemy | null = null;
        let hitIsHeadshot = false;
        let bestEnemyT = obsT; // Never hit an enemy behind a wall!

        for (let i = 0; i < this.enemies.length; i++) {
          const e = this.enemies[i];
          if (e.dying || e.busSeatIndex >= 0 || e.jumpingFromBus) continue;
          const s = this.getEnemyScale(e);
          const ex = e.rig.root.position.x;
          const ey = e.rig.root.position.y;
          const ez = e.rig.root.position.z;

          // 1. Separate Head Hitbox (upper cranium & face zone: ey + 1.54*s .. ey + 2.04*s)
          const tHead = this.segmentHitsCylinderT(
            prevPos,
            b.pos,
            ex,
            ez,
            0.39 * s,
            ey + 1.54 * s,
            ey + 2.04 * s,
          );
          if (tHead < bestEnemyT) {
            bestEnemyT = tHead;
            hitEnemy = e;
            hitIsHeadshot = true;
          }

          // 2. Separate Body Hitbox (torso & legs zone: ey + 0.02 .. ey + 1.54*s)
          const tBody = this.segmentHitsCylinderT(
            prevPos,
            b.pos,
            ex,
            ez,
            e.radius + 0.3,
            ey + 0.02,
            ey + 1.54 * s,
          );
          if (tBody < bestEnemyT) {
            bestEnemyT = tBody;
            hitEnemy = e;
            hitIsHeadshot = false;
          }
        }

        // Also test swept bullet hit against scattered wild animals (never behind walls)
        let hitWildAnimal: ActiveWildAnimal | null = null;
        for (const wa of this.wildAnimals) {
          if (wa.state === 'dead') continue;
          const bodyS = WILD_ANIMAL_CATALOG[wa.species].bodyScale;
          const tAnimal = this.segmentHitsCylinderT(
            prevPos,
            b.pos,
            wa.pos.x,
            wa.pos.z,
            wa.radius + 0.34,
            wa.pos.y + 0.04,
            wa.pos.y + 1.52 * bodyS,
          );
          if (tAnimal < bestEnemyT) {
            bestEnemyT = tAnimal;
            hitEnemy = null;
            hitWildAnimal = wa;
          }
        }

        if (hitWildAnimal) {
          if (this.tryWildAnimalBulletDodge(hitWildAnimal, b.vel)) {
            // Animal agilely sidestepped this incoming shot — let the tracer zip cleanly past!
            continue;
          }
          _v6.lerpVectors(prevPos, b.pos, bestEnemyT);
          this.damageWildAnimal(hitWildAnimal, b.damage, b.vel, _v6);
          b.active = false;
          b.mesh.visible = false;
          continue;
        }

        if (hitEnemy) {
          _v6.lerpVectors(prevPos, b.pos, bestEnemyT);
          this.damageEnemy(hitEnemy, b.damage, b.vel, hitIsHeadshot, _v6);
          b.active = false;
          b.mesh.visible = false;
          continue;
        }
      } else {
        // Enemy bullet: player is 100% invulnerable while inside or jumping off the WBTC bus!
        if (this.busMode === 'none' && !this.heroJumpingFromBus) {
          const tHero = this.segmentHitsCylinderT(
            prevPos,
            b.pos,
            this.heroPos.x,
            this.heroPos.z,
            0.64,
            this.heroPos.y + 0.05,
            this.heroPos.y + 2.18 - this.heroCrouchBlend * 0.48,
          );
          if (tHero < obsT) {
            this.damagePlayer(b.damage, false, b.sourceX, b.sourceZ);
            b.active = false;
            b.mesh.visible = false;
            continue;
          }
        }
      }

      // If bullet hit a wall, mud house, yellow taxi, tree, cover crate, or WBTC bus hull
      if (obsT <= 1) {
        _v6.lerpVectors(prevPos, b.pos, obsT);
        const sparkColor = this.busMode === 'driving' ? 0xffe082 : 0xd8a872;
        this.spawnParticles(_v6, sparkColor, 5, 3.8);
        this.spawnImpactFlash(_v6, 0xffe6ad, 0.85, 0.11);
        b.active = false;
        b.mesh.visible = false;
      }
    }
  }

  private damageEnemy(
    e: ActiveEnemy,
    baseDmg: number,
    bulletVel: THREE.Vector3,
    isHeadshot = false,
    hitPoint?: THREE.Vector3,
  ): void {
    const finalDmg = isHeadshot ? Math.round(baseDmg * 2.5) : Math.round(baseDmg);
    e.hp -= finalDmg;
    e.hitFlashTimer = 0.105;
    e.rig.flashMaterials.forEach((m) => m.emissive.setHex(isHeadshot ? 0xff2828 : 0xffffff));

    // Crisp head/torso hit-flinch reaction & reactive cover-seeking under fire
    e.flinchTimer = isHeadshot ? 0.24 : 0.16;
    e.flinchHead = isHeadshot;
    e.flinchSide = Math.random() > 0.5 ? 1 : -1;
    if (
      e.hp > 0 &&
      e.archetype !== 'rusher' &&
      e.tacticState !== 'hold_cover' &&
      e.tacticState !== 'seek_cover' &&
      Math.random() < 0.65
    ) {
      if (this.findCoverSpotForEnemy(e)) {
        e.hasCoverSpot = true;
        e.tacticState = 'seek_cover';
        e.tacticTimer = 2.8;
      }
    }

    // Track live Headshot vs Body Shot counters
    if (isHeadshot) {
      this.headshots++;
    } else {
      this.bodyshots++;
    }

    // Spawn animated floating 3D damage number above hit point
    const s = this.getEnemyScale(e);
    const dmgOrigin = hitPoint
      ? hitPoint.clone()
      : new THREE.Vector3(
          e.rig.root.position.x,
          e.rig.root.position.y + (isHeadshot ? 1.85 * s : 1.3 * s),
          e.rig.root.position.z,
        );
    this.spawnFloatingDamage(dmgOrigin, finalDmg, isHeadshot);

    // Squash & stretch impact reaction
    e.rig.bodyGroup.scale.set(s * 1.13, s * 0.89, s * 1.13);

    // Knockback along shot direction
    if (bulletVel.lengthSq() > 0.0001) {
      _v1.copy(bulletVel).setY(0).normalize().multiplyScalar(e.archetype === 'heavy' ? 2.6 : 5.4);
      e.knockback.copy(_v1);
    }

    // Update world-space health bar
    e.rig.hpBarBg.visible = true;
    const ratio = Math.max(0, e.hp / e.maxHp);
    e.rig.hpBarFill.scale.x = Math.max(0.001, ratio);

    // Punchy 3D impact burst ring + directional hit sparks
    this.spawnImpactFlash(
      dmgOrigin,
      isHeadshot ? 0xff2b2b : 0xffe07d,
      isHeadshot ? 2.1 : 1.35,
      isHeadshot ? 0.19 : 0.13,
    );
    this.spawnParticles(dmgOrigin, isHeadshot ? 0xff2424 : 0xff9244, isHeadshot ? 13 : 7, isHeadshot ? 6.2 : 5.2);

    if (e.hp <= 0) {
      e.dying = true;
      e.deathTimer = 0;
      this.kills++;
      const pts =
        (e.archetype === 'heavy' ? 180 : e.archetype === 'rusher' ? 130 : 100) +
        (isHeadshot ? 50 : 0);
      this.score += pts;
      this.checkHighScore();
      this.hitMarker = 1.0;
      this.hitMarkerKill = true;
      this.hitMarkerHeadshot = isHeadshot;
      this.hitstopTimer = isHeadshot ? 0.055 : 0.038;
      this.camShake = Math.min(0.36, this.camShake + (isHeadshot ? 0.17 : 0.12));
      if (isHeadshot) {
        this.audio.playHeadshotPing();
      }
      this.audio.playEnemyHit(true);
      this.spawnParticles(
        _v2.set(e.rig.root.position.x, e.rig.root.position.y + 1.2, e.rig.root.position.z),
        0xffa73b,
        15,
        6.8,
      );

      // Spawn a glowing wooden-and-brass Warrior Loot Chest ('যোদ্ধা সিন্দুক') whenever an enemy is defeated!
      // (Animal Hearts NEVER drop from human enemies — only from selected special wild animals!)
      this.spawnWarriorChest(e.rig.root.position.x, e.rig.root.position.z, e.rig.root.rotation.y);
    } else {
      this.hitMarker = isHeadshot ? 0.96 : 0.78;
      this.hitMarkerKill = false;
      this.hitMarkerHeadshot = isHeadshot;
      this.camShake = Math.min(0.24, this.camShake + (isHeadshot ? 0.055 : 0.026));
      if (isHeadshot) {
        this.audio.playHeadshotPing();
      } else {
        this.audio.playEnemyHit(false);
      }
    }
  }

  private damagePlayer(
    dmg: number,
    bypassArmor = false,
    sourceX?: number,
    sourceZ?: number,
  ): void {
    // Player is completely invulnerable while inside or leaping off the WBTC bus
    if (this.busMode !== 'none' || this.heroJumpingFromBus) return;

    // Cancel active Sanjibani healing, sprint toggle, or wild animal taming if struck by a direct impact
    if (!bypassArmor && dmg > 0 && this.sprintToggled) {
      this.cancelSprintToggle();
    }
    if (!bypassArmor && this.isHealing) {
      this.isHealing = false;
      this.pickupToast = 'আঘাতে চিকিৎসা ব্যাহত হয়েছে!';
      this.pickupToastTimer = 1.4;
    }
    if (!bypassArmor && this.tamingActive) {
      this.cancelTaming('আঘাতে বশ করার চেষ্টা ব্যাহত হয়েছে!');
    }

    let remaining = dmg;
    let armorAbsorbed = false;
    if (!bypassArmor && this.armor > 0) {
      // Raksha Kabach (Body Armor) absorbs incoming bullet damage first!
      const absorbed = Math.min(this.armor, remaining);
      this.armor -= absorbed;
      remaining -= absorbed;
      armorAbsorbed = absorbed > 0 && remaining <= 0;
      this.hero.armorVestOverlay.visible = this.armor > 0;
    }

    if (remaining > 0) {
      this.health = Math.max(0, this.health - remaining);
    }

    this.damageFlash = bypassArmor ? Math.max(this.damageFlash, 0.42) : 0.95;
    if (!bypassArmor) {
      if (sourceX !== undefined && sourceZ !== undefined) {
        this.damageSourcePos.set(sourceX, this.heroPos.y, sourceZ);
        this.hasDamageSource = true;
      }
      this.camShake = Math.min(0.42, this.camShake + (armorAbsorbed ? 0.12 : 0.18));
      this.audio.playPlayerHurt(armorAbsorbed);
    }

    if (this.health <= 0) {
      if (this.activeTwoWheeler) {
        this.dismountTwoWheeler(true);
      }
      this.phase = 'gameover';
      this.scopeActive = false;
      this.isHealing = false;
      this.tamingActive = false;
      this.tamingProgress = 0;
      this.cancelSprintToggle();
      this.keysHeld.clear();
      this.mouseShootHeld = false;
      this.virtualInput.shooting = false;
      this.safeExitPointerLock();
      this.checkHighScore();
      this.emitHud();
    }
  }

  private updatePickups(dt: number): void {
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const p = this.pickups[i];
      p.life -= dt;
      if (p.kind !== 'sanjibani') {
        p.mesh.rotation.y += dt * 1.8;
        p.mesh.position.y = p.pos.y + Math.sin(this.worldTime * 3.2 + p.id) * 0.1;
      } else {
        p.mesh.rotation.y += dt * 0.7;
      }

      if (this.busMode === 'none' && !this.heroJumpingFromBus) {
        const distSq = p.pos.distanceToSquared(this.heroPos);
        if (distSq < 1.9 * 1.9) {
          let collected = false;
          if (p.kind === 'sanjibani') {
            if (this.sanjibaniCount < this.maxSanjibani) {
              this.sanjibaniCount++;
              this.sanjibaniCollected++;
              this.pickupToast = `সঞ্জীবনী গাছ +১ (${toBengaliNumber(this.sanjibaniCount)}/${toBengaliNumber(this.maxSanjibani)})`;
              this.audio.playPickup('health');
              collected = true;
            }
          } else if (p.kind === 'armor') {
            if (this.armor < this.maxArmor) {
              this.armor = this.maxArmor;
              this.hero.armorVestOverlay.visible = true;
              this.pickupToast = 'রক্ষা কবচ +৫০';
              this.audio.playPickup('health');
              collected = true;
            }
          } else if (p.kind === 'grenade') {
            if (this.grenadeCount < this.maxGrenades) {
              this.grenadeCount++;
              this.pickupToast = 'বজ্র গোলা +১';
              this.audio.playPickup('ammo');
              collected = true;
            }
          } else {
            const targetW: WeaponType = this.weaponType === 'fala' ? 'agni47' : this.weaponType;
            const meta = WEAPON_CATALOG[targetW];
            const slot = this.weaponSlots[targetW];
            slot.reserve = Math.min(meta.maxReserve, slot.reserve + meta.magSize);
            this.pickupToast = `${meta.shortName} গুলি +${toBengaliNumber(meta.magSize)}`;
            this.audio.playPickup('ammo');
            collected = true;
          }

          if (collected) {
            this.pickupToastTimer = 1.9;
            this.scene.remove(p.mesh);
            this.pickups.splice(i, 1);
            continue;
          }
        }
      }

      if (p.life <= 0) {
        this.scene.remove(p.mesh);
        this.pickups.splice(i, 1);
      }
    }
  }

  private updateChests(dt: number): void {
    let closest: LootChestItem | null = null;
    let closestDistSq = 3.25 * 3.25;

    for (let i = this.chests.length - 1; i >= 0; i--) {
      const c = this.chests[i];
      if (c.opened) {
        c.openProgress = Math.min(1, c.openProgress + dt * 4.5);
        c.rig.lidPivot.rotation.x = -c.openProgress * 1.75;
        c.rig.glowRing.visible = false;
        c.rig.innerGlow.visible = c.openProgress < 0.85;
        c.rig.brassMat.emissiveIntensity = 0.08;
        c.life -= dt * 3.5;
        if (c.life <= 0) {
          this.scene.remove(c.rig.root);
          this.chests.splice(i, 1);
        }
        continue;
      }

      // Subtle warm golden chest shimmer
      const shimmer = 0.55 + Math.sin(this.worldTime * 3.8 + c.id) * 0.25;
      c.rig.brassMat.emissiveIntensity = shimmer;
      c.rig.glowRing.rotation.z = this.worldTime * 0.6;

      if (this.busMode === 'none' && !this.heroJumpingFromBus && !this.activeTwoWheeler) {
        const dSq = c.pos.distanceToSquared(this.heroPos);
        if (dSq < closestDistSq) {
          closestDistSq = dSq;
          closest = c;
        }
      }
    }

    this.nearestChest = closest;
    this.nearChest = closest !== null;
  }

  private updateGrenades(dt: number): void {
    for (let i = this.grenades.length - 1; i >= 0; i--) {
      const g = this.grenades[i];
      g.fuseTimer -= dt;

      // Parabolic gravity flight & bounce against ground/obstacles
      g.vel.y -= 21 * dt;
      g.pos.addScaledVector(g.vel, dt);
      const gGround = this.world.getGroundHeight(g.pos.x, g.pos.z, g.pos.y) + 0.16;
      if (g.pos.y < gGround) {
        g.pos.y = gGround;
        g.vel.y = Math.abs(g.vel.y) * 0.38;
        g.vel.x *= 0.68;
        g.vel.z *= 0.68;
      }
      this.resolveCircleWorldCollision(g.pos, 0.22, true);
      g.mesh.position.copy(g.pos);
      g.mesh.rotation.x += dt * 7;
      g.mesh.rotation.z += dt * 5;

      // Blinking fuse spark intensity speeds up near detonation
      const spark = g.mesh.getObjectByName('fuseSpark') as THREE.Mesh | undefined;
      if (spark) {
        const rate = g.fuseTimer < 1.0 ? 28 : 12;
        spark.visible = Math.sin(this.worldTime * rate) > 0;
      }

      if (g.fuseTimer <= 0) {
        this.detonateGrenade(g.pos);
        this.scene.remove(g.mesh);
        this.grenades.splice(i, 1);
      }
    }

    // Animate fiery explosion shockwave rings
    for (let i = this.shockwaves.length - 1; i >= 0; i--) {
      const sw = this.shockwaves[i];
      sw.life -= dt;
      if (sw.life <= 0) {
        this.scene.remove(sw.mesh);
        sw.mesh.geometry.dispose();
        (sw.mesh.material as THREE.Material).dispose();
        this.shockwaves.splice(i, 1);
        continue;
      }
      const p = 1 - sw.life / sw.maxLife;
      const scale = 0.6 + p * 7.5;
      sw.mesh.scale.set(scale, scale, 1);
      (sw.mesh.material as THREE.MeshBasicMaterial).opacity = (1 - p) * 0.85;
    }
  }

  private detonateGrenade(center: THREE.Vector3): void {
    this.audio.playGrenadeExplosion();
    this.camShake = Math.min(0.62, this.camShake + 0.45);
    this.spawnParticles(center, 0xff6e1f, 24, 9.5);
    this.spawnParticles(_v1.set(center.x, center.y + 0.4, center.z), 0xffe066, 14, 7.2);

    // Expanding fiery ground shockwave ring
    const ringGeo = new THREE.RingGeometry(0.65, 1.0, 32);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0xff8c2b,
      transparent: true,
      opacity: 0.85,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    const ringMesh = new THREE.Mesh(ringGeo, ringMat);
    ringMesh.rotation.x = -Math.PI / 2;
    ringMesh.position.set(center.x, 0.14, center.z);
    this.scene.add(ringMesh);
    this.shockwaves.push({ mesh: ringMesh, life: 0.42, maxLife: 0.42 });

    // Area damage (7.4m blast radius) to all grounded enemies
    const blastR = 7.4;
    for (const e of this.enemies) {
      if (e.dying || e.busSeatIndex >= 0 || e.jumpingFromBus) continue;
      const dist = e.rig.root.position.distanceTo(center);
      if (dist <= blastR) {
        const falloff = 1 - (dist / blastR) * 0.62;
        const dmg = this.getScaledPlayerDamage(125 * falloff);
        _v4.subVectors(e.rig.root.position, center).setY(0);
        const hitPt = new THREE.Vector3(e.rig.root.position.x, 1.35, e.rig.root.position.z);
        this.damageEnemy(e, dmg, _v4, false, hitPt);
      }
    }

    // Grenade blast can also damage or kill nearby wild animals
    for (const wa of this.wildAnimals) {
      if (wa.state === 'dead') continue;
      const dist = wa.pos.distanceTo(center);
      if (dist <= blastR) {
        const falloff = 1 - (dist / blastR) * 0.62;
        const dmg = this.getScaledPlayerDamage(115 * falloff);
        _v4.subVectors(wa.pos, center).setY(0);
        const hitPt = _v6.set(wa.pos.x, wa.pos.y + 0.8, wa.pos.z);
        this.damageWildAnimal(wa, dmg, _v4, hitPt);
      }
    }
  }

  // --- Player & Pet XP / Level-Up Progression, Challenging Animal-to-Pet Taming & Selective Animal Hearts ---

  private getScaledPlayerDamage(baseDmg: number): number {
    return Math.max(1, Math.round(baseDmg * this.playerProgression.weaponDamageMult));
  }

  private syncPetCompanionAfterUpgrade(updatedPet: TamedPetRecord): void {
    if (!this.petCompanion) return;
    this.petCompanion.record = updatedPet;
    this.petCompanion.maxHp = updatedPet.stats.maxHp;
    this.petCompanion.hp = updatedPet.stats.maxHp;
    this.petCompanion.retreatHealTimer = 0;
    applyPetLevelVisuals(this.petCompanion.rig, updatedPet.upgrades.level);
    this.spawnParticles(
      _v1.set(this.petCompanion.pos.x, this.petCompanion.pos.y + 1.0, this.petCompanion.pos.z),
      0x4df5b8,
      18,
      5.8,
    );
    this.spawnParticles(
      _v1.set(this.petCompanion.pos.x, this.petCompanion.pos.y + 1.2, this.petCompanion.pos.z),
      0xffd24c,
      14,
      4.8,
    );
  }

  public upgradePlayerWithHearts(): boolean {
    if (this.phase !== 'title') return false;
    const result = upgradePlayerWithAnimalHeartsForId(this.playerId);
    if (!result) return false;

    this.playerProgression = result.state;
    this.maxHealth = result.state.maxHealth;
    this.health = this.maxHealth;
    this.animalHearts = result.wallet;

    this.spawnParticles(
      _v1.set(this.heroPos.x, this.heroPos.y + 1.2, this.heroPos.z),
      0xffd84d,
      20,
      6.0,
    );
    this.spawnParticles(
      _v1.set(this.heroPos.x, this.heroPos.y + 1.4, this.heroPos.z),
      0xff6b8a,
      14,
      5.0,
    );

    this.audio.playTameSuccess();
    this.levelUpNotice = {
      target: 'player',
      playerLevel: result.state.level,
      playerHpGain: result.hpGain,
      playerDmgBonusPct: result.state.weaponDamageBonusPct,
      seq: ++this.levelUpSeq,
    };
    this.levelUpNoticeTimer = 4.4;
    this.emitHud();
    return true;
  }

  public upgradePermanentPet(): boolean {
    if (this.phase !== 'title') return false;
    if (!this.permanentPet) return false;
    const result = upgradePermanentPetForId(this.playerId);
    if (!result) return false;

    this.permanentPet = result.pet;
    this.animalHearts = result.wallet;
    this.syncPetCompanionAfterUpgrade(result.pet);

    this.audio.playTameSuccess();
    const hpGain = result.pet.stats.maxHp - result.prevStats.maxHp;
    const dmgGain = result.pet.stats.attackDamage - result.prevStats.attackDamage;
    const spdGain = Number((result.pet.stats.moveSpeed - result.prevStats.moveSpeed).toFixed(1));
    this.levelUpNotice = {
      target: 'pet',
      playerLevel: this.playerProgression.level,
      playerHpGain: 0,
      playerDmgBonusPct: this.playerProgression.weaponDamageBonusPct,
      petNameBn: result.pet.nameBn,
      petLevel: result.pet.upgrades.level,
      petHpGain: hpGain,
      petDmgGain: dmgGain,
      petSpeedGain: spdGain,
      seq: ++this.levelUpSeq,
    };
    this.levelUpNoticeTimer = 4.4;
    this.emitHud();
    return true;
  }

  private spawnPermanentPetCompanion(record: TamedPetRecord, spawnPos?: THREE.Vector3): void {
    if (this.petCompanion) {
      this.scene.remove(this.petCompanion.rig.root);
      this.petCompanion = null;
    }
    const rig = buildAnimalRig(record.species, true);
    rig.hpBarBg.visible = false;
    rig.subduedRing.visible = false;
    rig.tameRing.visible = false;
    rig.heartAuraRing.visible = false;
    applyPetLevelVisuals(rig, record.upgrades.level);
    const pos = spawnPos ? spawnPos.clone() : new THREE.Vector3(-1.62, 0, 7.66);
    rig.root.position.copy(pos);
    this.scene.add(rig.root);

    this.petCompanion = {
      record,
      rig,
      hp: record.stats.maxHp,
      maxHp: record.stats.maxHp,
      pos,
      velX: 0,
      velZ: 0,
      yaw: 0.42,
      walkPhase: 0,
      moveBlend: 0,
      assistState: 'follow',
      assistTargetId: null,
      assistTargetWild: false,
      assistTargetWildId: null,
      assistCooldown: Math.min(2.6, record.stats.assistCooldown * 0.55),
      assistTimer: 0,
      retreatHealTimer: 0,
      placedOnFoot: Boolean(spawnPos),
    };
  }

  private spawnScatteredWildAnimals(targetCount: number): void {
    const biomeOrder = [
      'জলাভূমি ও বিল',
      'প্রাচীন ধ্বংসাবশেষ',
      'পাথুরে পাহাড়',
      'উন্মুক্ত তৃণভূমি',
      'পাথুরে গুহা',
      'শালবন',
      'সুন্দরবন প্রান্ত',
    ];
    for (let i = 0; i < targetCount; i++) {
      const areaBn = biomeOrder[i % biomeOrder.length];
      this.spawnWildAnimal(undefined, areaBn);
    }
  }

  private spawnWildAnimal(forcedSpecies?: WildAnimalSpecies, preferredAreaBn?: string): void {
    const maxAnimals = this.gameMode === 'pet_taming' ? 14 : 6;
    const aliveCount = this.wildAnimals.filter((w) => w.state !== 'dead').length;
    if (aliveCount >= maxAnimals) return;

    // Scatter animals across ALL varied areas (forests, caves, rocky hills, swamp, ancient ruins, grassland)
    const bounds = this.world.playableBounds;
    const habitats = this.world.wildAnimalHabitats;

    // Prefer habitats matching requested biome or least-populated biome so animals always stay spread out
    let habitatPool = habitats;
    if (preferredAreaBn) {
      const areaMatches = habitats.filter((h) => h.areaBn === preferredAreaBn);
      if (areaMatches.length > 0) habitatPool = areaMatches;
    } else if (forcedSpecies) {
      const spMatches = habitats.filter((h) => !h.speciesHint || h.speciesHint === forcedSpecies);
      if (spMatches.length > 0) habitatPool = spMatches;
    }

    const minDistFromHero = this.gameMode === 'pet_taming' ? 68 : 105;
    const isSpotClear = (h: { x: number; z: number }, minSpacing: number) => {
      const dHero = Math.hypot(h.x - this.heroPos.x, h.z - this.heroPos.z);
      if (dHero < minDistFromHero) return false;
      for (const existing of this.wildAnimals) {
        if (existing.state === 'dead') continue;
        if (Math.hypot(h.x - existing.homeX, h.z - existing.homeZ) < minSpacing) return false;
      }
      return true;
    };

    let unoccupied = habitatPool.filter((h) => isSpotClear(h, 24));
    if (unoccupied.length === 0) {
      // Fallback across all biomes if the preferred biome is already full
      unoccupied = habitats.filter((h) => isSpotClear(h, 24));
    }
    const candidates =
      unoccupied.length > 0
        ? unoccupied
        : habitatPool.filter((h) => Math.hypot(h.x - this.heroPos.x, h.z - this.heroPos.z) >= 55);
    const finalPool = candidates.length > 0 ? candidates : habitatPool;

    const chosen = finalPool[Math.floor(Math.random() * finalPool.length)];
    const species =
      forcedSpecies ??
      chosen?.speciesHint ??
      WILD_ANIMAL_SPECIES_LIST[this.wildAnimalSpawnIndex % WILD_ANIMAL_SPECIES_LIST.length];
    this.wildAnimalSpawnIndex++;
    const meta = WILD_ANIMAL_CATALOG[species];

    let spawnX = chosen ? chosen.x : 140;
    let spawnZ = chosen ? chosen.z : 190;
    for (let attempt = 0; attempt < 12; attempt++) {
      const jitterR = attempt === 0 ? 1.5 : 3 + Math.random() * 8;
      const jitterA = Math.random() * Math.PI * 2;
      const cx = THREE.MathUtils.clamp(
        (chosen ? chosen.x : 140) + Math.cos(jitterA) * jitterR,
        bounds.minX + 12,
        bounds.maxX - 12,
      );
      const cz = THREE.MathUtils.clamp(
        (chosen ? chosen.z : 190) + Math.sin(jitterA) * jitterR,
        bounds.minZ + 12,
        bounds.maxZ - 12,
      );
      if (this.world.isWaterBlocked(cx, cz)) continue;
      const gy = this.world.getGroundHeight(cx, cz, 0);
      if (gy >= -0.2 && gy < 16.0) {
        spawnX = cx;
        spawnZ = cz;
        break;
      }
    }

    const pos = new THREE.Vector3(spawnX, this.world.getGroundHeight(spawnX, spawnZ, 0), spawnZ);
    this.resolveCircleWorldCollision(pos, 0.72, false);
    pos.y = this.world.getGroundHeight(pos.x, pos.z, pos.y);
    const resolvedAreaBn = chosen?.areaBn || this.world.getLocationName(pos.x, pos.z, pos.y) || 'শালবন';

    const rig = buildAnimalRig(species, false);
    rig.root.position.copy(pos);
    // Keep HP bar & heart aura HIDDEN at a glance so players must explore and spot animals naturally!
    rig.hpBarBg.visible = false;
    rig.hpBarFill.scale.x = 1;

    // Assign wild animal level & enforce scarce Special Heart-Bearer subset:
    // ONLY selected tougher animals carry Animal Hearts, and higher tiers (Rare/Epic/Legendary) are truly scarce!
    const progBias = Math.min(
      0.32,
      ((this.permanentPet ? this.permanentPet.upgrades.level : 1) + this.playerProgression.level - 2) *
        0.015,
    );
    const activeHeartBearers = this.wildAnimals.filter(
      (w) => w.state !== 'dead' && w.isHeartBearer,
    ).length;
    const maxHeartBearers = this.gameMode === 'pet_taming' ? 3 : 1;
    const minHeartBearers = this.gameMode === 'pet_taming' ? 1 : 0;

    let isHeartBearer = false;
    if (meta.canCarryAnimalHeart && activeHeartBearers < maxHeartBearers) {
      if (activeHeartBearers < minHeartBearers && Math.random() < 0.58) {
        isHeartBearer = true;
      } else if (this.heartBearerStreak >= 1) {
        isHeartBearer = false;
      } else {
        isHeartBearer = Math.random() < 0.22;
      }
    }
    this.heartBearerStreak = isHeartBearer
      ? Math.max(1, this.heartBearerStreak + 1)
      : Math.min(-1, this.heartBearerStreak - 1);

    const heartTier: AnimalHeartTier | null = isHeartBearer
      ? clampAnimalHeartTier(
          rollAnimalHeartDropTier(0.05 + meta.heartLuckBonus * 0.6 + progBias, species),
        )
      : null;
    const animalLevel = heartTier ?? (Math.random() < 0.25 ? 2 : 1);
    const heartMeta = heartTier ? ANIMAL_HEART_TIERS[heartTier] : null;
    const heartValue = heartMeta ? heartMeta.value : 0;

    if (isHeartBearer && heartMeta && heartTier) {
      (rig.heartAuraRing.material as THREE.MeshBasicMaterial).color.setHex(heartMeta.colorHex);
      // Distinct physical presence & glowing eyes for higher-tier Heart-Bearers (Rare / Epic / Legendary)
      const tierScale =
        heartTier === 4 ? 1.26 : heartTier === 3 ? 1.18 : heartTier === 2 ? 1.1 : 1.04;
      rig.root.scale.setScalar(tierScale);
      if (heartTier >= 2) {
        const eyeGlowIntensity = heartTier === 4 ? 2.4 : heartTier === 3 ? 1.85 : 1.35;
        for (const em of rig.eyeMaterials) {
          em.color.setHex(heartMeta.ringHex);
          em.emissive.setHex(heartMeta.colorHex);
          em.emissiveIntensity = eyeGlowIntensity;
        }
      }
    }
    rig.heartAuraRing.visible = false;

    const eliteHpBoost =
      isHeartBearer && heartTier
        ? heartTier === 4
          ? 0.54
          : heartTier === 3
            ? 0.36
            : heartTier === 2
              ? 0.22
              : 0.12
        : 0;
    const eliteDmgBoost =
      isHeartBearer && heartTier
        ? heartTier === 4
          ? 0.34
          : heartTier === 3
            ? 0.22
            : heartTier === 2
              ? 0.14
              : 0.08
        : 0;
    const lvScaleHp = 1 + (animalLevel - 1) * 0.16 + eliteHpBoost;
    const lvScaleDmg = 1 + (animalLevel - 1) * 0.14 + eliteDmgBoost;
    const scaledMaxHp = Math.round(meta.maxHp * lvScaleHp);
    const scaledAttackDmg = Math.round(meta.attackDamage * lvScaleDmg);

    this.scene.add(rig.root);

    const roamRadius =
      resolvedAreaBn === 'পাথুরে গুহা'
        ? 5.2
        : resolvedAreaBn === 'প্রাচীন ধ্বংসাবশেষ'
          ? 7.8
          : resolvedAreaBn === 'জলাভূমি ও বিল'
            ? 8.8
            : resolvedAreaBn === 'উন্মুক্ত তৃণভূমি' || resolvedAreaBn === 'পাথুরে পাহাড়'
              ? 11.2
              : 9.5;
    const initAngle = Math.random() * Math.PI * 2;
    const initYaw = Math.random() * Math.PI * 2;
    rig.root.rotation.set(0, initYaw, 0);

    this.wildAnimals.push({
      id: this.nextWildAnimalId++,
      species,
      rig,
      level: animalLevel,
      attackDamage: scaledAttackDmg,
      isHeartBearer,
      heartTier,
      heartValue,
      hp: scaledMaxHp,
      maxHp: scaledMaxHp,
      subdueRatio: meta.subdueRatio,
      radius: 0.68 * meta.bodyScale * (isHeartBearer && heartTier && heartTier >= 3 ? 1.12 : 1.0),
      pos,
      velX: 0,
      velZ: 0,
      yaw: initYaw,
      walkPhase: Math.random() * Math.PI * 2,
      moveBlend: 0,
      state: Math.random() < 0.45 ? 'rest' : 'roam',
      stateTimer: 2.2 + Math.random() * 4.0,
      attackCooldown: 1.2,
      subduedRecoveryTimer: 0,
      hitFlashTimer: 0,
      flinchTimer: 0,
      deathTimer: 0,
      subduedAnnounced: false,
      fleeAnnounced: false,
      fleeWeaveSign: Math.random() < 0.5 ? -1 : 1,
      evadeTimer: 0,
      evadeDir: Math.random() < 0.5 ? -1 : 1,
      evadeCooldown: 0.8,
      bulletDodgeCooldown: 0.6,
      bulletDodgeWindow: 0,
      dodgeVelX: 0,
      dodgeVelZ: 0,
      homeX: pos.x,
      homeZ: pos.z,
      roamTargetX: pos.x + Math.cos(initAngle) * (roamRadius * 0.65),
      roamTargetZ: pos.z + Math.sin(initAngle) * (roamRadius * 0.65),
      roamRadius,
      discovered: false,
      provoked: false,
      aggroTimer: 0,
      lastDamagedTimer: 0,
      cueTimer: 2.5 + Math.random() * 4.5,
      emberTimer: 0.5 + Math.random() * 0.6,
      lungeBurstTimer: 0,
      lungeBurstCooldown: 3.2,
      areaBn: resolvedAreaBn,
    });
  }

  private spawnAnimalHeartDrop(origin: THREE.Vector3, tier: AnimalHeartTier): void {
    const meta = ANIMAL_HEART_TIERS[tier];
    const mesh = buildAnimalHeartPickupMesh(tier);
    const groundY = this.world.getGroundHeight(origin.x, origin.z, origin.y);
    const pos = new THREE.Vector3(origin.x, groundY, origin.z);
    mesh.position.copy(pos);
    this.scene.add(mesh);

    this.animalHeartDrops.push({
      id: this.nextHeartDropId++,
      tier,
      value: meta.value,
      mesh,
      pos,
      life: 120,
    });
  }

  private updateAnimalHeartDrops(dt: number): void {
    if (this.animalHeartDrops.length === 0) return;
    const collectorPos = this.busMode === 'driving' ? this.busPos : this.heroPos;
    const collectRadius =
      this.busMode === 'driving' ? 4.2 : this.activeTwoWheeler !== null ? 3.25 : 2.65;

    for (let i = this.animalHeartDrops.length - 1; i >= 0; i--) {
      const drop = this.animalHeartDrops[i];
      drop.life -= dt;
      if (drop.life <= 0) {
        this.scene.remove(drop.mesh);
        this.animalHeartDrops.splice(i, 1);
        continue;
      }

      // Gentle levitation bob + spin on the sculpted 3D heart & tilted halo ring
      const heartChild = drop.mesh.children[0];
      const haloChild = drop.mesh.children[1];
      const bob = Math.sin(this.worldTime * 3.4 + drop.id * 1.3) * 0.14;
      if (heartChild) {
        heartChild.position.y = 0.76 + bob;
        heartChild.rotation.y += dt * 1.9;
      }
      if (haloChild) {
        haloChild.position.y = 0.76 + bob;
        haloChild.rotation.z += dt * 2.4;
      }

      const dist = Math.hypot(collectorPos.x - drop.pos.x, collectorPos.z - drop.pos.z);
      if (dist <= collectRadius) {
        const { wallet, tierMeta } = addAnimalHeartForId(this.playerId, drop.tier);
        this.animalHearts = wallet;
        this.audio.playTameSuccess();
        this.spawnParticles(
          _v1.set(drop.pos.x, drop.pos.y + 0.85, drop.pos.z),
          tierMeta.colorHex,
          16,
          5.2,
        );
        this.spawnParticles(
          _v1.set(drop.pos.x, drop.pos.y + 0.95, drop.pos.z),
          0xffd966,
          10,
          4.4,
        );
        this.pickupToast = `+${toBengaliNumber(tierMeta.value)} ${tierMeta.nameBn} সংগ্রহ! (মোট হার্ট: ${toBengaliNumber(wallet.totalValue)} · লবিতে লেভেল আপ করুন)`;
        this.pickupToastTimer = 3.8;
        this.scene.remove(drop.mesh);
        this.animalHeartDrops.splice(i, 1);
        this.emitHud();
      }
    }
  }

  /**
   * Balanced occasional bullet-evasion check for wild animals.
   * Agile species sidestep slightly more often than heavy brutes, always gated by a fair cooldown.
   */
  private tryWildAnimalBulletDodge(wa: ActiveWildAnimal, bulletVel: THREE.Vector3): boolean {
    if (wa.state === 'dead' || wa.state === 'subdued') return false;

    // Brief invulnerability frames during an already-triggered agile sidestep (lets multi-pellet bursts whiz past)
    if (wa.bulletDodgeWindow > 0) return true;
    if (wa.bulletDodgeCooldown > 0) return false;

    const distHero = Math.hypot(this.heroPos.x - wa.pos.x, this.heroPos.z - wa.pos.z);
    if (distHero < 3.4) return false; // Point-blank shots always connect reliably

    const meta = WILD_ANIMAL_CATALOG[wa.species];
    const eliteBonus = wa.isHeartBearer && wa.heartTier && wa.heartTier >= 3 ? 0.04 : 0;
    const dodgeProb = Math.min(0.38, meta.dodgeChance + eliteBonus);
    if (Math.random() >= dodgeProb) return false;

    wa.bulletDodgeWindow = 0.22;
    wa.bulletDodgeCooldown = meta.dodgeCooldown;
    wa.discovered = true;
    wa.provoked = true;
    wa.aggroTimer = Math.max(wa.aggroTimer, 16.0);
    wa.lastDamagedTimer = Math.max(wa.lastDamagedTimer, 10.0);
    if (wa.state === 'roam' || wa.state === 'rest') {
      wa.state = 'provoked';
    }

    // Compute clean lateral sidestep perpendicular to bullet trajectory
    const bLen = Math.hypot(bulletVel.x, bulletVel.z);
    const bx = bLen > 0.001 ? bulletVel.x / bLen : 0;
    const bz = bLen > 0.001 ? bulletVel.z / bLen : 1;
    let side = Math.random() < 0.5 ? -1 : 1;
    let perpX = -bz * side;
    let perpZ = bx * side;
    if (this.world.isWaterBlocked(wa.pos.x + perpX * 2.2, wa.pos.z + perpZ * 2.2)) {
      side = -side;
      perpX = -bz * side;
      perpZ = bx * side;
    }

    // Kick up dust at original spot, apply instant short hop + smooth lateral velocity burst
    this.spawnParticles(
      _v1.set(wa.pos.x, wa.pos.y + 0.35, wa.pos.z),
      0xc7b698,
      5,
      3.6,
    );
    const bounds = this.world.playableBounds;
    wa.pos.x = THREE.MathUtils.clamp(wa.pos.x + perpX * 0.46, bounds.minX + 4, bounds.maxX - 4);
    wa.pos.z = THREE.MathUtils.clamp(wa.pos.z + perpZ * 0.46, bounds.minZ + 4, bounds.maxZ - 4);
    this.resolveCircleWorldCollision(wa.pos, wa.radius, false);
    wa.pos.y = this.world.getGroundHeight(wa.pos.x, wa.pos.z, wa.pos.y);

    const dashSpeed = meta.lungeSpeed * 0.72;
    wa.dodgeVelX = perpX * dashSpeed;
    wa.dodgeVelZ = perpZ * dashSpeed;
    wa.evadeDir = side;
    wa.rig.hpBarBg.visible = true;
    if (wa.isHeartBearer) {
      wa.rig.heartAuraRing.visible = true;
    }
    this.audio.playAnimalDodge();
    return true;
  }

  private damageWildAnimal(
    wa: ActiveWildAnimal,
    baseDmg: number,
    impulseDir: THREE.Vector3,
    hitPoint?: THREE.Vector3,
  ): void {
    if (wa.state === 'dead') return;
    const finalDmg = Math.max(1, Math.round(baseDmg));
    const wasProvoked = wa.provoked;
    wa.hp = Math.max(0, wa.hp - finalDmg);
    wa.discovered = true;
    wa.provoked = true;
    wa.aggroTimer = 18.0;
    wa.lastDamagedTimer = 14.0;
    wa.hitFlashTimer = 0.11;
    wa.flinchTimer = 0.22;
    wa.rig.flashMaterials.forEach((m) => m.emissive.setHex(0xffffff));

    const meta = WILD_ANIMAL_CATALOG[wa.species];
    const dmgOrigin = hitPoint
      ? hitPoint.clone()
      : new THREE.Vector3(wa.pos.x, wa.pos.y + 1.05 * meta.bodyScale, wa.pos.z);
    this.spawnFloatingDamage(dmgOrigin, finalDmg, false);
    this.spawnImpactFlash(dmgOrigin, 0xffd27a, 1.35, 0.14);
    this.spawnParticles(dmgOrigin, 0xff9244, 7, 5.0);

    if (impulseDir.lengthSq() > 0.0001) {
      _v1.copy(impulseDir).setY(0).normalize().multiplyScalar(1.8);
      wa.velX += _v1.x;
      wa.velZ += _v1.z;
    }

    wa.rig.hpBarBg.visible = true;
    if (wa.isHeartBearer) {
      wa.rig.heartAuraRing.visible = true;
    }
    const ratio = Math.max(0, wa.hp / wa.maxHp);
    wa.rig.hpBarFill.scale.x = Math.max(0.001, ratio);

    this.hitMarker = 0.78;
    this.hitMarkerKill = wa.hp <= 0;
    this.hitMarkerHeadshot = false;
    this.camShake = Math.min(0.24, this.camShake + 0.028);

    // CRITICAL: If animal HP reaches 0 and dies, taming FAILS — NEVER turn a dead animal into a pet!
    // Designated heart-bearer animals drop a 4-tier Animal Heart on defeat (no XP, no mid-match level-up).
    if (wa.hp <= 0) {
      wa.state = 'dead';
      wa.provoked = false;
      wa.aggroTimer = 0;
      wa.deathTimer = 0;
      wa.rig.hpBarBg.visible = false;
      wa.rig.subduedRing.visible = false;
      wa.rig.tameRing.visible = false;
      wa.rig.heartAuraRing.visible = false;
      if (this.tamingActive && this.tamingTargetId === wa.id) {
        this.cancelTaming('প্রাণীটি মারা গেছে — বশ করা ব্যর্থ!', false);
      }

      if (wa.isHeartBearer && wa.heartTier !== null) {
        const heartMeta = ANIMAL_HEART_TIERS[wa.heartTier];
        this.spawnAnimalHeartDrop(wa.pos, wa.heartTier);
        this.audio.playAnimalSubdued();
        this.spawnParticles(dmgOrigin, heartMeta.colorHex, 18, 6.0);
        if (this.gameMode === 'pet_taming' && this.permanentPet === null) {
          this.pickupToast = `বশ ব্যর্থ, তবে ${heartMeta.nameBn} (+${toBengaliNumber(heartMeta.value)}) ড্রপ হয়েছে! কাছে গিয়ে সংগ্রহ করুন`;
          this.waveBanner = `${heartMeta.nameBn} ড্রপ (+${toBengaliNumber(heartMeta.value)})!`;
        } else {
          this.pickupToast = `${heartMeta.nameBn} (+${toBengaliNumber(heartMeta.value)}) ড্রপ হয়েছে! কাছে গিয়ে সংগ্রহ করুন`;
          this.waveBanner = `${heartMeta.nameBn} (+${toBengaliNumber(heartMeta.value)})!`;
        }
        this.pickupToastTimer = 4.0;
        this.waveBannerTimer = 2.8;
      } else {
        this.audio.playTameFail();
        this.spawnParticles(dmgOrigin, 0xd86b42, 14, 5.6);
        if (this.gameMode === 'pet_taming' && this.permanentPet === null) {
          this.pickupToast = `${meta.nameBn} মারা গেছে (হার্ট নেই)! অন্য প্রাণী বা বিশেষ হৃদয়ধারী প্রাণী খুঁজুন`;
        } else {
          this.pickupToast = `${meta.nameBn} সাধারণ প্রাণী — এনিমেল হার্ট নেই! বিশেষ হৃদয়ধারী প্রাণী খুঁজুন`;
        }
        this.pickupToastTimer = 3.2;
      }

      this.wildAnimalRespawnTimer = Math.min(this.wildAnimalRespawnTimer, 12.0);
      this.emitHud();
      return;
    }

    // Subdue threshold (Pet Taming Mode when player doesn't have a permanent pet yet: 0 < hp <= maxHp * 0.22)
    const canSubdueForTaming =
      this.gameMode === 'pet_taming' &&
      this.permanentPet === null &&
      wa.hp <= wa.maxHp * wa.subdueRatio;
    const fleeRatio =
      this.gameMode === 'pet_taming' && this.permanentPet === null
        ? Math.max(0.32, meta.fleeHpRatio)
        : meta.fleeHpRatio;

    if (canSubdueForTaming) {
      (wa.rig.hpBarFill.material as THREE.MeshBasicMaterial).color.setHex(0xffd24c);
      if (wa.state !== 'subdued') {
        wa.state = 'subdued';
        wa.subduedRecoveryTimer = 12.5;
        wa.attackCooldown = 1.25;
        wa.evadeTimer = 0.45;
        wa.evadeDir = Math.random() < 0.5 ? -1 : 1;
        wa.stateTimer = 0;
        if (!wa.subduedAnnounced) {
          wa.subduedAnnounced = true;
          this.audio.playAnimalSubdued();
          this.pickupToast = `${meta.nameBn} দুর্বল (<২২%)! দ্রুত সোনালি বলয়ে গিয়ে বশ করুন [T]`;
          this.pickupToastTimer = 3.4;
          this.waveBanner = `${meta.nameBn} দুর্বল! সোনালি বলয়ে গিয়ে বশ করুন`;
          this.waveBannerTimer = 2.8;
          this.emitHud();
        }
      } else {
        this.audio.playAnimalGrowl(true);
        const distHero = Math.hypot(this.heroPos.x - wa.pos.x, this.heroPos.z - wa.pos.z);
        if (distHero < 3.1 && wa.attackCooldown <= 0.3) {
          wa.attackCooldown = 1.5;
          this.damagePlayer(Math.max(10, Math.round(wa.attackDamage * 0.7)), false, wa.pos.x, wa.pos.z);
        }
        this.pickupToast = 'সতর্কতা! আর গুলি করলে প্রাণীটি মারা যাবে — সোনালি বলয়ে গিয়ে বশ করুন!';
        this.pickupToastTimer = 2.2;
      }
    } else if (wa.hp <= wa.maxHp * fleeRatio) {
      // Low-HP Wounded Retreat: injured animals attempt to flee/retreat instead of fighting blindly to the death!
      this.audio.playEnemyHit(false);
      (wa.rig.hpBarFill.material as THREE.MeshBasicMaterial).color.setHex(0xff8c2b);
      if (wa.state !== 'flee') {
        wa.state = 'flee';
        wa.aggroTimer = 22.0;
        wa.lungeBurstTimer = 0;
        wa.fleeWeaveSign = Math.random() < 0.5 ? -1 : 1;
        if (!wa.fleeAnnounced) {
          wa.fleeAnnounced = true;
          this.audio.playAnimalGrowl(false);
          this.pickupToast = `${meta.nameBn} আহত হয়ে পালাচ্ছে! ধাওয়া করে ধরুন`;
          this.pickupToastTimer = 2.8;
          this.emitHud();
        }
      }
    } else {
      // Provoked combat retaliation: ONLY when the player shoots/attacks/hits the animal does it roar and fight back!
      this.audio.playEnemyHit(false);
      if (wa.state !== 'provoked' || !wasProvoked) {
        wa.state = 'provoked';
        wa.attackCooldown = Math.min(wa.attackCooldown, 0.45);
        if (wa.isHeartBearer && wa.heartTier && wa.heartTier >= 2) {
          const tierMeta = ANIMAL_HEART_TIERS[wa.heartTier];
          this.audio.playEliteTierRoar(wa.heartTier);
          this.camShake = Math.min(0.28, this.camShake + (wa.heartTier === 4 ? 0.14 : 0.08));
          this.spawnParticles(
            _v1.set(wa.pos.x, wa.pos.y + 1.0, wa.pos.z),
            tierMeta.colorHex,
            wa.heartTier === 4 ? 14 : 9,
            5.8,
          );
        } else {
          this.audio.playAnimalGrowl(true);
        }
      }
      if (wa.evadeCooldown <= 0) {
        wa.evadeTimer = 0.42;
        wa.evadeCooldown = wa.isHeartBearer && wa.heartTier && wa.heartTier >= 3 ? 1.55 : 2.1;
        wa.evadeDir = Math.random() < 0.5 ? -wa.evadeDir : wa.evadeDir;
      }
    }
  }

  private updateWildAnimal(dt: number): void {
    if (this.busMode === 'riding_intro' || this.heroJumpingFromBus) {
      return;
    }

    const maxAnimals = this.gameMode === 'pet_taming' ? 14 : 6;
    let aliveCount = 0;
    for (const w of this.wildAnimals) {
      if (w.state !== 'dead') aliveCount++;
    }
    if (aliveCount < maxAnimals) {
      this.wildAnimalRespawnTimer -= dt;
      if (this.wildAnimalRespawnTimer <= 0) {
        this.spawnWildAnimal();
        this.wildAnimalRespawnTimer = 14.0;
      }
    }

    this.wildernessCueGlobalCooldown = Math.max(0, this.wildernessCueGlobalCooldown - dt);
    this.rareWhisperCooldown = Math.max(0, this.rareWhisperCooldown - dt);

    const refPos = this.busMode === 'driving' ? this.busPos : this.heroPos;
    const bounds = this.world.playableBounds;

    for (let i = this.wildAnimals.length - 1; i >= 0; i--) {
      const wa = this.wildAnimals[i];
      const meta = WILD_ANIMAL_CATALOG[wa.species];

      if (wa.hitFlashTimer > 0) {
        wa.hitFlashTimer -= dt;
        if (wa.hitFlashTimer <= 0) {
          wa.rig.flashMaterials.forEach((m, idx) => m.emissive.copy(wa.rig.baseEmissives[idx]));
        }
      }
      if (wa.flinchTimer > 0) {
        wa.flinchTimer = Math.max(0, wa.flinchTimer - dt);
      }
      if (wa.lastDamagedTimer > 0) {
        wa.lastDamagedTimer = Math.max(0, wa.lastDamagedTimer - dt);
      }

      // Dead state: collapse onto side and fade out; NEVER converts to a pet
      if (wa.state === 'dead') {
        wa.deathTimer += dt;
        const fallT = Math.min(1, wa.deathTimer / 0.55);
        wa.rig.bodyGroup.rotation.z = fallT * (Math.PI * 0.48);
        wa.rig.bodyGroup.position.y = THREE.MathUtils.lerp(
          0.52 * meta.bodyScale,
          0.18 * meta.bodyScale,
          fallT,
        );
        if (wa.deathTimer > 3.2) {
          wa.rig.root.position.y -= dt * 0.85;
        }
        if (wa.deathTimer > 4.4) {
          this.scene.remove(wa.rig.root);
          this.wildAnimals.splice(i, 1);
        }
        continue;
      }

      const dxHero = refPos.x - wa.pos.x;
      const dzHero = refPos.z - wa.pos.z;
      const distHero = Math.hypot(dxHero, dzHero);

      // Mobile performance optimization: distant unprovoked wild animals idle peacefully in their spots with zero per-frame rig work
      if (distHero > 74 && !wa.provoked && wa.lastDamagedTimer <= 0) {
        wa.rig.hpBarBg.visible = false;
        wa.rig.heartAuraRing.visible = false;
        continue;
      }

      // Subtle wilderness audio & environmental cues when exploring near hidden roaming animals (13m..42m)
      if (!wa.provoked && wa.state !== 'subdued' && distHero > 12.5 && distHero <= 42.0) {
        wa.cueTimer -= dt;
        if (wa.cueTimer <= 0) {
          wa.cueTimer = 4.6 + Math.random() * 3.8;
          const inCave = wa.areaBn === 'পাথুরে গুহা';
          if (this.wildernessCueGlobalCooldown <= 0) {
            const proximity = THREE.MathUtils.clamp(1 - (distHero - 12.5) / 31.0, 0.16, 1.0);
            this.audio.playWildernessCue(wa.species, proximity, inCave);
            this.wildernessCueGlobalCooldown = 3.8;
          }
          // Subtle biome-matched movement trace (leaf rustle, swamp droplet, meadow grass dust)
          if (distHero <= 34.0) {
            const traceColor =
              wa.areaBn === 'জলাভূমি ও বিল'
                ? 0x4f8c7a
                : wa.areaBn === 'উন্মুক্ত তৃণভূমি'
                  ? 0xcbd068
                  : wa.areaBn === 'পাথুরে গুহা' || wa.areaBn === 'প্রাচীন ধ্বংসাবশেষ'
                    ? 0x8e8376
                    : 0x5f853c;
            this.spawnParticles(
              _v1.set(wa.pos.x, wa.pos.y + 0.35, wa.pos.z),
              traceColor,
              2,
              1.6,
            );
          }
          // Rare sensory whisper when first drawing near an undiscovered Rare/Epic/Legendary Heart-Bearer
          if (
            !wa.discovered &&
            wa.isHeartBearer &&
            wa.heartTier &&
            wa.heartTier >= 2 &&
            distHero <= 34.0 &&
            this.rareWhisperCooldown <= 0 &&
            this.pickupToastTimer <= 0
          ) {
            this.rareWhisperCooldown = 24.0;
            this.pickupToast = inCave
              ? 'গুহার ভেতর থেকে গভীর গর্জন শোনা যাচ্ছে...'
              : 'কাছেই পাতার খসখস ও ভারী পায়ের আওয়াজ শোনা যাচ্ছে...';
            this.pickupToastTimer = 2.6;
          }
        }
      }

      // Hard-to-spot discovery rule: only reveal HP bar & subtle aura when player explores close (<= 18m) or provokes/hits the animal
      if (!wa.discovered && distHero <= 18.0) {
        wa.discovered = true;
      }
      const showDetails =
        (wa.discovered && distHero <= 24.0) ||
        wa.provoked ||
        wa.state === 'flee' ||
        wa.lastDamagedTimer > 0 ||
        wa.state === 'subdued';
      wa.rig.hpBarBg.visible = showDetails;
      wa.rig.heartAuraRing.visible = wa.isHeartBearer && showDetails;

      // Distinct visual energy embers around discovered/provoked Rare, Epic & Legendary Heart-Bearers
      if (wa.isHeartBearer && wa.heartTier && wa.heartTier >= 2 && showDetails && distHero <= 34.0) {
        wa.emberTimer -= dt;
        if (wa.emberTimer <= 0) {
          const tierMeta = ANIMAL_HEART_TIERS[wa.heartTier];
          wa.emberTimer = wa.heartTier === 4 ? 0.38 : wa.heartTier === 3 ? 0.56 : 0.78;
          this.spawnParticles(
            _v1.set(
              wa.pos.x + (Math.random() - 0.5) * 1.1,
              wa.pos.y + 0.5 + Math.random() * 0.7,
              wa.pos.z + (Math.random() - 0.5) * 1.1,
            ),
            tierMeta.colorHex,
            wa.heartTier === 4 ? 3 : 2,
            wa.heartTier === 4 ? 2.6 : 1.9,
          );
        }
      }

      if (wa.rig.hpBarBg.visible) {
        wa.rig.hpBarBg.lookAt(this.camera.position);
      }

      const dirToHeroX = distHero > 0.001 ? dxHero / distHero : 0;
      const dirToHeroZ = distHero > 0.001 ? dzHero / distHero : 1;

      // Active tense taming channel logic for this specific target animal
      const isBeingTamed = this.tamingActive && this.tamingTargetId === wa.id;
      if (isBeingTamed) {
        if (wa.state !== 'subdued' || wa.hp <= 0) {
          this.cancelTaming('প্রাণীটি আর বশযোগ্য অবস্থায় নেই!');
        } else {
          const movedDist = Math.hypot(
            this.heroPos.x - this.tamingStartHeroPos.x,
            this.heroPos.z - this.tamingStartHeroPos.z,
          );
          if (
            movedDist > 0.72 ||
            this.heroJumpOffset > 0.15 ||
            distHero > TAME_GOLDEN_RING_RADIUS + 0.35
          ) {
            this.cancelTaming('নড়াচড়া করায় বশ করার চেষ্টা ব্যাহত!');
          } else {
            wa.subduedRecoveryTimer = Math.max(wa.subduedRecoveryTimer, 5.0);
            this.tamingProgress = Math.min(1, this.tamingProgress + dt / this.tamingDuration);
            this.tamingTickAccum += dt;
            if (this.tamingTickAccum >= 0.42) {
              this.tamingTickAccum = 0;
              this.audio.playTameTick(this.tamingProgress);
            }

            if (this.tamingResistStage === 0 && this.tamingProgress >= 0.38) {
              this.tamingResistStage = 1;
              wa.flinchTimer = 0.28;
              this.camShake = Math.min(0.2, this.camShake + 0.045);
              this.audio.playAnimalGrowl(true);
              this.tamingStatusText = 'প্রাণীটি ছটফট করছে — এক চুলও নড়বেন না!';
              this.tamingStatusTimer = 2.2;
            } else if (this.tamingResistStage === 1 && this.tamingProgress >= 0.74) {
              this.tamingResistStage = 2;
              wa.flinchTimer = 0.32;
              this.camShake = Math.min(0.24, this.camShake + 0.06);
              this.audio.playAnimalGrowl(true);
              this.tamingStatusText = 'শেষ প্রতিরোধ! স্থির থাকুন, আর একটু বাকি...';
              this.tamingStatusTimer = 2.2;
            }

            const desiredYaw = Math.atan2(dxHero, dzHero);
            let diff = desiredYaw - wa.yaw;
            while (diff > Math.PI) diff -= Math.PI * 2;
            while (diff < -Math.PI) diff += Math.PI * 2;
            wa.yaw += diff * Math.min(1, dt * 6);

            if (this.tamingProgress >= 1) {
              this.tamingActive = false;
              this.tamingTargetId = null;
              this.tamingProgress = 0;
              this.tamingResistStage = 0;
              const saved = savePermanentPetForId(this.playerId, wa.species);
              if (saved) {
                this.permanentPet = saved;
                const tamePos = wa.pos.clone();
                this.scene.remove(wa.rig.root);
                this.wildAnimals.splice(i, 1);

                this.spawnPermanentPetCompanion(saved, tamePos);
                this.audio.playTameSuccess();
                this.spawnParticles(_v1.set(tamePos.x, tamePos.y + 0.9, tamePos.z), 0x4df5b8, 22, 6.4);
                this.spawnParticles(_v1.set(tamePos.x, tamePos.y + 1.1, tamePos.z), 0xffd24c, 16, 5.2);
                this.tamingStatusText = `সফল! ${saved.nameBn} আপনার আজীবনের স্থায়ী সঙ্গী!`;
                this.tamingStatusTimer = 3.5;
                this.pickupToast = `স্থায়ী সঙ্গী বশ হয়েছে: ${saved.nameBn}!`;
                this.pickupToastTimer = 3.8;
                this.waveBanner = `স্থায়ী সঙ্গী: ${saved.nameBn}`;
                this.waveBannerTimer = 3.6;
                this.emitHud();
                continue;
              } else {
                this.cancelTaming('এই আইডি-তে ইতিমধ্যেই স্থায়ী সঙ্গী আছে!');
              }
            }
          }
        }
      }

      // PROVOKED-ONLY COMBAT, WOUNDED FLEE & PEACEFUL TERRITORY AI:
      // Unprovoked animals NEVER chase or attack the player from afar — they peacefully roam & rest inside their spots.
      // When the player attacks/shoots an animal, it fights back ('provoked'); when HP drops low it retreats ('flee').
      wa.attackCooldown = Math.max(0, wa.attackCooldown - dt);
      wa.evadeTimer = Math.max(0, wa.evadeTimer - dt);
      wa.evadeCooldown = Math.max(0, wa.evadeCooldown - dt);
      wa.bulletDodgeCooldown = Math.max(0, wa.bulletDodgeCooldown - dt);
      wa.bulletDodgeWindow = Math.max(0, wa.bulletDodgeWindow - dt);
      wa.dodgeVelX = THREE.MathUtils.damp(wa.dodgeVelX, 0, 12, dt);
      wa.dodgeVelZ = THREE.MathUtils.damp(wa.dodgeVelZ, 0, 12, dt);
      wa.lungeBurstTimer = Math.max(0, wa.lungeBurstTimer - dt);
      wa.lungeBurstCooldown = Math.max(0, wa.lungeBurstCooldown - dt);
      let targetVx = 0;
      let targetVz = 0;

      const fromHomeX = wa.pos.x - wa.homeX;
      const fromHomeZ = wa.pos.z - wa.homeZ;
      const distHome = Math.hypot(fromHomeX, fromHomeZ);

      if (wa.state === 'subdued') {
        if (!isBeingTamed) {
          wa.subduedRecoveryTimer -= dt;
          if (wa.subduedRecoveryTimer <= 0) {
            wa.hp = Math.min(wa.maxHp, Math.round(wa.hp + wa.maxHp * 0.28));
            (wa.rig.hpBarFill.material as THREE.MeshBasicMaterial).color.setHex(0xe84a36);
            wa.rig.hpBarFill.scale.x = Math.max(0.001, wa.hp / wa.maxHp);
            wa.subduedAnnounced = false;
            wa.fleeAnnounced = false;
            if (wa.provoked && distHero <= 34.0) {
              wa.state = 'provoked';
              wa.aggroTimer = 14.0;
            } else {
              wa.provoked = false;
              wa.aggroTimer = 0;
              wa.state = 'roam';
            }
            this.audio.playAnimalGrowl(false);
          } else if (this.busMode === 'none' && distHero < 2.25 && wa.attackCooldown <= 0) {
            // Defensive swipe only if player crowds recklessly without starting Tame
            wa.attackCooldown = 1.6;
            wa.flinchTimer = 0.2;
            this.audio.playAnimalGrowl(true);
            this.damagePlayer(Math.max(10, Math.round(wa.attackDamage * 0.7)), false, wa.pos.x, wa.pos.z);
          } else if (distHero < 6.0) {
            // Cautious defensive sidestep while subdued
            const tangentX = -dirToHeroZ * wa.evadeDir;
            const tangentZ = dirToHeroX * wa.evadeDir;
            targetVx = tangentX * 1.45;
            targetVz = tangentZ * 1.45;
          }
        }
      } else if (wa.state === 'flee') {
        // Wounded low-HP retreat: sprint away from the player with light terrain/shore steering (lag-free on mobile)
        wa.aggroTimer -= dt;
        const eliteTier = wa.isHeartBearer && wa.heartTier ? wa.heartTier : 0;
        if (distHero > 56.0 && wa.lastDamagedTimer <= 0) {
          // Escaped successfully — settle into a new spot peacefully
          wa.provoked = false;
          wa.aggroTimer = 0;
          wa.state = 'roam';
          wa.homeX = wa.pos.x;
          wa.homeZ = wa.pos.z;
          wa.roamTargetX = wa.pos.x;
          wa.roamTargetZ = wa.pos.z;
          wa.stateTimer = 3.5;
          wa.fleeAnnounced = false;
        } else {
          const weave = Math.sin(this.worldTime * 2.3 + wa.id * 1.7) * 0.26 * wa.fleeWeaveSign;
          const awayX = -dirToHeroX;
          const awayZ = -dirToHeroZ;
          let fleeDirX = awayX * Math.cos(weave) - awayZ * Math.sin(weave);
          let fleeDirZ = awayX * Math.sin(weave) + awayZ * Math.cos(weave);

          // Single lightweight 1-step boundary & water probe so retreating beasts glide around rivers & edges
          const probeX = wa.pos.x + fleeDirX * 5.2;
          const probeZ = wa.pos.z + fleeDirZ * 5.2;
          const nearEdge =
            probeX < bounds.minX + 12 ||
            probeX > bounds.maxX - 12 ||
            probeZ < bounds.minZ + 12 ||
            probeZ > bounds.maxZ - 12;
          if (nearEdge || this.world.isWaterBlocked(probeX, probeZ)) {
            const turnAng = wa.fleeWeaveSign * 1.15;
            const c = Math.cos(turnAng);
            const sn = Math.sin(turnAng);
            const rx = fleeDirX * c - fleeDirZ * sn;
            const rz = fleeDirX * sn + fleeDirZ * c;
            fleeDirX = rx;
            fleeDirZ = rz;
          }

          const fleeSpeed = meta.moveSpeed * (eliteTier >= 3 ? 1.06 : 0.96);
          targetVx = fleeDirX * fleeSpeed;
          targetVz = fleeDirZ * fleeSpeed;

          // If cornered up close while retreating, snap defensively once before bolting past
          if (this.busMode === 'none' && distHero < 2.65 && wa.attackCooldown <= 0) {
            wa.attackCooldown = 1.65;
            wa.flinchTimer = 0.18;
            this.audio.playAnimalGrowl(true);
            this.damagePlayer(
              Math.max(10, Math.round(wa.attackDamage * 0.75)),
              false,
              wa.pos.x,
              wa.pos.z,
            );
          }
        }
      } else if (wa.state === 'provoked') {
        wa.aggroTimer -= dt;
        const eliteTier = wa.isHeartBearer && wa.heartTier ? wa.heartTier : 0;
        // Keep aggro active while the player remains engaged within combat range
        if (distHero <= 24.0) {
          wa.aggroTimer = Math.max(wa.aggroTimer, 6.5);
        }

        const outOfRange =
          distHero > 48.0 ||
          distHome > Math.max(wa.roamRadius + 42.0, 56.0) ||
          (wa.aggroTimer <= 0 && distHero > 24.0) ||
          (this.busMode === 'driving' && distHero > 26.0);

        if (outOfRange) {
          // Player escaped out of range: disengage calmly and return to home territory
          wa.provoked = false;
          wa.aggroTimer = 0;
          wa.lungeBurstTimer = 0;
          wa.state = 'roam';
          wa.roamTargetX = wa.homeX;
          wa.roamTargetZ = wa.homeZ;
          wa.stateTimer = 5.5;
        } else if (this.busMode === 'none' && distHero <= 3.05 && wa.attackCooldown <= 0) {
          // Provoked close-range attack/bite/strike (faster & harder for Rare / Epic / Legendary!)
          wa.attackCooldown =
            eliteTier === 4 ? 0.94 : eliteTier === 3 ? 1.06 : eliteTier === 2 ? 1.18 : 1.35;
          wa.flinchTimer = 0.22;
          if (eliteTier >= 3 && wa.heartTier) {
            const tierMeta = ANIMAL_HEART_TIERS[wa.heartTier];
            this.audio.playEliteTierRoar(wa.heartTier);
            this.camShake = Math.min(0.32, this.camShake + (eliteTier === 4 ? 0.14 : 0.08));
            this.spawnParticles(
              _v1.set(wa.pos.x + dirToHeroX * 1.1, wa.pos.y + 0.95, wa.pos.z + dirToHeroZ * 1.1),
              tierMeta.colorHex,
              eliteTier === 4 ? 10 : 6,
              5.4,
            );
          } else {
            this.audio.playAnimalGrowl(true);
          }
          this.damagePlayer(wa.attackDamage, false, wa.pos.x, wa.pos.z);
        } else {
          // Actively charge and fight back during provoked engagement
          const stopDist = this.busMode === 'driving' ? 4.4 : 2.15;
          if (distHero > stopDist) {
            // Epic & Legendary Heart-Bearers periodically unleash an intense Lunge Burst pounce!
            if (
              eliteTier >= 3 &&
              wa.heartTier &&
              wa.lungeBurstCooldown <= 0 &&
              distHero >= 4.5 &&
              distHero <= 13.5
            ) {
              wa.lungeBurstTimer = eliteTier === 4 ? 0.48 : 0.38;
              wa.lungeBurstCooldown = eliteTier === 4 ? 3.8 : 4.8;
              const tierMeta = ANIMAL_HEART_TIERS[wa.heartTier];
              this.audio.playEliteTierRoar(wa.heartTier);
              this.spawnParticles(
                _v1.set(wa.pos.x, wa.pos.y + 0.65, wa.pos.z),
                tierMeta.colorHex,
                8,
                4.8,
              );
            }

            const tierSpeedMult =
              eliteTier === 4 ? 1.24 : eliteTier === 3 ? 1.16 : eliteTier === 2 ? 1.08 : 0.94;
            const burstMult = wa.lungeBurstTimer > 0 ? 1.48 : 1.0;
            const chaseSpeed = meta.moveSpeed * tierSpeedMult * burstMult;

            if (wa.evadeTimer > 0 && wa.lungeBurstTimer <= 0 && distHero > 4.2) {
              const sideX = -dirToHeroZ * wa.evadeDir;
              const sideZ = dirToHeroX * wa.evadeDir;
              targetVx = (dirToHeroX * 0.72 + sideX * 0.58) * chaseSpeed;
              targetVz = (dirToHeroZ * 0.72 + sideZ * 0.58) * chaseSpeed;
            } else {
              targetVx = dirToHeroX * chaseSpeed;
              targetVz = dirToHeroZ * chaseSpeed;
            }
          } else if (this.busMode === 'none') {
            // Tight aggressive circling between melee cooldown swings
            const strafeX = -dirToHeroZ * wa.evadeDir;
            const strafeZ = dirToHeroX * wa.evadeDir;
            targetVx = strafeX * meta.moveSpeed * (eliteTier >= 3 ? 0.52 : 0.36);
            targetVz = strafeZ * meta.moveSpeed * (eliteTier >= 3 ? 0.52 : 0.36);
          }
        }
      } else if (wa.state === 'rest') {
        // Peaceful unprovoked resting — never attacks or chases on its own
        wa.stateTimer -= dt;
        if (wa.stateTimer <= 0) {
          wa.state = 'roam';
          wa.stateTimer = 3.2 + Math.random() * 4.2;
          const ang = Math.random() * Math.PI * 2;
          const rad = (0.35 + Math.random() * 0.65) * wa.roamRadius;
          wa.roamTargetX = wa.homeX + Math.cos(ang) * rad;
          wa.roamTargetZ = wa.homeZ + Math.sin(ang) * rad;
        }
      } else {
        // Peaceful unprovoked local roaming inside cave / forest / highland / swamp / ruins / meadow spot
        wa.stateTimer -= dt;
        const rx = wa.roamTargetX - wa.pos.x;
        const rz = wa.roamTargetZ - wa.pos.z;
        const rLen = Math.hypot(rx, rz);
        if (rLen > 0.9 && wa.stateTimer > 0) {
          targetVx = (rx / rLen) * meta.moveSpeed * 0.34;
          targetVz = (rz / rLen) * meta.moveSpeed * 0.34;
        } else {
          wa.state = 'rest';
          wa.stateTimer = 2.6 + Math.random() * 4.4;
        }
      }

      // Territory leash for unprovoked animals: smoothly guide roaming/disengaged animals back to their home area
      if (!wa.provoked && wa.state !== 'provoked' && wa.state !== 'flee') {
        const maxLeash = wa.roamRadius + 2.5;
        if (distHome > maxLeash) {
          const pullX = -fromHomeX / distHome;
          const pullZ = -fromHomeZ / distHome;
          targetVx = pullX * meta.moveSpeed * 0.56;
          targetVz = pullZ * meta.moveSpeed * 0.56;
        }
      }

      wa.velX = THREE.MathUtils.damp(wa.velX, targetVx, 8, dt);
      wa.velZ = THREE.MathUtils.damp(wa.velZ, targetVz, 8, dt);

      wa.pos.x += (wa.velX + wa.dodgeVelX) * dt;
      wa.pos.z += (wa.velZ + wa.dodgeVelZ) * dt;
      this.resolveCircleWorldCollision(wa.pos, wa.radius, false);
      wa.pos.x = THREE.MathUtils.clamp(wa.pos.x, bounds.minX + 4, bounds.maxX - 4);
      wa.pos.z = THREE.MathUtils.clamp(wa.pos.z, bounds.minZ + 4, bounds.maxZ - 4);
      wa.pos.y = this.world.getGroundHeight(wa.pos.x, wa.pos.z, wa.pos.y);

      const speed = Math.hypot(wa.velX + wa.dodgeVelX, wa.velZ + wa.dodgeVelZ);
      const desiredYaw =
        wa.state === 'flee'
          ? speed > 0.2
            ? Math.atan2(wa.velX, wa.velZ)
            : wa.yaw
          : wa.state === 'provoked' || (wa.state === 'subdued' && distHero < 8)
            ? Math.atan2(dxHero, dzHero)
            : speed > 0.25
              ? Math.atan2(wa.velX, wa.velZ)
              : wa.yaw;
      let yawDiff = desiredYaw - wa.yaw;
      while (yawDiff > Math.PI) yawDiff -= Math.PI * 2;
      while (yawDiff < -Math.PI) yawDiff += Math.PI * 2;
      wa.yaw += yawDiff * Math.min(1, dt * (wa.state === 'provoked' || wa.state === 'flee' ? 10 : 7));

      wa.moveBlend = THREE.MathUtils.damp(wa.moveBlend, Math.min(1, speed / meta.moveSpeed), 10, dt);
      wa.walkPhase += dt * (3.2 + speed * 1.4);

      wa.rig.root.position.copy(wa.pos);
      wa.rig.root.rotation.set(0, wa.yaw, 0);

      animateAnimalRig(wa.rig, wa.species, dt, this.worldTime, wa.walkPhase, wa.moveBlend, {
        isSubdued: wa.state === 'subdued',
        isLunging:
          (wa.state === 'provoked' && (wa.attackCooldown > 1.0 || distHero < 6.5)) ||
          wa.bulletDodgeWindow > 0,
        isTaming: isBeingTamed,
        isTamed: false,
        flinchPulse: wa.flinchTimer > 0 ? wa.flinchTimer / 0.22 : 0,
      });
    }
  }

  private updatePetCompanion(dt: number): void {
    const pc = this.petCompanion;
    if (!pc) return;

    // Hide pet while riding/driving the bus; deploy smoothly beside hero when on foot
    if (this.busMode !== 'none' || this.heroJumpingFromBus) {
      pc.rig.root.visible = false;
      pc.placedOnFoot = false;
      return;
    }

    const meta = WILD_ANIMAL_CATALOG[pc.record.species];
    const stats = pc.record.stats;
    pc.maxHp = stats.maxHp;
    pc.hp = Math.min(pc.maxHp, pc.hp);
    const petRadius = Math.max(0.62, 0.56 * meta.bodyScale);
    if (!pc.placedOnFoot) {
      const heroRightX = -Math.cos(this.heroYaw);
      const heroRightZ = Math.sin(this.heroYaw);
      pc.pos.set(
        this.heroPos.x - heroRightX * 2.1 - Math.sin(this.heroYaw) * 1.55,
        this.heroPos.y,
        this.heroPos.z - heroRightZ * 2.1 - Math.cos(this.heroYaw) * 1.55,
      );
      this.resolveCircleWorldCollision(pc.pos, petRadius, false);
      pc.pos.y = this.world.getGroundHeight(pc.pos.x, pc.pos.z, this.heroPos.y);
      pc.placedOnFoot = true;
      pc.rig.root.visible = true;
    }
    pc.rig.root.visible = true;

    // Smooth vitality recovery while staying near hero (higher maxHp keeps pet fighting longer)
    if (pc.assistState !== 'dash' && pc.hp < pc.maxHp) {
      pc.hp = Math.min(pc.maxHp, pc.hp + pc.maxHp * 0.08 * dt);
    }
    if (pc.retreatHealTimer > 0) {
      pc.retreatHealTimer = Math.max(0, pc.retreatHealTimer - dt);
    }

    // Safety catch-up warp if pet ever gets stranded across a bridge/ramp (> 28m away)
    const distToHero = Math.hypot(this.heroPos.x - pc.pos.x, this.heroPos.z - pc.pos.z);
    if (distToHero > 28) {
      pc.pos.set(this.heroPos.x - 2.0, this.heroPos.y, this.heroPos.z - 2.0);
      this.resolveCircleWorldCollision(pc.pos, petRadius, false);
      pc.pos.y = this.world.getGroundHeight(pc.pos.x, pc.pos.z, this.heroPos.y);
      pc.assistState = 'follow';
      pc.assistTargetId = null;
      pc.assistTargetWild = false;
      pc.assistTargetWildId = null;
    }

    pc.assistCooldown = Math.max(0, pc.assistCooldown - dt);

    let targetX = this.heroPos.x;
    let targetZ = this.heroPos.z;
    let desiredSpeed = stats.moveSpeed * 1.08;
    const dashSpeed = Math.max(meta.lungeSpeed * 0.92, stats.moveSpeed * 2.18);

    // Level-scaled combat assist: strikes nearby enemies or discovered wild animals the player engages
    if (pc.assistState === 'follow') {
      const heroRightX = -Math.cos(this.heroYaw);
      const heroRightZ = Math.sin(this.heroYaw);
      const heroFwdX = Math.sin(this.heroYaw);
      const heroFwdZ = Math.cos(this.heroYaw);
      targetX = this.heroPos.x - heroRightX * 1.95 - heroFwdX * 1.75;
      targetZ = this.heroPos.z - heroRightZ * 1.95 - heroFwdZ * 1.75;

      const canEngage =
        pc.assistCooldown <= 0 &&
        !this.tamingActive &&
        pc.retreatHealTimer <= 0 &&
        pc.hp >= pc.maxHp * 0.24 &&
        this.activeTwoWheeler === null;

      if (canEngage) {
        let bestEnemy: ActiveEnemy | null = null;
        let bestDist = 12.2 + Math.min(8, (pc.record.upgrades.level - 1) * 0.8);
        for (const e of this.enemies) {
          if (e.dying || e.busSeatIndex >= 0 || e.jumpingFromBus || e.postLandingSafeTimer > 0) continue;
          const d = Math.hypot(e.rig.root.position.x - this.heroPos.x, e.rig.root.position.z - this.heroPos.z);
          if (d < bestDist) {
            bestDist = d;
            bestEnemy = e;
          }
        }
        if (bestEnemy) {
          pc.assistState = 'dash';
          pc.assistTargetId = bestEnemy.id;
          pc.assistTargetWild = false;
          pc.assistTargetWildId = null;
          pc.assistTimer = 2.2;
          this.audio.playPetAssistBark();
        } else {
          // Only assist against wild animals that the player has already provoked/engaged
          let bestWild: ActiveWildAnimal | null = null;
          let bestWildDist = 13.5 + Math.min(8, (pc.record.upgrades.level - 1) * 0.9);
          for (const wa of this.wildAnimals) {
            if (wa.state === 'dead' || wa.hp <= 0) continue;
            if (!wa.provoked && wa.lastDamagedTimer <= 0) continue;
            const dWild = Math.hypot(wa.pos.x - this.heroPos.x, wa.pos.z - this.heroPos.z);
            if (dWild < bestWildDist) {
              bestWildDist = dWild;
              bestWild = wa;
            }
          }
          if (bestWild) {
            pc.assistState = 'dash';
            pc.assistTargetId = null;
            pc.assistTargetWild = true;
            pc.assistTargetWildId = bestWild.id;
            pc.assistTimer = 2.4;
            this.audio.playPetAssistBark();
          }
        }
      }
    } else if (pc.assistState === 'dash') {
      pc.assistTimer -= dt;
      if (pc.assistTargetWild) {
        const wa = this.wildAnimals.find((w) => w.id === pc.assistTargetWildId) ?? null;
        if (!wa || wa.state === 'dead' || wa.hp <= 0 || pc.assistTimer <= 0) {
          pc.assistState = 'return';
          pc.assistTargetWild = false;
          pc.assistTargetWildId = null;
          pc.assistCooldown = stats.assistCooldown;
        } else {
          targetX = wa.pos.x;
          targetZ = wa.pos.z;
          desiredSpeed = dashSpeed;
          const dWild = Math.hypot(targetX - pc.pos.x, targetZ - pc.pos.z);
          if (dWild <= 1.95) {
            _v4.set(targetX - pc.pos.x, 0, targetZ - pc.pos.z);
            const hitPt = _v6.set(targetX, wa.pos.y + 1.0, targetZ);
            this.damageWildAnimal(wa, stats.attackDamage, _v4, hitPt);
            pc.hp = Math.max(1, pc.hp - Math.round(wa.attackDamage * 0.72));
            if (pc.hp < pc.maxHp * 0.24) {
              pc.retreatHealTimer = 4.0;
            }
            pc.assistState = 'return';
            pc.assistTargetWild = false;
            pc.assistTargetWildId = null;
            pc.assistCooldown = stats.assistCooldown;
          }
        }
      } else {
        const targetEnemy = this.enemies.find((e) => e.id === pc.assistTargetId && !e.dying);
        if (!targetEnemy || pc.assistTimer <= 0) {
          pc.assistState = 'return';
          pc.assistTargetId = null;
          pc.assistCooldown = stats.assistCooldown;
        } else {
          targetX = targetEnemy.rig.root.position.x;
          targetZ = targetEnemy.rig.root.position.z;
          desiredSpeed = dashSpeed;
          const dEnemy = Math.hypot(targetX - pc.pos.x, targetZ - pc.pos.z);
          if (dEnemy <= 1.85) {
            _v4.set(targetX - pc.pos.x, 0, targetZ - pc.pos.z);
            const hitPt = _v6.set(targetX, targetEnemy.rig.root.position.y + 1.25, targetZ);
            this.damageEnemy(targetEnemy, stats.attackDamage, _v4, false, hitPt);
            pc.hp = Math.max(1, pc.hp - 16);
            if (pc.hp < pc.maxHp * 0.24) {
              pc.retreatHealTimer = 3.5;
            }
            pc.assistState = 'return';
            pc.assistTargetId = null;
            pc.assistCooldown = stats.assistCooldown;
          }
        }
      }
    } else if (pc.assistState === 'return') {
      const heroRightX = -Math.cos(this.heroYaw);
      const heroRightZ = Math.sin(this.heroYaw);
      targetX = this.heroPos.x - heroRightX * 1.95;
      targetZ = this.heroPos.z - heroRightZ * 1.95;
      desiredSpeed = stats.moveSpeed * 1.24;
      if (Math.hypot(targetX - pc.pos.x, targetZ - pc.pos.z) < 2.6) {
        pc.assistState = 'follow';
      }
    }

    const dx = targetX - pc.pos.x;
    const dz = targetZ - pc.pos.z;
    const dist = Math.hypot(dx, dz);
    let targetVx = 0;
    let targetVz = 0;
    if (dist > 0.75) {
      const speedFactor = pc.assistState === 'dash' ? 1 : Math.min(1, (dist - 0.5) / 3.2);
      const catchupBoost = dist > 7 ? 1.38 : 1.0;
      targetVx = (dx / dist) * desiredSpeed * speedFactor * catchupBoost;
      targetVz = (dz / dist) * desiredSpeed * speedFactor * catchupBoost;
    }

    pc.velX = THREE.MathUtils.damp(pc.velX, targetVx, 11, dt);
    pc.velZ = THREE.MathUtils.damp(pc.velZ, targetVz, 11, dt);
    pc.pos.x += pc.velX * dt;
    pc.pos.z += pc.velZ * dt;
    this.resolveCircleWorldCollision(pc.pos, petRadius, false);
    pc.pos.y = this.world.getGroundHeight(pc.pos.x, pc.pos.z, pc.pos.y);

    const speed = Math.hypot(pc.velX, pc.velZ);
    const desiredYaw = speed > 0.35 ? Math.atan2(pc.velX, pc.velZ) : this.heroYaw;
    let yawDiff = desiredYaw - pc.yaw;
    while (yawDiff > Math.PI) yawDiff -= Math.PI * 2;
    while (yawDiff < -Math.PI) yawDiff += Math.PI * 2;
    pc.yaw += yawDiff * Math.min(1, dt * 10);

    pc.moveBlend = THREE.MathUtils.damp(
      pc.moveBlend,
      Math.min(1, speed / Math.max(4, stats.moveSpeed)),
      12,
      dt,
    );
    pc.walkPhase += dt * (4.0 + speed * 1.45);

    pc.rig.root.position.copy(pc.pos);
    pc.rig.root.rotation.set(0, pc.yaw, 0);

    animateAnimalRig(pc.rig, pc.record.species, dt, this.worldTime, pc.walkPhase, pc.moveBlend, {
      isLunging: pc.assistState === 'dash',
      isTamed: true,
    });
  }

  private updateFloatingDamages(dt: number): void {
    for (let i = this.floatingDamages.length - 1; i >= 0; i--) {
      const fd = this.floatingDamages[i];
      fd.life -= dt;
      if (fd.life <= 0) {
        this.scene.remove(fd.sprite);
        fd.texture.dispose();
        fd.material.dispose();
        this.floatingDamages.splice(i, 1);
        continue;
      }
      const progress = 1 - fd.life / fd.maxLife;
      fd.pos.y += fd.velY * dt * (1 - progress * 0.45);
      fd.sprite.position.copy(fd.pos);
      // Punchy scale-pop on entry then gentle fade out
      const pop = progress < 0.16 ? 0.75 + (progress / 0.16) * 0.4 : 1.15 - progress * 0.2;
      fd.sprite.scale.set(fd.baseScaleX * pop, fd.baseScaleY * pop, 1);
      fd.material.opacity = progress > 0.55 ? 1 - (progress - 0.55) / 0.45 : 1;
    }
  }

  private updateKalboishakhiStorm(dt: number): void {
    this.stormRig.uniforms.uTime.value = this.worldTime;
    this.stormTeleportFlash = Math.max(0, this.stormTeleportFlash - dt * 0.72);

    // Pause storm countdown while still watching the intro WBTC bridge bus ride
    if (this.busMode === 'riding_intro') {
      this.outsideStorm = false;
      this.outsideStormElapsed = 0;
      this.stormDrainTimer = 0;
      return;
    }

    // 4 contraction stages every 90 seconds from expanded 780u full-map down to 34u final showdown
    const stageRadii = [this.initialStormRadius, 460, 240, 105, 34];

    if (this.stormShrinking) {
      this.stormShrinkElapsed += dt;
      const t = Math.min(1, this.stormShrinkElapsed / this.stormShrinkDuration);
      const ease = t * t * (3 - 2 * t);
      this.stormRadius = THREE.MathUtils.lerp(this.stormStartRadius, this.stormTargetRadius, ease);
      if (t >= 1) {
        this.stormShrinking = false;
        this.stormPhase = Math.min(stageRadii.length, this.stormPhase + 1);
        this.stormCountdown = this.stormPhaseInterval;
      }
    } else if (this.stormPhase < stageRadii.length) {
      this.stormCountdown -= dt;
      if (this.stormCountdown <= 0) {
        this.stormShrinking = true;
        this.stormShrinkElapsed = 0;
        this.stormStartRadius = this.stormRadius;
        this.stormTargetRadius = stageRadii[this.stormPhase];
        this.stormCountdown = 0;
        this.audio.playStormWarning();
        this.waveBanner = 'কালবৈশাখী বলয় সংকুচিত হচ্ছে!';
        this.waveBannerTimer = 2.8;
      }
    }

    this.stormRig.wallMesh.scale.set(this.stormRadius, 1, this.stormRadius);
    this.stormRig.groundRing.scale.set(this.stormRadius, this.stormRadius, 1);

    // Check if player is outside the safe circle
    const checkPos = this.busMode === 'driving' ? this.busPos : this.heroPos;
    const distFromCenter = Math.hypot(
      checkPos.x - this.stormCenter.x,
      checkPos.z - this.stormCenter.y,
    );
    this.outsideStorm = distFromCenter > this.stormRadius;

    if (this.outsideStorm && !this.heroJumpingFromBus) {
      // Ultra-slow minimal HP drain: strictly 1 HP every 5 seconds (max 12 HP over 60 seconds)
      this.outsideStormElapsed += dt;
      this.stormDrainTimer += dt;

      while (this.stormDrainTimer >= 5.0) {
        this.stormDrainTimer -= 5.0;
        if (this.busMode === 'driving') {
          this.health = Math.max(0, this.health - 1);
          this.damageFlash = Math.max(this.damageFlash, 0.22);
          if (this.health <= 0) {
            this.busMode = 'none';
            this.hero.root.visible = true;
            this.damagePlayer(1, true);
            return;
          }
        } else {
          this.health = Math.max(0, this.health - 1);
          this.damageFlash = Math.max(this.damageFlash, 0.22);
          if (this.health <= 0) {
            this.damagePlayer(1, true);
            return;
          }
        }
      }

      // After 60 full seconds outside, Kalboishakhi wind automatically teleports player inside the Safe Zone
      if (this.outsideStormElapsed >= this.outsideStormDuration) {
        this.triggerKalboishakhiTeleport();
      }
    } else {
      // Re-entering the Safe Zone immediately stops drain and resets the 60-second timer
      this.outsideStormElapsed = 0;
      this.stormDrainTimer = 0;
    }
  }

  private triggerKalboishakhiTeleport(): void {
    const departPos = _v2.copy(this.busMode === 'driving' ? this.busPos : this.heroPos);

    // Safely dismount if driving the bus or riding a bicycle/motorcycle so wind drops hero cleanly onto walkable ground
    if (this.busMode === 'driving') {
      this.busMode = 'none';
      this.busSpeed = 0;
      this.hero.root.visible = true;
    }
    if (this.activeTwoWheeler) {
      this.dismountTwoWheeler(true);
    }
    this.scopeActive = false;

    const bounds = this.world.playableBounds;
    const safeMaxR = Math.max(3.2, this.stormRadius - 2.4);
    const sampleMaxR = Math.min(safeMaxR, 145);
    const dest = _v3.set(this.stormCenter.x, 0, this.stormCenter.y);

    // Active grounded enemies inside or close to the current safe zone
    const activeEnemies = this.enemies.filter((e) => {
      if (e.dying || e.busSeatIndex >= 0 || e.jumpingFromBus) return false;
      const d = Math.hypot(
        e.rig.root.position.x - this.stormCenter.x,
        e.rig.root.position.z - this.stormCenter.y,
      );
      return d <= this.stormRadius + 4;
    });

    const clampInsideSafeZone = (pt: THREE.Vector3) => {
      pt.x = THREE.MathUtils.clamp(pt.x, bounds.minX + 1.5, bounds.maxX - 1.5);
      pt.z = THREE.MathUtils.clamp(pt.z, bounds.minZ + 1.5, bounds.maxZ - 1.5);
      const dx = pt.x - this.stormCenter.x;
      const dz = pt.z - this.stormCenter.y;
      const d = Math.hypot(dx, dz);
      if (d > safeMaxR && d > 0.001) {
        pt.x = this.stormCenter.x + (dx / d) * safeMaxR;
        pt.z = this.stormCenter.y + (dz / d) * safeMaxR;
      }
      if (this.world.isWaterBlocked(pt.x, pt.z)) {
        pt.z = pt.z > -45.5 ? -18.5 : -74.0;
      }
      this.resolveCircleWorldCollision(pt, 0.62, true);
      pt.y = this.world.getGroundHeight(pt.x, pt.z);
    };

    // 50% chance to drop near an active enemy warrior; 50% chance to drop at a distant safe spot
    const placeNearEnemy = activeEnemies.length > 0 && Math.random() < 0.5;

    if (placeNearEnemy) {
      const targetEnemy = activeEnemies[Math.floor(Math.random() * activeEnemies.length)];
      let bestFound = false;
      for (let attempt = 0; attempt < 12; attempt++) {
        const ang = Math.random() * Math.PI * 2;
        const dist = 5.8 + Math.random() * 3.8;
        dest.set(
          targetEnemy.rig.root.position.x + Math.cos(ang) * dist,
          0,
          targetEnemy.rig.root.position.z + Math.sin(ang) * dist,
        );
        clampInsideSafeZone(dest);
        const finalDistToCenter = Math.hypot(
          dest.x - this.stormCenter.x,
          dest.z - this.stormCenter.y,
        );
        if (finalDistToCenter <= this.stormRadius - 1.2) {
          bestFound = true;
          break;
        }
      }
      if (!bestFound) {
        dest.set(this.stormCenter.x, 0, this.stormCenter.y);
        clampInsideSafeZone(dest);
      }
    } else {
      // Distant quiet location inside the Safe Zone (farthest from active enemies)
      let bestScore = -Infinity;
      const candidate = _v4;
      for (let attempt = 0; attempt < 16; attempt++) {
        const ang = Math.random() * Math.PI * 2;
        const rad = sampleMaxR * (0.2 + Math.sqrt(Math.random()) * 0.72);
        candidate.set(
          this.stormCenter.x + Math.cos(ang) * rad,
          0,
          this.stormCenter.y + Math.sin(ang) * rad,
        );
        clampInsideSafeZone(candidate);

        let nearestEnemyDist = 30;
        for (const e of activeEnemies) {
          const d = Math.hypot(
            candidate.x - e.rig.root.position.x,
            candidate.z - e.rig.root.position.z,
          );
          if (d < nearestEnemyDist) nearestEnemyDist = d;
        }
        const distFromDepart = Math.hypot(candidate.x - departPos.x, candidate.z - departPos.z);
        const score = nearestEnemyDist * 1.4 + Math.min(24, distFromDepart) * 0.45;
        if (score > bestScore) {
          bestScore = score;
          dest.copy(candidate);
        }
      }
    }

    // Swirling departure wind burst
    this.spawnParticles(_v1.set(departPos.x, 1.0, departPos.z), 0x7ceeff, 16, 7.5);
    this.spawnParticles(_v1.set(departPos.x, 1.3, departPos.z), 0xc7a6ff, 12, 6.2);

    // Teleport hero cleanly into the Safe Zone on valid solid terrain
    this.heroPos.copy(dest);
    this.heroPos.y = this.world.getGroundHeight(this.heroPos.x, this.heroPos.z);
    this.hero.root.position.copy(this.heroPos);

    // Swirling arrival wind burst + dust eddy
    this.spawnParticles(_v1.set(this.heroPos.x, 0.9, this.heroPos.z), 0x82f0ff, 20, 8.2);
    this.spawnParticles(_v1.set(this.heroPos.x, 1.2, this.heroPos.z), 0xffe296, 14, 6.5);

    this.stormTeleportFlash = 1.0;
    this.camShake = Math.min(0.62, this.camShake + 0.45);
    this.audio.playStormTeleport();
    this.waveBanner = 'কালবৈশাখী ঝড় আপনাকে উড়িয়ে নিয়ে এসেছে!';
    this.waveBannerTimer = 3.8;

    this.outsideStormElapsed = 0;
    this.stormDrainTimer = 0;
    this.outsideStorm = false;
    this.emitHud();
  }

  private updateParticles(dt: number): void {
    for (const p of this.particles) {
      if (!p.active) continue;
      p.life -= dt;
      if (p.life <= 0) {
        p.active = false;
        p.mesh.visible = false;
        continue;
      }
      p.vel.y -= 14 * dt;
      p.pos.addScaledVector(p.vel, dt);
      if (p.pos.y < 0.05) {
        p.pos.y = 0.05;
        p.vel.y *= -0.35;
      }
      p.mesh.position.copy(p.pos);
      const t = p.life / p.maxLife;
      p.mesh.scale.setScalar(p.scale * t);
    }
  }

  private updateImpactFlashes(dt: number): void {
    for (let i = 0; i < this.impactFlashes.length; i++) {
      const fl = this.impactFlashes[i];
      if (!fl.active) continue;
      fl.life -= dt;
      if (fl.life <= 0) {
        fl.active = false;
        fl.mesh.visible = false;
        continue;
      }
      const p = 1 - fl.life / fl.maxLife;
      const scale = 0.38 + (1 - Math.pow(1 - p, 2)) * fl.maxScale;
      fl.mesh.scale.setScalar(scale);
      fl.mesh.lookAt(this.camera.position);
      fl.material.opacity = (1 - p) * 0.92;
    }
  }

  private checkHighScore(): void {
    if (this.score > this.highScore) {
      this.highScore = this.score;
      try {
        localStorage.setItem(STORAGE_KEY_HIGHSCORE, String(this.highScore));
      } catch {
        // ignore storage errors
      }
    }
  }

  // --- Render Loop with Software-WebGL Pacing ---

  private afterDraw(cb: () => void): void {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) return;
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private tick = (): void => {
    if (this.disposed) return;

    const now = performance.now();
    const rawDt = (now - this.lastFrameMs) / 1000;
    this.lastFrameMs = now;
    const dt = Math.min(Math.max(rawDt, 0.001), 0.05);

    if (this.phase !== 'paused' && this.levelUpNoticeTimer > 0) {
      this.levelUpNoticeTimer -= dt;
      if (this.levelUpNoticeTimer <= 0) {
        this.levelUpNoticeTimer = 0;
        this.levelUpNotice = null;
      }
    }

    this.update(dt);
    this.renderer.render(this.scene, this.camera);

    // Emit HUD snapshot at ~20Hz so React never throttles the 60fps WebGL loop
    this.hudEmitAccum += dt;
    if (this.hudEmitAccum >= 0.05) {
      this.hudEmitAccum = 0;
      this.emitHud();
    }

    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  };

  private emitHud(): void {
    const alive = this.enemies.filter((e) => !e.dying).length;
    const activeSlot = this.weaponSlots[this.weaponType];
    const locPos = this.busMode !== 'none' ? this.busPos : this.heroPos;
    this.onHudUpdate({
      phase: this.phase,
      busMode: this.busMode,
      nearBus: this.nearBus,
      ridingVehicle: this.activeTwoWheeler ? this.activeTwoWheeler.kind : null,
      nearVehicle: this.nearTwoWheeler ? this.nearTwoWheeler.kind : null,
      vehicleSpeedKmh: this.activeTwoWheeler ? Math.round(Math.abs(this.rideSpeed) * 3.6) : 0,
      nearChest: this.nearChest,
      busZoneLabel: this.busMode === 'riding_intro' ? this.busZoneLabel : null,
      locationName: this.world.getLocationName(locPos.x, locPos.z, locPos.y),
      busSpeedKmh: Math.round(Math.abs(this.busSpeed) * 3.6),
      busRouteProgress: this.busRouteT,
      busInteriorCam: this.busInteriorCam,
      busExitSlowing: this.busExitSlowing,
      health: Math.ceil(this.health),
      maxHealth: this.maxHealth,
      armor: Math.ceil(this.armor),
      maxArmor: this.maxArmor,
      activeWeapon: this.weaponType,
      weapons: {
        agni47: { ...this.weaponSlots.agni47 },
        kalbhairav: { ...this.weaponSlots.kalbhairav },
        trishul: { ...this.weaponSlots.trishul },
        fala: { ...this.weaponSlots.fala },
      },
      scopeActive: this.scopeActive,
      ammo: activeSlot.ammo,
      maxAmmo: activeSlot.maxAmmo,
      reserveAmmo: activeSlot.reserve,
      isReloading: this.isReloading,
      reloadProgress: this.isReloading
        ? 1 - Math.max(0, this.reloadTimer / Math.max(0.01, this.reloadDuration))
        : 1,
      sanjibaniCount: this.sanjibaniCount,
      sanjibaniCollected: this.sanjibaniCollected,
      maxSanjibani: this.maxSanjibani,
      isHealing: this.isHealing,
      healProgress: this.isHealing
        ? 1 - Math.max(0, this.healTimer / this.healDuration)
        : 0,
      grenadeCount: this.grenadeCount,
      maxGrenades: this.maxGrenades,
      headshots: this.headshots,
      bodyshots: this.bodyshots,
      stormPhase: this.stormPhase,
      stormCountdown: Math.ceil(this.stormCountdown),
      stormShrinking: this.stormShrinking,
      outsideStorm: this.outsideStorm,
      outsideStormRemaining: this.outsideStorm
        ? Math.max(0, Math.ceil(this.outsideStormDuration - this.outsideStormElapsed))
        : this.outsideStormDuration,
      stormTeleportFlash: this.stormTeleportFlash,
      stormRadius: Math.round(this.stormRadius),
      score: this.score,
      highScore: this.highScore,
      kills: this.kills,
      wave: this.wave,
      enemiesRemaining:
        this.gameMode === 'survival'
          ? Math.max(0, this.maxMapEnemies - this.kills)
          : alive + this.waveEnemiesToSpawn.length,
      maxMapEnemies: this.maxMapEnemies,
      matchVictory: this.matchVictory,
      radarBlips: this.buildRadarBlips(),
      radarNorthDeg: Math.round(((Math.PI - this.camYaw) * 180) / Math.PI),
      waveBanner: this.waveBanner,
      damageFlash: this.damageFlash,
      damageAngle: this.damageAngle,
      hitMarker: this.hitMarker,
      hitMarkerKill: this.hitMarkerKill,
      hitMarkerHeadshot: this.hitMarkerHeadshot,
      reticleSpread: this.reticleSpread,
      muted: this.audio.isMuted(),
      sprintRatio: this.sprintStamina,
      isSprinting:
        this.sprintToggled ||
        ((this.keysHeld.has('ShiftLeft') || this.keysHeld.has('ShiftRight')) &&
          this.heroSprintWeight > 0.35),
      isCrouching: this.isCrouching,
      isJumping: this.heroJumpOffset > 0.05,
      pickupToast: this.pickupToast,
      gameMode: this.gameMode,
      playerId: this.playerId,
      playerLevel: this.playerProgression.level,
      playerMaxLevel: this.playerProgression.maxLevel,
      playerXp: this.playerProgression.xp,
      playerXpToNext: this.playerProgression.xpToNext,
      weaponDamageBonusPct: this.playerProgression.weaponDamageBonusPct,
      levelUpNotice: this.levelUpNotice,
      permanentPet: this.permanentPet,
      animalHearts: this.animalHearts,
      petHp: this.petCompanion
        ? Math.ceil(this.petCompanion.hp)
        : this.permanentPet
          ? this.permanentPet.stats.maxHp
          : 0,
      petMaxHp: this.permanentPet ? this.permanentPet.stats.maxHp : 0,
      wildAnimal: this.buildWildAnimalHudState(),
      tamingActive: this.tamingActive,
      tamingProgress: this.tamingProgress,
      tamingStatusText: this.tamingStatusText,
    });
  }

  private buildRadarBlips(): RadarBlip[] {
    if (this.phase !== 'playing' && this.phase !== 'paused') {
      return [];
    }
    const blips: RadarBlip[] = [];
    const refPos = this.busMode !== 'none' ? this.busPos : this.heroPos;
    const fwdX = Math.sin(this.camYaw);
    const fwdZ = Math.cos(this.camYaw);
    const rightX = -fwdZ;
    const rightZ = fwdX;
    const radarRange = 140;
    const maxNormR = 0.9;

    const pushBlip = (wx: number, wz: number, kind: RadarBlip['kind']) => {
      const dx = wx - refPos.x;
      const dz = wz - refPos.z;
      const dotRight = dx * rightX + dz * rightZ;
      const dotFwd = dx * fwdX + dz * fwdZ;
      let nx = dotRight / radarRange;
      let ny = dotFwd / radarRange;
      const r = Math.hypot(nx, ny);
      let clamped = false;
      if (r > maxNormR) {
        const scale = maxNormR / r;
        nx *= scale;
        ny *= scale;
        clamped = true;
      }
      blips.push({
        x: Number(nx.toFixed(3)),
        y: Number(ny.toFixed(3)),
        kind,
        clamped,
      });
    };

    for (const e of this.enemies) {
      if (e.dying || e.busSeatIndex >= 0) continue;
      pushBlip(
        e.rig.root.position.x,
        e.rig.root.position.z,
        e.archetype === 'heavy' ? 'heavy' : 'enemy',
      );
    }

    // Keep hidden wildlife OFF the minimap until the player explores close (<= 22m) or provokes/chases them!
    for (const wa of this.wildAnimals) {
      if (wa.state === 'dead' || wa.hp <= 0) continue;
      const engaged = wa.provoked || wa.state === 'flee' || wa.lastDamagedTimer > 0;
      if (!wa.discovered && !engaged) continue;
      const d = Math.hypot(wa.pos.x - refPos.x, wa.pos.z - refPos.z);
      if (d <= 22 || (engaged && d <= 52)) {
        pushBlip(wa.pos.x, wa.pos.z, wa.isHeartBearer ? 'wild_heart' : 'wild');
      }
    }

    if (this.petCompanion && this.petCompanion.rig.root.visible) {
      pushBlip(this.petCompanion.pos.x, this.petCompanion.pos.z, 'pet');
    }

    return blips;
  }

  private buildWildAnimalHudState(): WildAnimalHudState | null {
    if (
      this.phase !== 'playing' ||
      this.busMode === 'riding_intro' ||
      this.heroJumpingFromBus
    ) {
      return null;
    }
    const refPos = this.busMode === 'driving' ? this.busPos : this.heroPos;
    let nearest: ActiveWildAnimal | null = null;
    let nearestDist = Infinity;

    // Only surface a wild animal in HUD once closely discovered (<= 24m) or actively provoked/fleeing (<= 52m)
    for (const wa of this.wildAnimals) {
      if (wa.state === 'dead' || wa.hp <= 0) continue;
      const d = Math.hypot(wa.pos.x - refPos.x, wa.pos.z - refPos.z);
      const engaged = wa.provoked || wa.state === 'flee' || wa.lastDamagedTimer > 0;
      const visibleRange = engaged ? 52 : 24;
      if ((wa.discovered || engaged) && d <= visibleRange && d < nearestDist) {
        nearestDist = d;
        nearest = wa;
      }
    }

    if (!nearest) return null;
    const wa = nearest;
    const dx = wa.pos.x - refPos.x;
    const dz = wa.pos.z - refPos.z;
    const dist = nearestDist;
    const fwdX = Math.sin(this.camYaw);
    const fwdZ = Math.cos(this.camYaw);
    const rightX = -fwdZ;
    const rightZ = fwdX;
    const dotFwd = dx * fwdX + dz * fwdZ;
    const dotRight = dx * rightX + dz * rightZ;
    const bearingDeg = Math.round((Math.atan2(dotRight, dotFwd) * 180) / Math.PI);
    const meta = WILD_ANIMAL_CATALOG[wa.species];
    const isSubdued = wa.state === 'subdued';
    const alreadyHasPet = this.permanentPet !== null;
    const onFoot = this.busMode === 'none' && this.activeTwoWheeler === null;
    const isTamingMode = this.gameMode === 'pet_taming';
    const areaBn = this.world.getLocationName(wa.pos.x, wa.pos.z, wa.pos.y) || wa.areaBn;
    return {
      species: wa.species,
      nameBn: meta.nameBn,
      areaBn,
      level: wa.level,
      hasAnimalHeart: wa.isHeartBearer,
      heartTier: wa.heartTier,
      heartValue: wa.heartValue,
      heartTierNameBn: wa.heartTier ? ANIMAL_HEART_TIERS[wa.heartTier].nameBn : null,
      hp: Math.ceil(wa.hp),
      maxHp: wa.maxHp,
      subdueRatio: wa.subdueRatio,
      isSubdued,
      distance: Math.round(dist),
      bearingDeg,
      canTame: isTamingMode && onFoot && isSubdued && dist <= TAME_GOLDEN_RING_RADIUS && !alreadyHasPet,
      blockedByLifetimeLimit:
        isTamingMode && onFoot && isSubdued && dist <= TAME_GOLDEN_RING_RADIUS + 0.5 && alreadyHasPet,
    };
  }

  // --- Event Listeners ---

  private onKeyDown = (e: KeyboardEvent): void => {
    if (this.customHudEditing) return;
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
      e.preventDefault();
    }

    if (this.phase === 'title' && (e.code === 'Enter' || e.code === 'Space')) {
      this.startGame();
      return;
    }

    if (e.code === 'Escape' || e.code === 'KeyP') {
      if (this.phase === 'playing' || this.phase === 'paused') {
        this.togglePause();
      }
      return;
    }

    if (this.phase !== 'playing') return;

    // Bus Jump/Exit, Bicycle/Motorcycle Mount/Dismount, OR Open Warrior Loot Chest ('F')
    if (e.code === 'KeyF') {
      if (this.busMode !== 'none') {
        this.exitBus();
      } else if (this.activeTwoWheeler) {
        this.dismountTwoWheeler();
      } else if (this.nearChest) {
        this.openNearestChest();
      } else if (this.nearTwoWheeler) {
        this.mountNearestTwoWheeler();
      } else if (this.nearBus) {
        this.enterBus();
      }
      return;
    }
    if (e.code === 'Space' && this.busMode === 'riding_intro') {
      this.exitBus();
      return;
    }
    if ((e.code === 'KeyV' || e.code === 'KeyC') && this.busMode === 'riding_intro') {
      this.toggleBusCameraView();
      return;
    }
    if (e.code === 'KeyH' && this.busMode !== 'none') {
      this.honkBusHorn();
      return;
    }

    // Battle Royale Quick-Switch Weapons (1-4), Scope (X), Sanjibani Heal (H/V), Bajra Gola (G) — on-foot only
    if (this.busMode === 'none' && !this.activeTwoWheeler) {
      if (e.code === 'Digit1') {
        this.setWeaponType('agni47');
        return;
      }
      if (e.code === 'Digit2') {
        this.setWeaponType('kalbhairav');
        return;
      }
      if (e.code === 'Digit3') {
        this.setWeaponType('trishul');
        return;
      }
      if (e.code === 'Digit4') {
        this.setWeaponType('fala');
        return;
      }
      if (e.code === 'KeyG') {
        this.throwGrenade();
        return;
      }
      if (e.code === 'KeyH' || e.code === 'KeyV') {
        this.useSanjibani();
        return;
      }
      if (e.code === 'KeyX') {
        this.toggleScope();
        return;
      }
      if (e.code === 'KeyT') {
        this.startTamingWildAnimal();
        return;
      }
      if (e.code === 'Space' && !e.repeat) {
        this.triggerJump();
        return;
      }
      if ((e.code === 'KeyC' || e.code === 'ControlLeft') && !e.repeat) {
        this.toggleCrouch();
        return;
      }
    }

    this.keysHeld.add(e.code);
    if (e.code === 'KeyR' && !this.activeTwoWheeler) {
      this.attemptStartReload();
    }
    if (e.code === 'KeyM') {
      this.toggleMute();
    }
  };

  private onKeyUp = (e: KeyboardEvent): void => {
    this.keysHeld.delete(e.code);
  };

  private onWindowBlur = (): void => {
    this.keysHeld.clear();
    this.mouseShootHeld = false;
    this.dragLookActive = false;
    this.dragPointerId = null;
    this.activeTouchPointers.clear();
    this.lastPinchDist = null;
    this.lobbyDragActive = false;
    this.lobbyDragPointerId = null;
    this.virtualInput.shooting = false;
    this.cancelSprintToggle();
  };

  private onPointerDown = (e: PointerEvent): void => {
    if (this.customHudEditing) return;
    if (e.target !== this.renderer.domElement) return;

    // Free Fire-style lobby: drag left/right to rotate the 3D Bengali hero
    if (this.phase === 'title') {
      this.lobbyDragActive = true;
      this.lobbyDragPointerId = e.pointerId;
      this.lobbyLastDragX = e.clientX;
      return;
    }

    if (this.phase !== 'playing') return;
    this.audio.unlock();

    if (e.pointerType === 'mouse') {
      if (e.button === 2 && this.busMode === 'none' && !this.activeTwoWheeler) {
        this.toggleScope();
        return;
      }
      if (e.button === 0 && !this.activeTwoWheeler) {
        this.mouseShootHeld = true;
      }
      // Allow smooth mouse drag camera turning on left or right button
      this.dragLookActive = true;
      this.dragPointerId = e.pointerId;
      this.lastDragX = e.clientX;
      this.lastDragY = e.clientY;
    } else {
      // Track active canvas touches for smooth single-finger look AND 2-finger mobile pinch-to-zoom
      this.activeTouchPointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (this.activeTouchPointers.size === 2) {
        this.dragLookActive = false;
        this.dragPointerId = null;
        const pts = Array.from(this.activeTouchPointers.values());
        this.lastPinchDist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
      } else if (this.activeTouchPointers.size === 1) {
        this.lastPinchDist = null;
        this.dragLookActive = true;
        this.dragPointerId = e.pointerId;
        this.lastDragX = e.clientX;
        this.lastDragY = e.clientY;
      }
    }
  };

  private onPointerMove = (e: PointerEvent): void => {
    if (this.customHudEditing) return;
    if (this.phase === 'title') {
      if (this.lobbyDragActive && e.pointerId === this.lobbyDragPointerId) {
        const dx = e.clientX - this.lobbyLastDragX;
        this.lobbyLastDragX = e.clientX;
        this.lobbyHeroTargetYaw += dx * 0.011;
      }
      return;
    }

    if (this.phase !== 'playing') return;

    if (document.pointerLockElement === this.renderer.domElement) {
      const lookMult = this.scopeActive
        ? this.getScopeLookFactor()
        : this.getGeneralLookFactor();
      this.camYaw -= e.movementX * 0.0032 * lookMult;
      this.camPitch = THREE.MathUtils.clamp(
        this.camPitch + e.movementY * 0.0024 * lookMult,
        -0.12,
        0.65,
      );
      return;
    }

    // Mobile 2-finger pinch-to-zoom on canvas (on-foot only)
    if (e.pointerType !== 'mouse' && this.activeTouchPointers.has(e.pointerId)) {
      this.activeTouchPointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (this.activeTouchPointers.size === 2 && this.busMode === 'none' && !this.activeTwoWheeler) {
        const pts = Array.from(this.activeTouchPointers.values());
        const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
        if (this.lastPinchDist !== null) {
          const delta = dist - this.lastPinchDist;
          // Spread fingers -> zoom in (lower FOV); pinch closer -> zoom out (wider FOV)
          this.pinchFovOffset = THREE.MathUtils.clamp(
            this.pinchFovOffset - delta * 0.14,
            -26,
            10,
          );
          if (!this.scopeActive && this.pinchFovOffset <= -18) {
            this.scopeActive = true;
            this.pinchFovOffset = 0;
            this.emitHud();
          } else if (this.scopeActive && this.pinchFovOffset >= 8) {
            this.scopeActive = false;
            this.pinchFovOffset = 0;
            this.emitHud();
          }
        }
        this.lastPinchDist = dist;
        return;
      }
    }

    if (this.dragLookActive && e.pointerId === this.dragPointerId) {
      const dx = e.clientX - this.lastDragX;
      const dy = e.clientY - this.lastDragY;
      this.lastDragX = e.clientX;
      this.lastDragY = e.clientY;
      this.virtualInput.lookDeltaX += dx;
      this.virtualInput.lookDeltaY += dy;
    }
  };

  private onPointerUp = (e: PointerEvent): void => {
    if (e.pointerId === this.lobbyDragPointerId) {
      this.lobbyDragActive = false;
      this.lobbyDragPointerId = null;
    }
    if (e.pointerType === 'mouse' && e.button === 0) {
      this.mouseShootHeld = false;
    }
    if (this.activeTouchPointers.has(e.pointerId)) {
      this.activeTouchPointers.delete(e.pointerId);
      if (this.activeTouchPointers.size < 2) {
        this.lastPinchDist = null;
      }
      if (this.activeTouchPointers.size === 1) {
        const [remainingId, pt] = Array.from(this.activeTouchPointers.entries())[0];
        this.dragLookActive = true;
        this.dragPointerId = remainingId;
        this.lastDragX = pt.x;
        this.lastDragY = pt.y;
      }
    }
    if (e.pointerId === this.dragPointerId && !this.activeTouchPointers.has(e.pointerId)) {
      this.dragLookActive = false;
      this.dragPointerId = null;
    }
  };

  private onContextMenu = (e: MouseEvent): void => {
    if (this.phase === 'playing') {
      e.preventDefault();
    }
  };

  private onResize = (): void => {
    const w = this.container.clientWidth || window.innerWidth;
    const h = Math.max(1, this.container.clientHeight || window.innerHeight);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setPixelRatio(this.getPixelRatioCap());
    this.renderer.setSize(w, h, false);
  };

  private onOrientationOrFullscreenChange = (): void => {
    this.onResize();
    if (this.orientationResizeTimer !== null) {
      window.clearTimeout(this.orientationResizeTimer);
    }
    this.orientationResizeTimer = window.setTimeout(() => {
      if (!this.disposed) this.onResize();
    }, 120);
  };

  private bindEvents(): void {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onWindowBlur);
    window.addEventListener('resize', this.onResize);
    window.addEventListener('orientationchange', this.onOrientationOrFullscreenChange);
    document.addEventListener('fullscreenchange', this.onOrientationOrFullscreenChange);
    document.addEventListener('webkitfullscreenchange', this.onOrientationOrFullscreenChange);
    window.visualViewport?.addEventListener('resize', this.onResize);
    if (typeof ResizeObserver !== 'undefined') {
      this.resizeObserver = new ResizeObserver(() => this.onResize());
      this.resizeObserver.observe(this.container);
    }
    this.renderer.domElement.addEventListener('pointerdown', this.onPointerDown);
    window.addEventListener('pointermove', this.onPointerMove);
    window.addEventListener('pointerup', this.onPointerUp);
    window.addEventListener('pointercancel', this.onPointerUp);
    this.renderer.domElement.addEventListener('contextmenu', this.onContextMenu);
  }

  public dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
    if (this.orientationResizeTimer !== null) {
      window.clearTimeout(this.orientationResizeTimer);
      this.orientationResizeTimer = null;
    }
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
      this.resizeObserver = null;
    }

    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onWindowBlur);
    window.removeEventListener('resize', this.onResize);
    window.removeEventListener('orientationchange', this.onOrientationOrFullscreenChange);
    document.removeEventListener('fullscreenchange', this.onOrientationOrFullscreenChange);
    document.removeEventListener('webkitfullscreenchange', this.onOrientationOrFullscreenChange);
    window.visualViewport?.removeEventListener('resize', this.onResize);
    this.renderer.domElement.removeEventListener('pointerdown', this.onPointerDown);
    window.removeEventListener('pointermove', this.onPointerMove);
    window.removeEventListener('pointerup', this.onPointerUp);
    window.removeEventListener('pointercancel', this.onPointerUp);
    this.renderer.domElement.removeEventListener('contextmenu', this.onContextMenu);

    this.scene.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh) {
        const mesh = obj as THREE.Mesh;
        mesh.geometry?.dispose();
        if (Array.isArray(mesh.material)) {
          mesh.material.forEach((m) => m.dispose());
        } else {
          mesh.material?.dispose();
        }
      }
    });

    this.textures.disposeAll();
    this.audio.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
