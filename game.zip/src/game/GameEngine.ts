import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { GameAudio } from './audio';
import {
  buildWbtcBus,
  BusRouteData,
  createBusIntroRoute,
  WbtcBusRig,
} from './bus';
import {
  buildBengaliHero,
  buildEnemyBot,
  buildPickupMesh,
  EnemyRig,
  HeroRig,
} from './characters';
import { createTextureBundle, TextureBundle } from './textures';
import {
  BusMode,
  CircleCollider,
  EnemyArchetype,
  GamchaStyle,
  GamePhase,
  HudSnapshot,
  PickupKind,
  VirtualInputState,
  WeaponType,
} from './types';
import { buildWestBengalWorld, WorldBuildResult } from './worldBuilder';

interface ActiveEnemy {
  id: number;
  archetype: EnemyArchetype;
  rig: EnemyRig;
  hp: number;
  maxHp: number;
  speed: number;
  radius: number;
  fireRange: number;
  fireCooldown: number;
  telegraphTimer: number;
  strafeDir: number;
  strafeTimer: number;
  walkPhase: number;
  hitFlashTimer: number;
  dying: boolean;
  deathTimer: number;
  knockback: THREE.Vector3;
  busSeatIndex: number;
  busDropT: number;
}

interface Bullet {
  active: boolean;
  fromPlayer: boolean;
  mesh: THREE.Mesh;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  life: number;
  damage: number;
}

interface Particle {
  active: boolean;
  mesh: THREE.Mesh;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  life: number;
  maxLife: number;
  scale: number;
}

interface PickupItem {
  id: number;
  kind: PickupKind;
  mesh: THREE.Group;
  pos: THREE.Vector3;
  life: number;
}

const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _v3 = new THREE.Vector3();
const _v4 = new THREE.Vector3();
const _camTarget = new THREE.Vector3();
const _camDesired = new THREE.Vector3();
const _lookAtPt = new THREE.Vector3();

const STORAGE_KEY_HIGHSCORE = 'banglar_joddha_high_score_v1';

const BENGALI_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
export function toBengaliNumber(n: number): string {
  return String(Math.max(0, Math.floor(n)))
    .split('')
    .map((ch) => {
      const code = ch.charCodeAt(0) - 48;
      return code >= 0 && code <= 9 ? BENGALI_DIGITS[code] : ch;
    })
    .join('');
}

export class GameEngine {
  private container: HTMLElement;
  private onHudUpdate: (snapshot: HudSnapshot) => void;
  private isSoftwareGl: boolean;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private sunLight: THREE.DirectionalLight;
  private textures: TextureBundle;
  private world: WorldBuildResult;
  private bus: WbtcBusRig;
  private busRoute: BusRouteData;
  private hero: HeroRig;
  private audio: GameAudio;

  private phase: GamePhase = 'title';
  private busMode: BusMode = 'none';
  private busAutoDriving = false;
  private busRouteT = 0;
  private busPos = new THREE.Vector3(-13, 0, 8.2);
  private busYaw = -Math.PI / 2;
  private busSpeed = 0;
  private busSteerAngle = 0;
  private busZoneLabel: string | null = null;
  private nearBus = false;
  private heroJumpingFromBus = false;
  private heroJumpProgress = 0;
  private heroJumpDuration = 0.55;
  private heroJumpStart = new THREE.Vector3();
  private heroJumpEnd = new THREE.Vector3();
  private heroJumpPeakY = 2.0;

  private gamchaStyle: GamchaStyle = 'red-white';
  private weaponType: WeaponType = 'rifle';
  private heroPos = new THREE.Vector3(0, 0, 7.2);
  private prevHeroPos = new THREE.Vector3(0, 0, 7.2);
  private prevHeroYaw = 0.28;
  private heroYaw = 0.28;
  private lobbyHeroYaw = 0.28;
  private lobbyHeroTargetYaw = 0.28;
  private lobbyShowcasePulse = 0;
  private heroWalkPhase = 0;
  private heroRecoil = 0;
  private muzzleFlashTimer = 0;
  private health = 100;
  private readonly maxHealth = 100;
  private ammo = 24;
  private maxAmmo = 24;
  private reserveAmmo = 96;
  private isReloading = false;
  private reloadTimer = 0;
  private readonly reloadDuration = 1.15;
  private fireCooldown = 0;
  private sprintStamina = 1.0;

  private score = 0;
  private highScore = 0;
  private kills = 0;
  private wave = 1;
  private waveEnemiesToSpawn: EnemyArchetype[] = [];
  private waveSpawnTimer = 0;
  private waveBreakTimer = 0;
  private waveBanner: string | null = null;
  private waveBannerTimer = 0;
  private pickupToast: string | null = null;
  private pickupToastTimer = 0;

  private camYaw = Math.PI;
  private camPitch = 0.24;
  private isZoomed = false;
  private camShake = 0;
  private hitstopTimer = 0;
  private damageFlash = 0;
  private hitMarker = 0;
  private hitMarkerKill = false;
  private titleTime = 0;
  private worldTime = 0;
  private introTransitionProgress = 1;
  private readonly introTransitionDuration = 0.92;
  private introStartCamPos = new THREE.Vector3();
  private introStartLookAt = new THREE.Vector3();
  private lobbyDragActive = false;
  private lobbyDragPointerId: number | null = null;
  private lobbyLastDragX = 0;

  private enemies: ActiveEnemy[] = [];
  private nextEnemyId = 1;
  private pickups: PickupItem[] = [];
  private nextPickupId = 1;
  private bullets: Bullet[] = [];
  private particles: Particle[] = [];

  private keysHeld = new Set<string>();
  private mouseShootHeld = false;
  private dragLookActive = false;
  private dragPointerId: number | null = null;
  private lastDragX = 0;
  private lastDragY = 0;
  private virtualInput: VirtualInputState = {
    moveX: 0,
    moveY: 0,
    shooting: false,
    sprinting: false,
    reloadJustPressed: false,
    lookDeltaX: 0,
    lookDeltaY: 0,
  };

  private disposed = false;
  private frameId = 0;
  private lastFrameMs = 0;
  private hudEmitAccum = 0;

  private onZoomEvent = (e: Event): void => {
    const detail = (e as CustomEvent<{ zoomed?: boolean }>).detail;
    this.isZoomed = Boolean(detail?.zoomed);
  };

  constructor(container: HTMLElement, onHudUpdate: (snapshot: HudSnapshot) => void) {
    this.container = container;
    this.onHudUpdate = onHudUpdate;
    this.audio = new GameAudio();

    try {
      const saved = localStorage.getItem(STORAGE_KEY_HIGHSCORE);
      if (saved) this.highScore = Math.max(0, parseInt(saved, 10) || 0);
    } catch {
      // ignore storage restrictions
    }

    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setSize(
      container.clientWidth || window.innerWidth,
      container.clientHeight || window.innerHeight,
    );

    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0xdba76f);
    this.scene.fog = new THREE.FogExp2(0xdba76f, 0.0078);

    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    const aspect =
      (container.clientWidth || window.innerWidth) /
      Math.max(1, container.clientHeight || window.innerHeight);
    this.camera = new THREE.PerspectiveCamera(56, aspect, 0.15, 320);

    const hemi = new THREE.HemisphereLight(0x9ec8e8, 0x8a5b36, 0.92);
    this.scene.add(hemi);

    this.sunLight = new THREE.DirectionalLight(0xffdfb0, 2.35);
    this.sunLight.position.set(28, 38, -22);
    this.sunLight.castShadow = true;
    this.sunLight.shadow.mapSize.set(2048, 2048);
    const d = 34;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.sunLight.shadow.camera.near = 2;
    this.sunLight.shadow.camera.far = 115;
    this.sunLight.shadow.bias = -0.0005;
    this.sunLight.shadow.normalBias = 0.025;
    this.scene.add(this.sunLight);
    this.scene.add(this.sunLight.target);

    const rimLight = new THREE.DirectionalLight(0xf59d56, 0.58);
    rimLight.position.set(-30, 14, -45);
    this.scene.add(rimLight);

    const frontFillLight = new THREE.DirectionalLight(0xffe7c2, 0.72);
    frontFillLight.position.set(16, 12, 24);
    this.scene.add(frontFillLight);

    this.textures = createTextureBundle(this.renderer);
    this.world = buildWestBengalWorld(this.textures);
    this.scene.add(this.world.worldGroup);

    this.busRoute = createBusIntroRoute();
    this.scene.add(this.busRoute.rampMesh);

    this.bus = buildWbtcBus(this.textures);
    this.bus.root.position.set(-13, 0, 8.2);
    this.scene.add(this.bus.root);

    this.hero = buildBengaliHero(this.textures);
    this.hero.root.position.copy(this.heroPos);
    this.hero.root.rotation.y = this.heroYaw;
    this.scene.add(this.hero.root);

    this.initPools();

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.bindEvents();
    this.emitHud();

    this.lastFrameMs = performance.now();
    this.tick();
  }

  private initPools(): void {
    const playerBulletGeo = new THREE.BoxGeometry(0.06, 0.06, 0.58);
    const enemyBulletGeo = new THREE.SphereGeometry(0.11, 6, 6);
    const playerBulletMat = new THREE.MeshBasicMaterial({ color: 0xffe48a });
    const enemyBulletMat = new THREE.MeshBasicMaterial({ color: 0xff4930 });

    for (let i = 0; i < 48; i++) {
      const isPlayer = i < 28;
      const mesh = new THREE.Mesh(
        isPlayer ? playerBulletGeo : enemyBulletGeo,
        isPlayer ? playerBulletMat : enemyBulletMat,
      );
      mesh.visible = false;
      this.scene.add(mesh);
      this.bullets.push({
        active: false,
        fromPlayer: isPlayer,
        mesh,
        pos: new THREE.Vector3(),
        vel: new THREE.Vector3(),
        life: 0,
        damage: isPlayer ? 34 : 11,
      });
    }

    const partGeo = new THREE.BoxGeometry(0.13, 0.13, 0.13);
    for (let i = 0; i < 64; i++) {
      const mat = new THREE.MeshBasicMaterial({ color: 0xffb84d });
      const mesh = new THREE.Mesh(partGeo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.particles.push({
        active: false,
        mesh,
        pos: new THREE.Vector3(),
        vel: new THREE.Vector3(),
        life: 0,
        maxLife: 0.4,
        scale: 1,
      });
    }
  }

  public setGamchaStyle(style: GamchaStyle): void {
    this.gamchaStyle = style;
    this.hero.gamchaMaterial.map =
      style === 'green-white' ? this.textures.gamchaGreenMap : this.textures.gamchaMap;
    this.hero.gamchaMaterial.needsUpdate = true;
    this.lobbyShowcasePulse = 1.0;
    this.audio.unlock();
    this.audio.playPickup('health');
  }

  public setWeaponType(weapon: WeaponType): void {
    this.weaponType = weapon;
    this.hero.rifleGroup.visible = weapon === 'rifle';
    this.hero.shotgunGroup.visible = weapon === 'shotgun';
    this.maxAmmo = weapon === 'shotgun' ? 8 : 24;
    this.ammo = this.maxAmmo;
    this.reserveAmmo = weapon === 'shotgun' ? 40 : 96;
    this.lobbyShowcasePulse = 1.0;
    if (this.phase === 'title') {
      this.lobbyHeroTargetYaw = weapon === 'shotgun' ? -0.45 : 0.32;
    }
    this.audio.unlock();
    this.audio.playReload();
    this.emitHud();
  }

  public startGame(): void {
    this.audio.unlock();
    this.clearDynamicEntities();

    const comingFromLobby = this.phase === 'title';

    this.phase = 'playing';
    this.busMode = 'riding_intro';
    this.busAutoDriving = true;
    this.busRouteT = 0.03;
    this.busSpeed = 12;
    this.busSteerAngle = 0;
    this.nearBus = false;
    this.heroJumpingFromBus = false;
    this.heroJumpProgress = 0;

    this.camYaw = Math.PI * 0.5;
    this.camPitch = 0.24;
    this.maxAmmo = this.weaponType === 'shotgun' ? 8 : 24;
    this.health = this.maxHealth;
    this.ammo = this.maxAmmo;
    this.reserveAmmo = this.weaponType === 'shotgun' ? 40 : 96;
    this.isReloading = false;
    this.reloadTimer = 0;
    this.fireCooldown = 0;
    this.sprintStamina = 1;
    this.score = 0;
    this.kills = 0;
    this.wave = 1;
    this.damageFlash = 0;
    this.hitMarker = 0;
    this.camShake = 0;
    this.pickupToast = null;
    this.lobbyDragActive = false;
    this.lobbyDragPointerId = null;

    this.hero.bodyGroup.scale.set(1, 1, 1);

    this.positionBusOnIntroRoute(this.busRouteT);

    this.bus.root.updateMatrixWorld(true);
    this.bus.heroIntroSeat.getWorldPosition(this.heroPos);
    this.hero.root.position.copy(this.heroPos);
    this.heroYaw = this.busYaw - Math.PI * 0.5;
    this.hero.root.rotation.y = this.heroYaw;

    this.waveEnemiesToSpawn = [];
    const dropTs = [0.54, 0.62, 0.70, 0.78, 0.86, 0.93];
    const introTypes: EnemyArchetype[] = ['scout', 'scout', 'rusher', 'scout', 'rusher', 'scout'];
    for (let i = 0; i < introTypes.length; i++) {
      this.spawnEnemyOnBus(introTypes[i], i, dropTs[i]);
    }

    this.waveBanner = 'WBTC বাস — হাওড়া সেতু পারাপার';
    this.waveBannerTimer = 3.0;
    this.audio.playBusHorn();

    if (comingFromLobby) {
      this.introStartCamPos.copy(this.camera.position);
      this.introStartLookAt.set(0.15, 1.25, -4.0);
      this.introTransitionProgress = 0;
    } else {
      this.introTransitionProgress = 1;
    }

    this.emitHud();
  }

  public exitBus(): void {
    if (this.phase !== 'playing') return;
    if (this.busMode === 'none') return;

    this.audio.unlock();
    this.audio.playBusJump();
    this.bus.root.updateMatrixWorld(true);

    if (this.busMode === 'riding_intro') {
      const startPos = this.heroJumpStart;
      this.bus.heroIntroSeat.getWorldPosition(startPos);

      const exitWorld = _v1;
      this.bus.doorExitPoint.getWorldPosition(exitWorld);

      const bounds = this.world.playableBounds;
      const landX = THREE.MathUtils.clamp(exitWorld.x, bounds.minX + 2.5, bounds.maxX - 2.5);
      const landZ =
        exitWorld.z < -13.5
          ? -12.5
          : THREE.MathUtils.clamp(exitWorld.z, bounds.minZ + 1.5, bounds.maxZ - 2.0);

      this.heroJumpEnd.set(landX, 0, landZ);
      this.resolveCircleWorldCollision(this.heroJumpEnd, 0.65);

      const dropHeight = Math.max(0.4, startPos.y);
      this.heroJumpPeakY = Math.max(startPos.y + 1.35, 1.85);
      this.heroJumpDuration = dropHeight > 2.2 ? 0.68 : 0.36;
      this.heroJumpProgress = 0;
      this.heroJumpingFromBus = true;

      this.busMode = 'none';
      this.camYaw = Math.PI;
      this.camPitch = 0.22;
      this.pickupToast = 'আপনি বাস থেকে নেমেছেন!';
      this.pickupToastTimer = 2.0;
      this.emitHud();
      return;
    }

    if (this.busMode === 'driving') {
      const exitPos = _v1;
      this.bus.doorExitPoint.getWorldPosition(exitPos);
      exitPos.y = 0;
      this.resolveCircleWorldCollision(exit
