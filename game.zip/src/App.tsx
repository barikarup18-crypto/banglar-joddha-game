import { useCallback, useEffect, useRef, useState } from 'react';
import { CustomHudEditor } from './components/CustomHudEditor';
import { GameHud } from './components/GameHud';
import { GuestProfileModal } from './components/GuestProfileModal';
import { SettingsModal } from './components/SettingsModal';
import { StatusModal } from './components/StatusModal';
import { TitleOverlay } from './components/TitleOverlay';
import { TouchControls } from './components/TouchControls';
import { loadApsaraProgress } from './game/apsaraSystem';
import { GameEngine } from './game/GameEngine';
import {
  loadGamchaStyle,
  loadGuestName,
  loadHeroOutfit,
  loadLoadoutPresets,
  saveGamchaStyle,
  saveGuestName,
  saveHeroOutfit,
  saveLoadoutPresets,
} from './game/loadoutStorage';
import {
  getOrCreatePlayerId,
  loadAnimalHeartsForId,
  loadPermanentPetForId,
  loadPlayerProgressionForId,
} from './game/petSystem';
import {
  cloneCustomHud,
  CustomHudLayout,
  DEFAULT_CUSTOM_HUD,
  GameSettings,
  loadGameSettings,
  saveGameSettings,
} from './game/settings';
import {
  ApsaraProgressState,
  GamchaStyle,
  GameMode,
  HeroOutfitId,
  HudSnapshot,
  LoadoutPreset,
  WEAPON_CATALOG,
  WeaponType,
} from './game/types';

const INITIAL_PLAYER_ID = getOrCreatePlayerId();
const INITIAL_PLAYER_PROGRESS = loadPlayerProgressionForId(INITIAL_PLAYER_ID);

const INITIAL_HUD: HudSnapshot = {
  phase: 'title',
  gameMode: 'survival',
  busMode: 'none',
  nearBus: false,
  ridingVehicle: null,
  nearVehicle: null,
  vehicleSpeedKmh: 0,
  nearChest: false,
  busZoneLabel: null,
  locationName: 'বাংলার গ্রাম',
  busSpeedKmh: 0,
  busRouteProgress: 0,
  busInteriorCam: true,
  busExitSlowing: false,
  health: INITIAL_PLAYER_PROGRESS.maxHealth,
  maxHealth: INITIAL_PLAYER_PROGRESS.maxHealth,
  armor: 0,
  maxArmor: 50,
  activeWeapon: 'agni47',
  weapons: {
    agni47: {
      ammo: WEAPON_CATALOG.agni47.magSize,
      maxAmmo: WEAPON_CATALOG.agni47.magSize,
      reserve: WEAPON_CATALOG.agni47.startReserve,
    },
    kalbhairav: {
      ammo: WEAPON_CATALOG.kalbhairav.magSize,
      maxAmmo: WEAPON_CATALOG.kalbhairav.magSize,
      reserve: WEAPON_CATALOG.kalbhairav.startReserve,
    },
    trishul: {
      ammo: WEAPON_CATALOG.trishul.magSize,
      maxAmmo: WEAPON_CATALOG.trishul.magSize,
      reserve: WEAPON_CATALOG.trishul.startReserve,
    },
    fala: {
      ammo: 0,
      maxAmmo: 0,
      reserve: 0,
    },
  },
  scopeActive: false,
  ammo: WEAPON_CATALOG.agni47.magSize,
  maxAmmo: WEAPON_CATALOG.agni47.magSize,
  reserveAmmo: WEAPON_CATALOG.agni47.startReserve,
  isReloading: false,
  reloadProgress: 1,
  sanjibaniCount: 1,
  sanjibaniCollected: 0,
  maxSanjibani: 5,
  isHealing: false,
  healProgress: 0,
  grenadeCount: 1,
  maxGrenades: 3,
  headshots: 0,
  bodyshots: 0,
  stormPhase: 1,
  stormCountdown: 90,
  stormShrinking: false,
  outsideStorm: false,
  outsideStormRemaining: 60,
  stormTeleportFlash: 0,
  stormRadius: 780,
  score: 0,
  highScore: 0,
  kills: 0,
  wave: 1,
  enemiesRemaining: 40,
  maxMapEnemies: 40,
  matchVictory: false,
  radarBlips: [],
  radarNorthDeg: 0,
  waveBanner: null,
  damageFlash: 0,
  damageAngle: null,
  hitMarker: 0,
  hitMarkerKill: false,
  hitMarkerHeadshot: false,
  reticleSpread: 0,
  muted: false,
  sprintRatio: 1,
  isSprinting: false,
  isCrouching: false,
  isJumping: false,
  pickupToast: null,
  playerId: INITIAL_PLAYER_ID,
  playerLevel: INITIAL_PLAYER_PROGRESS.level,
  playerMaxLevel: INITIAL_PLAYER_PROGRESS.maxLevel,
  playerXp: INITIAL_PLAYER_PROGRESS.xp,
  playerXpToNext: INITIAL_PLAYER_PROGRESS.xpToNext,
  weaponDamageBonusPct: INITIAL_PLAYER_PROGRESS.weaponDamageBonusPct,
  levelUpNotice: null,
  permanentPet: loadPermanentPetForId(INITIAL_PLAYER_ID),
  animalHearts: loadAnimalHeartsForId(INITIAL_PLAYER_ID),
  petHp: loadPermanentPetForId(INITIAL_PLAYER_ID)?.stats.maxHp ?? 0,
  petMaxHp: loadPermanentPetForId(INITIAL_PLAYER_ID)?.stats.maxHp ?? 0,
  wildAnimal: null,
  tamingActive: false,
  tamingProgress: 0,
  tamingStatusText: null,
};

type FullscreenElement = HTMLElement & {
  webkitRequestFullscreen?: () => Promise<void> | void;
  msRequestFullscreen?: () => Promise<void> | void;
};

type FullscreenDocument = Document & {
  webkitFullscreenElement?: Element | null;
  msFullscreenElement?: Element | null;
  webkitExitFullscreen?: () => Promise<void> | void;
  msExitFullscreen?: () => Promise<void> | void;
};

function getFullscreenActive(): boolean {
  if (typeof document === 'undefined') return false;
  const doc = document as FullscreenDocument;
  return Boolean(doc.fullscreenElement || doc.webkitFullscreenElement || doc.msFullscreenElement);
}

function requestGameFullscreen(): void {
  if (typeof document === 'undefined' || getFullscreenActive()) return;
  try {
    const el = document.documentElement as FullscreenElement;
    if (typeof el.requestFullscreen === 'function') {
      const res = el.requestFullscreen();
      if (res && typeof res.catch === 'function') {
        res.catch(() => {});
      }
    } else if (typeof el.webkitRequestFullscreen === 'function') {
      const res = el.webkitRequestFullscreen();
      if (res && typeof res.catch === 'function') {
        res.catch(() => {});
      }
    } else if (typeof el.msRequestFullscreen === 'function') {
      el.msRequestFullscreen();
    }
  } catch {
    // Ignore browser/iframe fullscreen restrictions cleanly
  }
}

function exitGameFullscreen(): void {
  if (typeof document === 'undefined' || !getFullscreenActive()) return;
  try {
    const doc = document as FullscreenDocument;
    if (typeof doc.exitFullscreen === 'function') {
      const res = doc.exitFullscreen();
      if (res && typeof res.catch === 'function') {
        res.catch(() => {});
      }
    } else if (typeof doc.webkitExitFullscreen === 'function') {
      const res = doc.webkitExitFullscreen();
      if (res && typeof res.catch === 'function') {
        res.catch(() => {});
      }
    } else if (typeof doc.msExitFullscreen === 'function') {
      doc.msExitFullscreen();
    }
  } catch {
    // Ignore browser/iframe fullscreen exit errors
  }
}

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const [hud, setHud] = useState<HudSnapshot>(INITIAL_HUD);
  const [gameMode, setGameMode] = useState<GameMode>('survival');
  const [gamchaStyle, setGamchaStyle] = useState<GamchaStyle>(() => loadGamchaStyle());
  const [heroOutfit, setHeroOutfit] = useState<HeroOutfitId>(() => loadHeroOutfit());
  const [presets, setPresets] = useState<LoadoutPreset[]>(() => loadLoadoutPresets());
  const [weaponType, setWeaponType] = useState<WeaponType>('agni47');
  const [isFullscreen, setIsFullscreen] = useState<boolean>(() => getFullscreenActive());
  const initialOutfitRef = useRef<HeroOutfitId>(heroOutfit);
  const initialGamchaRef = useRef<GamchaStyle>(gamchaStyle);

  // Persisted Game Settings & Custom HUD (localStorage)
  const [settings, setSettings] = useState<GameSettings>(() => loadGameSettings());
  const [settingsOpen, setSettingsOpen] = useState<boolean>(false);
  const [customHudOpen, setCustomHudOpen] = useState<boolean>(false);
  const pausedBySettingsRef = useRef<boolean>(false);
  const settingsRef = useRef(settings);
  const lastPhaseRef = useRef<HudSnapshot['phase']>('title');

  // Persisted Guest Profile Name (localStorage)
  const [guestName, setGuestName] = useState<string | null>(() => loadGuestName());
  const [guestModalOpen, setGuestModalOpen] = useState<boolean>(() => !loadGuestName());

  // Persisted Player Profile Currency (localStorage)
  const [progress] = useState<ApsaraProgressState>(() => loadApsaraProgress());

  useEffect(() => {
    lastPhaseRef.current = hud.phase;
  }, [hud.phase]);

  // Sync fullscreen state across standard & WebKit browsers
  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(getFullscreenActive());
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    document.addEventListener('webkitfullscreenchange', handleFsChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFsChange);
      document.removeEventListener('webkitfullscreenchange', handleFsChange);
    };
  }, []);

  // Persist and apply Game Settings live to Three.js engine
  useEffect(() => {
    settingsRef.current = settings;
    saveGameSettings(settings);
    const engine = engineRef.current;
    if (engine) {
      engine.setSensitivity(settings.generalSensitivity, settings.scopeSensitivity);
      engine.setGraphicsQuality(settings.graphicsQuality);
      engine.setAudioSettings(settings.sfxEnabled, settings.sfxVolume);
    }
  }, [settings]);

  // Isolate canvas firing/look touch handlers completely while Custom HUD editor is open
  useEffect(() => {
    engineRef.current?.setCustomHudEditing(customHudOpen);
  }, [customHudOpen]);

  // Mount Three.js GameEngine
  useEffect(() => {
    const mount = canvasMountRef.current;
    if (!mount) return;

    const engine = new GameEngine(mount, (snapshot) => {
      setHud(snapshot);
    });
    engineRef.current = engine;

    // Apply persisted user settings & outfit immediately on engine initialization
    const initial = settingsRef.current;
    engine.setSensitivity(initial.generalSensitivity, initial.scopeSensitivity);
    engine.setGraphicsQuality(initial.graphicsQuality);
    engine.setAudioSettings(initial.sfxEnabled, initial.sfxVolume);
    engine.setHeroOutfit(initialOutfitRef.current, true);
    engine.setGamchaStyle(initialGamchaRef.current, true);

    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  // --- Core Game Engine Controls ---

  const handleSelectGamcha = useCallback((style: GamchaStyle) => {
    setGamchaStyle(style);
    saveGamchaStyle(style);
    engineRef.current?.setGamchaStyle(style);
  }, []);

  const handleSelectOutfit = useCallback((outfit: HeroOutfitId) => {
    setHeroOutfit(outfit);
    saveHeroOutfit(outfit);
    engineRef.current?.setHeroOutfit(outfit);
  }, []);

  const handleSelectWeapon = useCallback((weapon: WeaponType) => {
    setWeaponType(weapon);
    engineRef.current?.setWeaponType(weapon);
  }, []);

  const handleApplyPreset = useCallback((preset: LoadoutPreset) => {
    setHeroOutfit(preset.outfit);
    saveHeroOutfit(preset.outfit);
    setGamchaStyle(preset.gamchaStyle);
    saveGamchaStyle(preset.gamchaStyle);
    setWeaponType(preset.weaponType);
    setGameMode(preset.gameMode);

    const engine = engineRef.current;
    if (engine) {
      engine.setHeroOutfit(preset.outfit, true);
      engine.setGamchaStyle(preset.gamchaStyle, true);
      engine.setGameMode(preset.gameMode);
      engine.setWeaponType(preset.weaponType);
    }
  }, []);

  const handleSavePreset = useCallback(
    (slot: 1 | 2 | 3) => {
      setPresets((prev) => {
        const next = prev.map((p) =>
          p.slot === slot
            ? {
                ...p,
                outfit: heroOutfit,
                gamchaStyle,
                weaponType,
                gameMode,
              }
            : p,
        );
        saveLoadoutPresets(next);
        return next;
      });
    },
    [heroOutfit, gamchaStyle, weaponType, gameMode],
  );

  const handleToggleScope = useCallback(() => {
    engineRef.current?.toggleScope();
  }, []);

  const handleUseSanjibani = useCallback(() => {
    engineRef.current?.useSanjibani();
  }, []);

  const handleThrowGrenade = useCallback(() => {
    engineRef.current?.throwGrenade();
  }, []);

  const handleOpenChest = useCallback(() => {
    engineRef.current?.openNearestChest();
  }, []);

  const handleStartTaming = useCallback(() => {
    engineRef.current?.startTamingWildAnimal();
  }, []);

  const handleSelectGameMode = useCallback((mode: GameMode) => {
    setGameMode(mode);
    engineRef.current?.setGameMode(mode);
  }, []);

  const handleSaveGuestName = useCallback((rawName: string) => {
    const saved = saveGuestName(rawName);
    if (!saved) return;
    setGuestName(saved);
    setGuestModalOpen(false);
  }, []);

  const handleOpenGuestProfile = useCallback(() => {
    setGuestModalOpen(true);
  }, []);

  const handleCloseGuestProfile = useCallback(() => {
    if (!guestName) return;
    setGuestModalOpen(false);
  }, [guestName]);

  const handleStart = useCallback(() => {
    if (!guestName || !guestName.trim()) {
      setGuestModalOpen(true);
      return;
    }
    requestGameFullscreen();
    setSettingsOpen(false);
    setCustomHudOpen(false);
    pausedBySettingsRef.current = false;
    engineRef.current?.startGame(gameMode);
  }, [gameMode, guestName]);

  const handleToggleFullscreen = useCallback(() => {
    if (getFullscreenActive()) {
      exitGameFullscreen();
    } else {
      requestGameFullscreen();
    }
  }, []);

  const handleOpenSettings = useCallback(() => {
    if (lastPhaseRef.current === 'playing') {
      pausedBySettingsRef.current = true;
      engineRef.current?.setPaused(true);
    } else {
      pausedBySettingsRef.current = false;
    }
    setCustomHudOpen(false);
    setSettingsOpen(true);
  }, []);

  const handleCloseSettings = useCallback(() => {
    setSettingsOpen(false);
    setCustomHudOpen(false);
    if (pausedBySettingsRef.current) {
      pausedBySettingsRef.current = false;
      engineRef.current?.setPaused(false);
    }
  }, []);

  const handleOpenCustomHud = useCallback(() => {
    setSettingsOpen(false);
    setCustomHudOpen(true);
  }, []);

  const handleSaveCustomHud = useCallback((layout: CustomHudLayout) => {
    setSettings((prev) => ({
      ...prev,
      customHud: cloneCustomHud(layout),
    }));
    setCustomHudOpen(false);
    setSettingsOpen(true);
  }, []);

  const handleCancelCustomHud = useCallback(() => {
    setCustomHudOpen(false);
    setSettingsOpen(true);
  }, []);

  const handleResetCustomHud = useCallback(() => {
    setSettings((prev) => ({
      ...prev,
      customHud: cloneCustomHud(DEFAULT_CUSTOM_HUD),
    }));
  }, []);

  const handleUpdateSettings = useCallback(
    (updater: (prev: GameSettings) => GameSettings) => {
      setSettings(updater);
    },
    [],
  );

  const handlePause = useCallback(() => {
    engineRef.current?.togglePause();
  }, []);

  const handleMainMenu = useCallback(() => {
    setSettingsOpen(false);
    setCustomHudOpen(false);
    pausedBySettingsRef.current = false;
    engineRef.current?.returnToTitle();
  }, []);

  const handleToggleMute = useCallback(() => {
    setSettings((prev) => ({
      ...prev,
      sfxEnabled: !prev.sfxEnabled,
    }));
  }, []);

  const handleVirtualMove = useCallback((x: number, y: number) => {
    engineRef.current?.setVirtualMove(x, y);
  }, []);

  const handleVirtualShoot = useCallback((active: boolean) => {
    engineRef.current?.setVirtualShoot(active);
  }, []);

  const handleToggleSprint = useCallback(() => {
    engineRef.current?.toggleSprint();
  }, []);

  const handleReload = useCallback(() => {
    engineRef.current?.triggerReload();
  }, []);

  const handleJump = useCallback(() => {
    engineRef.current?.triggerJump();
  }, []);

  const handleCrouch = useCallback(() => {
    engineRef.current?.toggleCrouch();
  }, []);

  const handleExitBus = useCallback(() => {
    engineRef.current?.exitBus();
  }, []);

  const handleEnterBus = useCallback(() => {
    engineRef.current?.enterBus();
  }, []);

  const handleMountVehicle = useCallback(() => {
    engineRef.current?.mountNearestTwoWheeler();
  }, []);

  const handleDismountVehicle = useCallback(() => {
    engineRef.current?.dismountTwoWheeler();
  }, []);

  const handleBusHorn = useCallback(() => {
    engineRef.current?.honkBusHorn();
  }, []);

  const handleToggleBusCameraView = useCallback(() => {
    engineRef.current?.toggleBusCameraView();
  }, []);

  const handleUpgradePlayer = useCallback(() => {
    engineRef.current?.upgradePlayerWithHearts();
  }, []);

  const handleUpgradePet = useCallback(() => {
    engineRef.current?.upgradePermanentPet();
  }, []);

  return (
    <main className="relative m-0 h-[100dvh] w-[100vw] overflow-hidden bg-[#121311] p-0">
      {/* Isolated WebGL canvas mount — edge-to-edge 100vw x 100dvh */}
      <div
        ref={canvasMountRef}
        className={`fixed inset-0 h-[100dvh] w-[100vw] touch-none ${
          hud.phase === 'title' ? 'cursor-grab active:cursor-grabbing' : ''
        }`}
      />

      {hud.phase === 'title' && !customHudOpen && (
        <TitleOverlay
          guestName={guestName}
          playerId={hud.playerId}
          playerLevel={hud.playerLevel}
          playerMaxLevel={hud.playerMaxLevel}
          playerXp={hud.playerXp}
          playerXpToNext={hud.playerXpToNext}
          playerMaxHealth={hud.maxHealth}
          weaponDamageBonusPct={hud.weaponDamageBonusPct}
          levelUpNotice={hud.levelUpNotice}
          permanentPet={hud.permanentPet}
          animalHearts={hud.animalHearts}
          gameMode={gameMode}
          muted={!settings.sfxEnabled}
          gamchaStyle={gamchaStyle}
          heroOutfit={heroOutfit}
          weaponType={weaponType}
          presets={presets}
          progress={progress}
          onSelectGameMode={handleSelectGameMode}
          onSelectGamcha={handleSelectGamcha}
          onSelectOutfit={handleSelectOutfit}
          onSelectWeapon={handleSelectWeapon}
          onApplyPreset={handleApplyPreset}
          onSavePreset={handleSavePreset}
          onUpgradePlayer={handleUpgradePlayer}
          onUpgradePet={handleUpgradePet}
          onStart={handleStart}
          onToggleMute={handleToggleMute}
          onOpenSettings={handleOpenSettings}
          onOpenGuestProfile={handleOpenGuestProfile}
        />
      )}

      {hud.phase !== 'title' && !customHudOpen && (
        <GameHud
          hud={hud}
          customHud={settings.customHud}
          isFullscreen={isFullscreen}
          onToggleFullscreen={handleToggleFullscreen}
          onOpenSettings={handleOpenSettings}
          onPause={handlePause}
          onToggleMute={handleToggleMute}
          onExitBus={handleExitBus}
          onEnterBus={handleEnterBus}
          onMountVehicle={handleMountVehicle}
          onBusHorn={handleBusHorn}
          onToggleBusCameraView={handleToggleBusCameraView}
          onSelectWeapon={handleSelectWeapon}
          onToggleScope={handleToggleScope}
          onUseSanjibani={handleUseSanjibani}
          onThrowGrenade={handleThrowGrenade}
          onOpenChest={handleOpenChest}
          onStartTaming={handleStartTaming}
        />
      )}

      {hud.phase === 'playing' && !customHudOpen && !settingsOpen && (
        <TouchControls
          busMode={hud.busMode}
          ridingVehicle={hud.ridingVehicle}
          activeWeapon={hud.activeWeapon}
          customHud={settings.customHud}
          onMove={handleVirtualMove}
          onShootChange={handleVirtualShoot}
          onToggleSprint={handleToggleSprint}
          onReload={handleReload}
          onJump={handleJump}
          onCrouch={handleCrouch}
          onExitBus={handleExitBus}
          onBusHorn={handleBusHorn}
          onDismountVehicle={handleDismountVehicle}
          isReloading={hud.isReloading}
          isSprinting={hud.isSprinting}
          isCrouching={hud.isCrouching}
          isJumping={hud.isJumping}
          ammo={hud.ammo}
          maxAmmo={hud.maxAmmo}
          reserveAmmo={hud.reserveAmmo}
        />
      )}

      {!settingsOpen && !customHudOpen && (
        <StatusModal
          hud={hud}
          onResume={handlePause}
          onRestart={handleStart}
          onMainMenu={handleMainMenu}
        />
      )}

      <SettingsModal
        open={settingsOpen}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        onOpenCustomHud={handleOpenCustomHud}
        onResetCustomHud={handleResetCustomHud}
        onClose={handleCloseSettings}
      />

      <CustomHudEditor
        open={customHudOpen}
        initialLayout={settings.customHud}
        onSave={handleSaveCustomHud}
        onCancel={handleCancelCustomHud}
      />

      <GuestProfileModal
        open={hud.phase === 'title' && guestModalOpen && !customHudOpen}
        currentName={guestName}
        playerId={hud.playerId}
        playerLevel={hud.playerLevel}
        gamchaStyle={gamchaStyle}
        isMandatory={!guestName}
        onConfirm={handleSaveGuestName}
        onClose={handleCloseGuestProfile}
      />
    </main>
  );
}
