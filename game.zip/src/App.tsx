import { useCallback, useEffect, useRef, useState } from 'react';
import { GameHud } from './components/GameHud';
import { StatusModal } from './components/StatusModal';
import { LobbyPanel, TitleOverlay } from './components/TitleOverlay';
import { TouchControls } from './components/TouchControls';
import {
  buildMatchSummaryCommentary,
  canClaimDailyGift,
  DAILY_GIFT_COINS,
  getSpeechRecognitionCtor,
  getTodayDateKey,
  loadApsaraProgress,
  loadFriendsList,
  processApsaraUtterance,
  saveApsaraProgress,
  saveFriendsList,
  speakAsApsara,
  stopApsaraSpeech,
} from './game/apsaraSystem';
import { GameEngine, toBengaliNumber } from './game/GameEngine';
import {
  ApsaraProgressState,
  ApsaraVoiceState,
  FriendEntry,
  GamchaStyle,
  HudSnapshot,
  MissionId,
  WEAPON_CATALOG,
  WeaponType,
} from './game/types';

const INITIAL_HUD: HudSnapshot = {
  phase: 'title',
  busMode: 'none',
  nearBus: false,
  nearChest: false,
  busZoneLabel: null,
  locationName: 'বাংলার গ্রাম',
  busSpeedKmh: 0,
  busRouteProgress: 0,
  busInteriorCam: true,
  busExitSlowing: false,
  health: 100,
  maxHealth: 100,
  armor: 0,
  maxArmor: 50,
  activeWeapon: 'agni47',
  weapons: {
    agni47: {
      ammo: WEAPON_CATALOG.agni47.magSize,
      maxAmmo: WEAPON_CATALOG.agni47.magSize,
      reserve: WEAPON_CATALOG.agni47.startReserve,
    },
    kalbhairav: {
      ammo: WEAPON_CATALOG.kalbhairav.magSize,
      maxAmmo: WEAPON_CATALOG.kalbhairav.magSize,
      reserve: WEAPON_CATALOG.kalbhairav.startReserve,
    },
    trishul: {
      ammo: WEAPON_CATALOG.trishul.magSize,
      maxAmmo: WEAPON_CATALOG.trishul.magSize,
      reserve: WEAPON_CATALOG.trishul.startReserve,
    },
    fala: {
      ammo: 0,
      maxAmmo: 0,
      reserve: 0,
    },
  },
  scopeActive: false,
  ammo: WEAPON_CATALOG.agni47.magSize,
  maxAmmo: WEAPON_CATALOG.agni47.magSize,
  reserveAmmo: WEAPON_CATALOG.agni47.startReserve,
  isReloading: false,
  reloadProgress: 1,
  sanjibaniCount: 1,
  sanjibaniCollected: 0,
  maxSanjibani: 5,
  isHealing: false,
  healProgress: 0,
  grenadeCount: 1,
  maxGrenades: 3,
  headshots: 0,
  bodyshots: 0,
  stormPhase: 1,
  stormCountdown: 90,
  stormShrinking: false,
  outsideStorm: false,
  outsideStormRemaining: 60,
  stormTeleportFlash: 0,
  stormRadius: 550,
  score: 0,
  highScore: 0,
  kills: 0,
  wave: 1,
  enemiesRemaining: 0,
  waveBanner: null,
  damageFlash: 0,
  hitMarker: 0,
  hitMarkerKill: false,
  hitMarkerHeadshot: false,
  muted: false,
  sprintRatio: 1,
  pickupToast: null,
};

const INITIAL_APSARA_GREETING =
  'নমস্কার যোদ্ধা! আমি অপ্সরা—তোমার ছায়া-সঙ্গিনী। আমার সাথে বাংলায় কথা বলো, বন্ধুদের ডাকো, বা দৈনিক উপহার নাও!';

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const [hud, setHud] = useState<HudSnapshot>(INITIAL_HUD);
  const [gamchaStyle, setGamchaStyle] = useState<GamchaStyle>('red-white');
  const [weaponType, setWeaponType] = useState<WeaponType>('agni47');

  // Persisted Apsara Rewards, Missions & Friends List (localStorage)
  const [progress, setProgress] = useState<ApsaraProgressState>(() => loadApsaraProgress());
  const [friends, setFriends] = useState<FriendEntry[]>(() => loadFriendsList());
  const [missionToast, setMissionToast] = useState<string | null>(null);
  const [externalPanelRequest, setExternalPanelRequest] = useState<{
    panel: LobbyPanel;
    nonce: number;
  } | null>(null);

  // Apsara Web Speech API State
  const [apsaraVoiceState, setApsaraVoiceState] = useState<ApsaraVoiceState>('idle');
  const [apsaraSpeechText, setApsaraSpeechText] = useState<string>(INITIAL_APSARA_GREETING);
  const [apsaraTranscript, setApsaraTranscript] = useState<string>('');
  const [apsaraVoiceMuted, setApsaraVoiceMuted] = useState<boolean>(false);
  const [apsaraMicNotice, setApsaraMicNotice] = useState<string | null>(null);

  // Refs for fresh state inside speech callbacks & match delta syncing
  const progressRef = useRef(progress);
  const friendsRef = useRef(friends);
  const voiceMutedRef = useRef(apsaraVoiceMuted);
  const recognitionRef = useRef<{ stop: () => void; abort: () => void } | null>(null);
  const stopSpeechCleanupRef = useRef<(() => void) | null>(null);
  const missionToastTimerRef = useRef<number | null>(null);
  const lastPhaseRef = useRef<HudSnapshot['phase']>('title');
  const matchStatTrackerRef = useRef({ headshots: 0, kills: 0, sanjibaniCollected: 0 });

  useEffect(() => {
    progressRef.current = progress;
    saveApsaraProgress(progress);
  }, [progress]);

  useEffect(() => {
    friendsRef.current = friends;
    saveFriendsList(friends);
  }, [friends]);

  useEffect(() => {
    voiceMutedRef.current = apsaraVoiceMuted;
  }, [apsaraVoiceMuted]);

  const showMissionToast = useCallback((message: string) => {
    setMissionToast(message);
    if (missionToastTimerRef.current !== null) {
      window.clearTimeout(missionToastTimerRef.current);
    }
    missionToastTimerRef.current = window.setTimeout(() => {
      setMissionToast(null);
    }, 3600);
  }, []);

  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {
        // Ignore already-stopped recognition
      }
      recognitionRef.current = null;
    }
    setApsaraVoiceState((prev) => (prev === 'listening' ? 'idle' : prev));
  }, []);

  const speakLine = useCallback((line: string) => {
    setApsaraSpeechText(line);
    if (stopSpeechCleanupRef.current) {
      stopSpeechCleanupRef.current();
      stopSpeechCleanupRef.current = null;
    }
    stopSpeechCleanupRef.current = speakAsApsara(line, {
      muted: voiceMutedRef.current,
      onStart: () => setApsaraVoiceState('speaking'),
      onEnd: () => setApsaraVoiceState((prev) => (prev === 'speaking' ? 'idle' : prev)),
    });
  }, []);

  // Pre-warm speechSynthesis voices list in Chrome/Edge
  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.getVoices();
    }
    return () => {
      if (missionToastTimerRef.current !== null) {
        window.clearTimeout(missionToastTimerRef.current);
      }
      if (stopSpeechCleanupRef.current) {
        stopSpeechCleanupRef.current();
      }
      stopApsaraSpeech();
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {
          // Ignore cleanup errors
        }
      }
    };
  }, []);

  // Mount Three.js GameEngine
  useEffect(() => {
    const mount = canvasMountRef.current;
    if (!mount) return;

    const engine = new GameEngine(mount, (snapshot) => {
      setHud(snapshot);
    });
    engineRef.current = engine;

    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  // Sync cross-match stats (headshots, kills, sanjibaniCollected) into Apsara Missions
  useEffect(() => {
    const prevPhase = lastPhaseRef.current;
    lastPhaseRef.current = hud.phase;

    if (hud.phase === 'playing') {
      // Stop lobby speech/mic cleanly when entering combat
      if (prevPhase !== 'playing') {
        stopListening();
        if (stopSpeechCleanupRef.current) {
          stopSpeechCleanupRef.current();
          stopSpeechCleanupRef.current = null;
        }
        stopApsaraSpeech();
        setApsaraVoiceState('idle');
      }

      // Reset per-match stat tracker whenever engine starts a fresh match
      if (
        hud.headshots < matchStatTrackerRef.current.headshots ||
        hud.kills < matchStatTrackerRef.current.kills ||
        hud.sanjibaniCollected < matchStatTrackerRef.current.sanjibaniCollected
      ) {
        matchStatTrackerRef.current = { headshots: 0, kills: 0, sanjibaniCollected: 0 };
      }

      const dHeadshots = Math.max(0, hud.headshots - matchStatTrackerRef.current.headshots);
      const dKills = Math.max(0, hud.kills - matchStatTrackerRef.current.kills);
      const dSanjibani = Math.max(
        0,
        hud.sanjibaniCollected - matchStatTrackerRef.current.sanjibaniCollected,
      );

      if (dHeadshots > 0 || dKills > 0 || dSanjibani > 0) {
        matchStatTrackerRef.current = {
          headshots: hud.headshots,
          kills: hud.kills,
          sanjibaniCollected: hud.sanjibaniCollected,
        };

        let newlyCompletedTitle: string | null = null;
        setProgress((prev) => {
          let changed = false;
          const nextMissions = prev.missions.map((m) => {
            if (m.progress >= m.target) return m;
            const delta =
              m.id === 'headshots_3'
                ? dHeadshots
                : m.id === 'kills_5'
                  ? dKills
                  : dSanjibani;
            if (delta <= 0) return m;
            changed = true;
            const nextVal = Math.min(m.target, m.progress + delta);
            if (nextVal >= m.target && m.progress < m.target) {
              newlyCompletedTitle = m.title;
            }
            return { ...m, progress: nextVal };
          });
          return changed ? { ...prev, missions: nextMissions } : prev;
        });

        if (newlyCompletedTitle) {
          showMissionToast(`অপ্সরার চ্যালেঞ্জ সম্পূর্ণ: ${newlyCompletedTitle} — উপহার নিন!`);
        }
      }
    }

    // Trigger Apsara spoken Match Summary reaction on Game Over
    if (hud.phase === 'gameover' && prevPhase !== 'gameover') {
      const commentary = buildMatchSummaryCommentary(hud);
      speakLine(commentary);
    }
  }, [hud, showMissionToast, speakLine, stopListening]);

  // --- Friend Actions (shared by UI clicks & Apsara Voice Commands) ---

  const openLobbyDrawer = useCallback((panel: LobbyPanel) => {
    setExternalPanelRequest({ panel, nonce: Date.now() });
  }, []);

  const handleSendFriendRequest = useCallback(
    (friendIdOrName: string, skipSpeech = false) => {
      let targetDisplayName = friendIdOrName;
      setFriends((prev) => {
        const existing = prev.find(
          (f) => f.id === friendIdOrName || f.name.toLowerCase() === friendIdOrName.toLowerCase(),
        );
        if (existing) {
          targetDisplayName = existing.name;
          if (existing.status === 'friend') return prev;
          return prev.map((f) =>
            f.id === existing.id ? { ...f, status: 'request_sent' } : f,
          );
        }
        const created: FriendEntry = {
          id: `friend-${Date.now()}`,
          name: friendIdOrName,
          aliases: [friendIdOrName.toLowerCase()],
          level: 1 + (prev.length % 9),
          status: 'request_sent',
          presence: 'online',
          invitedToSquad: false,
          district: 'পশ্চিমবঙ্গ',
        };
        return [created, ...prev];
      });
      if (!skipSpeech) {
        speakLine(`${targetDisplayName}-কে বন্ধুত্বের অনুরোধ পাঠানো হয়েছে যোদ্ধা!`);
      }
    },
    [speakLine],
  );

  const handleAcceptFriendRequest = useCallback(
    (friendId: string, skipSpeech = false) => {
      const target = friendsRef.current.find((f) => f.id === friendId);
      setFriends((prev) =>
        prev.map((f) =>
          f.id === friendId ? { ...f, status: 'friend', presence: 'online' } : f,
        ),
      );
      if (!skipSpeech && target) {
        speakLine(`${target.name}-এর বন্ধুত্বের অনুরোধ গ্রহণ করা হয়েছে যোদ্ধা! এখন আপনারা বন্ধু!`);
      }
    },
    [speakLine],
  );

  const handleInviteFriend = useCallback(
    (friendIdOrName: string, skipSpeech = false) => {
      let targetDisplayName = friendIdOrName;
      setFriends((prev) => {
        const existing = prev.find(
          (f) => f.id === friendIdOrName || f.name.toLowerCase() === friendIdOrName.toLowerCase(),
        );
        if (existing) {
          targetDisplayName = existing.name;
          return prev.map((f) =>
            f.id === existing.id ? { ...f, invitedToSquad: true } : f,
          );
        }
        const created: FriendEntry = {
          id: `friend-${Date.now()}`,
          name: friendIdOrName,
          aliases: [friendIdOrName.toLowerCase()],
          level: 5,
          status: 'friend',
          presence: 'online',
          invitedToSquad: true,
          district: 'কলকাতা',
        };
        return [created, ...prev];
      });
      if (!skipSpeech) {
        speakLine(`${targetDisplayName}-কে খেলায় ডাকার আমন্ত্রণ পাঠানো হয়েছে যোদ্ধা!`);
      }
    },
    [speakLine],
  );

  const handleAddNewFriendByName = useCallback(
    (name: string) => {
      handleSendFriendRequest(name, false);
    },
    [handleSendFriendRequest],
  );

  // --- Daily Gift & Mission Reward Claims ---

  const handleClaimDailyGift = useCallback(
    (skipSpeech = false) => {
      if (!canClaimDailyGift(progressRef.current)) return;
      const today = getTodayDateKey();
      setProgress((prev) => ({
        ...prev,
        goldCoins: prev.goldCoins + DAILY_GIFT_COINS,
        lastDailyClaimDate: today,
        dailyStreak: prev.dailyStreak + 1,
      }));
      if (!skipSpeech) {
        speakLine(
          `তোমার জন্য আজকের ${toBengaliNumber(DAILY_GIFT_COINS)} স্বর্ণমুদ্রা দিলাম যোদ্ধা! হুগলির ময়দানে বিজয়ী হও!`,
        );
      }
    },
    [speakLine],
  );

  const handleClaimMissionReward = useCallback(
    (missionId: MissionId) => {
      const target = progressRef.current.missions.find((m) => m.id === missionId);
      if (!target || target.claimed || target.progress < target.target) return;

      setProgress((prev) => {
        const nextMissions = prev.missions.map((m) =>
          m.id === missionId ? { ...m, claimed: true } : m,
        );
        const nextTitles = prev.unlockedTitles.includes(target.unlockTitle)
          ? prev.unlockedTitles
          : [...prev.unlockedTitles, target.unlockTitle];
        return {
          ...prev,
          goldCoins: prev.goldCoins + target.rewardCoins,
          missions: nextMissions,
          unlockedTitles: nextTitles,
          activeTitle: target.unlockTitle,
          auraBoostUnlocked: true,
        };
      });

      speakLine(
        `অভিনন্দন যোদ্ধা! ${toBengaliNumber(target.rewardCoins)} স্বর্ণমুদ্রা এবং "${target.unlockTitle}" উপাধি আনলক হয়েছে!`,
      );
    },
    [speakLine],
  );

  const handleSelectTitle = useCallback((title: string) => {
    setProgress((prev) => ({ ...prev, activeTitle: title }));
  }, []);

  // --- Voice-to-Voice Utterance Handler ---

  const handleApsaraPrompt = useCallback(
    (utterance: string) => {
      setApsaraMicNotice(null);
      setApsaraTranscript('');
      const result = processApsaraUtterance(
        utterance,
        friendsRef.current,
        progressRef.current,
      );

      switch (result.action.type) {
        case 'send_friend_request':
          handleSendFriendRequest(
            result.action.friendId ?? result.action.targetName,
            true,
          );
          openLobbyDrawer('friends');
          break;
        case 'invite_squad':
          handleInviteFriend(result.action.friendId ?? result.action.targetName, true);
          openLobbyDrawer('friends');
          break;
        case 'accept_friend_request':
          if (result.action.friendId) {
            handleAcceptFriendRequest(result.action.friendId, true);
          }
          openLobbyDrawer('friends');
          break;
        case 'claim_daily_gift':
          handleClaimDailyGift(true);
          openLobbyDrawer('rewards');
          break;
        case 'open_friends':
          openLobbyDrawer('friends');
          break;
        case 'open_rewards':
          openLobbyDrawer('rewards');
          break;
        default:
          break;
      }

      speakLine(result.reply);
    },
    [
      handleAcceptFriendRequest,
      handleClaimDailyGift,
      handleInviteFriend,
      handleSendFriendRequest,
      openLobbyDrawer,
      speakLine,
    ],
  );

  const handleToggleApsaraListen = useCallback(() => {
    if (apsaraVoiceState === 'listening') {
      stopListening();
      return;
    }

    const Ctor = getSpeechRecognitionCtor();
    if (!Ctor) {
      setApsaraMicNotice('মাইক্রোফোন সমর্থিত নয়—নিচের কুইক বোতামে ট্যাপ করুন।');
      speakLine('তোমার ব্রাউজারে মাইক্রোফোন পাওয়া যাচ্ছে না যোদ্ধা, তবে নিচের বোতামগুলোতে ট্যাপ করে আমার সাথে কথা বলো!');
      return;
    }

    // Stop current speech before listening so the mic doesn't hear Apsara
    if (stopSpeechCleanupRef.current) {
      stopSpeechCleanupRef.current();
      stopSpeechCleanupRef.current = null;
    }
    stopApsaraSpeech();
    setApsaraMicNotice(null);
    setApsaraTranscript('');

    const startWithLang = (lang: 'bn-IN' | 'bn-BD', allowFallback: boolean) => {
      try {
        const recognition = new Ctor();
        recognition.lang = lang;
        recognition.continuous = false;
        recognition.interimResults = true;
        recognition.maxAlternatives = 1;

        let finalSpoken = '';
        let latestInterim = '';

        recognition.onstart = () => {
          setApsaraVoiceState('listening');
        };

        recognition.onresult = (event) => {
          let interim = '';
          for (let i = event.resultIndex; i < event.results.length; i++) {
            const chunk = event.results[i][0]?.transcript ?? '';
            if (event.results[i].isFinal) {
              finalSpoken += chunk;
            } else {
              interim += chunk;
            }
          }
          latestInterim = interim;
          setApsaraTranscript((finalSpoken || interim).trim());
        };

        recognition.onerror = (event) => {
          recognitionRef.current = null;
          if (event.error === 'language-not-supported' && allowFallback) {
            startWithLang('bn-BD', false);
            return;
          }
          setApsaraVoiceState('idle');
          if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
            setApsaraMicNotice('মাইক্রোফোন অনুমতি বন্ধ—নিচের কুইক বোতামে ট্যাপ করুন।');
          } else if (event.error !== 'aborted' && event.error !== 'no-speech') {
            setApsaraMicNotice('কণ্ঠ শোনা যায়নি—আবার চেষ্টা করুন বা নিচে ট্যাপ করুন।');
          }
        };

        recognition.onend = () => {
          recognitionRef.current = null;
          setApsaraVoiceState((prev) => (prev === 'listening' ? 'idle' : prev));
          const captured = (finalSpoken || latestInterim).trim();
          if (captured) {
            handleApsaraPrompt(captured);
          }
        };

        recognitionRef.current = recognition;
        recognition.start();
      } catch {
        setApsaraVoiceState('idle');
        setApsaraMicNotice('মাইক্রোফোন চালু হয়নি—নিচের কুইক বোতাম ব্যবহার করুন।');
      }
    };

    startWithLang('bn-IN', true);
  }, [apsaraVoiceState, handleApsaraPrompt, speakLine, stopListening]);

  const handleToggleApsaraVoiceMute = useCallback(() => {
    setApsaraVoiceMuted((prev) => {
      const next = !prev;
      if (next) {
        if (stopSpeechCleanupRef.current) {
          stopSpeechCleanupRef.current();
          stopSpeechCleanupRef.current = null;
        }
        stopApsaraSpeech();
        setApsaraVoiceState((s) => (s === 'speaking' ? 'idle' : s));
      }
      return next;
    });
  }, []);

  // --- Core Game Engine Controls ---

  const handleSelectGamcha = useCallback((style: GamchaStyle) => {
    setGamchaStyle(style);
    engineRef.current?.setGamchaStyle(style);
  }, []);

  const handleSelectWeapon = useCallback((weapon: WeaponType) => {
    setWeaponType(weapon);
    engineRef.current?.setWeaponType(weapon);
  }, []);

  const handleToggleScope = useCallback(() => {
    engineRef.current?.toggleScope();
  }, []);

  const handleUseSanjibani = useCallback(() => {
    engineRef.current?.useSanjibani();
  }, []);

  const handleThrowGrenade = useCallback(() => {
    engineRef.current?.throwGrenade();
  }, []);

  const handleOpenChest = useCallback(() => {
    engineRef.current?.openNearestChest();
  }, []);

  const handleStart = useCallback(() => {
    stopListening();
    stopApsaraSpeech();
    matchStatTrackerRef.current = { headshots: 0, kills: 0, sanjibaniCollected: 0 };
    engineRef.current?.startGame();
  }, [stopListening]);

  const handlePause = useCallback(() => {
    engineRef.current?.togglePause();
  }, []);

  const handleMainMenu = useCallback(() => {
    engineRef.current?.returnToTitle();
    setApsaraSpeechText(INITIAL_APSARA_GREETING);
  }, []);

  const handleToggleMute = useCallback(() => {
    engineRef.current?.toggleMute();
  }, []);

  const handleVirtualMove = useCallback((x: number, y: number) => {
    engineRef.current?.setVirtualMove(x, y);
  }, []);

  const handleVirtualShoot = useCallback((active: boolean) => {
    engineRef.current?.setVirtualShoot(active);
  }, []);

  const handleVirtualSprint = useCallback((active: boolean) => {
    engineRef.current?.setVirtualSprint(active);
  }, []);

  const handleReload = useCallback(() => {
    engineRef.current?.triggerReload();
  }, []);

  const handleExitBus = useCallback(() => {
    engineRef.current?.exitBus();
  }, []);

  const handleEnterBus = useCallback(() => {
    engineRef.current?.enterBus();
  }, []);

  const handleBusHorn = useCallback(() => {
    engineRef.current?.honkBusHorn();
  }, []);

  const handleToggleBusCameraView = useCallback(() => {
    engineRef.current?.toggleBusCameraView();
  }, []);

  return (
    <main className="relative h-screen w-screen overflow-hidden bg-[#18120e]">
      {/* Isolated WebGL canvas mount — React HUD state updates never recreate the canvas */}
      <div
        ref={canvasMountRef}
        className={`fixed inset-0 h-full w-full touch-none ${
          hud.phase === 'title' ? 'cursor-grab active:cursor-grabbing' : ''
        }`}
      />

      {hud.phase === 'title' && (
        <TitleOverlay
          highScore={hud.highScore}
          muted={hud.muted}
          gamchaStyle={gamchaStyle}
          weaponType={weaponType}
          progress={progress}
          friends={friends}
          apsaraVoiceState={apsaraVoiceState}
          apsaraSpeechText={apsaraSpeechText}
          apsaraTranscript={apsaraTranscript}
          apsaraVoiceMuted={apsaraVoiceMuted}
          apsaraMicNotice={apsaraMicNotice}
          externalPanelRequest={externalPanelRequest}
          onSelectGamcha={handleSelectGamcha}
          onSelectWeapon={handleSelectWeapon}
          onStart={handleStart}
          onToggleMute={handleToggleMute}
          onToggleApsaraListen={handleToggleApsaraListen}
          onToggleApsaraVoiceMute={handleToggleApsaraVoiceMute}
          onSendApsaraPrompt={handleApsaraPrompt}
          onSendFriendRequest={handleSendFriendRequest}
          onAcceptFriendRequest={handleAcceptFriendRequest}
          onInviteFriend={handleInviteFriend}
          onAddNewFriendByName={handleAddNewFriendByName}
          onClaimDailyGift={handleClaimDailyGift}
          onClaimMissionReward={handleClaimMissionReward}
          onSelectTitle={handleSelectTitle}
        />
      )}

      {hud.phase !== 'title' && (
        <GameHud
          hud={hud}
          missionToast={missionToast}
          onPause={handlePause}
          onToggleMute={handleToggleMute}
          onExitBus={handleExitBus}
          onEnterBus={handleEnterBus}
          onBusHorn={handleBusHorn}
          onToggleBusCameraView={handleToggleBusCameraView}
          onSelectWeapon={handleSelectWeapon}
          onToggleScope={handleToggleScope}
          onUseSanjibani={handleUseSanjibani}
          onThrowGrenade={handleThrowGrenade}
          onOpenChest={handleOpenChest}
        />
      )}

      {hud.phase === 'playing' && (
        <TouchControls
          busMode={hud.busMode}
          activeWeapon={hud.activeWeapon}
          onMove={handleVirtualMove}
          onShootChange={handleVirtualShoot}
          onSprintChange={handleVirtualSprint}
          onReload={handleReload}
          onExitBus={handleExitBus}
          onBusHorn={handleBusHorn}
          isReloading={hud.isReloading}
          ammo={hud.ammo}
          maxAmmo={hud.maxAmmo}
          reserveAmmo={hud.reserveAmmo}
        />
      )}

      <StatusModal
        hud={hud}
        progress={progress}
        apsaraVoiceState={apsaraVoiceState}
        apsaraSpeechText={apsaraSpeechText}
        apsaraTranscript={apsaraTranscript}
        apsaraVoiceMuted={apsaraVoiceMuted}
        onToggleApsaraListen={handleToggleApsaraListen}
        onToggleApsaraVoiceMute={handleToggleApsaraVoiceMute}
        onSendApsaraPrompt={handleApsaraPrompt}
        onClaimMissionReward={handleClaimMissionReward}
        onResume={handlePause}
        onRestart={handleStart}
        onMainMenu={handleMainMenu}
      />
    </main>
  );
}
