import React, { useState } from 'react';
import { toBengaliNumber } from '../game/GameEngine';
import { GamchaStyle, WeaponType } from '../game/types';

type LobbyPanel = 'character' | 'weapon' | 'map' | null;

interface TitleOverlayProps {
  highScore: number;
  muted: boolean;
  gamchaStyle: GamchaStyle;
  weaponType: WeaponType;
  onSelectGamcha: (style: GamchaStyle) => void;
  onSelectWeapon: (weapon: WeaponType) => void;
  onStart: () => void;
  onToggleMute: () => void;
}

export const TitleOverlay: React.FC<TitleOverlayProps> = ({
  highScore,
  muted,
  gamchaStyle,
  weaponType,
  onSelectGamcha,
  onSelectWeapon,
  onStart,
  onToggleMute,
}) => {
  const [activePanel, setActivePanel] = useState<LobbyPanel>(null);

  const togglePanel = (panel: Exclude<LobbyPanel, null>) => {
    setActivePanel((prev) => (prev === panel ? null : panel));
  };

  return (
    <div className="pointer-events-none fixed inset-0 z-30 flex flex-col justify-between px-3.5 py-3.5 sm:px-6 sm:py-5">
      {/* Subtle top/bottom cinematic edge shading without obstructing the center 3D hero */}
      <div className="pointer-events-none fixed inset-x-0 top-0 -z-10 h-24 bg-gradient-to-b from-[#130b07]/70 to-transparent" />
      <div className="pointer-events-none fixed inset-x-0 bottom-0 -z-10 h-28 bg-gradient-to-t from-[#130b07]/78 to-transparent" />

      {/* TOP BAR: Player Profile Badge (Left) + Game Title Emblem & Audio (Right) */}
      <div className="flex items-start justify-between gap-3">
        {/* Top-Left: Free Fire-Style Player Profile Badge ('ভানু • LV 1') + Coins & Diamonds */}
        <div className="pointer-events-auto flex flex-wrap items-center gap-2.5">
          {/* Player Card */}
          <div className="flex items-center gap-2.5 rounded-xl border border-[#f5c763]/55 bg-[#19110c]/88 px-2.5 py-1.5 shadow-[0_6px_20px_rgba(0,0,0,0.52)]">
            {/* Bengali Hero Avatar Emblem */}
            <div className="relative flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-lg border border-[#ffd87d]/70 bg-gradient-to-b from-[#8f261f] to-[#3a120e]">
              <svg viewBox="0 0 40 40" className="h-9 w-9">
                {/* Gamcha patterned collar */}
                <path d="M6 38 Q20 26 34 38 Z" fill={gamchaStyle === 'red-white' ? '#c92228' : '#1b7a3d'} />
                <path d="M10 38 Q20 30 30 38 Z" fill="#faf3e6" fillOpacity="0.65" />
                {/* Face */}
                <circle cx="20" cy="17" r="8.5" fill="#c99163" />
                {/* Hair */}
                <path d="M11 16 C11 8, 29 8, 29 16 C26 11, 14 11, 11 16 Z" fill="#181414" />
                {/* Gamcha headband */}
                <rect
                  x="11.5"
                  y="12.5"
                  width="17"
                  height="2.8"
                  rx="1"
                  fill={gamchaStyle === 'red-white' ? '#d42028' : '#208844'}
                />
                {/* Moustache */}
                <path d="M16.5 21 Q20 19.6 23.5 21" stroke="#181414" strokeWidth="1.6" fill="none" strokeLinecap="round" />
              </svg>
            </div>

            <div className="pr-1.5">
              <div className="flex items-center gap-1.5">
                <span className="font-bengali-ui text-sm font-bold tracking-wide text-[#fff4de] sm:text-base">
                  ভানু • LV 1
                </span>
              </div>
              {/* Compact Level Progress Bar */}
              <div className="mt-1 flex items-center gap-1.5">
                <div className="h-1.5 w-20 overflow-hidden rounded-full bg-[#362418]">
                  <div className="h-full w-[38%] rounded-full bg-gradient-to-r from-[#f7b529] to-[#ffe17a]" />
                </div>
                <span className="font-bengali-ui text-[10px] font-semibold text-[#d7bc93]">
                  হুগলি গার্ড
                </span>
              </div>
            </div>
          </div>

          {/* Coins & Diamonds Currency Strip */}
          <div className="flex items-center gap-2">
            {/* Gold Coins */}
            <div className="flex items-center gap-1.5 rounded-lg border border-[#f5c763]/45 bg-[#19110c]/86 px-2.5 py-1.5 shadow-[0_4px_14px_rgba(0,0,0,0.45)]">
              <svg viewBox="0 0 20 20" className="h-4 w-4 shrink-0">
                <circle cx="10" cy="10" r="8.5" fill="#f7c034" stroke="#9e640b" strokeWidth="1.4" />
                <circle cx="10" cy="10" r="5.5" fill="none" stroke="#fff0b5" strokeWidth="1.1" />
                <text x="10" y="13.2" textAnchor="middle" fontSize="8.5" fontWeight="bold" fill="#7c4704">৳</text>
              </svg>
              <span className="font-bengali-ui tabular-nums text-xs font-bold text-[#ffe59e] sm:text-sm">
                ২,৪৫০
              </span>
            </div>

            {/* Diamonds */}
            <div className="flex items-center gap-1.5 rounded-lg border border-[#63d4f5]/45 bg-[#111920]/86 px-2.5 py-1.5 shadow-[0_4px_14px_rgba(0,0,0,0.45)]">
              <svg viewBox="0 0 20 20" className="h-4 w-4 shrink-0">
                <polygon points="10,2 18,8 10,18 2,8" fill="#3fd3ff" stroke="#b8f3ff" strokeWidth="1.2" />
                <polyline points="2,8 18,8" stroke="#c8f7ff" strokeWidth="0.9" fill="none" />
                <polyline points="6,8 10,2 14,8 10,18 6,8" stroke="#0c84b0" strokeWidth="0.8" fill="none" />
              </svg>
              <span className="font-bengali-ui tabular-nums text-xs font-bold text-[#bdf2ff] sm:text-sm">
                ১২০
              </span>
            </div>
          </div>
        </div>

        {/* Top-Right: Compact Game Emblem + Best Score + Mute Toggle */}
        <div className="flex items-center gap-2">
          <div className="hidden flex-col items-end sm:flex">
            <div className="flex items-center gap-2">
              <span className="font-bengali-display text-lg font-extrabold tracking-wide text-[#ffd875] drop-shadow-[0_2px_8px_rgba(0,0,0,0.85)]">
                বাংলার যোদ্ধা
              </span>
            </div>
            {highScore > 0 ? (
              <span className="font-bengali-ui text-[11px] font-semibold text-[#f5ddb2]">
                সেরা স্কোর: <span className="tabular-nums text-[#ffd262]">{toBengaliNumber(highScore)}</span>
              </span>
            ) : (
              <span className="font-bengali-ui text-[11px] font-medium text-[#e9cfa8]/85">
                হুগলি তীর · পশ্চিমবঙ্গ
              </span>
            )}
          </div>

          <button
            type="button"
            onClick={onToggleMute}
            aria-label={muted ? 'শব্দ চালু করুন' : 'শব্দ বন্ধ করুন'}
            className="pointer-events-auto flex h-10 w-10 items-center justify-center rounded-xl border border-[#f0c268]/45 bg-[#19110c]/86 text-[#fdebd0] shadow hover:bg-[#2a1c14]"
          >
            {muted ? (
              <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-2">
                <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                <line x1="22" y1="9" x2="16" y2="15" strokeLinecap="round" />
                <line x1="16" y1="9" x2="22" y2="15" strokeLinecap="round" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-2">
                <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                <path d="M15.5 8.5a5 5 0 0 1 0 7" strokeLinecap="round" />
                <path d="M18.8 5.5a9 9 0 0 1 0 13" strokeLinecap="round" />
              </svg>
            )}
          </button>
        </div>
      </div>

      {/* MIDDLE ROW: Left-Side Free Fire Lobby Menu Rail + Contextual Popover Drawer */}
      <div className="my-auto flex items-center justify-start gap-3">
        {/* Left Vertical Menu Buttons */}
        <div className="pointer-events-auto flex flex-col gap-2.5">
          {/* 1. চরিত্র (Character) */}
          <button
            type="button"
            onClick={() => togglePanel('character')}
            className={`group flex w-[132px] items-center gap-2.5 rounded-r-xl rounded-l-md border-l-4 px-3 py-2.5 text-left shadow-[0_6px_18px_rgba(0,0,0,0.48)] transition-transform active:scale-95 sm:w-[148px] ${
              activePanel === 'character'
                ? 'border-l-[#ffd23f] border-y border-r border-[#ffd23f]/65 bg-[#2d1c11]/94 text-[#fff4d4]'
                : 'border-l-[#d6342c] border-y border-r border-[#e8bc6a]/35 bg-[#18100b]/84 text-[#f5e3c6] hover:bg-[#241811]/92'
            }`}
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5 shrink-0 fill-none stroke-[#ffd05b] stroke-2">
              <circle cx="12" cy="7.5" r="3.5" />
              <path d="M5 20c0-3.8 3.1-6.5 7-6.5s7 2.7 7 6.5" strokeLinecap="round" />
            </svg>
            <div>
              <div className="font-bengali-ui text-sm font-bold leading-tight">চরিত্র</div>
              <div className="font-bengali-ui text-[10px] text-[#d6ba91]">
                {gamchaStyle === 'red-white' ? 'লাল-সাদা গামছা' : 'সবুজ-সাদা গামছা'}
              </div>
            </div>
          </button>

          {/* 2. অস্ত্র (Weapons) */}
          <button
            type="button"
            onClick={() => togglePanel('weapon')}
            className={`group flex w-[132px] items-center gap-2.5 rounded-r-xl rounded-l-md border-l-4 px-3 py-2.5 text-left shadow-[0_6px_18px_rgba(0,0,0,0.48)] transition-transform active:scale-95 sm:w-[148px] ${
              activePanel === 'weapon'
                ? 'border-l-[#ffd23f] border-y border-r border-[#ffd23f]/65 bg-[#2d1c11]/94 text-[#fff4d4]'
                : 'border-l-[#f0a52c] border-y border-r border-[#e8bc6a]/35 bg-[#18100b]/84 text-[#f5e3c6] hover:bg-[#241811]/92'
            }`}
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5 shrink-0 fill-none stroke-[#ffd05b] stroke-2">
              <path d="M3 11h14l4-2v4l-4-1H13l-2 5H8l1-5H5l-2 2v-3z" strokeLinejoin="round" />
            </svg>
            <div>
              <div className="font-bengali-ui text-sm font-bold leading-tight">অস্ত্র</div>
              <div className="font-bengali-ui text-[10px] text-[#d6ba91]">
                {weaponType === 'rifle' ? 'রাইফেল' : 'শটগান'}
              </div>
            </div>
          </button>

          {/* 3. ম্যাপ: বাংলা (Map) */}
          <button
            type="button"
            onClick={() => togglePanel('map')}
            className={`group flex w-[132px] items-center gap-2.5 rounded-r-xl rounded-l-md border-l-4 px-3 py-2.5 text-left shadow-[0_6px_18px_rgba(0,0,0,0.48)] transition-transform active:scale-95 sm:w-[148px] ${
              activePanel === 'map'
                ? 'border-l-[#ffd23f] border-y border-r border-[#ffd23f]/65 bg-[#2d1c11]/94 text-[#fff4d4]'
                : 'border-l-[#349e56] border-y border-r border-[#e8bc6a]/35 bg-[#18100b]/84 text-[#f5e3c6] hover:bg-[#241811]/92'
            }`}
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5 shrink-0 fill-none stroke-[#ffd05b] stroke-2">
              <path d="M12 21s-6-5.2-6-10a6 6 0 1 1 12 0c0 4.8-6 10-6 10z" />
              <circle cx="12" cy="11" r="2.2" />
            </svg>
            <div>
              <div className="font-bengali-ui text-sm font-bold leading-tight">ম্যাপ: বাংলা</div>
              <div className="font-bengali-ui text-[10px] text-[#d6ba91]">হুগলি ও হাওড়া</div>
            </div>
          </button>
        </div>

        {/* Compact Contextual Customization Sub-Panel (opens right beside menu, never covers center hero) */}
        {activePanel === 'character' && (
          <div className="pointer-events-auto w-[224px] rounded-xl border border-[#f5c763]/55 bg-[#1a110c]/92 p-3.5 shadow-[0_12px_32px_rgba(0,0,0,0.62)]">
            <div className="mb-2.5 flex items-center justify-between">
              <span className="font-bengali-ui text-sm font-bold text-[#ffd978]">
                গামছার রঙ বাছুন
              </span>
              <button
                type="button"
                onClick={() => setActivePanel(null)}
                aria-label="বন্ধ করুন"
                className="text-xs font-bold text-[#ccb38e] hover:text-white"
              >
                ✕
              </button>
            </div>
            <div className="flex flex-col gap-2">
              <button
                type="button"
                onClick={() => onSelectGamcha('red-white')}
                className={`flex items-center gap-3 rounded-lg border px-3 py-2 text-left transition-colors ${
                  gamchaStyle === 'red-white'
                    ? 'border-[#ffd24c] bg-[#361813] text-[#fff6e3]'
                    : 'border-[#e8bc6a]/25 bg-[#231710] text-[#dfcaa8] hover:bg-[#2d1e15]'
                }`}
              >
                <span className="flex h-7 w-7 shrink-0 overflow-hidden rounded-md border border-[#fff2d9]/60">
                  <span className="h-full w-1/2 bg-[#c81f26]" />
                  <span className="h-full w-1/2 bg-[#faf3e6]" />
                </span>
                <div>
                  <div className="font-bengali-ui text-xs font-bold">লাল-সাদা গামছা</div>
                  <div className="font-bengali-ui text-[10px] text-[#c8b08a]">ঐতিহ্যবাহী বাংলা</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => onSelectGamcha('green-white')}
                className={`flex items-center gap-3 rounded-lg border px-3 py-2 text-left transition-colors ${
                  gamchaStyle === 'green-white'
                    ? 'border-[#ffd24c] bg-[#16301d] text-[#fff6e3]'
                    : 'border-[#e8bc6a]/25 bg-[#231710] text-[#dfcaa8] hover:bg-[#2d1e15]'
                }`}
              >
                <span className="flex h-7 w-7 shrink-0 overflow-hidden rounded-md border border-[#fff2d9]/60">
                  <span className="h-full w-1/2 bg-[#1c7c3e]" />
                  <span className="h-full w-1/2 bg-[#faf3e6]" />
                </span>
                <div>
                  <div className="font-bengali-ui text-xs font-bold">সবুজ-সাদা গামছা</div>
                  <div className="font-bengali-ui text-[10px] text-[#c8b08a]">নদী তীরের স্টাইল</div>
                </div>
              </button>
            </div>
          </div>
        )}

        {activePanel === 'weapon' && (
          <div className="pointer-events-auto w-[236px] rounded-xl border border-[#f5c763]/55 bg-[#1a110c]/92 p-3.5 shadow-[0_12px_32px_rgba(0,0,0,0.62)]">
            <div className="mb-2.5 flex items-center justify-between">
              <span className="font-bengali-ui text-sm font-bold text-[#ffd978]">
                অস্ত্র নির্বাচন
              </span>
              <button
                type="button"
                onClick={() => setActivePanel(null)}
                aria-label="বন্ধ করুন"
                className="text-xs font-bold text-[#ccb38e] hover:text-white"
              >
                ✕
              </button>
            </div>
            <div className="flex flex-col gap-2">
              {/* Rifle Option */}
              <button
                type="button"
                onClick={() => onSelectWeapon('rifle')}
                className={`rounded-lg border p-2.5 text-left transition-colors ${
                  weaponType === 'rifle'
                    ? 'border-[#ffd24c] bg-[#302012] text-[#fff6e3]'
                    : 'border-[#e8bc6a]/25 bg-[#231710] text-[#dfcaa8] hover:bg-[#2d1e15]'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bengali-ui text-xs font-bold">কার্বাইন রাইফেল</span>
                  <span className="font-bengali-ui text-[10px] font-semibold text-[#ffd262]">
                    ২৪ গুলি
                  </span>
                </div>
                <div className="mt-1.5 space-y-1 text-[10px] text-[#cdb591]">
                  <div className="flex items-center gap-2">
                    <span className="w-10">গতি</span>
                    <div className="h-1.5 flex-1 rounded-full bg-[#3a281c]">
                      <div className="h-full w-[85%] rounded-full bg-[#f5c03e]" />
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-10">রেঞ্জ</span>
                    <div className="h-1.5 flex-1 rounded-full bg-[#3a281c]">
                      <div className="h-full w-[80%] rounded-full bg-[#f5c03e]" />
                    </div>
                  </div>
                </div>
              </button>

              {/* Shotgun Option */}
              <button
                type="button"
                onClick={() => onSelectWeapon('shotgun')}
                className={`rounded-lg border p-2.5 text-left transition-colors ${
                  weaponType === 'shotgun'
                    ? 'border-[#ffd24c] bg-[#302012] text-[#fff6e3]'
                    : 'border-[#e8bc6a]/25 bg-[#231710] text-[#dfcaa8] hover:bg-[#2d1e15]'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bengali-ui text-xs font-bold">পাম্প শটগান</span>
                  <span className="font-bengali-ui text-[10px] font-semibold text-[#ffd262]">
                    ৮ শেল · ৫x
                  </span>
                </div>
                <div className="mt-1.5 space-y-1 text-[10px] text-[#cdb591]">
                  <div className="flex items-center gap-2">
                    <span className="w-10">ক্ষতি</span>
                    <div className="h-1.5 flex-1 rounded-full bg-[#3a281c]">
                      <div className="h-full w-[95%] rounded-full bg-[#ee6034]" />
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-10">রেঞ্জ</span>
                    <div className="h-1.5 flex-1 rounded-full bg-[#3a281c]">
                      <div className="h-full w-[48%] rounded-full bg-[#f5c03e]" />
                    </div>
                  </div>
                </div>
              </button>
            </div>
          </div>
        )}

        {activePanel === 'map' && (
          <div className="pointer-events-auto w-[236px] rounded-xl border border-[#f5c763]/55 bg-[#1a110c]/92 p-3.5 shadow-[0_12px_32px_rgba(0,0,0,0.62)]">
            <div className="mb-2 flex items-center justify-between">
              <span className="font-bengali-ui text-sm font-bold text-[#ffd978]">
                ম্যাপ: বাংলা
              </span>
              <button
                type="button"
                onClick={() => setActivePanel(null)}
                aria-label="বন্ধ করুন"
                className="text-xs font-bold text-[#ccb38e] hover:text-white"
              >
                ✕
              </button>
            </div>
            <div className="rounded-lg border border-[#e7b96b]/30 bg-[#251810] p-2.5">
              <div className="font-bengali-display text-sm font-bold text-[#fff1d0]">
                হুগলি তীর · পশ্চিমবঙ্গ
              </div>
              <p className="font-bengali-ui mt-1 text-[11px] leading-relaxed text-[#d7be98]">
                হাওড়া ব্রিজের পটভূমিতে বাংলার মাটির গ্রাম, নারকেল বাগান এবং হলুদ অ্যাম্বাসেডর ট্যাক্সির মাঝে সার্ভাইভাল যুদ্ধ।
              </p>
              <div className="mt-2 flex flex-wrap gap-1.5 text-[10px] font-semibold text-[#ffe08f]">
                <span className="rounded bg-[#3b2517] px-1.5 py-0.5">হাওড়া সেতু</span>
                <span className="rounded bg-[#3b2517] px-1.5 py-0.5">মাটির ঘর</span>
                <span className="rounded bg-[#3b2517] px-1.5 py-0.5">হলুদ ট্যাক্সি</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* BOTTOM BAR: Drag-to-Rotate Hint (Center-Left) + Large Glowing Yellow Start Button (Bottom-Right) */}
      <div className="flex items-end justify-between gap-3">
        {/* Bottom-Left Subtle Control Hint */}
        <div className="hidden sm:block">
          <p className="font-bengali-ui text-xs font-medium text-[#edd9b9]/85 drop-shadow">
            WASD / জয়স্টিক চলাচল · ক্লিক / গুলি ফায়ার · R রিলোড
          </p>
        </div>

        {/* Bottom-Center Subtle 3D Character Drag-to-Rotate Cue */}
        <div className="mx-auto flex items-center gap-2 rounded-full border border-[#f5c763]/35 bg-[#18100b]/74 px-3.5 py-1 text-[11px] font-semibold text-[#f5e1be] sm:mx-0">
          <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 fill-none stroke-[#ffd05b] stroke-2">
            <path d="M12 5l-5 5 5 5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <span className="font-bengali-ui">চরিত্র ঘোরাতে টেনে নিন</span>
          <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 fill-none stroke-[#ffd05b] stroke-2">
            <path d="M8 5l5 5-5 5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>

        {/* Bottom-Right: Large Glowing Yellow Free Fire-Style 'খেলা শুরু করুন' Button */}
        <div className="pointer-events-auto flex flex-col items-end gap-1">
          <div className="flex items-center gap-2 pr-1 text-[11px] font-semibold text-[#ffe5a3] drop-shadow">
            <span className="font-bengali-ui">সার্ভাইভাল মোড · ম্যাপ: বাংলা</span>
          </div>
          <button
            type="button"
            onClick={onStart}
            className="font-bengali-display group relative flex items-center gap-3 overflow-hidden rounded-xl border-2 border-[#fff4b8] bg-gradient-to-b from-[#ffe24a] via-[#f7b818] to-[#df8608] px-7 py-3.5 text-xl font-extrabold tracking-wide text-[#241205] shadow-[0_0_28px_rgba(255,194,32,0.72),0_10px_28px_rgba(0,0,0,0.6)] transition-transform duration-150 hover:scale-[1.03] hover:brightness-105 active:scale-[0.97] sm:px-9 sm:py-4 sm:text-2xl"
          >
            {/* Subtle glossy diagonal highlight */}
            <span className="pointer-events-none absolute -left-8 top-0 h-full w-16 -skew-x-20 bg-white/25 transition-transform duration-300 group-hover:translate-x-56" />
            <span className="relative">খেলা শুরু করুন</span>
            <svg
              viewBox="0 0 24 24"
              className="relative h-6 w-6 fill-[#241205] transition-transform duration-150 group-hover:translate-x-1"
            >
              <path d="M8 5v14l11-7z" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};
