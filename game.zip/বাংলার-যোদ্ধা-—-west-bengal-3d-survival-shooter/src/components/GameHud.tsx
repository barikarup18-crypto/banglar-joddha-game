import React from 'react';
import { toBengaliNumber } from '../game/GameEngine';
import { HudSnapshot } from '../game/types';

interface GameHudProps {
  hud: HudSnapshot;
  onPause: () => void;
  onToggleMute: () => void;
  onExitBus: () => void;
  onEnterBus: () => void;
  onBusHorn: () => void;
}

export const GameHud: React.FC<GameHudProps> = ({
  hud,
  onPause,
  onToggleMute,
  onExitBus,
  onEnterBus,
  onBusHorn,
}) => {
  const healthPct = Math.max(0, Math.min(100, (hud.health / hud.maxHealth) * 100));
  const lowHealth = healthPct <= 30;
  const lowAmmo = hud.ammo <= 5 && !hud.isReloading;

  return (
    <div className="pointer-events-none fixed inset-0 z-10 overflow-hidden">
      {/* Damage Red Vignette Flash */}
      {hud.damageFlash > 0.02 && (
        <div
          style={{
            opacity: Math.min(0.85, hud.damageFlash),
            boxShadow: 'inset 0 0 110px 36px rgba(196, 20, 24, 0.85)',
          }}
          className="pointer-events-none fixed inset-0"
        />
      )}

      {/* Top Perimeter Status Row */}
      <div className="flex items-start justify-between px-4 pt-3.5 sm:px-6 sm:pt-4">
        {/* Top-Left: Health ('স্বাস্থ্য') + Wave & Score */}
        <div className="flex flex-col gap-2">
          {/* Health Bar Card (solid/rgba Bengal terracotta-espresso, zero backdrop-filter) */}
          <div className="w-[218px] rounded-xl border border-[#e7b96b]/45 bg-[#1b120d]/84 px-3.5 py-2.5 shadow-[0_6px_18px_rgba(0,0,0,0.42)] sm:w-[250px]">
            <div className="mb-1.5 flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <svg viewBox="0 0 20 20" className="h-4 w-4 fill-[#e03a32]">
                  <path d="M10 17.5l-1.2-1.1C4.4 12.5 1.8 10.1 1.8 7.1 1.8 4.7 3.7 2.8 6.1 2.8c1.4 0 2.7.7 3.9 1.8 1.2-1.1 2.5-1.8 3.9-1.8 2.4 0 4.3 1.9 4.3 4.3 0 3-2.6 5.4-7 9.3L10 17.5z" />
                </svg>
                <span className="font-bengali-ui text-sm font-bold tracking-wide text-[#fdf1dc]">
                  স্বাস্থ্য
                </span>
              </div>
              <span
                className={`font-bengali-ui tabular-nums text-sm font-bold ${
                  lowHealth ? 'text-[#ff6961]' : 'text-[#f8d794]'
                }`}
              >
                {toBengaliNumber(hud.health)} / {toBengaliNumber(hud.maxHealth)}
              </span>
            </div>
            <div className="h-2.5 w-full overflow-hidden rounded-full bg-[#36231a]">
              <div
                style={{ width: `${healthPct}%` }}
                className={`h-full rounded-full transition-[width] duration-150 ${
                  lowHealth ? 'bg-[#e32d2d]' : 'bg-gradient-to-r from-[#c42429] to-[#ef7d3b]'
                }`}
              />
            </div>
          </div>

          {/* Compact Wave / Enemies / Score Bar */}
          <div className="flex items-center gap-2">
            <div className="rounded-lg border border-[#e7b96b]/35 bg-[#1b120d]/82 px-2.5 py-1 text-xs font-semibold text-[#f9e7c8]">
              <span className="text-[#d9a85c]">তরঙ্গ </span>
              <span className="tabular-nums font-bold">{toBengaliNumber(hud.wave)}</span>
            </div>
            <div className="rounded-lg border border-[#e7b96b]/35 bg-[#1b120d]/82 px-2.5 py-1 text-xs font-semibold text-[#f9e7c8]">
              <span className="text-[#e36c5b]">শত্রু </span>
              <span className="tabular-nums font-bold">{toBengaliNumber(hud.enemiesRemaining)}</span>
            </div>
            <div className="rounded-lg border border-[#e7b96b]/35 bg-[#1b120d]/82 px-2.5 py-1 text-xs font-semibold text-[#f9e7c8]">
              <span className="text-[#f0c563]">স্কোর </span>
              <span className="tabular-nums font-bold">{toBengaliNumber(hud.score)}</span>
            </div>
          </div>
        </div>

        {/* Top-Right: Ammo ('গুলি') OR Bus Speed Badge + Mute & Pause Buttons */}
        <div className="flex items-start gap-2.5">
          {hud.busMode === 'driving' ? (
            <div className="rounded-xl border border-[#5cb6ff]/55 bg-[#0e1c2b]/88 px-3.5 py-2 text-right shadow-[0_6px_18px_rgba(0,0,0,0.45)]">
              <div className="font-bengali-ui text-[11px] font-bold tracking-wide text-[#ffd65c]">
                WBTC বাস গতি
              </div>
              <div className="font-bengali-ui tabular-nums mt-0.5 text-lg font-bold leading-tight text-[#fff7e2]">
                {toBengaliNumber(hud.busSpeedKmh)}{' '}
                <span className="text-xs font-semibold text-[#a5d2f7]">কিমি/ঘ</span>
              </div>
            </div>
          ) : (
            <div className="rounded-xl border border-[#e7b96b]/45 bg-[#1b120d]/84 px-3.5 py-2 text-right shadow-[0_6px_18px_rgba(0,0,0,0.42)]">
              <div className="flex items-center justify-end gap-1.5">
                <svg viewBox="0 0 20 20" className="h-4 w-4 fill-[#f4c04e]">
                  <path d="M5 17h3V8.5L6.5 3 5 8.5V17zm7 0h3V8.5L13.5 3 12 8.5V17z" />
                </svg>
                <span className="font-bengali-ui text-xs font-bold uppercase tracking-wider text-[#f3cb77]">
                  গুলি
                </span>
              </div>
              {hud.isReloading ? (
                <div className="mt-1 w-24">
                  <div className="font-bengali-ui text-[11px] font-semibold text-[#ffd67d]">
                    রিলোড হচ্ছে...
                  </div>
                  <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-[#3a291e]">
                    <div
                      style={{ width: `${Math.round(hud.reloadProgress * 100)}%` }}
                      className="h-full bg-[#f5c049]"
                    />
                  </div>
                </div>
              ) : (
                <div className="font-bengali-ui tabular-nums mt-0.5 text-lg font-bold leading-tight">
                  <span className={lowAmmo ? 'text-[#ff6961]' : 'text-[#fff5e1]'}>
                    {toBengaliNumber(hud.ammo)}
                  </span>
                  <span className="mx-1 text-xs text-[#c7a980]">/</span>
                  <span className="text-sm text-[#d9bd96]">{toBengaliNumber(hud.reserveAmmo)}</span>
                </div>
              )}
            </div>
          )}

          {/* Mute Toggle */}
          <button
            type="button"
            onClick={onToggleMute}
            aria-label={hud.muted ? 'শব্দ চালু করুন' : 'শব্দ বন্ধ করুন'}
            className="pointer-events-auto flex h-10 w-10 items-center justify-center rounded-xl border border-[#e7b96b]/45 bg-[#1b120d]/84 text-[#fdebd0] shadow-[0_4px_14px_rgba(0,0,0,0.4)] hover:bg-[#2b1d15]"
          >
            {hud.muted ? (
              <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-2">
                <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                <line x1="22" y1="9" x2="16" y2="15" strokeLinecap="round" />
                <line x1="16" y1="9" x2="22" y2="15" strokeLinecap="round" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-2">
                <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                <path d="M15.5 8.5a5 5 0 0 1 0 7" strokeLinecap="round" />
                <path d="M18.8 5.5a9 9 0 0 1 0 13" strokeLinecap="round" />
              </svg>
            )}
          </button>

          {/* Pause Button */}
          <button
            type="button"
            onClick={onPause}
            aria-label="বিরতি"
            className="pointer-events-auto flex h-10 w-10 items-center justify-center rounded-xl border border-[#e7b96b]/45 bg-[#1b120d]/84 text-[#fdebd0] shadow-[0_4px_14px_rgba(0,0,0,0.4)] hover:bg-[#2b1d15]"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5 fill-current">
              <rect x="6" y="5" width="4" height="14" rx="1" />
              <rect x="14" y="5" width="4" height="14" rx="1" />
            </svg>
          </button>
        </div>
      </div>

      {/* Center Reticle & Hitmarker (only when on foot) */}
      {hud.busMode === 'none' && (
        <div className="pointer-events-none fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className="relative h-9 w-9">
            <span className="absolute left-1/2 top-0 h-2.5 w-[2px] -translate-x-1/2 bg-[#fff6e2]/90 shadow" />
            <span className="absolute bottom-0 left-1/2 h-2.5 w-[2px] -translate-x-1/2 bg-[#fff6e2]/90 shadow" />
            <span className="absolute left-0 top-1/2 h-[2px] w-2.5 -translate-y-1/2 bg-[#fff6e2]/90 shadow" />
            <span className="absolute right-0 top-1/2 h-[2px] w-2.5 -translate-y-1/2 bg-[#fff6e2]/90 shadow" />
            <span className="absolute left-1/2 top-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#f5c247]" />

            {hud.hitMarker > 0.05 && (
              <svg
                viewBox="0 0 36 36"
                style={{ opacity: Math.min(1, hud.hitMarker) }}
                className="absolute inset-0 h-9 w-9"
              >
                <g
                  stroke={hud.hitMarkerKill ? '#ff3838' : '#ffe078'}
                  strokeWidth={hud.hitMarkerKill ? 3 : 2.2}
                  strokeLinecap="round"
                >
                  <line x1="7" y1="7" x2="13" y2="13" />
                  <line x1="29" y1="7" x2="23" y2="13" />
                  <line x1="7" y1="29" x2="13" y2="23" />
                  <line x1="29" y1="29" x2="23" y2="23" />
                </g>
              </svg>
            )}
          </div>
        </div>
      )}

      {/* WBTC INTRO BUS RIDE UI: Route Indicator + Prominent 'বাস থেকে নামুন' (Jump / Exit Bus) Button */}
      {hud.busMode === 'riding_intro' && (
        <>
          {/* Top-Center Route Bar */}
          <div className="pointer-events-none fixed left-1/2 top-4 hidden -translate-x-1/2 flex-col items-center rounded-xl border border-[#5bb2ff]/55 bg-[#0f1d2e]/88 px-4 py-2 shadow-[0_8px_24px_rgba(0,0,0,0.48)] sm:flex">
            <div className="flex items-center gap-2 text-xs font-bold text-[#ffd85c]">
              <span>WBTC S-12</span>
              <span className="text-[#8fc8f5]">•</span>
              <span className="font-bengali-ui text-[#fff6e3]">{hud.busZoneLabel || 'হাওড়া সেতু'}</span>
            </div>
            <div className="mt-1.5 h-1.5 w-48 overflow-hidden rounded-full bg-[#1e354d]">
              <div
                style={{ width: `${Math.round(hud.busRouteProgress * 100)}%` }}
                className="h-full rounded-full bg-gradient-to-r from-[#2e9bff] via-[#ffd245] to-[#ef5338]"
              />
            </div>
          </div>

          {/* Bottom-Center Prominent Jump / Exit Bus CTA ('বাস থেকে নামুন') */}
          <div className="pointer-events-auto fixed bottom-7 left-1/2 z-30 flex -translate-x-1/2 flex-col items-center gap-2">
            <div className="rounded-lg border border-[#5bb2ff]/45 bg-[#0f1d2e]/86 px-3 py-1 text-xs font-semibold text-[#dff0ff] sm:hidden">
              {hud.busZoneLabel || 'হাওড়া সেতু'}
            </div>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onExitBus}
                className="font-bengali-display flex items-center gap-2.5 rounded-2xl border-2 border-[#fff1b5] bg-gradient-to-b from-[#ffe047] via-[#f5b415] to-[#d97c06] px-7 py-3.5 text-lg font-extrabold tracking-wide text-[#241205] shadow-[0_0_26px_rgba(255,194,32,0.68),0_10px_28px_rgba(0,0,0,0.58)] transition-transform hover:scale-[1.03] active:scale-[0.96] sm:px-9 sm:text-xl"
              >
                <svg viewBox="0 0 24 24" className="h-6 w-6 fill-none stroke-[#241205] stroke-[2.4]">
                  <path d="M12 4v12" strokeLinecap="round" />
                  <path d="M7 11l5 5 5-5" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M5 20h14" strokeLinecap="round" />
                </svg>
                <span>বাস থেকে নামুন</span>
              </button>

              <button
                type="button"
                onClick={onBusHorn}
                aria-label="হর্ন বাজান"
                className="flex h-12 w-12 items-center justify-center rounded-xl border border-[#5bb2ff]/65 bg-[#123d70]/90 text-[#ffe078] shadow-[0_6px_18px_rgba(0,0,0,0.5)] hover:bg-[#195194] active:scale-95"
              >
                <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-2">
                  <path d="M3 14v-4h4l6-4v12l-6-4H3z" strokeLinejoin="round" />
                  <path d="M17 9a4 4 0 0 1 0 6" strokeLinecap="round" />
                  <path d="M19.5 6.5a7.5 7.5 0 0 1 0 11" strokeLinecap="round" />
                </svg>
              </button>
            </div>
            <span className="font-bengali-ui text-xs font-semibold text-[#f8e7c5] drop-shadow">
              পছন্দের জায়গায় নামতে Space / F চাপুন বা বোতামে ট্যাপ করুন
            </span>
          </div>
        </>
      )}

      {/* ON-FOOT PROXIMITY PROMPT: 'বাসে উঠুন' when standing near the parked WBTC bus */}
      {hud.busMode === 'none' && hud.nearBus && (
        <div className="pointer-events-auto fixed bottom-28 left-1/2 z-30 -translate-x-1/2 sm:bottom-24">
          <button
            type="button"
            onClick={onEnterBus}
            className="font-bengali-display flex items-center gap-2.5 rounded-xl border-2 border-[#ffe27a] bg-gradient-to-b from-[#1772cc] to-[#0d4a8c] px-6 py-3 text-base font-bold tracking-wide text-[#fff9e8] shadow-[0_0_22px_rgba(30,130,235,0.6),0_8px_22px_rgba(0,0,0,0.55)] transition-transform hover:scale-[1.03] active:scale-95 sm:text-lg"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-[#ffe27a] stroke-2">
              <rect x="4" y="5" width="16" height="12" rx="2" />
              <line x1="4" y1="11" x2="20" y2="11" />
              <circle cx="8" cy="17" r="1.5" fill="#ffe27a" />
              <circle cx="16" cy="17" r="1.5" fill="#ffe27a" />
            </svg>
            <span>বাসে উঠুন</span>
            <span className="rounded bg-[#0a2f59] px-1.5 py-0.5 text-xs font-bold text-[#ffd85c]">
              F
            </span>
          </button>
        </div>
      )}

      {/* Wave Announcement Banner */}
      {hud.waveBanner && (
        <div className="pointer-events-none fixed left-1/2 top-24 -translate-x-1/2 rounded-xl border border-[#f5c768]/65 bg-[#1d120c]/88 px-6 py-2 shadow-[0_8px_28px_rgba(0,0,0,0.48)]">
          <div className="font-bengali-display text-lg font-bold tracking-wide text-[#ffe094] sm:text-2xl">
            {hud.waveBanner}
          </div>
        </div>
      )}

      {/* Pickup / Bus Action Notification Toast */}
      {hud.pickupToast && (
        <div className="pointer-events-none fixed left-1/2 top-36 -translate-x-1/2 rounded-lg border border-[#e7c06f]/55 bg-[#20160f]/86 px-4 py-1 text-sm font-bold text-[#ffebc2]">
          {hud.pickupToast}
        </div>
      )}
    </div>
  );
};
