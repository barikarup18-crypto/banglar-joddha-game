import React from 'react';
import { toBengaliNumber } from '../game/GameEngine';
import { HudSnapshot } from '../game/types';

interface StatusModalProps {
  hud: HudSnapshot;
  onResume: () => void;
  onRestart: () => void;
  onMainMenu: () => void;
}

export const StatusModal: React.FC<StatusModalProps> = ({
  hud,
  onResume,
  onRestart,
  onMainMenu,
}) => {
  if (hud.phase !== 'paused' && hud.phase !== 'gameover') return null;

  const isGameOver = hud.phase === 'gameover';

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-[#120b08]/78 px-4">
      <div className="w-full max-w-md rounded-2xl border-2 border-[#e8ba68]/55 bg-[#20140e] p-6 text-center shadow-[0_20px_60px_rgba(0,0,0,0.72)] sm:p-7">
        {/* Gamcha decorative top trim */}
        <div className="mx-auto mb-4 flex h-2 w-36 overflow-hidden rounded-full border border-[#5e2418]">
          <div className="flex-1 bg-[#c41e25]" />
          <div className="flex-1 bg-[#faf2e3]" />
          <div className="flex-1 bg-[#c41e25]" />
          <div className="flex-1 bg-[#faf2e3]" />
          <div className="flex-1 bg-[#c41e25]" />
        </div>

        <h2 className="font-bengali-display text-3xl font-bold text-[#ffd87d]">
          {isGameOver ? 'খেলা শেষ' : 'খেলা বিরতি'}
        </h2>
        <p className="font-bengali-ui mt-1.5 text-sm text-[#e3cbb0]">
          {isGameOver
            ? 'হুগলির তীর রক্ষায় আপনি বীরত্বের সাথে লড়েছেন!'
            : 'আবার যুদ্ধ শুরু করতে প্রস্তুত?'}
        </p>

        {/* Stats Grid */}
        <div className="mt-5 grid grid-cols-3 gap-2.5 rounded-xl border border-[#e7b96b]/25 bg-[#150d09] p-3.5">
          <div>
            <div className="text-xs text-[#c7a882]">স্কোর</div>
            <div className="tabular-nums mt-0.5 text-xl font-bold text-[#ffe296]">
              {toBengaliNumber(hud.score)}
            </div>
          </div>
          <div>
            <div className="text-xs text-[#c7a882]">তরঙ্গ</div>
            <div className="tabular-nums mt-0.5 text-xl font-bold text-[#f9ebd4]">
              {toBengaliNumber(hud.wave)}
            </div>
          </div>
          <div>
            <div className="text-xs text-[#c7a882]">পরাজিত শত্রু</div>
            <div className="tabular-nums mt-0.5 text-xl font-bold text-[#ff846e]">
              {toBengaliNumber(hud.kills)}
            </div>
          </div>
        </div>

        {isGameOver && hud.highScore > 0 && (
          <div className="mt-3 text-xs font-semibold text-[#e6c48a]">
            সেরা স্কোর: <span className="tabular-nums text-[#ffd26a]">{toBengaliNumber(hud.highScore)}</span>
          </div>
        )}

        {/* Action Buttons */}
        <div className="mt-6 flex flex-col gap-2.5">
          {!isGameOver ? (
            <button
              type="button"
              onClick={onResume}
              className="font-bengali-ui w-full rounded-xl border border-[#ffe199] bg-[#c42027] py-3 text-base font-bold text-[#fff6e6] shadow hover:bg-[#d6262e]"
            >
              খেলা চালিয়ে যান
            </button>
          ) : (
            <button
              type="button"
              onClick={onRestart}
              className="font-bengali-ui w-full rounded-xl border border-[#ffe199] bg-[#c42027] py-3 text-base font-bold text-[#fff6e6] shadow hover:bg-[#d6262e]"
            >
              আবার খেলুন
            </button>
          )}

          {!isGameOver && (
            <button
              type="button"
              onClick={onRestart}
              className="font-bengali-ui w-full rounded-xl border border-[#e7b96b]/45 bg-[#2e1e15] py-2.5 text-sm font-semibold text-[#f8e6c8] hover:bg-[#3d291d]"
            >
              নতুন করে শুরু করুন
            </button>
          )}

          <button
            type="button"
            onClick={onMainMenu}
            className="font-bengali-ui w-full rounded-xl border border-[#e7b96b]/30 bg-transparent py-2.5 text-sm font-semibold text-[#d9bfa0] hover:bg-[#2a1b13]"
          >
            মূল মেনু
          </button>
        </div>
      </div>
    </div>
  );
};
