import React, { useRef, useState } from 'react';
import { BusMode } from '../game/types';

interface TouchControlsProps {
  busMode: BusMode;
  onMove: (x: number, y: number) => void;
  onShootChange: (shooting: boolean) => void;
  onSprintChange: (sprinting: boolean) => void;
  onReload: () => void;
  onExitBus: () => void;
  onBusHorn: () => void;
  isReloading: boolean;
  ammo: number;
  maxAmmo: number;
  reserveAmmo: number;
}

const JOYSTICK_RADIUS = 46;
const DEADZONE = 0.1;

export const TouchControls: React.FC<TouchControlsProps> = ({
  busMode,
  onMove,
  onShootChange,
  onSprintChange,
  onReload,
  onExitBus,
  onBusHorn,
  isReloading,
  ammo,
  maxAmmo,
  reserveAmmo,
}) => {
  const baseRef = useRef<HTMLDivElement | null>(null);
  const joyPointerId = useRef<number | null>(null);
  const shootPointerId = useRef<number | null>(null);
  const sprintPointerId = useRef<number | null>(null);

  const [knobOffset, setKnobOffset] = useState({ x: 0, y: 0 });
  const [joyActive, setJoyActive] = useState(false);
  const [shootPressed, setShootPressed] = useState(false);
  const [sprintPressed, setSprintPressed] = useState(false);

  // Hide touch shooter/steering pads while watching the WBTC intro bus drop-in
  if (busMode === 'riding_intro') return null;

  const updateJoystick = (clientX: number, clientY: number) => {
    const el = baseRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;

    let dx = clientX - cx;
    let dy = clientY - cy;
    const dist = Math.hypot(dx, dy);

    if (dist > JOYSTICK_RADIUS) {
      dx = (dx / dist) * JOYSTICK_RADIUS;
      dy = (dy / dist) * JOYSTICK_RADIUS;
    }

    setKnobOffset({ x: dx, y: dy });

    const nx = dx / JOYSTICK_RADIUS;
    const ny = -dy / JOYSTICK_RADIUS; // forward is up on screen
    const mag = Math.hypot(nx, ny);
    if (mag < DEADZONE) {
      onMove(0, 0);
    } else {
      onMove(nx, ny);
    }
  };

  const handleJoyDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.stopPropagation();
    if (joyPointerId.current !== null) return;
    joyPointerId.current = e.pointerId;
    e.currentTarget.setPointerCapture(e.pointerId);
    setJoyActive(true);
    updateJoystick(e.clientX, e.clientY);
  };

  const handleJoyMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerId !== joyPointerId.current) return;
    e.stopPropagation();
    updateJoystick(e.clientX, e.clientY);
  };

  const handleJoyUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerId !== joyPointerId.current) return;
    e.stopPropagation();
    joyPointerId.current = null;
    setJoyActive(false);
    setKnobOffset({ x: 0, y: 0 });
    onMove(0, 0);
  };

  const handleShootDown = (e: React.PointerEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    if (shootPointerId.current !== null) return;
    shootPointerId.current = e.pointerId;
    e.currentTarget.setPointerCapture(e.pointerId);
    setShootPressed(true);
    onShootChange(true);
  };

  const handleShootUp = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerId !== shootPointerId.current) return;
    e.stopPropagation();
    shootPointerId.current = null;
    setShootPressed(false);
    onShootChange(false);
  };

  const handleSprintDown = (e: React.PointerEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    if (sprintPointerId.current !== null) return;
    sprintPointerId.current = e.pointerId;
    e.currentTarget.setPointerCapture(e.pointerId);
    setSprintPressed(true);
    onSprintChange(true);
  };

  const handleSprintUp = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerId !== sprintPointerId.current) return;
    e.stopPropagation();
    sprintPointerId.current = null;
    setSprintPressed(false);
    onSprintChange(false);
  };

  const canReload = !isReloading && ammo < maxAmmo && reserveAmmo > 0;
  const isDriving = busMode === 'driving';

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-0 z-20 flex items-end justify-between px-4 pb-5 sm:px-7 sm:pb-6">
      {/* Bottom-Left: Mobile Touch Virtual Joystick (Movement on foot / Steering & Throttle in bus) */}
      <div className="pointer-events-auto flex flex-col items-center gap-1.5">
        <div
          ref={baseRef}
          onPointerDown={handleJoyDown}
          onPointerMove={handleJoyMove}
          onPointerUp={handleJoyUp}
          onPointerCancel={handleJoyUp}
          aria-label={isDriving ? 'বাস চালনা জয়স্টিক' : 'চলাচল জয়স্টিক'}
          role="slider"
          aria-valuenow={Math.round(Math.hypot(knobOffset.x, knobOffset.y))}
          className={`relative flex h-[122px] w-[122px] touch-none items-center justify-center rounded-full border-2 shadow-[0_8px_24px_rgba(0,0,0,0.45)] ${
            isDriving
              ? 'border-[#67beff]/65 bg-[#0f1d2e]/78'
              : 'border-[#f3c669]/55 bg-[#1b120d]/72'
          }`}
        >
          <div className="pointer-events-none absolute inset-2.5 rounded-full border border-[#f3c669]/22" />
          <div className="pointer-events-none absolute top-2.5 h-1.5 w-1.5 rounded-full bg-[#f3c669]/55" />
          <div className="pointer-events-none absolute bottom-2.5 h-1.5 w-1.5 rounded-full bg-[#f3c669]/55" />
          <div className="pointer-events-none absolute left-2.5 h-1.5 w-1.5 rounded-full bg-[#f3c669]/55" />
          <div className="pointer-events-none absolute right-2.5 h-1.5 w-1.5 rounded-full bg-[#f3c669]/55" />

          {/* Draggable Thumbstick Puck */}
          <div
            style={{
              transform: `translate3d(${knobOffset.x}px, ${knobOffset.y}px, 0)`,
            }}
            className={`pointer-events-none flex h-12 w-12 items-center justify-center rounded-full border-2 transition-colors duration-75 ${
              isDriving
                ? joyActive
                  ? 'border-[#fff2d6] bg-[#1a7ad9]'
                  : 'border-[#7bc8ff]/80 bg-[#124d8c]/90'
                : joyActive
                  ? 'border-[#fff2d6] bg-[#c9282d]'
                  : 'border-[#f5ca72]/80 bg-[#8d2c22]/90'
            } shadow-[0_4px_12px_rgba(0,0,0,0.5)]`}
          >
            <div className="h-3.5 w-3.5 rounded-full bg-[#fff5e4]/85" />
          </div>
        </div>
        <span className="font-bengali-ui text-[11px] font-semibold tracking-wide text-[#f6e3c2]/85 drop-shadow">
          {isDriving ? 'বাস চালনা' : 'চলাচল'}
        </span>
      </div>

      {/* Bottom-Right: Bus Driving Controls OR On-Foot Shooter Buttons */}
      {isDriving ? (
        <div className="pointer-events-auto flex items-end gap-3 pb-1">
          <button
            type="button"
            onPointerDown={(e) => {
              e.stopPropagation();
              onBusHorn();
            }}
            className="flex h-14 w-14 touch-none flex-col items-center justify-center rounded-full border-2 border-[#7ac6ff]/75 bg-[#103866]/92 text-[#ffe17a] shadow-[0_6px_18px_rgba(0,0,0,0.5)] active:scale-95"
            aria-label="হর্ন"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-2">
              <path d="M3 14v-4h4l6-4v12l-6-4H3z" strokeLinejoin="round" />
              <path d="M17 9a4 4 0 0 1 0 6" strokeLinecap="round" />
            </svg>
            <span className="font-bengali-ui text-[10px] font-bold leading-none">হর্ন</span>
          </button>

          <button
            type="button"
            onPointerDown={(e) => {
              e.stopPropagation();
              onExitBus();
            }}
            className="font-bengali-display flex items-center gap-2 rounded-2xl border-2 border-[#fff0b3] bg-gradient-to-b from-[#ffe047] via-[#f4b114] to-[#d97c06] px-6 py-4 text-base font-extrabold text-[#241205] shadow-[0_8px_24px_rgba(0,0,0,0.55)] active:scale-95 sm:text-lg"
          >
            <span>বাস থেকে নামুন</span>
            <span className="rounded bg-[#241205]/20 px-1.5 py-0.5 text-xs font-bold">F</span>
          </button>
        </div>
      ) : (
        <div className="pointer-events-auto flex items-end gap-3">
          <div className="flex flex-col gap-2.5 pb-1">
            {/* Reload Button */}
            <button
              type="button"
              onPointerDown={(e) => {
                e.stopPropagation();
                onReload();
              }}
              disabled={!canReload}
              className={`flex h-12 w-12 touch-none flex-col items-center justify-center rounded-full border text-xs font-bold shadow-[0_4px_14px_rgba(0,0,0,0.45)] transition-transform active:scale-95 ${
                canReload
                  ? 'border-[#f4c66a]/75 bg-[#2a1c14]/88 text-[#fdeccf]'
                  : 'border-[#f4c66a]/25 bg-[#1b130e]/65 text-[#bca98f]/50'
              }`}
              aria-label="রিলোড"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current stroke-2">
                <path d="M21 12a9 9 0 1 1-2.64-6.36" strokeLinecap="round" />
                <path d="M21 3v6h-6" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <span className="font-bengali-ui mt-0.5 text-[10px] leading-none">রিলোড</span>
            </button>

            {/* Sprint Button */}
            <button
              type="button"
              onPointerDown={handleSprintDown}
              onPointerUp={handleSprintUp}
              onPointerCancel={handleSprintUp}
              className={`flex h-12 w-12 touch-none flex-col items-center justify-center rounded-full border text-xs font-bold shadow-[0_4px_14px_rgba(0,0,0,0.45)] transition-transform active:scale-95 ${
                sprintPressed
                  ? 'border-[#ffe6a3] bg-[#d48c20] text-[#1a110a]'
                  : 'border-[#f4c66a]/70 bg-[#2a1c14]/88 text-[#fdeccf]'
              }`}
              aria-label="দৌড়"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current stroke-2">
                <path d="M13 4L5 14h7l-1 6 8-10h-7l1-6z" strokeLinejoin="round" />
              </svg>
              <span className="font-bengali-ui mt-0.5 text-[10px] leading-none">দৌড়</span>
            </button>
          </div>

          {/* Main Shoot Button ('গুলি') */}
          <div className="flex flex-col items-center gap-1.5">
            <button
              type="button"
              onPointerDown={handleShootDown}
              onPointerUp={handleShootUp}
              onPointerCancel={handleShootUp}
              aria-label="গুলি করুন"
              className={`relative flex h-[92px] w-[92px] touch-none flex-col items-center justify-center rounded-full border-[3px] shadow-[0_10px_28px_rgba(0,0,0,0.52)] transition-transform ${
                shootPressed
                  ? 'scale-95 border-[#fff3d1] bg-[#e22b2b] text-white'
                  : 'border-[#f6c866] bg-[#b81d24]/92 text-[#fff5e4] hover:bg-[#cc232b]'
              }`}
            >
              <svg viewBox="0 0 32 32" className="h-8 w-8 fill-none stroke-current stroke-[2.2]">
                <circle cx="16" cy="16" r="9" />
                <line x1="16" y1="3" x2="16" y2="9" strokeLinecap="round" />
                <line x1="16" y1="23" x2="16" y2="29" strokeLinecap="round" />
                <line x1="3" y1="16" x2="9" y2="16" strokeLinecap="round" />
                <line x1="23" y1="16" x2="29" y2="16" strokeLinecap="round" />
                <circle cx="16" cy="16" r="2" className="fill-current" />
              </svg>
              <span className="font-bengali-ui mt-0.5 text-sm font-bold leading-none tracking-wide">
                গুলি
              </span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
