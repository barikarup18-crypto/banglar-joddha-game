import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { GameAudio } from './audio';
import {
  buildWbtcBus,
  BusRouteData,
  createBusIntroRoute,
  WbtcBusRig,
} from './bus';
import {
  buildBengaliHero,
  buildEnemyBot,
  buildPickupMesh,
  EnemyRig,
  HeroRig,
} from './characters';
import { createTextureBundle, TextureBundle } from './textures';
import {
  BusMode,
  CircleCollider,
  EnemyArchetype,
  GamchaStyle,
  GamePhase,
  HudSnapshot,
  PickupKind,
  VirtualInputState,
  WeaponType,
} from './types';
import { buildWestBengalWorld, WorldBuildResult } from './worldBuilder';

interface ActiveEnemy {
  id: number;
  archetype: EnemyArchetype;
  rig: EnemyRig;
  hp: number;
  maxHp: number;
  speed: number;
  radius: number;
  fireRange: number;
  fireCooldown: number;
  telegraphTimer: number;
  strafeDir: number;
  strafeTimer: number;
  walkPhase: number;
  hitFlashTimer: number;
  dying: boolean;
  deathTimer: number;
  knockback: THREE.Vector3;
  // Bus riding state for intro drop-in
  busSeatIndex: number; // -1 when on foot
  busDropT: number;
}

interface Bullet {
  active: boolean;
  fromPlayer: boolean;
  mesh: THREE.Mesh;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  life: number;
  damage: number;
}

interface Particle {
  active: boolean;
  mesh: THREE.Mesh;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  life: number;
  maxLife: number;
  scale: number;
}

interface PickupItem {
  id: number;
  kind: PickupKind;
  mesh: THREE.Group;
  pos: THREE.Vector3;
  life: number;
}

// Pre-allocated zero-GC scratch helpers
const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _v3 = new THREE.Vector3();
const _v4 = new THREE.Vector3();
const _camTarget = new THREE.Vector3();
const _camDesired = new THREE.Vector3();
const _lookAtPt = new THREE.Vector3();

const STORAGE_KEY_HIGHSCORE = 'banglar_joddha_high_score_v1';

const BENGALI_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
export function toBengaliNumber(n: number): string {
  return String(Math.max(0, Math.floor(n)))
    .split('')
    .map((ch) => {
      const code = ch.charCodeAt(0) - 48;
      return code >= 0 && code <= 9 ? BENGALI_DIGITS[code] : ch;
    })
    .join('');
}

export class GameEngine {
  private container: HTMLElement;
  private onHudUpdate: (snapshot: HudSnapshot) => void;
  private isSoftwareGl: boolean;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private sunLight: THREE.DirectionalLight;
  private textures: TextureBundle;
  private world: WorldBuildResult;
  private bus: WbtcBusRig;
  private busRoute: BusRouteData;
  private hero: HeroRig;
  private audio: GameAudio;

  // Game state
  private phase: GamePhase = 'title';
  private busMode: BusMode = 'none';
  private busAutoDriving = false;
  private busRouteT = 0;
  private busPos = new THREE.Vector3(-13, 0, 8.2);
  private busYaw = -Math.PI / 2;
  private busSpeed = 0;
  private busSteerAngle = 0;
  private busZoneLabel: string | null = null;
  private nearBus = false;
  // Hero parabolic jump arc when jumping off the moving bus
  private heroJumpingFromBus = false;
  private heroJumpProgress = 0;
  private heroJumpDuration = 0.55;
  private heroJumpStart = new THREE.Vector3();
  private heroJumpEnd = new THREE.Vector3();
  private heroJumpPeakY = 2.0;

  private gamchaStyle: GamchaStyle = 'red-white';
  private weaponType: WeaponType = 'rifle';
  private heroPos = new THREE.Vector3(0, 0, 7.2);
  private prevHeroPos = new THREE.Vector3(0, 0, 7.2);
  private prevHeroYaw = 0.28;
  private heroYaw = 0.28; // heroic 3/4 stance facing lobby camera
  private lobbyHeroYaw = 0.28;
  private lobbyHeroTargetYaw = 0.28;
  private lobbyShowcasePulse = 0;
  private heroWalkPhase = 0;
  private heroRecoil = 0;
  private muzzleFlashTimer = 0;
  private health = 100;
  private readonly maxHealth = 100;
  private ammo = 24;
  private maxAmmo = 24;
  private reserveAmmo = 96;
  private isReloading = false;
  private reloadTimer = 0;
  private readonly reloadDuration = 1.15;
  private fireCooldown = 0;
  private sprintStamina = 1.0;

  private score = 0;
  private highScore = 0;
  private kills = 0;
  private wave = 1;
  private waveEnemiesToSpawn: EnemyArchetype[] = [];
  private waveSpawnTimer = 0;
  private waveBreakTimer = 0;
  private waveBanner: string | null = null;
  private waveBannerTimer = 0;
  private pickupToast: string | null = null;
  private pickupToastTimer = 0;

  // Juice, Lobby & Camera Transition
  private camYaw = Math.PI; // looking north (-Z) toward the river & bridge
  private camPitch = 0.24;
  private camShake = 0;
  private hitstopTimer = 0;
  private damageFlash = 0;
  private hitMarker = 0;
  private hitMarkerKill = false;
  private titleTime = 0;
  private worldTime = 0;
  private introTransitionProgress = 1; // < 1 while sweeping from lobby into gameplay
  private readonly introTransitionDuration = 0.92;
  private introStartCamPos = new THREE.Vector3();
  private introStartLookAt = new THREE.Vector3();
  private lobbyDragActive = false;
  private lobbyDragPointerId: number | null = null;
  private lobbyLastDragX = 0;

  // Entities & Pools
  private enemies: ActiveEnemy[] = [];
  private nextEnemyId = 1;
  private pickups: PickupItem[] = [];
  private nextPickupId = 1;
  private bullets: Bullet[] = [];
  private particles: Particle[] = [];

  // Input state
  private keysHeld = new Set<string>();
  private mouseShootHeld = false;
  private dragLookActive = false;
  private dragPointerId: number | null = null;
  private lastDragX = 0;
  private lastDragY = 0;
  private virtualInput: VirtualInputState = {
    moveX: 0,
    moveY: 0,
    shooting: false,
    sprinting: false,
    reloadJustPressed: false,
    lookDeltaX: 0,
    lookDeltaY: 0,
  };

  // Loop & lifecycle
  private disposed = false;
  private frameId = 0;
  private lastFrameMs = 0;
  private hudEmitAccum = 0;

  constructor(container: HTMLElement, onHudUpdate: (snapshot: HudSnapshot) => void) {
    this.container = container;
    this.onHudUpdate = onHudUpdate;
    this.audio = new GameAudio();

    try {
      const saved = localStorage.getItem(STORAGE_KEY_HIGHSCORE);
      if (saved) this.highScore = Math.max(0, parseInt(saved, 10) || 0);
    } catch {
      // ignore storage restrictions
    }

    // Software WebGL detection from GPU renderer string (never user agent)
    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);

    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    container.appendChild(this.renderer.domElement);

    // Scene & golden-hour West Bengal atmosphere
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0xdba76f);
    this.scene.fog = new THREE.FogExp2(0xdba76f, 0.0078);

    // Mandatory studio environment map via RoomEnvironment on all devices
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    // Camera
    const aspect =
      (container.clientWidth || window.innerWidth) /
      Math.max(1, container.clientHeight || window.innerHeight);
    this.camera = new THREE.PerspectiveCamera(56, aspect, 0.15, 320);

    // Balanced warm/cool outdoor golden-hour lighting rig
    const hemi = new THREE.HemisphereLight(0x9ec8e8, 0x8a5b36, 0.92);
    this.scene.add(hemi);

    this.sunLight = new THREE.DirectionalLight(0xffdfb0, 2.35);
    this.sunLight.position.set(28, 38, -22);
    this.sunLight.castShadow = true;
    this.sunLight.shadow.mapSize.set(2048, 2048);
    const d = 34;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.sunLight.shadow.camera.near = 2;
    this.sunLight.shadow.camera.far = 115;
    this.sunLight.shadow.bias = -0.0005;
    this.sunLight.shadow.normalBias = 0.025;
    this.scene.add(this.sunLight);
    this.scene.add(this.sunLight.target);

    // Subtle warm river sunset rim fill + front-right fill so the lobby hero is well-lit
    const rimLight = new THREE.DirectionalLight(0xf59d56, 0.58);
    rimLight.position.set(-30, 14, -45);
    this.scene.add(rimLight);

    const frontFillLight = new THREE.DirectionalLight(0xffe7c2, 0.72);
    frontFillLight.position.set(16, 12, 24);
    this.scene.add(frontFillLight);

    // Procedural Textures, World, WBTC Passenger Bus & Hero
    this.textures = createTextureBundle(this.renderer);
    this.world = buildWestBengalWorld(this.textures);
    this.scene.add(this.world.worldGroup);

    this.busRoute = createBusIntroRoute();
    this.scene.add(this.busRoute.rampMesh);

    this.bus = buildWbtcBus(this.textures);
    this.bus.root.position.set(-13, 0, 8.2);
    this.scene.add(this.bus.root);

    this.hero = buildBengaliHero(this.textures);
    this.hero.root.position.copy(this.heroPos);
    this.hero.root.rotation.y = this.heroYaw;
    this.scene.add(this.hero.root);

    // Pre-allocate bullet & particle pools
    this.initPools();

    // Pre-warm shaders on GPU (skip on software WebGL)
    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.bindEvents();
    this.emitHud();

    this.lastFrameMs = performance.now();
    this.tick();
  }

  private initPools(): void {
    const playerBulletGeo = new THREE.BoxGeometry(0.06, 0.06, 0.58);
    const enemyBulletGeo = new THREE.SphereGeometry(0.11, 6, 6);
    const playerBulletMat = new THREE.MeshBasicMaterial({ color: 0xffe48a });
    const enemyBulletMat = new THREE.MeshBasicMaterial({ color: 0xff4930 });

    for (let i = 0; i < 48; i++) {
      const isPlayer = i < 28;
      const mesh = new THREE.Mesh(
        isPlayer ? playerBulletGeo : enemyBulletGeo,
        isPlayer ? playerBulletMat : enemyBulletMat,
      );
      mesh.visible = false;
      this.scene.add(mesh);
      this.bullets.push({
        active: false,
        fromPlayer: isPlayer,
        mesh,
        pos: new THREE.Vector3(),
        vel: new THREE.Vector3(),
        life: 0,
        damage: isPlayer ? 34 : 11,
      });
    }

    const partGeo = new THREE.BoxGeometry(0.13, 0.13, 0.13);
    for (let i = 0; i < 64; i++) {
      const mat = new THREE.MeshBasicMaterial({ color: 0xffb84d });
      const mesh = new THREE.Mesh(partGeo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.particles.push({
        active: false,
        mesh,
        pos: new THREE.Vector3(),
        vel: new THREE.Vector3(),
        life: 0,
        maxLife: 0.4,
        scale: 1,
      });
    }
  }

  // --- Public API for React UI ---

  public setGamchaStyle(style: GamchaStyle): void {
    this.gamchaStyle = style;
    this.hero.gamchaMaterial.map =
      style === 'green-white' ? this.textures.gamchaGreenMap : this.textures.gamchaMap;
    this.hero.gamchaMaterial.needsUpdate = true;
    this.lobbyShowcasePulse = 1.0;
    this.audio.unlock();
    this.audio.playPickup('health');
  }

  public setWeaponType(weapon: WeaponType): void {
    this.weaponType = weapon;
    this.hero.rifleGroup.visible = weapon === 'rifle';
    this.hero.shotgunGroup.visible = weapon === 'shotgun';
    this.maxAmmo = weapon === 'shotgun' ? 8 : 24;
    this.ammo = this.maxAmmo;
    this.reserveAmmo = weapon === 'shotgun' ? 40 : 96;
    this.lobbyShowcasePulse = 1.0;
    // Gently turn hero to a crisp profile angle to showcase the weapon
    if (this.phase === 'title') {
      this.lobbyHeroTargetYaw = weapon === 'shotgun' ? -0.45 : 0.32;
    }
    this.audio.unlock();
    this.audio.playReload();
    this.emitHud();
  }

  public startGame(): void {
    this.audio.unlock();
    this.clearDynamicEntities();

    const comingFromLobby = this.phase === 'title';

    this.phase = 'playing';
    this.busMode = 'riding_intro';
    this.busAutoDriving = true;
    this.busRouteT = 0.03;
    this.busSpeed = 12;
    this.busSteerAngle = 0;
    this.nearBus = false;
    this.heroJumpingFromBus = false;
    this.heroJumpProgress = 0;

    this.camYaw = Math.PI * 0.5;
    this.camPitch = 0.24;
    this.maxAmmo = this.weaponType === 'shotgun' ? 8 : 24;
    this.health = this.maxHealth;
    this.ammo = this.maxAmmo;
    this.reserveAmmo = this.weaponType === 'shotgun' ? 40 : 96;
    this.isReloading = false;
    this.reloadTimer = 0;
    this.fireCooldown = 0;
    this.sprintStamina = 1;
    this.score = 0;
    this.kills = 0;
    this.wave = 1;
    this.damageFlash = 0;
    this.hitMarker = 0;
    this.camShake = 0;
    this.pickupToast = null;
    this.lobbyDragActive = false;
    this.lobbyDragPointerId = null;

    this.hero.bodyGroup.scale.set(1, 1, 1);

    // Position the WBTC bus at the west end of the Howrah-style bridge
    this.positionBusOnIntroRoute(this.busRouteT);

    // Place hero visibly in the bus doorway/cabin
    this.bus.root.updateMatrixWorld(true);
    this.bus.heroIntroSeat.getWorldPosition(this.heroPos);
    this.hero.root.position.copy(this.heroPos);
    this.heroYaw = this.busYaw - Math.PI * 0.5;
    this.hero.root.rotation.y = this.heroYaw;

    // Load Wave 1 AI enemies onto the WBTC bus so they ride across the bridge & exit automatically!
    this.waveEnemiesToSpawn = [];
    const dropTs = [0.54, 0.62, 0.70, 0.78, 0.86, 0.93];
    const introTypes: EnemyArchetype[] = ['scout', 'scout', 'rusher', 'scout', 'rusher', 'scout'];
    for (let i = 0; i < introTypes.length; i++) {
      this.spawnEnemyOnBus(introTypes[i], i, dropTs[i]);
    }

    this.waveBanner = 'WBTC বাস — হাওড়া সেতু পারাপার';
    this.waveBannerTimer = 3.0;
    this.audio.playBusHorn();

    if (comingFromLobby) {
      // Smoothly sweep camera from the lobby hero right onto the moving WBTC bus!
      this.introStartCamPos.copy(this.camera.position);
      this.introStartLookAt.set(0.15, 1.25, -4.0);
      this.introTransitionProgress = 0;
    } else {
      this.introTransitionProgress = 1;
    }

    this.emitHud();
  }

  public exitBus(): void {
    if (this.phase !== 'playing') return;
    if (this.busMode === 'none') return;

    this.audio.unlock();
    this.audio.playBusJump();
    this.bus.root.updateMatrixWorld(true);

    if (this.busMode === 'riding_intro') {
      // Compute a dramatic safe drop landing spot onto the West Bengal village / riverbank road
      const startPos = this.heroJumpStart;
      this.bus.heroIntroSeat.getWorldPosition(startPos);

      const exitWorld = _v1;
      this.bus.doorExitPoint.getWorldPosition(exitWorld);

      const bounds = this.world.playableBounds;
      const landX = THREE.MathUtils.clamp(exitWorld.x, bounds.minX + 2.5, bounds.maxX - 2.5);
      // If player jumps early while still over the Howrah Bridge / river, land safely on the Hooghly ghat riverbank road!
      const landZ =
        exitWorld.z < -13.5
          ? -12.5
          : THREE.MathUtils.clamp(exitWorld.z, bounds.minZ + 1.5, bounds.maxZ - 2.0);

      this.heroJumpEnd.set(landX, 0, landZ);
      this.resolveCircleWorldCollision(this.heroJumpEnd, 0.65);

      const dropHeight = Math.max(0.4, startPos.y);
      this.heroJumpPeakY = Math.max(startPos.y + 1.35, 1.85);
      this.heroJumpDuration = dropHeight > 2.2 ? 0.68 : 0.36;
      this.heroJumpProgress = 0;
      this.heroJumpingFromBus = true;

      this.busMode = 'none';
      this.camYaw = Math.PI; // face north/village action cleanly
      this.camPitch = 0.22;
      this.pickupToast = 'আপনি বাস থেকে নেমেছেন!';
      this.pickupToastTimer = 2.0;
      this.emitHud();
      return;
    }

    if (this.busMode === 'driving') {
      // Hop out cleanly beside the parked/slowing bus doorway
      const exitPos = _v1;
      this.bus.doorExitPoint.getWorldPosition(exitPos);
      exitPos.y = 0;
      this.resolveCircleWorldCollision(exitPos, 0.65);
      this.heroPos.copy(exitPos);
      this.hero.root.position.copy(this.heroPos);
      this.hero.root.rotation.set(0, this.busYaw - Math.PI * 0.5, 0);
      this.heroYaw = this.busYaw - Math.PI * 0.5;
      this.camYaw = this.busYaw;
      this.busMode = 'none';
      this.pickupToast = 'বাস থেকে নেমেছেন';
      this.pickupToastTimer = 1.6;
      this.emitHud();
    }
  }

  public enterBus(): void {
    if (this.phase !== 'playing' || this.busMode !== 'none' || this.heroJumpingFromBus) return;
    if (this.busAutoDriving) return;
    const dist = this.heroPos.distanceTo(this.busPos);
    if (dist > 6.2) return;

    this.audio.unlock();
    this.audio.playBusHorn();
    this.busMode = 'driving';
    this.nearBus = false;
    this.isReloading = false;
    this.mouseShootHeld = false;
    this.virtualInput.shooting = false;
    this.pickupToast = 'WBTC বাস চালাচ্ছেন!';
    this.pickupToastTimer = 2.0;
    this.emitHud();
  }

  public honkBusHorn(): void {
    if (this.phase !== 'playing' || this.busMode === 'none') return;
    this.audio.unlock();
    this.audio.playBusHorn();
  }

  public togglePause(): void {
    if (this.phase === 'playing') {
      this.phase = 'paused';
      this.keysHeld.clear();
      this.mouseShootHeld = false;
      this.virtualInput.shooting = false;
      if (document.pointerLockElement === this.renderer.domElement) {
        document.exitPointerLock();
      }
      this.emitHud();
    } else if (this.phase === 'paused') {
      this.phase = 'playing';
      this.lastFrameMs = performance.now();
      this.emitHud();
    }
  }

  public returnToTitle(): void {
    this.clearDynamicEntities();
    this.phase = 'title';
    this.busMode = 'none';
    this.busAutoDriving = false;
    this.heroJumpingFromBus = false;
    this.nearBus = false;
    this.heroPos.set(0, 0, 7.2);
    this.lobbyHeroYaw = 0.28;
    this.lobbyHeroTargetYaw = 0.28;
    this.heroYaw = 0.28;
    this.hero.root.position.copy(this.heroPos);
    this.hero.root.rotation.set(0, this.lobbyHeroYaw, 0);
    this.hero.leftLeg.rotation.x = 0;
    this.hero.rightLeg.rotation.x = 0;
    this.hero.leftKnee.rotation.x = 0;
    this.hero.rightKnee.rotation.x = 0;
    this.hero.headGroup.rotation.set(0, 0, 0);
    this.hero.bodyGroup.position.y = 0;
    this.prevHeroPos.copy(this.heroPos);
    this.prevHeroYaw = this.lobbyHeroYaw;
    this.introTransitionProgress = 1;
    if (document.pointerLockElement === this.renderer.domElement) {
      document.exitPointerLock();
    }
    this.emitHud();
  }

  public toggleMute(): void {
    this.audio.unlock();
    this.audio.toggleMute();
    this.emitHud();
  }

  public setVirtualMove(x: number, y: number): void {
    this.virtualInput.moveX = THREE.MathUtils.clamp(x, -1, 1);
    this.virtualInput.moveY = THREE.MathUtils.clamp(y, -1, 1);
  }

  public setVirtualShoot(active: boolean): void {
    if (active) this.audio.unlock();
    this.virtualInput.shooting = active;
  }

  public setVirtualSprint(active: boolean): void {
    this.virtualInput.sprinting = active;
  }

  public triggerReload(): void {
    this.audio.unlock();
    this.virtualInput.reloadJustPressed = true;
  }

  // --- Wave & Entity Management ---

  private clearDynamicEntities(): void {
    for (const e of this.enemies) {
      this.scene.remove(e.rig.root);
    }
    this.enemies = [];
    for (const p of this.pickups) {
      this.scene.remove(p.mesh);
    }
    this.pickups = [];
    for (const b of this.bullets) {
      b.active = false;
      b.mesh.visible = false;
    }
    for (const pt of this.particles) {
      pt.active = false;
      pt.mesh.visible = false;
    }
  }

  private beginWave(waveNum: number): void {
    this.wave = waveNum;
    const totalCount = 4 + waveNum * 2;
    const queue: EnemyArchetype[] = [];

    for (let i = 0; i < totalCount; i++) {
      const r = Math.random();
      if (waveNum >= 3 && r < 0.25) {
        queue.push('heavy');
      } else if (waveNum >= 2 && r < 0.52) {
        queue.push('rusher');
      } else {
        queue.push('scout');
      }
    }

    this.waveEnemiesToSpawn = queue;
    this.waveSpawnTimer = 0.6;
    this.waveBanner = `তরঙ্গ ${toBengaliNumber(waveNum)}`;
    this.waveBannerTimer = 2.6;
    this.audio.playWaveStart();

    // Drop a helpful supply crate near the village square at start of waves >= 2
    if (waveNum >= 2) {
      const anchor = this.world.pickupAnchors[waveNum % this.world.pickupAnchors.length];
      this.spawnPickup(anchor.x, anchor.z, this.health < 65 ? 'health' : 'ammo');
    }
  }

  private spawnEnemy(archetype: EnemyArchetype): void {
    // Pick spawn point furthest from hero for fair telegraphing
    let bestPt = this.world.enemySpawnPoints[0];
    let bestDistSq = -1;
    const tries = 4;
    for (let t = 0; t < tries; t++) {
      const pt =
        this.world.enemySpawnPoints[
          Math.floor(Math.random() * this.world.enemySpawnPoints.length)
        ];
      const dSq = pt.distanceToSquared(this.heroPos);
      if (dSq > bestDistSq) {
        bestDistSq = dSq;
        bestPt = pt;
      }
    }

    const rig = buildEnemyBot(archetype, this.textures);
    rig.root.position.set(
      bestPt.x + (Math.random() - 0.5) * 2.5,
      0,
      bestPt.z + (Math.random() - 0.5) * 2.5,
    );
    this.scene.add(rig.root);

    const waveHpScale = 1 + (this.wave - 1) * 0.12;
    const maxHp =
      archetype === 'heavy'
        ? Math.round(140 * waveHpScale)
        : archetype === 'rusher'
          ? Math.round(60 * waveHpScale)
          : Math.round(82 * waveHpScale);

    const speed =
      archetype === 'heavy'
        ? 3.1
        : archetype === 'rusher'
          ? 6.1
          : 4.35;

    this.enemies.push({
      id: this.nextEnemyId++,
      archetype,
      rig,
      hp: maxHp,
      maxHp,
      speed,
      radius: archetype === 'heavy' ? 0.72 : 0.55,
      fireRange: archetype === 'rusher' ? 14 : 26,
      fireCooldown: 1.0 + Math.random() * 1.0,
      telegraphTimer: 0,
      strafeDir: Math.random() > 0.5 ? 1 : -1,
      strafeTimer: 1.4 + Math.random() * 1.8,
      walkPhase: Math.random() * Math.PI * 2,
      hitFlashTimer: 0,
      dying: false,
      deathTimer: 0,
      knockback: new THREE.Vector3(),
      busSeatIndex: -1,
      busDropT: -1,
    });
  }

  private spawnEnemyOnBus(archetype: EnemyArchetype, seatIndex: number, dropT: number): void {
    const rig = buildEnemyBot(archetype, this.textures);
    this.scene.add(rig.root);

    const maxHp = archetype === 'rusher' ? 60 : 82;
    const speed = archetype === 'rusher' ? 5.9 : 4.25;

    this.enemies.push({
      id: this.nextEnemyId++,
      archetype,
      rig,
      hp: maxHp,
      maxHp,
      speed,
      radius: 0.55,
      fireRange: archetype === 'rusher' ? 14 : 26,
      fireCooldown: 1.4 + Math.random() * 0.9,
      telegraphTimer: 0,
      strafeDir: Math.random() > 0.5 ? 1 : -1,
      strafeTimer: 1.4 + Math.random() * 1.6,
      walkPhase: Math.random() * Math.PI * 2,
      hitFlashTimer: 0,
      dying: false,
      deathTimer: 0,
      knockback: new THREE.Vector3(),
      busSeatIndex: seatIndex % this.bus.enemySeats.length,
      busDropT: dropT,
    });
  }

  private positionBusOnIntroRoute(t: number): void {
    const clampedT = THREE.MathUtils.clamp(t, 0, 1);
    this.busRoute.curve.getPointAt(clampedT, this.busPos);
    const lookT = Math.min(1, clampedT + 0.012);
    this.busRoute.curve.getPointAt(lookT, _v1);

    if (clampedT >= 0.995) {
      // Keep final west-facing heading at village bus stop
      _v1.set(this.busPos.x - 1, this.busPos.y, this.busPos.z);
    }

    this.bus.root.position.copy(this.busPos);
    this.bus.root.lookAt(_v1);
    this.busYaw = Math.atan2(_v1.x - this.busPos.x, _v1.z - this.busPos.z);

    if (clampedT < 0.35) {
      this.busZoneLabel = 'হাওড়া সেতু';
    } else if (clampedT < 0.62) {
      this.busZoneLabel = 'হুগলি ঘাট র‍্যাম্প';
    } else if (clampedT < 0.82) {
      this.busZoneLabel = 'হলুদ ট্যাক্সি চক';
    } else {
      this.busZoneLabel = 'মাটির গ্রাম সড়ক';
    }
  }

  private spawnPickup(x: number, z: number, kind: PickupKind): void {
    const mesh = buildPickupMesh(kind);
    mesh.position.set(x, 0, z);
    this.scene.add(mesh);
    this.pickups.push({
      id: this.nextPickupId++,
      kind,
      mesh,
      pos: new THREE.Vector3(x, 0, z),
      life: 28,
    });
  }

  private spawnParticles(pos: THREE.Vector3, colorHex: number, count: number, speed = 5.5): void {
    let spawned = 0;
    for (const p of this.particles) {
      if (p.active) continue;
      p.active = true;
      p.pos.copy(pos);
      p.vel.set(
        (Math.random() - 0.5) * speed * 2,
        1.5 + Math.random() * speed,
        (Math.random() - 0.5) * speed * 2,
      );
      p.maxLife = 0.24 + Math.random() * 0.26;
      p.life = p.maxLife;
      p.scale = 0.7 + Math.random() * 0.9;
      (p.mesh.material as THREE.MeshBasicMaterial).color.setHex(colorHex);
      p.mesh.position.copy(p.pos);
      p.mesh.scale.setScalar(p.scale);
      p.mesh.visible = true;
      spawned++;
      if (spawned >= count) break;
    }
  }

  private spawnBullet(
    fromPlayer: boolean,
    origin: THREE.Vector3,
    direction: THREE.Vector3,
    speed: number,
    damage: number,
  ): void {
    for (const b of this.bullets) {
      if (b.active || b.fromPlayer !== fromPlayer) continue;
      b.active = true;
      b.pos.copy(origin);
      b.vel.copy(direction).normalize().multiplyScalar(speed);
      b.life = 1.65;
      b.damage = damage;
      b.mesh.position.copy(origin);
      _v1.copy(origin).add(b.vel);
      b.mesh.lookAt(_v1);
      b.mesh.visible = true;
      return;
    }
  }

  // --- Combat & Firing ---

  private attemptStartReload(): void {
    if (this.isReloading || this.ammo >= this.maxAmmo || this.reserveAmmo <= 0) return;
    this.isReloading = true;
    this.reloadTimer = this.reloadDuration;
    this.audio.playReload();
  }

  private firePlayerWeapon(): void {
    if (this.isReloading || this.fireCooldown > 0) return;
    if (this.ammo <= 0) {
      this.fireCooldown = 0.28;
      this.audio.playDryFire();
      if (this.reserveAmmo > 0) this.attemptStartReload();
      return;
    }

    const isShotgun = this.weaponType === 'shotgun';
    this.ammo--;
    this.fireCooldown = isShotgun ? 0.56 : 0.145;
    this.heroRecoil = isShotgun ? 1.55 : 1.0;
    this.muzzleFlashTimer = isShotgun ? 0.08 : 0.05;
    this.camShake = Math.min(0.34, this.camShake + (isShotgun ? 0.17 : 0.085));
    this.audio.playPlayerShot();

    // Determine world aim direction from center camera ray + generous smart aim assist for touch/TPS feel
    const camForward = _v1.set(0, 0, -1).applyQuaternion(this.camera.quaternion).normalize();
    const aimTarget = _v2.copy(this.camera.position).addScaledVector(camForward, 45);

    // Soft tactical aim-assist toward nearest alive enemy inside a narrow central sight cone
    let bestEnemy: ActiveEnemy | null = null;
    let bestDot = 0.945; // ~19 degree assist cone
    for (const e of this.enemies) {
      if (e.dying) continue;
      _v3.copy(e.rig.root.position);
      _v3.y += 1.25;
      const toEnemy = _v4.subVectors(_v3, this.camera.position);
      const dist = toEnemy.length();
      if (dist > 44 || dist < 1.5) continue;
      toEnemy.divideScalar(dist);
      const dot = toEnemy.dot(camForward);
      if (dot > bestDot) {
        bestDot = dot;
        bestEnemy = e;
      }
    }

    if (bestEnemy) {
      aimTarget.copy(bestEnemy.rig.root.position);
      aimTarget.y += 1.2;
    }

    // Align hero facing with shot direction smoothly
    const dx = aimTarget.x - this.heroPos.x;
    const dz = aimTarget.z - this.heroPos.z;
    this.heroYaw = Math.atan2(dx, dz);
    this.hero.root.rotation.y = this.heroYaw;
    this.hero.root.updateMatrixWorld(true);

    // Origin from weapon muzzle
    const muzzleWorld = _v3;
    this.hero.muzzlePoint.getWorldPosition(muzzleWorld);

    if (isShotgun) {
      // 5-pellet close-range spread blast
      for (let p = 0; p < 5; p++) {
        const pelletDir = _v4.subVectors(aimTarget, muzzleWorld).normalize();
        pelletDir.x += (Math.random() - 0.5) * 0.11;
        pelletDir.y += (Math.random() - 0.5) * 0.06;
        pelletDir.z += (Math.random() - 0.5) * 0.11;
        pelletDir.normalize();
        this.spawnBullet(true, muzzleWorld, pelletDir, 66, 22);
      }
      this.spawnParticles(muzzleWorld, 0xffd166, 7, 3.8);
    } else {
      const bulletDir = _v4.subVectors(aimTarget, muzzleWorld).normalize();
      bulletDir.x += (Math.random() - 0.5) * 0.018;
      bulletDir.y += (Math.random() - 0.5) * 0.015;
      bulletDir.z += (Math.random() - 0.5) * 0.018;
      bulletDir.normalize();
      this.spawnBullet(true, muzzleWorld, bulletDir, 74, 34);
      this.spawnParticles(muzzleWorld, 0xffd166, 3, 2.5);
    }

    if (this.ammo === 0 && this.reserveAmmo > 0) {
      this.attemptStartReload();
    }
  }

  // --- Collision Helpers ---

  private resolveCircleWorldCollision(
    pos: THREE.Vector3,
    actorRadius: number,
    includeBusHull = true,
  ): void {
    const bounds = this.world.playableBounds;
    pos.x = THREE.MathUtils.clamp(pos.x, bounds.minX, bounds.maxX);
    pos.z = THREE.MathUtils.clamp(pos.z, bounds.minZ, bounds.maxZ);

    const colliders: CircleCollider[] = this.world.circleColliders;
    for (let i = 0; i < colliders.length; i++) {
      const c = colliders[i];
      const dx = pos.x - c.x;
      const dz = pos.z - c.z;
      const minDist = actorRadius + c.radius;
      const distSq = dx * dx + dz * dz;
      if (distSq < minDist * minDist && distSq > 0.00001) {
        const dist = Math.sqrt(distSq);
        const push = minDist - dist;
        pos.x += (dx / dist) * push;
        pos.z += (dz / dist) * push;
      }
    }

    // Solid two-circle collision against the WBTC bus when parked on village ground
    if (includeBusHull && !this.busAutoDriving && this.busPos.y < 0.5) {
      const fwdX = Math.sin(this.busYaw);
      const fwdZ = Math.cos(this.busYaw);
      const offsets = [-2.15, 2.15];
      for (const off of offsets) {
        const bx = this.busPos.x + fwdX * off;
        const bz = this.busPos.z + fwdZ * off;
        const dx = pos.x - bx;
        const dz = pos.z - bz;
        const minDist = actorRadius + 1.52;
        const distSq = dx * dx + dz * dz;
        if (distSq < minDist * minDist && distSq > 0.00001) {
          const dist = Math.sqrt(distSq);
          const push = minDist - dist;
          pos.x += (dx / dist) * push;
          pos.z += (dz / dist) * push;
        }
      }
    }
  }

  private hitsWorldObstacle(pos: THREE.Vector3): boolean {
    if (pos.y <= 0.06) return true;
    const colliders = this.world.circleColliders;
    for (let i = 0; i < colliders.length; i++) {
      const c = colliders[i];
      if (pos.y > c.height) continue;
      const dx = pos.x - c.x;
      const dz = pos.z - c.z;
      if (dx * dx + dz * dz < c.radius * c.radius) {
        return true;
      }
    }
    return false;
  }

  // --- Simulation Update ---

  private update(dt: number): void {
    this.worldTime += dt;

    // Ambient world animation (water ripples, swaying coconut palms, bobbing country boat)
    this.world.waterUniforms.uTime.value = this.worldTime;
    this.world.waterBumpTexture.offset.x = (this.worldTime * 0.03) % 1;
    this.world.waterBumpTexture.offset.y = (this.worldTime * 0.015) % 1;

    for (const palm of this.world.swayingPalms) {
      palm.crown.rotation.z = Math.sin(this.worldTime * 1.35 + palm.phase) * 0.045;
      palm.crown.rotation.x = Math.cos(this.worldTime * 1.05 + palm.phase) * 0.035;
    }

    this.world.boatGroup.position.y = -1.18 + Math.sin(this.worldTime * 1.6) * 0.09;
    this.world.boatGroup.rotation.z = Math.sin(this.worldTime * 1.3) * 0.045;

    if (this.phase === 'title') {
      this.titleTime += dt;
      // Free Fire-style 3D Main Lobby: hero stands center-stage in front of West Bengal village,
      // Yellow Ambassador Taxi, coconut palms, Hooghly River, and Howrah-style bridge.
      this.hero.root.position.set(0, 0, 7.2);

      // Scenic background WBTC bus gliding slowly across the Howrah-style bridge in the lobby!
      const lobbyBusT = 0.02 + ((this.titleTime * 0.025) % 0.3);
      this.positionBusOnIntroRoute(lobbyBusT);
      for (const w of this.bus.wheels) {
        w.rotation.x += dt * 4.5;
      }

      // Exponentially damped turntable rotation from horizontal drag
      const prevYaw = this.lobbyHeroYaw;
      const yawDamp = 1 - Math.exp(-12 * dt);
      this.lobbyHeroYaw += (this.lobbyHeroTargetYaw - this.lobbyHeroYaw) * yawDamp;
      this.hero.root.rotation.y = this.lobbyHeroYaw;
      const lobbyYawRate = (this.lobbyHeroYaw - prevYaw) / Math.max(0.001, dt);

      // Subtle heroic breathing, natural head micro-motion & showcase pop on gamcha/weapon switch
      this.lobbyShowcasePulse = Math.max(0, this.lobbyShowcasePulse - dt * 3.5);
      const breath = Math.sin(this.titleTime * 2.2) * 0.016;
      const popScale = 1 + Math.sin(this.lobbyShowcasePulse * Math.PI) * 0.04;
      this.hero.bodyGroup.position.y = breath;
      this.hero.bodyGroup.scale.set(popScale, popScale, popScale);
      this.hero.headGroup.rotation.y = Math.sin(this.titleTime * 0.85) * 0.075;
      this.hero.headGroup.rotation.x = Math.sin(this.titleTime * 1.4) * 0.025;
      this.hero.leftLeg.rotation.x = 0;
      this.hero.rightLeg.rotation.x = 0;
      this.hero.leftKnee.rotation.x = 0;
      this.hero.rightKnee.rotation.x = 0;
      this.hero.recoilGroup.position.z = 0.27;
      this.hero.recoilGroup.rotation.x = Math.sin(this.titleTime * 1.6) * 0.022;

      // Real-time Verlet cloth simulation on the red-and-white gamcha (Hooghly river breeze + drag-spin whip!)
      this.hero.updateGamchaCloth(dt, this.worldTime, 0, 0, 0, lobbyYawRate, 0.28);

      // Keep shadow frustum locked cleanly on the lobby hero & village square
      this.sunLight.position.set(26, 38, -14);
      this.sunLight.target.position.set(0, 0, 4);

      // Heroic front-facing lobby camera with gentle atmospheric float
      const swayX = Math.sin(this.titleTime * 0.45) * 0.16;
      const swayY = Math.cos(this.titleTime * 0.65) * 0.045;
      this.camera.position.set(-0.2 + swayX, 1.5 + swayY, 11.1);
      this.camera.lookAt(0.14, 1.28, -4.0);
      return;
    }

    if (this.phase !== 'playing') {
      return;
    }

    // Brief hitstop on heavy kill impact for tactile weight
    if (this.hitstopTimer > 0) {
      this.hitstopTimer = Math.max(0, this.hitstopTimer - dt);
      return;
    }

    // Decay UI / feedback timers
    this.damageFlash = Math.max(0, this.damageFlash - dt * 2.4);
    this.hitMarker = Math.max(0, this.hitMarker - dt * 4.2);
    this.camShake = Math.max(0, this.camShake - dt * 1.6);
    if (this.waveBannerTimer > 0) {
      this.waveBannerTimer -= dt;
      if (this.waveBannerTimer <= 0) this.waveBanner = null;
    }
    if (this.pickupToastTimer > 0) {
      this.pickupToastTimer -= dt;
      if (this.pickupToastTimer <= 0) this.pickupToast = null;
    }

    // Camera keyboard orbit assist (Q/E) + touch drag look
    if (this.keysHeld.has('KeyQ')) this.camYaw += 2.2 * dt;
    if (this.keysHeld.has('KeyE')) this.camYaw -= 2.2 * dt;
    if (this.virtualInput.lookDeltaX !== 0 || this.virtualInput.lookDeltaY !== 0) {
      this.camYaw -= this.virtualInput.lookDeltaX * 0.0055;
      this.camPitch = THREE.MathUtils.clamp(
        this.camPitch + this.virtualInput.lookDeltaY * 0.0042,
        -0.12,
        0.65,
      );
      this.virtualInput.lookDeltaX = 0;
      this.virtualInput.lookDeltaY = 0;
    }

    // Read unified movement / steering input (Keyboard WASD / Arrows + Virtual Touch Joystick)
    let moveRight = this.virtualInput.moveX;
    let moveForward = this.virtualInput.moveY;
    if (this.keysHeld.has('KeyD') || this.keysHeld.has('ArrowRight')) moveRight += 1;
    if (this.keysHeld.has('KeyA') || this.keysHeld.has('ArrowLeft')) moveRight -= 1;
    if (this.keysHeld.has('KeyW') || this.keysHeld.has('ArrowUp')) moveForward += 1;
    if (this.keysHeld.has('KeyS') || this.keysHeld.has('ArrowDown')) moveForward -= 1;

    const moveLen = Math.hypot(moveRight, moveForward);
    if (moveLen > 1) {
      moveRight /= moveLen;
      moveForward /= moveLen;
    }

    // --- 1. Update WBTC Passenger Bus (Auto Intro Route OR Player Driving OR Coasting Stop) ---
    if (this.busAutoDriving) {
      const prevPos = _v2.copy(this.busPos);
      // Smoothly decelerate as the bus approaches its final village bus stop
      const slowDown = this.busRouteT > 0.88 ? THREE.MathUtils.lerp(1.0, 0.35, (this.busRouteT - 0.88) / 0.12) : 1.0;
      this.busRouteT = Math.min(1.0, this.busRouteT + dt * 0.046 * slowDown);
      this.positionBusOnIntroRoute(this.busRouteT);

      const movedDist = this.busPos.distanceTo(prevPos);
      this.busSpeed = movedDist / Math.max(0.001, dt);
      for (const w of this.bus.wheels) {
        w.rotation.x += movedDist / 0.54;
      }
      this.bus.chassisGroup.position.y = Math.sin(this.worldTime * 14) * 0.018;

      this.bus.root.updateMatrixWorld(true);

      // Update & auto-drop AI enemy passengers riding on the bus along the route
      for (const e of this.enemies) {
        if (e.dying || e.busSeatIndex < 0) continue;
        if (this.busRouteT >= e.busDropT) {
          this.dropEnemyFromBus(e);
        } else {
          this.bus.enemySeats[e.busSeatIndex].getWorldPosition(e.rig.root.position);
          e.rig.root.rotation.y = this.busYaw;
        }
      }

      // Auto-exit hero at the very end of the route if they stayed on until the last village stop
      if (this.busRouteT >= 0.999) {
        this.busAutoDriving = false;
        this.busSpeed = 0;
        this.bus.chassisGroup.position.y = 0;
        this.bus.root.rotation.set(0, this.busYaw, 0);
        // Drop any straggling bus enemies safely
        for (const e of this.enemies) {
          if (!e.dying && e.busSeatIndex >= 0) this.dropEnemyFromBus(e);
        }
        if (this.busMode === 'riding_intro') {
          this.exitBus();
        }
      }
    } else if (this.busMode === 'driving') {
      // Player-controlled WBTC bus driving around the West Bengal village!
      const accel = 14.5;
      const maxFwd = 15.0;
      const maxRev = -6.0;

      if (Math.abs(moveForward) > 0.05) {
        this.busSpeed += moveForward * accel * dt;
      } else {
        this.busSpeed *= Math.exp(-3.4 * dt);
        if (Math.abs(this.busSpeed) < 0.08) this.busSpeed = 0;
      }
      this.busSpeed = THREE.MathUtils.clamp(this.busSpeed, maxRev, maxFwd);

      const targetSteer = -moveRight * 0.48;
      this.busSteerAngle += (targetSteer - this.busSteerAngle) * (1 - Math.exp(-10 * dt));
      for (const pivot of this.bus.frontWheelPivots) {
        pivot.rotation.y = this.busSteerAngle;
      }

      if (Math.abs(this.busSpeed) > 0.25) {
        const turnSign = this.busSpeed >= 0 ? 1 : -1;
        const turnFactor = Math.min(1, Math.abs(this.busSpeed) / 6.0);
        this.busYaw += this.busSteerAngle * 2.15 * turnFactor * turnSign * dt;
      }

      const bFwdX = Math.sin(this.busYaw);
      const bFwdZ = Math.cos(this.busYaw);
      const prevX = this.busPos.x;
      const prevZ = this.busPos.z;

      this.busPos.x += bFwdX * this.busSpeed * dt;
      this.busPos.z += bFwdZ * this.busSpeed * dt;
      this.busPos.y = 0;

      // Keep drivable bus cleanly inside the West Bengal village & slide off houses/trees/taxi
      this.resolveCircleWorldCollision(this.busPos, 1.85, false);
      const actualDist = Math.hypot(this.busPos.x - prevX, this.busPos.z - prevZ);
      if (Math.abs(this.busSpeed) > 2.5 && actualDist < Math.abs(this.busSpeed) * dt * 0.35) {
        this.busSpeed *= 0.55; // gentle bumper bounce on impact
      }

      this.bus.root.position.copy(this.busPos);
      this.bus.root.rotation.set(0, this.busYaw, 0);
      this.bus.chassisGroup.rotation.z = -this.busSteerAngle * Math.min(1, Math.abs(this.busSpeed) / 12) * 0.08;
      this.bus.chassisGroup.position.y = Math.sin(this.worldTime * 16) * (Math.abs(this.busSpeed) > 1 ? 0.02 : 0.005);

      const wheelSpin = (this.busSpeed * dt) / 0.54;
      for (const w of this.bus.wheels) {
        w.rotation.x += wheelSpin;
      }

      // Ram enemy bots with the bus!
      if (Math.abs(this.busSpeed) > 4.2) {
        for (const e of this.enemies) {
          if (e.dying || e.busSeatIndex >= 0) continue;
          const dx = e.rig.root.position.x - this.busPos.x;
          const dz = e.rig.root.position.z - this.busPos.z;
          if (dx * dx + dz * dz < 3.1 * 3.1) {
            _v4.set(bFwdX * this.busSpeed, 0, bFwdZ * this.busSpeed);
            this.damageEnemy(e, 95, _v4);
            this.camShake = Math.min(0.36, this.camShake + 0.16);
          }
        }
      }

      this.bus.root.updateMatrixWorld(true);
    } else {
      // Bus coasting smoothly to a stop when unmanned on village ground
      if (Math.abs(this.busSpeed) > 0.05) {
        this.busSpeed *= Math.exp(-4.5 * dt);
        const bFwdX = Math.sin(this.busYaw);
        const bFwdZ = Math.cos(this.busYaw);
        this.busPos.x += bFwdX * this.busSpeed * dt;
        this.busPos.z += bFwdZ * this.busSpeed * dt;
        this.resolveCircleWorldCollision(this.busPos, 1.85, false);
        this.bus.root.position.copy(this.busPos);
        for (const w of this.bus.wheels) {
          w.rotation.x += (this.busSpeed * dt) / 0.54;
        }
      } else {
        this.busSpeed = 0;
      }
      this.bus.chassisGroup.rotation.z *= Math.exp(-8 * dt);
      this.bus.chassisGroup.position.y *= Math.exp(-8 * dt);
    }

    // --- 2. Update Hero Position, Mode & Actions ---
    const fwdX = Math.sin(this.camYaw);
    const fwdZ = Math.cos(this.camYaw);
    const rightX = -fwdZ;
    const rightZ = fwdX;

    if (this.busMode === 'riding_intro') {
      // Hero rides visibly inside the open WBTC bus doorway across the bridge & village!
      this.bus.heroIntroSeat.getWorldPosition(this.heroPos);
      this.hero.root.position.copy(this.heroPos);
      this.heroYaw = this.busYaw - Math.PI * 0.45;
      this.hero.root.rotation.set(0, this.heroYaw, 0);
      this.hero.leftLeg.rotation.x = 0;
      this.hero.rightLeg.rotation.x = 0;
      this.hero.leftKnee.rotation.x = 0;
      this.hero.rightKnee.rotation.x = 0;
      this.hero.headGroup.rotation.set(0, 0.15, 0);
      this.hero.updateGamchaCloth(dt, this.worldTime, 1.8, 0, this.busSpeed * 0.55, 0, 1.35);
      this.hero.muzzleFlash.visible = false;
      this.hero.muzzleLight.intensity = 0;
      this.nearBus = false;
    } else if (this.busMode === 'driving') {
      // Hero sits visibly in the right-hand-drive cab behind the steering wheel!
      this.bus.heroDriverSeat.getWorldPosition(this.heroPos);
      this.hero.root.position.copy(this.heroPos);
      this.heroYaw = this.busYaw;
      this.hero.root.rotation.set(0, this.heroYaw, 0);
      this.hero.leftLeg.rotation.x = -0.85;
      this.hero.rightLeg.rotation.x = -0.85;
      this.hero.leftKnee.rotation.x = 0.85;
      this.hero.rightKnee.rotation.x = 0.85;
      this.hero.headGroup.rotation.set(0, -this.busSteerAngle * 0.45, 0);
      this.hero.updateGamchaCloth(dt, this.worldTime, 0, 0, this.busSpeed * 0.25, 0, 0.35);
      this.hero.muzzleFlash.visible = false;
      this.hero.muzzleLight.intensity = 0;
      this.nearBus = false;
    } else if (this.heroJumpingFromBus) {
      // Dramatic parabolic leap arc from the WBTC bus onto the village riverbank!
      const prevY = this.heroPos.y;
      this.heroJumpProgress = Math.min(1, this.heroJumpProgress + dt / this.heroJumpDuration);
      const t = this.heroJumpProgress;
      this.heroPos.lerpVectors(this.heroJumpStart, this.heroJumpEnd, t);
      const arc = 4 * t * (1 - t);
      this.heroPos.y = THREE.MathUtils.lerp(this.heroJumpStart.y, 0, t) + arc * (this.heroJumpPeakY - this.heroJumpStart.y * 0.5);
      this.hero.root.position.copy(this.heroPos);
      this.hero.leftLeg.rotation.x = 0.42;
      this.hero.rightLeg.rotation.x = -0.35;
      this.hero.leftKnee.rotation.x = 0.55;
      this.hero.rightKnee.rotation.x = 0.28;
      const vertVel = (this.heroPos.y - prevY) / Math.max(0.001, dt);
      this.hero.updateGamchaCloth(dt, this.worldTime, 0, vertVel * 0.75, 4.5, 0, 1.55);

      if (this.heroJumpProgress >= 1) {
        this.heroJumpingFromBus = false;
        this.heroPos.y = 0;
        this.hero.root.position.copy(this.heroPos);
        this.camShake = Math.min(0.28, this.camShake + 0.14);
        this.spawnParticles(this.heroPos, 0xd8a872, 12, 4.5);
      }
      this.nearBus = false;
    } else {
      // Standard on-foot third-person shooter movement & combat
      const wantsSprint =
        (this.keysHeld.has('ShiftLeft') || this.keysHeld.has('ShiftRight') || this.virtualInput.sprinting) &&
        moveLen > 0.2;
      let speedMult = 1.0;
      if (wantsSprint && this.sprintStamina > 0.08) {
        speedMult = 1.48;
        this.sprintStamina = Math.max(0, this.sprintStamina - dt * 0.42);
      } else {
        this.sprintStamina = Math.min(1, this.sprintStamina + dt * 0.28);
      }

      const moveSpeed = 7.6 * speedMult;
      const vx = (fwdX * moveForward + rightX * moveRight) * moveSpeed;
      const vz = (fwdZ * moveForward + rightZ * moveRight) * moveSpeed;

      this.prevHeroPos.copy(this.heroPos);
      this.prevHeroYaw = this.heroYaw;

      this.heroPos.x += vx * dt;
      this.heroPos.z += vz * dt;
      this.heroPos.y = 0;
      this.resolveCircleWorldCollision(this.heroPos, 0.56, true);
      this.hero.root.position.copy(this.heroPos);

      // Proximity check for re-entering & driving the WBTC bus ('বাসে উঠুন')
      this.nearBus =
        !this.busAutoDriving &&
        this.busPos.y < 0.5 &&
        this.heroPos.distanceTo(this.busPos) < 5.8;

      // Smooth hero facing (aligns with camera aim when shooting, or movement direction when running)
      const isShooting =
        this.mouseShootHeld || this.keysHeld.has('Space') || this.virtualInput.shooting;

      const desiredYaw = isShooting
        ? this.camYaw
        : moveLen > 0.12
          ? Math.atan2(vx, vz)
          : this.camYaw;

      let yawDiff = desiredYaw - this.heroYaw;
      while (yawDiff > Math.PI) yawDiff -= Math.PI * 2;
      while (yawDiff < -Math.PI) yawDiff += Math.PI * 2;
      this.heroYaw += yawDiff * (1 - Math.exp(-14 * dt));
      this.hero.root.rotation.set(0, this.heroYaw, 0);
      this.hero.headGroup.rotation.set(0, 0, 0);

      // Procedural hero walk cycle with articulated knee flexion
      if (moveLen > 0.08) {
        this.heroWalkPhase += dt * (9.5 * speedMult);
        const swing = Math.sin(this.heroWalkPhase) * 0.58 * Math.min(1, moveLen);
        this.hero.leftLeg.rotation.x = swing;
        this.hero.rightLeg.rotation.x = -swing;
        this.hero.leftKnee.rotation.x = Math.max(0, -swing) * 0.92;
        this.hero.rightKnee.rotation.x = Math.max(0, swing) * 0.92;
        this.hero.bodyGroup.position.y = Math.abs(Math.cos(this.heroWalkPhase)) * 0.055;
      } else {
        const damp = 1 - Math.exp(-12 * dt);
        this.hero.leftLeg.rotation.x *= 1 - damp;
        this.hero.rightLeg.rotation.x *= 1 - damp;
        this.hero.leftKnee.rotation.x *= 1 - damp;
        this.hero.rightKnee.rotation.x *= 1 - damp;
        this.hero.bodyGroup.position.y *= 1 - damp;
      }

      // Convert hero world velocity into hero local space for realistic cloth-physics gamcha drag
      const worldVx = (this.heroPos.x - this.prevHeroPos.x) / Math.max(0.001, dt);
      const worldVz = (this.heroPos.z - this.prevHeroPos.z) / Math.max(0.001, dt);
      const sinY = Math.sin(this.heroYaw);
      const cosY = Math.cos(this.heroYaw);
      const localVelZ = worldVx * sinY + worldVz * cosY;
      const localVelX = worldVx * cosY - worldVz * sinY;
      let dYaw = this.heroYaw - this.prevHeroYaw;
      while (dYaw > Math.PI) dYaw -= Math.PI * 2;
      while (dYaw < -Math.PI) dYaw += Math.PI * 2;
      const yawRate = dYaw / Math.max(0.001, dt);

      this.hero.updateGamchaCloth(
        dt,
        this.worldTime,
        localVelX,
        0,
        localVelZ,
        yawRate,
        wantsSprint ? 0.95 : moveLen > 0.1 ? 0.45 : 0.18,
      );

      // Reloading & firing
      if (this.virtualInput.reloadJustPressed) {
        this.virtualInput.reloadJustPressed = false;
        this.attemptStartReload();
      }
      if (this.isReloading) {
        this.reloadTimer -= dt;
        if (this.reloadTimer <= 0) {
          const needed = this.maxAmmo - this.ammo;
          const load = Math.min(needed, this.reserveAmmo);
          this.ammo += load;
          this.reserveAmmo -= load;
          this.isReloading = false;
        }
      }

      this.fireCooldown = Math.max(0, this.fireCooldown - dt);
      if (isShooting) {
        this.firePlayerWeapon();
      }

      // Weapon recoil & muzzle flash decay
      this.heroRecoil = Math.max(0, this.heroRecoil - dt * 7.5);
      this.hero.recoilGroup.position.z = 0.27 - this.heroRecoil * 0.085;
      this.hero.recoilGroup.rotation.x = -this.heroRecoil * 0.14;

      if (this.muzzleFlashTimer > 0) {
        this.muzzleFlashTimer -= dt;
        this.hero.muzzleFlash.visible = true;
        this.hero.muzzleFlash.rotation.z = Math.random() * Math.PI * 2;
        this.hero.muzzleLight.intensity = 4.5;
      } else {
        this.hero.muzzleFlash.visible = false;
        this.hero.muzzleLight.intensity = 0;
      }
    }

    // Keep shadow frustum centered around active subject (bus or hero)
    const focusPos = this.busMode !== 'none' ? this.busPos : this.heroPos;
    this.sunLight.position.set(focusPos.x + 26, 38, focusPos.z - 22);
    this.sunLight.target.position.copy(focusPos);

    // Wave spawning & progression (pause wave auto-advance while Wave 1 intro bus is still dropping enemies)
    if (!this.busAutoDriving || this.wave > 1) {
      this.updateWaves(dt);
    }

    // Update enemies, bullets, pickups, particles
    this.updateEnemies(dt);
    this.updateBullets(dt);
    this.updatePickups(dt);
    this.updateParticles(dt);

    // --- 3. Camera Rig (Cinematic Bus Chase vs. Bus Driving vs. Third-Person Shooter) ---
    if (this.busMode === 'riding_intro') {
      // Sweeping cinematic side-rear chase camera showing the WBTC bus, Howrah Bridge, and passengers!
      const bFwdX = Math.sin(this.busYaw);
      const bFwdZ = Math.cos(this.busYaw);
      const bRightX = -bFwdZ;
      const bRightZ = bFwdX;

      _camDesired.set(
        this.busPos.x - bFwdX * 11.5 - bRightX * 4.8,
        this.busPos.y + 5.1,
        this.busPos.z - bFwdZ * 11.5 - bRightZ * 4.8,
      );
      _lookAtPt.set(
        this.busPos.x + bFwdX * 3.5,
        this.busPos.y + 1.8,
        this.busPos.z + bFwdZ * 3.5,
      );
    } else if (this.busMode === 'driving') {
      // Responsive vehicle chase camera behind the player-driven WBTC bus
      const bFwdX = Math.sin(this.busYaw);
      const bFwdZ = Math.cos(this.busYaw);
      _camDesired.set(
        this.busPos.x - bFwdX * 12.2,
        this.busPos.y + 5.2,
        this.busPos.z - bFwdZ * 12.2,
      );
      _lookAtPt.set(
        this.busPos.x + bFwdX * 5.0,
        this.busPos.y + 1.8,
        this.busPos.z + bFwdZ * 5.0,
      );
    } else {
      // Third-person over-the-shoulder shooter camera
      const camDist = 6.2;
      const shoulderRight = 1.05;
      const camHeight = 2.65 + this.camPitch * 2.8;
      _camDesired.set(
        this.heroPos.x - fwdX * camDist + rightX * shoulderRight,
        this.heroPos.y + camHeight,
        this.heroPos.z - fwdZ * camDist + rightZ * shoulderRight,
      );
      _camDesired.y = Math.max(1.35, _camDesired.y);

      _lookAtPt.set(
        this.heroPos.x + fwdX * 14 + rightX * 0.45,
        this.heroPos.y + 1.55 - this.camPitch * 4.2,
        this.heroPos.z + fwdZ * 14 + rightZ * 0.45,
      );
    }

    if (this.introTransitionProgress < 1) {
      this.introTransitionProgress = Math.min(
        1,
        this.introTransitionProgress + dt / this.introTransitionDuration,
      );
      const t = this.introTransitionProgress;
      const ease = t * t * (3 - 2 * t);

      this.camera.position.lerpVectors(this.introStartCamPos, _camDesired, ease);
      this.camera.position.y += Math.sin(ease * Math.PI) * 2.4;
      _camTarget.lerpVectors(this.introStartLookAt, _lookAtPt, ease);
      this.camera.lookAt(_camTarget);
    } else {
      const camDamp = 1 - Math.exp(-(this.busMode !== 'none' ? 6.5 : 12) * dt);
      this.camera.position.lerp(_camDesired, camDamp);

      if (this.camShake > 0.005) {
        this.camera.position.x += (Math.random() - 0.5) * this.camShake;
        this.camera.position.y += (Math.random() - 0.5) * this.camShake;
      }

      _camTarget.lerp(_lookAtPt, 1 - Math.exp(-14 * dt));
      this.camera.lookAt(_camTarget);
    }
  }

  private dropEnemyFromBus(e: ActiveEnemy): void {
    e.busSeatIndex = -1;
    this.bus.doorExitPoint.getWorldPosition(_v1);
    const bounds = this.world.playableBounds;
    const dropX = THREE.MathUtils.clamp(_v1.x + (Math.random() - 0.5) * 3.0, bounds.minX + 2, bounds.maxX - 2);
    const dropZ = THREE.MathUtils.clamp(_v1.z + (Math.random() - 0.5) * 3.0, bounds.minZ + 2, bounds.maxZ - 2);
    e.rig.root.position.set(dropX, 0, dropZ);
    this.resolveCircleWorldCollision(e.rig.root.position, e.radius, false);
    this.spawnParticles(e.rig.root.position, 0xd8a872, 7, 3.6);
  }

  private updateWaves(dt: number): void {
    const aliveEnemies = this.enemies.filter((e) => !e.dying).length;

    if (this.waveEnemiesToSpawn.length > 0) {
      const maxSimultaneous = Math.min(8, 3 + this.wave);
      if (aliveEnemies < maxSimultaneous) {
        this.waveSpawnTimer -= dt;
        if (this.waveSpawnTimer <= 0) {
          const next = this.waveEnemiesToSpawn.shift()!;
          this.spawnEnemy(next);
          this.waveSpawnTimer = Math.max(0.7, 1.85 - this.wave * 0.12);
        }
      }
    } else if (aliveEnemies === 0) {
      if (this.waveBreakTimer <= 0) {
        this.waveBreakTimer = 2.5;
        this.waveBanner = `তরঙ্গ ${toBengaliNumber(this.wave)} সম্পূর্ণ!`;
        this.waveBannerTimer = 2.2;
        this.score += 150 * this.wave;
        this.checkHighScore();
      } else {
        this.waveBreakTimer -= dt;
        if (this.waveBreakTimer <= 0) {
          this.beginWave(this.wave + 1);
        }
      }
    }
  }

  private updateEnemies(dt: number): void {
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];

      // Enemies currently riding on the intro WBTC bus wait until they exit
      if (e.busSeatIndex >= 0) continue;

      if (e.dying) {
        e.deathTimer += dt;
        e.rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(0, -Math.PI * 0.48, Math.min(1, e.deathTimer * 3.8));
        e.rig.bodyGroup.position.y = THREE.MathUtils.lerp(0, -0.18, Math.min(1, e.deathTimer * 3.8));
        e.rig.hpBarBg.visible = false;
        e.rig.telegraphGlow.visible = false;
        if (e.deathTimer > 1.15) {
          this.scene.remove(e.rig.root);
          this.enemies.splice(i, 1);
        }
        continue;
      }

      // Hit flash recovery
      if (e.hitFlashTimer > 0) {
        e.hitFlashTimer -= dt;
        if (e.hitFlashTimer <= 0) {
          e.rig.flashMaterials.forEach((m, idx) => {
            m.emissive.copy(e.rig.baseEmissives[idx]);
          });
          e.rig.bodyGroup.scale.setScalar(
            e.archetype === 'heavy' ? 1.18 : e.archetype === 'rusher' ? 0.96 : 1.02,
          );
        }
      }

      // Billboard floating health bar toward camera
      if (e.rig.hpBarBg.visible) {
        e.rig.hpBarBg.lookAt(this.camera.position);
      }

      const toHeroX = this.heroPos.x - e.rig.root.position.x;
      const toHeroZ = this.heroPos.z - e.rig.root.position.z;
      const dist = Math.hypot(toHeroX, toHeroZ) || 0.001;
      const dirX = toHeroX / dist;
      const dirZ = toHeroZ / dist;

      // Face player
      e.rig.root.rotation.y = Math.atan2(dirX, dirZ);

      // Tactical movement: approach desired range, then strafe & flank
      const desiredRange =
        e.archetype === 'rusher' ? 6.5 : e.archetype === 'heavy' ? 12.0 : 13.5;

      e.strafeTimer -= dt;
      if (e.strafeTimer <= 0) {
        e.strafeDir = -e.strafeDir;
        e.strafeTimer = 1.4 + Math.random() * 1.8;
      }

      let moveX = 0;
      let moveZ = 0;
      if (dist > desiredRange + 1.2) {
        moveX += dirX;
        moveZ += dirZ;
      } else if (dist < desiredRange - 2.2) {
        moveX -= dirX * 0.55;
        moveZ -= dirZ * 0.55;
      }
      // Strafe perpendicular to player
      moveX += -dirZ * e.strafeDir * 0.65;
      moveZ += dirX * e.strafeDir * 0.65;

      // Soft separation between enemies so they don't stack
      for (let j = 0; j < this.enemies.length; j++) {
        if (i === j || this.enemies[j].dying) continue;
        const other = this.enemies[j];
        const sx = e.rig.root.position.x - other.rig.root.position.x;
        const sz = e.rig.root.position.z - other.rig.root.position.z;
        const sDistSq = sx * sx + sz * sz;
        if (sDistSq < 3.6 && sDistSq > 0.001) {
          const sDist = Math.sqrt(sDistSq);
          moveX += (sx / sDist) * 1.1;
          moveZ += (sz / sDist) * 1.1;
        }
      }

      const mLen = Math.hypot(moveX, moveZ);
      if (mLen > 0.01) {
        moveX /= mLen;
        moveZ /= mLen;
        e.rig.root.position.x += moveX * e.speed * dt;
        e.rig.root.position.z += moveZ * e.speed * dt;
        e.walkPhase += dt * (e.speed * 1.8);
        const swing = Math.sin(e.walkPhase) * 0.52;
        e.rig.leftLeg.rotation.x = swing;
        e.rig.rightLeg.rotation.x = -swing;
        e.rig.leftKnee.rotation.x = Math.max(0, -swing) * 0.88;
        e.rig.rightKnee.rotation.x = Math.max(0, swing) * 0.88;
      }

      // Apply knockback decay
      if (e.knockback.lengthSq() > 0.01) {
        e.rig.root.position.addScaledVector(e.knockback, dt);
        e.knockback.multiplyScalar(Math.exp(-10 * dt));
      }

      this.resolveCircleWorldCollision(e.rig.root.position, e.radius);

      // Combat firing with visible telegraph windup (hold fire while player is riding intro bus)
      if (dist <= e.fireRange && this.busMode !== 'riding_intro') {
        if (e.telegraphTimer > 0) {
          e.telegraphTimer -= dt;
          e.rig.telegraphGlow.visible = true;
          const pulse = 0.8 + (1 - e.telegraphTimer / 0.45) * 0.7;
          e.rig.telegraphGlow.scale.setScalar(pulse);
          if (e.telegraphTimer <= 0) {
            e.rig.telegraphGlow.visible = false;
            this.fireEnemyShot(e, dist);
            e.fireCooldown =
              e.archetype === 'heavy'
                ? 1.55
                : e.archetype === 'rusher'
                  ? 1.15
                  : Math.max(1.0, 1.8 - this.wave * 0.06);
          }
        } else {
          e.fireCooldown -= dt;
          if (e.fireCooldown <= 0) {
            e.telegraphTimer = e.archetype === 'heavy' ? 0.55 : 0.42;
          }
        }
      } else {
        e.rig.telegraphGlow.visible = false;
        e.telegraphTimer = 0;
      }
    }
  }

  private fireEnemyShot(e: ActiveEnemy, distToHero: number): void {
    e.rig.root.updateMatrixWorld(true);
    const muzzleWorld = _v1;
    e.rig.muzzlePoint.getWorldPosition(muzzleWorld);

    const aimTarget = _v2.set(this.heroPos.x, 1.25, this.heroPos.z);
    const dir = _v3.subVectors(aimTarget, muzzleWorld).normalize();

    // Fair dodgeable inaccuracy so movement & cover matter
    const spread = e.archetype === 'heavy' ? 0.05 : 0.075;
    dir.x += (Math.random() - 0.5) * spread;
    dir.y += (Math.random() - 0.5) * 0.03;
    dir.z += (Math.random() - 0.5) * spread;
    dir.normalize();

    const dmg = e.archetype === 'heavy' ? 14 : e.archetype === 'rusher' ? 9 : 10;
    const speed = e.archetype === 'heavy' ? 23 : 27;
    this.spawnBullet(false, muzzleWorld, dir, speed, dmg);
    this.audio.playEnemyShot(distToHero);
  }

  private updateBullets(dt: number): void {
    for (const b of this.bullets) {
      if (!b.active) continue;
      b.life -= dt;
      b.pos.addScaledVector(b.vel, dt);
      b.mesh.position.copy(b.pos);

      if (b.life <= 0 || this.hitsWorldObstacle(b.pos)) {
        if (b.life > 0) {
          this.spawnParticles(b.pos, 0xd8a872, 4, 3.2);
        }
        b.active = false;
        b.mesh.visible = false;
        continue;
      }

      if (b.fromPlayer) {
        // Check collision with enemies
        for (const e of this.enemies) {
          if (e.dying || e.busSeatIndex >= 0) continue;
          const dx = b.pos.x - e.rig.root.position.x;
          const dz = b.pos.z - e.rig.root.position.z;
          const hitR = e.radius + 0.32;
          if (dx * dx + dz * dz <= hitR * hitR && b.pos.y >= 0.1 && b.pos.y <= 2.35) {
            this.damageEnemy(e, b.damage, b.vel);
            b.active = false;
            b.mesh.visible = false;
            break;
          }
        }
      } else if (this.busMode !== 'riding_intro') {
        // Check collision with hero (armored reduction when driving the WBTC bus)
        const targetPos = this.busMode === 'driving' ? this.busPos : this.heroPos;
        const hitRadius = this.busMode === 'driving' ? 1.65 : 0.62;
        const maxY = this.busMode === 'driving' ? 3.2 : 2.0;
        const dx = b.pos.x - targetPos.x;
        const dz = b.pos.z - targetPos.z;
        if (dx * dx + dz * dz <= hitRadius * hitRadius && b.pos.y >= 0.1 && b.pos.y <= maxY) {
          const finalDmg =
            this.busMode === 'driving' ? Math.max(3, Math.round(b.damage * 0.45)) : b.damage;
          this.damagePlayer(finalDmg);
          if (this.busMode === 'driving') {
            this.spawnParticles(b.pos, 0xffe082, 5, 4.0);
          }
          b.active = false;
          b.mesh.visible = false;
        }
      }
    }
  }

  private damageEnemy(e: ActiveEnemy, dmg: number, bulletVel: THREE.Vector3): void {
    e.hp -= dmg;
    e.hitFlashTimer = 0.095;
    e.rig.flashMaterials.forEach((m) => m.emissive.setHex(0xffffff));

    // Squash & stretch impact reaction
    const baseScale = e.archetype === 'heavy' ? 1.18 : e.archetype === 'rusher' ? 0.96 : 1.02;
    e.rig.bodyGroup.scale.set(baseScale * 1.12, baseScale * 0.9, baseScale * 1.12);

    // Knockback along shot direction
    _v1.copy(bulletVel).setY(0).normalize().multiplyScalar(e.archetype === 'heavy' ? 2.5 : 5.2);
    e.knockback.copy(_v1);

    // Update world-space health bar
    e.rig.hpBarBg.visible = true;
    const ratio = Math.max(0, e.hp / e.maxHp);
    e.rig.hpBarFill.scale.x = Math.max(0.001, ratio);

    this.spawnParticles(
      _v2.set(e.rig.root.position.x, 1.35, e.rig.root.position.z),
      0xff5c38,
      7,
      4.8,
    );

    if (e.hp <= 0) {
      e.dying = true;
      e.deathTimer = 0;
      this.kills++;
      const pts = e.archetype === 'heavy' ? 180 : e.archetype === 'rusher' ? 130 : 100;
      this.score += pts;
      this.checkHighScore();
      this.hitMarker = 1.0;
      this.hitMarkerKill = true;
      this.hitstopTimer = 0.045;
      this.camShake = Math.min(0.32, this.camShake + 0.12);
      this.audio.playEnemyHit(true);
      this.spawnParticles(
        _v2.set(e.rig.root.position.x, 1.2, e.rig.root.position.z),
        0xffa73b,
        14,
        6.5,
      );

      // Chance to drop Health or Ammo crate
      if (Math.random() < 0.42) {
        const kind: PickupKind =
          this.health < 55 && Math.random() < 0.65 ? 'health' : 'ammo';
        this.spawnPickup(e.rig.root.position.x, e.rig.root.position.z, kind);
      }
    } else {
      this.hitMarker = 0.72;
      this.hitMarkerKill = false;
      this.audio.playEnemyHit(false);
    }
  }

  private damagePlayer(dmg: number): void {
    this.health = Math.max(0, this.health - dmg);
    this.damageFlash = 0.92;
    this.camShake = Math.min(0.4, this.camShake + 0.18);
    this.audio.playPlayerHurt();

    if (this.health <= 0) {
      this.phase = 'gameover';
      this.keysHeld.clear();
      this.mouseShootHeld = false;
      this.virtualInput.shooting = false;
      if (document.pointerLockElement === this.renderer.domElement) {
        document.exitPointerLock();
      }
      this.checkHighScore();
      this.emitHud();
    }
  }

  private updatePickups(dt: number): void {
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const p = this.pickups[i];
      p.life -= dt;
      p.mesh.rotation.y += dt * 1.8;
      p.mesh.position.y = Math.sin(this.worldTime * 3.2 + p.id) * 0.1;

      const distSq = p.pos.distanceToSquared(this.heroPos);
      if (distSq < 1.85 * 1.85) {
        if (p.kind === 'health') {
          this.health = Math.min(this.maxHealth, this.health + 35);
          this.pickupToast = 'স্বাস্থ্য +৩৫';
        } else {
          this.reserveAmmo = Math.min(180, this.reserveAmmo + 28);
          this.pickupToast = 'গুলি +২৮';
        }
        this.pickupToastTimer = 1.8;
        this.audio.playPickup(p.kind);
        this.scene.remove(p.mesh);
        this.pickups.splice(i, 1);
        continue;
      }

      if (p.life <= 0) {
        this.scene.remove(p.mesh);
        this.pickups.splice(i, 1);
      }
    }
  }

  private updateParticles(dt: number): void {
    for (const p of this.particles) {
      if (!p.active) continue;
      p.life -= dt;
      if (p.life <= 0) {
        p.active = false;
        p.mesh.visible = false;
        continue;
      }
      p.vel.y -= 14 * dt;
      p.pos.addScaledVector(p.vel, dt);
      if (p.pos.y < 0.05) {
        p.pos.y = 0.05;
        p.vel.y *= -0.35;
      }
      p.mesh.position.copy(p.pos);
      const t = p.life / p.maxLife;
      p.mesh.scale.setScalar(p.scale * t);
    }
  }

  private checkHighScore(): void {
    if (this.score > this.highScore) {
      this.highScore = this.score;
      try {
        localStorage.setItem(STORAGE_KEY_HIGHSCORE, String(this.highScore));
      } catch {
        // ignore storage errors
      }
    }
  }

  // --- Render Loop with Software-WebGL Pacing ---

  private afterDraw(cb: () => void): void {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) return;
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private tick = (): void => {
    if (this.disposed) return;

    const now = performance.now();
    const rawDt = (now - this.lastFrameMs) / 1000;
    this.lastFrameMs = now;
    const dt = Math.min(Math.max(rawDt, 0.001), 0.05);

    this.update(dt);
    this.renderer.render(this.scene, this.camera);

    // Emit HUD snapshot at ~20Hz so React never throttles the 60fps WebGL loop
    this.hudEmitAccum += dt;
    if (this.hudEmitAccum >= 0.05) {
      this.hudEmitAccum = 0;
      this.emitHud();
    }

    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  };

  private emitHud(): void {
    const alive = this.enemies.filter((e) => !e.dying).length;
    this.onHudUpdate({
      phase: this.phase,
      busMode: this.busMode,
      nearBus: this.nearBus,
      busZoneLabel: this.busMode === 'riding_intro' ? this.busZoneLabel : null,
      busSpeedKmh: Math.round(Math.abs(this.busSpeed) * 3.6),
      busRouteProgress: this.busRouteT,
      health: Math.ceil(this.health),
      maxHealth: this.maxHealth,
      ammo: this.ammo,
      maxAmmo: this.maxAmmo,
      reserveAmmo: this.reserveAmmo,
      isReloading: this.isReloading,
      reloadProgress: this.isReloading
        ? 1 - Math.max(0, this.reloadTimer / this.reloadDuration)
        : 1,
      score: this.score,
      highScore: this.highScore,
      kills: this.kills,
      wave: this.wave,
      enemiesRemaining: alive + this.waveEnemiesToSpawn.length,
      waveBanner: this.waveBanner,
      damageFlash: this.damageFlash,
      hitMarker: this.hitMarker,
      hitMarkerKill: this.hitMarkerKill,
      muted: this.audio.isMuted(),
      sprintRatio: this.sprintStamina,
      pickupToast: this.pickupToast,
    });
  }

  // --- Event Listeners ---

  private onKeyDown = (e: KeyboardEvent): void => {
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
      e.preventDefault();
    }

    if (this.phase === 'title' && (e.code === 'Enter' || e.code === 'Space')) {
      this.startGame();
      return;
    }

    if (e.code === 'Escape' || e.code === 'KeyP') {
      if (this.phase === 'playing' || this.phase === 'paused') {
        this.togglePause();
      }
      return;
    }

    if (this.phase !== 'playing') return;

    // Bus Jump/Exit ('F' or 'Space' while riding intro) & Re-Enter ('F') & Horn ('H')
    if (e.code === 'KeyF') {
      if (this.busMode !== 'none') {
        this.exitBus();
      } else if (this.nearBus) {
        this.enterBus();
      }
      return;
    }
    if (e.code === 'Space' && this.busMode === 'riding_intro') {
      this.exitBus();
      return;
    }
    if (e.code === 'KeyH' && this.busMode !== 'none') {
      this.honkBusHorn();
      return;
    }

    this.keysHeld.add(e.code);
    if (e.code === 'KeyR') {
      this.attemptStartReload();
    }
    if (e.code === 'KeyM') {
      this.toggleMute();
    }
  };

  private onKeyUp = (e: KeyboardEvent): void => {
    this.keysHeld.delete(e.code);
  };

  private onWindowBlur = (): void => {
    this.keysHeld.clear();
    this.mouseShootHeld = false;
    this.dragLookActive = false;
    this.dragPointerId = null;
    this.lobbyDragActive = false;
    this.lobbyDragPointerId = null;
    this.virtualInput.shooting = false;
  };

  private onPointerDown = (e: PointerEvent): void => {
    if (e.target !== this.renderer.domElement) return;

    // Free Fire-style lobby: drag left/right to rotate the 3D Bengali hero
    if (this.phase === 'title') {
      this.lobbyDragActive = true;
      this.lobbyDragPointerId = e.pointerId;
      this.lobbyLastDragX = e.clientX;
      return;
    }

    if (this.phase !== 'playing') return;
    this.audio.unlock();

    if (e.pointerType === 'mouse') {
      if (e.button === 0) {
        this.mouseShootHeld = true;
      }
      // Allow smooth mouse drag camera turning on left or right button
      this.dragLookActive = true;
      this.dragPointerId = e.pointerId;
      this.lastDragX = e.clientX;
      this.lastDragY = e.clientY;
    } else {
      // Touch drag on open canvas area rotates the camera smoothly
      this.dragLookActive = true;
      this.dragPointerId = e.pointerId;
      this.lastDragX = e.clientX;
      this.lastDragY = e.clientY;
    }
  };

  private onPointerMove = (e: PointerEvent): void => {
    if (this.phase === 'title') {
      if (this.lobbyDragActive && e.pointerId === this.lobbyDragPointerId) {
        const dx = e.clientX - this.lobbyLastDragX;
        this.lobbyLastDragX = e.clientX;
        this.lobbyHeroTargetYaw += dx * 0.011;
      }
      return;
    }

    if (this.phase !== 'playing') return;

    if (document.pointerLockElement === this.renderer.domElement) {
      this.camYaw -= e.movementX * 0.0032;
      this.camPitch = THREE.MathUtils.clamp(this.camPitch + e.movementY * 0.0024, -0.12, 0.65);
      return;
    }

    if (this.dragLookActive && e.pointerId === this.dragPointerId) {
      const dx = e.clientX - this.lastDragX;
      const dy = e.clientY - this.lastDragY;
      this.lastDragX = e.clientX;
      this.lastDragY = e.clientY;
      this.virtualInput.lookDeltaX += dx;
      this.virtualInput.lookDeltaY += dy;
    }
  };

  private onPointerUp = (e: PointerEvent): void => {
    if (e.pointerId === this.lobbyDragPointerId) {
      this.lobbyDragActive = false;
      this.lobbyDragPointerId = null;
    }
    if (e.pointerType === 'mouse' && e.button === 0) {
      this.mouseShootHeld = false;
    }
    if (e.pointerId === this.dragPointerId) {
      this.dragLookActive = false;
      this.dragPointerId = null;
    }
  };

  private onContextMenu = (e: MouseEvent): void => {
    if (this.phase === 'playing') {
      e.preventDefault();
    }
  };

  private onResize = (): void => {
    const w = this.container.clientWidth || window.innerWidth;
    const h = Math.max(1, this.container.clientHeight || window.innerHeight);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
  };

  private bindEvents(): void {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onWindowBlur);
    window.addEventListener('resize', this.onResize);
    this.renderer.domElement.addEventListener('pointerdown', this.onPointerDown);
    window.addEventListener('pointermove', this.onPointerMove);
    window.addEventListener('pointerup', this.onPointerUp);
    window.addEventListener('pointercancel', this.onPointerUp);
    this.renderer.domElement.addEventListener('contextmenu', this.onContextMenu);
  }

  public dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);

    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onWindowBlur);
    window.removeEventListener('resize', this.onResize);
    this.renderer.domElement.removeEventListener('pointerdown', this.onPointerDown);
    window.removeEventListener('pointermove', this.onPointerMove);
    window.removeEventListener('pointerup', this.onPointerUp);
    window.removeEventListener('pointercancel', this.onPointerUp);
    this.renderer.domElement.removeEventListener('contextmenu', this.onContextMenu);

    this.scene.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh) {
        const mesh = obj as THREE.Mesh;
        mesh.geometry?.dispose();
        if (Array.isArray(mesh.material)) {
          mesh.material.forEach((m) => m.dispose());
        } else {
          mesh.material?.dispose();
        }
      }
    });

    this.textures.disposeAll();
    this.audio.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
