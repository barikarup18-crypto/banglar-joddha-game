export type GamePhase = 'title' | 'playing' | 'paused' | 'gameover';

export type BusMode = 'none' | 'riding_intro' | 'driving';

export type GamchaStyle = 'red-white' | 'green-white';

export type WeaponType = 'rifle' | 'shotgun';

export type EnemyArchetype = 'scout' | 'heavy' | 'rusher';

export type PickupKind = 'health' | 'ammo';

export interface HudSnapshot {
  phase: GamePhase;
  busMode: BusMode;
  nearBus: boolean;
  busZoneLabel: string | null;
  busSpeedKmh: number;
  busRouteProgress: number;
  health: number;
  maxHealth: number;
  ammo: number;
  maxAmmo: number;
  reserveAmmo: number;
  isReloading: boolean;
  reloadProgress: number;
  score: number;
  highScore: number;
  kills: number;
  wave: number;
  enemiesRemaining: number;
  waveBanner: string | null;
  damageFlash: number;
  hitMarker: number;
  hitMarkerKill: boolean;
  muted: boolean;
  sprintRatio: number;
  pickupToast: string | null;
}

export interface CircleCollider {
  x: number;
  z: number;
  radius: number;
  height: number;
  kind: 'house' | 'tree' | 'taxi' | 'prop';
}

export interface BoxCollider {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  height: number;
  kind: 'house' | 'taxi' | 'wall';
}

export interface VirtualInputState {
  moveX: number; // -1..1 (right positive)
  moveY: number; // -1..1 (forward positive)
  shooting: boolean;
  sprinting: boolean;
  reloadJustPressed: boolean;
  lookDeltaX: number;
  lookDeltaY: number;
}
