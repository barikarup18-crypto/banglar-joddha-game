import * as THREE from 'three';
import { TextureBundle } from './textures';

export interface WbtcBusRig {
  root: THREE.Group;
  chassisGroup: THREE.Group;
  wheels: THREE.Object3D[];
  frontWheelPivots: THREE.Group[];
  headlights: THREE.Mesh[];
  heroIntroSeat: THREE.Object3D;
  heroDriverSeat: THREE.Object3D;
  doorExitPoint: THREE.Object3D;
  enemySeats: THREE.Object3D[];
}

export interface BusRouteData {
  curve: THREE.CatmullRomCurve3;
  rampMesh: THREE.Group;
}

/**
 * Builds a classic West Bengal WBTC-style 3D passenger bus (blue-and-white with yellow-red livery stripe,
 * destination header board, open-air windows & side doorway so passengers inside are clearly visible,
 * roof luggage rail, spinning wheels, and Indian right-hand-drive steering cab).
 * Local forward axis is +Z.
 */
export function buildWbtcBus(textures: TextureBundle): WbtcBusRig {
  const root = new THREE.Group();
  const chassisGroup = new THREE.Group();
  root.add(chassisGroup);

  const wbtcBlue = new THREE.MeshPhysicalMaterial({
    color: 0x1362b5,
    roughness: 0.34,
    metalness: 0.2,
    clearcoat: 0.75,
    clearcoatRoughness: 0.2,
  });
  const wbtcWhite = new THREE.MeshPhysicalMaterial({
    color: 0xf4f6f7,
    roughness: 0.38,
    metalness: 0.1,
    clearcoat: 0.5,
  });
  const stripeYellow = new THREE.MeshStandardMaterial({
    color: 0xf4be1c,
    roughness: 0.36,
    metalness: 0.18,
  });
  const stripeRed = new THREE.MeshStandardMaterial({
    color: 0xcc2229,
    roughness: 0.4,
    metalness: 0.12,
  });
  const sideLiveryMat = new THREE.MeshStandardMaterial({
    map: textures.busSideMap,
    roughness: 0.38,
    metalness: 0.16,
  });
  const destBoardMat = new THREE.MeshStandardMaterial({
    map: textures.busDestinationMap,
    emissive: 0xffc83d,
    emissiveMap: textures.busDestinationMap,
    emissiveIntensity: 0.45,
    roughness: 0.3,
  });
  const darkMetal = new THREE.MeshStandardMaterial({
    color: 0x22262b,
    roughness: 0.55,
    metalness: 0.6,
  });
  const chromeMat = new THREE.MeshStandardMaterial({
    color: 0xe6ecf0,
    roughness: 0.2,
    metalness: 0.9,
  });
  const interiorFloorMat = new THREE.MeshStandardMaterial({
    color: 0x3b3532,
    roughness: 0.92,
  });
  const seatMat = new THREE.MeshStandardMaterial({
    color: 0x7c3322,
    roughness: 0.8,
  });
  const glassMat = new THREE.MeshPhysicalMaterial({
    color: 0x89b7cf,
    transparent: true,
    opacity: 0.26,
    roughness: 0.12,
    metalness: 0.1,
    depthWrite: false,
  });
  const rubberMat = new THREE.MeshStandardMaterial({
    color: 0x161616,
    roughness: 0.92,
  });
  const headlightMat = new THREE.MeshStandardMaterial({
    color: 0xfff5cf,
    emissive: 0xffd26e,
    emissiveIntensity: 1.6,
    roughness: 0.2,
  });
  const taillightMat = new THREE.MeshStandardMaterial({
    color: 0xd92626,
    emissive: 0xcc1d1d,
    emissiveIntensity: 1.1,
    roughness: 0.25,
  });

  // Soft ground contact shadow under bus
  const shadowGeo = new THREE.PlaneGeometry(3.5, 9.6);
  shadowGeo.rotateX(-Math.PI / 2);
  const shadowMesh = new THREE.Mesh(
    shadowGeo,
    new THREE.MeshBasicMaterial({
      map: textures.contactShadowMap,
      transparent: true,
      opacity: 0.6,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -1,
      polygonOffsetUnits: -1,
    }),
  );
  shadowMesh.position.y = 0.03;
  root.add(shadowMesh);

  // 1. Floor deck & undercarriage chassis frame (y = 0.56 .. 0.86)
  const floorDeck = new THREE.Mesh(new THREE.BoxGeometry(2.5, 0.24, 8.2), interiorFloorMat);
  floorDeck.position.set(0, 0.68, 0);
  floorDeck.castShadow = true;
  floorDeck.receiveShadow = true;
  chassisGroup.add(floorDeck);

  // 2. Lower painted side skirts (WBTC blue-white-yellow-red livery texture)
  // Left side (+X): full length lower panel
  const leftSkirt = new THREE.Mesh(new THREE.BoxGeometry(0.12, 1.05, 8.2), [
    sideLiveryMat,
    wbtcBlue,
    wbtcWhite,
    darkMetal,
    wbtcBlue,
    wbtcBlue,
  ]);
  leftSkirt.position.set(1.22, 1.18, 0);
  leftSkirt.castShadow = true;
  leftSkirt.receiveShadow = true;
  chassisGroup.add(leftSkirt);

  // Right side (-X): split to leave a wide open Indian bus passenger doorway near front-middle (z = +1.4..+2.9)
  const rightSkirtRear = new THREE.Mesh(new THREE.BoxGeometry(0.12, 1.05, 5.4), [
    wbtcBlue,
    sideLiveryMat,
    wbtcWhite,
    darkMetal,
    wbtcBlue,
    wbtcBlue,
  ]);
  rightSkirtRear.position.set(-1.22, 1.18, -1.4);
  rightSkirtRear.castShadow = true;
  chassisGroup.add(rightSkirtRear);

  const rightSkirtFront = new THREE.Mesh(new THREE.BoxGeometry(0.12, 1.05, 1.25), wbtcBlue);
  rightSkirtFront.position.set(-1.22, 1.18, 3.48);
  chassisGroup.add(rightSkirtFront);

  // Yellow & red door step frame at open passenger entry (-X, z = 2.15)
  const doorStep = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.08, 1.45), stripeYellow);
  doorStep.position.set(-1.18, 0.54, 2.12);
  chassisGroup.add(doorStep);

  // 3. Front & Rear lower bulkheads with yellow/red accent stripe
  const frontLower = new THREE.Mesh(new THREE.BoxGeometry(2.54, 1.1, 0.22), wbtcBlue);
  frontLower.position.set(0, 1.16, 4.08);
  frontLower.castShadow = true;
  chassisGroup.add(frontLower);

  const frontYellowBand = new THREE.Mesh(new THREE.BoxGeometry(2.58, 0.22, 0.25), stripeYellow);
  frontYellowBand.position.set(0, 1.56, 4.08);
  chassisGroup.add(frontYellowBand);

  const frontRedBand = new THREE.Mesh(new THREE.BoxGeometry(2.58, 0.12, 0.25), stripeRed);
  frontRedBand.position.set(0, 1.4, 4.08);
  chassisGroup.add(frontRedBand);

  const rearLower = new THREE.Mesh(new THREE.BoxGeometry(2.54, 1.15, 0.22), wbtcBlue);
  rearLower.position.set(0, 1.18, -4.08);
  rearLower.castShadow = true;
  chassisGroup.add(rearLower);

  const rearStripe = new THREE.Mesh(new THREE.BoxGeometry(2.58, 0.22, 0.25), stripeYellow);
  rearStripe.position.set(0, 1.56, -4.08);
  chassisGroup.add(rearStripe);

  // 4. White Window Pillars (leaves open/clear view into cabin so hero & AI bots are super visible!)
  const pillarZs = [-4.02, -2.6, -1.15, 0.3, 1.4, 2.85, 4.02];
  for (const pz of pillarZs) {
    for (const px of [-1.22, 1.22]) {
      const pillar = new THREE.Mesh(new THREE.BoxGeometry(0.14, 1.24, 0.16), wbtcWhite);
      pillar.position.set(px, 2.32, pz);
      pillar.castShadow = true;
      chassisGroup.add(pillar);
    }
  }
  // Center front windshield divider (classic Kolkata bus split windshield!)
  const frontDivider = new THREE.Mesh(new THREE.BoxGeometry(0.1, 1.22, 0.12), wbtcWhite);
  frontDivider.position.set(0, 2.32, 4.08);
  chassisGroup.add(frontDivider);

  // Semi-translucent front & side window panes (leaving open doorway unobstructed)
  const frontWindshield = new THREE.Mesh(new THREE.PlaneGeometry(2.34, 1.14), glassMat);
  frontWindshield.position.set(0, 2.32, 4.14);
  chassisGroup.add(frontWindshield);

  const leftGlass = new THREE.Mesh(new THREE.PlaneGeometry(7.8, 1.05), glassMat);
  leftGlass.rotation.y = Math.PI / 2;
  leftGlass.position.set(1.26, 2.32, 0);
  chassisGroup.add(leftGlass);

  const rightGlass = new THREE.Mesh(new THREE.PlaneGeometry(5.1, 1.05), glassMat);
  rightGlass.rotation.y = -Math.PI / 2;
  rightGlass.position.set(-1.26, 2.32, -1.4);
  chassisGroup.add(rightGlass);

  // 5. Roof Crown, Destination Board ('S-12 হাওড়া ↔ গ্রাম') & Classic Roof Luggage Rail
  const roofUpper = new THREE.Mesh(new THREE.BoxGeometry(2.58, 0.34, 8.34), wbtcWhite);
  roofUpper.position.set(0, 3.08, 0);
  roofUpper.castShadow = true;
  roofUpper.receiveShadow = true;
  chassisGroup.add(roofUpper);

  const roofBlueCap = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.14, 7.6), wbtcBlue);
  roofBlueCap.position.set(0, 3.28, -0.1);
  chassisGroup.add(roofBlueCap);

  // Front illuminated destination board
  const destBoard = new THREE.Mesh(new THREE.BoxGeometry(1.76, 0.32, 0.12), [
    darkMetal,
    darkMetal,
    darkMetal,
    darkMetal,
    destBoardMat,
    darkMetal,
  ]);
  destBoard.position.set(0, 3.08, 4.18);
  chassisGroup.add(destBoard);

  // Roof side safety guard rails
  for (const rx of [-1.06, 1.06]) {
    const rail = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 6.2, 6), chromeMat);
    rail.rotation.x = Math.PI / 2;
    rail.position.set(rx, 3.44, -0.4);
    chassisGroup.add(rail);
  }

  // 6. Front Radiator Grille, Chrome Bumpers, Headlights, Tail Lamps & Side Mirrors
  const grille = new THREE.Mesh(new THREE.BoxGeometry(1.45, 0.42, 0.12), darkMetal);
  grille.position.set(0, 0.96, 4.18);
  chassisGroup.add(grille);

  for (const gy of [0.86, 0.96, 1.06]) {
    const slat = new THREE.Mesh(new THREE.BoxGeometry(1.36, 0.035, 0.15), chromeMat);
    slat.position.set(0, gy, 4.19);
    chassisGroup.add(slat);
  }

  // Front & rear bumpers
  for (const bz of [4.24, -4.24]) {
    const bumper = new THREE.Mesh(new THREE.BoxGeometry(2.62, 0.2, 0.22), chromeMat);
    bumper.position.set(0, 0.62, bz);
    chassisGroup.add(bumper);
  }

  // Front West Bengal license plate
  const plateMat = new THREE.MeshStandardMaterial({ map: textures.licensePlateMap, roughness: 0.45 });
  const frontPlate = new THREE.Mesh(new THREE.PlaneGeometry(0.72, 0.2), plateMat);
  frontPlate.position.set(0, 0.62, 4.36);
  chassisGroup.add(frontPlate);

  const headlights: THREE.Mesh[] = [];
  for (const hx of [-0.94, 0.94]) {
    const lamp = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 0.1, 12), headlightMat);
    lamp.rotation.x = Math.PI / 2;
    lamp.position.set(hx, 0.98, 4.19);
    chassisGroup.add(lamp);
    headlights.push(lamp);

    const tail = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.34, 0.12), taillightMat);
    tail.position.set(hx, 1.05, -4.19);
    chassisGroup.add(tail);

    // Tall Indian bus side mirror arms
    const mirrorArm = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.04, 0.04), darkMetal);
    mirrorArm.position.set(hx > 0 ? 1.4 : -1.4, 2.3, 4.15);
    chassisGroup.add(mirrorArm);

    const mirrorGlass = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.36, 0.16), darkMetal);
    mirrorGlass.position.set(hx > 0 ? 1.52 : -1.52, 2.22, 4.22);
    chassisGroup.add(mirrorGlass);
  }

  // 7. Interior Passenger Benches & Indian Right-Hand-Drive Steering Column
  const steeringWheel = new THREE.Mesh(new THREE.TorusGeometry(0.22, 0.032, 8, 16), darkMetal);
  steeringWheel.position.set(-0.62, 1.56, 3.45);
  steeringWheel.rotation.x = Math.PI * 0.36;
  chassisGroup.add(steeringWheel);

  const driverSeat = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.6, 0.55), seatMat);
  driverSeat.position.set(-0.62, 1.1, 2.95);
  chassisGroup.add(driverSeat);

  for (let row = 0; row < 4; row++) {
    const rz = 0.6 - row * 1.15;
    for (const sx of [-0.74, 0.74]) {
      const bench = new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.45, 0.48), seatMat);
      bench.position.set(sx, 1.0, rz);
      chassisGroup.add(bench);
    }
  }

  // 8. Four Heavy-Duty Bus Wheels (front two inside steering pivots)
  const wheels: THREE.Object3D[] = [];
  const frontWheelPivots: THREE.Group[] = [];
  const tireGeo = new THREE.CylinderGeometry(0.54, 0.54, 0.36, 18);
  tireGeo.rotateZ(Math.PI / 2);
  const rimGeo = new THREE.CylinderGeometry(0.3, 0.3, 0.39, 12);
  rimGeo.rotateZ(Math.PI / 2);
  const boltGeo = new THREE.BoxGeometry(0.41, 0.08, 0.48);

  const wheelDefs: [number, number, boolean][] = [
    [-1.18, 2.55, true],
    [1.18, 2.55, true],
    [-1.18, -2.35, false],
    [1.18, -2.35, false],
  ];

  for (const [wx, wz, isFront] of wheelDefs) {
    const pivot = new THREE.Group();
    pivot.position.set(wx, 0.54, wz);
    root.add(pivot);

    const spinGroup = new THREE.Group();
    const tire = new THREE.Mesh(tireGeo, rubberMat);
    tire.castShadow = true;
    const rim = new THREE.Mesh(rimGeo, chromeMat);
    const lug = new THREE.Mesh(boltGeo, darkMetal);
    spinGroup.add(tire, rim, lug);
    pivot.add(spinGroup);

    wheels.push(spinGroup);
    if (isFront) frontWheelPivots.push(pivot);
  }

  // 9. Passenger & Driver Seat Anchors (visible through open doorway, windows & roof!)
  // Hero rides standing heroically in the open side passenger doorway / window during intro
  const heroIntroSeat = new THREE.Object3D();
  heroIntroSeat.position.set(-0.92, 0.78, 2.08);
  chassisGroup.add(heroIntroSeat);

  // Hero sits at the steering wheel when driving the bus later
  const heroDriverSeat = new THREE.Object3D();
  heroDriverSeat.position.set(-0.62, 0.82, 2.85);
  chassisGroup.add(heroDriverSeat);

  // Door exit spawn offset (just outside the right-side doorway)
  const doorExitPoint = new THREE.Object3D();
  doorExitPoint.position.set(-2.35, 0.0, 2.1);
  chassisGroup.add(doorExitPoint);

  // 6 Visible Enemy Rider Anchors inside cabin windows & riding atop the classic Bengal bus roof
  const enemySeatCoords: [number, number, number][] = [
    [0.68, 0.85, 1.35],
    [-0.68, 0.85, 0.2],
    [0.68, 0.85, -0.95],
    [-0.68, 0.85, -2.1],
    [0.55, 3.24, -0.45], // riding on roof rail!
    [-0.55, 3.24, -1.95], // riding on roof rail!
  ];
  const enemySeats: THREE.Object3D[] = enemySeatCoords.map(([x, y, z]) => {
    const seat = new THREE.Object3D();
    seat.position.set(x, y, z);
    chassisGroup.add(seat);
    return seat;
  });

  return {
    root,
    chassisGroup,
    wheels,
    frontWheelPivots,
    headlights,
    heroIntroSeat,
    heroDriverSeat,
    doorExitPoint,
    enemySeats,
  };
}

/**
 * Creates the smooth 3D road curve starting across the Howrah-style bridge,
 * descending the eastern riverbank approach viaduct, and cruising straight down
 * the West Bengal village main road past the yellow taxi and mud houses.
 */
export function createBusIntroRoute(): BusRouteData {
  const waypoints = [
    new THREE.Vector3(-54, 6.58, -40), // West span of Howrah Bridge
    new THREE.Vector3(-22, 6.58, -40), // Western tower portal
    new THREE.Vector3(12, 6.58, -40),  // Mid-span over Hooghly River
    new THREE.Vector3(33, 6.45, -39.2), // Eastern tower exit onto viaduct
    new THREE.Vector3(41, 4.4, -27.5), // Descending riverbank ramp curve
    new THREE.Vector3(38.5, 1.35, -11.5), // Lower ramp approaching village
    new THREE.Vector3(32, 0.0, 3.5),   // Merging into east village entry
    new THREE.Vector3(22, 0.0, 8.2),   // Village main road East
    new THREE.Vector3(5, 0.0, 8.2),    // Central village square near Yellow Taxi
    new THREE.Vector3(-13, 0.0, 8.2),  // West village main road bus stop
  ];

  const curve = new THREE.CatmullRomCurve3(waypoints, false, 'centripetal', 0.4);

  // Build physical 3D asphalt & stone-pillared approach viaduct connecting bridge deck (y=6.58) to village road (y=0)
  const rampMesh = new THREE.Group();
  const roadMat = new THREE.MeshStandardMaterial({
    color: 0x454446,
    roughness: 0.9,
    metalness: 0.04,
  });
  const curbMat = new THREE.MeshStandardMaterial({
    color: 0xb68b5a,
    roughness: 0.88,
  });
  const pillarMat = new THREE.MeshStandardMaterial({
    color: 0x877b6f,
    roughness: 0.92,
  });

  // Sample ramp section from t = 0.34 (east bridge exit) to t = 0.72 (village road merge)
  const steps = 22;
  const tStart = 0.34;
  const tEnd = 0.72;
  const pA = new THREE.Vector3();
  const pB = new THREE.Vector3();
  const mid = new THREE.Vector3();

  for (let i = 0; i < steps; i++) {
    const t0 = THREE.MathUtils.lerp(tStart, tEnd, i / steps);
    const t1 = THREE.MathUtils.lerp(tStart, tEnd, (i + 1) / steps);
    curve.getPointAt(t0, pA);
    curve.getPointAt(t1, pB);
    mid.addVectors(pA, pB).multiplyScalar(0.5);
    const segLen = pA.distanceTo(pB) + 0.35;

    const seg = new THREE.Mesh(new THREE.BoxGeometry(5.6, 0.42, segLen), roadMat);
    seg.position.set(mid.x, Math.max(0.02, mid.y - 0.18), mid.z);
    seg.lookAt(pB.x, Math.max(0.02, pB.y - 0.18), pB.z);
    seg.receiveShadow = true;
    rampMesh.add(seg);

    // Side safety curbs along elevated portion
    if (mid.y > 0.35) {
      const curbL = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.55, segLen), curbMat);
      curbL.position.set(-2.7, 0.28, 0);
      const curbR = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.55, segLen), curbMat);
      curbR.position.set(2.7, 0.28, 0);
      seg.add(curbL, curbR);
    }

    // Concrete support piers every 4 segments where ramp is elevated
    if (i % 4 === 1 && mid.y > 0.8) {
      const pierH = mid.y + 1.8;
      const pier = new THREE.Mesh(new THREE.BoxGeometry(1.4, pierH, 1.4), pillarMat);
      pier.position.set(mid.x, mid.y - pierH * 0.5 - 0.2, mid.z);
      rampMesh.add(pier);
    }
  }

  return { curve, rampMesh };
}
