import * as THREE from 'three';
import { TextureBundle } from './textures';
import { EnemyArchetype, PickupKind } from './types';

export interface HeroRig {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  headGroup: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  leftKnee: THREE.Group;
  rightKnee: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  gamchaTail: THREE.Mesh;
  gamchaMaterial: THREE.MeshStandardMaterial;
  rifleGroup: THREE.Group;
  shotgunGroup: THREE.Group;
  muzzlePoint: THREE.Object3D;
  muzzleFlash: THREE.Mesh;
  muzzleLight: THREE.PointLight;
  recoilGroup: THREE.Group;
  updateGamchaCloth: (
    dt: number,
    time: number,
    localVelX: number,
    localVelY: number,
    localVelZ: number,
    yawRate: number,
    windBoost: number,
  ) => void;
}

export interface EnemyRig {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  headGroup: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  leftKnee: THREE.Group;
  rightKnee: THREE.Group;
  weaponPivot: THREE.Group;
  muzzlePoint: THREE.Object3D;
  telegraphGlow: THREE.Mesh;
  hpBarBg: THREE.Mesh;
  hpBarFill: THREE.Mesh;
  flashMaterials: THREE.MeshStandardMaterial[];
  baseEmissives: THREE.Color[];
}

// Module-level reusable math helpers (zero GC inside builders/updates)
const _up = new THREE.Vector3(0, 1, 0);
const _dir = new THREE.Vector3();
const _mid = new THREE.Vector3();
const _quat = new THREE.Quaternion();

function addActorShadow(parent: THREE.Object3D, shadowMap: THREE.CanvasTexture, size = 1.35): void {
  const geo = new THREE.PlaneGeometry(size, size);
  geo.rotateX(-Math.PI / 2);
  const mat = new THREE.MeshBasicMaterial({
    map: shadowMap,
    transparent: true,
    opacity: 0.56,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.y = 0.025;
  parent.add(mesh);
}

// ============================================================================
// Realistic PBR Materials (Skin Subsurface Shader, Woven Fabric, Hair, Leather)
// ============================================================================

/**
 * Realistic human PBR skin material using MeshPhysicalMaterial with skin-pore bump,
 * soft velvet sheen, natural epidermal clearcoat, and an injected warm subsurface
 * scattering (SSS) wrap-lighting term so cheeks, jawline, ears, and forearms glow warmly.
 */
function createRealisticSkinMaterial(
  baseHex: number,
  textures: TextureBundle,
): THREE.MeshPhysicalMaterial {
  const mat = new THREE.MeshPhysicalMaterial({
    color: baseHex,
    roughness: 0.52,
    metalness: 0.0,
    bumpMap: textures.skinBumpMap,
    bumpScale: 0.0042,
    sheen: 0.34,
    sheenRoughness: 0.72,
    sheenColor: new THREE.Color(0xeaa480),
    clearcoat: 0.09,
    clearcoatRoughness: 0.56,
  });

  mat.onBeforeCompile = (shader) => {
    shader.fragmentShader = shader.fragmentShader.replace(
      '#include <lights_fragment_end>',
      `
      #include <lights_fragment_end>
      vec3 sssNormal = normalize( vNormal );
      vec3 sssView = normalize( vViewPosition );
      float sssRim = pow( 1.0 - clamp( dot( sssNormal, sssView ), 0.0, 1.0 ), 2.4 );
      float sssWrap = clamp( dot( sssNormal, normalize( vec3( 0.45, 0.65, 0.35 ) ) ) * 0.5 + 0.5, 0.0, 1.0 );
      reflectedLight.indirectDiffuse += vec3( 0.145, 0.044, 0.024 ) * ( 0.35 + 0.65 * sssRim ) * sssWrap;
      `,
    );
  };
  mat.customProgramCacheKey = () => 'bengal-realistic-skin-sss-v1';

  return mat;
}

function createClothMaterial(
  colorHex: number,
  textures: TextureBundle,
  options?: {
    map?: THREE.Texture;
    roughness?: number;
    sheen?: number;
    sheenColor?: number;
    side?: THREE.Side;
    bumpScale?: number;
  },
): THREE.MeshPhysicalMaterial {
  return new THREE.MeshPhysicalMaterial({
    color: colorHex,
    map: options?.map ?? null,
    roughness: options?.roughness ?? 0.86,
    metalness: 0.0,
    bumpMap: textures.fabricBumpMap,
    bumpScale: options?.bumpScale ?? 0.008,
    sheen: options?.sheen ?? 0.46,
    sheenRoughness: 0.78,
    sheenColor: new THREE.Color(options?.sheenColor ?? 0xf4ebe0),
    side: options?.side ?? THREE.FrontSide,
  });
}

function createHairMaterial(colorHex = 0x181412): THREE.MeshPhysicalMaterial {
  return new THREE.MeshPhysicalMaterial({
    color: colorHex,
    roughness: 0.54,
    metalness: 0.04,
    sheen: 0.38,
    sheenRoughness: 0.45,
    sheenColor: new THREE.Color(0x52463f),
  });
}

// ============================================================================
// Sculpted Organic Humanoid Geometry Generators (Lathe + Analytical Sculpting)
// ============================================================================

/**
 * Generates an anatomically contoured human torso from pelvis (y=0) to shoulder crest (y=0.58)
 * by starting with a smooth LatheGeometry and sculpting pectorals, ribcage taper, lumbar curve,
 * shoulder deltoid breadth, and dorsal spine groove directly into the vertex buffer.
 */
function createContouredTorsoGeometry(widthMult = 1.0, depthMult = 1.0): THREE.BufferGeometry {
  const profile: THREE.Vector2[] = [
    new THREE.Vector2(0.001, 0.0),
    new THREE.Vector2(0.145, 0.02),
    new THREE.Vector2(0.168, 0.07), // hips / pelvis
    new THREE.Vector2(0.156, 0.14), // lower waist
    new THREE.Vector2(0.148, 0.21), // tapered athletic waist
    new THREE.Vector2(0.164, 0.29), // lower ribcage / obliques
    new THREE.Vector2(0.188, 0.37), // mid chest / lats
    new THREE.Vector2(0.212, 0.45), // broad pectorals / upper lats
    new THREE.Vector2(0.218, 0.51), // clavicular shoulder line
    new THREE.Vector2(0.165, 0.56), // trapezius slope
    new THREE.Vector2(0.088, 0.59), // neck collar base
    new THREE.Vector2(0.001, 0.595),
  ];

  const geo = new THREE.LatheGeometry(profile, 28);
  const pos = geo.attributes.position;

  for (let i = 0; i < pos.count; i++) {
    let x = pos.getX(i);
    const y = pos.getY(i);
    let z = pos.getZ(i);

    const ny = THREE.MathUtils.clamp(y / 0.59, 0, 1);

    // Realistic elliptical human torso cross-section (broader shoulders, trimmer depth)
    const xScale = (1.06 + ny * 0.16) * widthMult;
    const zScale = (0.68 - Math.abs(ny - 0.68) * 0.08) * depthMult;
    x *= xScale;
    z *= zScale;

    // Subtle anatomical S-curve along spine (slight lumbar hollow, proud chest)
    const spineShift = Math.sin((ny - 0.25) * Math.PI) * 0.014;
    z += spineShift;

    // Pectoral fullness on front upper chest + subtle sternum valley at x = 0
    if (z > 0.02 && ny > 0.48 && ny < 0.88) {
      const chestBell = Math.sin(((ny - 0.48) / 0.4) * Math.PI);
      const pecX = Math.exp(-Math.pow((Math.abs(x) - 0.095) / 0.075, 2));
      const sternumDip = Math.exp(-Math.pow(x / 0.032, 2)) * 0.009;
      z += chestBell * (pecX * 0.022 - sternumDip);
    }

    // Subtle dorsal spine groove & shoulder-blade definition along back
    if (z < -0.02 && ny > 0.18 && ny < 0.88) {
      const backBell = Math.sin(((ny - 0.18) / 0.7) * Math.PI);
      const spineGroove = Math.exp(-Math.pow(x / 0.035, 2)) * 0.013;
      const scapula = ny > 0.55 ? Math.exp(-Math.pow((Math.abs(x) - 0.1) / 0.06, 2)) * 0.012 : 0;
      z += backBell * (spineGroove - scapula);
    }

    // Subtle lower abdominal taper
    if (z > 0.01 && ny > 0.12 && ny < 0.45) {
      const absCurve = Math.sin(((ny - 0.12) / 0.33) * Math.PI);
      z += absCurve * 0.008 * Math.exp(-Math.pow(x / 0.1, 2));
    }

    pos.setXYZ(i, x, y, z);
  }

  geo.computeVertexNormals();
  return geo;
}

/**
 * Generates an organic sculpted limb segment (thigh, calf, upper arm, forearm, neck)
 * along the +Y axis from y = 0 to y = length using LatheGeometry + elliptical muscle contour.
 */
function createContouredLimbGeometry(
  profilePairs: Array<[number, number]>, // [normalizedT (0..1), radius]
  length: number,
  xScale = 1.0,
  zScale = 1.0,
  radialSegments = 18,
  muscleBulgeZ = 0,
): THREE.BufferGeometry {
  const pts: THREE.Vector2[] = [];
  pts.push(new THREE.Vector2(0.001, 0));
  for (const [t, r] of profilePairs) {
    pts.push(new THREE.Vector2(Math.max(0.002, r), t * length));
  }
  pts.push(new THREE.Vector2(0.001, length));

  const geo = new THREE.LatheGeometry(pts, radialSegments);
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i) * xScale;
    const y = pos.getY(i);
    let z = pos.getZ(i) * zScale;

    if (muscleBulgeZ !== 0) {
      const ny = y / Math.max(0.001, length);
      z += Math.sin(ny * Math.PI) * muscleBulgeZ;
    }

    pos.setXYZ(i, x, y, z);
  }
  geo.computeVertexNormals();
  return geo;
}

/**
 * Generates a realistic sculpted human head geometry starting from a subdivided SphereGeometry,
 * carving authentic cranial volume, tapered angular jawline, chin, brow ridge, cheekbones,
 * recessed eye sockets (orbital cavities), and nasal-philtrum contour.
 */
function createSculptedHeadGeometry(): THREE.BufferGeometry {
  const geo = new THREE.SphereGeometry(0.112, 32, 26);
  const pos = geo.attributes.position;

  for (let i = 0; i < pos.count; i++) {
    let x = pos.getX(i);
    let y = pos.getY(i);
    let z = pos.getZ(i);

    // Overall realistic human cranium proportions (slightly taller & deeper front-to-back)
    x *= 0.89;
    y *= 1.13;
    z *= 1.02;

    const absX = Math.abs(x);

    // 1. Cranial back (occiput) slightly rounded upward & backward
    if (y > 0.015 && z < 0.01) {
      const craniumT = THREE.MathUtils.clamp((y - 0.015) / 0.1, 0, 1);
      z -= craniumT * 0.012;
      x *= 1.0 + craniumT * 0.04;
    }

    // 2. Temple narrowing beside the forehead
    if (y > 0.015 && y < 0.08 && z > -0.01 && absX > 0.055) {
      const templeW = Math.exp(-Math.pow((y - 0.042) / 0.028, 2)) * Math.exp(-Math.pow((z - 0.025) / 0.035, 2));
      x *= 1.0 - templeW * 0.085;
    }

    // 3. Tapered angular jawline & sculpted chin (y < -0.015)
    if (y < -0.015) {
      const jawT = THREE.MathUtils.clamp((-0.015 - y) / 0.115, 0, 1);
      // Narrow smoothly toward chin tip while preserving defined jaw corners near z ~ 0.0
      const frontFactor = THREE.MathUtils.clamp((z + 0.04) / 0.13, 0, 1);
      const jawNarrow = 1.0 - jawT * (0.28 + frontFactor * 0.24);
      x *= jawNarrow;

      // Sculpt distinct chin projection at front bottom
      if (z > 0.01) {
        const chinBell = Math.exp(-Math.pow((y + 0.105) / 0.028, 2)) * Math.exp(-Math.pow(x / 0.034, 2));
        z += chinBell * 0.024;
        y -= chinBell * 0.008;
      }

      // Tuck underside of skull smoothly into neck at back-bottom
      if (z < -0.01) {
        z += jawT * 0.036;
      }

      // Slight defined jaw angle (gonion)
      const gonion =
        Math.exp(-Math.pow((y + 0.068) / 0.022, 2)) *
        Math.exp(-Math.pow((z - 0.008) / 0.028, 2)) *
        THREE.MathUtils.clamp((absX - 0.04) / 0.04, 0, 1);
      x += Math.sign(x) * gonion * 0.01;
    }

    // 4. Brow ridge overhang above eyes
    if (z > 0.055 && y > 0.018 && y < 0.052) {
      const brow =
        Math.exp(-Math.pow((y - 0.033) / 0.013, 2)) *
        Math.exp(-Math.pow(x / 0.058, 2));
      z += brow * 0.014;
    }

    // 5. Recessed eye orbits (carved cavities so realistic eyes sit naturally inside the skull)
    if (z > 0.055) {
      const leftEyeDist = Math.hypot((x + 0.034) / 0.022, (y - 0.009) / 0.016);
      const rightEyeDist = Math.hypot((x - 0.034) / 0.022, (y - 0.009) / 0.016);
      const orbitDepth = Math.exp(-leftEyeDist * leftEyeDist) + Math.exp(-rightEyeDist * rightEyeDist);
      z -= orbitDepth * 0.018;
    }

    // 6. Cheekbone prominence (zygomatic arch below outer eyes)
    if (z > 0.02 && y > -0.042 && y < 0.005) {
      const cheek =
        Math.exp(-Math.pow((absX - 0.058) / 0.024, 2)) *
        Math.exp(-Math.pow((y + 0.017) / 0.018, 2));
      x += Math.sign(x) * cheek * 0.0085;
      z += cheek * 0.009;
    }

    // 7. Subtle hollow below cheekbones (sculpted athletic cheeks)
    if (z > 0.02 && y < -0.035 && y > -0.082) {
      const hollow =
        Math.exp(-Math.pow((absX - 0.054) / 0.02, 2)) *
        Math.exp(-Math.pow((y + 0.056) / 0.02, 2));
      x -= Math.sign(x) * hollow * 0.006;
      z -= hollow * 0.004;
    }

    // 8. Mouth barrel / philtrum subtle anterior curve
    if (z > 0.06 && y < -0.032 && y > -0.086) {
      const mouthMound =
        Math.exp(-Math.pow((y + 0.058) / 0.024, 2)) *
        Math.exp(-Math.pow(x / 0.038, 2));
      z += mouthMound * 0.009;
    }

    pos.setXYZ(i, x, y, z);
  }

  geo.computeVertexNormals();
  return geo;
}

/**
 * Builds a realistic short skin-fade haircut with tapered buzzed sides/nape
 * and textured, organically sculpted swept top locks.
 */
function buildShortFadeHair(
  hairMat: THREE.MeshPhysicalMaterial,
  fadeMat: THREE.MeshStandardMaterial,
): THREE.Group {
  const hairGroup = new THREE.Group();

  // 1. Skin-fade lower sides & tapered occiput hugging the skull cleanly
  const fadeGeo = new THREE.SphereGeometry(0.108, 26, 20, 0, Math.PI * 2, 0.05, Math.PI * 0.56);
  const fPos = fadeGeo.attributes.position;
  for (let i = 0; i < fPos.count; i++) {
    let x = fPos.getX(i) * 0.915;
    let y = fPos.getY(i) * 1.12;
    let z = fPos.getZ(i) * 1.035;

    // Push hairline cleanly back over the forehead so face & eyebrows stay completely clear
    if (z > 0.045) {
      const browCut = THREE.MathUtils.clamp((0.068 - y) / 0.06, 0, 1);
      z -= browCut * 0.032;
      y += browCut * 0.015;
    }
    // Taper cleanly down the nape of the neck at back
    if (z < -0.03) {
      y -= 0.01;
    }
    fPos.setXYZ(i, x, y, z);
  }
  fadeGeo.computeVertexNormals();
  const fadeCap = new THREE.Mesh(fadeGeo, fadeMat);
  fadeCap.position.set(0, 0.008, -0.006);
  fadeCap.castShadow = true;
  hairGroup.add(fadeCap);

  // 2. Fuller textured short-crop top volume (sculpted dome sitting above the fade line)
  const topGeo = new THREE.SphereGeometry(0.104, 24, 16, 0, Math.PI * 2, 0, Math.PI * 0.44);
  const tPos = topGeo.attributes.position;
  for (let i = 0; i < tPos.count; i++) {
    let x = tPos.getX(i) * 0.88;
    let y = tPos.getY(i) * 0.94;
    let z = tPos.getZ(i) * 1.04;

    // Natural textured crop ridges sweeping subtly up-and-back
    const wave =
      Math.sin(x * 78 + z * 28) * 0.0038 +
      Math.cos(z * 62 - x * 35) * 0.0028;
    const frontLift = z > 0.02 ? THREE.MathUtils.clamp((z - 0.02) / 0.08, 0, 1) * 0.015 : 0;
    y += wave + frontLift;
    tPos.setXYZ(i, x, y, z);
  }
  topGeo.computeVertexNormals();
  const topCrop = new THREE.Mesh(topGeo, hairMat);
  topCrop.position.set(0, 0.034, -0.002);
  topCrop.castShadow = true;
  hairGroup.add(topCrop);

  // 3. Layered swept hair locks across the front hairline & crown for crisp close-up silhouette
  const lockSpecs: Array<{
    pts: [number, number, number][];
    radius: number;
  }> = [
    {
      pts: [
        [-0.048, 0.082, 0.072],
        [-0.028, 0.118, 0.048],
        [-0.015, 0.132, -0.005],
        [-0.02, 0.114, -0.065],
      ],
      radius: 0.019,
    },
    {
      pts: [
        [-0.012, 0.086, 0.082],
        [0.005, 0.125, 0.052],
        [0.014, 0.136, -0.008],
        [0.008, 0.118, -0.072],
      ],
      radius: 0.021,
    },
    {
      pts: [
        [0.028, 0.084, 0.076],
        [0.044, 0.12, 0.044],
        [0.048, 0.128, -0.012],
        [0.038, 0.108, -0.068],
      ],
      radius: 0.019,
    },
    {
      pts: [
        [0.058, 0.076, 0.054],
        [0.072, 0.104, 0.022],
        [0.068, 0.108, -0.032],
      ],
      radius: 0.016,
    },
    {
      pts: [
        [-0.066, 0.072, 0.048],
        [-0.076, 0.098, 0.016],
        [-0.07, 0.104, -0.034],
      ],
      radius: 0.015,
    },
  ];

  for (const spec of lockSpecs) {
    const curve = new THREE.CatmullRomCurve3(
      spec.pts.map(([px, py, pz]) => new THREE.Vector3(px, py, pz)),
    );
    const lockGeo = new THREE.TubeGeometry(curve, 12, spec.radius * 0.82, 8, false);
    lockGeo.computeVertexNormals();
    const lock = new THREE.Mesh(lockGeo, hairMat);
    lock.castShadow = true;
    hairGroup.add(lock);
  }

  // 4. Clean tapered sideburns
  for (const side of [-1, 1]) {
    const sideburn = new THREE.Mesh(new THREE.CapsuleGeometry(0.006, 0.036, 4, 6), fadeMat);
    sideburn.position.set(side * 0.092, 0.014, 0.024);
    sideburn.rotation.x = 0.14;
    sideburn.scale.set(0.45, 1, 1.25);
    hairGroup.add(sideburn);
  }

  return hairGroup;
}

/**
 * Builds a complete realistic human head with neck, sculpted cranium/jaw,
 * recessed realistic eyes (sclera + iris + pupil + eyelids), sculpted eyebrows,
 * multi-part nose, defined upper & lower lips, ears, short fade hair, and optional moustache.
 */
function buildDetailedHumanHead(options: {
  skinMat: THREE.MeshPhysicalMaterial;
  hairMat: THREE.MeshPhysicalMaterial;
  fadeMat: THREE.MeshStandardMaterial;
  hasMoustache?: boolean;
  hasStubble?: boolean;
  irisHex?: number;
  lipHex?: number;
  browFierce?: number;
}): THREE.Group {
  const headGroup = new THREE.Group();

  // 1. Sculpted anatomical neck (LatheGeometry with gentle sternocleidomastoid taper)
  const neckGeo = createContouredLimbGeometry(
    [
      [0.0, 0.068],
      [0.25, 0.058],
      [0.58, 0.054],
      [0.85, 0.056],
      [1.0, 0.052],
    ],
    0.15,
    0.96,
    1.04,
    18,
    0.005,
  );
  const neck = new THREE.Mesh(neckGeo, options.skinMat);
  neck.position.set(0, -0.195, -0.008);
  neck.castShadow = true;
  headGroup.add(neck);

  // 2. Sculpted cranium, cheekbones, orbital cavities, jawline & chin
  const craniumGeo = createSculptedHeadGeometry();
  const cranium = new THREE.Mesh(craniumGeo, options.skinMat);
  cranium.castShadow = true;
  cranium.receiveShadow = true;
  headGroup.add(cranium);

  // 3. Detailed Realistic Eyes (Sclera + Iris + Pupil + Upper/Lower Eyelids)
  const scleraMat = new THREE.MeshPhysicalMaterial({
    color: 0xf0eae3,
    roughness: 0.14,
    metalness: 0.0,
    clearcoat: 1.0,
    clearcoatRoughness: 0.06,
  });
  const irisMat = new THREE.MeshPhysicalMaterial({
    color: options.irisHex ?? 0x2c1a10,
    roughness: 0.18,
    metalness: 0.05,
    clearcoat: 1.0,
    clearcoatRoughness: 0.04,
  });
  const pupilMat = new THREE.MeshBasicMaterial({ color: 0x070606 });
  const lashMat = new THREE.MeshStandardMaterial({ color: 0x16110e, roughness: 0.85 });

  for (const side of [-1, 1]) {
    const eyeGroup = new THREE.Group();
    eyeGroup.position.set(side * 0.034, 0.011, 0.088);
    eyeGroup.rotation.y = side * 0.12;
    headGroup.add(eyeGroup);

    const eyeball = new THREE.Mesh(new THREE.SphereGeometry(0.0145, 16, 14), scleraMat);
    eyeGroup.add(eyeball);

    const iris = new THREE.Mesh(new THREE.SphereGeometry(0.0082, 14, 10), irisMat);
    iris.scale.set(1, 1, 0.42);
    iris.position.set(0, 0, 0.012);
    eyeGroup.add(iris);

    const pupil = new THREE.Mesh(new THREE.SphereGeometry(0.0044, 12, 8), pupilMat);
    pupil.scale.set(1, 1, 0.38);
    pupil.position.set(0, 0, 0.014);
    eyeGroup.add(pupil);

    // Sculpted upper eyelid fold + dark lash line
    const upperLidCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.016, -0.001, 0.006),
      new THREE.Vector3(-0.006, 0.0085, 0.0135),
      new THREE.Vector3(0.006, 0.0085, 0.0135),
      new THREE.Vector3(0.016, -0.001, 0.006),
    ]);
    const upperLid = new THREE.Mesh(
      new THREE.TubeGeometry(upperLidCurve, 10, 0.0036, 7, false),
      options.skinMat,
    );
    eyeGroup.add(upperLid);

    const lashLine = new THREE.Mesh(
      new THREE.TubeGeometry(upperLidCurve, 10, 0.0018, 6, false),
      lashMat,
    );
    lashLine.position.set(0, -0.0018, 0.0016);
    eyeGroup.add(lashLine);

    // Subtle lower eyelid rim
    const lowerLidCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.014, -0.002, 0.006),
      new THREE.Vector3(0, -0.0078, 0.0125),
      new THREE.Vector3(0.014, -0.002, 0.006),
    ]);
    const lowerLid = new THREE.Mesh(
      new THREE.TubeGeometry(lowerLidCurve, 8, 0.0026, 6, false),
      options.skinMat,
    );
    eyeGroup.add(lowerLid);

    // 4. Sculpted Eyebrows (curved tapered brow arcs)
    const fierce = options.browFierce ?? 0.004;
    const browCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(side * 0.014, 0.032 - fierce, 0.105),
      new THREE.Vector3(side * 0.034, 0.038, 0.104),
      new THREE.Vector3(side * 0.056, 0.034 + fierce * 0.35, 0.092),
    ]);
    const browGeo = new THREE.TubeGeometry(browCurve, 10, 0.0042, 7, false);
    const brow = new THREE.Mesh(browGeo, options.hairMat);
    headGroup.add(brow);
  }

  // 5. Sculpted Multi-Part Human Nose (bridge + rounded tip + alar nostril wings)
  const noseGroup = new THREE.Group();
  headGroup.add(noseGroup);

  const bridgeCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, 0.022, 0.104),
    new THREE.Vector3(0, -0.004, 0.114),
    new THREE.Vector3(0, -0.026, 0.123),
  ]);
  const bridgeGeo = new THREE.TubeGeometry(bridgeCurve, 10, 0.009, 8, false);
  bridgeGeo.scale(0.82, 1.0, 1.05);
  const noseBridge = new THREE.Mesh(bridgeGeo, options.skinMat);
  noseBridge.castShadow = true;
  noseGroup.add(noseBridge);

  const noseTip = new THREE.Mesh(new THREE.SphereGeometry(0.0115, 14, 12), options.skinMat);
  noseTip.scale.set(1.05, 0.86, 1.08);
  noseTip.position.set(0, -0.028, 0.121);
  noseGroup.add(noseTip);

  // Nostril wings (alae) + subtle dark nostrils underneath
  const nostrilDarkMat = new THREE.MeshStandardMaterial({ color: 0x4b2c20, roughness: 0.9 });
  for (const side of [-1, 1]) {
    const wing = new THREE.Mesh(new THREE.SphereGeometry(0.0085, 10, 8), options.skinMat);
    wing.scale.set(0.95, 0.72, 1.1);
    wing.position.set(side * 0.011, -0.032, 0.112);
    noseGroup.add(wing);

    const nostril = new THREE.Mesh(new THREE.SphereGeometry(0.0036, 8, 6), nostrilDarkMat);
    nostril.scale.set(1.2, 0.45, 1.3);
    nostril.position.set(side * 0.007, -0.037, 0.114);
    noseGroup.add(nostril);
  }

  // 6. Sculpted Mouth & Lips (Upper Cupid's Bow + Fuller Lower Lip + Mouth Crease)
  const lipMat = new THREE.MeshPhysicalMaterial({
    color: options.lipHex ?? 0x995d4c,
    roughness: 0.44,
    metalness: 0.0,
    sheen: 0.25,
    clearcoat: 0.14,
    clearcoatRoughness: 0.42,
  });
  const mouthLineMat = new THREE.MeshStandardMaterial({ color: 0x4c2920, roughness: 0.8 });

  const upperLipCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-0.022, -0.062, 0.097),
    new THREE.Vector3(-0.008, -0.0585, 0.106),
    new THREE.Vector3(0.0, -0.0605, 0.107),
    new THREE.Vector3(0.008, -0.0585, 0.106),
    new THREE.Vector3(0.022, -0.062, 0.097),
  ]);
  const upperLip = new THREE.Mesh(
    new THREE.TubeGeometry(upperLipCurve, 12, 0.0044, 7, false),
    lipMat,
  );
  headGroup.add(upperLip);

  const lowerLipCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-0.019, -0.064, 0.097),
    new THREE.Vector3(-0.007, -0.0685, 0.1065),
    new THREE.Vector3(0.007, -0.0685, 0.1065),
    new THREE.Vector3(0.019, -0.064, 0.097),
  ]);
  const lowerLip = new THREE.Mesh(
    new THREE.TubeGeometry(lowerLipCurve, 10, 0.0052, 7, false),
    lipMat,
  );
  headGroup.add(lowerLip);

  const mouthCreaseCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-0.021, -0.063, 0.098),
    new THREE.Vector3(0.0, -0.0635, 0.108),
    new THREE.Vector3(0.021, -0.063, 0.098),
  ]);
  const mouthCrease = new THREE.Mesh(
    new THREE.TubeGeometry(mouthCreaseCurve, 8, 0.0014, 5, false),
    mouthLineMat,
  );
  headGroup.add(mouthCrease);

  // Optional sharp trimmed Bengali hero moustache & light jaw stubble
  if (options.hasMoustache) {
    for (const side of [-1, 1]) {
      const stacheCurve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(side * 0.002, -0.047, 0.111),
        new THREE.Vector3(side * 0.015, -0.049, 0.109),
        new THREE.Vector3(side * 0.029, -0.056, 0.099),
      ]);
      const stacheGeo = new THREE.TubeGeometry(stacheCurve, 10, 0.0044, 7, false);
      const stacheHalf = new THREE.Mesh(stacheGeo, options.hairMat);
      headGroup.add(stacheHalf);
    }
  }

  if (options.hasStubble) {
    // Subtle chin/jaw beard shadow strip following the jawline
    const stubbleCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.062, -0.062, 0.025),
      new THREE.Vector3(-0.04, -0.094, 0.064),
      new THREE.Vector3(0.0, -0.106, 0.088),
      new THREE.Vector3(0.04, -0.094, 0.064),
      new THREE.Vector3(0.062, -0.062, 0.025),
    ]);
    const stubbleGeo = new THREE.TubeGeometry(stubbleCurve, 16, 0.0056, 6, false);
    const stubble = new THREE.Mesh(stubbleGeo, options.fadeMat);
    headGroup.add(stubble);
  }

  // 7. Sculpted Ears (Left & Right auricles with helix rim + inner concha)
  for (const side of [-1, 1]) {
    const earGroup = new THREE.Group();
    earGroup.position.set(side * 0.096, -0.008, -0.008);
    earGroup.rotation.y = side * -0.34;
    earGroup.rotation.z = side * -0.12;
    headGroup.add(earGroup);

    const earShell = new THREE.Mesh(new THREE.TorusGeometry(0.019, 0.0058, 8, 14, Math.PI * 1.45), options.skinMat);
    earShell.rotation.z = side === 1 ? -Math.PI * 0.55 : Math.PI * 0.1;
    earShell.scale.set(0.72, 1.25, 0.72);
    earGroup.add(earShell);

    const earLobe = new THREE.Mesh(new THREE.SphereGeometry(0.0095, 10, 8), options.skinMat);
    earLobe.scale.set(0.62, 1.15, 0.78);
    earLobe.position.set(0, -0.017, 0.002);
    earGroup.add(earLobe);
  }

  // 8. Short Fade Hair
  const hair = buildShortFadeHair(options.hairMat, options.fadeMat);
  headGroup.add(hair);

  return headGroup;
}

// ============================================================================
// Articulated Hands with Individual Fingers
// ============================================================================

/**
 * Builds an anatomically contoured hand with palm, thumb pad, and 5 articulated fingers
 * (each finger composed of proximal + curled distal phalanges + knuckle joints).
 * Local space: wrist at (0,0,0), fingers extending along +Y, palm facing -X (for right) / +X (for left).
 */
function buildArticulatedHand(
  side: -1 | 1, // -1 = left hand, +1 = right hand
  skinMat: THREE.MeshPhysicalMaterial,
  pose: 'grip' | 'cradle' | 'relaxed',
  gloveMat?: THREE.MeshStandardMaterial,
): THREE.Group {
  const hand = new THREE.Group();
  const palmMat = gloveMat ?? skinMat;

  // Sculpted beveled palm
  const palmShape = new THREE.Shape();
  palmShape.moveTo(-0.033, 0.0);
  palmShape.quadraticCurveTo(-0.039, 0.042, -0.036, 0.078);
  palmShape.lineTo(0.036, 0.078);
  palmShape.quadraticCurveTo(0.039, 0.042, 0.033, 0.0);
  palmShape.closePath();

  const palmGeo = new THREE.ExtrudeGeometry(palmShape, {
    depth: 0.02,
    bevelEnabled: true,
    bevelThickness: 0.007,
    bevelSize: 0.006,
    bevelSegments: 3,
  });
  palmGeo.translate(0, 0, -0.01);
  palmGeo.computeVertexNormals();
  const palm = new THREE.Mesh(palmGeo, palmMat);
  palm.castShadow = true;
  hand.add(palm);

  // Thenar (thumb base) muscular mound
  const thenar = new THREE.Mesh(new THREE.SphereGeometry(0.018, 10, 8), palmMat);
  thenar.scale.set(0.85, 1.35, 0.85);
  thenar.position.set(-side * 0.024, 0.028, 0.012);
  hand.add(thenar);

  // 4 Articulated Fingers (Index, Middle, Ring, Pinky)
  const fingerSpecs = [
    { name: 'index', x: -side * 0.026, len1: 0.036, len2: 0.028, r: 0.0082 },
    { name: 'middle', x: -side * 0.009, len1: 0.041, len2: 0.031, r: 0.0084 },
    { name: 'ring', x: side * 0.009, len1: 0.037, len2: 0.028, r: 0.0079 },
    { name: 'pinky', x: side * 0.026, len1: 0.029, len2: 0.022, r: 0.0068 },
  ];

  for (let i = 0; i < fingerSpecs.length; i++) {
    const f = fingerSpecs[i];
    const fingerRoot = new THREE.Group();
    fingerRoot.position.set(f.x, 0.078, 0.002);

    // Curl angles based on pose (right trigger finger extended slightly forward on 'grip')
    let curl1 = 0.25;
    let curl2 = 0.35;
    if (pose === 'grip') {
      if (i === 0) {
        curl1 = 0.34; // trigger finger poised cleanly along trigger guard
        curl2 = 0.42;
      } else {
        curl1 = 0.92 + i * 0.06;
        curl2 = 1.05;
      }
    } else if (pose === 'cradle') {
      curl1 = 0.52 + i * 0.05;
      curl2 = 0.64;
    }

    fingerRoot.rotation.x = curl1;
    hand.add(fingerRoot);

    // Knuckle joint
    const knuckle = new THREE.Mesh(new THREE.SphereGeometry(f.r * 1.04, 8, 8), skinMat);
    fingerRoot.add(knuckle);

    // Proximal phalanx
    const phalanx1 = new THREE.Mesh(
      new THREE.CapsuleGeometry(f.r * 0.92, f.len1 * 0.55, 4, 8),
      skinMat,
    );
    phalanx1.position.y = f.len1 * 0.5;
    fingerRoot.add(phalanx1);

    // Distal phalanx group (articulated middle/tip curl)
    const distalGroup = new THREE.Group();
    distalGroup.position.y = f.len1;
    distalGroup.rotation.x = curl2;
    fingerRoot.add(distalGroup);

    const phalanx2 = new THREE.Mesh(
      new THREE.CapsuleGeometry(f.r * 0.78, f.len2 * 0.55, 4, 8),
      skinMat,
    );
    phalanx2.position.y = f.len2 * 0.5;
    distalGroup.add(phalanx2);
  }

  // Opposable Articulated Thumb (2 segments)
  const thumbRoot = new THREE.Group();
  thumbRoot.position.set(-side * 0.036, 0.036, 0.012);
  if (pose === 'grip') {
    thumbRoot.rotation.set(0.45, side * 0.55, side * 0.62);
  } else if (pose === 'cradle') {
    thumbRoot.rotation.set(0.32, side * 0.4, side * 0.48);
  } else {
    thumbRoot.rotation.set(0.2, side * 0.3, side * 0.35);
  }
  hand.add(thumbRoot);

  const thumbSeg1 = new THREE.Mesh(new THREE.CapsuleGeometry(0.0098, 0.022, 4, 8), skinMat);
  thumbSeg1.position.y = 0.016;
  thumbRoot.add(thumbSeg1);

  const thumbDistal = new THREE.Group();
  thumbDistal.position.y = 0.032;
  thumbDistal.rotation.x = pose === 'grip' ? 0.58 : 0.32;
  thumbRoot.add(thumbDistal);

  const thumbSeg2 = new THREE.Mesh(new THREE.CapsuleGeometry(0.0085, 0.018, 4, 8), skinMat);
  thumbSeg2.position.y = 0.014;
  thumbDistal.add(thumbSeg2);

  return hand;
}

// ============================================================================
// Multi-Part Sculpted Combat Boots & Articulated Legs
// ============================================================================

/**
 * Builds a detailed tactical combat boot with high-top ankle shaft, contoured leather vamp,
 * reinforced rounded toe cap, speed-lace straps, and thick lugged rubber outsole.
 * Pivot at ankle top (y = 0); outsole bottom touches y = -0.14 exactly.
 */
function buildCombatBoot(
  leatherMat: THREE.MeshStandardMaterial,
  soleMat: THREE.MeshStandardMaterial,
  metalMat: THREE.MeshStandardMaterial,
): THREE.Group {
  const boot = new THREE.Group();

  // 1. High-top laced ankle cuff (LatheGeometry tapering smoothly over ankle)
  const shaftGeo = createContouredLimbGeometry(
    [
      [0.0, 0.056],
      [0.35, 0.054],
      [0.72, 0.06],
      [1.0, 0.064],
    ],
    0.135,
    0.92,
    1.12,
    16,
  );
  const shaft = new THREE.Mesh(shaftGeo, leatherMat);
  shaft.position.set(0, -0.095, -0.008);
  shaft.castShadow = true;
  boot.add(shaft);

  // Padded collar rim at boot top
  const collar = new THREE.Mesh(new THREE.TorusGeometry(0.058, 0.012, 8, 16), soleMat);
  collar.rotation.x = Math.PI / 2;
  collar.scale.set(0.95, 1.12, 1.0);
  collar.position.set(0, 0.038, -0.008);
  boot.add(collar);

  // 2. Contoured instep & reinforced toe vamp
  const vampGeo = new THREE.SphereGeometry(0.064, 18, 14);
  vampGeo.scale(0.98, 0.68, 1.65);
  const vamp = new THREE.Mesh(vampGeo, leatherMat);
  vamp.position.set(0, -0.088, 0.062);
  vamp.castShadow = true;
  boot.add(vamp);

  // Reinforced rubber toe bumper cap
  const toeCapGeo = new THREE.SphereGeometry(0.058, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.65);
  toeCapGeo.scale(0.94, 0.62, 1.05);
  const toeCap = new THREE.Mesh(toeCapGeo, soleMat);
  toeCap.position.set(0, -0.096, 0.115);
  boot.add(toeCap);

  // 3. Thick lugged tactical outsole + heel block (bottom flush at y = -0.14)
  const soleShape = new THREE.Shape();
  soleShape.moveTo(-0.052, -0.072);
  soleShape.quadraticCurveTo(-0.058, 0.02, -0.062, 0.085);
  soleShape.quadraticCurveTo(-0.06, 0.172, 0.0, 0.184);
  soleShape.quadraticCurveTo(0.06, 0.172, 0.062, 0.085);
  soleShape.quadraticCurveTo(0.058, 0.02, 0.052, -0.072);
  soleShape.quadraticCurveTo(0.0, -0.086, -0.052, -0.072);

  const soleGeo = new THREE.ExtrudeGeometry(soleShape, {
    depth: 0.028,
    bevelEnabled: true,
    bevelThickness: 0.004,
    bevelSize: 0.004,
    bevelSegments: 2,
  });
  soleGeo.rotateX(Math.PI / 2);
  const sole = new THREE.Mesh(soleGeo, soleMat);
  sole.position.set(0, -0.108, 0.0);
  sole.castShadow = true;
  boot.add(sole);

  // Tactical speed-laces & metal lace eyelets along the front tongue
  for (let l = 0; l < 4; l++) {
    const ly = -0.062 + l * 0.024;
    const lz = 0.058 - l * 0.004;
    const lace = new THREE.Mesh(new THREE.CapsuleGeometry(0.004, 0.044, 3, 6), soleMat);
    lace.rotation.z = Math.PI / 2;
    lace.position.set(0, ly, lz);
    boot.add(lace);

    for (const sx of [-0.028, 0.028]) {
      const eyelet = new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.004, 0.006, 6), metalMat);
      eyelet.rotation.x = Math.PI / 2;
      eyelet.position.set(sx, ly, lz - 0.002);
      boot.add(eyelet);
    }
  }

  return boot;
}

/**
 * Builds an anatomically sculpted articulated leg (hip -> contoured thigh + cargo pocket
 * -> articulated knee + molded tactical knee pad -> contoured calf -> combat boot).
 * Hip pivot at y = 0.90; combat boot sole rests cleanly on y = 0.00.
 */
function buildSculptedLeg(options: {
  xOff: number;
  pantsMat: THREE.MeshStandardMaterial;
  kneePadMat: THREE.MeshStandardMaterial;
  bootLeatherMat: THREE.MeshStandardMaterial;
  bootSoleMat: THREE.MeshStandardMaterial;
  metalMat: THREE.MeshStandardMaterial;
  thicknessMult?: number;
  hasDropHolster?: boolean;
}): { hip: THREE.Group; knee: THREE.Group } {
  const mult = options.thicknessMult ?? 1.0;
  const hip = new THREE.Group();
  hip.position.set(options.xOff, 0.9, 0);

  // Hip joint sphere so leg swings cleanly inside pelvis/tunic hem
  const hipCap = new THREE.Mesh(new THREE.SphereGeometry(0.095 * mult, 14, 12), options.pantsMat);
  hipCap.scale.set(0.96, 1.0, 1.04);
  hip.add(hipCap);

  // Sculpted thigh (quadriceps + hamstring taper from hip 0 down to knee -0.41)
  const thighGeo = createContouredLimbGeometry(
    [
      [0.0, 0.066 * mult], // knee top
      [0.25, 0.078 * mult],
      [0.58, 0.094 * mult], // full quadriceps
      [0.85, 0.098 * mult], // upper thigh
      [1.0, 0.092 * mult], // hip socket
    ],
    0.41,
    0.95,
    1.08,
    20,
    0.008,
  );
  const thigh = new THREE.Mesh(thighGeo, options.pantsMat);
  thigh.position.y = -0.41;
  thigh.castShadow = true;
  hip.add(thigh);

  // Sculpted tactical cargo pocket on outer thigh
  const sideSign = Math.sign(options.xOff) || 1;
  const pocketShape = new THREE.Shape();
  pocketShape.moveTo(-0.052, -0.065);
  pocketShape.lineTo(0.052, -0.065);
  pocketShape.lineTo(0.056, 0.055);
  pocketShape.lineTo(-0.056, 0.055);
  pocketShape.closePath();

  const pocketGeo = new THREE.ExtrudeGeometry(pocketShape, {
    depth: 0.018,
    bevelEnabled: true,
    bevelThickness: 0.005,
    bevelSize: 0.005,
    bevelSegments: 2,
  });
  const pocket = new THREE.Mesh(pocketGeo, options.pantsMat);
  pocket.rotation.y = sideSign * (Math.PI / 2);
  pocket.position.set(sideSign * (0.082 * mult), -0.22, 0.005);
  pocket.castShadow = true;
  hip.add(pocket);

  // Optional tactical drop-leg utility strap on right thigh
  if (options.hasDropHolster) {
    const strap = new THREE.Mesh(
      new THREE.TorusGeometry(0.092 * mult, 0.01, 6, 18),
      options.kneePadMat,
    );
    strap.rotation.x = Math.PI / 2;
    strap.scale.set(0.96, 1.1, 1.0);
    strap.position.set(0, -0.17, 0);
    hip.add(strap);
  }

  // Articulated Knee Group at local y = -0.41
  const knee = new THREE.Group();
  knee.position.set(0, -0.41, 0);
  hip.add(knee);

  const kneeJoint = new THREE.Mesh(new THREE.SphereGeometry(0.067 * mult, 14, 12), options.pantsMat);
  knee.add(kneeJoint);

  // Molded tactical knee pad shell + elastic strap
  const padGeo = new THREE.SphereGeometry(0.052 * mult, 14, 12, 0, Math.PI * 2, 0, Math.PI * 0.55);
  padGeo.rotateX(Math.PI / 2);
  padGeo.scale(0.95, 1.24, 0.68);
  const kneePad = new THREE.Mesh(padGeo, options.kneePadMat);
  kneePad.position.set(0, -0.01, 0.055 * mult);
  kneePad.castShadow = true;
  knee.add(kneePad);

  const kneeStrap = new THREE.Mesh(
    new THREE.TorusGeometry(0.066 * mult, 0.009, 6, 16),
    options.kneePadMat,
  );
  kneeStrap.rotation.x = Math.PI / 2;
  kneeStrap.position.set(0, -0.015, 0);
  knee.add(kneeStrap);

  // Sculpted lower leg / cargo trouser calf tucked into combat boot (knee 0 down to ankle -0.35)
  const calfGeo = createContouredLimbGeometry(
    [
      [0.0, 0.052 * mult], // ankle tuck
      [0.25, 0.061 * mult],
      [0.62, 0.075 * mult], // gastrocnemius calf belly
      [0.88, 0.071 * mult],
      [1.0, 0.065 * mult], // knee bottom
    ],
    0.35,
    0.95,
    1.06,
    18,
    -0.009, // calf muscle protrudes subtly backward
  );
  const calf = new THREE.Mesh(calfGeo, options.pantsMat);
  calf.position.y = -0.35;
  calf.castShadow = true;
  knee.add(calf);

  // Combat Boot grounded cleanly at local y = -0.35 (sole reaches -0.35 - 0.14 = -0.49; hip 0.90 - 0.41 - 0.49 = 0.00!)
  const boot = buildCombatBoot(options.bootLeatherMat, options.bootSoleMat, options.metalMat);
  boot.position.set(0, -0.35, 0);
  knee.add(boot);

  return { hip, knee };
}

// ============================================================================
// Watertight Two-Bone Sculpted Arm + Rolled Sleeve + Articulated Hand Builder
// ============================================================================

function orientSegment(
  mesh: THREE.Object3D,
  start: THREE.Vector3,
  end: THREE.Vector3,
): number {
  _dir.subVectors(end, start);
  const len = _dir.length();
  _mid.copy(start);
  mesh.position.copy(_mid);
  if (len > 0.0001) {
    _dir.divideScalar(len);
    _quat.setFromUnitVectors(_up, _dir);
    mesh.quaternion.copy(_quat);
  }
  return len;
}

function buildSculptedArm(options: {
  side: -1 | 1;
  shoulderWorld: THREE.Vector3;
  elbowWorld: THREE.Vector3;
  wristWorld: THREE.Vector3;
  sleeveMat: THREE.MeshStandardMaterial;
  skinMat: THREE.MeshPhysicalMaterial;
  handPose: 'grip' | 'cradle' | 'relaxed';
  handRollOffset?: number;
  rolledSleeve?: boolean;
  fullSleeve?: boolean;
  watchMat?: THREE.MeshStandardMaterial;
  gloveMat?: THREE.MeshStandardMaterial;
  thicknessMult?: number;
}): THREE.Group {
  const mult = options.thicknessMult ?? 1.0;
  const armGroup = new THREE.Group();
  armGroup.position.copy(options.shoulderWorld);

  // Local coordinates relative to shoulder
  const p0 = new THREE.Vector3(0, 0, 0);
  const pElbow = options.elbowWorld.clone().sub(options.shoulderWorld);
  const pWrist = options.wristWorld.clone().sub(options.shoulderWorld);

  // Sculpted deltoid shoulder cap blending cleanly into torso
  const deltoid = new THREE.Mesh(new THREE.SphereGeometry(0.072 * mult, 16, 14), options.sleeveMat);
  deltoid.scale.set(0.95, 1.08, 1.02);
  deltoid.castShadow = true;
  armGroup.add(deltoid);

  // Upper arm (shoulder -> elbow)
  const upperLen = p0.distanceTo(pElbow);
  const upperGeo = createContouredLimbGeometry(
    [
      [0.0, 0.068 * mult], // deltoid base
      [0.32, 0.062 * mult], // bicep belly
      [0.68, 0.056 * mult],
      [1.0, 0.048 * mult], // elbow
    ],
    upperLen,
    0.96,
    1.04,
    16,
  );
  const upperMesh = new THREE.Mesh(upperGeo, options.sleeveMat);
  orientSegment(upperMesh, p0, pElbow);
  upperMesh.castShadow = true;
  armGroup.add(upperMesh);

  // Rolled-up tactical kurta cuff near elbow (for Hero / Rusher)
  if (options.rolledSleeve) {
    const cuffHolder = new THREE.Group();
    orientSegment(cuffHolder, p0, pElbow);
    const cuff = new THREE.Mesh(
      new THREE.TorusGeometry(0.052 * mult, 0.012 * mult, 8, 16),
      options.sleeveMat,
    );
    cuff.rotation.x = Math.PI / 2;
    cuff.position.y = upperLen * 0.88;
    cuffHolder.add(cuff);
    armGroup.add(cuffHolder);
  }

  // Sculpted elbow joint
  const elbowJoint = new THREE.Mesh(
    new THREE.SphereGeometry(0.047 * mult, 12, 10),
    options.fullSleeve ? options.sleeveMat : options.skinMat,
  );
  elbowJoint.position.copy(pElbow);
  armGroup.add(elbowJoint);

  // Forearm (elbow -> wrist) with realistic brachioradialis muscular taper
  const foreLen = pElbow.distanceTo(pWrist);
  const foreGeo = createContouredLimbGeometry(
    [
      [0.0, 0.048 * mult], // elbow
      [0.26, 0.053 * mult], // brachioradialis muscle bulge
      [0.64, 0.042 * mult],
      [1.0, 0.033 * mult], // tapered wrist
    ],
    foreLen,
    0.96,
    1.05,
    16,
  );
  const foreMesh = new THREE.Mesh(
    foreGeo,
    options.fullSleeve ? options.sleeveMat : options.skinMat,
  );
  orientSegment(foreMesh, pElbow, pWrist);
  foreMesh.castShadow = true;
  armGroup.add(foreMesh);

  // Optional rugged field wristwatch on left wrist
  if (options.watchMat) {
    const watchHolder = new THREE.Group();
    orientSegment(watchHolder, pElbow, pWrist);
    const strap = new THREE.Mesh(
      new THREE.TorusGeometry(0.036 * mult, 0.006, 6, 14),
      options.watchMat,
    );
    strap.rotation.x = Math.PI / 2;
    strap.position.y = foreLen * 0.86;
    watchHolder.add(strap);

    const dial = new THREE.Mesh(
      new THREE.CylinderGeometry(0.016, 0.016, 0.008, 12),
      options.watchMat,
    );
    dial.rotation.z = Math.PI / 2;
    dial.position.set(-0.036 * mult, foreLen * 0.86, 0.006);
    watchHolder.add(dial);
    armGroup.add(watchHolder);
  }

  // Articulated Hand with 5 fingers anchored directly at the wrist
  const handMount = new THREE.Group();
  orientSegment(handMount, pElbow, pWrist);
  handMount.position.copy(pWrist);
  const hand = buildArticulatedHand(options.side, options.skinMat, options.handPose, options.gloveMat);
  if (options.handRollOffset) {
    hand.rotation.y = options.handRollOffset;
  }
  handMount.add(hand);
  armGroup.add(handMount);

  return armGroup;
}

// ============================================================================
// Physics-Animated Cloth Red-and-White Gamcha System (Verlet + Constraints)
// ============================================================================

interface GamchaClothController {
  tailMesh: THREE.Mesh;
  update: (
    dt: number,
    time: number,
    localVelX: number,
    localVelY: number,
    localVelZ: number,
    yawRate: number,
    windBoost: number,
  ) => void;
}

/**
 * Builds the hero's traditional Bengali red-and-white checkered gamcha draped organically
 * around his collar/shoulder plus a real-time Verlet cloth-physics trailing tail mesh
 * with wind turbulence, movement inertia, turning whip, and torso collision avoidance.
 */
function createGamchaClothSystem(
  bodyGroup: THREE.Group,
  gamchaMat: THREE.MeshPhysicalMaterial,
): GamchaClothController {
  // 1. Sculpted draped neck collar wrap (two organic overlapping curved cloth folds)
  const collarPts1 = [
    new THREE.Vector3(-0.115, 1.495, 0.045),
    new THREE.Vector3(-0.055, 1.462, 0.118),
    new THREE.Vector3(0.045, 1.466, 0.115),
    new THREE.Vector3(0.112, 1.492, 0.048),
    new THREE.Vector3(0.118, 1.506, -0.045),
    new THREE.Vector3(0.045, 1.514, -0.102),
    new THREE.Vector3(-0.068, 1.508, -0.098),
    new THREE.Vector3(-0.128, 1.496, -0.032),
  ];
  const collarCurve1 = new THREE.CatmullRomCurve3(collarPts1, true);
  const collarGeo1 = new THREE.TubeGeometry(collarCurve1, 32, 0.03, 10, true);
  collarGeo1.computeVertexNormals();
  const collarFold1 = new THREE.Mesh(collarGeo1, gamchaMat);
  collarFold1.castShadow = true;
  bodyGroup.add(collarFold1);

  // Secondary shoulder drape fold flowing over the left collarbone & shoulder blade
  const drapeCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0.055, 1.43, 0.125),
    new THREE.Vector3(-0.065, 1.4, 0.145),
    new THREE.Vector3(-0.155, 1.475, 0.092),
    new THREE.Vector3(-0.185, 1.495, -0.015),
    new THREE.Vector3(-0.155, 1.465, -0.125),
  ]);
  const drapeGeo = new THREE.TubeGeometry(drapeCurve, 22, 0.036, 10, false);
  drapeGeo.computeVertexNormals();
  const shoulderDrape = new THREE.Mesh(drapeGeo, gamchaMat);
  shoulderDrape.castShadow = true;
  bodyGroup.add(shoulderDrape);

  // Front chest sash panel hugging the left chest diagonally down to the tactical belt
  const sashCols = 5;
  const sashRows = 10;
  const sashGeo = new THREE.PlaneGeometry(0.16, 0.56, sashCols - 1, sashRows - 1);
  const sPos = sashGeo.attributes.position;
  for (let r = 0; r < sashRows; r++) {
    const v = r / (sashRows - 1); // 0 = top shoulder, 1 = lower chest/waist
    for (let c = 0; c < sashCols; c++) {
      const u = c / (sashCols - 1) - 0.5; // -0.5..0.5 across cloth width
      const idx = r * sashCols + c;
      // Curve smoothly over left shoulder across pecs down toward right hip
      const x = THREE.MathUtils.lerp(-0.145, 0.05, v) + u * (0.145 + v * 0.02);
      const y = THREE.MathUtils.lerp(1.485, 0.96, v);
      // Conform cleanly outside chest curvature + slight cloth fold ripple
      const chestCurve = Math.sin(v * Math.PI) * 0.045;
      const fold = Math.sin(u * Math.PI * 2.5 + v * 3.0) * 0.008;
      const z = 0.126 + chestCurve - Math.abs(x) * 0.18 + fold;
      sPos.setXYZ(idx, x, y, z);
    }
  }
  sashGeo.computeVertexNormals();
  const chestSash = new THREE.Mesh(sashGeo, gamchaMat);
  chestSash.castShadow = true;
  bodyGroup.add(chestSash);

  // 2. Real-Time Verlet Physics Cloth Tail hanging over & behind left shoulder
  const COLS = 7;
  const ROWS = 14;
  const COUNT = COLS * ROWS;
  const clothWidth = 0.23;
  const clothLength = 0.86;
  const dxRest = clothWidth / (COLS - 1);
  const dyRest = clothLength / (ROWS - 1);
  const diagRest = Math.hypot(dxRest, dyRest);

  const tailGeo = new THREE.PlaneGeometry(clothWidth, clothLength, COLS - 1, ROWS - 1);
  // Pre-allocate zero-GC Verlet state buffers
  const curr = new Float32Array(COUNT * 3);
  const prev = new Float32Array(COUNT * 3);
  const pinned = new Uint8Array(COUNT);

  // Initialize cloth vertices in natural draped rest pose behind left shoulder
  const posAttr = tailGeo.attributes.position as THREE.BufferAttribute;
  for (let r = 0; r < ROWS; r++) {
    const vr = r / (ROWS - 1);
    for (let c = 0; c < COLS; c++) {
      const uc = c / (COLS - 1) - 0.5;
      const i = r * COLS + c;
      const i3 = i * 3;
      // Anchor top edge cleanly along the back of the left shoulder
      const x = -0.145 + uc * clothWidth * (1.0 + vr * 0.14) - vr * 0.03;
      const y = 1.465 - r * dyRest * 0.96;
      const z = -0.135 - Math.sin(vr * Math.PI * 0.65) * 0.09 - Math.abs(uc) * 0.025;

      curr[i3] = x;
      curr[i3 + 1] = y;
      curr[i3 + 2] = z;
      prev[i3] = x;
      prev[i3 + 1] = y;
      prev[i3 + 2] = z;

      if (r === 0) pinned[i] = 1;
      posAttr.setXYZ(i, x, y, z);
    }
  }
  tailGeo.computeVertexNormals();

  const tailMesh = new THREE.Mesh(tailGeo, gamchaMat);
  tailMesh.castShadow = true;
  tailMesh.frustumCulled = false; // dynamic vertex positions updated every frame
  bodyGroup.add(tailMesh);

  // Build flat constraint pair index lists once (structural + shear + bend)
  const cA: number[] = [];
  const cB: number[] = [];
  const cRest: number[] = [];

  const addConstraint = (a: number, b: number, rest: number) => {
    cA.push(a);
    cB.push(b);
    cRest.push(rest);
  };

  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      const i = r * COLS + c;
      if (c + 1 < COLS) addConstraint(i, i + 1, dxRest);
      if (r + 1 < ROWS) addConstraint(i, i + COLS, dyRest);
      if (c + 1 < COLS && r + 1 < ROWS) {
        addConstraint(i, i + COLS + 1, diagRest);
        addConstraint(i + 1, i + COLS, diagRest);
      }
      if (r + 2 < ROWS) addConstraint(i, i + COLS * 2, dyRest * 2);
    }
  }
  const constraintCount = cA.length;

  // Back/torso ellipsoid collision center & radii in hero local space
  const colCx = 0.0;
  const colCy = 1.15;
  const colCz = -0.015;
  const colRx = 0.235;
  const colRy = 0.39;
  const colRz = 0.165;

  const update = (
    dt: number,
    time: number,
    localVelX: number,
    localVelY: number,
    localVelZ: number,
    yawRate: number,
    windBoost: number,
  ): void => {
    const stepDt = Math.min(dt, 0.032);
    const dtSq = stepDt * stepDt;
    const damping = 0.945;

    // 1. Verlet integration with gravity, Bengal breeze turbulence, movement inertia & turn whip
    for (let r = 1; r < ROWS; r++) {
      const vr = r / (ROWS - 1);
      // Lower tail reacts more dramatically to breeze and movement
      const airExposure = 0.35 + vr * 0.85;

      for (let c = 0; c < COLS; c++) {
        const i = r * COLS + c;
        const i3 = i * 3;
        const x = curr[i3];
        const y = curr[i3 + 1];
        const z = curr[i3 + 2];

        const vx = (x - prev[i3]) * damping;
        const vy = (y - prev[i3 + 1]) * damping;
        const vz = (z - prev[i3 + 2]) * damping;

        prev[i3] = x;
        prev[i3 + 1] = y;
        prev[i3 + 2] = z;

        // Multi-frequency traveling river-breeze gusts
        const wave1 = Math.sin(time * 5.2 - r * 0.48 + c * 0.32);
        const wave2 = Math.cos(time * 8.6 - r * 0.72 - c * 0.55);
        const gust = 1.0 + 0.45 * Math.sin(time * 1.9 + c * 0.2);

        const breezeZ = (-2.6 - windBoost * 9.5) * gust + wave1 * (1.85 + windBoost * 2.4);
        const breezeX = (-0.85 + wave2 * (1.45 + windBoost * 1.8)) * airExposure;
        const breezeY = Math.sin(time * 6.4 - r * 0.5) * (0.65 + windBoost * 1.4) * vr;

        // Character velocity drag (running forward sweeps cloth backward along -Z)
        const dragX = (-localVelX * 1.65 - yawRate * 2.1 * vr) * airExposure;
        const dragY = (-localVelY * 1.25) * airExposure;
        const dragZ = (-localVelZ * 1.85 - Math.abs(yawRate) * 1.45 * vr) * airExposure;

        const ax = breezeX + dragX;
        const ay = -10.8 + breezeY + dragY;
        const az = breezeZ * airExposure + dragZ;

        curr[i3] = x + vx + ax * dtSq;
        curr[i3 + 1] = y + vy + ay * dtSq;
        curr[i3 + 2] = z + vz + az * dtSq;
      }
    }

    // 2. Iterative distance constraints + torso/back collision push-out
    for (let iter = 0; iter < 3; iter++) {
      for (let k = 0; k < constraintCount; k++) {
        const ia = cA[k];
        const ib = cB[k];
        const a3 = ia * 3;
        const b3 = ib * 3;

        const dx = curr[b3] - curr[a3];
        const dy = curr[b3 + 1] - curr[a3 + 1];
        const dz = curr[b3 + 2] - curr[a3 + 2];
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz) || 0.0001;
        const diff = (dist - cRest[k]) / dist;

        const pinA = pinned[ia];
        const pinB = pinned[ib];
        if (pinA && pinB) continue;

        if (pinA) {
          curr[b3] -= dx * diff;
          curr[b3 + 1] -= dy * diff;
          curr[b3 + 2] -= dz * diff;
        } else if (pinB) {
          curr[a3] += dx * diff;
          curr[a3 + 1] += dy * diff;
          curr[a3 + 2] += dz * diff;
        } else {
          const half = diff * 0.5;
          curr[a3] += dx * half;
          curr[a3 + 1] += dy * half;
          curr[a3 + 2] += dz * half;
          curr[b3] -= dx * half;
          curr[b3 + 1] -= dy * half;
          curr[b3 + 2] -= dz * half;
        }
      }

      // Soft collision with torso ellipsoid so cloth glides outside the hero's back
      for (let i = COLS; i < COUNT; i++) {
        const i3 = i * 3;
        const ex = (curr[i3] - colCx) / colRx;
        const ey = (curr[i3 + 1] - colCy) / colRy;
        const ez = (curr[i3 + 2] - colCz) / colRz;
        const dSq = ex * ex + ey * ey + ez * ez;
        if (dSq < 1.0 && dSq > 0.0001) {
          const inv = 1.0 / Math.sqrt(dSq);
          curr[i3] = colCx + ex * inv * colRx;
          curr[i3 + 1] = colCy + ey * inv * colRy;
          // Bias cloth safely behind back surface
          curr[i3 + 2] = Math.min(curr[i3 + 2], colCz + ez * inv * colRz - 0.012);
        }
        // Keep cloth off the ground plane
        if (curr[i3 + 1] < 0.08) {
          curr[i3 + 1] = 0.08;
        }
      }
    }

    // 3. Upload deformed positions to GPU & recompute smooth cloth shading normals
    const arr = posAttr.array as Float32Array;
    arr.set(curr);
    posAttr.needsUpdate = true;
    tailGeo.computeVertexNormals();
  };

  return { tailMesh, update };
}

// ============================================================================
// Detailed Multi-Part Tactical Firearms (Carbine Rifle & Pump-Action Shotgun)
// ============================================================================

function buildDetailedCarbine(
  gunMetalMat: THREE.MeshStandardMaterial,
  gunDarkMat: THREE.MeshStandardMaterial,
  gunWoodMat: THREE.MeshStandardMaterial,
): THREE.Group {
  const rifle = new THREE.Group();

  // Sculpted stock with rubber buttpad
  const stockShape = new THREE.Shape();
  stockShape.moveTo(0, 0.035);
  stockShape.lineTo(-0.28, 0.02);
  stockShape.lineTo(-0.29, -0.09);
  stockShape.lineTo(-0.18, -0.068);
  stockShape.lineTo(0, -0.02);
  stockShape.closePath();

  const stockGeo = new THREE.ExtrudeGeometry(stockShape, {
    depth: 0.044,
    bevelEnabled: true,
    bevelThickness: 0.007,
    bevelSize: 0.006,
    bevelSegments: 2,
  });
  stockGeo.rotateY(Math.PI / 2);
  stockGeo.translate(-0.022, -0.015, 0.0);
  const stock = new THREE.Mesh(stockGeo, gunWoodMat);
  stock.castShadow = true;
  rifle.add(stock);

  // Angled ergonomic pistol grip positioned precisely inside the hero's right hand
  const grip = new THREE.Mesh(new THREE.CapsuleGeometry(0.024, 0.095, 5, 10), gunDarkMat);
  grip.position.set(0, -0.068, 0.025);
  grip.rotation.x = -0.32;
  rifle.add(grip);

  // Trigger guard loop
  const guard = new THREE.Mesh(new THREE.TorusGeometry(0.025, 0.0045, 6, 12), gunMetalMat);
  guard.rotation.y = Math.PI / 2;
  guard.position.set(0, -0.048, 0.085);
  rifle.add(guard);

  // Beveled steel receiver body + top Picatinny rail
  const receiverShape = new THREE.Shape();
  receiverShape.moveTo(-0.032, -0.042);
  receiverShape.lineTo(0.032, -0.042);
  receiverShape.lineTo(0.035, 0.028);
  receiverShape.lineTo(0.024, 0.046);
  receiverShape.lineTo(-0.024, 0.046);
  receiverShape.lineTo(-0.035, 0.028);
  receiverShape.closePath();

  const receiverGeo = new THREE.ExtrudeGeometry(receiverShape, {
    depth: 0.34,
    bevelEnabled: true,
    bevelThickness: 0.006,
    bevelSize: 0.005,
    bevelSegments: 2,
  });
  const receiver = new THREE.Mesh(receiverGeo, gunMetalMat);
  receiver.position.set(0, 0.012, -0.02);
  receiver.castShadow = true;
  rifle.add(receiver);

  // Compact tactical reflex optic sight on top rail
  const opticHousing = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.075, 12), gunDarkMat);
  opticHousing.rotation.x = Math.PI / 2;
  opticHousing.position.set(0, 0.082, 0.12);
  rifle.add(opticHousing);

  const opticMount = new THREE.Mesh(new THREE.BoxGeometry(0.032, 0.024, 0.048), gunMetalMat);
  opticMount.position.set(0, 0.064, 0.12);
  rifle.add(opticMount);

  // Curved tactical rifle magazine
  const magCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, -0.02, 0.21),
    new THREE.Vector3(0, -0.11, 0.23),
    new THREE.Vector3(0, -0.19, 0.275),
  ]);
  const magGeo = new THREE.TubeGeometry(magCurve, 8, 0.024, 8, false);
  magGeo.translate(0, 0, -0.23);
  magGeo.scale(0.65, 1.0, 1.3);
  magGeo.translate(0, 0, 0.23);
  const mag = new THREE.Mesh(magGeo, gunDarkMat);
  mag.castShadow = true;
  rifle.add(mag);

  // Contoured wooden/tactical ribbed handguard (cradled by left hand)
  const handguard = new THREE.Mesh(new THREE.CylinderGeometry(0.031, 0.034, 0.28, 12), gunWoodMat);
  handguard.rotation.x = Math.PI / 2;
  handguard.scale.set(0.95, 1.0, 1.15);
  handguard.position.set(0, 0.012, 0.44);
  handguard.castShadow = true;
  rifle.add(handguard);

  // Gas block + front sight post
  const frontSight = new THREE.Mesh(new THREE.BoxGeometry(0.014, 0.056, 0.032), gunMetalMat);
  frontSight.position.set(0, 0.052, 0.64);
  rifle.add(frontSight);

  // Fluted barrel + tactical flash hider muzzle brake
  const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.018, 0.42, 12), gunMetalMat);
  barrel.rotation.x = Math.PI / 2;
  barrel.position.set(0, 0.026, 0.72);
  barrel.castShadow = true;
  rifle.add(barrel);

  const muzzleBrake = new THREE.Mesh(new THREE.CylinderGeometry(0.021, 0.019, 0.068, 10), gunDarkMat);
  muzzleBrake.rotation.x = Math.PI / 2;
  muzzleBrake.position.set(0, 0.026, 0.93);
  rifle.add(muzzleBrake);

  return rifle;
}

function buildDetailedShotgun(
  gunMetalMat: THREE.MeshStandardMaterial,
  gunDarkMat: THREE.MeshStandardMaterial,
  gunWoodMat: THREE.MeshStandardMaterial,
): THREE.Group {
  const shotgun = new THREE.Group();

  const brassMat = new THREE.MeshStandardMaterial({
    color: 0xdca73c,
    roughness: 0.24,
    metalness: 0.9,
  });
  const shellRedMat = new THREE.MeshStandardMaterial({
    color: 0xb82222,
    roughness: 0.42,
    metalness: 0.05,
  });

  // Ergonomic walnut shotgun stock
  const stockShape = new THREE.Shape();
  stockShape.moveTo(0.02, 0.028);
  stockShape.lineTo(-0.3, -0.01);
  stockShape.lineTo(-0.31, -0.115);
  stockShape.lineTo(-0.14, -0.07);
  stockShape.lineTo(0.02, -0.035);
  stockShape.closePath();

  const stockGeo = new THREE.ExtrudeGeometry(stockShape, {
    depth: 0.048,
    bevelEnabled: true,
    bevelThickness: 0.008,
    bevelSize: 0.007,
    bevelSegments: 2,
  });
  stockGeo.rotateY(Math.PI / 2);
  stockGeo.translate(-0.024, -0.015, 0.0);
  const stock = new THREE.Mesh(stockGeo, gunWoodMat);
  stock.castShadow = true;
  shotgun.add(stock);

  // Beveled heavy steel receiver
  const receiver = new THREE.Mesh(new THREE.BoxGeometry(0.072, 0.105, 0.3), gunMetalMat);
  receiver.position.set(0, 0.014, 0.14);
  receiver.castShadow = true;
  shotgun.add(receiver);

  // Side-saddle carrier with 4 red/brass 12-gauge shells
  for (let s = 0; s < 4; s++) {
    const sz = 0.065 + s * 0.036;
    const shellBody = new THREE.Mesh(new THREE.CylinderGeometry(0.011, 0.011, 0.052, 8), shellRedMat);
    shellBody.position.set(0.044, 0.012, sz);
    shotgun.add(shellBody);
    const shellBrass = new THREE.Mesh(new THREE.CylinderGeometry(0.0115, 0.0115, 0.018, 8), brassMat);
    shellBrass.position.set(0.044, -0.018, sz);
    shotgun.add(shellBrass);
  }

  // Ribbed walnut pump-action forend (aligned cleanly with left hand)
  const pump = new THREE.Mesh(new THREE.CylinderGeometry(0.038, 0.038, 0.25, 14), gunWoodMat);
  pump.rotation.x = Math.PI / 2;
  pump.position.set(0, -0.008, 0.45);
  pump.castShadow = true;
  shotgun.add(pump);

  // Heavy upper 12-gauge barrel + under-barrel tubular magazine + barrel clamp
  const topBarrel = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.024, 0.62, 12), gunMetalMat);
  topBarrel.rotation.x = Math.PI / 2;
  topBarrel.position.set(0, 0.036, 0.6);
  topBarrel.castShadow = true;
  shotgun.add(topBarrel);

  const magTube = new THREE.Mesh(new THREE.CylinderGeometry(0.019, 0.019, 0.54, 10), gunDarkMat);
  magTube.rotation.x = Math.PI / 2;
  magTube.position.set(0, -0.006, 0.56);
  shotgun.add(magTube);

  const beadSight = new THREE.Mesh(new THREE.SphereGeometry(0.007, 8, 8), brassMat);
  beadSight.position.set(0, 0.06, 0.88);
  shotgun.add(beadSight);

  return shotgun;
}

// ============================================================================
// Bengali Hero Builder (Realistic Sculpted Human + Tactical Gear + Cloth Gamcha)
// ============================================================================

/**
 * Builds the Bengali Hero ("ভানু") as a realistic, anatomically sculpted 3D human character:
 * smooth contoured torso & muscular limbs, PBR skin shader with subsurface warmth, detailed
 * facial features (eyes, brows, nose, lips, ears, trimmed moustache, short fade hair),
 * articulated 5-finger hands, combat boots, tactical kurta + chest rig, swappable rifle/shotgun,
 * and a real-time Verlet physics-animated red-and-white checkered gamcha.
 */
export function buildBengaliHero(textures: TextureBundle): HeroRig {
  const root = new THREE.Group();
  addActorShadow(root, textures.contactShadowMap, 1.48);

  const bodyGroup = new THREE.Group();
  root.add(bodyGroup);

  // Realistic PBR Material Suite (varied roughness & metalness across skin, cotton, ripstop, leather, gunmetal)
  const skinMat = createRealisticSkinMaterial(0xc48b63, textures);
  const hairMat = createHairMaterial(0x161211);
  const fadeMat = new THREE.MeshStandardMaterial({
    color: 0x261f1c,
    roughness: 0.88,
    metalness: 0.0,
    bumpMap: textures.skinBumpMap,
    bumpScale: 0.003,
  });
  const kurtaMat = createClothMaterial(0xf2eadb, textures, {
    roughness: 0.88,
    sheen: 0.45,
    sheenColor: 0xfff8ed,
  });
  const tacticalRigMat = new THREE.MeshStandardMaterial({
    color: 0x2f362d, // muted olive-charcoal tactical cordura
    roughness: 0.8,
    metalness: 0.06,
    bumpMap: textures.fabricBumpMap,
    bumpScale: 0.011,
  });
  const pantsMat = new THREE.MeshStandardMaterial({
    color: 0x2a323b, // dark slate tactical cargo trousers
    roughness: 0.84,
    metalness: 0.02,
    bumpMap: textures.fabricBumpMap,
    bumpScale: 0.01,
  });
  const kneePadMat = new THREE.MeshStandardMaterial({
    color: 0x1b1e21,
    roughness: 0.55,
    metalness: 0.14,
  });
  const bootLeatherMat = new THREE.MeshStandardMaterial({
    color: 0x3b2618, // rugged oiled dark brown leather
    roughness: 0.44,
    metalness: 0.06,
    bumpMap: textures.skinBumpMap,
    bumpScale: 0.005,
  });
  const bootSoleMat = new THREE.MeshStandardMaterial({
    color: 0x171819,
    roughness: 0.92,
    metalness: 0.02,
  });
  const beltLeatherMat = new THREE.MeshStandardMaterial({
    color: 0x472d1b,
    roughness: 0.48,
    metalness: 0.05,
  });
  const metalBuckleMat = new THREE.MeshStandardMaterial({
    color: 0x8e969d,
    roughness: 0.28,
    metalness: 0.88,
  });
  const gamchaMat = createClothMaterial(0xffffff, textures, {
    map: textures.gamchaMap,
    roughness: 0.84,
    sheen: 0.56,
    sheenColor: 0xffe4df,
    side: THREE.DoubleSide,
    bumpScale: 0.012,
  });
  const gunMetalMat = new THREE.MeshStandardMaterial({
    color: 0x2d3238,
    roughness: 0.3,
    metalness: 0.84,
  });
  const gunDarkMat = new THREE.MeshStandardMaterial({
    color: 0x1c1f23,
    roughness: 0.48,
    metalness: 0.45,
  });
  const gunWoodMat = new THREE.MeshStandardMaterial({
    color: 0x6f3e21,
    roughness: 0.58,
    metalness: 0.05,
  });

  // 1. Articulated Sculpted Legs + Tactical Cargo Trousers + Knee Pads + Combat Boots
  const leftLegBuild = buildSculptedLeg({
    xOff: -0.115,
    pantsMat,
    kneePadMat,
    bootLeatherMat,
    bootSoleMat,
    metalMat: metalBuckleMat,
  });
  const rightLegBuild = buildSculptedLeg({
    xOff: 0.115,
    pantsMat,
    kneePadMat,
    bootLeatherMat,
    bootSoleMat,
    metalMat: metalBuckleMat,
    hasDropHolster: true,
  });
  bodyGroup.add(leftLegBuild.hip, rightLegBuild.hip);

  // 2. Sculpted Contoured Torso (Tactical Bengali Field Kurta)
  const torsoGeo = createContouredTorsoGeometry(1.0, 1.0);
  const torso = new THREE.Mesh(torsoGeo, kurtaMat);
  torso.position.set(0, 0.91, 0);
  torso.castShadow = true;
  torso.receiveShadow = true;
  bodyGroup.add(torso);

  // Sculpted pleated lower kurta hem draping organically over the pelvis/upper thighs
  const hemProfile: THREE.Vector2[] = [
    new THREE.Vector2(0.185, 0.0),
    new THREE.Vector2(0.178, 0.08),
    new THREE.Vector2(0.168, 0.16),
    new THREE.Vector2(0.16, 0.22),
  ];
  const hemGeo = new THREE.LatheGeometry(hemProfile, 28);
  const hPos = hemGeo.attributes.position;
  for (let i = 0; i < hPos.count; i++) {
    const x = hPos.getX(i);
    const y = hPos.getY(i);
    const z = hPos.getZ(i);
    const ang = Math.atan2(z, x);
    const pleat = 1.0 + Math.sin(ang * 8) * 0.025 * (1 - y / 0.22);
    hPos.setXYZ(i, x * 1.12 * pleat, y, z * 0.78 * pleat);
  }
  hemGeo.computeVertexNormals();
  const kurtaHem = new THREE.Mesh(hemGeo, kurtaMat);
  kurtaHem.position.set(0, 0.74, 0);
  kurtaHem.castShadow = true;
  bodyGroup.add(kurtaHem);

  // Mandarin collar & buttoned front placket detail
  const collarRing = new THREE.Mesh(new THREE.CylinderGeometry(0.088, 0.095, 0.045, 20, 1, true), kurtaMat);
  collarRing.position.set(0, 1.5, -0.005);
  bodyGroup.add(collarRing);

  const placket = new THREE.Mesh(new THREE.BoxGeometry(0.036, 0.24, 0.012), kurtaMat);
  placket.position.set(0, 1.37, 0.132);
  bodyGroup.add(placket);
  for (let b = 0; b < 3; b++) {
    const btn = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.005, 8), beltLeatherMat);
    btn.rotation.x = Math.PI / 2;
    btn.position.set(0, 1.44 - b * 0.055, 0.14);
    bodyGroup.add(btn);
  }

  // 3. Tactical Chest Rig, MOLLE Mag Pouches & Rugged Utility Belt
  // Contoured waist belt
  const beltGeo = new THREE.TorusGeometry(0.168, 0.022, 10, 28);
  beltGeo.rotateX(Math.PI / 2);
  beltGeo.scale(1.06, 1.1, 0.74);
  const waistBelt = new THREE.Mesh(beltGeo, beltLeatherMat);
  waistBelt.position.set(0, 0.94, 0.004);
  waistBelt.castShadow = true;
  bodyGroup.add(waistBelt);

  const buckle = new THREE.Mesh(new THREE.BoxGeometry(0.058, 0.044, 0.022), metalBuckleMat);
  buckle.position.set(0, 0.94, 0.134);
  bodyGroup.add(buckle);

  // Tactical side belt pouches
  for (const sx of [-0.185, 0.185]) {
    const pouch = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.095, 0.078), tacticalRigMat);
    pouch.position.set(sx, 0.92, 0.02);
    pouch.castShadow = true;
    bodyGroup.add(pouch);
  }

  // Contoured tactical chest carrier panel across lower ribs + shoulder harness straps
  const rigGeo = createContouredTorsoGeometry(1.04, 1.07);
  // Slice-feel: mount a compact contoured tactical vest shell over mid-chest
  const vestPlateGeo = new THREE.CylinderGeometry(0.18, 0.172, 0.25, 22, 1, false);
  vestPlateGeo.scale(1.12, 1.0, 0.72);
  const vestPlate = new THREE.Mesh(vestPlateGeo, tacticalRigMat);
  vestPlate.position.set(0, 1.21, 0.006);
  vestPlate.castShadow = true;
  bodyGroup.add(vestPlate);
  rigGeo.dispose(); // unused intermediate

  // 3 Front MOLLE rifle magazine pouches on tactical rig
  for (let m = -1; m <= 1; m++) {
    const magPouch = new THREE.Mesh(new THREE.BoxGeometry(0.056, 0.115, 0.036), tacticalRigMat);
    magPouch.position.set(m * 0.068, 1.16, 0.138 - Math.abs(m) * 0.012);
    magPouch.rotation.y = m * 0.18;
    magPouch.castShadow = true;
    bodyGroup.add(magPouch);

    const flap = new THREE.Mesh(new THREE.BoxGeometry(0.052, 0.032, 0.04), kneePadMat);
    flap.position.set(m * 0.068, 1.21, 0.141 - Math.abs(m) * 0.012);
    flap.rotation.y = m * 0.18;
    bodyGroup.add(flap);
  }

  // Right shoulder tactical strap + quick-release clip
  const strapCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0.12, 1.32, 0.115),
    new THREE.Vector3(0.14, 1.48, 0.045),
    new THREE.Vector3(0.135, 1.48, -0.065),
    new THREE.Vector3(0.115, 1.32, -0.115),
  ]);
  const rStrapGeo = new THREE.TubeGeometry(strapCurve, 16, 0.022, 8, false);
  rStrapGeo.scale(1.0, 1.0, 0.92);
  const rStrap = new THREE.Mesh(rStrapGeo, tacticalRigMat);
  bodyGroup.add(rStrap);

  const radioClip = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.062, 0.024), kneePadMat);
  radioClip.position.set(0.135, 1.38, 0.115);
  bodyGroup.add(radioClip);

  // 4. Detailed Sculpted Bengali Hero Head (Eyes, Brows, Nose, Lips, Ears, Moustache, Short Fade Hair)
  const headGroup = buildDetailedHumanHead({
    skinMat,
    hairMat,
    fadeMat,
    hasMoustache: true,
    hasStubble: true,
    irisHex: 0x2b180e,
    lipHex: 0x995e4c,
    browFierce: 0.0045,
  });
  headGroup.position.set(0, 1.69, 0.005);
  bodyGroup.add(headGroup);

  // 5. Physics-Animated Cloth Red-and-White Checkered Gamcha
  const gamchaCloth = createGamchaClothSystem(bodyGroup, gamchaMat);

  // 6. Sculpted Muscular Arms + Rolled Kurta Sleeves + Articulated 5-Finger Hands
  const leftArm = buildSculptedArm({
    side: -1,
    shoulderWorld: new THREE.Vector3(-0.23, 1.43, -0.008),
    elbowWorld: new THREE.Vector3(-0.165, 1.19, 0.18),
    wristWorld: new THREE.Vector3(0.07, 1.215, 0.43),
    sleeveMat: kurtaMat,
    skinMat,
    handPose: 'cradle',
    handRollOffset: 0.95,
    rolledSleeve: true,
    watchMat: kneePadMat,
  });
  bodyGroup.add(leftArm);

  const rightArm = buildSculptedArm({
    side: 1,
    shoulderWorld: new THREE.Vector3(0.23, 1.43, -0.008),
    elbowWorld: new THREE.Vector3(0.265, 1.195, 0.06),
    wristWorld: new THREE.Vector3(0.125, 1.195, 0.255),
    sleeveMat: kurtaMat,
    skinMat,
    handPose: 'grip',
    handRollOffset: -1.35,
    rolledSleeve: true,
  });
  bodyGroup.add(rightArm);

  // 7. Detailed Swappable Multi-Part Weapon Rig aligned cleanly to the articulated hands
  const recoilGroup = new THREE.Group();
  recoilGroup.position.set(0.115, 1.255, 0.27);
  bodyGroup.add(recoilGroup);

  const rifleGroup = buildDetailedCarbine(gunMetalMat, gunDarkMat, gunWoodMat);
  recoilGroup.add(rifleGroup);

  const shotgunGroup = buildDetailedShotgun(gunMetalMat, gunDarkMat, gunWoodMat);
  shotgunGroup.visible = false;
  recoilGroup.add(shotgunGroup);

  const muzzlePoint = new THREE.Object3D();
  muzzlePoint.position.set(0, 0.028, 0.97);
  recoilGroup.add(muzzlePoint);

  const flashMat = new THREE.MeshBasicMaterial({
    color: 0xffd36b,
    transparent: true,
    opacity: 0.92,
  });
  const muzzleFlash = new THREE.Mesh(new THREE.ConeGeometry(0.13, 0.4, 6), flashMat);
  muzzleFlash.rotation.x = Math.PI / 2;
  muzzleFlash.position.set(0, 0.028, 1.12);
  muzzleFlash.visible = false;
  recoilGroup.add(muzzleFlash);

  const muzzleLight = new THREE.PointLight(0xffb84d, 0, 8, 2);
  muzzleLight.position.set(0, 0.1, 1.05);
  recoilGroup.add(muzzleLight);

  return {
    root,
    bodyGroup,
    headGroup,
    leftLeg: leftLegBuild.hip,
    rightLeg: rightLegBuild.hip,
    leftKnee: leftLegBuild.knee,
    rightKnee: rightLegBuild.knee,
    leftArm,
    rightArm,
    gamchaTail: gamchaCloth.tailMesh,
    gamchaMaterial: gamchaMat,
    rifleGroup,
    shotgunGroup,
    muzzlePoint,
    muzzleFlash,
    muzzleLight,
    recoilGroup,
    updateGamchaCloth: gamchaCloth.update,
  };
}

// ============================================================================
// Realistic 3D Human Enemy Characters (Scout, Rusher, Heavy)
// ============================================================================

/**
 * Builds an articulated realistic 3D human enemy fighter with sculpted torso/limbs,
 * PBR skin shader, detailed facial features + short fade hair, articulated fingers,
 * combat boots, archetype-specific tactical gear, telegraph glow, and world-space HP bar.
 */
export function buildEnemyBot(
  archetype: EnemyArchetype,
  textures: TextureBundle,
): EnemyRig {
  const root = new THREE.Group();
  const scale = archetype === 'heavy' ? 1.18 : archetype === 'rusher' ? 0.96 : 1.02;
  addActorShadow(root, textures.contactShadowMap, 1.32 * scale);

  const bodyGroup = new THREE.Group();
  bodyGroup.scale.setScalar(scale);
  root.add(bodyGroup);

  const skinHex =
    archetype === 'heavy' ? 0xa36e4b : archetype === 'rusher' ? 0xb87e59 : 0xae7550;
  const jacketHex =
    archetype === 'heavy' ? 0x2c2928 : archetype === 'rusher' ? 0x4b2a20 : 0x232d3a;
  const rigHex =
    archetype === 'heavy' ? 0x9c3720 : archetype === 'rusher' ? 0xc87420 : 0x991f28;
  const pantsHex =
    archetype === 'heavy' ? 0x242628 : archetype === 'rusher' ? 0x3b352c : 0x1f252c;

  const skinMat = createRealisticSkinMaterial(skinHex, textures);
  const hairMat = createHairMaterial(0x141212);
  const fadeMat = new THREE.MeshStandardMaterial({
    color: 0x241e1b,
    roughness: 0.88,
  });
  const jacketMat = new THREE.MeshStandardMaterial({
    color: jacketHex,
    roughness: 0.78,
    metalness: 0.08,
    bumpMap: textures.fabricBumpMap,
    bumpScale: 0.01,
  });
  const rigMat = new THREE.MeshStandardMaterial({
    color: rigHex,
    roughness: 0.62,
    metalness: archetype === 'heavy' ? 0.32 : 0.12,
    bumpMap: textures.fabricBumpMap,
    bumpScale: 0.008,
  });
  const pantsMat = new THREE.MeshStandardMaterial({
    color: pantsHex,
    roughness: 0.84,
    metalness: 0.04,
    bumpMap: textures.fabricBumpMap,
    bumpScale: 0.01,
  });
  const kneePadMat = new THREE.MeshStandardMaterial({
    color: 0x181a1d,
    roughness: 0.56,
    metalness: 0.18,
  });
  const bootLeatherMat = new THREE.MeshStandardMaterial({
    color: 0x201d1b,
    roughness: 0.46,
    metalness: 0.08,
  });
  const bootSoleMat = new THREE.MeshStandardMaterial({
    color: 0x121315,
    roughness: 0.92,
  });
  const gloveMat = new THREE.MeshStandardMaterial({
    color: 0x1e2022,
    roughness: 0.74,
    metalness: 0.06,
  });
  const gunMat = new THREE.MeshStandardMaterial({
    color: 0x222529,
    roughness: 0.34,
    metalness: 0.82,
  });
  const visorMat = new THREE.MeshStandardMaterial({
    color: 0xff3b30,
    emissive: 0xff2a1f,
    emissiveIntensity: 1.5,
    roughness: 0.2,
  });

  const flashMaterials: THREE.MeshStandardMaterial[] = [jacketMat, rigMat, skinMat, pantsMat];
  const baseEmissives = flashMaterials.map((m) => m.emissive.clone());

  const thicknessMult = archetype === 'heavy' ? 1.15 : archetype === 'rusher' ? 0.94 : 1.0;

  // 1. Sculpted Legs + Cargo Pants + Knee Pads + Combat Boots
  const leftLegBuild = buildSculptedLeg({
    xOff: -0.115 * thicknessMult,
    pantsMat,
    kneePadMat,
    bootLeatherMat,
    bootSoleMat,
    metalMat: gunMat,
    thicknessMult,
  });
  const rightLegBuild = buildSculptedLeg({
    xOff: 0.115 * thicknessMult,
    pantsMat,
    kneePadMat,
    bootLeatherMat,
    bootSoleMat,
    metalMat: gunMat,
    thicknessMult,
  });
  bodyGroup.add(leftLegBuild.hip, rightLegBuild.hip);

  // 2. Sculpted Contoured Torso + Tactical Plate Carrier / Harness
  const torsoGeo = createContouredTorsoGeometry(
    archetype === 'heavy' ? 1.18 : archetype === 'rusher' ? 0.96 : 1.02,
    archetype === 'heavy' ? 1.16 : 1.0,
  );
  const torso = new THREE.Mesh(torsoGeo, jacketMat);
  torso.position.set(0, 0.91, 0);
  torso.castShadow = true;
  bodyGroup.add(torso);

  // Tactical plate carrier vest sculpted over chest
  const vestGeo = new THREE.CylinderGeometry(
    0.185 * thicknessMult,
    0.175 * thicknessMult,
    archetype === 'heavy' ? 0.36 : 0.28,
    20,
  );
  vestGeo.scale(1.14, 1.0, 0.76);
  const vest = new THREE.Mesh(vestGeo, rigMat);
  vest.position.set(0, 1.24, 0.008);
  vest.castShadow = true;
  bodyGroup.add(vest);

  // Tactical waist belt
  const beltGeo = new THREE.TorusGeometry(0.172 * thicknessMult, 0.022, 8, 22);
  beltGeo.rotateX(Math.PI / 2);
  beltGeo.scale(1.06, 1.0, 0.76);
  const belt = new THREE.Mesh(beltGeo, kneePadMat);
  belt.position.set(0, 0.94, 0.004);
  bodyGroup.add(belt);

  // Front ammo pouches on chest carrier
  for (let p = -1; p <= 1; p++) {
    const pouch = new THREE.Mesh(new THREE.BoxGeometry(0.056, 0.1, 0.042), kneePadMat);
    pouch.position.set(p * 0.072 * thicknessMult, 1.18, 0.145 * thicknessMult);
    pouch.rotation.y = p * 0.2;
    bodyGroup.add(pouch);
  }

  // Heavy Enforcer contoured composite shoulder pauldrons + gorget collar
  if (archetype === 'heavy') {
    for (const sx of [-1, 1]) {
      const pauldronGeo = new THREE.SphereGeometry(0.135, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.62);
      pauldronGeo.scale(0.95, 0.82, 1.12);
      const pauldron = new THREE.Mesh(pauldronGeo, rigMat);
      pauldron.position.set(sx * 0.285, 1.44, 0);
      pauldron.rotation.z = -sx * 0.42;
      pauldron.castShadow = true;
      bodyGroup.add(pauldron);
    }
    const gorget = new THREE.Mesh(new THREE.TorusGeometry(0.12, 0.028, 8, 18), rigMat);
    gorget.rotation.x = Math.PI / 2;
    gorget.position.set(0, 1.5, 0.005);
    bodyGroup.add(gorget);
  }

  // 3. Detailed Sculpted Human Head + Archetype Tactical Headgear
  const headGroup = buildDetailedHumanHead({
    skinMat,
    hairMat,
    fadeMat,
    hasMoustache: archetype === 'heavy',
    hasStubble: true,
    irisHex: 0x26160d,
    lipHex: 0x8a5343,
    browFierce: 0.0065,
  });
  headGroup.position.set(0, 1.69, 0.005);
  bodyGroup.add(headGroup);

  if (archetype === 'heavy') {
    // Open-face ballistic tactical helmet + glowing red rangefinder eyepiece
    const helmGeo = new THREE.SphereGeometry(0.128, 20, 14, 0, Math.PI * 2, 0, Math.PI * 0.56);
    helmGeo.scale(0.94, 1.05, 1.08);
    const helmet = new THREE.Mesh(helmGeo, rigMat);
    helmet.position.set(0, 0.025, -0.005);
    helmet.castShadow = true;
    headGroup.add(helmet);

    const eyepiece = new THREE.Mesh(new THREE.BoxGeometry(0.068, 0.028, 0.024), visorMat);
    eyepiece.position.set(0.036, 0.012, 0.114);
    headGroup.add(eyepiece);
  } else if (archetype === 'scout') {
    // Tactical half-mask + sleek red-tinted ballistic shades
    const shades = new THREE.Mesh(new THREE.BoxGeometry(0.112, 0.028, 0.022), visorMat);
    shades.position.set(0, 0.012, 0.108);
    headGroup.add(shades);

    const maskGeo = new THREE.CylinderGeometry(0.072, 0.062, 0.062, 16, 1, false, -Math.PI * 0.45, Math.PI * 0.9);
    const mask = new THREE.Mesh(maskGeo, kneePadMat);
    mask.position.set(0, -0.062, 0.048);
    headGroup.add(mask);
  } else {
    // Rusher: sleek tactical comm headset + crimson headband accent
    const commBand = new THREE.Mesh(new THREE.TorusGeometry(0.106, 0.009, 6, 18, Math.PI), kneePadMat);
    commBand.position.set(0, 0.025, 0.0);
    headGroup.add(commBand);

    for (const sx of [-0.104, 0.104]) {
      const earCup = new THREE.Mesh(new THREE.CylinderGeometry(0.024, 0.024, 0.018, 10), rigMat);
      earCup.rotation.z = Math.PI / 2;
      earCup.position.set(sx, -0.006, -0.005);
      headGroup.add(earCup);
    }
    const browGlow = new THREE.Mesh(new THREE.BoxGeometry(0.052, 0.016, 0.018), visorMat);
    browGlow.position.set(-0.034, 0.012, 0.11);
    headGroup.add(browGlow);
  }

  // 4. Sculpted Support Left Arm + Articulated Hand
  const sx = 0.23 * thicknessMult;
  const leftArm = buildSculptedArm({
    side: -1,
    shoulderWorld: new THREE.Vector3(-sx, 1.43, -0.01),
    elbowWorld: new THREE.Vector3(-0.16, 1.2, 0.16),
    wristWorld: new THREE.Vector3(0.08, 1.24, 0.42),
    sleeveMat: jacketMat,
    skinMat,
    handPose: 'cradle',
    handRollOffset: 0.95,
    rolledSleeve: archetype === 'rusher',
    fullSleeve: archetype !== 'rusher',
    gloveMat,
    thicknessMult,
  });
  bodyGroup.add(leftArm);

  // 5. Weapon Pivot (Right Arm + Articulated Trigger Hand + Archetype Tactical Firearm)
  const weaponPivot = new THREE.Group();
  weaponPivot.position.set(0.14, 1.27, 0.22);
  bodyGroup.add(weaponPivot);

  const rightArm = buildSculptedArm({
    side: 1,
    shoulderWorld: new THREE.Vector3(sx - 0.14, 1.43 - 1.27, -0.01 - 0.22),
    elbowWorld: new THREE.Vector3(0.14, -0.06, -0.14),
    wristWorld: new THREE.Vector3(0.01, -0.04, 0.04),
    sleeveMat: jacketMat,
    skinMat,
    handPose: 'grip',
    handRollOffset: -1.35,
    rolledSleeve: archetype === 'rusher',
    fullSleeve: archetype !== 'rusher',
    gloveMat,
    thicknessMult,
  });
  weaponPivot.add(rightArm);

  const gunLen = archetype === 'heavy' ? 0.68 : archetype === 'rusher' ? 0.42 : 0.54;
  const gunReceiver = new THREE.Mesh(new THREE.BoxGeometry(0.068, 0.105, gunLen * 0.58), gunMat);
  gunReceiver.position.set(0, 0.01, 0.2);
  gunReceiver.castShadow = true;
  weaponPivot.add(gunReceiver);

  const gunGrip = new THREE.Mesh(new THREE.CapsuleGeometry(0.022, 0.085, 4, 8), kneePadMat);
  gunGrip.position.set(0, -0.062, 0.07);
  gunGrip.rotation.x = -0.32;
  weaponPivot.add(gunGrip);

  const gunBarrel = new THREE.Mesh(
    new THREE.CylinderGeometry(
      archetype === 'heavy' ? 0.024 : 0.016,
      archetype === 'heavy' ? 0.028 : 0.018,
      gunLen * 0.65,
      10,
    ),
    gunMat,
  );
  gunBarrel.rotation.x = Math.PI / 2;
  gunBarrel.position.set(0, 0.024, 0.2 + gunLen * 0.52);
  gunBarrel.castShadow = true;
  weaponPivot.add(gunBarrel);

  if (archetype === 'heavy') {
    // Heavy LMG drum magazine
    const drum = new THREE.Mesh(new THREE.CylinderGeometry(0.072, 0.072, 0.09, 14), rigMat);
    drum.rotation.z = Math.PI / 2;
    drum.position.set(0, -0.075, 0.28);
    weaponPivot.add(drum);
  } else {
    const mag = new THREE.Mesh(new THREE.BoxGeometry(0.036, 0.16, 0.064), kneePadMat);
    mag.position.set(0, -0.085, 0.24);
    mag.rotation.x = 0.2;
    weaponPivot.add(mag);
  }

  const muzzlePoint = new THREE.Object3D();
  muzzlePoint.position.set(0, 0.024, 0.2 + gunLen * 0.88);
  weaponPivot.add(muzzlePoint);

  // Bright windup telegraph orb before enemy shoots
  const telegraphGlow = new THREE.Mesh(
    new THREE.SphereGeometry(0.11, 10, 10),
    new THREE.MeshBasicMaterial({ color: 0xff5a2b, transparent: true, opacity: 0.9 }),
  );
  telegraphGlow.position.copy(muzzlePoint.position);
  telegraphGlow.visible = false;
  weaponPivot.add(telegraphGlow);

  // Floating world-space health bar above enemy
  const hpBarBg = new THREE.Mesh(
    new THREE.PlaneGeometry(0.95, 0.12),
    new THREE.MeshBasicMaterial({ color: 0x1a1210, side: THREE.DoubleSide }),
  );
  hpBarBg.position.set(0, 2.25 * scale, 0);
  hpBarBg.visible = false;
  root.add(hpBarBg);

  const hpFillGeo = new THREE.PlaneGeometry(0.89, 0.075);
  hpFillGeo.translate(0.445, 0, 0);
  const hpBarFill = new THREE.Mesh(
    hpFillGeo,
    new THREE.MeshBasicMaterial({ color: 0xe83b2e, side: THREE.DoubleSide }),
  );
  hpBarFill.position.set(-0.445, 0, 0.01);
  hpBarBg.add(hpBarFill);

  return {
    root,
    bodyGroup,
    headGroup,
    leftLeg: leftLegBuild.hip,
    rightLeg: rightLegBuild.hip,
    leftKnee: leftLegBuild.knee,
    rightKnee: rightLegBuild.knee,
    weaponPivot,
    muzzlePoint,
    telegraphGlow,
    hpBarBg,
    hpBarFill,
    flashMaterials,
    baseEmissives,
  };
}

// ============================================================================
// Tactical Supply Pickups (Health Medkit & Ammo Crate)
// ============================================================================

export function buildPickupMesh(kind: PickupKind): THREE.Group {
  const group = new THREE.Group();

  const isHealth = kind === 'health';
  const boxMat = new THREE.MeshStandardMaterial({
    color: isHealth ? 0xf7f2e7 : 0x3b4d2b,
    roughness: 0.45,
    metalness: 0.25,
    emissive: isHealth ? 0x224a2b : 0x523f12,
    emissiveIntensity: 0.45,
  });
  const accentMat = new THREE.MeshStandardMaterial({
    color: isHealth ? 0xd92626 : 0xf4bd14,
    emissive: isHealth ? 0xd92626 : 0xe8a812,
    emissiveIntensity: 1.1,
    roughness: 0.3,
  });

  const crate = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.44, 0.48), boxMat);
  crate.position.y = 0.42;
  crate.castShadow = true;
  group.add(crate);

  if (isHealth) {
    const crossH = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.09, 0.52), accentMat);
    crossH.position.y = 0.42;
    const crossV = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.3, 0.52), accentMat);
    crossV.position.y = 0.42;
    group.add(crossH, crossV);
  } else {
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.66, 0.12, 0.52), accentMat);
    stripe.position.y = 0.44;
    group.add(stripe);
  }

  // Ground beacon ring
  const ring = new THREE.Mesh(
    new THREE.RingGeometry(0.48, 0.62, 20),
    new THREE.MeshBasicMaterial({
      color: isHealth ? 0x38d679 : 0xf7c538,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.72,
    }),
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.04;
  group.add(ring);

  return group;
}
