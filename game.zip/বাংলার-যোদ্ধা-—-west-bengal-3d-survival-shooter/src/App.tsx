import { useCallback, useEffect, useRef, useState } from 'react';
import { GameHud } from './components/GameHud';
import { StatusModal } from './components/StatusModal';
import { TitleOverlay } from './components/TitleOverlay';
import { TouchControls } from './components/TouchControls';
import { GameEngine } from './game/GameEngine';
import { GamchaStyle, HudSnapshot, WeaponType } from './game/types';

const INITIAL_HUD: HudSnapshot = {
  phase: 'title',
  busMode: 'none',
  nearBus: false,
  busZoneLabel: null,
  busSpeedKmh: 0,
  busRouteProgress: 0,
  health: 100,
  maxHealth: 100,
  ammo: 24,
  maxAmmo: 24,
  reserveAmmo: 96,
  isReloading: false,
  reloadProgress: 1,
  score: 0,
  highScore: 0,
  kills: 0,
  wave: 1,
  enemiesRemaining: 0,
  waveBanner: null,
  damageFlash: 0,
  hitMarker: 0,
  hitMarkerKill: false,
  muted: false,
  sprintRatio: 1,
  pickupToast: null,
};

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const [hud, setHud] = useState<HudSnapshot>(INITIAL_HUD);
  const [gamchaStyle, setGamchaStyle] = useState<GamchaStyle>('red-white');
  const [weaponType, setWeaponType] = useState<WeaponType>('rifle');

  useEffect(() => {
    const mount = canvasMountRef.current;
    if (!mount) return;

    const engine = new GameEngine(mount, (snapshot) => {
      setHud(snapshot);
    });
    engineRef.current = engine;

    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  const handleSelectGamcha = useCallback((style: GamchaStyle) => {
    setGamchaStyle(style);
    engineRef.current?.setGamchaStyle(style);
  }, []);

  const handleSelectWeapon = useCallback((weapon: WeaponType) => {
    setWeaponType(weapon);
    engineRef.current?.setWeaponType(weapon);
  }, []);

  const handleStart = useCallback(() => {
    engineRef.current?.startGame();
  }, []);

  const handlePause = useCallback(() => {
    engineRef.current?.togglePause();
  }, []);

  const handleMainMenu = useCallback(() => {
    engineRef.current?.returnToTitle();
  }, []);

  const handleToggleMute = useCallback(() => {
    engineRef.current?.toggleMute();
  }, []);

  const handleVirtualMove = useCallback((x: number, y: number) => {
    engineRef.current?.setVirtualMove(x, y);
  }, []);

  const handleVirtualShoot = useCallback((active: boolean) => {
    engineRef.current?.setVirtualShoot(active);
  }, []);

  const handleVirtualSprint = useCallback((active: boolean) => {
    engineRef.current?.setVirtualSprint(active);
  }, []);

  const handleReload = useCallback(() => {
    engineRef.current?.triggerReload();
  }, []);

  const handleExitBus = useCallback(() => {
    engineRef.current?.exitBus();
  }, []);

  const handleEnterBus = useCallback(() => {
    engineRef.current?.enterBus();
  }, []);

  const handleBusHorn = useCallback(() => {
    engineRef.current?.honkBusHorn();
  }, []);

  return (
    <main className="relative h-screen w-screen overflow-hidden bg-[#18120e]">
      {/* Isolated WebGL canvas mount — React HUD state updates never recreate the canvas */}
      <div
        ref={canvasMountRef}
        className={`fixed inset-0 h-full w-full touch-none ${
          hud.phase === 'title' ? 'cursor-grab active:cursor-grabbing' : ''
        }`}
      />

      {hud.phase === 'title' && (
        <TitleOverlay
          highScore={hud.highScore}
          muted={hud.muted}
          gamchaStyle={gamchaStyle}
          weaponType={weaponType}
          onSelectGamcha={handleSelectGamcha}
          onSelectWeapon={handleSelectWeapon}
          onStart={handleStart}
          onToggleMute={handleToggleMute}
        />
      )}

      {hud.phase !== 'title' && (
        <GameHud
          hud={hud}
          onPause={handlePause}
          onToggleMute={handleToggleMute}
          onExitBus={handleExitBus}
          onEnterBus={handleEnterBus}
          onBusHorn={handleBusHorn}
        />
      )}

      {hud.phase === 'playing' && (
        <TouchControls
          busMode={hud.busMode}
          onMove={handleVirtualMove}
          onShootChange={handleVirtualShoot}
          onSprintChange={handleVirtualSprint}
          onReload={handleReload}
          onExitBus={handleExitBus}
          onBusHorn={handleBusHorn}
          isReloading={hud.isReloading}
          ammo={hud.ammo}
          maxAmmo={hud.maxAmmo}
          reserveAmmo={hud.reserveAmmo}
        />
      )}

      <StatusModal
        hud={hud}
        onResume={handlePause}
        onRestart={handleStart}
        onMainMenu={handleMainMenu}
      />
    </main>
  );
}
