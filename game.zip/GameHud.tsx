import React, { useState } from 'react';
import { toBengaliNumber } from '../game/GameEngine';
import { HudSnapshot } from '../game/types';

interface GameHudProps {
  hud: HudSnapshot;
  onPause: () => void;
  onToggleMute: () => void;
  onExitBus: () => void;
  onEnterBus: () => void;
  onBusHorn: () => void;
  onToggleZoom?: (zoomed: boolean) => void;
}

export const GameHud: React.FC<GameHudProps> = ({
  hud,
  onPause,
  onToggleMute,
  onExitBus,
  onEnterBus,
  onBusHorn,
  onToggleZoom,
}) => {
  const [isZoomed, setIsZoomed] = useState(false);

  const healthPct = Math.max(0, Math.min(100, (hud.health / hud.maxHealth) * 100));
  const lowHealth = healthPct <= 30;
  const lowAmmo = hud.ammo <= 5 && !hud.isReloading;

  const handleZoomToggle = () => {
    const nextState = !isZoomed;
    setIsZoomed(nextState);
    if (onToggleZoom) {
      onToggleZoom(nextState);
    }
    window.dispatchEvent(
      new CustomEvent('banglar-joddha-zoom', { detail: { zoomed: nextState } })
    );
  };

  return (
    <div className="pointer-events-none fixed inset-0 z-10 overflow-hidden select-none">
      {/* Damage Red Vignette Flash */}
      {hud.damageFlash > 0.02 && (
        <div
          style={{
            opacity: Math.min(0.85, hud.damageFlash),
            boxShadow: 'inset 0 0 110px 36px rgba(196, 20, 24, 0.85)',
          }}
          className="pointer-events-none fixed inset-0"
        />
      )}

      {/* Top Perimeter Status Row */}
      <div className="flex items-start justify-between gap-2 px-3 pt-2.5 sm:px-5 sm:pt-3.5">
        {/* Top-Left: Pill Health & Compact Stat Pills */}
        <div className="flex flex-col gap-1.5">
          <div className="flex w-[184px] items-center gap-2 rounded-full border border-amber-400/50 bg-black/45 px-3 py-1.5 backdrop-blur-md shadow-[0_4px_14px_rgba(0,0,0,0.4)] sm:w-[225px]">
            <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 shrink-0 fill-[#ff4742]">
              <path d="M10 17.5l-1.2-1.1C4.4 12.5 1.8 10.1 1.8 7.1 1.8 4.7 3.7 2.8 6.1 2.8c1.4 0 2.7.7 3.9 1.8 1.2-1.1 2.5-1.8 3.9-1.8 2.4 0 4.3 1.9 4.3 4.3 0 3-2.6 5.4-7 9.3L10 17.5z" />
            </svg>
            <div className="h-2 flex-1 overflow-hidden rounded-full bg-white/15">
              <div
                style={{ width: `${healthPct}%` }}
                className={`h-full rounded-full transition-[width] duration-150 ${
                  lowHealth ? 'bg-[#ff3b3b]' : 'bg-gradient-to-r from-[#e02d32] to-[#ff9838]'
                }`}
              />
            </div>
            <span
              className={`font-bengali-ui tabular-nums whitespace-nowrap text-[11px] font-bold ${
                lowHealth ? 'text-[#ff7870]' : 'text-[#ffe6ad]'
              }`}
            >
              {toBengaliNumber(hud.health)}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            <div className="whitespace-nowrap rounded-full border border-amber-400/45 bg-black/45 px-2 py-0.5 text-[10px] font-semibold text-[#fdf0d5] backdrop-blur-md sm:px-2.5 sm:text-[11px]">
              <span className="text-[#f5be58]">তরঙ্গ </span>
              <span className="tabular-nums font-bold">{toBengaliNumber(hud.wave)}</span>
            </div>
            <div className="whitespace-nowrap rounded-full border border-amber-400/45 bg-black/45 px-2 py-0.5 text-[10px] font-semibold text-[#fdf0d5] backdrop-blur-md sm:px-2.5 sm:text-[11px]">
              <span className="text-[#ff7b6b]">শত্রু </span>
              <span className="tabular-nums font-bold">{toBengaliNumber(hud.enemiesRemaining)}</span>
            </div>
            <div className="whitespace-nowrap rounded-full border border-amber-400/45 bg-black/45 px-2 py-0.5 text-[10px] font-semibold text-[#fdf0d5] backdrop-blur-md sm:px-2.5 sm:text-[11px]">
              <span className="text-[#ffd269]">স্কোর </span>
              <span className="tabular-nums font-bold">{toBengaliNumber(hud.score)}</span>
            </div>
          </div>
        </div>

        {/* Top-Right: Pill Ammo / Bus Speed + Circular Mute & Pause Buttons */}
        <div className="flex shrink-0 items-center gap-1.5 sm:gap-2">
          {hud.busMode === 'driving' ? (
            <div className="flex items-center gap-1.5 whitespace-nowrap rounded-full border border-sky-400/55 bg-black/50 px-3 py-1.5 backdrop-blur-md shadow-[0_4px_14px_rgba(0,0,0,0.45)]">
              <span className="font-bengali-ui text-[11px] font-bold text-[#ffd65c]">গতি</span>
              <span className="font-bengali-ui tabular-nums text-xs font-bold text-[#fff7e2] sm:text-sm">
                {toBengaliNumber(hud.busSpeedKmh)} কিমি/ঘ
              </span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 whitespace-nowrap rounded-full border border-amber-400/50 bg-black/45 px-3 py-1.5 backdrop-blur-md shadow-[0_4px_14px_rgba(0,0,0,0.42)]">
              <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 fill-[#f4c04e]">
                <path d="M5 17h3V8.5L6.5 3 5 8.5V17zm7 0h3V8.5L13.5 3 12 8.5V17z" />
              </svg>
              {hud.isReloading ? (
                <span className="font-bengali-ui text-[11px] font-bold text-[#ffd67d]">
                  রিলোড...
                </span>
              ) : (
                <div className="font-bengali-ui tabular-nums text-xs font-bold leading-none">
                  <span className={lowAmmo ? 'text-[#ff6961]' : 'text-[#fff5e1]'}>
                    {toBengaliNumber(hud.ammo)}
                  </span>
                  <span className="mx-0.5 text-[#c7a980]">/</span>
                  <span className="text-[#d9bd96]">{toBengaliNumber(hud.reserveAmmo)}</span>
                </div>
              )}
            </div>
          )}

          {/* Circular Mute Toggle */}
          <button
            type="button"
            onClick={onToggleMute}
            aria-label={hud.muted ? 'শব্দ চালু করুন' : 'শব্দ বন্ধ করুন'}
            className="pointer-events-auto flex h-9 w-9 items-center justify-center rounded-full border border-amber-400/50 bg-black/45 text-[#fdebd0] backdrop-blur-md shadow-[0_4px_14px_rgba(0,0,0,0.4)] transition active:scale-95 hover:bg-black/65"
          >
            {hud.muted ? (
              <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current stroke-2">
                <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                <line x1="22" y1="9" x2="16" y2="15" strokeLinecap="round" />
                <line x1="16" y1="9" x2="22" y2="15" strokeLinecap="round" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current stroke-2">
                <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                <path d="M15.5 8.5a5 5 0 0 1 0 7" strokeLinecap="round" />
              </svg>
            )}
          </button>

          {/* Circular Pause Button */}
          <button
            type="button"
            onClick={onPause}
            aria-label="বিরতি"
            className="pointer-events-auto flex h-9 w-9 items-center justify-center rounded-full border border-amber-400/50 bg-black/45 text-[#fdebd0] backdrop-blur-md shadow-[0_4px_14px_rgba(0,0,0,0.4)] transition active:scale-95 hover:bg-black/65"
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4 fill-current">
              <rect x="6" y="5" width="4" height="14" rx="1.5" />
              <rect x="14" y="5" width="4" height="14" rx="1.5" />
            </svg>
          </button>
        </div>
      </div>

      {/* Circular Zoom In / Zoom Out Button */}
      {hud.busMode === 'none' && (
        <div className="pointer-events-auto fixed bottom-36 right-4 z-20 flex flex-col items-center gap-1 sm:right-6">
          <button
            type="button"
            onClick={handleZoomToggle}
            aria-label={isZoomed ? 'জুম আউট' : 'জুম ইন'}
            className={`flex h-12 w-12 items-center justify-center rounded-full border-2 backdrop-blur-md transition-all active:scale-90 ${
              isZoomed
                ? 'border-amber-300 bg-amber-500/35 text-amber-200 ring-4 ring-amber-400/40 shadow-[0_0_20px_rgba(251,191,36,0.65)]'
                : 'border-amber-400/50 bg-black/45 text-[#fdf0d5] shadow-[0_4px_14px_rgba(0,0,0,0.45)] hover:bg-black/65'
            }`}
          >
            {isZoomed ? (
              <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-2">
                <circle cx="11" cy="11" r="7" />
                <line x1="21" y1="21" x2="16.65" y2="16.65" strokeLinecap="round" />
                <line x1="8" y1="11" x2="14" y2="11" strokeLinecap="round" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-2">
                <circle cx="11" cy="11" r="7" />
                <line x1="21" y1="21" x2="16.65" y2="16.65" strokeLinecap="round" />
                <line x1="11" y1="8" x2="11" y2="14" strokeLinecap="round" />
                <line x1="8" y1="11" x2="14" y2="11" strokeLinecap="round" />
              </svg>
            )}
          </button>
          <span className="font-bengali-ui rounded-full bg-black/50 px-2 py-0.5 text-[10px] font-bold text-amber-200 backdrop-blur-sm">
            {isZoomed ? 'জুম আউট' : 'জুম ইন'}
          </span>
        </div>
      )}

      {/* Center Reticle & Hitmarker */}
      {hud.busMode === 'none' && (
        <div className="pointer-events-none fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className={`relative transition-transform duration-150 ${isZoomed ? 'scale-125' : 'scale-100'} h-9 w-9`}>
            <span className="absolute left-1/2 top-0 h-2.5 w-[2px] -translate-x-1/2 bg-[#fff6e2]/90 shadow" />
            <span className="absolute bottom-0 left-1/2 h-2.5 w-[2px] -translate-x-1/2 bg-[#fff6e2]/90 shadow" />
            <span className="absolute left-0 top-1/2 h-[2px] w-2.5 -translate-y-1/2 bg-[#fff6e2]/90 shadow" />
            <span className="absolute right-0 top-1/2 h-[2px] w-2.5 -translate-y-1/2 bg-[#fff6e2]/90 shadow" />
            <span className="absolute left-1/2 top-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#f5c247]" />

            {hud.hitMarker > 0.05 && (
              <svg
                viewBox="0 0 36 36"
                style={{ opacity: Math.min(1, hud.hitMarker) }}
                className="absolute inset-0 h-9 w-9"
              >
                <g
                  stroke={hud.hitMarkerKill ? '#ff3838' : '#ffe078'}
                  strokeWidth={hud.hitMarkerKill ? 3 : 2.2}
                  strokeLinecap="round"
                >
                  <line x1="7" y1="7" x2="13" y2="13" />
                  <line x1="29" y1="7" x2="23" y2="13" />
                  <line x1="7" y1="29" x2="13" y2="23" />
                  <line x1="29" y1="29" x2="23" y2="23" />
                </g>
              </svg>
            )}
          </div>
        </div>
      )}

      {/* WBTC INTRO BUS RIDE UI */}
      {hud.busMode === 'riding_intro' && (
        <>
          <div className="pointer-events-none fixed left-1/2 top-14 -translate-x-1/2 rounded-full border border-sky-400/50 bg-black/50 px-3.5 py-1 backdrop-blur-md shadow">
            <div className="flex items-center gap-2 text-[11px] font-bold text-[#ffd85c]">
              <span>WBTC S-12</span>
              <span className="text-[#8fc8f5]">•</span>
              <span className="font-bengali-ui text-[#fff6e3]">{hud.busZoneLabel || 'হাওড়া সেতু'}</span>
            </div>
          </div>

          <div className="pointer-events-auto fixed bottom-3 left-1/2 z-30 flex -translate-x-1/2 items-center gap-2.5">
            <button
              type="button"
              onClick={onExitBus}
              className="font-bengali-display flex items-center gap-2 whitespace-nowrap rounded-full border-2 border-[#fff1b5] bg-gradient-to-b from-[#ffe047] via-[#f5b415] to-[#d97c06] px-5 py-2.5 text-sm font-extrabold tracking-wide text-[#241205] shadow-[0_0_22px_rgba(255,194,32,0.65)] transition-transform active:scale-95 sm:px-6 sm:text-base"
            >
              <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-[#241205] stroke-[2.4]">
                <path d="M12 4v12" strokeLinecap="round" />
                <path d="M7 11l5 5 5-5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <span>বাস থেকে নামুন</span>
            </button>

            <button
              type="button"
              onClick={onBusHorn}
              aria-label="হর্ন বাজান"
              className="flex h-11 w-11 items-center justify-center rounded-full border border-amber-300/60 bg-black/55 text-[#ffd85c] backdrop-blur-md transition active:scale-95"
            >
              <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-2">
                <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                <path d="M15.5 8.5a5 5 0 0 1 0 7" strokeLinecap="round" />
              </svg>
            </button>
          </div>
        </>
      )}

      {/* Enter Bus Prompt when near WBTC bus */}
      {hud.busMode === 'none' && hud.nearBus && (
        <div className="pointer-events-auto fixed bottom-28 left-1/2 z-30 -translate-x-1/2">
          <button
            type="button"
            onClick={onEnterBus}
            className="font-bengali-display whitespace-nowrap rounded-full border border-sky-300/70 bg-black/65 px-4 py-2 text-xs font-bold text-[#ffe27a] backdrop-blur-md shadow-lg transition active:scale-95"
          >
            WBTC বাসে উঠুন
          </button>
        </div>
      )}

      {/* Wave Banner & Pickup Toast */}
      {(hud.waveBanner || hud.pickupToast) && (
        <div className="pointer-events-none fixed left-1/2 top-24 flex -translate-x-1/2 flex-col items-center gap-1.5">
          {hud.waveBanner && (
            <div className="font-bengali-display whitespace-nowrap rounded-full border border-amber-300/60 bg-black/60 px-4 py-1 text-xs font-bold text-[#ffe380] backdrop-blur-md shadow">
              {hud.waveBanner}
            </div>
          )}
          {hud.pickupToast && (
            <div className="font-bengali-ui whitespace-nowrap rounded-full border border-emerald-300/50 bg-black/60 px-3.5 py-0.5 text-[11px] font-bold text-emerald-200 backdrop-blur-md shadow">
              {hud.pickupToast}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
