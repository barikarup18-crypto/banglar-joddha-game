import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { GameAudio } from './audio';
import {
  buildBajraGolaMesh,
  buildKalboishakhiStormWall,
  buildWarriorChest,
  createFloatingDamageSprite,
  KalboishakhiStormRig,
  WarriorChestRig,
} from './battleRoyaleAssets';
import {
  buildWbtcBus,
  BusRouteData,
  createBusIntroRoute,
  WbtcBusRig,
} from './bus';
import {
  buildBengaliHero,
  buildEnemyBot,
  buildPickupMesh,
  EnemyRig,
  HeroRig,
} from './characters';
import { createTextureBundle, TextureBundle } from './textures';
import {
  BusMode,
  CircleCollider,
  EnemyArchetype,
  GamchaStyle,
  GamePhase,
  HudSnapshot,
  PickupKind,
  VirtualInputState,
  WEAPON_CATALOG,
  WEAPON_SLOT_ORDER,
  WeaponSlotSnapshot,
  WeaponType,
} from './types';
import { buildWestBengalWorld, WorldBuildResult } from './worldBuilder';

interface ActiveEnemy {
  id: number;
  archetype: EnemyArchetype;
  rig: EnemyRig;
  hp: number;
  maxHp: number;
  speed: number;
  radius: number;
  fireRange: number;
  fireCooldown: number;
  telegraphTimer: number;
  strafeDir: number;
  strafeTimer: number;
  walkPhase: number;
  hitFlashTimer: number;
  dying: boolean;
  deathTimer: number;
  knockback: THREE.Vector3;
  // Bus riding, smooth jump landing & 2-second post-landing safe phase
  busSeatIndex: number; // -1 when on foot or jumping
  busDropT: number;
  jumpingFromBus: boolean;
  jumpProgress: number;
  jumpDuration: number;
  jumpStart: THREE.Vector3;
  jumpEnd: THREE.Vector3;
  jumpPeakY: number;
  postLandingSafeTimer: number; // 2.0s after touching y=0 before enemy can aim or shoot
}

interface Bullet {
  active: boolean;
  fromPlayer: boolean;
  mesh: THREE.Mesh;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  life: number;
  damage: number;
}

interface Particle {
  active: boolean;
  mesh: THREE.Mesh;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  life: number;
  maxLife: number;
  scale: number;
}

interface PickupItem {
  id: number;
  kind: PickupKind;
  mesh: THREE.Group;
  pos: THREE.Vector3;
  life: number;
}

interface LootChestItem {
  id: number;
  rig: WarriorChestRig;
  pos: THREE.Vector3;
  opened: boolean;
  openProgress: number;
  life: number;
}

interface ThrownGrenade {
  id: number;
  mesh: THREE.Group;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  fuseTimer: number;
}

interface FloatingDamageText {
  sprite: THREE.Sprite;
  texture: THREE.CanvasTexture;
  material: THREE.SpriteMaterial;
  pos: THREE.Vector3;
  velY: number;
  life: number;
  maxLife: number;
  baseScaleX: number;
  baseScaleY: number;
}

interface ExplosionShockwave {
  mesh: THREE.Mesh;
  life: number;
  maxLife: number;
}

// Pre-allocated zero-GC scratch helpers
const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _v3 = new THREE.Vector3();
const _v4 = new THREE.Vector3();
const _v5 = new THREE.Vector3();
const _v6 = new THREE.Vector3();
const _camTarget = new THREE.Vector3();
const _camDesired = new THREE.Vector3();
const _lookAtPt = new THREE.Vector3();

const STORAGE_KEY_HIGHSCORE = 'banglar_joddha_high_score_v1';

const BENGALI_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
export function toBengaliNumber(n: number): string {
  return String(Math.max(0, Math.floor(n)))
    .split('')
    .map((ch) => {
      const code = ch.charCodeAt(0) - 48;
      return code >= 0 && code <= 9 ? BENGALI_DIGITS[code] : ch;
    })
    .join('');
}

export class GameEngine {
  private container: HTMLElement;
  private onHudUpdate: (snapshot: HudSnapshot) => void;
  private isSoftwareGl: boolean;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private sunLight: THREE.DirectionalLight;
  private textures: TextureBundle;
  private world: WorldBuildResult;
  private bus: WbtcBusRig;
  private busRoute: BusRouteData;
  private hero: HeroRig;
  private audio: GameAudio;

  // Game state
  private phase: GamePhase = 'title';
  private busMode: BusMode = 'none';
  private busAutoDriving = false;
  private busRouteT = 0;
  private busPos = new THREE.Vector3(-13, 0, 8.2);
  private busYaw = -Math.PI / 2;
  private busSpeed = 0;
  private busSteerAngle = 0;
  private busZoneLabel: string | null = null;
  private nearBus = false;
  // Realistic WBTC Bus Interior Camera & Direct Ground Exit (Braking + Bi-Fold Door Open, No Parachute)
  private busInteriorCam = true;
  private busExitSlowing = false;
  private busExitSlowTimer = 0;
  private readonly busExitSlowDuration = 0.54;
  private busDoorOpenAmount = 0;
  private busDoorAutoHoldTimer = 0;
  private busInteriorLookYaw = 0;
  private heroDoorwayWorld = new THREE.Vector3();
  // Short grounded hop arc when stepping/jumping directly onto bridge or road from open bus door
  private heroJumpingFromBus = false;
  private heroJumpProgress = 0;
  private heroJumpDuration = 0.26;
  private heroJumpStart = new THREE.Vector3();
  private heroJumpEnd = new THREE.Vector3();
  private heroJumpPeakY = 1.2;

  private gamchaStyle: GamchaStyle = 'red-white';
  private weaponType: WeaponType = 'agni47';
  private weaponSlots: Record<WeaponType, WeaponSlotSnapshot> = {
    agni47: {
      ammo: WEAPON_CATALOG.agni47.magSize,
      maxAmmo: WEAPON_CATALOG.agni47.magSize,
      reserve: WEAPON_CATALOG.agni47.startReserve,
    },
    kalbhairav: {
      ammo: WEAPON_CATALOG.kalbhairav.magSize,
      maxAmmo: WEAPON_CATALOG.kalbhairav.magSize,
      reserve: WEAPON_CATALOG.kalbhairav.startReserve,
    },
    trishul: {
      ammo: WEAPON_CATALOG.trishul.magSize,
      maxAmmo: WEAPON_CATALOG.trishul.magSize,
      reserve: WEAPON_CATALOG.trishul.startReserve,
    },
    fala: { ammo: 0, maxAmmo: 0, reserve: 0 },
  };
  private scopeActive = false;
  private currentFov = 56;
  private meleeSlashTimer = 0;

  private heroPos = new THREE.Vector3(0, 0, 7.2);
  private prevHeroPos = new THREE.Vector3(0, 0, 7.2);
  private prevHeroYaw = 0.28;
  private heroYaw = 0.28; // heroic 3/4 stance facing lobby camera
  private lobbyHeroYaw = 0.28;
  private lobbyHeroTargetYaw = 0.28;
  private lobbyShowcasePulse = 0;
  private heroWalkPhase = 0;
  private heroRecoil = 0;
  private muzzleFlashTimer = 0;
  private health = 100;
  private readonly maxHealth = 100;
  private armor = 0;
  private readonly maxArmor = 50;
  private isReloading = false;
  private reloadTimer = 0;
  private reloadDuration = 1.15;
  private fireCooldown = 0;
  private sprintStamina = 1.0;

  // Sanjibani Healing Plants & Bajra Gola Grenades
  private sanjibaniCount = 1;
  private sanjibaniCollected = 0;
  private readonly maxSanjibani = 5;
  private isHealing = false;
  private healTimer = 0;
  private readonly healDuration = 3.0;
  private grenadeCount = 1;
  private readonly maxGrenades = 3;

  // Warrior Loot Chests proximity
  private nearChest = false;
  private nearestChest: LootChestItem | null = null;

  // Headshot & Body Shot counters
  private headshots = 0;
  private bodyshots = 0;
  private hitMarkerHeadshot = false;

  // Kalboishakhi Shrinking Safe Zone (starts full-map at 550u, contracts in 4 stages every 90s)
  private stormRig!: KalboishakhiStormRig;
  private stormCenter = new THREE.Vector2(0, 6);
  private readonly initialStormRadius = 550;
  private readonly stormPhaseInterval = 90;
  private stormPhase = 1;
  private stormRadius = 550;
  private stormStartRadius = 550;
  private stormTargetRadius = 550;
  private stormCountdown = 90;
  private stormShrinking = false;
  private stormShrinkElapsed = 0;
  private readonly stormShrinkDuration = 22;
  private readonly outsideStormDuration = 60;
  private outsideStorm = false;
  private outsideStormElapsed = 0;
  private stormDrainTimer = 0;
  private stormTeleportFlash = 0;

  private score = 0;
  private highScore = 0;
  private kills = 0;
  private wave = 1;
  private waveEnemiesToSpawn: EnemyArchetype[] = [];
  private waveSpawnTimer = 0;
  private waveBreakTimer = 0;
  private waveBanner: string | null = null;
  private waveBannerTimer = 0;
  private pickupToast: string | null = null;
  private pickupToastTimer = 0;

  // Juice, Lobby & Camera Transition
  private camYaw = Math.PI; // looking north (-Z) toward the river & bridge
  private camPitch = 0.24;
  private camShake = 0;
  private hitstopTimer = 0;
  private damageFlash = 0;
  private hitMarker = 0;
  private hitMarkerKill = false;
  private titleTime = 0;
  private worldTime = 0;
  private introTransitionProgress = 1; // < 1 while sweeping from lobby into gameplay
  private readonly introTransitionDuration = 0.92;
  private introStartCamPos = new THREE.Vector3();
  private introStartLookAt = new THREE.Vector3();
  private lobbyDragActive = false;
  private lobbyDragPointerId: number | null = null;
  private lobbyLastDragX = 0;

  // Entities & Pools
  private enemies: ActiveEnemy[] = [];
  private nextEnemyId = 1;
  private pickups: PickupItem[] = [];
  private nextPickupId = 1;
  private chests: LootChestItem[] = [];
  private nextChestId = 1;
  private grenades: ThrownGrenade[] = [];
  private nextGrenadeId = 1;
  private floatingDamages: FloatingDamageText[] = [];
  private shockwaves: ExplosionShockwave[] = [];
  private bullets: Bullet[] = [];
  private particles: Particle[] = [];

  // Input state
  private keysHeld = new Set<string>();
  private mouseShootHeld = false;
  private dragLookActive = false;
  private dragPointerId: number | null = null;
  private lastDragX = 0;
  private lastDragY = 0;
  private virtualInput: VirtualInputState = {
    moveX: 0,
    moveY: 0,
    shooting: false,
    sprinting: false,
    reloadJustPressed: false,
    lookDeltaX: 0,
    lookDeltaY: 0,
  };

  // Loop & lifecycle
  private disposed = false;
  private frameId = 0;
  private lastFrameMs = 0;
  private hudEmitAccum = 0;

  constructor(container: HTMLElement, onHudUpdate: (snapshot: HudSnapshot) => void) {
    this.container = container;
    this.onHudUpdate = onHudUpdate;
    this.audio = new GameAudio();

    try {
      const saved = localStorage.getItem(STORAGE_KEY_HIGHSCORE);
      if (saved) this.highScore = Math.max(0, parseInt(saved, 10) || 0);
    } catch {
      // ignore storage restrictions
    }

    // Software WebGL detection from GPU renderer string (never user agent)
    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.24;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);

    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    container.appendChild(this.renderer.domElement);

    // Scene & bright sunny Bengali daytime atmosphere (clear blue sky + light airy horizon haze across 1000x1000 map)
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x87cefa);
    this.scene.fog = new THREE.FogExp2(0xc7e6fa, 0.0011);

    // Mandatory studio environment map via RoomEnvironment on all devices
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    // Camera (far plane 1650 so 1000x1000 map, 550u Safe Zone, and 1350u bright blue sky dome render cleanly)
    const aspect =
      (container.clientWidth || window.innerWidth) /
      Math.max(1, container.clientHeight || window.innerHeight);
    this.camera = new THREE.PerspectiveCamera(56, aspect, 0.15, 1650);

    // Bright sunny Bengali daytime lighting rig across bridge, river, and village
    const ambient = new THREE.AmbientLight(0xfff9ed, 0.52);
    this.scene.add(ambient);

    const hemi = new THREE.HemisphereLight(0xbbe6ff, 0xa8916b, 1.15);
    this.scene.add(hemi);

    this.sunLight = new THREE.DirectionalLight(0xfff4d4, 2.75);
    this.sunLight.position.set(34, 58, -26);
    this.sunLight.castShadow = true;
    this.sunLight.shadow.mapSize.set(2048, 2048);
    const d = 34;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.sunLight.shadow.camera.near = 2;
    this.sunLight.shadow.camera.far = 140;
    this.sunLight.shadow.bias = -0.0005;
    this.sunLight.shadow.normalBias = 0.025;
    this.scene.add(this.sunLight);
    this.scene.add(this.sunLight.target);

    // Crisp daytime sky rim fill + warm front fill so the hero and village stay bright from every angle
    const rimLight = new THREE.DirectionalLight(0xdff3ff, 0.68);
    rimLight.position.set(-30, 24, -45);
    this.scene.add(rimLight);

    const frontFillLight = new THREE.DirectionalLight(0xfff4d8, 0.78);
    frontFillLight.position.set(16, 18, 24);
    this.scene.add(frontFillLight);

    // Procedural Textures, World, WBTC Passenger Bus & Hero
    this.textures = createTextureBundle(this.renderer);
    this.world = buildWestBengalWorld(this.textures);
    this.scene.add(this.world.worldGroup);

    this.busRoute = createBusIntroRoute();
    this.scene.add(this.busRoute.rampMesh);

    this.bus = buildWbtcBus(this.textures);
    this.bus.root.position.set(-13, 0, 8.2);
    this.scene.add(this.bus.root);

    this.hero = buildBengaliHero(this.textures);
    this.hero.root.position.copy(this.heroPos);
    this.hero.root.rotation.y = this.heroYaw;
    this.scene.add(this.hero.root);

    // Kalboishakhi Shrinking Storm Wall (hidden in title lobby, active during match)
    this.stormRig = buildKalboishakhiStormWall();
    this.stormRig.root.visible = false;
    this.scene.add(this.stormRig.root);

    // Pre-allocate bullet & particle pools
    this.initPools();

    // Pre-warm shaders on GPU (skip on software WebGL)
    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.bindEvents();
    this.emitHud();

    this.lastFrameMs = performance.now();
    this.tick();
  }

  private initPools(): void {
    const playerBulletGeo = new THREE.BoxGeometry(0.06, 0.06, 0.58);
    const enemyBulletGeo = new THREE.SphereGeometry(0.11, 6, 6);
    const playerBulletMat = new THREE.MeshBasicMaterial({ color: 0xffe48a });
    const enemyBulletMat = new THREE.MeshBasicMaterial({ color: 0xff4930 });

    for (let i = 0; i < 48; i++) {
      const isPlayer = i < 28;
      const mesh = new THREE.Mesh(
        isPlayer ? playerBulletGeo : enemyBulletGeo,
        isPlayer ? playerBulletMat : enemyBulletMat,
      );
      mesh.visible = false;
      this.scene.add(mesh);
      this.bullets.push({
        active: false,
        fromPlayer: isPlayer,
        mesh,
        pos: new THREE.Vector3(),
        vel: new THREE.Vector3(),
        life: 0,
        damage: isPlayer ? 34 : 11,
      });
    }

    const partGeo = new THREE.BoxGeometry(0.13, 0.13, 0.13);
    for (let i = 0; i < 64; i++) {
      const mat = new THREE.MeshBasicMaterial({ color: 0xffb84d });
      const mesh = new THREE.Mesh(partGeo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.particles.push({
        active: false,
        mesh,
        pos: new THREE.Vector3(),
        vel: new THREE.Vector3(),
        life: 0,
        maxLife: 0.4,
        scale: 1,
      });
    }
  }

  // --- Public API for React UI ---

  public setGamchaStyle(style: GamchaStyle): void {
    this.gamchaStyle = style;
    this.hero.gamchaMaterial.map =
      style === 'green-white' ? this.textures.gamchaGreenMap : this.textures.gamchaMap;
    this.hero.gamchaMaterial.needsUpdate = true;
    this.lobbyShowcasePulse = 1.0;
    this.audio.unlock();
    this.audio.playPickup('health');
  }

  public setWeaponType(weapon: WeaponType): void {
    this.weaponType = weapon;
    this.hero.rifleGroup.visible = weapon === 'agni47';
    this.hero.shotgunGroup.visible = weapon === 'kalbhairav';
    this.hero.trishulGroup.visible = weapon === 'trishul';
    this.hero.falaGroup.visible = weapon === 'fala';
    this.hero.muzzlePoint.position.set(
      0,
      0.028,
      weapon === 'trishul' ? 1.28 : weapon === 'kalbhairav' ? 0.92 : 0.97,
    );

    // Cancel reload & sniper scope when switching weapons
    this.isReloading = false;
    this.reloadTimer = 0;
    this.reloadDuration = WEAPON_CATALOG[weapon].reloadDuration || 1.15;
    if (weapon !== 'trishul') {
      this.scopeActive = false;
    }

    this.lobbyShowcasePulse = 1.0;
    if (this.phase === 'title') {
      this.lobbyHeroTargetYaw = weapon === 'kalbhairav' || weapon === 'trishul' ? -0.45 : 0.32;
    }
    this.audio.unlock();
    this.audio.playReload();
    this.emitHud();
  }

  public toggleScope(): void {
    if (this.phase !== 'playing' || this.busMode !== 'none') return;
    if (this.weaponType !== 'trishul') return;
    this.scopeActive = !this.scopeActive;
    if (this.scopeActive) {
      this.isHealing = false;
    }
    this.emitHud();
  }

  public useSanjibani(): void {
    if (this.phase !== 'playing' || this.busMode !== 'none' || this.heroJumpingFromBus) return;
    if (this.isHealing) return;
    if (this.sanjibaniCount <= 0) {
      this.pickupToast = 'সঞ্জীবনী গাছ নেই!';
      this.pickupToastTimer = 1.4;
      this.emitHud();
      return;
    }
    if (this.health >= this.maxHealth) {
      this.pickupToast = 'স্বাস্থ্য ইতিমধ্যেই পূর্ণ!';
      this.pickupToastTimer = 1.4;
      this.emitHud();
      return;
    }
    this.audio.unlock();
    this.isHealing = true;
    this.healTimer = this.healDuration;
    this.scopeActive = false;
    this.isReloading = false;
    this.pickupToast = 'সঞ্জীবনী গাছ ব্যবহার হচ্ছে...';
    this.pickupToastTimer = 1.5;
    this.emitHud();
  }

  public throwGrenade(): void {
    if (this.phase !== 'playing' || this.busMode !== 'none' || this.heroJumpingFromBus) return;
    if (this.grenadeCount <= 0) {
      this.pickupToast = 'বজ্র গোলা নেই!';
      this.pickupToastTimer = 1.4;
      this.emitHud();
      return;
    }

    this.audio.unlock();
    this.audio.playGrenadeThrow();
    this.grenadeCount--;
    this.isHealing = false;
    this.scopeActive = false;

    const mesh = buildBajraGolaMesh();
    const startPos = new THREE.Vector3(this.heroPos.x, 1.55, this.heroPos.z);
    const camForward = _v1.set(0, 0, -1).applyQuaternion(this.camera.quaternion).normalize();
    startPos.addScaledVector(camForward, 0.75);
    mesh.position.copy(startPos);
    this.scene.add(mesh);

    // Smooth parabolic lob trajectory
    const vel = camForward.clone().multiplyScalar(15.5);
    vel.y = Math.max(5.8, vel.y + 5.6);

    this.grenades.push({
      id: this.nextGrenadeId++,
      mesh,
      pos: startPos,
      vel,
      fuseTimer: 3.0,
    });

    this.pickupToast = 'বজ্র গোলা নিক্ষেপ!';
    this.pickupToastTimer = 1.4;
    this.emitHud();
  }

  public openNearestChest(): void {
    if (this.phase !== 'playing' || this.busMode !== 'none' || this.heroJumpingFromBus) return;
    const chest = this.nearestChest;
    if (!chest || chest.opened) return;
    if (chest.pos.distanceTo(this.heroPos) > 3.6) return;

    chest.opened = true;
    this.nearChest = false;
    this.nearestChest = null;
    this.audio.unlock();
    this.audio.playChestOpen();

    // Golden treasure spark burst
    this.spawnParticles(_v1.set(chest.pos.x, 0.75, chest.pos.z), 0xffd24a, 16, 5.2);

    // Rich Battle Royale loot bundle: Ammo + Raksha Kabach + Sanjibani + Bajra Gola + Weapon Supply
    const rewards: string[] = [];

    // 1. Raksha Kabach (50-pt blue Shield Bar)
    if (this.armor < this.maxArmor) {
      this.armor = this.maxArmor;
      this.hero.armorVestOverlay.visible = true;
      rewards.push('রক্ষা কবচ +৫০');
    }

    // 2. Sanjibani Healing Plant (up to 5)
    if (this.sanjibaniCount < this.maxSanjibani) {
      this.sanjibaniCount = Math.min(this.maxSanjibani, this.sanjibaniCount + 1);
      this.sanjibaniCollected++;
      rewards.push('সঞ্জীবনী +১');
    }

    // 3. Bajra Gola Grenade (up to 3)
    if (this.grenadeCount < this.maxGrenades) {
      this.grenadeCount = Math.min(this.maxGrenades, this.grenadeCount + 1);
      rewards.push('বজ্র গোলা +১');
    }

    // 4. Weapon & Ammo top-up (random spotlight weapon + active firearm refill)
    const featuredList: WeaponType[] = ['agni47', 'kalbhairav', 'trishul'];
    const featured = featuredList[chest.id % featuredList.length];
    const featMeta = WEAPON_CATALOG[featured];
    const featSlot = this.weaponSlots[featured];
    const addAmt = featured === 'trishul' ? 6 : featured === 'kalbhairav' ? 8 : 24;
    featSlot.reserve = Math.min(featMeta.maxReserve, featSlot.reserve + addAmt);
    rewards.push(`${featMeta.shortName} গুলি +${toBengaliNumber(addAmt)}`);

    // Also top up active weapon reserve if different
    if (this.weaponType !== 'fala' && this.weaponType !== featured) {
      const aMeta = WEAPON_CATALOG[this.weaponType];
      const aSlot = this.weaponSlots[this.weaponType];
      aSlot.reserve = Math.min(aMeta.maxReserve, aSlot.reserve + aMeta.magSize);
    }

    this.score += 40;
    this.checkHighScore();
    this.pickupToast = `সিন্দুক: ${rewards.slice(0, 3).join(' · ')}`;
    this.pickupToastTimer = 2.6;
    this.emitHud();
  }

  public startGame(): void {
    this.audio.unlock();
    this.clearDynamicEntities();

    const comingFromLobby = this.phase === 'title';

    this.phase = 'playing';
    this.busMode = 'riding_intro';
    this.busAutoDriving = true;
    this.busRouteT = 0.03;
    this.busSpeed = 12;
    this.busSteerAngle = 0;
    this.busInteriorCam = true;
    this.busExitSlowing = false;
    this.busExitSlowTimer = 0;
    this.busDoorOpenAmount = 0;
    this.busDoorAutoHoldTimer = 0;
    this.busInteriorLookYaw = 0;
    this.bus.interior.setDoorOpenAmount(0);
    this.bus.interior.introDriverGroup.visible = true;
    this.nearBus = false;
    this.nearChest = false;
    this.nearestChest = null;
    this.heroJumpingFromBus = false;
    this.heroJumpProgress = 0;

    this.camYaw = Math.PI * 0.5;
    this.camPitch = 0.24;
    this.scopeActive = false;
    this.currentFov = 56;
    this.camera.fov = 56;
    this.camera.updateProjectionMatrix();
    this.meleeSlashTimer = 0;

    this.health = this.maxHealth;
    this.armor = 0;
    this.hero.armorVestOverlay.visible = false;
    this.sanjibaniCount = 1;
    this.sanjibaniCollected = 0;
    this.isHealing = false;
    this.healTimer = 0;
    this.grenadeCount = 1;
    this.headshots = 0;
    this.bodyshots = 0;
    this.hitMarkerHeadshot = false;

    // Reset all 4 weapon slots cleanly from WEAPON_CATALOG
    for (const wId of WEAPON_SLOT_ORDER) {
      const m = WEAPON_CATALOG[wId];
      this.weaponSlots[wId] = {
        ammo: m.magSize,
        maxAmmo: m.magSize,
        reserve: m.startReserve,
      };
    }
    this.setWeaponType(this.weaponType);

    this.isReloading = false;
    this.reloadTimer = 0;
    this.fireCooldown = 0;
    this.sprintStamina = 1;
    this.score = 0;
    this.kills = 0;
    this.wave = 1;
    this.damageFlash = 0;
    this.hitMarker = 0;
    this.camShake = 0;
    this.pickupToast = null;
    this.lobbyDragActive = false;
    this.lobbyDragPointerId = null;

    // Reset Kalboishakhi Shrinking Safe Zone (full-map 400u start, 4 stages every 90 seconds)
    this.stormCenter.set((Math.random() - 0.5) * 8, 4 + (Math.random() - 0.5) * 8);
    this.stormPhase = 1;
    this.stormRadius = this.initialStormRadius;
    this.stormStartRadius = this.initialStormRadius;
    this.stormTargetRadius = this.initialStormRadius;
    this.stormCountdown = this.stormPhaseInterval;
    this.stormShrinking = false;
    this.stormShrinkElapsed = 0;
    this.outsideStorm = false;
    this.outsideStormElapsed = 0;
    this.stormDrainTimer = 0;
    this.stormTeleportFlash = 0;
    this.stormRig.root.visible = true;
    this.stormRig.root.position.set(this.stormCenter.x, 0, this.stormCenter.y);
    this.stormRig.wallMesh.scale.set(this.stormRadius, 1, this.stormRadius);
    this.stormRig.groundRing.scale.set(this.stormRadius, this.stormRadius, 1);

    this.hero.bodyGroup.scale.set(1, 1, 1);

    // Spawn Warrior Loot Chests ('যোদ্ধা সিন্দুক') near village mud houses & along the riverbank
    this.spawnInitialWorldLoot();

    // Position the WBTC bus at the west end of the Howrah-style bridge
    this.positionBusOnIntroRoute(this.busRouteT);

    // Seat hero inside the hollow WBTC bus cabin facing forward down the aisle
    this.bus.root.updateMatrixWorld(true);
    this.bus.heroIntroSeat.getWorldPosition(this.heroPos);
    this.hero.root.position.copy(this.heroPos);
    this.heroYaw = this.busYaw;
    this.hero.root.rotation.set(0, this.heroYaw, 0);
    this.hero.leftLeg.rotation.x = -1.16;
    this.hero.rightLeg.rotation.x = -1.16;
    this.hero.leftKnee.rotation.x = 1.16;
    this.hero.rightKnee.rotation.x = 1.16;

    // Load Wave 1 AI enemies onto the WBTC bus so they ride across the bridge & exit cleanly along the village road
    this.waveEnemiesToSpawn = [];
    const dropTs = [0.64, 0.70, 0.76, 0.82, 0.88, 0.94];
    const introTypes: EnemyArchetype[] = ['scout', 'scout', 'rusher', 'scout', 'rusher', 'scout'];
    for (let i = 0; i < introTypes.length; i++) {
      this.spawnEnemyOnBus(introTypes[i], i, dropTs[i]);
    }

    this.waveBanner = 'WBTC বাস — হাওড়া সেতু পারাপার';
    this.waveBannerTimer = 3.0;
    this.audio.playBusHorn();

    if (comingFromLobby) {
      // Smoothly sweep camera from the lobby hero right onto the moving WBTC bus!
      this.introStartCamPos.copy(this.camera.position);
      this.introStartLookAt.set(0.15, 1.25, -4.0);
      this.introTransitionProgress = 0;
    } else {
      this.introTransitionProgress = 1;
    }

    this.emitHud();
  }

  public toggleBusCameraView(): void {
    if (this.phase !== 'playing' || this.busMode !== 'riding_intro') return;
    this.busInteriorCam = !this.busInteriorCam;
    this.busInteriorLookYaw = 0;
    this.emitHud();
  }

  public exitBus(): void {
    if (this.phase !== 'playing') return;
    if (this.busMode === 'none') return;

    this.audio.unlock();
    this.bus.root.updateMatrixWorld(true);

    if (this.busMode === 'riding_intro') {
      // Realistic direct ground exit: briefly slow the WBTC bus, hiss air-brakes, swing side door open,
      // then hop straight onto the Howrah Bridge or road surface (no parachute!)
      if (this.busExitSlowing) return;
      this.busExitSlowing = true;
      this.busExitSlowTimer = this.busExitSlowDuration;
      this.audio.playBusDoorBrake();
      this.pickupToast = 'বাস থামছে... দরজা খুলছে';
      this.pickupToastTimer = 1.1;
      this.emitHud();
      return;
    }

    if (this.busMode === 'driving') {
      // Quick grounded hop-out beside the bus onto guaranteed clear road/bridge surface
      this.audio.playBusDoorBrake();
      this.audio.playBusJump();
      this.busDoorAutoHoldTimer = 1.1;
      this.bus.interior.heroDoorwayAnchor.getWorldPosition(this.heroJumpStart);
      this.findSafeBusExitPosition(this.heroJumpEnd, 0.62, 1, 0, false);

      this.heroJumpPeakY = Math.max(this.heroJumpStart.y, this.heroJumpEnd.y) + 0.36;
      this.heroJumpDuration = 0.24;
      this.heroJumpProgress = 0;
      this.heroJumpingFromBus = true;

      this.heroYaw = this.busYaw - Math.PI * 0.5;
      this.hero.root.rotation.set(0, this.heroYaw, 0);
      this.camYaw = this.busYaw;
      this.busMode = 'none';
      this.pickupToast = 'বাস থেকে নেমেছেন';
      this.pickupToastTimer = 1.6;
      this.emitHud();
    }
  }

  private executeDirectGroundExit(): void {
    if (this.busMode !== 'riding_intro') return;

    this.busExitSlowing = false;
    this.busExitSlowTimer = 0;
    this.busDoorAutoHoldTimer = 1.25;
    this.audio.playBusJump();
    this.bus.root.updateMatrixWorld(true);

    // Launch hero directly from the open side passenger doorway onto the bridge deck or village road (zero parachute!)
    this.bus.interior.heroDoorwayAnchor.getWorldPosition(this.heroJumpStart);
    this.findSafeBusExitPosition(this.heroJumpEnd, 0.62, 1, 0, true);

    const dropDiff = Math.abs(this.heroJumpStart.y - this.heroJumpEnd.y);
    this.heroJumpPeakY = Math.max(this.heroJumpStart.y, this.heroJumpEnd.y) + 0.42;
    this.heroJumpDuration = dropDiff > 1.8 ? 0.38 : 0.25;
    this.heroJumpProgress = 0;
    this.heroJumpingFromBus = true;

    this.heroYaw = this.busYaw;
    this.hero.root.rotation.set(0, this.heroYaw, 0);
    this.busMode = 'none';
    this.camYaw = this.busYaw;
    this.camPitch = 0.2;
    this.pickupToast = 'বাস থেকে নেমেছেন — লড়াই শুরু!';
    this.pickupToastTimer = 2.0;
    this.emitHud();
  }

  public enterBus(): void {
    if (this.phase !== 'playing' || this.busMode !== 'none' || this.heroJumpingFromBus) return;
    if (this.busAutoDriving) return;
    const dist = this.heroPos.distanceTo(this.busPos);
    if (dist > 6.2) return;

    this.audio.unlock();
    this.audio.playBusHorn();
    this.busMode = 'driving';
    this.busDoorAutoHoldTimer = 0.65;
    this.bus.interior.introDriverGroup.visible = false;
    this.nearBus = false;
    this.nearChest = false;
    this.isReloading = false;
    this.isHealing = false;
    this.scopeActive = false;
    this.mouseShootHeld = false;
    this.virtualInput.shooting = false;
    this.pickupToast = 'WBTC বাস চালাচ্ছেন!';
    this.pickupToastTimer = 2.0;
    this.emitHud();
  }

  public honkBusHorn(): void {
    if (this.phase !== 'playing' || this.busMode === 'none') return;
    this.audio.unlock();
    this.audio.playBusHorn();
  }

  public togglePause(): void {
    if (this.phase === 'playing') {
      this.phase = 'paused';
      this.keysHeld.clear();
      this.mouseShootHeld = false;
      this.virtualInput.shooting = false;
      if (document.pointerLockElement === this.renderer.domElement) {
        document.exitPointerLock();
      }
      this.emitHud();
    } else if (this.phase === 'paused') {
      this.phase = 'playing';
      this.lastFrameMs = performance.now();
      this.emitHud();
    }
  }

  public returnToTitle(): void {
    this.clearDynamicEntities();
    this.phase = 'title';
    this.busMode = 'none';
    this.busAutoDriving = false;
    this.busInteriorCam = true;
    this.busExitSlowing = false;
    this.busExitSlowTimer = 0;
    this.busDoorOpenAmount = 0;
    this.busDoorAutoHoldTimer = 0;
    this.busInteriorLookYaw = 0;
    this.bus.interior.setDoorOpenAmount(0);
    this.bus.interior.introDriverGroup.visible = true;
    this.heroJumpingFromBus = false;
    this.nearBus = false;
    this.nearChest = false;
    this.nearestChest = null;
    this.scopeActive = false;
    this.isHealing = false;
    this.armor = 0;
    this.hero.armorVestOverlay.visible = false;
    this.stormRig.root.visible = false;
    this.outsideStorm = false;
    this.outsideStormElapsed = 0;
    this.stormDrainTimer = 0;
    this.stormTeleportFlash = 0;
    this.currentFov = 56;
    this.camera.fov = 56;
    this.camera.updateProjectionMatrix();
    this.heroPos.set(0, 0, 7.2);
    this.lobbyHeroYaw = 0.28;
    this.lobbyHeroTargetYaw = 0.28;
    this.heroYaw = 0.28;
    this.hero.root.position.copy(this.heroPos);
    this.hero.root.rotation.set(0, this.lobbyHeroYaw, 0);
    this.hero.leftLeg.rotation.x = 0;
    this.hero.rightLeg.rotation.x = 0;
    this.hero.leftKnee.rotation.x = 0;
    this.hero.rightKnee.rotation.x = 0;
    this.hero.headGroup.rotation.set(0, 0, 0);
    this.hero.bodyGroup.position.y = 0;
    this.prevHeroPos.copy(this.heroPos);
    this.prevHeroYaw = this.lobbyHeroYaw;
    this.introTransitionProgress = 1;
    if (document.pointerLockElement === this.renderer.domElement) {
      document.exitPointerLock();
    }
    this.emitHud();
  }

  public toggleMute(): void {
    this.audio.unlock();
    this.audio.toggleMute();
    this.emitHud();
  }

  public setVirtualMove(x: number, y: number): void {
    this.virtualInput.moveX = THREE.MathUtils.clamp(x, -1, 1);
    this.virtualInput.moveY = THREE.MathUtils.clamp(y, -1, 1);
  }

  public setVirtualShoot(active: boolean): void {
    if (active) this.audio.unlock();
    this.virtualInput.shooting = active;
  }

  public setVirtualSprint(active: boolean): void {
    this.virtualInput.sprinting = active;
  }

  public triggerReload(): void {
    this.audio.unlock();
    this.virtualInput.reloadJustPressed = true;
  }

  // --- Wave & Entity Management ---

  private clearDynamicEntities(): void {
    for (const e of this.enemies) {
      this.scene.remove(e.rig.root);
    }
    this.enemies = [];
    for (const p of this.pickups) {
      this.scene.remove(p.mesh);
    }
    this.pickups = [];
    for (const c of this.chests) {
      this.scene.remove(c.rig.root);
    }
    this.chests = [];
    this.nearChest = false;
    this.nearestChest = null;
    for (const g of this.grenades) {
      this.scene.remove(g.mesh);
    }
    this.grenades = [];
    for (const fd of this.floatingDamages) {
      this.scene.remove(fd.sprite);
      fd.texture.dispose();
      fd.material.dispose();
    }
    this.floatingDamages = [];
    for (const sw of this.shockwaves) {
      this.scene.remove(sw.mesh);
      sw.mesh.geometry.dispose();
      (sw.mesh.material as THREE.Material).dispose();
    }
    this.shockwaves = [];
    for (const b of this.bullets) {
      b.active = false;
      b.mesh.visible = false;
    }
    for (const pt of this.particles) {
      pt.active = false;
      pt.mesh.visible = false;
    }
  }

  private spawnInitialWorldLoot(): void {
    // 1. Warrior Loot Chests ('যোদ্ধা সিন্দুক') beside village mud house verandas & along Hooghly riverbank
    const chestSpots: Array<[number, number, number]> = [
      // Village house porch / veranda spots (outside house circle collider so player walks right up)
      [-12.2, -1.6, 0.35],
      [-13.4, 15.8, 1.25],
      [13.0, 14.5, -1.35],
      [-6.8, 21.8, 0.15],
      [10.2, 21.2, -0.25],
      // Hooghly Riverbank ghat chests
      [-7.8, -14.2, 0.0],
      [8.6, -14.0, 0.0],
    ];
    for (const [cx, cz, rotY] of chestSpots) {
      this.spawnWarriorChest(cx, cz, rotY);
    }

    // Landmark Warrior Loot Chests (Sal Forest, Zamindar Bari downstairs & 2nd-floor terrace, Tram Depot, Extended Ghat)
    for (const anchor of this.world.landmarkChestAnchors) {
      this.spawnWarriorChest(anchor.x, anchor.z, anchor.rotY, anchor.y);
    }

    // 2. Glowing emerald Sanjibani medicinal herb plants ('সঞ্জীবনী গাছ') across grassy village terrain
    const plantSpots: Array<[number, number]> = [
      [-10.5, -10.0],
      [11.8, -9.8],
      [-9.5, 9.8],
      [10.2, 8.8],
      [-1.8, 18.2],
      [-22.5, 4.5],
      [22.5, 4.2],
      [3.5, -12.5],
    ];
    for (const [px, pz] of plantSpots) {
      this.spawnPickup(px, pz, 'sanjibani', true);
    }

    // Extra Sanjibani medicinal herbs across Sal Forest hills, Zamindar Bari garden, Tram Depot & Riverbank Ghat
    for (const herb of this.world.landmarkSanjibaniAnchors) {
      this.spawnPickup(herb.x, herb.z, 'sanjibani', true);
    }

    // 3. Initial Raksha Kabach armor pickups near Village Taxi, Zamindar Bari courtyard & Tram Depot
    this.spawnPickup(3.2, -6.5, 'armor', true);
    this.spawnPickup(98.0, 25.5, 'armor', true);
    this.spawnPickup(0.0, -110.0, 'armor', true);
  }

  private spawnWarriorChest(x: number, z: number, rotY = 0, forcedY?: number): void {
    const pos = new THREE.Vector3(x, forcedY ?? 0, z);
    if (forcedY === undefined) {
      this.resolveCircleWorldCollision(pos, 0.72, false);
      pos.y = this.world.getGroundHeight(pos.x, pos.z);
    } else {
      pos.y = forcedY;
    }

    const rig = buildWarriorChest();
    rig.root.position.copy(pos);
    rig.root.rotation.y = rotY;
    this.scene.add(rig.root);

    this.chests.push({
      id: this.nextChestId++,
      rig,
      pos,
      opened: false,
      openProgress: 0,
      life: 600,
    });
  }

  private spawnFloatingDamage(worldPos: THREE.Vector3, amount: number, isHeadshot: boolean): void {
    const label = `-${toBengaliNumber(amount)}`;
    const { sprite, texture, material } = createFloatingDamageSprite(label, isHeadshot);
    const pos = worldPos.clone();
    pos.x += (Math.random() - 0.5) * 0.32;
    pos.y += isHeadshot ? 0.35 : 0.2;
    pos.z += (Math.random() - 0.5) * 0.32;
    sprite.position.copy(pos);
    this.scene.add(sprite);

    this.floatingDamages.push({
      sprite,
      texture,
      material,
      pos,
      velY: isHeadshot ? 1.85 : 1.35,
      life: isHeadshot ? 1.05 : 0.85,
      maxLife: isHeadshot ? 1.05 : 0.85,
      baseScaleX: sprite.scale.x,
      baseScaleY: sprite.scale.y,
    });
  }

  private beginWave(waveNum: number): void {
    this.wave = waveNum;
    const totalCount = 4 + waveNum * 2;
    const queue: EnemyArchetype[] = [];

    for (let i = 0; i < totalCount; i++) {
      const r = Math.random();
      if (waveNum >= 3 && r < 0.25) {
        queue.push('heavy');
      } else if (waveNum >= 2 && r < 0.52) {
        queue.push('rusher');
      } else {
        queue.push('scout');
      }
    }

    this.waveEnemiesToSpawn = queue;
    this.waveSpawnTimer = 0.6;
    this.waveBanner = `তরঙ্গ ${toBengaliNumber(waveNum)}`;
    this.waveBannerTimer = 2.6;
    this.audio.playWaveStart();

    // Refresh helpful Battle Royale loot near the village square at start of waves >= 2
    if (waveNum >= 2) {
      const anchor = this.world.pickupAnchors[waveNum % this.world.pickupAnchors.length];
      this.spawnWarriorChest(anchor.x, anchor.z, Math.random() * Math.PI * 2);
      const plantAnchor = this.world.pickupAnchors[(waveNum + 2) % this.world.pickupAnchors.length];
      this.spawnPickup(plantAnchor.x, plantAnchor.z, 'sanjibani');
    }
  }

  private spawnEnemy(archetype: EnemyArchetype): void {
    // Pick spawn point furthest from hero for fair telegraphing
    let bestPt = this.world.enemySpawnPoints[0];
    let bestDistSq = -1;
    const tries = 4;
    for (let t = 0; t < tries; t++) {
      const pt =
        this.world.enemySpawnPoints[
          Math.floor(Math.random() * this.world.enemySpawnPoints.length)
        ];
      const dSq = pt.distanceToSquared(this.heroPos);
      if (dSq > bestDistSq) {
        bestDistSq = dSq;
        bestPt = pt;
      }
    }

    const rig = buildEnemyBot(archetype, this.textures);
    const sx = bestPt.x + (Math.random() - 0.5) * 2.5;
    const sz = bestPt.z + (Math.random() - 0.5) * 2.5;
    const sy = this.world.getGroundHeight(sx, sz);
    rig.root.position.set(sx, sy, sz);
    this.scene.add(rig.root);

    const waveHpScale = 1 + (this.wave - 1) * 0.12;
    const maxHp =
      archetype === 'heavy'
        ? Math.round(140 * waveHpScale)
        : archetype === 'rusher'
          ? Math.round(60 * waveHpScale)
          : Math.round(82 * waveHpScale);

    const speed =
      archetype === 'heavy'
        ? 3.1
        : archetype === 'rusher'
          ? 6.1
          : 4.35;

    this.enemies.push({
      id: this.nextEnemyId++,
      archetype,
      rig,
      hp: maxHp,
      maxHp,
      speed,
      radius: archetype === 'heavy' ? 0.72 : 0.55,
      fireRange: archetype === 'rusher' ? 14 : 26,
      fireCooldown: 1.0 + Math.random() * 1.0,
      telegraphTimer: 0,
      strafeDir: Math.random() > 0.5 ? 1 : -1,
      strafeTimer: 1.4 + Math.random() * 1.8,
      walkPhase: Math.random() * Math.PI * 2,
      hitFlashTimer: 0,
      dying: false,
      deathTimer: 0,
      knockback: new THREE.Vector3(),
      busSeatIndex: -1,
      busDropT: -1,
      jumpingFromBus: false,
      jumpProgress: 1,
      jumpDuration: 0.45,
      jumpStart: new THREE.Vector3(),
      jumpEnd: new THREE.Vector3(),
      jumpPeakY: 1.8,
      postLandingSafeTimer: 0.6,
    });
  }

  private spawnEnemyOnBus(archetype: EnemyArchetype, seatIndex: number, dropT: number): void {
    const rig = buildEnemyBot(archetype, this.textures);
    this.scene.add(rig.root);

    const maxHp = archetype === 'rusher' ? 60 : 82;
    const speed = archetype === 'rusher' ? 5.9 : 4.25;

    this.enemies.push({
      id: this.nextEnemyId++,
      archetype,
      rig,
      hp: maxHp,
      maxHp,
      speed,
      radius: 0.55,
      fireRange: archetype === 'rusher' ? 14 : 26,
      fireCooldown: 1.1 + Math.random() * 0.8,
      telegraphTimer: 0,
      strafeDir: Math.random() > 0.5 ? 1 : -1,
      strafeTimer: 1.4 + Math.random() * 1.6,
      walkPhase: Math.random() * Math.PI * 2,
      hitFlashTimer: 0,
      dying: false,
      deathTimer: 0,
      knockback: new THREE.Vector3(),
      busSeatIndex: seatIndex % this.bus.enemySeats.length,
      busDropT: dropT,
      jumpingFromBus: false,
      jumpProgress: 0,
      jumpDuration: 0.52,
      jumpStart: new THREE.Vector3(),
      jumpEnd: new THREE.Vector3(),
      jumpPeakY: 2.0,
      postLandingSafeTimer: 2.0,
    });
  }

  private positionBusOnIntroRoute(t: number): void {
    const clampedT = THREE.MathUtils.clamp(t, 0, 1);
    this.busRoute.curve.getPointAt(clampedT, this.busPos);
    const lookT = Math.min(1, clampedT + 0.012);
    this.busRoute.curve.getPointAt(lookT, _v1);

    if (clampedT >= 0.995) {
      // Keep final west-facing heading at village bus stop
      _v1.set(this.busPos.x - 1, this.busPos.y, this.busPos.z);
    }

    this.bus.root.position.copy(this.busPos);
    this.bus.root.lookAt(_v1);
    this.busYaw = Math.atan2(_v1.x - this.busPos.x, _v1.z - this.busPos.z);

    if (clampedT < 0.35) {
      this.busZoneLabel = 'হাওড়া সেতু';
    } else if (clampedT < 0.62) {
      this.busZoneLabel = 'হুগলি ঘাট র‍্যাম্প';
    } else if (clampedT < 0.82) {
      this.busZoneLabel = 'হলুদ ট্যাক্সি চক';
    } else {
      this.busZoneLabel = 'মাটির গ্রাম সড়ক';
    }
  }

  private spawnPickup(x: number, z: number, kind: PickupKind, persistent = false): void {
    const mesh = buildPickupMesh(kind);
    const py = this.world.getGroundHeight(x, z);
    mesh.position.set(x, py, z);
    this.scene.add(mesh);
    this.pickups.push({
      id: this.nextPickupId++,
      kind,
      mesh,
      pos: new THREE.Vector3(x, py, z),
      life: persistent ? 600 : 32,
    });
  }

  private spawnParticles(pos: THREE.Vector3, colorHex: number, count: number, speed = 5.5): void {
    let spawned = 0;
    for (const p of this.particles) {
      if (p.active) continue;
      p.active = true;
      p.pos.copy(pos);
      p.vel.set(
        (Math.random() - 0.5) * speed * 2,
        1.5 + Math.random() * speed,
        (Math.random() - 0.5) * speed * 2,
      );
      p.maxLife = 0.24 + Math.random() * 0.26;
      p.life = p.maxLife;
      p.scale = 0.7 + Math.random() * 0.9;
      (p.mesh.material as THREE.MeshBasicMaterial).color.setHex(colorHex);
      p.mesh.position.copy(p.pos);
      p.mesh.scale.setScalar(p.scale);
      p.mesh.visible = true;
      spawned++;
      if (spawned >= count) break;
    }
  }

  private spawnBullet(
    fromPlayer: boolean,
    origin: THREE.Vector3,
    direction: THREE.Vector3,
    speed: number,
    damage: number,
  ): void {
    for (const b of this.bullets) {
      if (b.active || b.fromPlayer !== fromPlayer) continue;
      b.active = true;
      b.pos.copy(origin);
      b.vel.copy(direction).normalize().multiplyScalar(speed);
      b.life = 1.65;
      b.damage = damage;
      b.mesh.position.copy(origin);
      _v1.copy(origin).add(b.vel);
      b.mesh.lookAt(_v1);
      b.mesh.visible = true;
      return;
    }
  }

  // --- Combat & Firing ---

  private getEnemyScale(e: ActiveEnemy): number {
    return e.archetype === 'heavy' ? 1.18 : e.archetype === 'rusher' ? 0.96 : 1.02;
  }

  private attemptStartReload(): void {
    const meta = WEAPON_CATALOG[this.weaponType];
    if (meta.isMelee) return;
    const slot = this.weaponSlots[this.weaponType];
    if (this.isReloading || slot.ammo >= slot.maxAmmo || slot.reserve <= 0) return;
    this.isReloading = true;
    this.reloadDuration = meta.reloadDuration;
    this.reloadTimer = this.reloadDuration;
    this.isHealing = false;
    this.scopeActive = false;
    this.audio.playReload();
  }

  private performMeleeSlash(): void {
    const meta = WEAPON_CATALOG.fala;
    this.fireCooldown = meta.fireCooldown;
    this.meleeSlashTimer = 0.24;
    this.heroRecoil = 0.6;
    this.isHealing = false;
    this.audio.playWeaponShot('fala');

    // Align hero forward with camera aim
    this.heroYaw = this.camYaw;
    this.hero.root.rotation.y = this.heroYaw;
    const fwdX = Math.sin(this.camYaw);
    const fwdZ = Math.cos(this.camYaw);
    const heroChest = _v5.set(this.heroPos.x, 1.32, this.heroPos.z);

    // Check grounded enemies within fast melee slash arc (3.3m reach, wide front cone)
    for (const e of this.enemies) {
      if (e.dying || e.busSeatIndex >= 0 || e.jumpingFromBus) continue;
      const dx = e.rig.root.position.x - this.heroPos.x;
      const dz = e.rig.root.position.z - this.heroPos.z;
      const dist = Math.hypot(dx, dz);
      if (dist > 3.35) continue;
      const dot = (dx * fwdX + dz * fwdZ) / Math.max(0.001, dist);
      if (dot < 0.28) continue;

      const s = this.getEnemyScale(e);
      const targetPt = _v3.set(e.rig.root.position.x, 1.35 * s, e.rig.root.position.z);
      if (!this.hasLineOfSight(heroChest, targetPt)) continue;

      // High-aim slash (camPitch < 0.14) lands a lethal critical headshot slash!
      const isHead = this.camPitch < 0.12;
      const hitPos = _v6.set(
        e.rig.root.position.x,
        isHead ? 1.78 * s : 1.25 * s,
        e.rig.root.position.z,
      );
      _v4.set(fwdX, 0, fwdZ);
      this.damageEnemy(e, meta.baseDamage, _v4, isHead, hitPos);
      this.camShake = Math.min(0.28, this.camShake + 0.08);
    }
  }

  private firePlayerWeapon(): void {
    if (this.isReloading || this.fireCooldown > 0) return;
    const meta = WEAPON_CATALOG[this.weaponType];

    // Slot 4 — বাংলার ফলা (fast silent melee slash)
    if (meta.isMelee) {
      this.performMeleeSlash();
      return;
    }

    const slot = this.weaponSlots[this.weaponType];
    if (slot.ammo <= 0) {
      this.fireCooldown = 0.28;
      this.audio.playDryFire();
      if (slot.reserve > 0) this.attemptStartReload();
      return;
    }

    // Firing cancels healing cleanly
    this.isHealing = false;

    slot.ammo--;
    this.fireCooldown = meta.fireCooldown;
    this.heroRecoil =
      this.weaponType === 'trishul' ? 1.75 : this.weaponType === 'kalbhairav' ? 1.55 : 0.95;
    this.muzzleFlashTimer = this.weaponType === 'agni47' ? 0.05 : 0.085;
    this.camShake = Math.min(
      0.38,
      this.camShake +
        (this.weaponType === 'trishul'
          ? 0.2
          : this.weaponType === 'kalbhairav'
            ? 0.17
            : 0.075),
    );
    this.audio.playWeaponShot(this.weaponType);

    // Determine world aim direction from center camera ray
    const camForward = _v1.set(0, 0, -1).applyQuaternion(this.camera.quaternion).normalize();
    const maxAimDist = this.weaponType === 'trishul' ? 90 : 50;
    const aimTarget = _v2.copy(this.camera.position).addScaledVector(camForward, maxAimDist);
    const heroChest = _v5.set(this.heroPos.x, this.heroPos.y + 1.32, this.heroPos.z);

    // Respect solid obstacles along camera sightline first
    const obsT = this.segmentFirstObstacleT(this.camera.position, aimTarget, true);
    if (obsT < 1) {
      aimTarget.lerpVectors(this.camera.position, aimTarget, obsT);
    }

    // Precision aim-assist that preserves player's Head vs Body aim!
    // When scoped with Trishul Sniper, use tighter cone (0.992) so exact crosshair placement rules;
    // on hip-fire use forgiving cone (0.955) and choose Head if crosshair points closer to head than chest.
    const assistThreshold = this.scopeActive ? 0.992 : 0.955;
    let bestTargetPt: THREE.Vector3 | null = null;
    let bestDot = assistThreshold;

    for (const e of this.enemies) {
      if (e.dying || e.busSeatIndex >= 0 || e.jumpingFromBus) continue;
      const s = this.getEnemyScale(e);
      const ey = e.rig.root.position.y;

      // Evaluate both Head (1.74 * s) and Chest (1.16 * s) centers against camera sightline
      const headY = ey + 1.74 * s;
      const chestY = ey + 1.16 * s;

      for (const yAim of [headY, chestY]) {
        _v3.set(e.rig.root.position.x, yAim, e.rig.root.position.z);
        const toPt = _v4.subVectors(_v3, this.camera.position);
        const dist = toPt.length();
        if (dist > maxAimDist || dist < 1.0) continue;
        toPt.divideScalar(dist);
        const dot = toPt.dot(camForward);
        // Tiny preference for head when aimed cleanly at head height
        const scoreDot = yAim === headY ? dot + 0.0015 : dot;
        if (scoreDot > bestDot && this.hasLineOfSight(heroChest, _v3)) {
          bestDot = scoreDot;
          if (!bestTargetPt) bestTargetPt = new THREE.Vector3();
          bestTargetPt.copy(_v3);
        }
      }
    }

    if (bestTargetPt) {
      aimTarget.copy(bestTargetPt);
    }

    // Align hero facing cleanly with shot direction
    const dx = aimTarget.x - this.heroPos.x;
    const dz = aimTarget.z - this.heroPos.z;
    this.heroYaw = Math.atan2(dx, dz);
    this.hero.root.rotation.y = this.heroYaw;
    this.hero.root.updateMatrixWorld(true);

    // Fire from muzzle (or hero chest if hugging a wall so shots never spawn inside cover)
    const muzzleWorld = _v3;
    this.hero.muzzlePoint.getWorldPosition(muzzleWorld);
    if (this.segmentFirstObstacleT(heroChest, muzzleWorld, true) < 1) {
      muzzleWorld.copy(heroChest);
    }

    const effectiveSpread = this.scopeActive ? meta.spread * 0.25 : meta.spread;
    for (let p = 0; p < meta.pellets; p++) {
      const bulletDir = _v4.subVectors(aimTarget, muzzleWorld).normalize();
      if (effectiveSpread > 0) {
        bulletDir.x += (Math.random() - 0.5) * effectiveSpread;
        bulletDir.y += (Math.random() - 0.5) * effectiveSpread * 0.6;
        bulletDir.z += (Math.random() - 0.5) * effectiveSpread;
        bulletDir.normalize();
      }
      this.spawnBullet(true, muzzleWorld, bulletDir, meta.bulletSpeed, meta.baseDamage);
    }

    this.spawnParticles(
      muzzleWorld,
      this.weaponType === 'trishul' ? 0xfff0a8 : 0xffd166,
      this.weaponType === 'kalbhairav' ? 7 : 4,
      this.weaponType === 'kalbhairav' ? 3.8 : 2.8,
    );

    if (slot.ammo === 0 && slot.reserve > 0) {
      this.attemptStartReload();
    }
  }

  // --- Collision, Safe Bus Exit & Line-of-Sight Helpers ---

  private pushOutOfBusHull(pos: THREE.Vector3, actorRadius: number, forceCheck = false): void {
    if (!forceCheck && this.busPos.y >= 1.15) return;
    const fwdX = Math.sin(this.busYaw);
    const fwdZ = Math.cos(this.busYaw);
    // 3 overlapping circles covering full 8.4m x 2.6m WBTC bus hull with zero mid-body gap
    const offsets = [-2.65, 0.0, 2.65];
    const busCircleR = 1.48;
    for (let k = 0; k < offsets.length; k++) {
      const bx = this.busPos.x + fwdX * offsets[k];
      const bz = this.busPos.z + fwdZ * offsets[k];
      const dx = pos.x - bx;
      const dz = pos.z - bz;
      const minDist = actorRadius + busCircleR;
      const distSq = dx * dx + dz * dz;
      if (distSq < minDist * minDist) {
        if (distSq > 0.0001) {
          const dist = Math.sqrt(distSq);
          const push = minDist - dist;
          pos.x += (dx / dist) * push;
          pos.z += (dz / dist) * push;
        } else {
          // Exactly centered: push cleanly out to the right-side doorway
          pos.x += -fwdZ * minDist;
          pos.z += fwdX * minDist;
        }
      }
    }
  }

  private findSafeBusExitPosition(
    out: THREE.Vector3,
    actorRadius: number,
    preferSideSign = 1,
    alongOffset = 0,
    isIntroRoute = false,
  ): void {
    const fwdX = Math.sin(this.busYaw);
    const fwdZ = Math.cos(this.busYaw);
    // Local -X (right-side animated passenger doorway) in world XZ is (-fwdZ, fwdX)
    const doorRightX = -fwdZ;
    const doorRightZ = fwdX;
    const bounds = this.world.playableBounds;

    // 1. Direct Howrah Bridge Deck Exit (NO parachute — hop straight onto the bridge road surface beside the open door!)
    const onHowrahBridgeDeck =
      this.busPos.y > 4.2 &&
      Math.abs(this.busPos.z + 40) < 6.0 &&
      this.busPos.x >= -62 &&
      this.busPos.x <= 62;
    if (onHowrahBridgeDeck) {
      const bx = THREE.MathUtils.clamp(this.busPos.x + fwdX * (1.7 + alongOffset), -62, 62);
      const bz = THREE.MathUtils.clamp(
        this.busPos.z + doorRightZ * (preferSideSign * 2.48),
        -43.9,
        -36.1,
      );
      out.set(bx, 6.58, bz);
      return;
    }

    // 2. Eastern Viaduct Approach Ramp Exit: step safely onto solid East Ghat road (never into river water)
    if (isIntroRoute && this.busPos.y > 0.65) {
      const gx = THREE.MathUtils.clamp(this.busPos.x - 4.5 + alongOffset * 0.6, 22, 42);
      const gz = THREE.MathUtils.clamp(Math.max(this.busPos.z + 2.5, -17.0), -17.0, 18.0);
      out.set(gx, 0, gz);
      this.resolveCircleWorldCollision(out, actorRadius, false);
      out.y = this.world.getGroundHeight(out.x, out.z, 0);
      return;
    }

    // 3. Direct Road / Ground Exit right outside the open side passenger doorway
    const candidates: Array<[number, number]> = [
      [preferSideSign * 2.85, 1.9 + alongOffset],
      [preferSideSign * 3.85, 0.5 + alongOffset],
      [-preferSideSign * 2.95, 1.6 + alongOffset],
      [preferSideSign * 3.35, -2.1 + alongOffset],
      [0, -5.2],
    ];

    for (let c = 0; c < candidates.length; c++) {
      const [lat, fwd] = candidates[c];
      const cx = THREE.MathUtils.clamp(
        this.busPos.x + doorRightX * lat + fwdX * fwd,
        bounds.minX + 1.8,
        bounds.maxX - 1.8,
      );
      const cz = THREE.MathUtils.clamp(
        this.busPos.z + doorRightZ * lat + fwdZ * fwd,
        bounds.minZ + 1.5,
        bounds.maxZ - 1.8,
      );

      const refY = this.world.getGroundHeight(cx, cz, this.busPos.y);
      out.set(cx, refY, cz);
      this.resolveCircleWorldCollision(out, actorRadius, false);
      if (this.busPos.y < 1.35) {
        this.pushOutOfBusHull(out, actorRadius + 0.45, true);
        this.resolveCircleWorldCollision(out, actorRadius, false);
      }

      let clearOfBus = true;
      if (this.busPos.y < 1.35) {
        for (const off of [-2.65, 0.0, 2.65]) {
          const dx = out.x - (this.busPos.x + fwdX * off);
          const dz = out.z - (this.busPos.z + fwdZ * off);
          if (dx * dx + dz * dz < (actorRadius + 1.52) * (actorRadius + 1.52)) {
            clearOfBus = false;
            break;
          }
        }
      }
      if (clearOfBus) {
        out.y = this.world.getGroundHeight(out.x, out.z, this.busPos.y);
        return;
      }
    }

    // Final guaranteed push-out fallback
    if (this.busPos.y < 1.35) {
      this.pushOutOfBusHull(out, actorRadius + 0.7, true);
    }
    out.x = THREE.MathUtils.clamp(out.x, bounds.minX + 1.5, bounds.maxX - 1.5);
    out.z = THREE.MathUtils.clamp(out.z, bounds.minZ + 1.5, bounds.maxZ - 1.5);
    out.y = this.world.getGroundHeight(out.x, out.z, this.busPos.y);
  }

  private resolveCircleWorldCollision(
    pos: THREE.Vector3,
    actorRadius: number,
    includeBusHull = true,
  ): void {
    const bounds = this.world.playableBounds;
    pos.x = THREE.MathUtils.clamp(pos.x, bounds.minX, bounds.maxX);
    pos.z = THREE.MathUtils.clamp(pos.z, bounds.minZ, bounds.maxZ);

    // Hooghly River water barrier: allow crossing via the Howrah Bridge deck & North/South ramps,
    // while keeping actors safely on bridge guardrails or riverbanks everywhere else
    if (this.world.isWaterBlocked(pos.x, pos.z)) {
      if (pos.y > 1.2) {
        // Actor is elevated on bridge/ramps — clamp cleanly back inside the nearest guardrail lane
        if (pos.z <= -35.2 && pos.z >= -44.8) {
          pos.x = THREE.MathUtils.clamp(pos.x, -65.2, 65.2);
          pos.z = THREE.MathUtils.clamp(pos.z, -44.2, -35.8);
        } else if (pos.x < 0) {
          pos.x = THREE.MathUtils.clamp(pos.x, -20.9, -14.1);
        } else {
          pos.x = THREE.MathUtils.clamp(pos.x, 14.1, 20.9);
        }
      } else {
        // Ground-level riverbank edge: gently block wading into deep river water
        pos.z = pos.z > -45.5 ? -20.4 : -70.6;
      }
    }

    // When walking atop the 2nd-floor Zamindar Bari rooftop terrace (y >= 2.8),
    // skip ground-floor partition wall colliders underneath while staying inside the terrace roof
    const onZamindarTerrace =
      pos.y >= 2.8 && pos.x >= 80 && pos.x <= 116 && pos.z >= 7 && pos.z <= 37;

    const colliders: CircleCollider[] = this.world.circleColliders;
    for (let i = 0; i < colliders.length; i++) {
      const c = colliders[i];
      if (onZamindarTerrace && c.kind === 'ruin' && c.height <= 4.7) continue;
      const dx = pos.x - c.x;
      const dz = pos.z - c.z;
      const minDist = actorRadius + c.radius;
      const distSq = dx * dx + dz * dz;
      if (distSq < minDist * minDist && distSq > 0.00001) {
        const dist = Math.sqrt(distSq);
        const push = minDist - dist;
        pos.x += (dx / dist) * push;
        pos.z += (dz / dist) * push;
      }
    }

    // Solid 3-circle hull collision against the WBTC bus whenever it is on village ground
    if (includeBusHull && this.busPos.y < 1.15) {
      this.pushOutOfBusHull(pos, actorRadius, false);
    }

    pos.x = THREE.MathUtils.clamp(pos.x, bounds.minX, bounds.maxX);
    pos.z = THREE.MathUtils.clamp(pos.z, bounds.minZ, bounds.maxZ);
  }

  /**
   * Parametric XZ ray-segment vs vertical cylinder intersection.
   * Returns earliest t in [0, 1] where segment A->B enters circle (cx, cz, r) within [minY, maxY], or Infinity.
   */
  private segmentHitsCylinderT(
    a: THREE.Vector3,
    b: THREE.Vector3,
    cx: number,
    cz: number,
    radius: number,
    minY: number,
    maxY: number,
  ): number {
    const dx = b.x - a.x;
    const dz = b.z - a.z;
    const fx = a.x - cx;
    const fz = a.z - cz;
    const rSq = radius * radius;
    const aLenSq = dx * dx + dz * dz;

    if (aLenSq < 1e-8) {
      if (fx * fx + fz * fz <= rSq && a.y >= minY && a.y <= maxY) return 0;
      return Infinity;
    }

    const cVal = fx * fx + fz * fz - rSq;
    if (cVal <= 0) {
      if (a.y >= minY && a.y <= maxY) return 0;
    }

    const bVal = 2 * (fx * dx + fz * dz);
    const disc = bVal * bVal - 4 * aLenSq * cVal;
    if (disc < 0) return Infinity;

    const sqrtD = Math.sqrt(disc);
    const t1 = (-bVal - sqrtD) / (2 * aLenSq);
    if (t1 >= 0 && t1 <= 1) {
      const yAt = a.y + (b.y - a.y) * t1;
      if (yAt >= minY && yAt <= maxY) return t1;
    }

    const t2 = (-bVal + sqrtD) / (2 * aLenSq);
    if (t1 < 0 && t2 >= 0) {
      const yAt = a.y;
      if (yAt >= minY && yAt <= maxY) return 0;
    }
    return Infinity;
  }

  /**
   * Returns earliest t in [0, 1] where 3D segment A->B hits ground, mud houses, taxi, trees,
   * cover crates, riverbank parapet walls, or the solid WBTC bus hull; returns Infinity if clear.
   */
  private segmentFirstObstacleT(
    a: THREE.Vector3,
    b: THREE.Vector3,
    includeBus = true,
  ): number {
    let bestT = Infinity;

    // Terrain surface hit check (respects laterite hills & bridge ramps)
    const groundB = this.world.getGroundHeight(b.x, b.z) + 0.05;
    if (b.y <= groundB && a.y > groundB) {
      const tG = (groundB - a.y) / (b.y - a.y);
      if (tG >= 0 && tG <= 1 && tG < bestT) bestT = tG;
    } else if (b.y <= groundB && a.y <= groundB) {
      return 0;
    }

    // All world obstacles (mud houses, Zamindar Bari ruins, vintage trams, stalls, boulders, trees, taxis, crates)
    const colliders = this.world.circleColliders;
    for (let i = 0; i < colliders.length; i++) {
      const c = colliders[i];
      const baseY = c.kind === 'boulder' || c.kind === 'tree' ? this.world.getGroundHeight(c.x, c.z) : 0;
      const t = this.segmentHitsCylinderT(a, b, c.x, c.z, c.radius, baseY, baseY + c.height);
      if (t < bestT) bestT = t;
    }

    // Riverbank brick parapet walls (z = -17.6, height = 0.95)
    if ((a.z > -17.3 && b.z < -17.9) || (a.z < -17.9 && b.z > -17.3)) {
      const tW = (-17.6 - a.z) / (b.z - a.z);
      if (tW >= 0 && tW <= 1 && tW < bestT) {
        const wx = a.x + (b.x - a.x) * tW;
        const wy = a.y + (b.y - a.y) * tW;
        if (Math.abs(wx) > 10 && Math.abs(wx) < 46 && wy <= 0.95) {
          bestT = tW;
        }
      }
    }

    // Solid WBTC bus hull (3 circles along length, height = 3.4m)
    if (includeBus && this.busPos.y < 1.2) {
      const fwdX = Math.sin(this.busYaw);
      const fwdZ = Math.cos(this.busYaw);
      for (const off of [-2.65, 0.0, 2.65]) {
        const bx = this.busPos.x + fwdX * off;
        const bz = this.busPos.z + fwdZ * off;
        const tB = this.segmentHitsCylinderT(a, b, bx, bz, 1.48, 0, 3.45);
        if (tB < bestT) bestT = tB;
      }
    }

    return bestT;
  }

  private hasLineOfSight(from: THREE.Vector3, to: THREE.Vector3): boolean {
    return this.segmentFirstObstacleT(from, to, true) === Infinity;
  }

  // --- Simulation Update ---

  private update(dt: number): void {
    this.worldTime += dt;

    // Ambient world animation (water ripples, swaying coconut palms, bobbing country boat)
    this.world.waterUniforms.uTime.value = this.worldTime;
    this.world.waterBumpTexture.offset.x = (this.worldTime * 0.03) % 1;
    this.world.waterBumpTexture.offset.y = (this.worldTime * 0.015) % 1;

    for (const palm of this.world.swayingPalms) {
      palm.crown.rotation.z = Math.sin(this.worldTime * 1.35 + palm.phase) * 0.045;
      palm.crown.rotation.x = Math.cos(this.worldTime * 1.05 + palm.phase) * 0.035;
    }

    for (let i = 0; i < this.world.bobbingBoats.length; i++) {
      const boat = this.world.bobbingBoats[i];
      const phase = i * 0.95;
      boat.position.y = -1.18 + Math.sin(this.worldTime * 1.55 + phase) * 0.09;
      boat.rotation.z = Math.sin(this.worldTime * 1.25 + phase) * 0.045;
    }

    if (this.phase === 'title') {
      this.titleTime += dt;
      // Free Fire-style 3D Main Lobby: hero stands center-stage in front of West Bengal village,
      // Yellow Ambassador Taxi, coconut palms, Hooghly River, and Howrah-style bridge.
      this.hero.root.position.set(0, 0, 7.2);

      // Scenic background WBTC bus gliding slowly across the Howrah-style bridge in the lobby!
      const lobbyBusT = 0.02 + ((this.titleTime * 0.025) % 0.3);
      this.positionBusOnIntroRoute(lobbyBusT);
      for (const w of this.bus.wheels) {
        w.rotation.x += dt * 4.5;
      }

      // Exponentially damped turntable rotation from horizontal drag
      const prevYaw = this.lobbyHeroYaw;
      const yawDamp = 1 - Math.exp(-12 * dt);
      this.lobbyHeroYaw += (this.lobbyHeroTargetYaw - this.lobbyHeroYaw) * yawDamp;
      this.hero.root.rotation.y = this.lobbyHeroYaw;
      const lobbyYawRate = (this.lobbyHeroYaw - prevYaw) / Math.max(0.001, dt);

      // Subtle heroic breathing, natural head micro-motion & showcase pop on gamcha/weapon switch
      this.lobbyShowcasePulse = Math.max(0, this.lobbyShowcasePulse - dt * 3.5);
      const breath = Math.sin(this.titleTime * 2.2) * 0.016;
      const popScale = 1 + Math.sin(this.lobbyShowcasePulse * Math.PI) * 0.04;
      this.hero.bodyGroup.position.y = breath;
      this.hero.bodyGroup.scale.set(popScale, popScale, popScale);
      this.hero.headGroup.rotation.y = Math.sin(this.titleTime * 0.85) * 0.075;
      this.hero.headGroup.rotation.x = Math.sin(this.titleTime * 1.4) * 0.025;
      this.hero.leftLeg.rotation.x = 0;
      this.hero.rightLeg.rotation.x = 0;
      this.hero.leftKnee.rotation.x = 0;
      this.hero.rightKnee.rotation.x = 0;
      this.hero.recoilGroup.position.z = 0.27;
      this.hero.recoilGroup.rotation.x = Math.sin(this.titleTime * 1.6) * 0.022;

      // Real-time Verlet cloth simulation on the red-and-white gamcha (Hooghly river breeze + drag-spin whip!)
      this.hero.updateGamchaCloth(dt, this.worldTime, 0, 0, 0, lobbyYawRate, 0.28);

      // Keep shadow frustum locked cleanly on the lobby hero & village square
      this.sunLight.position.set(32, 56, -18);
      this.sunLight.target.position.set(0, 0, 4);

      // Heroic front-facing lobby camera with gentle atmospheric float
      const swayX = Math.sin(this.titleTime * 0.45) * 0.16;
      const swayY = Math.cos(this.titleTime * 0.65) * 0.045;
      this.camera.position.set(-0.2 + swayX, 1.5 + swayY, 11.1);
      this.camera.lookAt(0.14, 1.28, -4.0);
      return;
    }

    if (this.phase !== 'playing') {
      return;
    }

    // Brief hitstop on heavy kill impact for tactile weight
    if (this.hitstopTimer > 0) {
      this.hitstopTimer = Math.max(0, this.hitstopTimer - dt);
      return;
    }

    // Decay UI / feedback timers
    this.damageFlash = Math.max(0, this.damageFlash - dt * 2.4);
    this.hitMarker = Math.max(0, this.hitMarker - dt * 4.2);
    this.camShake = Math.max(0, this.camShake - dt * 1.6);
    if (this.waveBannerTimer > 0) {
      this.waveBannerTimer -= dt;
      if (this.waveBannerTimer <= 0) this.waveBanner = null;
    }
    if (this.pickupToastTimer > 0) {
      this.pickupToastTimer -= dt;
      if (this.pickupToastTimer <= 0) this.pickupToast = null;
    }

    // Camera keyboard orbit assist (Q/E) + touch drag look (slower precision speed when sniper scope is active)
    const lookMult = this.scopeActive ? 0.36 : 1.0;
    if (this.busMode === 'riding_intro' && this.busInteriorCam) {
      // Allow subtle left/right cabin window glancing over the Howrah Bridge & landmarks
      if (this.keysHeld.has('KeyQ')) this.busInteriorLookYaw += 1.6 * dt;
      if (this.keysHeld.has('KeyE')) this.busInteriorLookYaw -= 1.6 * dt;
      if (this.virtualInput.lookDeltaX !== 0 || this.virtualInput.lookDeltaY !== 0) {
        this.busInteriorLookYaw -= this.virtualInput.lookDeltaX * 0.0045;
        this.virtualInput.lookDeltaX = 0;
        this.virtualInput.lookDeltaY = 0;
      }
      this.busInteriorLookYaw = THREE.MathUtils.clamp(this.busInteriorLookYaw, -0.68, 0.68);
    } else {
      if (this.keysHeld.has('KeyQ')) this.camYaw += 2.2 * lookMult * dt;
      if (this.keysHeld.has('KeyE')) this.camYaw -= 2.2 * lookMult * dt;
      if (this.virtualInput.lookDeltaX !== 0 || this.virtualInput.lookDeltaY !== 0) {
        this.camYaw -= this.virtualInput.lookDeltaX * 0.0055 * lookMult;
        this.camPitch = THREE.MathUtils.clamp(
          this.camPitch + this.virtualInput.lookDeltaY * 0.0042 * lookMult,
          -0.18,
          0.65,
        );
        this.virtualInput.lookDeltaX = 0;
        this.virtualInput.lookDeltaY = 0;
      }
    }

    // Read unified movement / steering input (Keyboard WASD / Arrows + Virtual Touch Joystick)
    let moveRight = this.virtualInput.moveX;
    let moveForward = this.virtualInput.moveY;
    if (this.keysHeld.has('KeyD') || this.keysHeld.has('ArrowRight')) moveRight += 1;
    if (this.keysHeld.has('KeyA') || this.keysHeld.has('ArrowLeft')) moveRight -= 1;
    if (this.keysHeld.has('KeyW') || this.keysHeld.has('ArrowUp')) moveForward += 1;
    if (this.keysHeld.has('KeyS') || this.keysHeld.has('ArrowDown')) moveForward -= 1;

    const moveLen = Math.hypot(moveRight, moveForward);
    if (moveLen > 1) {
      moveRight /= moveLen;
      moveForward /= moveLen;
    }

    // --- 1. Update WBTC Passenger Bus (Auto Intro Route OR Player Driving OR Coasting Stop) ---
    if (this.busDoorAutoHoldTimer > 0) {
      this.busDoorAutoHoldTimer = Math.max(0, this.busDoorAutoHoldTimer - dt);
    }
    const targetDoorOpen = this.busExitSlowing || this.busDoorAutoHoldTimer > 0 ? 1 : 0;
    this.busDoorOpenAmount += (targetDoorOpen - this.busDoorOpenAmount) * (1 - Math.exp(-11 * dt));
    this.bus.interior.setDoorOpenAmount(this.busDoorOpenAmount);
    this.bus.interior.introDriverGroup.visible = this.busAutoDriving && this.busMode !== 'driving';

    if (this.busAutoDriving) {
      const prevPos = _v2.copy(this.busPos);
      // Smoothly decelerate as the bus approaches its final stop OR briefly brakes when player taps 'বাস থেকে নামুন'
      const endSlowDown =
        this.busRouteT > 0.88 ? THREE.MathUtils.lerp(1.0, 0.35, (this.busRouteT - 0.88) / 0.12) : 1.0;
      const exitBrakeMult = this.busExitSlowing
        ? THREE.MathUtils.lerp(0.14, 0.85, Math.max(0, this.busExitSlowTimer / this.busExitSlowDuration))
        : 1.0;
      this.busRouteT = Math.min(1.0, this.busRouteT + dt * 0.046 * endSlowDown * exitBrakeMult);
      this.positionBusOnIntroRoute(this.busRouteT);

      const movedDist = this.busPos.distanceTo(prevPos);
      this.busSpeed = movedDist / Math.max(0.001, dt);
      for (const w of this.bus.wheels) {
        w.rotation.x += movedDist / 0.54;
      }
      this.bus.chassisGroup.position.y = Math.sin(this.worldTime * 14) * (this.busExitSlowing ? 0.007 : 0.016);

      this.bus.root.updateMatrixWorld(true);

      // Update & auto-drop AI enemy passengers riding seated inside the bus cabin along the route
      for (const e of this.enemies) {
        if (e.dying || e.busSeatIndex < 0) continue;
        if (this.busRouteT >= e.busDropT) {
          this.dropEnemyFromBus(e);
        } else {
          this.bus.enemySeats[e.busSeatIndex].getWorldPosition(e.rig.root.position);
          e.rig.root.rotation.y = this.busYaw;
        }
      }

      // Complete braking + door-opening exit sequence once bus has slowed & side door swung open
      if (this.busExitSlowing && this.busMode === 'riding_intro') {
        this.busExitSlowTimer -= dt;
        if (this.busExitSlowTimer <= 0) {
          this.executeDirectGroundExit();
        }
      }

      // Auto-exit hero at the very end of the route if they stayed on until the last village stop
      if (this.busRouteT >= 0.999) {
        this.busAutoDriving = false;
        this.busSpeed = 0;
        this.bus.chassisGroup.position.y = 0;
        this.bus.root.rotation.set(0, this.busYaw, 0);
        // Drop any straggling bus enemies safely
        for (const e of this.enemies) {
          if (!e.dying && e.busSeatIndex >= 0) this.dropEnemyFromBus(e);
        }
        if (this.busMode === 'riding_intro') {
          this.executeDirectGroundExit();
        }
      }
    } else if (this.busMode === 'driving') {
      // Player-controlled WBTC bus driving around the West Bengal village!
      const accel = 14.5;
      const maxFwd = 15.0;
      const maxRev = -6.0;

      if (Math.abs(moveForward) > 0.05) {
        this.busSpeed += moveForward * accel * dt;
      } else {
        this.busSpeed *= Math.exp(-3.4 * dt);
        if (Math.abs(this.busSpeed) < 0.08) this.busSpeed = 0;
      }
      this.busSpeed = THREE.MathUtils.clamp(this.busSpeed, maxRev, maxFwd);

      const targetSteer = -moveRight * 0.48;
      this.busSteerAngle += (targetSteer - this.busSteerAngle) * (1 - Math.exp(-10 * dt));
      for (const pivot of this.bus.frontWheelPivots) {
        pivot.rotation.y = this.busSteerAngle;
      }

      if (Math.abs(this.busSpeed) > 0.25) {
        const turnSign = this.busSpeed >= 0 ? 1 : -1;
        const turnFactor = Math.min(1, Math.abs(this.busSpeed) / 6.0);
        this.busYaw += this.busSteerAngle * 2.15 * turnFactor * turnSign * dt;
      }

      const bFwdX = Math.sin(this.busYaw);
      const bFwdZ = Math.cos(this.busYaw);
      const prevX = this.busPos.x;
      const prevZ = this.busPos.z;

      this.busPos.x += bFwdX * this.busSpeed * dt;
      this.busPos.z += bFwdZ * this.busSpeed * dt;

      // Keep drivable bus cleanly inside the 1000x1000 map & slide off houses/trees/taxi/river edge
      this.resolveCircleWorldCollision(this.busPos, 1.85, false);
      const busGroundY = this.world.getGroundHeight(this.busPos.x, this.busPos.z, this.busPos.y);
      this.busPos.y += (busGroundY - this.busPos.y) * Math.min(1, dt * 16);

      const actualDist = Math.hypot(this.busPos.x - prevX, this.busPos.z - prevZ);
      if (Math.abs(this.busSpeed) > 2.5 && actualDist < Math.abs(this.busSpeed) * dt * 0.35) {
        this.busSpeed *= 0.55; // gentle bumper bounce on impact
      }

      // Compute gentle road slope pitch for hills & Howrah Bridge crossing ramps
      const frontY = this.world.getGroundHeight(this.busPos.x + bFwdX * 2.4, this.busPos.z + bFwdZ * 2.4, this.busPos.y);
      const backY = this.world.getGroundHeight(this.busPos.x - bFwdX * 2.4, this.busPos.z - bFwdZ * 2.4, this.busPos.y);
      const slopePitch = -Math.atan2(frontY - backY, 4.8);

      this.bus.root.position.copy(this.busPos);
      this.bus.root.rotation.set(slopePitch, this.busYaw, 0);
      this.bus.chassisGroup.rotation.z = -this.busSteerAngle * Math.min(1, Math.abs(this.busSpeed) / 12) * 0.08;
      this.bus.chassisGroup.position.y = Math.sin(this.worldTime * 16) * (Math.abs(this.busSpeed) > 1 ? 0.02 : 0.005);

      const wheelSpin = (this.busSpeed * dt) / 0.54;
      for (const w of this.bus.wheels) {
        w.rotation.x += wheelSpin;
      }

      // Ram enemy bots with the bus!
      if (Math.abs(this.busSpeed) > 4.2) {
        for (const e of this.enemies) {
          if (e.dying || e.busSeatIndex >= 0) continue;
          const dx = e.rig.root.position.x - this.busPos.x;
          const dz = e.rig.root.position.z - this.busPos.z;
          if (dx * dx + dz * dz < 3.1 * 3.1) {
            _v4.set(bFwdX * this.busSpeed, 0, bFwdZ * this.busSpeed);
            _v6.set(e.rig.root.position.x, 1.2, e.rig.root.position.z);
            this.damageEnemy(e, 95, _v4, false, _v6);
            this.camShake = Math.min(0.36, this.camShake + 0.16);
          }
        }
      }

      this.bus.root.updateMatrixWorld(true);
    } else {
      // Bus coasting smoothly to a stop when unmanned on village ground
      if (Math.abs(this.busSpeed) > 0.05) {
        this.busSpeed *= Math.exp(-4.5 * dt);
        const bFwdX = Math.sin(this.busYaw);
        const bFwdZ = Math.cos(this.busYaw);
        this.busPos.x += bFwdX * this.busSpeed * dt;
        this.busPos.z += bFwdZ * this.busSpeed * dt;
        this.resolveCircleWorldCollision(this.busPos, 1.85, false);
        this.busPos.y = this.world.getGroundHeight(this.busPos.x, this.busPos.z, this.busPos.y);
        this.bus.root.position.copy(this.busPos);
        for (const w of this.bus.wheels) {
          w.rotation.x += (this.busSpeed * dt) / 0.54;
        }
      } else {
        this.busSpeed = 0;
      }
      this.bus.chassisGroup.rotation.z *= Math.exp(-8 * dt);
      this.bus.chassisGroup.position.y *= Math.exp(-8 * dt);
    }

    // Sway overhead bus hand-straps naturally with cabin speed and braking inertia
    const strapAmp = 0.04 + Math.min(0.18, Math.abs(this.busSpeed) * 0.012);
    const brakeTilt = this.busExitSlowing ? 0.28 : 0;
    for (let s = 0; s < this.bus.interior.hangingStraps.length; s++) {
      const strap = this.bus.interior.hangingStraps[s];
      strap.rotation.x = brakeTilt + Math.sin(this.worldTime * 4.2 + s * 0.75) * strapAmp;
      strap.rotation.z = Math.cos(this.worldTime * 3.1 + s * 0.55) * strapAmp * 0.65;
    }

    // --- 2. Update Hero Position, Mode & Actions ---
    const fwdX = Math.sin(this.camYaw);
    const fwdZ = Math.cos(this.camYaw);
    const rightX = -fwdZ;
    const rightZ = fwdX;

    if (this.busMode === 'riding_intro') {
      // Hero rides seated inside the hollow WBTC bus cabin, then stands & steps to the opening door when exiting
      this.bus.heroIntroSeat.getWorldPosition(this.heroPos);
      if (this.busExitSlowing) {
        this.bus.interior.heroDoorwayAnchor.getWorldPosition(this.heroDoorwayWorld);
        const stepT = THREE.MathUtils.clamp(
          1 - this.busExitSlowTimer / Math.max(0.01, this.busExitSlowDuration),
          0,
          1,
        );
        const smoothStep = stepT * stepT * (3 - 2 * stepT);
        this.heroPos.lerp(this.heroDoorwayWorld, smoothStep);
        this.heroYaw = this.busYaw - smoothStep * (Math.PI * 0.42);
        const sitBlend = 1 - smoothStep;
        this.hero.leftLeg.rotation.x = -1.16 * sitBlend;
        this.hero.rightLeg.rotation.x = -1.16 * sitBlend;
        this.hero.leftKnee.rotation.x = 1.16 * sitBlend;
        this.hero.rightKnee.rotation.x = 1.16 * sitBlend;
      } else {
        this.heroYaw = this.busYaw;
        this.hero.leftLeg.rotation.x = -1.16;
        this.hero.rightLeg.rotation.x = -1.16;
        this.hero.leftKnee.rotation.x = 1.16;
        this.hero.rightKnee.rotation.x = 1.16;
      }
      this.hero.root.position.copy(this.heroPos);
      this.hero.root.rotation.set(0, this.heroYaw, 0);
      this.hero.headGroup.rotation.set(0, Math.sin(this.worldTime * 0.85) * 0.14, 0);
      this.hero.updateGamchaCloth(dt, this.worldTime, 0.35, 0, this.busSpeed * 0.28, 0, 0.42);
      this.hero.muzzleFlash.visible = false;
      this.hero.muzzleLight.intensity = 0;
      this.nearBus = false;
    } else if (this.busMode === 'driving') {
      // Hero sits visibly in the right-hand-drive cab behind the steering wheel!
      this.bus.heroDriverSeat.getWorldPosition(this.heroPos);
      this.hero.root.position.copy(this.heroPos);
      this.heroYaw = this.busYaw;
      this.hero.root.rotation.set(0, this.heroYaw, 0);
      this.hero.leftLeg.rotation.x = -1.08;
      this.hero.rightLeg.rotation.x = -1.08;
      this.hero.leftKnee.rotation.x = 1.08;
      this.hero.rightKnee.rotation.x = 1.08;
      this.hero.headGroup.rotation.set(0, -this.busSteerAngle * 0.45, 0);
      this.hero.updateGamchaCloth(dt, this.worldTime, 0, 0, this.busSpeed * 0.25, 0, 0.35);
      this.hero.muzzleFlash.visible = false;
      this.hero.muzzleLight.intensity = 0;
      this.nearBus = false;
    } else if (this.heroJumpingFromBus) {
      // Direct grounded hop onto the Howrah Bridge deck or village road (no parachute!)
      const prevY = this.heroPos.y;
      this.heroJumpProgress = Math.min(1, this.heroJumpProgress + dt / this.heroJumpDuration);
      const t = this.heroJumpProgress;
      this.heroPos.lerpVectors(this.heroJumpStart, this.heroJumpEnd, t);
      const arc = 4 * t * (1 - t);
      const baseY = THREE.MathUtils.lerp(this.heroJumpStart.y, this.heroJumpEnd.y, t);
      const lift = Math.max(0.2, this.heroJumpPeakY - (this.heroJumpStart.y + this.heroJumpEnd.y) * 0.5);
      this.heroPos.y = baseY + arc * lift;
      this.hero.root.position.copy(this.heroPos);
      this.hero.leftLeg.rotation.x = 0.38;
      this.hero.rightLeg.rotation.x = -0.3;
      this.hero.leftKnee.rotation.x = 0.48;
      this.hero.rightKnee.rotation.x = 0.24;
      const vertVel = (this.heroPos.y - prevY) / Math.max(0.001, dt);
      this.hero.updateGamchaCloth(dt, this.worldTime, 0, vertVel * 0.6, 3.8, 0, 1.2);

      if (this.heroJumpProgress >= 1) {
        this.heroJumpingFromBus = false;
        this.resolveCircleWorldCollision(this.heroPos, 0.58, true);
        this.heroPos.y = this.world.getGroundHeight(
          this.heroPos.x,
          this.heroPos.z,
          this.heroJumpEnd.y,
        );
        this.hero.root.position.copy(this.heroPos);
        this.hero.bodyGroup.position.y = 0;
        this.hero.leftLeg.rotation.x = 0;
        this.hero.rightLeg.rotation.x = 0;
        this.hero.leftKnee.rotation.x = 0;
        this.hero.rightKnee.rotation.x = 0;
        this.camShake = Math.min(0.22, this.camShake + 0.1);
        this.spawnParticles(this.heroPos, 0xd8a872, 10, 3.8);
      }
      this.nearBus = false;
    } else {
      // Standard on-foot third-person shooter movement & combat
      const wantsSprint =
        (this.keysHeld.has('ShiftLeft') || this.keysHeld.has('ShiftRight') || this.virtualInput.sprinting) &&
        moveLen > 0.2;
      let speedMult = 1.0;
      if (wantsSprint && this.sprintStamina > 0.08) {
        speedMult = 1.48;
        this.sprintStamina = Math.max(0, this.sprintStamina - dt * 0.42);
      } else {
        this.sprintStamina = Math.min(1, this.sprintStamina + dt * 0.28);
      }

      const moveSpeed = 7.6 * speedMult;
      const vx = (fwdX * moveForward + rightX * moveRight) * moveSpeed;
      const vz = (fwdZ * moveForward + rightZ * moveRight) * moveSpeed;

      this.prevHeroPos.copy(this.heroPos);
      this.prevHeroYaw = this.heroYaw;

      this.heroPos.x += vx * dt;
      this.heroPos.z += vz * dt;
      this.resolveCircleWorldCollision(this.heroPos, 0.56, true);
      const targetGroundY = this.world.getGroundHeight(this.heroPos.x, this.heroPos.z, this.heroPos.y);
      if (Math.abs(targetGroundY - this.heroPos.y) <= 1.85) {
        this.heroPos.y = targetGroundY;
      } else {
        this.heroPos.y = THREE.MathUtils.lerp(this.heroPos.y, targetGroundY, Math.min(1, dt * 14));
      }
      this.hero.root.position.copy(this.heroPos);

      // Proximity check for re-entering & driving the WBTC bus ('বাসে উঠুন')
      this.nearBus =
        !this.busAutoDriving &&
        this.heroPos.distanceTo(this.busPos) < 5.8;

      // Smooth hero facing (aligns with camera aim when shooting, or movement direction when running)
      const isShooting =
        this.mouseShootHeld || this.keysHeld.has('Space') || this.virtualInput.shooting;

      const desiredYaw = isShooting
        ? this.camYaw
        : moveLen > 0.12
          ? Math.atan2(vx, vz)
          : this.camYaw;

      let yawDiff = desiredYaw - this.heroYaw;
      while (yawDiff > Math.PI) yawDiff -= Math.PI * 2;
      while (yawDiff < -Math.PI) yawDiff += Math.PI * 2;
      this.heroYaw += yawDiff * (1 - Math.exp(-14 * dt));
      this.hero.root.rotation.set(0, this.heroYaw, 0);
      this.hero.headGroup.rotation.set(0, 0, 0);

      // Procedural hero walk cycle with articulated knee flexion
      if (moveLen > 0.08) {
        this.heroWalkPhase += dt * (9.5 * speedMult);
        const swing = Math.sin(this.heroWalkPhase) * 0.58 * Math.min(1, moveLen);
        this.hero.leftLeg.rotation.x = swing;
        this.hero.rightLeg.rotation.x = -swing;
        this.hero.leftKnee.rotation.x = Math.max(0, -swing) * 0.92;
        this.hero.rightKnee.rotation.x = Math.max(0, swing) * 0.92;
        this.hero.bodyGroup.position.y = Math.abs(Math.cos(this.heroWalkPhase)) * 0.055;
      } else {
        const damp = 1 - Math.exp(-12 * dt);
        this.hero.leftLeg.rotation.x *= 1 - damp;
        this.hero.rightLeg.rotation.x *= 1 - damp;
        this.hero.leftKnee.rotation.x *= 1 - damp;
        this.hero.rightKnee.rotation.x *= 1 - damp;
        this.hero.bodyGroup.position.y *= 1 - damp;
      }

      // Convert hero world velocity into hero local space for realistic cloth-physics gamcha drag
      const worldVx = (this.heroPos.x - this.prevHeroPos.x) / Math.max(0.001, dt);
      const worldVz = (this.heroPos.z - this.prevHeroPos.z) / Math.max(0.001, dt);
      const sinY = Math.sin(this.heroYaw);
      const cosY = Math.cos(this.heroYaw);
      const localVelZ = worldVx * sinY + worldVz * cosY;
      const localVelX = worldVx * cosY - worldVz * sinY;
      let dYaw = this.heroYaw - this.prevHeroYaw;
      while (dYaw > Math.PI) dYaw -= Math.PI * 2;
      while (dYaw < -Math.PI) dYaw += Math.PI * 2;
      const yawRate = dYaw / Math.max(0.001, dt);

      this.hero.updateGamchaCloth(
        dt,
        this.worldTime,
        localVelX,
        0,
        localVelZ,
        yawRate,
        wantsSprint ? 0.95 : moveLen > 0.1 ? 0.45 : 0.18,
      );

      // 3-second Sanjibani medicinal plant healing progression (+50 HP)
      if (this.isHealing) {
        this.healTimer -= dt;
        if (this.healTimer <= 0) {
          this.isHealing = false;
          this.sanjibaniCount = Math.max(0, this.sanjibaniCount - 1);
          this.health = Math.min(this.maxHealth, this.health + 50);
          this.audio.playHealComplete();
          this.spawnParticles(_v1.set(this.heroPos.x, 1.15, this.heroPos.z), 0x26f28a, 14, 4.0);
          this.pickupToast = 'সঞ্জীবনী গাছ: স্বাস্থ্য +৫০';
          this.pickupToastTimer = 2.0;
        }
      }

      // Reloading & firing
      if (this.virtualInput.reloadJustPressed) {
        this.virtualInput.reloadJustPressed = false;
        this.attemptStartReload();
      }
      if (this.isReloading) {
        this.reloadTimer -= dt;
        if (this.reloadTimer <= 0) {
          const slot = this.weaponSlots[this.weaponType];
          const needed = slot.maxAmmo - slot.ammo;
          const load = Math.min(needed, slot.reserve);
          slot.ammo += load;
          slot.reserve -= load;
          this.isReloading = false;
        }
      }

      this.fireCooldown = Math.max(0, this.fireCooldown - dt);
      if (isShooting) {
        this.firePlayerWeapon();
      }

      // Weapon recoil, Bengali Fala melee slash swing, & muzzle flash decay
      this.heroRecoil = Math.max(0, this.heroRecoil - dt * 7.5);
      if (this.meleeSlashTimer > 0) {
        this.meleeSlashTimer = Math.max(0, this.meleeSlashTimer - dt);
        const slashT = 1 - this.meleeSlashTimer / 0.24;
        const swing = Math.sin(slashT * Math.PI);
        this.hero.recoilGroup.position.z = 0.27 + swing * 0.26;
        this.hero.recoilGroup.rotation.y = (slashT - 0.5) * -1.45;
        this.hero.recoilGroup.rotation.x = -swing * 0.42;
      } else {
        this.hero.recoilGroup.position.z = 0.27 - this.heroRecoil * 0.085;
        this.hero.recoilGroup.rotation.x = -this.heroRecoil * 0.14;
        this.hero.recoilGroup.rotation.y = 0;
      }

      if (this.muzzleFlashTimer > 0) {
        this.muzzleFlashTimer -= dt;
        this.hero.muzzleFlash.visible = true;
        this.hero.muzzleFlash.rotation.z = Math.random() * Math.PI * 2;
        this.hero.muzzleLight.intensity = 4.5;
      } else {
        this.hero.muzzleFlash.visible = false;
        this.hero.muzzleLight.intensity = 0;
      }
    }

    // Keep shadow frustum centered around active subject (bus or hero)
    const focusPos = this.busMode !== 'none' ? this.busPos : this.heroPos;
    this.sunLight.position.set(focusPos.x + 32, 56, focusPos.z - 26);
    this.sunLight.target.position.copy(focusPos);

    // Wave spawning & progression (pause wave auto-advance while Wave 1 intro bus is still dropping enemies)
    if (!this.busAutoDriving || this.wave > 1) {
      this.updateWaves(dt);
    }

    // Update Battle Royale systems: enemies, bullets, pickups, Warrior Chests, Bajra Gola grenades,
    // floating 3D damage numbers, Kalboishakhi storm safe zone, and particles
    this.updateEnemies(dt);
    this.updateBullets(dt);
    this.updatePickups(dt);
    this.updateChests(dt);
    this.updateGrenades(dt);
    this.updateFloatingDamages(dt);
    this.updateKalboishakhiStorm(dt);
    this.updateParticles(dt);

    // --- 3. Camera Rig (Bus Interior Cabin View / Bus Exterior Chase / Driving / Third-Person Shooter) ---
    if (this.busMode === 'riding_intro') {
      if (this.busInteriorCam) {
        // Realistic Bus Interior View: positioned inside the aisle looking forward past seated rivals,
        // overhead grab rails, driver cabin, and clear panoramic windows over the Howrah Bridge & landmarks
        this.bus.interior.interiorCamPos.getWorldPosition(_camDesired);
        _camDesired.y += Math.sin(this.worldTime * 15) * 0.008;

        this.bus.interior.interiorCamLook.getWorldPosition(_lookAtPt);
        if (Math.abs(this.busInteriorLookYaw) > 0.001) {
          const lx = _lookAtPt.x - _camDesired.x;
          const lz = _lookAtPt.z - _camDesired.z;
          const cosG = Math.cos(this.busInteriorLookYaw);
          const sinG = Math.sin(this.busInteriorLookYaw);
          _lookAtPt.x = _camDesired.x + lx * cosG + lz * sinG;
          _lookAtPt.z = _camDesired.z - lx * sinG + lz * cosG;
        }
      } else {
        // Exterior View toggle: sweeping side-rear chase camera showing the WBTC bus & Howrah Bridge
        const bFwdX = Math.sin(this.busYaw);
        const bFwdZ = Math.cos(this.busYaw);
        const bRightX = -bFwdZ;
        const bRightZ = bFwdX;

        _camDesired.set(
          this.busPos.x - bFwdX * 11.5 - bRightX * 4.8,
          this.busPos.y + 5.1,
          this.busPos.z - bFwdZ * 11.5 - bRightZ * 4.8,
        );
        _lookAtPt.set(
          this.busPos.x + bFwdX * 3.5,
          this.busPos.y + 1.8,
          this.busPos.z + bFwdZ * 3.5,
        );
      }
    } else if (this.busMode === 'driving') {
      // Responsive vehicle chase camera behind the player-driven WBTC bus
      const bFwdX = Math.sin(this.busYaw);
      const bFwdZ = Math.cos(this.busYaw);
      _camDesired.set(
        this.busPos.x - bFwdX * 12.2,
        this.busPos.y + 5.2,
        this.busPos.z - bFwdZ * 12.2,
      );
      _lookAtPt.set(
        this.busPos.x + bFwdX * 5.0,
        this.busPos.y + 1.8,
        this.busPos.z + bFwdZ * 5.0,
      );
    } else if (this.scopeActive && this.weaponType === 'trishul') {
      // Crisp over-shoulder Trishul Sniper optic alignment
      _camDesired.set(
        this.heroPos.x - fwdX * 1.15 + rightX * 0.42,
        this.heroPos.y + 1.72,
        this.heroPos.z - fwdZ * 1.15 + rightZ * 0.42,
      );
      _lookAtPt.set(
        this.heroPos.x + fwdX * 36 + rightX * 0.25,
        this.heroPos.y + 1.72 - this.camPitch * 14.5,
        this.heroPos.z + fwdZ * 36 + rightZ * 0.25,
      );
    } else {
      // Third-person over-the-shoulder shooter camera
      const camDist = 6.2;
      const shoulderRight = 1.05;
      const camHeight = 2.65 + this.camPitch * 2.8;
      _camDesired.set(
        this.heroPos.x - fwdX * camDist + rightX * shoulderRight,
        this.heroPos.y + camHeight,
        this.heroPos.z - fwdZ * camDist + rightZ * shoulderRight,
      );
      _camDesired.y = Math.max(this.heroPos.y + 1.35, _camDesired.y);

      _lookAtPt.set(
        this.heroPos.x + fwdX * 14 + rightX * 0.45,
        this.heroPos.y + 1.55 - this.camPitch * 4.2,
        this.heroPos.z + fwdZ * 14 + rightZ * 0.45,
      );
    }

    // Smoothly damp camera FOV (wider 66° inside bus cabin for clear panoramic window view, 22° sniper scope, 56° standard)
    const targetFov =
      this.scopeActive && this.weaponType === 'trishul' && this.busMode === 'none'
        ? 22
        : this.busMode === 'riding_intro' && this.busInteriorCam
          ? 66
          : 56;
    if (Math.abs(this.currentFov - targetFov) > 0.05) {
      this.currentFov += (targetFov - this.currentFov) * (1 - Math.exp(-14 * dt));
      this.camera.fov = this.currentFov;
      this.camera.updateProjectionMatrix();
    }

    if (this.introTransitionProgress < 1) {
      this.introTransitionProgress = Math.min(
        1,
        this.introTransitionProgress + dt / this.introTransitionDuration,
      );
      const t = this.introTransitionProgress;
      const ease = t * t * (3 - 2 * t);

      this.camera.position.lerpVectors(this.introStartCamPos, _camDesired, ease);
      if (!(this.busMode === 'riding_intro' && this.busInteriorCam)) {
        this.camera.position.y += Math.sin(ease * Math.PI) * 2.4;
      }
      _camTarget.lerpVectors(this.introStartLookAt, _lookAtPt, ease);
      this.camera.lookAt(_camTarget);
    } else {
      const inBusCabin = this.busMode === 'riding_intro' && this.busInteriorCam;
      const posRate = inBusCabin ? 28 : this.busMode !== 'none' ? 6.5 : this.scopeActive ? 18 : 12;
      const lookRate = inBusCabin ? 26 : this.scopeActive ? 22 : 14;
      const camDamp = 1 - Math.exp(-posRate * dt);
      this.camera.position.lerp(_camDesired, camDamp);

      if (this.camShake > 0.005) {
        this.camera.position.x += (Math.random() - 0.5) * this.camShake;
        this.camera.position.y += (Math.random() - 0.5) * this.camShake;
      }

      _camTarget.lerp(_lookAtPt, 1 - Math.exp(-lookRate * dt));
      this.camera.lookAt(_camTarget);
    }
  }

  private dropEnemyFromBus(e: ActiveEnemy): void {
    const prevSeat = e.busSeatIndex;
    e.busSeatIndex = -1;
    e.rig.telegraphGlow.visible = false;
    e.telegraphTimer = 0;

    // Swing side passenger door briefly open and launch rival warrior cleanly from the doorway
    this.busDoorAutoHoldTimer = Math.max(this.busDoorAutoHoldTimer, 0.72);
    this.bus.interior.heroDoorwayAnchor.getWorldPosition(e.jumpStart);

    // Spread slightly along the road so multiple exiting bots never stack or clip inside bus
    const sideSign = 1;
    const spread = ((prevSeat % 3) - 1) * 1.15;
    this.findSafeBusExitPosition(e.jumpEnd, e.radius + 0.2, sideSign, spread, true);

    e.jumpPeakY = Math.max(e.jumpStart.y, e.jumpEnd.y) + 0.42;
    e.jumpDuration = Math.abs(e.jumpStart.y - e.jumpEnd.y) > 1.8 ? 0.42 : 0.28;
    e.jumpProgress = 0;
    e.jumpingFromBus = true;
    // Full 2.0-second safe phase begins AFTER landing cleanly on the ground!
    e.postLandingSafeTimer = 2.0;
  }

  private updateWaves(dt: number): void {
    const aliveEnemies = this.enemies.filter((e) => !e.dying).length;

    if (this.waveEnemiesToSpawn.length > 0) {
      const maxSimultaneous = Math.min(8, 3 + this.wave);
      if (aliveEnemies < maxSimultaneous) {
        this.waveSpawnTimer -= dt;
        if (this.waveSpawnTimer <= 0) {
          const next = this.waveEnemiesToSpawn.shift()!;
          this.spawnEnemy(next);
          this.waveSpawnTimer = Math.max(0.7, 1.85 - this.wave * 0.12);
        }
      }
    } else if (aliveEnemies === 0) {
      if (this.waveBreakTimer <= 0) {
        this.waveBreakTimer = 2.5;
        this.waveBanner = `তরঙ্গ ${toBengaliNumber(this.wave)} সম্পূর্ণ!`;
        this.waveBannerTimer = 2.2;
        this.score += 150 * this.wave;
        this.checkHighScore();
      } else {
        this.waveBreakTimer -= dt;
        if (this.waveBreakTimer <= 0) {
          this.beginWave(this.wave + 1);
        }
      }
    }
  }

  private updateEnemies(dt: number): void {
    const playerProtectedInBus = this.busMode !== 'none' || this.heroJumpingFromBus;

    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];

      // Enemies currently seated inside the WBTC bus cabin never aim, shoot, or move independently
      if (e.busSeatIndex >= 0) {
        e.rig.telegraphGlow.visible = false;
        e.telegraphTimer = 0;
        e.rig.leftLeg.rotation.x = -1.15;
        e.rig.rightLeg.rotation.x = -1.15;
        e.rig.leftKnee.rotation.x = 1.15;
        e.rig.rightKnee.rotation.x = 1.15;
        continue;
      }

      if (e.dying) {
        e.deathTimer += dt;
        e.rig.bodyGroup.rotation.x = THREE.MathUtils.lerp(0, -Math.PI * 0.48, Math.min(1, e.deathTimer * 3.8));
        e.rig.bodyGroup.position.y = THREE.MathUtils.lerp(0, -0.18, Math.min(1, e.deathTimer * 3.8));
        e.rig.hpBarBg.visible = false;
        e.rig.telegraphGlow.visible = false;
        if (e.deathTimer > 1.15) {
          this.scene.remove(e.rig.root);
          this.enemies.splice(i, 1);
        }
        continue;
      }

      // Direct grounded hop from open bus side door onto bridge/road before entering combat
      if (e.jumpingFromBus) {
        e.jumpProgress = Math.min(1, e.jumpProgress + dt / e.jumpDuration);
        const t = e.jumpProgress;
        e.rig.root.position.lerpVectors(e.jumpStart, e.jumpEnd, t);
        const arc = 4 * t * (1 - t);
        const baseY = THREE.MathUtils.lerp(e.jumpStart.y, e.jumpEnd.y, t);
        const lift = Math.max(0.18, e.jumpPeakY - (e.jumpStart.y + e.jumpEnd.y) * 0.5);
        e.rig.root.position.y = baseY + arc * lift;
        e.rig.leftLeg.rotation.x = 0.36;
        e.rig.rightLeg.rotation.x = -0.28;
        e.rig.leftKnee.rotation.x = 0.48;
        e.rig.rightKnee.rotation.x = 0.25;
        e.rig.telegraphGlow.visible = false;
        e.telegraphTimer = 0;

        if (e.jumpProgress >= 1) {
          e.jumpingFromBus = false;
          this.resolveCircleWorldCollision(e.rig.root.position, e.radius, true);
          e.rig.root.position.y = this.world.getGroundHeight(
            e.rig.root.position.x,
            e.rig.root.position.z,
            e.jumpEnd.y,
          );
          e.rig.bodyGroup.position.y = 0;
          e.rig.leftLeg.rotation.x = 0;
          e.rig.rightLeg.rotation.x = 0;
          e.rig.leftKnee.rotation.x = 0;
          e.rig.rightKnee.rotation.x = 0;
          e.postLandingSafeTimer = 2.0; // Strictly 2 seconds after landing on ground before aiming/shooting
          this.spawnParticles(e.rig.root.position, 0xd8a872, 7, 3.6);
        }
        continue;
      }

      // Keep grounded enemies cleanly seated on laterite hills, bridge ramps, and courtyard floors
      e.rig.root.position.y = this.world.getGroundHeight(
        e.rig.root.position.x,
        e.rig.root.position.z,
        e.rig.root.position.y,
      );
      e.rig.bodyGroup.position.y = 0;

      // Count down 2-second post-landing safe timer
      if (e.postLandingSafeTimer > 0) {
        e.postLandingSafeTimer = Math.max(0, e.postLandingSafeTimer - dt);
      }

      // Hit flash recovery
      if (e.hitFlashTimer > 0) {
        e.hitFlashTimer -= dt;
        if (e.hitFlashTimer <= 0) {
          e.rig.flashMaterials.forEach((m, idx) => {
            m.emissive.copy(e.rig.baseEmissives[idx]);
          });
          e.rig.bodyGroup.scale.setScalar(
            e.archetype === 'heavy' ? 1.18 : e.archetype === 'rusher' ? 0.96 : 1.02,
          );
        }
      }

      // Billboard floating health bar toward camera
      if (e.rig.hpBarBg.visible) {
        e.rig.hpBarBg.lookAt(this.camera.position);
      }

      const toHeroX = this.heroPos.x - e.rig.root.position.x;
      const toHeroZ = this.heroPos.z - e.rig.root.position.z;
      const dist = Math.hypot(toHeroX, toHeroZ) || 0.001;
      const dirX = toHeroX / dist;
      const dirZ = toHeroZ / dist;

      // Check solid wall / obstacle line-of-sight before aiming or shooting
      _v5.set(e.rig.root.position.x, e.rig.root.position.y + 1.32, e.rig.root.position.z);
      _v6.set(this.heroPos.x, this.heroPos.y + 1.25, this.heroPos.z);
      const hasLOS = !playerProtectedInBus && dist <= e.fireRange && this.hasLineOfSight(_v5, _v6);

      // Tactical movement: disperse/flank while safe timer active or when LOS is blocked by a house/bus
      const desiredRange =
        e.archetype === 'rusher' ? 6.5 : e.archetype === 'heavy' ? 12.0 : 13.5;

      e.strafeTimer -= dt;
      if (e.strafeTimer <= 0) {
        e.strafeDir = -e.strafeDir;
        e.strafeTimer = 1.4 + Math.random() * 1.8;
      }

      let moveX = 0;
      let moveZ = 0;
      if (playerProtectedInBus || e.postLandingSafeTimer > 0) {
        // Patrol & spread out cleanly around the village during the safe drop-in phase
        moveX += -dirZ * e.strafeDir * 0.75 + dirX * 0.25;
        moveZ += dirX * e.strafeDir * 0.75 + dirZ * 0.25;
      } else if (!hasLOS) {
        // Actively flank around blocking walls/houses/taxi to gain a clean shot
        moveX += dirX * 0.55 - dirZ * e.strafeDir * 0.95;
        moveZ += dirZ * 0.55 + dirX * e.strafeDir * 0.95;
      } else {
        if (dist > desiredRange + 1.2) {
          moveX += dirX;
          moveZ += dirZ;
        } else if (dist < desiredRange - 2.2) {
          moveX -= dirX * 0.55;
          moveZ -= dirZ * 0.55;
        }
        moveX += -dirZ * e.strafeDir * 0.65;
        moveZ += dirX * e.strafeDir * 0.65;
      }

      // Soft separation between grounded enemies so they never stack
      for (let j = 0; j < this.enemies.length; j++) {
        if (i === j || this.enemies[j].dying || this.enemies[j].busSeatIndex >= 0) continue;
        const other = this.enemies[j];
        const sx = e.rig.root.position.x - other.rig.root.position.x;
        const sz = e.rig.root.position.z - other.rig.root.position.z;
        const sDistSq = sx * sx + sz * sz;
        if (sDistSq < 3.6 && sDistSq > 0.001) {
          const sDist = Math.sqrt(sDistSq);
          moveX += (sx / sDist) * 1.15;
          moveZ += (sz / sDist) * 1.15;
        }
      }

      const mLen = Math.hypot(moveX, moveZ);
      if (mLen > 0.01) {
        moveX /= mLen;
        moveZ /= mLen;
        e.rig.root.position.x += moveX * e.speed * dt;
        e.rig.root.position.z += moveZ * e.speed * dt;
        e.walkPhase += dt * (e.speed * 1.8);
        const swing = Math.sin(e.walkPhase) * 0.52;
        e.rig.leftLeg.rotation.x = swing;
        e.rig.rightLeg.rotation.x = -swing;
        e.rig.leftKnee.rotation.x = Math.max(0, -swing) * 0.88;
        e.rig.rightKnee.rotation.x = Math.max(0, swing) * 0.88;
      }

      // Face movement direction during safe phase, or lock gaze on hero once ready to engage
      if (playerProtectedInBus || e.postLandingSafeTimer > 0) {
        if (mLen > 0.05) {
          e.rig.root.rotation.y = Math.atan2(moveX, moveZ);
        }
      } else {
        e.rig.root.rotation.y = Math.atan2(dirX, dirZ);
      }

      // Apply knockback decay
      if (e.knockback.lengthSq() > 0.01) {
        e.rig.root.position.addScaledVector(e.knockback, dt);
        e.knockback.multiplyScalar(Math.exp(-10 * dt));
      }

      this.resolveCircleWorldCollision(e.rig.root.position, e.radius, true);
      e.rig.root.position.y = this.world.getGroundHeight(
        e.rig.root.position.x,
        e.rig.root.position.z,
        e.rig.root.position.y,
      );

      // Combat firing ONLY when: player is on foot (not in bus), enemy landed >= 2s ago, in range, AND clear line-of-sight!
      const canEngage = !playerProtectedInBus && e.postLandingSafeTimer <= 0 && hasLOS;
      if (canEngage) {
        if (e.telegraphTimer > 0) {
          e.telegraphTimer -= dt;
          e.rig.telegraphGlow.visible = true;
          const pulse = 0.8 + (1 - e.telegraphTimer / 0.45) * 0.7;
          e.rig.telegraphGlow.scale.setScalar(pulse);
          if (e.telegraphTimer <= 0) {
            e.rig.telegraphGlow.visible = false;
            this.fireEnemyShot(e, dist);
            e.fireCooldown =
              e.archetype === 'heavy'
                ? 1.55
                : e.archetype === 'rusher'
                  ? 1.15
                  : Math.max(1.0, 1.8 - this.wave * 0.06);
          }
        } else {
          e.fireCooldown -= dt;
          if (e.fireCooldown <= 0) {
            e.telegraphTimer = e.archetype === 'heavy' ? 0.55 : 0.42;
          }
        }
      } else {
        e.rig.telegraphGlow.visible = false;
        e.telegraphTimer = 0;
      }
    }
  }

  private fireEnemyShot(e: ActiveEnemy, distToHero: number): void {
    // Defense-in-depth: never fire while player is inside/jumping from bus or enemy safe timer active
    if (this.busMode !== 'none' || this.heroJumpingFromBus || e.postLandingSafeTimer > 0) return;

    e.rig.root.updateMatrixWorld(true);
    const muzzleWorld = _v1;
    e.rig.muzzlePoint.getWorldPosition(muzzleWorld);

    const aimTarget = _v2.set(this.heroPos.x, this.heroPos.y + 1.25, this.heroPos.z);
    // Verify clean line of sight from actual weapon muzzle too (never shoot through walls!)
    if (!this.hasLineOfSight(muzzleWorld, aimTarget)) return;

    const dir = _v3.subVectors(aimTarget, muzzleWorld).normalize();

    // Fair dodgeable inaccuracy so movement & cover matter
    const spread = e.archetype === 'heavy' ? 0.05 : 0.075;
    dir.x += (Math.random() - 0.5) * spread;
    dir.y += (Math.random() - 0.5) * 0.03;
    dir.z += (Math.random() - 0.5) * spread;
    dir.normalize();

    const dmg = e.archetype === 'heavy' ? 14 : e.archetype === 'rusher' ? 9 : 10;
    const speed = e.archetype === 'heavy' ? 23 : 27;
    this.spawnBullet(false, muzzleWorld, dir, speed, dmg);
    this.audio.playEnemyShot(distToHero);
  }

  private updateBullets(dt: number): void {
    for (const b of this.bullets) {
      if (!b.active) continue;
      b.life -= dt;

      // Swept continuous segment [prevPos -> nextPos] prevents tunneling through enemies OR solid walls!
      const prevPos = _v5.copy(b.pos);
      b.pos.addScaledVector(b.vel, dt);
      b.mesh.position.copy(b.pos);

      if (b.life <= 0) {
        b.active = false;
        b.mesh.visible = false;
        continue;
      }

      const obsT = this.segmentFirstObstacleT(prevPos, b.pos, true);

      if (b.fromPlayer) {
        // Find earliest swept hit against separate Head vs Body hitboxes BEFORE any solid wall/obstacle
        let hitEnemy: ActiveEnemy | null = null;
        let hitIsHeadshot = false;
        let bestEnemyT = obsT; // Never hit an enemy behind a wall!

        for (let i = 0; i < this.enemies.length; i++) {
          const e = this.enemies[i];
          if (e.dying || e.busSeatIndex >= 0 || e.jumpingFromBus) continue;
          const s = this.getEnemyScale(e);
          const ex = e.rig.root.position.x;
          const ey = e.rig.root.position.y;
          const ez = e.rig.root.position.z;

          // 1. Separate Head Hitbox (upper cranium & face zone: ey + 1.54*s .. ey + 2.04*s)
          const tHead = this.segmentHitsCylinderT(
            prevPos,
            b.pos,
            ex,
            ez,
            0.39 * s,
            ey + 1.54 * s,
            ey + 2.04 * s,
          );
          if (tHead < bestEnemyT) {
            bestEnemyT = tHead;
            hitEnemy = e;
            hitIsHeadshot = true;
          }

          // 2. Separate Body Hitbox (torso & legs zone: ey + 0.02 .. ey + 1.54*s)
          const tBody = this.segmentHitsCylinderT(
            prevPos,
            b.pos,
            ex,
            ez,
            e.radius + 0.3,
            ey + 0.02,
            ey + 1.54 * s,
          );
          if (tBody < bestEnemyT) {
            bestEnemyT = tBody;
            hitEnemy = e;
            hitIsHeadshot = false;
          }
        }

        if (hitEnemy) {
          _v6.lerpVectors(prevPos, b.pos, bestEnemyT);
          this.damageEnemy(hitEnemy, b.damage, b.vel, hitIsHeadshot, _v6);
          b.active = false;
          b.mesh.visible = false;
          continue;
        }
      } else {
        // Enemy bullet: player is 100% invulnerable while inside or jumping off the WBTC bus!
        if (this.busMode === 'none' && !this.heroJumpingFromBus) {
          const tHero = this.segmentHitsCylinderT(
            prevPos,
            b.pos,
            this.heroPos.x,
            this.heroPos.z,
            0.58,
            this.heroPos.y + 0.05,
            this.heroPos.y + 1.95,
          );
          if (tHero < obsT) {
            this.damagePlayer(b.damage, false);
            b.active = false;
            b.mesh.visible = false;
            continue;
          }
        }
      }

      // If bullet hit a wall, mud house, yellow taxi, tree, cover crate, or WBTC bus hull
      if (obsT <= 1) {
        _v6.lerpVectors(prevPos, b.pos, obsT);
        const sparkColor = this.busMode === 'driving' ? 0xffe082 : 0xd8a872;
        this.spawnParticles(_v6, sparkColor, 4, 3.4);
        b.active = false;
        b.mesh.visible = false;
      }
    }
  }

  private damageEnemy(
    e: ActiveEnemy,
    baseDmg: number,
    bulletVel: THREE.Vector3,
    isHeadshot = false,
    hitPoint?: THREE.Vector3,
  ): void {
    const finalDmg = isHeadshot ? Math.round(baseDmg * 2.5) : Math.round(baseDmg);
    e.hp -= finalDmg;
    e.hitFlashTimer = 0.095;
    e.rig.flashMaterials.forEach((m) => m.emissive.setHex(isHeadshot ? 0xff2828 : 0xffffff));

    // Track live Headshot vs Body Shot counters
    if (isHeadshot) {
      this.headshots++;
    } else {
      this.bodyshots++;
    }

    // Spawn animated floating 3D damage number above hit point
    const s = this.getEnemyScale(e);
    const dmgOrigin = hitPoint
      ? hitPoint.clone()
      : new THREE.Vector3(
          e.rig.root.position.x,
          isHeadshot ? 1.85 * s : 1.3 * s,
          e.rig.root.position.z,
        );
    this.spawnFloatingDamage(dmgOrigin, finalDmg, isHeadshot);

    // Squash & stretch impact reaction
    e.rig.bodyGroup.scale.set(s * 1.12, s * 0.9, s * 1.12);

    // Knockback along shot direction
    if (bulletVel.lengthSq() > 0.0001) {
      _v1.copy(bulletVel).setY(0).normalize().multiplyScalar(e.archetype === 'heavy' ? 2.5 : 5.2);
      e.knockback.copy(_v1);
    }

    // Update world-space health bar
    e.rig.hpBarBg.visible = true;
    const ratio = Math.max(0, e.hp / e.maxHp);
    e.rig.hpBarFill.scale.x = Math.max(0.001, ratio);

    this.spawnParticles(dmgOrigin, isHeadshot ? 0xff2424 : 0xff7b38, isHeadshot ? 11 : 6, 5.2);

    if (e.hp <= 0) {
      e.dying = true;
      e.deathTimer = 0;
      this.kills++;
      const pts =
        (e.archetype === 'heavy' ? 180 : e.archetype === 'rusher' ? 130 : 100) +
        (isHeadshot ? 50 : 0);
      this.score += pts;
      this.checkHighScore();
      this.hitMarker = 1.0;
      this.hitMarkerKill = true;
      this.hitMarkerHeadshot = isHeadshot;
      this.hitstopTimer = isHeadshot ? 0.055 : 0.04;
      this.camShake = Math.min(0.34, this.camShake + (isHeadshot ? 0.16 : 0.11));
      if (isHeadshot) {
        this.audio.playHeadshotPing();
      }
      this.audio.playEnemyHit(true);
      this.spawnParticles(
        _v2.set(e.rig.root.position.x, 1.2, e.rig.root.position.z),
        0xffa73b,
        14,
        6.5,
      );

      // Spawn a glowing wooden-and-brass Warrior Loot Chest ('যোদ্ধা সিন্দুক') whenever an enemy is defeated!
      this.spawnWarriorChest(e.rig.root.position.x, e.rig.root.position.z, e.rig.root.rotation.y);
    } else {
      this.hitMarker = isHeadshot ? 0.95 : 0.72;
      this.hitMarkerKill = false;
      this.hitMarkerHeadshot = isHeadshot;
      if (isHeadshot) {
        this.audio.playHeadshotPing();
      } else {
        this.audio.playEnemyHit(false);
      }
    }
  }

  private damagePlayer(dmg: number, bypassArmor = false): void {
    // Player is completely invulnerable while inside or leaping off the WBTC bus
    if (this.busMode !== 'none' || this.heroJumpingFromBus) return;

    // Cancel active Sanjibani healing if struck by an enemy bullet
    if (!bypassArmor && this.isHealing) {
      this.isHealing = false;
      this.pickupToast = 'আঘাতে চিকিৎসা ব্যাহত হয়েছে!';
      this.pickupToastTimer = 1.4;
    }

    let remaining = dmg;
    if (!bypassArmor && this.armor > 0) {
      // Raksha Kabach (Body Armor) absorbs incoming bullet damage first!
      const absorbed = Math.min(this.armor, remaining);
      this.armor -= absorbed;
      remaining -= absorbed;
      this.hero.armorVestOverlay.visible = this.armor > 0;
    }

    if (remaining > 0) {
      this.health = Math.max(0, this.health - remaining);
    }

    this.damageFlash = bypassArmor ? Math.max(this.damageFlash, 0.42) : 0.92;
    if (!bypassArmor) {
      this.camShake = Math.min(0.4, this.camShake + 0.16);
      this.audio.playPlayerHurt();
    }

    if (this.health <= 0) {
      this.phase = 'gameover';
      this.scopeActive = false;
      this.isHealing = false;
      this.keysHeld.clear();
      this.mouseShootHeld = false;
      this.virtualInput.shooting = false;
      if (document.pointerLockElement === this.renderer.domElement) {
        document.exitPointerLock();
      }
      this.checkHighScore();
      this.emitHud();
    }
  }

  private updatePickups(dt: number): void {
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const p = this.pickups[i];
      p.life -= dt;
      if (p.kind !== 'sanjibani') {
        p.mesh.rotation.y += dt * 1.8;
        p.mesh.position.y = p.pos.y + Math.sin(this.worldTime * 3.2 + p.id) * 0.1;
      } else {
        p.mesh.rotation.y += dt * 0.7;
      }

      if (this.busMode === 'none' && !this.heroJumpingFromBus) {
        const distSq = p.pos.distanceToSquared(this.heroPos);
        if (distSq < 1.9 * 1.9) {
          let collected = false;
          if (p.kind === 'sanjibani') {
            if (this.sanjibaniCount < this.maxSanjibani) {
              this.sanjibaniCount++;
              this.sanjibaniCollected++;
              this.pickupToast = `সঞ্জীবনী গাছ +১ (${toBengaliNumber(this.sanjibaniCount)}/${toBengaliNumber(this.maxSanjibani)})`;
              this.audio.playPickup('health');
              collected = true;
            }
          } else if (p.kind === 'armor') {
            if (this.armor < this.maxArmor) {
              this.armor = this.maxArmor;
              this.hero.armorVestOverlay.visible = true;
              this.pickupToast = 'রক্ষা কবচ +৫০';
              this.audio.playPickup('health');
              collected = true;
            }
          } else if (p.kind === 'grenade') {
            if (this.grenadeCount < this.maxGrenades) {
              this.grenadeCount++;
              this.pickupToast = 'বজ্র গোলা +১';
              this.audio.playPickup('ammo');
              collected = true;
            }
          } else {
            const targetW: WeaponType = this.weaponType === 'fala' ? 'agni47' : this.weaponType;
            const meta = WEAPON_CATALOG[targetW];
            const slot = this.weaponSlots[targetW];
            slot.reserve = Math.min(meta.maxReserve, slot.reserve + meta.magSize);
            this.pickupToast = `${meta.shortName} গুলি +${toBengaliNumber(meta.magSize)}`;
            this.audio.playPickup('ammo');
            collected = true;
          }

          if (collected) {
            this.pickupToastTimer = 1.9;
            this.scene.remove(p.mesh);
            this.pickups.splice(i, 1);
            continue;
          }
        }
      }

      if (p.life <= 0) {
        this.scene.remove(p.mesh);
        this.pickups.splice(i, 1);
      }
    }
  }

  private updateChests(dt: number): void {
    let closest: LootChestItem | null = null;
    let closestDistSq = 3.25 * 3.25;

    for (let i = this.chests.length - 1; i >= 0; i--) {
      const c = this.chests[i];
      if (c.opened) {
        c.openProgress = Math.min(1, c.openProgress + dt * 4.5);
        c.rig.lidPivot.rotation.x = -c.openProgress * 1.75;
        c.rig.glowRing.visible = false;
        c.rig.innerGlow.visible = c.openProgress < 0.85;
        c.rig.brassMat.emissiveIntensity = 0.08;
        c.life -= dt * 3.5;
        if (c.life <= 0) {
          this.scene.remove(c.rig.root);
          this.chests.splice(i, 1);
        }
        continue;
      }

      // Subtle warm golden chest shimmer
      const shimmer = 0.55 + Math.sin(this.worldTime * 3.8 + c.id) * 0.25;
      c.rig.brassMat.emissiveIntensity = shimmer;
      c.rig.glowRing.rotation.z = this.worldTime * 0.6;

      if (this.busMode === 'none' && !this.heroJumpingFromBus) {
        const dSq = c.pos.distanceToSquared(this.heroPos);
        if (dSq < closestDistSq) {
          closestDistSq = dSq;
          closest = c;
        }
      }
    }

    this.nearestChest = closest;
    this.nearChest = closest !== null;
  }

  private updateGrenades(dt: number): void {
    for (let i = this.grenades.length - 1; i >= 0; i--) {
      const g = this.grenades[i];
      g.fuseTimer -= dt;

      // Parabolic gravity flight & bounce against ground/obstacles
      g.vel.y -= 21 * dt;
      g.pos.addScaledVector(g.vel, dt);
      const gGround = this.world.getGroundHeight(g.pos.x, g.pos.z, g.pos.y) + 0.16;
      if (g.pos.y < gGround) {
        g.pos.y = gGround;
        g.vel.y = Math.abs(g.vel.y) * 0.38;
        g.vel.x *= 0.68;
        g.vel.z *= 0.68;
      }
      this.resolveCircleWorldCollision(g.pos, 0.22, true);
      g.mesh.position.copy(g.pos);
      g.mesh.rotation.x += dt * 7;
      g.mesh.rotation.z += dt * 5;

      // Blinking fuse spark intensity speeds up near detonation
      const spark = g.mesh.getObjectByName('fuseSpark') as THREE.Mesh | undefined;
      if (spark) {
        const rate = g.fuseTimer < 1.0 ? 28 : 12;
        spark.visible = Math.sin(this.worldTime * rate) > 0;
      }

      if (g.fuseTimer <= 0) {
        this.detonateGrenade(g.pos);
        this.scene.remove(g.mesh);
        this.grenades.splice(i, 1);
      }
    }

    // Animate fiery explosion shockwave rings
    for (let i = this.shockwaves.length - 1; i >= 0; i--) {
      const sw = this.shockwaves[i];
      sw.life -= dt;
      if (sw.life <= 0) {
        this.scene.remove(sw.mesh);
        sw.mesh.geometry.dispose();
        (sw.mesh.material as THREE.Material).dispose();
        this.shockwaves.splice(i, 1);
        continue;
      }
      const p = 1 - sw.life / sw.maxLife;
      const scale = 0.6 + p * 7.5;
      sw.mesh.scale.set(scale, scale, 1);
      (sw.mesh.material as THREE.MeshBasicMaterial).opacity = (1 - p) * 0.85;
    }
  }

  private detonateGrenade(center: THREE.Vector3): void {
    this.audio.playGrenadeExplosion();
    this.camShake = Math.min(0.62, this.camShake + 0.45);
    this.spawnParticles(center, 0xff6e1f, 24, 9.5);
    this.spawnParticles(_v1.set(center.x, center.y + 0.4, center.z), 0xffe066, 14, 7.2);

    // Expanding fiery ground shockwave ring
    const ringGeo = new THREE.RingGeometry(0.65, 1.0, 32);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0xff8c2b,
      transparent: true,
      opacity: 0.85,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    const ringMesh = new THREE.Mesh(ringGeo, ringMat);
    ringMesh.rotation.x = -Math.PI / 2;
    ringMesh.position.set(center.x, 0.14, center.z);
    this.scene.add(ringMesh);
    this.shockwaves.push({ mesh: ringMesh, life: 0.42, maxLife: 0.42 });

    // Area damage (7.4m blast radius) to all grounded enemies
    const blastR = 7.4;
    for (const e of this.enemies) {
      if (e.dying || e.busSeatIndex >= 0 || e.jumpingFromBus) continue;
      const dist = e.rig.root.position.distanceTo(center);
      if (dist <= blastR) {
        const falloff = 1 - (dist / blastR) * 0.62;
        const dmg = Math.round(125 * falloff);
        _v4.subVectors(e.rig.root.position, center).setY(0);
        const hitPt = new THREE.Vector3(e.rig.root.position.x, 1.35, e.rig.root.position.z);
        this.damageEnemy(e, dmg, _v4, false, hitPt);
      }
    }
  }

  private updateFloatingDamages(dt: number): void {
    for (let i = this.floatingDamages.length - 1; i >= 0; i--) {
      const fd = this.floatingDamages[i];
      fd.life -= dt;
      if (fd.life <= 0) {
        this.scene.remove(fd.sprite);
        fd.texture.dispose();
        fd.material.dispose();
        this.floatingDamages.splice(i, 1);
        continue;
      }
      const progress = 1 - fd.life / fd.maxLife;
      fd.pos.y += fd.velY * dt * (1 - progress * 0.45);
      fd.sprite.position.copy(fd.pos);
      // Punchy scale-pop on entry then gentle fade out
      const pop = progress < 0.16 ? 0.75 + (progress / 0.16) * 0.4 : 1.15 - progress * 0.2;
      fd.sprite.scale.set(fd.baseScaleX * pop, fd.baseScaleY * pop, 1);
      fd.material.opacity = progress > 0.55 ? 1 - (progress - 0.55) / 0.45 : 1;
    }
  }

  private updateKalboishakhiStorm(dt: number): void {
    this.stormRig.uniforms.uTime.value = this.worldTime;
    this.stormTeleportFlash = Math.max(0, this.stormTeleportFlash - dt * 0.72);

    // Pause storm countdown while still watching the intro WBTC bridge bus ride
    if (this.busMode === 'riding_intro') {
      this.outsideStorm = false;
      this.outsideStormElapsed = 0;
      this.stormDrainTimer = 0;
      return;
    }

    // 4 contraction stages every 90 seconds from huge full-map 550u down to 22u showdown
    const stageRadii = [this.initialStormRadius, 260, 130, 58, 22];

    if (this.stormShrinking) {
      this.stormShrinkElapsed += dt;
      const t = Math.min(1, this.stormShrinkElapsed / this.stormShrinkDuration);
      const ease = t * t * (3 - 2 * t);
      this.stormRadius = THREE.MathUtils.lerp(this.stormStartRadius, this.stormTargetRadius, ease);
      if (t >= 1) {
        this.stormShrinking = false;
        this.stormPhase = Math.min(stageRadii.length, this.stormPhase + 1);
        this.stormCountdown = this.stormPhaseInterval;
      }
    } else if (this.stormPhase < stageRadii.length) {
      this.stormCountdown -= dt;
      if (this.stormCountdown <= 0) {
        this.stormShrinking = true;
        this.stormShrinkElapsed = 0;
        this.stormStartRadius = this.stormRadius;
        this.stormTargetRadius = stageRadii[this.stormPhase];
        this.stormCountdown = 0;
        this.audio.playStormWarning();
        this.waveBanner = 'কালবৈশাখী বলয় সংকুচিত হচ্ছে!';
        this.waveBannerTimer = 2.8;
      }
    }

    this.stormRig.wallMesh.scale.set(this.stormRadius, 1, this.stormRadius);
    this.stormRig.groundRing.scale.set(this.stormRadius, this.stormRadius, 1);

    // Check if player is outside the safe circle
    const checkPos = this.busMode === 'driving' ? this.busPos : this.heroPos;
    const distFromCenter = Math.hypot(
      checkPos.x - this.stormCenter.x,
      checkPos.z - this.stormCenter.y,
    );
    this.outsideStorm = distFromCenter > this.stormRadius;

    if (this.outsideStorm && !this.heroJumpingFromBus) {
      // Ultra-slow minimal HP drain: strictly 1 HP every 5 seconds (max 12 HP over 60 seconds)
      this.outsideStormElapsed += dt;
      this.stormDrainTimer += dt;

      while (this.stormDrainTimer >= 5.0) {
        this.stormDrainTimer -= 5.0;
        if (this.busMode === 'driving') {
          this.health = Math.max(0, this.health - 1);
          this.damageFlash = Math.max(this.damageFlash, 0.22);
          if (this.health <= 0) {
            this.busMode = 'none';
            this.hero.root.visible = true;
            this.damagePlayer(1, true);
            return;
          }
        } else {
          this.health = Math.max(0, this.health - 1);
          this.damageFlash = Math.max(this.damageFlash, 0.22);
          if (this.health <= 0) {
            this.damagePlayer(1, true);
            return;
          }
        }
      }

      // After 60 full seconds outside, Kalboishakhi wind automatically teleports player inside the Safe Zone
      if (this.outsideStormElapsed >= this.outsideStormDuration) {
        this.triggerKalboishakhiTeleport();
      }
    } else {
      // Re-entering the Safe Zone immediately stops drain and resets the 60-second timer
      this.outsideStormElapsed = 0;
      this.stormDrainTimer = 0;
    }
  }

  private triggerKalboishakhiTeleport(): void {
    const departPos = _v2.copy(this.busMode === 'driving' ? this.busPos : this.heroPos);

    // Safely dismount if driving the bus so the wind drops the hero cleanly onto walkable ground
    if (this.busMode === 'driving') {
      this.busMode = 'none';
      this.busSpeed = 0;
      this.hero.root.visible = true;
    }
    this.scopeActive = false;

    const bounds = this.world.playableBounds;
    const safeMaxR = Math.max(3.2, this.stormRadius - 2.4);
    const sampleMaxR = Math.min(safeMaxR, 145);
    const dest = _v3.set(this.stormCenter.x, 0, this.stormCenter.y);

    // Active grounded enemies inside or close to the current safe zone
    const activeEnemies = this.enemies.filter((e) => {
      if (e.dying || e.busSeatIndex >= 0 || e.jumpingFromBus) return false;
      const d = Math.hypot(
        e.rig.root.position.x - this.stormCenter.x,
        e.rig.root.position.z - this.stormCenter.y,
      );
      return d <= this.stormRadius + 4;
    });

    const clampInsideSafeZone = (pt: THREE.Vector3) => {
      pt.x = THREE.MathUtils.clamp(pt.x, bounds.minX + 1.5, bounds.maxX - 1.5);
      pt.z = THREE.MathUtils.clamp(pt.z, bounds.minZ + 1.5, bounds.maxZ - 1.5);
      const dx = pt.x - this.stormCenter.x;
      const dz = pt.z - this.stormCenter.y;
      const d = Math.hypot(dx, dz);
      if (d > safeMaxR && d > 0.001) {
        pt.x = this.stormCenter.x + (dx / d) * safeMaxR;
        pt.z = this.stormCenter.y + (dz / d) * safeMaxR;
      }
      if (this.world.isWaterBlocked(pt.x, pt.z)) {
        pt.z = pt.z > -45.5 ? -18.5 : -74.0;
      }
      this.resolveCircleWorldCollision(pt, 0.62, true);
      pt.y = this.world.getGroundHeight(pt.x, pt.z);
    };

    // 50% chance to drop near an active enemy warrior; 50% chance to drop at a distant safe spot
    const placeNearEnemy = activeEnemies.length > 0 && Math.random() < 0.5;

    if (placeNearEnemy) {
      const targetEnemy = activeEnemies[Math.floor(Math.random() * activeEnemies.length)];
      let bestFound = false;
      for (let attempt = 0; attempt < 12; attempt++) {
        const ang = Math.random() * Math.PI * 2;
        const dist = 5.8 + Math.random() * 3.8;
        dest.set(
          targetEnemy.rig.root.position.x + Math.cos(ang) * dist,
          0,
          targetEnemy.rig.root.position.z + Math.sin(ang) * dist,
        );
        clampInsideSafeZone(dest);
        const finalDistToCenter = Math.hypot(
          dest.x - this.stormCenter.x,
          dest.z - this.stormCenter.y,
        );
        if (finalDistToCenter <= this.stormRadius - 1.2) {
          bestFound = true;
          break;
        }
      }
      if (!bestFound) {
        dest.set(this.stormCenter.x, 0, this.stormCenter.y);
        clampInsideSafeZone(dest);
      }
    } else {
      // Distant quiet location inside the Safe Zone (farthest from active enemies)
      let bestScore = -Infinity;
      const candidate = _v4;
      for (let attempt = 0; attempt < 16; attempt++) {
        const ang = Math.random() * Math.PI * 2;
        const rad = sampleMaxR * (0.2 + Math.sqrt(Math.random()) * 0.72);
        candidate.set(
          this.stormCenter.x + Math.cos(ang) * rad,
          0,
          this.stormCenter.y + Math.sin(ang) * rad,
        );
        clampInsideSafeZone(candidate);

        let nearestEnemyDist = 30;
        for (const e of activeEnemies) {
          const d = Math.hypot(
            candidate.x - e.rig.root.position.x,
            candidate.z - e.rig.root.position.z,
          );
          if (d < nearestEnemyDist) nearestEnemyDist = d;
        }
        const distFromDepart = Math.hypot(candidate.x - departPos.x, candidate.z - departPos.z);
        const score = nearestEnemyDist * 1.4 + Math.min(24, distFromDepart) * 0.45;
        if (score > bestScore) {
          bestScore = score;
          dest.copy(candidate);
        }
      }
    }

    // Swirling departure wind burst
    this.spawnParticles(_v1.set(departPos.x, 1.0, departPos.z), 0x7ceeff, 16, 7.5);
    this.spawnParticles(_v1.set(departPos.x, 1.3, departPos.z), 0xc7a6ff, 12, 6.2);

    // Teleport hero cleanly into the Safe Zone on valid solid terrain
    this.heroPos.copy(dest);
    this.heroPos.y = this.world.getGroundHeight(this.heroPos.x, this.heroPos.z);
    this.hero.root.position.copy(this.heroPos);

    // Swirling arrival wind burst + dust eddy
    this.spawnParticles(_v1.set(this.heroPos.x, 0.9, this.heroPos.z), 0x82f0ff, 20, 8.2);
    this.spawnParticles(_v1.set(this.heroPos.x, 1.2, this.heroPos.z), 0xffe296, 14, 6.5);

    this.stormTeleportFlash = 1.0;
    this.camShake = Math.min(0.62, this.camShake + 0.45);
    this.audio.playStormTeleport();
    this.waveBanner = 'কালবৈশাখী ঝড় আপনাকে উড়িয়ে নিয়ে এসেছে!';
    this.waveBannerTimer = 3.8;

    this.outsideStormElapsed = 0;
    this.stormDrainTimer = 0;
    this.outsideStorm = false;
    this.emitHud();
  }

  private updateParticles(dt: number): void {
    for (const p of this.particles) {
      if (!p.active) continue;
      p.life -= dt;
      if (p.life <= 0) {
        p.active = false;
        p.mesh.visible = false;
        continue;
      }
      p.vel.y -= 14 * dt;
      p.pos.addScaledVector(p.vel, dt);
      if (p.pos.y < 0.05) {
        p.pos.y = 0.05;
        p.vel.y *= -0.35;
      }
      p.mesh.position.copy(p.pos);
      const t = p.life / p.maxLife;
      p.mesh.scale.setScalar(p.scale * t);
    }
  }

  private checkHighScore(): void {
    if (this.score > this.highScore) {
      this.highScore = this.score;
      try {
        localStorage.setItem(STORAGE_KEY_HIGHSCORE, String(this.highScore));
      } catch {
        // ignore storage errors
      }
    }
  }

  // --- Render Loop with Software-WebGL Pacing ---

  private afterDraw(cb: () => void): void {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) return;
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private tick = (): void => {
    if (this.disposed) return;

    const now = performance.now();
    const rawDt = (now - this.lastFrameMs) / 1000;
    this.lastFrameMs = now;
    const dt = Math.min(Math.max(rawDt, 0.001), 0.05);

    this.update(dt);
    this.renderer.render(this.scene, this.camera);

    // Emit HUD snapshot at ~20Hz so React never throttles the 60fps WebGL loop
    this.hudEmitAccum += dt;
    if (this.hudEmitAccum >= 0.05) {
      this.hudEmitAccum = 0;
      this.emitHud();
    }

    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  };

  private emitHud(): void {
    const alive = this.enemies.filter((e) => !e.dying).length;
    const activeSlot = this.weaponSlots[this.weaponType];
    const locPos = this.busMode !== 'none' ? this.busPos : this.heroPos;
    this.onHudUpdate({
      phase: this.phase,
      busMode: this.busMode,
      nearBus: this.nearBus,
      nearChest: this.nearChest,
      busZoneLabel: this.busMode === 'riding_intro' ? this.busZoneLabel : null,
      locationName: this.world.getLocationName(locPos.x, locPos.z, locPos.y),
      busSpeedKmh: Math.round(Math.abs(this.busSpeed) * 3.6),
      busRouteProgress: this.busRouteT,
      busInteriorCam: this.busInteriorCam,
      busExitSlowing: this.busExitSlowing,
      health: Math.ceil(this.health),
      maxHealth: this.maxHealth,
      armor: Math.ceil(this.armor),
      maxArmor: this.maxArmor,
      activeWeapon: this.weaponType,
      weapons: {
        agni47: { ...this.weaponSlots.agni47 },
        kalbhairav: { ...this.weaponSlots.kalbhairav },
        trishul: { ...this.weaponSlots.trishul },
        fala: { ...this.weaponSlots.fala },
      },
      scopeActive: this.scopeActive,
      ammo: activeSlot.ammo,
      maxAmmo: activeSlot.maxAmmo,
      reserveAmmo: activeSlot.reserve,
      isReloading: this.isReloading,
      reloadProgress: this.isReloading
        ? 1 - Math.max(0, this.reloadTimer / Math.max(0.01, this.reloadDuration))
        : 1,
      sanjibaniCount: this.sanjibaniCount,
      sanjibaniCollected: this.sanjibaniCollected,
      maxSanjibani: this.maxSanjibani,
      isHealing: this.isHealing,
      healProgress: this.isHealing
        ? 1 - Math.max(0, this.healTimer / this.healDuration)
        : 0,
      grenadeCount: this.grenadeCount,
      maxGrenades: this.maxGrenades,
      headshots: this.headshots,
      bodyshots: this.bodyshots,
      stormPhase: this.stormPhase,
      stormCountdown: Math.ceil(this.stormCountdown),
      stormShrinking: this.stormShrinking,
      outsideStorm: this.outsideStorm,
      outsideStormRemaining: this.outsideStorm
        ? Math.max(0, Math.ceil(this.outsideStormDuration - this.outsideStormElapsed))
        : this.outsideStormDuration,
      stormTeleportFlash: this.stormTeleportFlash,
      stormRadius: Math.round(this.stormRadius),
      score: this.score,
      highScore: this.highScore,
      kills: this.kills,
      wave: this.wave,
      enemiesRemaining: alive + this.waveEnemiesToSpawn.length,
      waveBanner: this.waveBanner,
      damageFlash: this.damageFlash,
      hitMarker: this.hitMarker,
      hitMarkerKill: this.hitMarkerKill,
      hitMarkerHeadshot: this.hitMarkerHeadshot,
      muted: this.audio.isMuted(),
      sprintRatio: this.sprintStamina,
      pickupToast: this.pickupToast,
    });
  }

  // --- Event Listeners ---

  private onKeyDown = (e: KeyboardEvent): void => {
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
      e.preventDefault();
    }

    if (this.phase === 'title' && (e.code === 'Enter' || e.code === 'Space')) {
      this.startGame();
      return;
    }

    if (e.code === 'Escape' || e.code === 'KeyP') {
      if (this.phase === 'playing' || this.phase === 'paused') {
        this.togglePause();
      }
      return;
    }

    if (this.phase !== 'playing') return;

    // Bus Jump/Exit, Re-Enter, OR Open Warrior Loot Chest ('F')
    if (e.code === 'KeyF') {
      if (this.busMode !== 'none') {
        this.exitBus();
      } else if (this.nearChest) {
        this.openNearestChest();
      } else if (this.nearBus) {
        this.enterBus();
      }
      return;
    }
    if (e.code === 'Space' && this.busMode === 'riding_intro') {
      this.exitBus();
      return;
    }
    if ((e.code === 'KeyV' || e.code === 'KeyC') && this.busMode === 'riding_intro') {
      this.toggleBusCameraView();
      return;
    }
    if (e.code === 'KeyH' && this.busMode !== 'none') {
      this.honkBusHorn();
      return;
    }

    // Battle Royale Quick-Switch Weapons (1-4), Scope (X), Sanjibani Heal (H/V), Bajra Gola (G)
    if (this.busMode === 'none') {
      if (e.code === 'Digit1') {
        this.setWeaponType('agni47');
        return;
      }
      if (e.code === 'Digit2') {
        this.setWeaponType('kalbhairav');
        return;
      }
      if (e.code === 'Digit3') {
        this.setWeaponType('trishul');
        return;
      }
      if (e.code === 'Digit4') {
        this.setWeaponType('fala');
        return;
      }
      if (e.code === 'KeyG') {
        this.throwGrenade();
        return;
      }
      if (e.code === 'KeyH' || e.code === 'KeyV') {
        this.useSanjibani();
        return;
      }
      if (e.code === 'KeyX' && this.weaponType === 'trishul') {
        this.toggleScope();
        return;
      }
    }

    this.keysHeld.add(e.code);
    if (e.code === 'KeyR') {
      this.attemptStartReload();
    }
    if (e.code === 'KeyM') {
      this.toggleMute();
    }
  };

  private onKeyUp = (e: KeyboardEvent): void => {
    this.keysHeld.delete(e.code);
  };

  private onWindowBlur = (): void => {
    this.keysHeld.clear();
    this.mouseShootHeld = false;
    this.dragLookActive = false;
    this.dragPointerId = null;
    this.lobbyDragActive = false;
    this.lobbyDragPointerId = null;
    this.virtualInput.shooting = false;
  };

  private onPointerDown = (e: PointerEvent): void => {
    if (e.target !== this.renderer.domElement) return;

    // Free Fire-style lobby: drag left/right to rotate the 3D Bengali hero
    if (this.phase === 'title') {
      this.lobbyDragActive = true;
      this.lobbyDragPointerId = e.pointerId;
      this.lobbyLastDragX = e.clientX;
      return;
    }

    if (this.phase !== 'playing') return;
    this.audio.unlock();

    if (e.pointerType === 'mouse') {
      if (e.button === 2 && this.weaponType === 'trishul' && this.busMode === 'none') {
        this.toggleScope();
        return;
      }
      if (e.button === 0) {
        this.mouseShootHeld = true;
      }
      // Allow smooth mouse drag camera turning on left or right button
      this.dragLookActive = true;
      this.dragPointerId = e.pointerId;
      this.lastDragX = e.clientX;
      this.lastDragY = e.clientY;
    } else {
      // Touch drag on open canvas area rotates the camera smoothly
      this.dragLookActive = true;
      this.dragPointerId = e.pointerId;
      this.lastDragX = e.clientX;
      this.lastDragY = e.clientY;
    }
  };

  private onPointerMove = (e: PointerEvent): void => {
    if (this.phase === 'title') {
      if (this.lobbyDragActive && e.pointerId === this.lobbyDragPointerId) {
        const dx = e.clientX - this.lobbyLastDragX;
        this.lobbyLastDragX = e.clientX;
        this.lobbyHeroTargetYaw += dx * 0.011;
      }
      return;
    }

    if (this.phase !== 'playing') return;

    if (document.pointerLockElement === this.renderer.domElement) {
      this.camYaw -= e.movementX * 0.0032;
      this.camPitch = THREE.MathUtils.clamp(this.camPitch + e.movementY * 0.0024, -0.12, 0.65);
      return;
    }

    if (this.dragLookActive && e.pointerId === this.dragPointerId) {
      const dx = e.clientX - this.lastDragX;
      const dy = e.clientY - this.lastDragY;
      this.lastDragX = e.clientX;
      this.lastDragY = e.clientY;
      this.virtualInput.lookDeltaX += dx;
      this.virtualInput.lookDeltaY += dy;
    }
  };

  private onPointerUp = (e: PointerEvent): void => {
    if (e.pointerId === this.lobbyDragPointerId) {
      this.lobbyDragActive = false;
      this.lobbyDragPointerId = null;
    }
    if (e.pointerType === 'mouse' && e.button === 0) {
      this.mouseShootHeld = false;
    }
    if (e.pointerId === this.dragPointerId) {
      this.dragLookActive = false;
      this.dragPointerId = null;
    }
  };

  private onContextMenu = (e: MouseEvent): void => {
    if (this.phase === 'playing') {
      e.preventDefault();
    }
  };

  private onResize = (): void => {
    const w = this.container.clientWidth || window.innerWidth;
    const h = Math.max(1, this.container.clientHeight || window.innerHeight);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
  };

  private bindEvents(): void {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onWindowBlur);
    window.addEventListener('resize', this.onResize);
    this.renderer.domElement.addEventListener('pointerdown', this.onPointerDown);
    window.addEventListener('pointermove', this.onPointerMove);
    window.addEventListener('pointerup', this.onPointerUp);
    window.addEventListener('pointercancel', this.onPointerUp);
    this.renderer.domElement.addEventListener('contextmenu', this.onContextMenu);
  }

  public dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);

    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onWindowBlur);
    window.removeEventListener('resize', this.onResize);
    this.renderer.domElement.removeEventListener('pointerdown', this.onPointerDown);
    window.removeEventListener('pointermove', this.onPointerMove);
    window.removeEventListener('pointerup', this.onPointerUp);
    window.removeEventListener('pointercancel', this.onPointerUp);
    this.renderer.domElement.removeEventListener('contextmenu', this.onContextMenu);

    this.scene.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh) {
        const mesh = obj as THREE.Mesh;
        mesh.geometry?.dispose();
        if (Array.isArray(mesh.material)) {
          mesh.material.forEach((m) => m.dispose());
        } else {
          mesh.material?.dispose();
        }
      }
    });

    this.textures.disposeAll();
    this.audio.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
